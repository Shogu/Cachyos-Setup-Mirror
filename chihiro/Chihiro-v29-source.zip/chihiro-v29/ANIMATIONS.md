# Animations de Chihiro — v11

Les poses existantes `img-raw/green/pose-walk-2.png`, `pose-walk-3.png` et
`pose-walk-3b.png` proviennent des images de référence extraites du film. Le cycle
de marche utilise désormais ces trois poses réelles au lieu de répéter des variantes
quasi identiques (simple décalage vertical), ce qui réduisait fortement la sensation
de mouvement.

Le cycle de base alterne les poses 2, 3 et 3b, à cadence plus rapide, tandis que la
locomotion du moteur a été accélérée. Les durées d'immobilité ont été réduites et la
probabilité de marche augmentée. Les comportements spéciaux `hop` et `climb` sont
maintenant réellement sélectionnables par le système pondéré (ils étaient définis mais
absents de la table des comportements).

Pour générer à nouveau les poses depuis les images sources déjà présentes dans le
projet de préparation :

```sh
cd "chihiro-desktop-companion (Copie)"
python3 tools/matting.py tools/picks6.json
python3 tools/build-sprites.py
```

Les fichiers vidéo complets ne sont pas redistribués dans le paquet de l'extension.
Les sprites restent dans les deux tenues et sur une toile transparente 128×160.

## v17 — culbutes

Les poses `shimeT1.png` à `shimeT4.png`, présentes dans les deux tenues, sont désormais utilisées dans le cycle `fall`. Le cycle se joue pendant la descente physique et s’interrompt à l’atterrissage. De rares fins de parcours depuis un mur ou le plafond peuvent aussi déclencher une chute.


## Repos v18
La tenue verte n'utilise plus les frames 1/1a/1b au repos, car elles représentent une foulée de course. Le cycle calme utilise les poses debout 3/3a/3b/3c/3d, à durée ralentie. Le kimono utilise une boucle de repos plus lente et un clignement discret.


## Repos vivant (v19)

La pose debout utilise les images IDLE propres à chaque tenue et un mouvement continu très discret du corps : cycle lent de 3,8 s, déplacement vertical inférieur à 2 px et variation d’échelle verticale de 0,6 %. Le pivot est placé aux pieds afin de préserver le contact avec le sol. Cette micro-animation continue indépendamment des changements d’image, contrairement à une boucle composée seulement de poses presque identiques.


## Repos vivant (v20)
La tenue debout conserve ses poses dessinées dédiées et reçoit une boucle continue de 4,6 secondes : respiration légère, petit transfert latéral et inclinaison presque imperceptible. Les transformations sont remises à zéro hors repos afin qu'aucune inclinaison ne contamine la marche ou les chutes. Ce mouvement reste procédural : il ne remplace pas de nouveaux dessins image par image du visage ou des cheveux.

## Repos v21
La boucle verte ralentit les changements de pose afin de mieux suggérer un transfert de poids. Le souffle conserve maintenant le signe d'orientation du personnage : regarder vers la gauche ne doit pas être annulé par l'animation. La boucle du kimono emploie un clignement très bref.


## Course (v26)
- `RUN1` à `RUN6` : six poses du kimono rouge, fournies dans le pack de sprites de course.
- Fichiers installés : `img/red/run1.png` à `img/red/run6.png`, toile RGBA 128×160, pieds alignés sur y=160.
- Action courte (1,8–3,2 s), plus rapide que la marche ; choisie rarement en mode libre et uniquement avec la tenue rouge.

### Réactions contextuelles v29
- Retour après absence : utilise le plan `look` existant, sans inventer de nouvelle pose. Seuil de cinq minutes d'inactivité, puis réaction au premier geste utilisateur.
- Changement de fenêtre focalisée : utilise également `look`, avec un délai minimal de trois minutes entre réactions.
- Les phrases restent facultatives et respectent les réglages indépendants de bulles et notifications.
