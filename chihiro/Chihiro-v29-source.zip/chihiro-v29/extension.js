

import GLib from 'gi://GLib';
import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GObject from 'gi://GObject';
import St from 'gi://St';
import Meta from 'gi://Meta';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as MessageTray from 'resource:///org/gnome/shell/ui/messageTray.js';
import {QuickToggle, SystemIndicator} from 'resource:///org/gnome/shell/ui/quickSettings.js';

import {Engine} from './lib/engine.js';
import {Sprite} from './lib/sprite.js';
import {frameFile} from './lib/config.js';
import {MprisMonitor} from './lib/mpris.js';
import {shouldReactToReturn, shouldReactToWindowChange} from './lib/ambient.js';

const OUTFIT_SWITCH_CHANCE = 0.25;   // à chaque changement de comportement, si « Aléatoire »
const DRAG_THRESHOLD = 6;    // px the mouse must move before a press becomes a drag (otherwise it is a click)
const BUBBLE_SECS = 6;
const LOGIN_WINDOW_S = 20;

// Bulles rotatives pour l'heure. Toutes les formulations sont des adaptations originales
// dans la voix de Chihiro, jamais présentées comme des citations littérales du film.
// {time} est remplacé par « X h YY ».
const ANNOUNCE_PHRASES = [
    '{time} — Bon, une chose à la fois… on va finir ce qu’on a commencé.',
    '{time} — Ce qui est passé est passé. Maintenant, on continue.',
    '{time} — N’oublie pas ton nom, ni le chemin pour rentrer.',
    '{time} — Le temps avance, même quand on aimerait revenir en arrière.',
    '{time} — Moi, c’est Chihiro. Et je suis toujours là !',
    '{time} — Il ne faut pas rester figée trop longtemps. Allez, on y va.',
    '{time} — Même si le train file, on peut encore prendre le temps de respirer.',
    '{time} — Je veille encore un peu. Mais toi aussi, pense à souffler.',
    '{time} — Parfois, il suffit de regarder ailleurs quelques secondes.',
];
const WORK_BREAK_PHRASES = [
    'Je suis un peu patraque, moi… On pourrait souffler un instant ?',
    'Assieds-toi deux minutes avec moi, d’accord ?',
    'Les yeux aussi ont besoin de respirer.',
    'Je crois que le thé serait meilleur loin de l’écran.',
    'Même si on veut continuer, parfois il faut reprendre des forces.',
];
const BATTERY_PHRASE = 'La batterie faiblit… comme le fleuve qui s\'assèche.';
const CLICK_PHRASES = [
    'Bon, une chose à la fois. On va y arriver.',
    'Ce qui est passé est passé… on peut encore agir maintenant.',
    'Moi, c’est Chihiro ! Enchantée… enfin, tu me connais déjà.',
    'Le train file sur la mer, mais on a encore le temps de respirer.',
    'Ne t’inquiète pas, je reste par ici.',
    'Je suis un peu patraque aujourd’hui… mais ça va aller.',
];
const CLICK_PLATFORM_PHRASES = [
    'Oh, une fenêtre ! On peut marcher dessus ?',
    'Assise sur le rebord, ça repose.',
    'Vue d\'ici, ton bureau a l\'air tout petit.',
];

// Toggles des Quick Settings, sans icône dans la barre du haut :
// trois états — Au repos (désactivée), Chihiro (tenue verte), Sen (kimono).
// Sur GNOME 51 : QuickToggle (pas « Toggle ») + addExternalIndicator.
const ChihiroToggle = GObject.registerClass(
class ChihiroToggle extends QuickToggle {
    _init() {
        super._init({title: 'Chihiro', iconName: 'chihiro-symbolic', toggle_mode: false});
    }
});

const ChihiroIndicator = GObject.registerClass(
class ChihiroIndicator extends SystemIndicator {
    // volontairement vide : aucun icône dans le panneau, seuls les toggles comptent
});

// Source de notification avec le visage de Chihiro en couleur
const ChihiroSource = GObject.registerClass(
class ChihiroSource extends MessageTray.Source {
    _init(iconPath) {
        super._init({title: 'Chihiro'});
        this._iconPath = iconPath;
    }

    createIcon(size) {
        return new St.Icon({
            gicon: Gio.FileIcon.new(Gio.File.new_for_path(this._iconPath)),
            icon_size: size,
        });
    }
});
function shellAgeSeconds() {
    try {
        const dec = new TextDecoder();
        const stat = dec.decode(GLib.file_get_contents('/proc/self/stat')[1]);
        const start = Number(stat.slice(stat.lastIndexOf(')') + 2).split(' ')[19]) / 100;
        const up = Number(dec.decode(GLib.file_get_contents('/proc/uptime')[1]).split(' ')[0]);
        return up - start;
    } catch (e) {
        return Infinity;
    }
}

export default class ChihiroExtension extends Extension {
    enable() {
        this._settings = this.getSettings();
        this._ids = [];            // [object, signalId]
        this._timer = 0;
        this._announceTimer = 0;
        this._workBreakTimer = 0;
        this._agendaTimer = 0;
        this._memoryTimer = 0;
        this._updatesTimer = 0;
        this._demoTimer = 0;
        this._demoIndex = 0;
        this._updatesChecking = false;
        this._memoryLow = false;
        this._agendaAnnounced = new Set();
        this._batteryLow = false;
        this._upower = null;
        this._lastUserInput = GLib.get_monotonic_time();
        this._lastReturnReaction = 0;
        this._lastWindowReaction = 0;
        this._focusedIdentity = '';
        this._focusedWork = false;
        this._bubble = null; this._bubbleTimer = 0; this._bubbleCapId = 0;
        this._dragging = false; this._press = null;

        // GNOME
        if (!this._settings.get_boolean('launch-at-login') && shellAgeSeconds() < LOGIN_WINDOW_S) {
            this._loginTimer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 3, () => {
                this._loginTimer = 0;
                Main.extensionManager.disableExtension(this.uuid);
                return GLib.SOURCE_REMOVE;
            });
            return;
        }

        if (!Sprite.hasAssets(this.path)) {
            Main.notify('Chihiro', 'Sprites are missing. Reinstall the Chihiro extension.');
            return;
        }

        this._engine = new Engine();
        // Observe media playback now; visual listening/dancing awaits dedicated sprites.
        this._musicState = {playing: false, player: null, title: null, artists: []};
        this._mpris = new MprisMonitor(state => {
            this._musicState = state;
            this._engine?.setContext({music: state.playing});
            if (this._running()) this._schedule();
        });
        this._sprite = new Sprite(this.path);
        this._engine.setContext({outfit: this._sprite.outfit});
        this._overview = false;
        this._mon = -1;
        this._buildQuickSettings();
        this._connect(this._settings, 'changed', () => this._applySettings());
        this._connect(Main.layoutManager, 'monitors-changed', () => this._applyBounds());
        this._connect(global.display, 'workareas-changed', () => this._applyBounds());
        this._connect(global.display, 'window-created', () => this._schedulePlatformRefresh());
        this._connect(global.display, 'notify::focus-window', () => this._updateFocusContext());
        this._connect(global.stage, 'captured-event', (_stage, event) => this._onUserInput(event));
        this._connect(global.display, 'restacked', () => this._schedulePlatformRefresh());
        this._connect(global.workspace_manager, 'active-workspace-changed', () => this._schedulePlatformRefresh());
        this._platformTimer = 0;
        this._wanderTimer = 0;
        this._teleportTimer = 0;
        this._platformPollTimer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 1, () => {
            this._refreshPlatforms();
            return GLib.SOURCE_CONTINUE;
        });
        this._connect(Main.overview, 'showing', () => { this._overview = true; this._applySettings(); });
        this._connect(Main.overview, 'hiding', () => { this._overview = false; this._applySettings(); });
        this._connect(this._sprite.hit, 'button-press-event', (_a, ev) => this._onPress(ev));
        this._applyBounds(true);
        this._source = new ChihiroSource(`${this.path}/img/chihiro-face.png`);
        Main.messageTray.add(this._source);
        this._setupBattery();
        this._updateFocusContext();
        this._restartMemoryMonitor();
        this._restartUpdatesMonitor();
        this._restartWanderTimer();
        this._applySettings();
    }

    disable() {
        if (this._loginTimer) GLib.source_remove(this._loginTimer);
        if (this._announceTimer) GLib.source_remove(this._announceTimer);
        if (this._workBreakTimer) GLib.source_remove(this._workBreakTimer);
        if (this._agendaTimer) GLib.source_remove(this._agendaTimer);
        if (this._memoryTimer) GLib.source_remove(this._memoryTimer);
        if (this._updatesTimer) GLib.source_remove(this._updatesTimer);
        if (this._demoTimer) GLib.source_remove(this._demoTimer);
        if (this._platformTimer) GLib.source_remove(this._platformTimer);
        if (this._wanderTimer) GLib.source_remove(this._wanderTimer);
        if (this._teleportTimer) GLib.source_remove(this._teleportTimer);
        if (this._platformPollTimer) GLib.source_remove(this._platformPollTimer);
        this._loginTimer = this._platformTimer = this._platformPollTimer = 0;
        this._wanderTimer = this._teleportTimer = 0;
        this._announceTimer = this._workBreakTimer = this._agendaTimer = 0;
        this._memoryTimer = this._updatesTimer = this._demoTimer = 0;
        this._engine?.setContext({lowBattery: false, focused: false});
        this._upower?.run_dispose();
        this._upower = null;
        this._mpris?.destroy();
        this._mpris = null;
        this._musicState = {playing: false, player: null, title: null, artists: []};
        this._stopTimer();
        this._endGrab();
        this._hideBubble();
        for (const [obj, id] of this._ids ?? []) obj.disconnect(id);
        this._ids = null;
        if (this._indicator) {
            for (const item of this._indicator.quickSettingsItems) item.destroy();
            this._indicator.destroy();
        }
        this._indicator = null;
        this._toggle = null;
        this._quickSettings = null;
        this._source?.destroy();
        this._source = null;
        this._sprite?.destroy();
        this._sprite = null;
        this._engine = null;
        this._settings = null;
    }

    _connect(obj, name, fn) { this._ids.push([obj, obj.connect(name, fn)]); }

    // ---- timer: runs only when something changes (about 3x/s idle, 25x/s moving) ----
    _stopTimer() {
        if (this._timer) GLib.source_remove(this._timer);
        this._timer = 0;
    }
    _schedule() {
        this._stopTimer();
        if (!this._running()) return;
        const ms = this._engine.wake();
        if (ms < 0) return;
        this._timer = GLib.timeout_add(GLib.PRIORITY_DEFAULT, ms, () => {
            this._timer = 0;
            const now = GLib.get_monotonic_time();
            this._engine.step((now - this._last) / 1000);
            this._last = now;
            this._render();
            this._schedule();
            return GLib.SOURCE_REMOVE;
        });
    }
    _running() { return this._settings.get_boolean('visible') && !this._overview; }
    _render() {
        const h = new Date().getHours();
        const night = this._settings.get_boolean('night-mode') && (h >= 23 || h < 7);
        if (night !== this._lastNight) {
            this._lastNight = night;
            this._engine.setCfg({night});
        }
        const act = this._engine.act?.name;
        if (act !== this._lastActName) {
            this._lastActName = act;
            if (act !== 'run' && this._settings.get_string('outfit') === 'auto' && Math.random() < OUTFIT_SWITCH_CHANCE) {
                this._sprite.setOutfit(Math.random() < 0.5 ? 'green' : 'red');
                this._engine.setContext({outfit: this._sprite.outfit});
                this._syncToggle();                 // l'icône suit la tenue portée en mode aléatoire
            }
        }
        this._sprite.update(this._engine.view());
    }

    // ---- bureau : activité utilisateur et application au premier plan ----
    _onUserInput(event) {
        const type = event.type();
        if (type === Clutter.EventType.KEY_PRESS || type === Clutter.EventType.BUTTON_PRESS ||
            type === Clutter.EventType.TOUCH_BEGIN || type === Clutter.EventType.MOTION) {
            const now = GLib.get_monotonic_time();
            const returned = shouldReactToReturn(this._lastUserInput, now, this._lastReturnReaction);
            this._lastUserInput = now;
            if (returned && this._running() && !this._settings.get_boolean('paused') &&
                !this._overview && !this._dragging && !this._grab) {
                this._lastReturnReaction = now;
                this._engine.trigger('look');
                const phrase = 'Ah, te revoilà ! Je gardais tranquillement ta place.';
                this._notifyMaybe(phrase);
                this._bubbleMaybe(phrase);
                this._last = now;
                this._schedule();
            }
        }
        return Clutter.EVENT_PROPAGATE;
    }

    _updateFocusContext() {
        if (!this._engine) return;
        const win = global.display.get_focus_window();
        let identity = '';
        try {
            identity = `${win?.get_wm_class() ?? ''} ${win?.get_gtk_application_id() ?? ''}`.toLowerCase();
        } catch (e) { /* certaines fenêtres n'exposent pas de classe */ }
        const previousIdentity = this._focusedIdentity;
        this._focusedIdentity = identity;
        const now = GLib.get_monotonic_time();
        if (shouldReactToWindowChange(previousIdentity, identity, this._lastWindowReaction, now) &&
            this._running() && !this._settings.get_boolean('paused') && !this._overview &&
            !this._dragging && !this._grab) {
            this._lastWindowReaction = now;
            this._engine.trigger('look');
            // No title or application name is collected or displayed.
            if (this._speaking() && Math.random() < 0.35) {
                const phrase = 'Oh, on change de fenêtre ? Je regarde un peu.';
                this._notifyMaybe(phrase);
                this._bubbleMaybe(phrase);
            }
            this._last = now;
            this._schedule();
        }
        // Détection volontairement limitée aux outils de développement : pas au simple navigateur.
        const focused = /(^|[ ._-])(terminal|console|ptyxis|kgx|gnome-terminal|gnome-console|konsole|kitty|alacritty|wezterm|foot|code|codium|vscodium|vscode|pycharm|idea|geany|sublime_text|emacs)([ ._-]|$)/.test(identity);
        if (focused === this._focusedWork) return;
        this._focusedWork = focused;
        this._engine.setContext({focused});
        if (this._running()) this._schedule();
    }

    // ---- settings -> engine ----
    _applySettings() {
        const s = this._settings;
        this._engine.setCfg({
            speed: s.get_double('speed'), activity: s.get_double('activity'), size: s.get_double('size'),
            climbing: s.get_boolean('climbing'), jumping: s.get_boolean('jumping'),
            paused: s.get_boolean('paused'),
        });
        this._restartAnnounceTimer();
        this._sprite.setOverFullscreen(s.get_boolean('show-over-fullscreen'));
        const outfitPref = s.get_string('outfit');
        if (outfitPref !== 'auto') this._sprite.setOutfit(outfitPref);
        this._engine.setContext({outfit: this._sprite.outfit});
        const show = this._running();
        this._sprite.setShown(show);
        this._sprite.setInteractive(show);          // clic simple pour parler ; clic-glissé gauche ou droit pour déplacer
        if (!show) this._hideBubble();
        this._syncToggle();
        this._restartWorkBreakTimer();
        this._restartAgendaTimer();
        this._restartMemoryMonitor();
        this._restartUpdatesMonitor();
        this._restartWanderTimer();
        this._restartDemoTimer();
        this._last = GLib.get_monotonic_time();
        if (show) this._render();
        this._schedule();
    }

    _schedulePlatformRefresh() {
        if (this._platformTimer) GLib.source_remove(this._platformTimer);
        this._platformTimer = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 220, () => {
            this._platformTimer = 0;
            this._refreshPlatforms();
            return GLib.SOURCE_REMOVE;
        });
    }

    _refreshPlatforms() {
        if (!this._engine) return;
        const bounds = this._workArea(this._mon);
        const activeWorkspace = global.workspace_manager.get_active_workspace();
        const platforms = [];
        for (const actor of global.get_window_actors()) {
            const win = actor.get_meta_window();
            if (!win || win.get_window_type() !== Meta.WindowType.NORMAL || win.minimized || !actor.mapped)
                continue;
            if (win.get_workspace() !== activeWorkspace || !win.showing_on_its_workspace())
                continue;
            const rect = win.get_frame_rect();
            const x1 = Math.max(bounds.x1, rect.x);
            const x2 = Math.min(bounds.x2, rect.x + rect.width);
            if (x2 - x1 < 112 || rect.y <= bounds.y1 + 48 || rect.y >= bounds.y2 - 72)
                continue;
            platforms.push({x1, x2, y: rect.y, id: win.get_stable_sequence()});
        }
        this._engine.setPlatforms(platforms);
        if (this._running()) this._render();
    }

    _workArea(i) {
        const r = Main.layoutManager.getWorkAreaForMonitor(i);
        return {x1: r.x, y1: r.y, x2: r.x + r.width, y2: r.y + r.height};
    }
    _applyBounds(initial = false) {
        const lm = Main.layoutManager;
        if (this._mon < 0 || this._mon >= lm.monitors.length) this._mon = lm.primaryIndex;
        this._engine.setBounds(this._workArea(this._mon));
        this._refreshPlatforms();
        if (initial) {
            const b = this._engine.b;
            this._engine.x = b.x1 + (b.x2 - b.x1) * (0.2 + 0.6 * Math.random());
            this._engine.setBounds(b);
        }
        if (this._running()) this._render();
    }

    // Déplacements surprises, peu fréquents et suspendus quand l'utilisateur met en pause.
    _restartWanderTimer() {
        if (this._wanderTimer) GLib.source_remove(this._wanderTimer);
        this._wanderTimer = 0;
        if (!this._settings || !this._settings.get_boolean('visible')) return;
        const delay = 180 + Math.floor(Math.random() * 181); // 3 à 6 minutes
        this._wanderTimer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, delay, () => {
            this._wanderTimer = 0;
            const userQuiet = GLib.get_monotonic_time() - this._lastUserInput >= 45 * 1000000;
            if (!this._settings.get_boolean('demo-mode') && this._running() && userQuiet && !this._settings.get_boolean('paused') && !this._dragging && !this._grab &&
                this._engine && this._engine.surface !== 'air' && Math.random() < 0.72)
                this._beginWander();
            this._restartWanderTimer();
            return GLib.SOURCE_REMOVE;
        });
    }

    _restartDemoTimer() {
        if (this._demoTimer) GLib.source_remove(this._demoTimer);
        this._demoTimer = 0;
        if (!this._settings?.get_boolean('demo-mode') || !this._engine) return;
        const steps = [
            ['walk', 'Je marche un peu pour me dégourdir les jambes.'],
            ['stand', 'Je reprends mon souffle… doucement.'],
            ['look', 'Je regarde autour de moi, pour ne pas me perdre.'],
            ['sit', 'Une petite pause, ça fait du bien.'],
            ['hop', 'Hop ! Je peux encore sauter !'],
            ['climb', 'Je vais essayer de grimper un peu.'],
            ['fall', 'Oups ! Aïe… je me suis encore laissée tomber !'],
            ['stand', 'Tout va bien. Je me remets debout.'],
        ];
        this._demoTimer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 5, () => {
            if (!this._settings || !this._settings.get_boolean('demo-mode')) {
                this._demoTimer = 0;
                return GLib.SOURCE_REMOVE;
            }
            const [action, phrase] = steps[this._demoIndex % steps.length];
            this._demoIndex++;
            // La cadence des notifications reste bien de 5 s, même si l'animation est en pause.
            this._notify(`DEMO · ${phrase}`);
            if (this._running() && !this._settings.get_boolean('paused') && !this._dragging && !this._grab) {
                this._engine.demoStep(action);
                this._render();
                this._schedule();
            }
            return GLib.SOURCE_CONTINUE;
        });
    }

    _beginWander() {
        if (this._teleportTimer || !this._engine || !this._sprite ||
            !this._running() || this._settings.get_boolean('paused') || this._dragging || this._grab)
            return;
        this._hideBubble();
        // Un petit fondu évite l'effet de téléportation brutale.
        this._sprite.ease({opacity: 0, duration: 180, mode: Clutter.AnimationMode.EASE_OUT_QUAD});
        this._teleportTimer = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 520, () => {
            this._teleportTimer = 0;
            // L'utilisateur peut avoir mis en pause ou commencé à déplacer Chihiro pendant le fondu.
            if (!this._engine || !this._sprite || !this._running() ||
                this._settings.get_boolean('paused') || this._dragging || this._grab ||
                this._engine.surface === 'air' || this._engine.surface === 'drag') {
                this._sprite?.ease({opacity: 255, duration: 140, mode: Clutter.AnimationMode.EASE_OUT_QUAD});
                return GLib.SOURCE_REMOVE;
            }

            const currentX = this._engine.x;
            const currentPlatform = this._engine.platform;
            // Évite de réapparaître presque au même endroit ou sur le même rebord.
            const candidates = this._engine.platforms.filter(p => p.x2 - p.x1 >= 150 &&
                p.id !== currentPlatform?.id && Math.abs((p.x1 + p.x2) / 2 - currentX) > 150);
            const useWindow = candidates.length > 0 && Math.random() < 0.67;
            let platform = null, x;
            if (useWindow) {
                platform = candidates[Math.floor(Math.random() * candidates.length)];
                x = platform.x1 + 48 + Math.random() * Math.max(1, platform.x2 - platform.x1 - 96);
            } else {
                const b = this._engine.b;
                const left = b.x1 + 48, right = b.x2 - 48;
                // Choisir une zone suffisamment éloignée, avec repli sûr sur toute la largeur.
                const farZones = [left, left + (right - left) * 0.25,
                    left + (right - left) * 0.5, left + (right - left) * 0.75, right]
                    .filter(pos => Math.abs(pos - currentX) > 180);
                x = farZones.length
                    ? farZones[Math.floor(Math.random() * farZones.length)]
                    : left + Math.random() * Math.max(1, right - left);
            }
            this._engine.teleportTo(x, platform);
            this._last = GLib.get_monotonic_time();
            this._render();
            this._sprite.ease({opacity: 255, duration: 220, mode: Clutter.AnimationMode.EASE_OUT_QUAD});
            this._schedule();
            return GLib.SOURCE_REMOVE;
        });
    }

    // ---- click and drag ----
    _canDrag() {
        return this._settings.get_boolean('draggable') && !this._settings.get_boolean('paused');
    }
    // Clic gauche + déplacement (y compris tap-and-drag du pavé tactile) : déplacer Chihiro. Un clic simple reste une interaction. Le clic droit maintenu reste également accepté.
    _onPress(ev) {
        const button = ev.get_button();
        if (this._grab) return Clutter.EVENT_PROPAGATE;
        if (button === Clutter.BUTTON_SECONDARY) {
            if (!this._canDrag()) return Clutter.EVENT_STOP;
            this._hideBubble();
            const [px, py] = ev.get_coords();
            this._press = {px, py, button};
            this._dragging = false;
        } else if (button === Clutter.BUTTON_PRIMARY) {
            this._hideBubble();
            const [px, py] = ev.get_coords();
            this._press = {px, py, button};
            this._dragging = false;
        } else return Clutter.EVENT_PROPAGATE;
        this._grab = global.stage.grab(this._sprite.hit);
        this._dragIds = [
            this._sprite.hit.connect('motion-event', (_a, e) => this._onMotion(e)),
            this._sprite.hit.connect('button-release-event', () => this._onRelease()),
        ];
        return Clutter.EVENT_STOP;
    }
    // phrases de clic : citation au hasard, ou une remarque selon l'endroit
    _clickPhrase() {
        if (this._engine?.platform && Math.random() < 0.7) {
            return CLICK_PLATFORM_PHRASES[Math.floor(Math.random() * CLICK_PLATFORM_PHRASES.length)];
        }
        return CLICK_PHRASES[Math.floor(Math.random() * CLICK_PHRASES.length)];
    }

    _onRelease() {
        const wasClick = !this._dragging && this._press?.button === Clutter.BUTTON_PRIMARY;
        this._endGrab();
        if (wasClick) {
            const phrase = this._clickPhrase();
            if (this._settings.get_boolean('voice-bubbles')) this._showBubble(phrase);
            else if (this._settings.get_boolean('voice-notifications')) this._notify(phrase);
        }
        return Clutter.EVENT_STOP;
    }
    _onMotion(ev) {
        const [px, py] = ev.get_coords();
        if (!this._dragging) {
            if (!this._press || ![Clutter.BUTTON_PRIMARY, Clutter.BUTTON_SECONDARY].includes(this._press.button) || !this._canDrag() ||
                Math.hypot(px - this._press.px, py - this._press.py) < DRAG_THRESHOLD)
                return Clutter.EVENT_STOP;
            this._dragging = true;
            this._engine.beginDrag(this._press.px, this._press.py);
            this._last = GLib.get_monotonic_time();
            this._schedule();
        }
        const lm = Main.layoutManager;
        const i = lm.monitors.findIndex(m => px >= m.x && px < m.x + m.width && py >= m.y && py < m.y + m.height);
        if (i >= 0 && i !== this._mon) { this._mon = i; this._engine.setBounds(this._workArea(i)); }
        this._engine.dragTo(px, py);
        return Clutter.EVENT_STOP;
    }
    _endGrab() {
        if (this._dragIds) for (const id of this._dragIds) this._sprite?.hit.disconnect(id);
        this._dragIds = null;
        if (this._grab) {
            this._grab.dismiss(); this._grab = null;
            if (this._dragging) this._engine?.endDrag();
        }
        this._dragging = false; this._press = null;
        if (this._engine && this._running()) { this._last = GLib.get_monotonic_time(); this._schedule(); }
    }

    // ---- annonces périodiques : temps d'écran signé Chihiro ----
    _restartAnnounceTimer() {
        if (this._announceTimer) { GLib.source_remove(this._announceTimer); this._announceTimer = 0; }
        if (!this._settings || !this._settings.get_boolean('screen-time-announce')) return;
        const mins = Math.max(1, this._settings.get_int('screen-time-mins'));
        this._announceTimer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, mins * 60, () => {
            this._announceTimer = 0;
            this._announceScreenTime();
            this._restartAnnounceTimer();
            return GLib.SOURCE_REMOVE;
        });
    }

    // notification signée Chihiro, avec son visage en couleur
    _notify(text) {
        if (!this._source) {
            Main.notify('Chihiro', text);
            return;
        }
        let notification;
        try {
            notification = new MessageTray.Notification({source: this._source, title: 'Chihiro', body: text});
        } catch (e) {
            notification = new MessageTray.Notification(this._source, 'Chihiro', text);
        }
        this._source.showNotification(notification);
    }

    // ---- voix : deux interrupteurs indépendants, Bulles et Notifications ----
    _notifyMaybe(text) {
        if (this._settings.get_boolean('voice-notifications')) this._notify(text);
    }

    _bubbleMaybe(text) {
        if (this._settings.get_boolean('voice-bubbles') && this._running()) this._showBubble(text);
    }

    _speaking() {
        return this._settings.get_boolean('voice-bubbles') ||
            this._settings.get_boolean('voice-notifications');
    }

    _announceScreenTime() {
        if (!this._running()) return;
        const age = shellAgeSeconds();
        const h = Math.floor(age / 3600);
        const m = Math.round((age % 3600) / 60);
        const time = `${h} h ${String(m).padStart(2, '0')}`;
        const phrase = ANNOUNCE_PHRASES[Math.floor(Math.random() * ANNOUNCE_PHRASES.length)]
            .replace('{time}', time);
        this._notifyMaybe(`⏰ ${phrase}`);
        this._bubbleMaybe(`⏰ ${phrase}`);
        this._last = GLib.get_monotonic_time();
        this._schedule();
    }

    // ---- rythme de travail : pause régulière, désactivable ----
    _restartWorkBreakTimer() {
        if (this._workBreakTimer) { GLib.source_remove(this._workBreakTimer); this._workBreakTimer = 0; }
        if (!this._settings || !this._settings.get_boolean('work-break')) return;
        const mins = Math.max(1, this._settings.get_int('work-break-mins'));
        this._workBreakTimer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, mins * 60, () => {
            this._workBreakTimer = 0;
            this._announceWorkBreak();
            this._restartWorkBreakTimer();
            return GLib.SOURCE_REMOVE;
        });
    }

    _announceWorkBreak() {
        if (!this._running()) return;
        const phrase = WORK_BREAK_PHRASES[Math.floor(Math.random() * WORK_BREAK_PHRASES.length)];
        this._notifyMaybe(`☕ ${phrase}`);
        this._bubbleMaybe(`☕ ${phrase}`);
        this._engine.trigger('sit');
        this._last = GLib.get_monotonic_time();
        this._schedule();
    }

    // ---- agenda GNOME : préavis des rendez-vous, désactivable ----
    _restartAgendaTimer() {
        if (this._agendaTimer) { GLib.source_remove(this._agendaTimer); this._agendaTimer = 0; }
        if (!this._settings || !this._settings.get_boolean('agenda-announce')) return;
        this._agendaTimer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 300, () => {
            this._agendaTimer = 0;
            this._checkAgenda();
            this._restartAgendaTimer();
            return GLib.SOURCE_REMOVE;
        });
    }

    _checkAgenda() {
        if (!this._settings.get_boolean('agenda-announce')) return;
        const now = Math.floor(Date.now() / 1000);
        const until = now + Math.max(1, this._settings.get_int('agenda-lead-mins')) * 60 + 60;
        try {
            Gio.DBus.session.call('org.gnome.Shell.CalendarServer',
                '/org/gnome/Shell/CalendarServer', 'org.gnome.Shell.CalendarServer',
                'GetEvents', new GLib.Variant('(xxb)', [now, until, false]),
                null, Gio.DBusCallFlags.NONE, 8000, null, (bus, res) => {
                    try {
                        const [events] = bus.call_finish(res).deepUnpack();
                        this._announceEvents(events);
                    } catch (e) {
                        console.error(`Chihiro: agenda illisible: ${e}`);
                    }
                });
        } catch (e) {
            console.error(`Chihiro: appel agenda impossible: ${e}`);
        }
    }

    _announceEvents(events) {
        if (!Array.isArray(events)) return;
        const lead = Math.max(1, this._settings.get_int('agenda-lead-mins')) * 60;
        const nowS = Date.now() / 1000;
        if (this._agendaAnnounced.size > 200) this._agendaAnnounced.clear();
        for (const ev of events) {
            try {
                if (!Array.isArray(ev) || ev.length < 6) continue;
                const id = String(ev[0]);
                const summary = String(ev[1] ?? '');
                // début de l'événement : premier entier microsecondes plausible
                let startUs = 0;
                for (const v of ev.slice(3)) {
                    if (typeof v === 'number' && v > 1e12 && (!startUs || v < startUs)) startUs = v;
                }
                if (!summary || !startUs) continue;
                const startS = startUs / 1e6;
                if (startS < nowS || startS > nowS + lead) continue;
                if (this._agendaAnnounced.has(id)) continue;
                this._agendaAnnounced.add(id);
                const hhmm = new Date(startS * 1000).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
                const msg = `📅 On a rendez-vous à ${hhmm} : ${summary}. Il ne faudrait pas se perdre en route !`;
                if (this._settings.get_boolean('battery-announce')) {
                    this._notifyMaybe(msg);
                    this._bubbleMaybe(msg);
                }
                if (this._running() && this._speaking()) {
                    this._last = GLib.get_monotonic_time();
                    this._schedule();
                }
            } catch (e) {
                console.error(`Chihiro: événement agenda: ${e}`);
            }
        }
    }

    // ---- mémoire : lecture très légère de /proc/meminfo ----
    _restartMemoryMonitor() {
        if (this._memoryTimer) { GLib.source_remove(this._memoryTimer); this._memoryTimer = 0; }
        if (!this._settings || !this._settings.get_boolean('memory-announce')) return;
        this._memoryTimer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 300, () => {
            this._checkMemory();
            return GLib.SOURCE_CONTINUE;
        });
    }

    _checkMemory() {
        if (!this._settings || !this._settings.get_boolean('memory-announce')) return;
        try {
            const data = new TextDecoder().decode(GLib.file_get_contents('/proc/meminfo')[1]);
            const total = Number(data.match(/^MemTotal:\s+(\d+)/m)?.[1] ?? 0);
            const available = Number(data.match(/^MemAvailable:\s+(\d+)/m)?.[1] ?? 0);
            if (!total || !available) return;
            const percent = Math.round(available * 100 / total);
            const low = percent < this._settings.get_int('memory-threshold');
            if (low && !this._memoryLow) {
                this._memoryLow = true;
                const message = `Ouh là… il ne reste presque plus de place dans la chaufferie : ${percent} % de mémoire disponible (${Math.round(available / 1024)} Mio).`;
                this._notifyMaybe(message);
                this._bubbleMaybe(message);
            } else if (!low && percent >= this._settings.get_int('memory-threshold') + 3) {
                this._memoryLow = false;
            }
        } catch (e) { console.error(`Chihiro: lecture mémoire impossible: ${e}`); }
    }

    // ---- mises à jour : interroge uniquement la base pacman déjà présente ----
    _restartUpdatesMonitor() {
        if (this._updatesTimer) { GLib.source_remove(this._updatesTimer); this._updatesTimer = 0; }
        if (!this._settings || !this._settings.get_boolean('updates-announce')) return;
        const hours = Math.max(2, this._settings.get_int('updates-check-hours'));
        this._updatesTimer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, hours * 3600, () => {
            this._checkUpdates();
            return GLib.SOURCE_CONTINUE;
        });
    }

    _checkUpdates() {
        if (!this._settings || !this._settings.get_boolean('updates-announce') || this._updatesChecking) return;
        try {
            // No sudo, no network and no repository refresh: pacman only compares cached sync databases.
            const proc = Gio.Subprocess.new(['pacman', '-Qu'], Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_PIPE);
            this._updatesChecking = true;
            proc.communicate_utf8_async(null, null, (p, result) => {
                this._updatesChecking = false;
                if (!this._settings || !this._settings.get_boolean('updates-announce')) return;
                try {
                    const [, stdout] = p.communicate_utf8_finish(result);
                    if (!p.get_successful()) return;
                    const packages = (stdout ?? '').split('\n')
                        .map(line => line.trim())
                        .filter(line => line && !line.startsWith('warning:') && !line.startsWith('::'));
                    if (!packages.length) return;
                    const message = `Il y a du nouveau dans les dépôts locaux : ${packages.length} mise${packages.length > 1 ? 's' : ''} à jour disponible${packages.length > 1 ? 's' : ''}. On regardera ça quand tu veux.`;
                    this._notifyMaybe(message);
                    this._bubbleMaybe(message);
                } catch (e) { console.error(`Chihiro: résultat pacman illisible: ${e}`); }
            });
        } catch (e) { console.error(`Chihiro: vérification des mises à jour impossible: ${e}`); }
    }

    // ---- batterie : annonce une seule fois par décharge, désactivable ----
    _setupBattery() {
        try {
            this._upower = new Gio.DBusProxy({
                g_bus_type: Gio.BusType.SYSTEM,
                g_name: 'org.freedesktop.UPower',
                g_object_path: '/org/freedesktop/UPower/devices/DisplayDevice',
                g_interface_name: 'org.freedesktop.UPower.Device',
                g_flags: Gio.DBusProxyFlags.DO_NOT_AUTO_START,
            });
            this._upower.init(null);
            this._upower.connect('g-properties-changed', () => this._checkBattery());
            this._checkBattery();
        } catch (e) {
            console.error(`Chihiro: suivi batterie impossible: ${e}`);
            this._upower = null;
        }
    }

    _checkBattery() {
        if (!this._settings || !this._upower) return;
        try {
            const pct = this._upower.get_cached_property('Percentage')?.unpack() ?? 100;
            const state = this._upower.get_cached_property('State')?.unpack() ?? 1;
            const threshold = this._settings.get_int('battery-threshold');
            const low = state === 2 && pct <= threshold;          // 2 = décharge
            if (low !== this._batteryLow) {
                this._batteryLow = low;
                this._engine?.setContext({lowBattery: low});
                if (this._running()) this._schedule();
            }
            if (low && !this._batteryLowAnnounced) {
                this._batteryLowAnnounced = true;
                const msg = `🔋 ${BATTERY_PHRASE} (${Math.round(pct)} %)`;
                if (this._settings.get_boolean('battery-announce')) {
                    this._notifyMaybe(msg);
                    this._bubbleMaybe(msg);
                }
                if (this._running() && this._speaking()) {
                    this._engine.trigger('sit');
                    this._last = GLib.get_monotonic_time();
                    this._schedule();
                }
            } else if (!low && (state !== 2 || pct > threshold + 3)) {
                this._batteryLowAnnounced = false;
            }
        } catch (e) { /* batterie absente (fixe) : silencieux */ }
    }

    _showBubble(text = 'Chihiro réfléchit…') {
        if (!this._engine || !this._running() || this._bubble) return;
        const base = 'color: #fff4e8; font-weight: normal; padding: 7px 14px; border-radius: 14px; ' +
            'border: 1px solid rgba(185, 131, 112, 0.9); background-color: rgba(43, 35, 38, 0.95);';
        const hover = base.replace('rgba(43, 35, 38, 0.95)', 'rgba(72, 56, 55, 0.97)');
        const btn = new St.Button({label: text, reactive: true, can_focus: true,
            track_hover: true, style: base});
        btn.connect('notify::hover', () => btn.set_style(btn.hover ? hover : base));
        btn.connect('clicked', () => {
            this._hideBubble();
        });
        Main.layoutManager.addChrome(btn, {trackFullscreen: false});
        this._bubble = btn;

        const v = this._engine.view(), b = this._engine.b;
        const w = btn.get_preferred_width(-1)[1], h = btn.get_preferred_height(-1)[1];
        const x = Math.max(b.x1 + 4, Math.min(b.x2 - w - 4, v.x + v.w / 2 - w / 2));
        const y = Math.max(b.y1 + 4, v.y - h - 2);
        btn.set_position(Math.round(x), Math.round(y));

        this._bubbleTimer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, BUBBLE_SECS, () => {
            this._bubbleTimer = 0;
            this._hideBubble();
            return GLib.SOURCE_REMOVE;
        });
        // a press anywhere outside the button closes it (decided by pointer position, not by event source)
        this._bubbleCapId = global.stage.connect('captured-event', (_s, e) => {
            const t = e.type();
            if ((t === Clutter.EventType.BUTTON_PRESS || t === Clutter.EventType.TOUCH_BEGIN) && this._bubble) {
                const [ex, ey] = e.get_coords();
                const [bx, by] = this._bubble.get_transformed_position();
                const [bw, bh] = this._bubble.get_transformed_size();
                const inside = ex >= bx && ex <= bx + bw && ey >= by && ey <= by + bh;
                if (!inside) this._hideBubble();
            }
            return Clutter.EVENT_PROPAGATE;
        });
    }
    _hideBubble() {
        if (this._bubbleTimer) { GLib.source_remove(this._bubbleTimer); this._bubbleTimer = 0; }
        if (this._bubbleCapId) { global.stage.disconnect(this._bubbleCapId); this._bubbleCapId = 0; }
        if (this._bubble) {
            try { Main.layoutManager.removeChrome(this._bubble); this._bubble.destroy(); } catch (e) { console.error(`Chihiro: bubble cleanup failed: ${e}`); }
            this._bubble = null;
        }
    }

    // ---- quick settings ----
    // Toggle à trois états : Au repos -> Chihiro (verte) -> Sen (kimono) -> Au repos.
    _buildQuickSettings() {
        this._toggle = new ChihiroToggle();
        this._toggle.connect('clicked', () => this._cycleState());
        this._indicator = new ChihiroIndicator();   // vide : rien dans la barre du haut
        this._indicator.quickSettingsItems.push(this._toggle);
        this._quickSettings = Main.panel.statusArea.quickSettings;
        this._quickSettings.addExternalIndicator(this._indicator);
        this._syncToggle();
    }

    _stateFromSettings() {
        if (!this._settings.get_boolean('visible')) return 'repos';
        const outfit = this._settings.get_string('outfit');
        if (outfit === 'red') return 'sen';
        if (outfit === 'green') return 'chihiro';
        return this._sprite && this._sprite.outfit === 'red' ? 'sen' : 'chihiro';
    }

    _syncToggle() {
        if (!this._toggle) return;
        const s = this._stateFromSettings();
        const [title, sub, icon] = s === 'repos'
            ? ['Au repos', 'Chihiro dort', 'chihiro-repos-symbolic']
            : s === 'sen'
                ? ['Sen', 'Kimono des bains', 'sen-symbolic']
                : ['Chihiro', 'Tenue verte', 'chihiro-symbolic'];
        this._toggle.title = title;
        this._toggle.subtitle = sub;
        this._toggle.iconName = icon;
        // QuickToggle normally resolves iconName from the system theme. These icons
        // ship with the extension, so point its St.Icon at the real local SVG.
        const iconActor = this._toggle._icon ?? this._toggle.icon;
        if (iconActor) {
            const path = `${this.path}/icons/${icon}.svg`;
            iconActor.gicon = Gio.FileIcon.new(Gio.File.new_for_path(path));
            iconActor.icon_name = null;
        }
        this._toggle.checked = s !== 'repos';
    }

    _cycleState() {
        const cur = this._stateFromSettings();
        const next = cur === 'repos' ? 'chihiro' : cur === 'chihiro' ? 'sen' : 'repos';
        if (next === 'repos') {
            this._settings.set_boolean('visible', false);
        } else {
            this._settings.set_boolean('visible', true);
            this._settings.set_string('outfit', next === 'sen' ? 'red' : 'green');
        }
    }
}