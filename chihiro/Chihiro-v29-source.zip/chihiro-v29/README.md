# Chihiro — v26 (GNOME Shell 51)

Compagnon de bureau animé pour GNOME Shell, avec deux tenues, déplacements autonomes, escalade, sauts, assise sur les fenêtres, bulles et notifications.

## Installation — une seule commande

Depuis le dossier où se trouve l’archive :

```sh
gnome-extensions install --force ./chihiro@desktop-companion.shell-extension.zip
```

La commande installe l’extension et son schéma GSettings inclus dans l’archive. Aucun décompactage manuel, aucune compilation de schéma et aucune dépendance supplémentaire à installer. Active ensuite **Chihiro** dans l’application **Extensions** si elle n’est pas déjà activée. Selon la session GNOME, il peut être nécessaire de se déconnecter puis reconnecter pour charger une extension Shell.

## Feuille de route

Les fonctions restantes, les activités prévues, les besoins en sprites et les étapes de validation sont suivis dans [ROADMAP.md](ROADMAP.md).

## Fonctionnalités

- Déplacements autonomes, marche, repos, assise, escalade et sauts.
- Peut s’asseoir sur le bord supérieur des fenêtres compatibles.
- Clic simple pour lui parler ; clic-glissé gauche ou droit, y compris sur pavé tactile, pour la déplacer.
- Taille réglable de 0,4× à 2,5×, vitesse et fréquence des comportements réglables.
- Tenue verte, tenue rouge ou alternance aléatoire.
- Mode nuit, annonces du temps de session et rappels de pause.
- Directeur d’activités contextuel : écoute musicale, repos nocturne, cooldowns et comportements adaptés aux rebords de fenêtres.
- Annonces de rendez-vous, batterie faible, mémoire disponible basse et mises à jour CachyOS.
- Vérification des mises à jour avec `pacman -Qu`, uniquement à partir des bases locales : aucun rafraîchissement réseau, aucune installation et aucun privilège administrateur.
- Les chutes utilisent les quatre poses de culbute (T1–T4) fournies pour les deux tenues ; de rares descentes volontaires sont possibles depuis les murs et le plafond. Les chutes accidentelles depuis les rebords restent animées jusqu’à l’atterrissage.

## Correctifs v13

- Correction de la signature D-Bus du calendrier GNOME : les bornes temporelles sont transmises en entiers 64 bits, au lieu de la signature incompatible qui empêchait la requête.
- Nettoyage de deux doublons sans effet fonctionnel dans la boucle de rendu et le minuteur.

## Développement et validation

- Extension ciblée sur GNOME Shell 51.
- Le schéma GSettings compilé est inclus dans l’archive d’installation.
- La vérification statique des fichiers JavaScript et du schéma ne remplace pas un essai dans une session GNOME Shell réelle.


### Déplacements surprises (v15)

Toutes les 3 à 6 minutes, Chihiro peut s'éclipser brièvement puis réapparaître ailleurs. Elle privilégie les rebords supérieurs des fenêtres visibles et s'y assied ; sinon, elle revient sur le sol du bureau. Le comportement est suspendu pendant la pause, le glisser-déposer et l'aperçu des activités. Les chutes volontaires restent désactivées.


### v15 — déplacements surprises fiabilisés
- Fondu avant et après chaque réapparition.
- Annulation propre si une pause ou un glisser-déposer commence pendant la disparition.
- Destination choisie plus loin de la position précédente, en évitant le même rebord de fenêtre.


### v16 — Chihiro suit les fenêtres
- Correction du suivi des fenêtres : si une fenêtre se déplace ou se redimensionne pendant que Chihiro est assise sur son bord, elle conserve sa position relative et reste posée sur le rebord.
- Les anciennes coordonnées du rebord sont conservées avant le rafraîchissement, ce qui évite de perdre le déplacement de la fenêtre lors de la mise à jour de la géométrie.

### v19 — culbutes et voix de Chihiro
- Activation des poses de culbute T1–T4 pendant les chutes, avec transition vers l’atterrissage.
- Faible probabilité de petits gadins volontaires depuis les murs et le plafond, sans rendre ces comportements dominants.
- Ajout de la formulation originale « Je suis un peu patraque, moi… » aux réactions et rappels de pause.
- Réécriture des bulles horaires, phrases de clic, alertes mémoire, rendez-vous et mises à jour pour qu’elles soient des adaptations dans la voix de Chihiro, sans guillemets suggérant des citations littérales du film.
- Validation statique et tests du moteur à effectuer ; un essai en vraie session GNOME Shell 51 reste indispensable.

### Tests automatisés

Depuis la racine du dossier source, si Node.js est installé :

```sh
node --experimental-default-type=module tests/smoke.mjs
```

Ce test vérifie la séquence de culbute, la présence des poses dans les deux tenues et le retour au sol après une chute. Il ne remplace pas la validation visuelle dans GNOME Shell.


### v19 — animation et démonstration
- Les sprites de course ne sont plus utilisés pour l'animation de repos verte ; boucle de repos ralentie.
- Ajout du mode DEMO dans les préférences : séquence automatique d'actions et notification GNOME toutes les cinq secondes.
- Le mode DEMO suspend les déplacements surprises pour éviter que les comportements se concurrencent.
- Limite connue : la silhouette et les jambes restent contraintes par les sprites source ; la validation visuelle doit être faite dans GNOME Shell 51.


### v19 — repos animé en continu

Le repos ne dépend plus uniquement de la succession de sprites : une respiration verticale discrète et un balancement lent sont rendus en continu, ancrés aux pieds. En état debout, le moteur se réveille à 80 ms pour garder le mouvement fluide sans utiliser la cadence de la marche. Les poses IDLE restent spécifiques à chaque tenue.


### v21 — repos plus visible
- Cycle de repos ralenti à 4,6 s avec respiration, léger transfert latéral et inclinaison du corps.
- Mise à l'échelle très discrète pour donner du volume au souffle, avec pivot aux pieds.
- Retour explicite à une transformation neutre dès que Chihiro marche, tombe, grimpe ou s'assoit.
- Ajout de contrôles automatisés pour vérifier les micro-mouvements de repos.

### v21 — repos et orientation corrigés
- Boucle d'attente plus lente et moins saccadée pour limiter l'effet de marche sur place.
- Correction du signe de l'échelle horizontale : le souffle ne renverse plus l'orientation gauche/droite.
- Marche de la tenue rouge basée sur des poses debout/déplacement adaptées plutôt que sur les poses d'attente.
- Clignement du kimono réduit à une pose très brève dans le cycle de repos.

### v24 — préparation de la musique
- Ajout d'une observation MPRIS passive pour détecter les lecteurs en cours de lecture, avec priorité à Semitone.
- Aucun bouton de lecture n'est envoyé et aucun lecteur n'est lancé.
- Les animations d'écoute et de danse seront activées après création des sprites dédiés.


### v24 — directeur d’activités contextuel

- Ajout de `lib/director.js` pour arbitrer les comportements selon le contexte.
- En lecture musicale MPRIS, Chihiro privilégie les poses calmes déjà disponibles (debout, assise, regard) et réduit fortement marche, sauts et escalade.
- À l’arrêt de la musique, le comportement autonome normal reprend. Le mode nuit conserve sa priorité.
- Aucune animation de danse ou d’écoute avec accessoire n’est simulée : ces activités attendent leurs sprites dédiés.


## Correctifs v25

- Le directeur centralise désormais les choix en mode libre, écoute, nuit et assise sur un rebord.
- La lecture musicale réduit fortement les déplacements ; après quatre minutes, Chihiro privilégie encore davantage les poses calmes.
- Le mode nuit prend la priorité sur la musique et favorise nettement le repos, y compris sur les rebords.
- Ajout de temporisations anti-répétition pour marche, regard, assise, saut et escalade.
- Les sauts spontanés vers les fenêtres sont suspendus pendant l’écoute et la nuit.
- Les activités nécessitant de nouveaux sprites (lecture, thé, carnet, sieste, danse) restent volontairement désactivées jusqu’à la production des images correspondantes.


### v26 — course de Sen
- Intégration des six sprites corrigés de course du kimono rouge, normalisés sur la toile 128×160 avec transparence et ancrage aux pieds.
- Ajout d'une action `run` distincte de `walk`, avec une vitesse supérieure, une boucle à six poses et une durée courte.
- Le directeur ne peut choisir la course qu'en tenue rouge, en mode libre, rarement et avec un long cooldown ; elle est exclue de l'écoute musicale et du mode nuit.
- La tenue verte conserve uniquement sa marche existante : aucune course verte n'est simulée.

### v27 — arbitrage contextuel consolidé
- Réorganisation de `ActivityDirector` autour d'une priorité explicite : nuit, batterie faible, écoute musicale, travail concentré, puis mode libre.
- Ajout des contextes `lowBattery` et `focused` à l'API du directeur ; ils restent inactifs tant que l'extension ne leur transmet pas de signal fiable.
- Ajout d'un instantané d'état (`snapshot()`) pour faciliter les diagnostics et les futurs réglages.
- Les répétitions immédiates sont légèrement défavorisées, sans pouvoir supplanter les priorités du contexte (notamment le repos nocturne).
- Les temporisations restent centralisées et les activités sans sprites dédiés restent exclues.
- Tests ajoutés pour la hiérarchie des contextes, leur restauration après interruption et les poses sur rebord.


## v28 — réactions au bureau

- Le directeur reçoit maintenant le contexte de batterie faible via UPower, même si les annonces de batterie sont désactivées. Le réglage d'annonce ne contrôle que les notifications et bulles.
- Détection prudente des applications de développement au premier plan (terminaux et éditeurs/IDE connus) : Chihiro adopte alors le profil `focused`. Le navigateur ordinaire n'est pas classé comme outil de développement.
- Suivi des frappes, clics, contacts tactiles et mouvements de pointeur. Les déplacements autonomes surprises attendent au moins 45 secondes sans activité utilisateur afin de ne pas distraire pendant une interaction.
- Les plateformes de fenêtres continuent d'être recalculées périodiquement et après les changements de fenêtres, d'empilement et d'espace de travail.
- Aucun contrôle MPRIS, commande système ni lecture du contenu des fenêtres n'est ajouté.

## v29 — réactions de présence et de changement de fenêtre

- Après au moins cinq minutes sans frappe, clic, mouvement ni contact tactile, le premier geste de l'utilisateur déclenche une brève réaction de retour (regard + phrase facultative).
- Lors d'un changement réel de fenêtre focalisée, Chihiro peut lancer un regard ; une remarque facultative et peu fréquente accompagne parfois ce changement.
- Les réactions sont limitées par un délai anti-répétition de trois minutes et respectent pause, mode aperçu, glisser-déposer et visibilité.
- Les titres de fenêtres ne sont jamais lus ni conservés ; seules les identités techniques de classe/application déjà utilisées pour reconnaître les outils de développement sont comparées en mémoire.
- Ajout de tests unitaires pour les seuils d'absence, les changements de focus et les délais anti-répétition.
