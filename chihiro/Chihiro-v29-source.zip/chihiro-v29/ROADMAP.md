# Chihiro — feuille de route restante

État de référence : sources v26, extension ciblant GNOME Shell 51.

Ce document distingue les fonctions déjà présentes, les travaux à terminer et les idées validées pour la suite. Les comportements nouveaux ne doivent pas être simulés avec des sprites inadaptés : chaque activité visuelle doit disposer de poses cohérentes pour les deux tenues (`green` et `red`), avec transparence, toile et point d'ancrage constants.

## 1. Stabilisation de la base — priorité haute

- [ ] Installer et tester l'extension dans une vraie session GNOME Shell 51.
- [ ] Vérifier le chargement/désactivation, les préférences, le schéma GSettings et les notifications après reconnexion.
- [ ] Tester les déplacements, les rebords, le suivi des fenêtres, le glisser-déposer, les pauses, les changements d'espace/écran et les déplacements surprises.
- [ ] Vérifier les deux tenues à plusieurs tailles et vitesses, sur écran HiDPI et avec plusieurs fenêtres.
- [ ] Corriger les erreurs Shell/logs et les défauts visuels constatés en situation réelle.
- [ ] Garder les chutes volontaires désactivées ; conserver les chutes accidentelles et leurs culbutes.
- [ ] Compléter les tests automatisés du moteur et documenter une procédure de validation/reproduction.

## 2. Activités autonomes et loisirs — périmètre validé

### Musique et danse
- [ ] Détecter les lecteurs actifs via MPRIS/D-Bus, sans contrôler ni interrompre la lecture.
- [ ] Donner la priorité à Semitone lorsqu'il est actif ; fonctionner aussi avec les autres lecteurs MPRIS.
- [ ] Ajouter une posture d'écoute (éventuellement casque) et une danse courte, rare et aléatoire lorsque de la musique est réellement en lecture.
- [ ] Arrêter/revenir au calme à la pause, à l'arrêt ou à la disparition du lecteur ; gérer proprement les changements de piste.
- [ ] Prévoir une temporisation anti-répétition et ne jamais danser en boucle permanente.

### Lecture
- [ ] Ajouter une animation de lecture avec livre tenu correctement, pages et regard cohérents.
- [ ] *Que faire ?* de Lénine : lecture attentive, parfois petit hochement de tête approbateur.
- [ ] *Nausicaä de la Vallée du Vent* : curiosité, émerveillement et attention soutenue.
- [ ] *Manifeste du parti communiste* de Marx et Engels : lecture concentrée et réfléchie.
- [ ] *Spirou* : lecture plus légère, amusement et sourire.
- [ ] *Le Désert des Tartares* de Dino Buzzati : lecture contemplative, parfois rêveuse.
- [ ] Les couvertures peuvent être reconnaissables, mais les pages intérieures doivent rester génériques : ne pas reproduire de planches ou de pages protégées.
- [ ] Faire varier les réactions selon le livre sans imposer de commentaire politique ou de texte à l'écran.

### Vie quotidienne
- [ ] Regarder par la fenêtre/le bord de l'écran : s'approcher, observer quelques instants, repartir.
- [ ] Faire une sieste : assoupissement progressif, tête qui tombe, réveil/bâillement ; possibilité de s'endormir sur son livre.
- [ ] Boire du thé : faire apparaître une tasse, boire tranquillement, la reposer.
- [ ] Dessiner ou écrire dans un petit carnet, avec pauses de réflexion.
- [ ] Jouer brièvement avec un petit objet (balle, ruban ou objet trouvé), sans animation trop envahissante.
- [ ] S'étirer et se recoiffer/ajuster sa tenue.
- [ ] S'asseoir au bord d'une fenêtre ou d'un rebord et balancer doucement les jambes.
- [ ] Observer un papillon imaginaire, le suivre du regard et essayer de le toucher.
- [ ] Faire quelques pas de danse spontanés, très rarement, même sans musique.
- [ ] Prévoir une petite salutation matinale et une attitude plus somnolente le soir.
- [ ] Réagir à l'inactivité prolongée du poste : s'asseoir, lire ou dormir ; reprendre calmement quand l'utilisateur revient.
- [ ] Réagir à une tâche terminée/compilation réussie uniquement si un signal fiable et explicite est disponible ; ne pas surveiller arbitrairement tous les processus.
- [ ] Ajouter une curiosité discrète envers les fenêtres qui passent devant elle (regard ou petit coup d'œil depuis un rebord), sans gêner leur manipulation.

## 3. Réactions contextuelles et personnalité

- [ ] Compléter les familles de petites phrases et réactions originales : terminal/activité de développement, ressources mémoire, repos/sommeil, batterie faible, mises à jour CachyOS, retour/réapparition, inactivité et rendez-vous/calendrier.
- [ ] Garder des délais probabilistes assez longs, des fréquences basses et des périodes de silence ; aucune notification ne doit devenir répétitive ou envahissante.
- [ ] Utiliser des formulations originales dans la voix du personnage, sans présenter des adaptations comme des citations littérales du film.
- [ ] Faire correspondre les réactions à l'état courant : pas de lecture pendant une chute, pas de danse si la lecture musicale est arrêtée, pas d'activité longue pendant un glisser-déposer ou une pause.
- [ ] Prévoir des transitions douces, une priorité claire entre comportements et un retour fiable à l'état neutre.

## 4. Production des sprites et intégration graphique

- [ ] Produire les sprites manquants pour chaque activité, d'abord dans la tenue verte puis dans le kimono rouge.
- [ ] Garder une échelle, une toile transparente 128×160 et des points d'ancrage compatibles avec les sprites existants, sauf décision technique documentée.
- [ ] Prévoir plusieurs poses par animation (pas une image fixe étirée artificiellement) : écoute, danse, livre, tasse, carnet, sieste, fenêtre, objet, papillon, étirement et salutation.
- [ ] Vérifier les silhouettes, les mains qui tiennent réellement les objets, la continuité des cheveux/vêtements et l'alignement des pieds.
- [ ] Intégrer les nouveaux frames dans `lib/config.js`, les séquences d'action et le moteur de comportements ; ajouter des tests de présence des assets.
- [ ] Ne pas réutiliser les sprites de marche/repos pour prétendre représenter une activité qui n'existe pas graphiquement.

## 5. Réglages, robustesse et finition

- [ ] Ajouter des réglages simples pour activer/désactiver les activités (au minimum musique/danse et activités autonomes) et ajuster leur fréquence.
- [ ] Respecter le mode pause, le mode démonstration, les interactions utilisateur et les contraintes d'économie de ressources.
- [ ] Vérifier les abonnements D-Bus/MPRIS, les déconnexions et reconnexions, et libérer tous les timers/signaux à la désactivation.
- [ ] Vérifier qu'aucun service externe, accès réseau, privilège ou dépendance superflue n'est ajouté.
- [ ] Mettre à jour README.md et ANIMATIONS.md, les tests, les archives source/installation et les notes de version.
- [ ] Faire une dernière passe de tests sur GNOME Shell 51 et produire une archive d'installation propre.

## Ordre conseillé

1. Stabilisation GNOME 51 et correction des défauts de base.
2. Moteur d'activités : priorités, temporisations, pause, état contextuel et réglages.
3. Intégration MPRIS et musique/danse.
4. Lecture et activités quotidiennes au fur et à mesure que les sprites sont prêts.
5. Réactions contextuelles, tests complets, documentation et paquet final.

## Estimation indicative

Estimation de travail à partir de l'état v21, et non une promesse de délai :

- Validation réelle GNOME 51 et corrections : **4–8 h**.
- Architecture des activités, priorités, réglages et cycle de vie : **5–8 h**.
- MPRIS, écoute et danse (hors création des sprites) : **3–5 h**.
- Intégration des activités de lecture et quotidiennes (hors création des sprites) : **5–9 h**.
- Réactions contextuelles, tests, documentation et empaquetage : **5–8 h**.

Total de codage/intégration estimé : **22–38 heures**. La création, sélection et retouche des sprites peut ajouter **8–20 heures** selon le nombre de poses réellement livrées et leur cohérence. Prévoir donc environ **30–58 heures de travail effectif** pour le périmètre complet, puis une marge si des problèmes apparaissent en session GNOME réelle. En pratique, cela représente plutôt plusieurs sessions de travail qu'une seule soirée.

Le périmètre peut être livré par étapes : une première version stabilisée avec MPRIS, danse et lecture, puis les activités quotidiennes et les réactions plus fines. Le projet n'a pas besoin d'attendre que chaque animation secondaire soit parfaite pour devenir utilisable.

## Avancement v23 — première brique musique

- [x] Ajout d'un observateur MPRIS (`lib/mpris.js`) : découverte des lecteurs déjà lancés, suivi des changements de propriétés et des départs/arrivées sur le bus de session.
- [x] Priorité de sélection à Semitone lorsqu'il joue ; sinon sélection d'un autre lecteur en lecture.
- [x] Aucun contrôle de lecture, lancement d'application ou accès réseau : Chihiro observe uniquement l'état MPRIS.
- [x] Nettoyage des abonnements D-Bus à la désactivation de l'extension.
- [ ] Relier l'état musical au directeur d'activités et aux animations d'écoute/danse une fois les sprites disponibles.
- [ ] Tester avec Semitone et plusieurs lecteurs dans une session GNOME Shell 51 réelle.

Cette étape collecte l'état musical mais ne déclenche volontairement pas encore de danse : les sprites dédiés n'existent pas dans les deux tenues.


## Avancement v24 — directeur d’activités initial

- [x] Ajouter `lib/director.js` pour centraliser le choix contextuel des comportements existants.
- [x] Prioriser des comportements calmes pendant la lecture musicale ; réduire marche, sauts et escalade.
- [x] Restaurer le comportement libre à l’arrêt de la musique ; conserver la priorité du mode nuit.
- [x] Ajouter des tests de transition libre / écoute / nuit.
- [ ] Étendre l’arbitrage aux futures activités (lecture, thé, sieste, dessin, danse) seulement après disponibilité des sprites.
- [ ] Ajouter les réglages d’activation et de fréquence après stabilisation des activités.


## Avancement v25 — directeur contextuel enrichi

- [x] Centraliser les décisions des modes libre, écoute musicale, nuit et rebord de fenêtre dans `ActivityDirector`.
- [x] Ajouter des temporisations anti-répétition pour les comportements locomoteurs et spéciaux.
- [x] Adapter les probabilités à la durée d'écoute : après quatre minutes, favoriser encore davantage les poses calmes.
- [x] Donner la priorité au mode nuit sur l'écoute musicale, y compris lorsque Chihiro est assise sur un rebord.
- [x] Supprimer le saut spontané vers les fenêtres pendant l'écoute et le mode nuit.
- [x] Ajouter des tests des modes, priorités, rebords et transitions.
- [ ] Ajouter les activités lecture/thé/carnet/sieste/danse quand les sprites dédiés seront disponibles.
- [ ] Valider le comportement en session GNOME Shell 51 réelle.

Le directeur ne fabrique pas d'animations fictives : il arbitre uniquement entre les séquences graphiques présentes. La compilation stricte du schéma GSettings a été exécutée pour cette archive ; le XML n'a pas nécessité de modification fonctionnelle.


## Avancement v26 — course de Sen intégrée
- [x] Normaliser les six sprites de course rouge sur 128×160 RGBA avec ancrage aux pieds.
- [x] Ajouter une action `run` distincte de la marche, avec vitesse dédiée et boucle six poses.
- [x] Réserver la course à la tenue rouge, au mode libre, avec faible probabilité et cooldown long.
- [x] Exclure la course pendant l'écoute musicale et le mode nuit.
- [ ] Produire les six poses équivalentes pour la tenue verte si la course doit être disponible dans les deux tenues.
- [ ] Tester visuellement l'animation et son orientation dans GNOME Shell 51.

## Avancement v27 — arbitrage consolidé
- [x] Formaliser la hiérarchie des contextes : nuit > batterie faible > écoute > travail concentré > libre.
- [x] Ajouter les états `lowBattery` et `focused` au directeur sans activer de détection système prématurée.
- [x] Ajouter un instantané d'état pour faciliter le diagnostic et les prochaines intégrations.
- [x] Atténuer les choix répétés sans forcer un comportement contraire au contexte prioritaire.
- [x] Tester les priorités, la restauration des états précédents et les choix sur rebord.
- [ ] Relier les contextes batterie faible et travail concentré à des signaux GNOME fiables.
- [ ] Définir les durées et transitions propres à chaque future activité lorsqu'elles auront des sprites dédiés.
