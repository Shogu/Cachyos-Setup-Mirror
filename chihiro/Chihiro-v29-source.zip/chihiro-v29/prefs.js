// SPDX-License-Identifier: GPL-3.0-or-later
import Adw from 'gi://Adw';
import Gtk from 'gi://Gtk';
import Gio from 'gi://Gio';
import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

export default class ChihiroPrefs extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();
        const page = new Adw.PreferencesPage({title: 'Chihiro', icon_name: 'user-available-symbolic'});
        window.add(page);

        const motion = new Adw.PreferencesGroup({title: 'Déplacements',
            description: 'Les changements prennent effet immédiatement.'});
        page.add(motion);
        const spin = (title, subtitle, key, lo, hi, step) => {
            const row = new Adw.SpinRow({title, subtitle, digits: 2,
                adjustment: new Gtk.Adjustment({lower: lo, upper: hi, step_increment: step, page_increment: step * 4})});
            settings.bind(key, row, 'value', Gio.SettingsBindFlags.DEFAULT);
            motion.add(row);
        };
        spin('Vitesse de déplacement', 'Vitesse de marche et d’escalade', 'speed', 0.25, 3, 0.05);
        spin('Fréquence des comportements spéciaux', '0 = désactivés ; plus la valeur est élevée, plus ils sont fréquents', 'activity', 0, 3, 0.1);
        spin('Taille de Chihiro', '1 = taille native ; plage de 0,4 à 2,5', 'size', 0.4, 2.5, 0.1);
        spin('Intervalle des annonces (minutes)', 'Temps d\'écran annoncé par Chihiro', 'screen-time-mins', 5, 360, 5);
        spin('Intervalle des pauses (minutes)', 'Rythme de travail', 'work-break-mins', 15, 180, 5);
        spin('Préavis des rendez-vous (minutes)', 'Elle prévient ce temps avant chaque rdv', 'agenda-lead-mins', 5, 120, 5);
        spin('Seuil de batterie (%)', 'Annonce quand la charge passe sous ce niveau', 'battery-threshold', 5, 40, 1);
        spin('Seuil de mémoire disponible (%)', 'Alerte quand la mémoire disponible passe sous ce niveau', 'memory-threshold', 5, 40, 1);
        spin('Vérification des mises à jour (heures)', 'Interroge la base locale de pacman, sans synchronisation ni installation', 'updates-check-hours', 2, 24, 1);

        const OUTFITS = [['Aléatoire', 'auto'], ['Tenue verte (début du film)', 'green'],
            ['Tenue rouge des bains', 'red']];
        const outfitRow = new Adw.ComboRow({title: 'Tenue',
            subtitle: 'Aléatoire = elle alterne les deux tenues au fil des comportements',
            model: Gtk.StringList.new(OUTFITS.map(([label]) => label))});
        outfitRow.selected = Math.max(0, OUTFITS.findIndex(([, v]) => v === settings.get_string('outfit')));
        outfitRow.connect('notify::selected', () =>
            settings.set_string('outfit', OUTFITS[outfitRow.selected][1]));
        motion.add(outfitRow);

        const toggles = new Adw.PreferencesGroup({title: 'Comportements et notifications'});
        page.add(toggles);
        const sw = (title, subtitle, key) => {
            const row = new Adw.SwitchRow({title, subtitle});
            settings.bind(key, row, 'active', Gio.SettingsBindFlags.DEFAULT);
            toggles.add(row);
        };
        sw('Bulles', 'Elle parle avec des bulles sur le bureau', 'voice-bubbles');
        sw('Notifications', 'Elle parle avec des notifications GNOME (son visage en couleur)', 'voice-notifications');
        sw('Mode DEMO', 'Démonstration automatique : une action et une notification toutes les 5 secondes. À désactiver pour revenir au comportement normal.', 'demo-mode');
        sw('Afficher Chihiro', '', 'visible');
        sw('Mettre les déplacements en pause', 'Chihiro reste immobile jusqu’à la reprise', 'paused');
        sw('Escalade', 'Autoriser Chihiro à grimper aux murs et au plafond', 'climbing');
        sw('Sauts', 'Autoriser les petits sauts et les sauts depuis les murs', 'jumping');
        sw('Annoncer le temps d\'écran', 'Notification signée Chihiro à chaque intervalle', 'screen-time-announce');
        sw('Rythme de travail', 'Elle propose une pause à chaque intervalle', 'work-break');
        sw('Annoncer l\'agenda', 'Préavis des rendez-vous du calendrier GNOME', 'agenda-announce');
        sw('Annoncer la batterie faible', 'Une seule fois par décharge', 'battery-announce');
        sw('Surveiller la mémoire', 'Alerte si la mémoire disponible est basse', 'memory-announce');
        sw('Signaler les mises à jour CachyOS', 'Vérifie les bases locales de pacman, sans réseau ni installation', 'updates-announce');
        sw('Mode nuit', 'Entre 23 h et 7 h, elle marche peu et se repose', 'night-mode');
        sw('Déplacement manuel', 'Fais glisser Chihiro avec le clic gauche ou le tap-glissé du pavé tactile ; un clic simple lui parle. Le clic droit fonctionne aussi.', 'draggable');
        sw('Afficher Chihiro en plein écran', 'Désactivé = elle se cache pendant le plein écran', 'show-over-fullscreen');
        sw('Keep running across logins', 'Off = he never starts by himself when you log in', 'launch-at-login');

        const reset = new Adw.PreferencesGroup();
        page.add(reset);
        const row = new Adw.ActionRow({title: 'Réinitialiser tous les réglages'});
        const btn = new Gtk.Button({label: 'Réinitialiser', halign: Gtk.Align.CENTER});
        btn.connect('clicked', () => { for (const k of settings.list_keys()) settings.reset(k); });
        row.add_suffix(btn);
        reset.add(row);
    }
}