import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {Engine} from '../lib/engine.js';
import {ACTIONS, WALL, CEIL, frameFile} from '../lib/config.js';

assert.deepEqual(ACTIONS.fall.poses.map(([frame]) => frame), ['T1', 'T2', 'T3', 'T4', 'T3', 'T2']);
assert.ok(ACTIONS.stand.poses.every(([frame]) => frame.startsWith('IDLE')), 'idle must use dedicated idle aliases');
const idleEngine = new Engine(() => 0.5);
assert.equal(idleEngine.wake(), 80, 'idle must update continuously for subtle breathing animation');
assert.ok(ACTIONS.walk.poses.every(([frame]) => frame.startsWith('W')), 'walk must use outfit-specific aliases');
assert.deepEqual(ACTIONS.run.poses.map(([frame]) => frame), ['RUN1', 'RUN2', 'RUN3', 'RUN4', 'RUN5', 'RUN6']);
assert.equal(ACTIONS.run.poses.length, 6, 'run uses the six supplied Sen frames');
assert.ok(!ACTIONS.stand.poses.some(([frame]) => ['1', '1a', '1b', '1c', '1d'].includes(frame)), 'green running frames must not be used while idle');
assert.equal(WALL.endWeights.drop, 1);
assert.equal(CEIL.endWeights.drop, 1);
for (const outfit of ['green', 'red']) {
    for (const frame of ['T1', 'T2', 'T3', 'T4', '3', '3a', '3b', '3c', '3d', '1a', '1b', '1blink'])
        assert.ok(existsSync(frameFile(frame, outfit)), `missing ${outfit}/${frame}`);
}
for (let i = 1; i <= 6; i++)
    assert.ok(existsSync(new URL(`../img/red/shimerun${i}.png`, import.meta.url)), `missing red/run${i}.png`);
const engine = new Engine(() => 0.5);
engine.setBounds({x1: 0, y1: 32, x2: 800, y2: 600});
engine._launch(0, 0, 'fall');
const frames = new Set();
for (let i = 0; i < 30 && engine.surface === 'air'; i++) {
    frames.add(engine.view().frame);
    engine.step(40);
}
assert.ok([...frames].some(frame => /^T[1-4]$/.test(frame)), 'fall must show tumble poses');
assert.equal(engine.surface, 'floor', 'fall must end with a landing');
const spriteSource = await (await import('node:fs/promises')).readFile(new URL('../lib/sprite.js', import.meta.url), 'utf8');
assert.match(spriteSource, /Math\.sin\(phase\)/, 'sprite must include continuous idle breathing');
assert.match(spriteSource, /set_pivot_point\(0\.5, 1\.0\)/, 'idle movement must stay anchored at the feet');
assert.match(spriteSource, /facing \* \(1 \+ breath \* 0\.004\)/, 'breathing must preserve facing direction');
assert.ok(ACTIONS.stand.poses.find(([frame]) => frame === 'IDLE4')?.[1] === 40, 'blink pose must be brief');
console.log('Chihiro smoke tests: OK');

const {ActivityDirector} = await import('../lib/director.js');
const director = new ActivityDirector(() => 0);
assert.equal(director.mode, 'free');
assert.equal(director.pick({climbing: true, jumping: true}, 0), 'walk', 'normal mode keeps the usual autonomous movement');
const redRun = new ActivityDirector(() => 0.99);
redRun.setContext({outfit: 'red'}, 0);
assert.equal(redRun.pick({climbing: false, jumping: false}, 0), 'run', 'rare run is available in the red outfit');
const greenNoRun = new ActivityDirector(() => 0.99);
greenNoRun.setContext({outfit: 'green'}, 0);
assert.notEqual(greenNoRun.pick({climbing: false, jumping: false}, 0), 'run', 'run is unavailable without green outfit sprites');
director.setContext({music: true}, 1000);
assert.equal(director.mode, 'listening');
assert.equal(director.pick({climbing: true, jumping: true}, 1000), 'stand', 'music mode favors calm listening poses over movement');
director.setContext({music: false}, 2000);
assert.equal(director.mode, 'free', 'stopping music restores autonomous behavior');
director.setContext({night: true}, 3000);
assert.equal(director.mode, 'night');
const longListen = new ActivityDirector(() => 0);
longListen.setContext({music: true}, 1000);
assert.equal(longListen.pick({climbing: true, jumping: true}, 241000), 'stand', 'long listening remains calm');
assert.equal(longListen.pick({climbing: true, jumping: true}, 242000, {onPlatform: true}), 'ledgeSit', 'listening on a ledge favors sitting');
longListen.setContext({night: true}, 243000);
assert.equal(longListen.mode, 'night', 'night mode takes priority over music');
assert.equal(longListen.pick({climbing: true, jumping: true}, 243000, {onPlatform: true}), 'ledgeSit', 'night mode strongly favors resting on ledges');
const cooldown = new ActivityDirector(() => 0);
cooldown.setContext({music: true}, 0);
cooldown.pick({climbing: true, jumping: true}, 0);
assert.equal(cooldown.pick({climbing: true, jumping: true}, 1000), 'stand', 'cooldowns prevent immediate repetition of movement');

const interruptRun = new Engine(() => 0.5);
interruptRun.setContext({outfit: 'red'});
interruptRun.plan = [{a: 'run', secs: [3, 3], dir: 1}];
interruptRun._next();
assert.equal(interruptRun.act.name, 'run');
interruptRun.setContext({outfit: 'green'});
assert.notEqual(interruptRun.act.name, 'run', 'switching to green interrupts the red-only run animation');

// v27 activity arbitration: explicit context priority and clean restoration.
const priority = new ActivityDirector(() => 0);
priority.setContext({focused: true}, 10);
assert.equal(priority.mode, 'focused');
priority.setContext({music: true}, 20);
assert.equal(priority.mode, 'listening', 'music takes priority over focused work');
priority.setContext({lowBattery: true}, 30);
assert.equal(priority.mode, 'lowBattery', 'low battery takes priority over listening');
priority.setContext({night: true}, 40);
assert.equal(priority.mode, 'night', 'night mode is the highest-priority context');
priority.setContext({night: false}, 50);
assert.equal(priority.mode, 'lowBattery', 'leaving night restores the next active context');
priority.setContext({lowBattery: false, music: false}, 60);
assert.equal(priority.mode, 'focused', 'clearing higher priorities restores focused mode');
assert.equal(priority.snapshot(100).context.focused, true);
const focusedLedge = new ActivityDirector(() => 0);
focusedLedge.setContext({focused: true}, 0);
assert.equal(focusedLedge.pick({climbing: true, jumping: true}, 0, {onPlatform: true}), 'ledgeSit');


// v28 desktop integrations are wired without changing the engine's safe defaults.
const extensionSource = await (await import('node:fs/promises')).readFile(new URL('../extension.js', import.meta.url), 'utf8');
assert.match(extensionSource, /notify::focus-window/, 'focus changes must refresh the work context');
assert.match(extensionSource, /captured-event/, 'desktop input must be observed');
assert.match(extensionSource, />= 45 \* 1000000/, 'surprise wandering waits for a quiet period');
assert.match(extensionSource, /setContext\(\{lowBattery: low\}\)/, 'UPower battery state must reach the director');

// v29 ambient reactions: return-after-absence and focus-change gates are rate-limited.
const {shouldReactToReturn, shouldReactToWindowChange, RETURN_AFTER_MS, REACTION_COOLDOWN_MS} =
    await import('../lib/ambient.js');
const us = ms => ms * 1000;
assert.equal(shouldReactToReturn(0, us(RETURN_AFTER_MS - 1), 0), false);
assert.equal(shouldReactToReturn(0, us(RETURN_AFTER_MS), 0), true);
assert.equal(shouldReactToReturn(0, us(RETURN_AFTER_MS + 1), us(RETURN_AFTER_MS - 60000)), false, 'return reactions respect cooldown');
assert.equal(shouldReactToWindowChange('', 'firefox', 0, us(1000)), false, 'initial focus is not a change');
assert.equal(shouldReactToWindowChange('firefox', 'org.gnome.Terminal', 0, us(1000)), true);
assert.equal(shouldReactToWindowChange('firefox', 'firefox', 0, us(1000)), false);
assert.equal(shouldReactToWindowChange('firefox', 'code', us(1), us(REACTION_COOLDOWN_MS - 1)), false);
assert.equal(shouldReactToWindowChange('firefox', 'code', us(1), us(REACTION_COOLDOWN_MS + 1)), true);
console.log('Chihiro ambient reaction tests: OK');
