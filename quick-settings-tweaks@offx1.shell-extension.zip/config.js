export default {
    isDevelopmentBuild: false,
    isReleaseBuild: false,
    isGithubBuild: false,
    version: "main",
    buildNumber: 0,
    baseGTypeName: "quick-settings-tweaks_",
    loggerPrefix: "[quick-settings-tweaks]",
};
