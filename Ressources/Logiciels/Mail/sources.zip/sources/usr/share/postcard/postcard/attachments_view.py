"""Vue « Pièces jointes » : liste filtrable à gauche, aperçu à droite.

La liste vient de l'index (voir core/mime/attachment_index.py) : on y filtre par
mots-clés, expéditeur, période et type sans toucher au réseau. Le fichier n'est
téléchargé qu'au moment de l'afficher, de l'ouvrir ou de l'enregistrer, via le
même chemin que la lecture d'un message (copie locale si elle existe, sinon
serveur).
"""

import logging
from collections.abc import Callable
from datetime import datetime, timedelta, timezone
from functools import partial
from gettext import gettext as _
from gettext import ngettext
from typing import TYPE_CHECKING

from gi.repository import Adw, Gdk, Gio, GLib, Gtk

from . import mail_sync
from .attachment_preview import AttachmentPreview
from .core.mime.attachment_index import clean_filename
from .core.mime.message_parser import parse_message
from .core.models.attachment import Attachment
from .core.models.folder import FolderRole
from .core.store.database import AttachmentRow

if TYPE_CHECKING:
    from .window import PostcardMainWindow

logger = logging.getLogger(__name__)

# Combien de lignes on construit au maximum : une liste de milliers de lignes
# GTK ralentit l'ouverture, et personne ne les parcourt toutes. Les filtres
# servent à descendre plus loin.
MAX_ROWS = 300
FILTER_DEBOUNCE_MS = 250
SKIPPED_ROLES = (FolderRole.JUNK, FolderRole.TRASH)


def _timestamp(value: str) -> float:
    try:
        return datetime.fromisoformat(value).astimezone().timestamp()
    except (TypeError, ValueError):
        return 0.0


class AttachmentsView(Gtk.Box):
    __gtype_name__ = "PostcardAttachmentsView"

    def __init__(self, window: "PostcardMainWindow") -> None:
        # AdwNavigationSplitView est une classe finale : on la contient plutôt
        # que de la dériver.
        super().__init__()
        self._split = Adw.NavigationSplitView(
            sidebar_width_fraction=0.4,
            min_sidebar_width=300,
            max_sidebar_width=560,
            hexpand=True,
            vexpand=True,
        )
        self.append(self._split)
        self._window = window
        self._refresh_source = 0
        self._preview_token = 0
        self._rows: dict[Gtk.ListBoxRow, AttachmentRow] = {}
        # Les lignes qu'on a ajoutées : on ne retire que celles-là.
        self._previous_rows: list[Gtk.ListBoxRow] = []
        # Ligne de départ des sélections Maj+clic, et blocage des signaux pendant
        # qu'on modifie la sélection en plusieurs temps.
        self._anchor: Gtk.ListBoxRow | None = None
        self._selecting = False

        # (libellé, nombre de jours ; None = sans limite)
        self._periods: list[tuple[str, int | None]] = [
            (_("Any time"), None),
            (_("Last 7 days"), 7),
            (_("Last 30 days"), 30),
            (_("Last 3 months"), 90),
            (_("Last year"), 365),
        ]
        # (libellé, clé de database.ATTACHMENT_KINDS ; "" = tous)
        self._kinds: list[tuple[str, str]] = [
            (_("All types"), ""),
            (_("Documents"), "documents"),
            (_("Images"), "images"),
            (_("Archives"), "archives"),
            (_("Audio and Video"), "media"),
        ]

        self._split.set_sidebar(self._build_list_page())
        self._split.set_content(self._build_preview_page())
        self._install_actions()
        self.connect("map", lambda *_args: self.refresh())

    # --- construction ----------------------------------------------------

    def _build_list_page(self) -> Adw.NavigationPage:
        toolbar = Adw.ToolbarView()
        header = Adw.HeaderBar()
        back = Gtk.Button(
            icon_name="go-previous-symbolic", tooltip_text=_("Back to Mail")
        )
        back.connect("clicked", lambda *_args: self._window.show_mail_view())
        header.pack_start(back)
        self._title = Adw.WindowTitle(title=_("Attachments"), subtitle="")
        header.set_title_widget(self._title)

        menu = Gio.Menu()
        menu.append(_("Free All Local Copies…"), "att.free-all")
        header.pack_end(
            Gtk.MenuButton(
                icon_name="open-menu-symbolic",
                menu_model=menu,
                tooltip_text=_("Attachment Options"),
            )
        )
        toolbar.add_top_bar(header)

        self._text_entry = Gtk.SearchEntry(
            placeholder_text=_("Keywords"), width_chars=12, hexpand=True
        )
        self._sender_entry = Gtk.SearchEntry(
            placeholder_text=_("Sender"), width_chars=10, hexpand=True
        )
        self._period = Gtk.DropDown.new_from_strings(
            [label for label, _days in self._periods]
        )
        self._kind = Gtk.DropDown.new_from_strings(
            [label for label, _key in self._kinds]
        )
        for entry in (self._text_entry, self._sender_entry):
            entry.connect("search-changed", self._schedule_refresh)
        for dropdown in (self._period, self._kind):
            dropdown.connect("notify::selected", self._schedule_refresh)

        filters = Gtk.FlowBox(
            selection_mode=Gtk.SelectionMode.NONE,
            min_children_per_line=1,
            max_children_per_line=2,
            column_spacing=6,
            row_spacing=6,
            homogeneous=False,
            margin_top=6,
            margin_bottom=6,
            margin_start=12,
            margin_end=12,
        )
        for widget in (self._text_entry, self._sender_entry, self._period, self._kind):
            filters.append(widget)
        toolbar.add_top_bar(filters)

        # Ctrl+clic ajoute ou retire une ligne, Maj+clic étend la sélection.
        self._listbox = Gtk.ListBox(selection_mode=Gtk.SelectionMode.MULTIPLE)
        self._listbox.add_css_class("navigation-sidebar")
        self._listbox.connect("selected-rows-changed", self._on_selection_changed)
        self._listbox.connect("row-activated", lambda _box, _row: self._open())
        # Clic simple = cette ligne seule ; Ctrl+clic = ajouter ou retirer ;
        # Maj+clic = étendre. GtkListBox, lui, bascule la ligne à chaque clic.
        left_click = Gtk.GestureClick(button=1)
        left_click.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        left_click.connect("pressed", self._on_left_press)
        self._listbox.add_controller(left_click)
        right_click = Gtk.GestureClick(button=3)
        right_click.connect("pressed", self._on_right_click)
        self._listbox.add_controller(right_click)
        scroller = Gtk.ScrolledWindow(
            hscrollbar_policy=Gtk.PolicyType.NEVER, vexpand=True, child=self._listbox
        )

        self._empty = Adw.StatusPage(
            icon_name="mail-attachment-symbolic", title=_("No Attachments")
        )
        self._stack = Gtk.Stack()
        self._stack.add_named(scroller, "list")
        self._stack.add_named(self._empty, "empty")
        toolbar.set_content(self._stack)

        page = Adw.NavigationPage(title=_("Attachments"), child=toolbar)
        page.add_css_class("pane-conversations")
        return page

    def _build_preview_page(self) -> Adw.NavigationPage:
        toolbar = Adw.ToolbarView()
        header = Adw.HeaderBar()
        self._preview_title = Adw.WindowTitle(title="", subtitle="")
        header.set_title_widget(self._preview_title)

        self._open_button = Gtk.Button(
            icon_name="document-open-symbolic", tooltip_text=_("Open")
        )
        self._save_button = Gtk.Button(
            icon_name="folder-download-symbolic", tooltip_text=_("Save Attachment")
        )
        self._show_button = Gtk.Button(
            icon_name="mail-read-symbolic", tooltip_text=_("Show Message")
        )
        self._open_button.connect("clicked", lambda *_args: self._open())
        self._save_button.connect("clicked", lambda *_args: self._save())
        self._show_button.connect("clicked", lambda *_args: self._show_message())
        buttons = Gtk.Box(spacing=0)
        buttons.add_css_class("linked")
        for button in (self._open_button, self._save_button, self._show_button):
            buttons.append(button)
        header.pack_end(buttons)
        toolbar.add_top_bar(header)

        self._preview = AttachmentPreview()
        toolbar.set_content(self._preview)
        self._update_buttons()

        page = Adw.NavigationPage(title=_("Preview"), child=toolbar)
        page.add_css_class("pane-reader")
        return page

    def _install_actions(self) -> None:
        group = Gio.SimpleActionGroup()
        for name, handler in (
            ("open", self._open),
            ("save", self._save),
            ("show", self._show_message),
            ("free", self._free_selected),
            ("free-all", self._confirm_free_all),
        ):
            action = Gio.SimpleAction.new(name, None)
            action.connect("activate", lambda _action, _param, h=handler: h())
            group.add_action(action)
        self.insert_action_group("att", group)
        self._actions = group

        menu = Gio.Menu()
        menu.append(_("Open"), "att.open")
        menu.append(_("Save Attachment…"), "att.save")
        menu.append(_("Show Message"), "att.show")
        section = Gio.Menu()
        section.append(_("Free Local Copy"), "att.free")
        menu.append_section(None, section)
        self._context_menu = Gtk.PopoverMenu.new_from_model(menu)
        self._context_menu.set_parent(self)
        self._context_menu.set_has_arrow(False)
        self._context_menu.set_halign(Gtk.Align.START)

    # --- liste -----------------------------------------------------------

    def _schedule_refresh(self, *_args: object) -> None:
        if self._refresh_source:
            GLib.source_remove(self._refresh_source)
        self._refresh_source = GLib.timeout_add(FILTER_DEBOUNCE_MS, self._debounced)

    def _debounced(self) -> bool:
        self._refresh_source = 0
        self.refresh()
        return False

    def _has_filters(self) -> bool:
        return bool(
            self._text_entry.get_text().strip()
            or self._sender_entry.get_text().strip()
            or self._period.get_selected() > 0
            or self._kind.get_selected() > 0
        )

    def _visible_rows(self) -> list[AttachmentRow]:
        days = self._periods[self._period.get_selected()][1]
        since = None
        if days:
            since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        rows = self._window._db.search_attachments(
            text=self._text_entry.get_text(),
            sender=self._sender_entry.get_text(),
            since=since,
            kind=self._kinds[self._kind.get_selected()][1],
        )

        seen: set[tuple[str, str, int]] = set()
        kept: list[AttachmentRow] = []
        for row in rows:
            folder = self._window._folders_by_id.get(row.folder_id)
            if folder is None or mail_sync.folder_role(folder) in SKIPPED_ROLES:
                continue
            # Gmail montre un même message dans plusieurs dossiers : une seule ligne.
            identity = row.message_id or f"{row.sender}|{row.subject}|{row.date}"
            key = (identity, row.filename.lower(), row.size)
            if key in seen:
                continue
            seen.add(key)
            kept.append(row)
        kept.sort(key=lambda row: _timestamp(row.date), reverse=True)
        return kept

    def refresh(self) -> None:
        rows = self._visible_rows()
        total = len(rows)
        self._anchor = None
        self._selecting = True
        self._listbox.unselect_all()
        self._selecting = False
        self._rows.clear()
        # remove_all ne touche qu'aux lignes : le menu contextuel est lui aussi
        # un enfant de la liste, et une boucle sur get_first_child() tournait
        # sans fin en essayant de le retirer.
        for old in list(self._previous_rows):
            self._listbox.remove(old)
        self._previous_rows = []
        for att in rows[:MAX_ROWS]:
            widget = self._build_row(att)
            self._rows[widget] = att
            self._previous_rows.append(widget)
            self._listbox.append(widget)

        if total == 0:
            self._title.set_subtitle("")
            self._empty.set_description(
                _("No attachment matches these filters.")
                if self._has_filters()
                else _("Attachments appear here as Mail synchronizes your messages.")
            )
            self._stack.set_visible_child_name("empty")
        else:
            self._title.set_subtitle(
                ngettext("{n} attachment", "{n} attachments", total).format(n=total)
            )
            self._stack.set_visible_child_name("list")
        self._on_selection_changed()

    def _build_row(self, att: AttachmentRow) -> Adw.ActionRow:
        details = " · ".join(
            part
            for part in (
                att.sender or att.sender_address,
                mail_sync.format_date(att.date),
                GLib.format_size(att.size) if att.size else "",
            )
            if part
        )
        row = Adw.ActionRow(
            title=GLib.markup_escape_text(att.filename),
            subtitle=GLib.markup_escape_text(f"{details}\n{att.subject}"),
            title_lines=1,
            subtitle_lines=2,
        )
        content_type, _uncertain = Gio.content_type_guess(att.filename, None)
        row.add_prefix(
            Gtk.Image.new_from_gicon(Gio.content_type_get_symbolic_icon(content_type))
        )
        return row

    def _selected(self) -> list[AttachmentRow]:
        return [
            self._rows[row]
            for row in self._listbox.get_selected_rows()
            if row in self._rows
        ]

    def _on_left_press(
        self, gesture: Gtk.GestureClick, n_press: int, _x: float, y: float
    ) -> None:
        device = gesture.get_device()
        if device is not None and device.get_source() == Gdk.InputSource.TOUCHSCREEN:
            return  # au doigt, pas de Ctrl : la bascule de GTK est la bonne
        row = self._listbox.get_row_at_y(int(y))
        if row is None or row not in self._rows:
            return
        state = gesture.get_current_event_state()
        ctrl = bool(state & Gdk.ModifierType.CONTROL_MASK)
        shift = bool(state & Gdk.ModifierType.SHIFT_MASK)
        gesture.set_state(Gtk.EventSequenceState.CLAIMED)

        self._selecting = True
        try:
            if shift and self._anchor is not None and self._anchor in self._rows:
                low, high = sorted((self._anchor.get_index(), row.get_index()))
                if not ctrl:
                    self._listbox.unselect_all()
                for index in range(low, high + 1):
                    target = self._listbox.get_row_at_index(index)
                    if target is not None:
                        self._listbox.select_row(target)
            elif ctrl:
                if row.is_selected():
                    self._listbox.unselect_row(row)
                else:
                    self._listbox.select_row(row)
                self._anchor = row
            else:
                self._listbox.unselect_all()
                self._listbox.select_row(row)
                self._anchor = row
        finally:
            self._selecting = False
        self._on_selection_changed()
        if n_press == 2 and not ctrl and not shift:
            self._open()

    def _on_right_click(
        self, _gesture: Gtk.GestureClick, _n_press: int, x: float, y: float
    ) -> None:
        row = self._listbox.get_row_at_y(int(y))
        if row is None:
            return
        if not row.is_selected():
            self._listbox.unselect_all()
            self._listbox.select_row(row)
        translated = self._listbox.translate_coordinates(self, x, y)
        if translated is not None:
            x, y = translated
        rect = Gdk.Rectangle()
        rect.x, rect.y, rect.width, rect.height = int(x), int(y), 1, 1
        self._context_menu.set_pointing_to(rect)
        self._context_menu.popup()

    # --- sélection et aperçu ---------------------------------------------

    def _update_buttons(self) -> None:
        count = len(self._selected()) if hasattr(self, "_rows") else 0
        single = count == 1
        self._open_button.set_sensitive(single)
        self._show_button.set_sensitive(single)
        self._save_button.set_sensitive(count >= 1)
        for name, enabled in (
            ("open", single),
            ("show", single),
            ("save", count >= 1),
            ("free", count >= 1),
        ):
            action = self._actions.lookup_action(name) if hasattr(self, "_actions") else None
            if action is not None:
                action.set_enabled(enabled)

    def _on_selection_changed(self, *_args: object) -> None:
        if self._selecting:
            return
        self._preview_token += 1
        selected = self._selected()
        self._update_buttons()
        if not selected:
            self._preview_title.set_title("")
            self._preview_title.set_subtitle("")
            self._preview.show_empty()
            return
        if len(selected) > 1:
            self._preview_title.set_title("")
            self._preview_title.set_subtitle("")
            self._preview.show_selection(
                len(selected), sum(att.size for att in selected)
            )
            return

        att = selected[0]
        self._preview_title.set_title(GLib.markup_escape_text(att.filename))
        self._preview_title.set_subtitle(
            GLib.markup_escape_text(
                " · ".join(
                    part
                    for part in (
                        att.sender or att.sender_address,
                        GLib.format_size(att.size) if att.size else "",
                    )
                    if part
                )
            )
        )
        self._preview.show_loading()
        token = self._preview_token

        def loaded(found: Attachment | None, error: str | None) -> None:
            if token != self._preview_token:
                return  # une autre ligne a été choisie entre-temps
            if found is None:
                self._preview.show_error(error or "")
                return
            self._preview.show_attachment(found, partial(self._open_attachment, found))

        self._fetch(att, loaded)

    def _open_attachment(self, found: Attachment) -> None:
        self._window._open_attachment(found)

    # --- actions ---------------------------------------------------------

    def _open(self, *_args: object) -> None:
        selected = self._selected()
        if len(selected) != 1:
            return
        self._fetch(selected[0], self._then(self._window._open_attachment))

    def _save(self, *_args: object) -> None:
        selected = self._selected()
        if len(selected) == 1:
            self._fetch(selected[0], self._then(self._window._save_attachment))
        elif selected:
            dialog = Gtk.FileDialog(title=_("Save Attachments"))
            dialog.select_folder(
                self._window, None, partial(self._on_folder_chosen, selected)
            )

    def _show_message(self, *_args: object) -> None:
        selected = self._selected()
        if len(selected) != 1:
            return
        att = selected[0]
        if not att.server_id:
            self._window._toast(_("This message hasn't finished syncing yet."))
            return
        self._window.show_mail_view()
        self._window.open_email(att.folder_id, att.server_id)

    def _then(
        self, action: Callable[[Attachment], None]
    ) -> Callable[[Attachment | None, str | None], None]:
        def done(found: Attachment | None, error: str | None) -> None:
            if found is None:
                self._window._toast(error or _("Couldn't open the attachment."))
                return
            action(found)

        return done

    def _fetch(
        self,
        att: AttachmentRow,
        callback: Callable[[Attachment | None, str | None], None],
    ) -> None:
        """Charger le message (copie locale ou serveur), retrouver la pièce."""
        mail = self._window._db.get_email(att.email_id)
        if mail is None:
            callback(None, _("Couldn't open {name}.").format(name=att.filename))
            return

        def done(raw: bytes | None, error: str | None) -> None:
            if raw is None:
                callback(None, error)
                return
            found = _find_attachment(raw, att)
            if found is None:
                callback(None, _("Couldn't open {name}.").format(name=att.filename))
                return
            callback(found, None)

        self._window._load_body(mail, done)

    def _on_folder_chosen(
        self,
        selected: list[AttachmentRow],
        dialog: Gtk.FileDialog,
        result: Gio.AsyncResult,
    ) -> None:
        try:
            folder = dialog.select_folder_finish(result)
        except GLib.Error:
            return  # annulé
        self._save_all(folder, list(selected), 0)

    def _save_all(
        self, folder: Gio.File, queue: list[AttachmentRow], saved: int
    ) -> None:
        if not queue:
            self._window._toast(
                ngettext(
                    "Saved {n} attachment.", "Saved {n} attachments.", saved
                ).format(n=saved)
            )
            return
        att, rest = queue[0], queue[1:]

        def done(found: Attachment | None, error: str | None) -> None:
            count = saved
            if found is None:
                logger.warning("could not fetch %s: %s", att.filename, error)
            else:
                name = clean_filename(found.filename) or "attachment"
                target = _unique_child(folder, name)
                try:
                    target.replace_contents(
                        found.content, None, False, Gio.FileCreateFlags.NONE, None
                    )
                    count += 1
                except GLib.Error as err:
                    logger.warning("could not save %s: %s", name, err.message)
            self._save_all(folder, rest, count)

        self._fetch(att, done)

    # --- copies locales --------------------------------------------------

    def _free_selected(self, *_args: object) -> None:
        email_ids = sorted({att.email_id for att in self._selected()})
        if not email_ids:
            return
        freed = self._window._db.clear_cached_messages(email_ids)
        self._window._toast(
            ngettext(
                "Freed {n} local copy.", "Freed {n} local copies.", freed
            ).format(n=freed)
        )

    def _confirm_free_all(self, *_args: object) -> None:
        _count, size = self._window._db.cached_messages_stats()
        dialog = Adw.AlertDialog(
            heading=_("Free all local copies?"),
            body=_(
                "Downloaded messages and attachments ({size}) are removed from this "
                "computer. They stay on the server and are downloaded again when "
                "you open them. This may take a few seconds."
            ).format(size=GLib.format_size(size)),
        )
        dialog.add_response("cancel", _("Cancel"))
        dialog.add_response("free", _("Free Space"))
        dialog.set_response_appearance("free", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.set_close_response("cancel")
        dialog.set_default_response("cancel")
        dialog.choose(self._window, None, self._on_free_all_response)

    def _on_free_all_response(
        self, dialog: Adw.AlertDialog, result: Gio.AsyncResult
    ) -> None:
        if dialog.choose_finish(result) != "free":
            return
        freed = self._window._db.clear_cached_messages()
        self._window._db.compact()
        self._window._toast(
            ngettext(
                "Freed {n} local copy.", "Freed {n} local copies.", freed
            ).format(n=freed)
        )


def _unique_child(folder: Gio.File, name: str) -> Gio.File:
    """Un fichier de ce dossier qui n'écrase rien : « nom (2).ext » au besoin."""
    candidate = folder.get_child(name)
    if not candidate.query_exists(None):
        return candidate
    stem, dot, extension = name.rpartition(".")
    if not dot:
        stem, extension = name, ""
    number = 2
    while True:
        suffix = f".{extension}" if extension else ""
        candidate = folder.get_child(f"{stem} ({number}){suffix}")
        if not candidate.query_exists(None):
            return candidate
        number += 1


def _find_attachment(raw: bytes, wanted: AttachmentRow) -> Attachment | None:
    """La pièce de l'index dans le message : même nom, taille la plus proche."""
    try:
        attachments = parse_message(raw).attachments
    except Exception:
        logger.warning("could not parse message for %s", wanted.filename, exc_info=True)
        return None
    same_name = [a for a in attachments if clean_filename(a.filename) == wanted.filename]
    if not same_name:
        return attachments[0] if len(attachments) == 1 else None
    return min(same_name, key=lambda a: abs(a.size - wanted.size))
