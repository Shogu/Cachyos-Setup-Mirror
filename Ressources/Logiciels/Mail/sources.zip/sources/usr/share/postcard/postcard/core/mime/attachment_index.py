"""Lister les pièces jointes d'un message sans télécharger ses fichiers.

Deux sources alimentent l'index des pièces jointes :

* la réponse IMAP BODYSTRUCTURE, lue pendant la synchronisation, qui décrit
  l'arborescence MIME (types, noms, tailles) sans les données ;
* le message complet, quand il a déjà été téléchargé pour être lu.

Les deux passent par la même règle (is_listed_attachment) pour décider ce qui
compte comme une pièce jointe : un logo de signature intégré au corps n'en est
pas une, un PDF joint en est une.
"""

import email
import email.header
import email.message
import logging
import re
from dataclasses import dataclass
from email import policy
from urllib.parse import unquote_to_bytes

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class AttachmentInfo:
    filename: str
    mime_type: str
    size: int
    # Numéro de partie IMAP ("2.1"), vide quand l'information vient du message
    # téléchargé : on retrouve alors la pièce par son nom.
    part: str = ""


# Signatures et clés : jointes à presque chaque message d'un correspondant qui
# signe, et sans intérêt dans une liste de fichiers.
_IGNORED_TYPES = frozenset(
    {
        "application/pgp-signature",
        "application/pkcs7-signature",
        "application/x-pkcs7-signature",
        "application/pgp-encrypted",
    }
)

DEFAULT_NAME = "attachment"


def is_listed_attachment(
    mime_type: str, disposition: str, filename: str, has_content_id: bool
) -> bool:
    """Whether a MIME leaf is a file the user would call an attachment."""
    mime_type = mime_type.lower()
    disposition = disposition.lower()
    if mime_type in _IGNORED_TYPES or mime_type.startswith("multipart/"):
        return False
    if disposition == "attachment":
        return True
    # Sans nom ni disposition « attachment », c'est le corps du message ou une
    # partie technique (accusé de livraison, calendrier alternatif...).
    if not filename:
        return False
    # Image intégrée au corps (logo de signature, pixel de suivi) : référencée
    # par Content-ID et jamais déclarée comme pièce jointe.
    if mime_type.startswith("image/") and has_content_id and disposition != "attachment":
        return False
    return True


def clean_filename(name: str) -> str:
    """Nom lisible : décodé (RFC 2047), sans chemin ni caractère de contrôle."""
    if not name:
        return ""
    if "=?" in name:
        try:
            name = str(email.header.make_header(email.header.decode_header(name)))
        except (UnicodeDecodeError, LookupError, ValueError):
            pass
    name = re.sub(r"[\r\n\t]+", " ", name).strip()
    name = name.replace("\\", "/").rsplit("/", 1)[-1].strip()
    return name


# --- BODYSTRUCTURE ------------------------------------------------------------

_TOKEN = re.compile(r'\s*(?:(\()|(\))|"((?:[^"\\]|\\.)*)"|([^\s()"]+))')
_LITERAL_MARK = re.compile(r"\{(\d+)\}\s*$")
_RESPONSE_START = re.compile(r"\d+ \(")


def parse_sexp(text: str) -> list:
    """Lire une liste IMAP parenthésée : chaînes entre guillemets, atomes, NIL."""
    stack: list[list] = [[]]
    for match in _TOKEN.finditer(text):
        opening, closing, quoted, atom = match.groups()
        if opening:
            stack.append([])
        elif closing:
            if len(stack) > 1:
                done = stack.pop()
                stack[-1].append(done)
        elif quoted is not None:
            stack[-1].append(re.sub(r"\\(.)", r"\1", quoted))
        elif atom is not None:
            stack[-1].append(None if atom.upper() == "NIL" else atom)
    while len(stack) > 1:
        done = stack.pop()
        stack[-1].append(done)
    return stack[0]


def _quote(value: str) -> str:
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _responses(payload: list) -> list[str]:
    """Reconstituer le texte de chaque réponse FETCH renvoyée par imaplib.

    imaplib coupe une réponse à chaque littéral {n} : un tuple (début, octets),
    puis la suite comme élément à part. On remet les littéraux entre guillemets
    pour obtenir une réponse lisible d'un seul tenant.
    """
    responses: list[str] = []
    current = ""
    for item in payload:
        if isinstance(item, tuple):
            meta, literal = item[0], item[1]
            text = meta.decode("utf-8", "replace") if isinstance(meta, bytes) else meta
            body = (
                literal.decode("utf-8", "replace")
                if isinstance(literal, bytes)
                else str(literal)
            )
            text = _LITERAL_MARK.sub("", text) + _quote(body)
        elif isinstance(item, bytes):
            text = item.decode("utf-8", "replace")
        elif isinstance(item, str):
            text = item
        else:
            continue
        if _RESPONSE_START.match(text):
            if current:
                responses.append(current)
            current = text
        else:
            current += text
    if current:
        responses.append(current)
    return responses


def parse_fetch_responses(payload: list) -> dict[str, list[AttachmentInfo]]:
    """UID -> pièces jointes, d'après un FETCH (UID BODYSTRUCTURE)."""
    result: dict[str, list[AttachmentInfo]] = {}
    for text in _responses(payload):
        try:
            parsed = parse_sexp(text)
            fields = parsed[1] if len(parsed) > 1 and isinstance(parsed[1], list) else []
            values: dict[str, object] = {}
            for index in range(0, len(fields) - 1, 2):
                key = fields[index]
                if isinstance(key, str):
                    values[key.upper()] = fields[index + 1]
            uid = values.get("UID")
            structure = values.get("BODYSTRUCTURE")
            if isinstance(uid, str) and isinstance(structure, list):
                result[uid] = attachments_from_bodystructure(structure)
        except (IndexError, TypeError, ValueError):
            logger.warning("unreadable BODYSTRUCTURE reply", exc_info=True)
    return result


def _pairs(params: object) -> dict[str, str]:
    if not isinstance(params, list):
        return {}
    pairs: dict[str, str] = {}
    for index in range(0, len(params) - 1, 2):
        key, value = params[index], params[index + 1]
        if isinstance(key, str) and isinstance(value, str):
            pairs[key.lower()] = value
    return pairs


def _rfc2231_value(value: str, charset: str = "") -> tuple[str, str]:
    """"utf-8'fr'%C3%A9t%C3%A9" -> ("utf-8", "été") ; sans préfixe : charset donné."""
    if "'" in value:
        head, _lang, rest = value.split("'", 2)
        charset = head or charset
        value = rest
    raw = unquote_to_bytes(value)
    try:
        return charset, raw.decode(charset or "utf-8")
    except (LookupError, UnicodeDecodeError):
        return charset, raw.decode("utf-8", "replace")


def param_value(pairs: dict[str, str], key: str) -> str:
    """Valeur d'un paramètre MIME, avec les formes RFC 2231 (filename*, filename*0*)."""
    if key in pairs:
        return pairs[key]
    if key + "*" in pairs:
        return _rfc2231_value(pairs[key + "*"])[1]
    pieces = []
    for name, value in pairs.items():
        match = re.fullmatch(re.escape(key) + r"\*(\d+)(\*?)", name)
        if match:
            pieces.append((int(match.group(1)), bool(match.group(2)), value))
    if not pieces:
        return ""
    pieces.sort()
    charset = ""
    out = ""
    for _number, encoded, value in pieces:
        if encoded:
            charset, text = _rfc2231_value(value, charset)
            out += text
        else:
            out += value
    return out


def _decoded_size(size: int, encoding: str) -> int:
    # Taille annoncée = taille encodée ; le base64 gonfle de un tiers.
    if (encoding or "").lower() == "base64":
        return size * 3 // 4
    return size


def _disposition(parts: list) -> tuple[str, dict[str, str]]:
    for item in parts:
        if (
            isinstance(item, list)
            and item
            and isinstance(item[0], str)
            and item[0].lower() in ("attachment", "inline")
            and (len(item) < 2 or item[1] is None or isinstance(item[1], list))
        ):
            return item[0].lower(), _pairs(item[1] if len(item) > 1 else None)
    return "", {}


def attachments_from_bodystructure(structure: list) -> list[AttachmentInfo]:
    found: list[AttachmentInfo] = []
    _walk(structure, "", found)
    return found


def _walk(node: object, path: str, found: list[AttachmentInfo]) -> None:
    if not isinstance(node, list) or not node:
        return
    if isinstance(node[0], list):  # multipart : les enfants, puis le sous-type
        number = 0
        for child in node:
            if not isinstance(child, list):
                break
            number += 1
            _walk(child, f"{path}.{number}" if path else str(number), found)
        return
    if len(node) < 7 or not isinstance(node[0], str) or not isinstance(node[1], str):
        return
    mime_type = f"{node[0]}/{node[1]}".lower()
    type_params = _pairs(node[2])
    has_content_id = node[3] is not None
    encoding = node[5] if isinstance(node[5], str) else ""
    try:
        size = _decoded_size(int(node[6]), encoding)
    except (TypeError, ValueError):
        size = 0
    disposition, disposition_params = _disposition(node[7:])
    filename = clean_filename(
        param_value(disposition_params, "filename") or param_value(type_params, "name")
    )
    if not is_listed_attachment(mime_type, disposition, filename, has_content_id):
        return
    found.append(
        AttachmentInfo(
            filename=filename or DEFAULT_NAME,
            mime_type=mime_type,
            size=size,
            part=path or "1",
        )
    )


# --- message complet ----------------------------------------------------------


def attachments_from_raw(raw: bytes) -> list[AttachmentInfo]:
    """Les pièces jointes d'un message déjà téléchargé."""
    msg = email.message_from_bytes(raw, policy=policy.default)
    found: list[AttachmentInfo] = []
    _walk_message(msg, found)
    return found


def _walk_message(part: email.message.Message, found: list[AttachmentInfo]) -> None:
    mime_type = part.get_content_type()
    if part.is_multipart() and mime_type != "message/rfc822":
        for child in part.iter_parts():
            _walk_message(child, found)
        return
    disposition = part.get_content_disposition() or ""
    try:
        filename = clean_filename(part.get_filename() or "")
    except (TypeError, ValueError):
        filename = ""
    if not is_listed_attachment(
        mime_type, disposition, filename, part["Content-ID"] is not None
    ):
        return
    if mime_type == "message/rfc822":
        # Le message joint n'a pas de « charge utile » directe : son poids est
        # celui de sa forme sérialisée.
        payload = b"".join(
            sub.as_bytes() for sub in (part.get_payload() or []) if hasattr(sub, "as_bytes")
        )
    else:
        payload = part.get_payload(decode=True) or b""
    found.append(
        AttachmentInfo(
            filename=filename or DEFAULT_NAME, mime_type=mime_type, size=len(payload)
        )
    )
