import re

from .models.email import Email

_REPLY_PREFIX = re.compile(r"^\s*(re|fwd|fw)\s*:\s*", re.IGNORECASE)

# Stored, never translated. _normalize_subject blanks it so that unrelated
# subject-less messages don't all thread into one conversation -- which means
# whatever writes it has to use this exact string. Translating it at the point
# of storage would defeat the check for every non-English locale.
NO_SUBJECT = "(no subject)"


def group(emails: list[Email]) -> dict[int, int]:
    """Map each email id to a stable conversation id (the smallest id in its
    group). Links by Message-ID / In-Reply-To / References, with a same-subject
    fallback."""
    # Union-find over message tokens: each token points at another token in its
    # set, and the set's representative points at itself.
    parents: dict[str, str] = {}

    def find(token: str) -> str:
        parents.setdefault(token, token)
        while parents[token] != token:
            parents[token] = parents[parents[token]]  # path halving
            token = parents[token]
        return token

    def union(left: str, right: str) -> None:
        parents[find(left)] = find(right)

    # Every email gets a token: its Message-ID, or a synthetic one so a message
    # with no Message-ID still stands on its own.
    tokens: dict[int, str] = {}
    for mail in emails:
        tokens[mail.id] = mail.message_id.strip() or f"eid:{mail.id}"
        find(tokens[mail.id])

    # Reference links: join a message to its parent and ancestors.
    for mail in emails:
        token = tokens[mail.id]
        if mail.in_reply_to.strip():
            union(token, mail.in_reply_to.strip())
        for ref in mail.references.split():
            union(token, ref)

    # Fallback: messages sharing a normalized subject join the same thread.
    by_subject: dict[str, str] = {}
    for mail in emails:
        subject = _normalize_subject(mail.subject)
        if not subject:
            continue
        if subject in by_subject:
            union(tokens[mail.id], by_subject[subject])
        else:
            by_subject[subject] = tokens[mail.id]

    # Each group's conversation id is the smallest email id it contains.
    root_min_id: dict[str, int] = {}
    for mail in emails:
        root = find(tokens[mail.id])
        if root not in root_min_id or mail.id < root_min_id[root]:
            root_min_id[root] = mail.id

    return {mail.id: root_min_id[find(tokens[mail.id])] for mail in emails}


def _normalize_subject(subject: str) -> str:
    text = subject.strip()
    if text.lower() == NO_SUBJECT:
        return ""
    while True:
        stripped = _REPLY_PREFIX.sub("", text)
        if stripped == text:
            break
        text = stripped
    return text.strip().lower()
