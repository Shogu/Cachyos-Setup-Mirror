"""Aperçu d'une pièce jointe dans le volet de droite.

PDF (via Poppler), images, texte brut et documents Word/LibreOffice (texte
seulement). Pour tout le reste, on propose d'ouvrir le fichier avec l'appli
associée. Tout est affiché depuis la mémoire : rien n'est écrit sur le disque.
"""

import logging
import zipfile
from collections.abc import Callable
from gettext import gettext as _
from gettext import ngettext
from io import BytesIO
from pathlib import PurePosixPath
from xml.etree import ElementTree

from gi.repository import Adw, Gdk, Gio, GLib, Gtk

from .core.models.attachment import Attachment

try:
    import gi

    gi.require_version("Poppler", "0.18")
    from gi.repository import Poppler
except (ImportError, ValueError):  # poppler-glib absent : pas d'aperçu PDF
    Poppler = None

logger = logging.getLogger(__name__)

MAX_TEXT_BYTES = 400_000
MAX_OFFICE_MEMBER_BYTES = 30_000_000
MAX_PDF_PAGES = 80
PDF_ZOOM = 1.25

TEXT_EXTENSIONS = frozenset(
    {"txt", "md", "csv", "tsv", "log", "json", "xml", "ini", "conf", "yaml", "yml",
     "html", "htm", "css", "js", "py", "sh", "ics", "vcf", "eml", "tex", "srt"}
)
IMAGE_EXTENSIONS = frozenset(
    {"png", "jpg", "jpeg", "gif", "webp", "bmp", "tif", "tiff", "svg", "ico"}
)

PAGE_EMPTY = "empty"
PAGE_LOADING = "loading"
PAGE_PDF = "pdf"
PAGE_IMAGE = "image"
PAGE_TEXT = "text"
PAGE_MESSAGE = "message"


def _extension(filename: str) -> str:
    return PurePosixPath(filename).suffix.lower().lstrip(".")


def preview_kind(attachment: Attachment) -> str:
    """"pdf", "image", "text", "office" ou "" quand on ne sait pas l'afficher."""
    extension = _extension(attachment.filename)
    mime_type = attachment.mime_type.lower()
    if mime_type == "application/pdf" or extension == "pdf":
        return "pdf" if Poppler is not None else ""
    if mime_type.startswith("image/") or extension in IMAGE_EXTENSIONS:
        return "image"
    if extension in ("docx", "odt"):
        return "office"
    if mime_type.startswith("text/") or extension in TEXT_EXTENSIONS:
        return "text"
    return ""


def _local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def office_text(attachment: Attachment) -> str | None:
    """Le texte d'un .docx ou d'un .odt, paragraphe par paragraphe."""
    extension = _extension(attachment.filename)
    member = "word/document.xml" if extension == "docx" else "content.xml"
    try:
        with zipfile.ZipFile(BytesIO(attachment.content)) as archive:
            info = archive.getinfo(member)
            if info.file_size > MAX_OFFICE_MEMBER_BYTES:
                return None
            root = ElementTree.fromstring(archive.read(member))
    except (zipfile.BadZipFile, KeyError, ElementTree.ParseError, OSError):
        return None

    paragraphs: list[str] = []
    for element in root.iter():
        name = _local_name(element.tag)
        if extension == "docx" and name == "p":
            parts: list[str] = []
            for sub in element.iter():
                sub_name = _local_name(sub.tag)
                if sub_name == "t" and sub.text:
                    parts.append(sub.text)
                elif sub_name == "tab":
                    parts.append("\t")
                elif sub_name in ("br", "cr"):
                    parts.append("\n")
            paragraphs.append("".join(parts))
        elif extension == "odt" and name in ("p", "h"):
            paragraphs.append("".join(element.itertext()))
    text = "\n".join(paragraphs).strip()
    return text or None


class AttachmentPreview(Gtk.Box):
    __gtype_name__ = "PostcardAttachmentPreview"

    def __init__(self) -> None:
        super().__init__()
        self._stack = Gtk.Stack(
            transition_type=Gtk.StackTransitionType.CROSSFADE, hexpand=True, vexpand=True
        )

        self._empty = Adw.StatusPage(
            icon_name="mail-attachment-symbolic",
            title=_("Select an Attachment"),
            description=_("Pick an attachment from the list to preview it here."),
        )
        self._stack.add_named(self._empty, PAGE_EMPTY)

        self._stack.add_named(
            Adw.Spinner(halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER,
                        width_request=32, height_request=32),
            PAGE_LOADING,
        )

        self._pdf_box = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=12,
            margin_top=12,
            margin_bottom=12,
            margin_start=12,
            margin_end=12,
            halign=Gtk.Align.CENTER,
        )
        self._stack.add_named(Gtk.ScrolledWindow(child=self._pdf_box), PAGE_PDF)

        self._picture = Gtk.Picture(
            content_fit=Gtk.ContentFit.CONTAIN,
            can_shrink=True,
            margin_top=12,
            margin_bottom=12,
            margin_start=12,
            margin_end=12,
        )
        self._stack.add_named(self._picture, PAGE_IMAGE)

        self._text_view = Gtk.TextView(
            editable=False,
            cursor_visible=False,
            wrap_mode=Gtk.WrapMode.WORD_CHAR,
            monospace=True,
            top_margin=12,
            bottom_margin=12,
            left_margin=16,
            right_margin=16,
        )
        self._stack.add_named(Gtk.ScrolledWindow(child=self._text_view), PAGE_TEXT)

        self._message = Adw.StatusPage()
        self._open_button = Gtk.Button(
            label=_("Open"), halign=Gtk.Align.CENTER, visible=False
        )
        self._open_button.add_css_class("pill")
        self._message.set_child(self._open_button)
        self._stack.add_named(self._message, PAGE_MESSAGE)

        self._on_open: Callable[[], None] | None = None
        self._open_button.connect("clicked", lambda *_args: self._open_clicked())
        self.append(self._stack)

    def _open_clicked(self) -> None:
        if self._on_open is not None:
            self._on_open()

    # --- états -----------------------------------------------------------

    def show_empty(self) -> None:
        self._release()
        self._stack.set_visible_child_name(PAGE_EMPTY)

    def show_loading(self) -> None:
        self._release()
        self._stack.set_visible_child_name(PAGE_LOADING)

    def show_error(self, text: str) -> None:
        self._release()
        self._message.set_icon_name("dialog-warning-symbolic")
        self._message.set_title(_("Couldn't Load the Attachment"))
        self._message.set_description(GLib.markup_escape_text(text))
        self._open_button.set_visible(False)
        self._stack.set_visible_child_name(PAGE_MESSAGE)

    def show_selection(self, count: int, total_size: int) -> None:
        self._release()
        self._message.set_icon_name("mail-attachment-symbolic")
        self._message.set_title(
            ngettext("{n} attachment selected", "{n} attachments selected", count).format(
                n=count
            )
        )
        self._message.set_description(
            GLib.markup_escape_text(GLib.format_size(total_size))
            if total_size
            else ""
        )
        self._open_button.set_visible(False)
        self._stack.set_visible_child_name(PAGE_MESSAGE)

    def show_attachment(
        self, attachment: Attachment, on_open: Callable[[], None]
    ) -> None:
        self._release()
        self._on_open = on_open
        kind = preview_kind(attachment)
        try:
            if kind == "pdf" and self._show_pdf(attachment):
                return
            if kind == "image" and self._show_image(attachment):
                return
            if kind == "text" and self._show_text(attachment):
                return
            if kind == "office" and self._show_office(attachment):
                return
        except Exception:
            logger.warning("preview failed for %s", attachment.filename, exc_info=True)
            self._release()
        self._show_unsupported(attachment)

    # --- rendus ----------------------------------------------------------

    def _release(self) -> None:
        """Libérer ce que l'aperçu précédent tenait en mémoire."""
        self._on_open = None
        while (child := self._pdf_box.get_first_child()) is not None:
            self._pdf_box.remove(child)
        self._picture.set_paintable(None)
        self._text_view.get_buffer().set_text("")

    def _show_pdf(self, attachment: Attachment) -> bool:
        document = Poppler.Document.new_from_bytes(
            GLib.Bytes.new(attachment.content), None
        )
        pages = min(document.get_n_pages(), MAX_PDF_PAGES)
        if pages == 0:
            return False
        for index in range(pages):
            page = document.get_page(index)
            width, height = page.get_size()
            area = Gtk.DrawingArea(
                content_width=int(width * PDF_ZOOM),
                content_height=int(height * PDF_ZOOM),
                halign=Gtk.Align.CENTER,
            )
            area.add_css_class("card")
            area.set_draw_func(self._draw_page, (page, width))
            self._pdf_box.append(area)
        if document.get_n_pages() > pages:
            self._pdf_box.append(
                Gtk.Label(
                    label=_("Only the first {n} pages are shown.").format(n=pages),
                    css_classes=["dim-label"],
                )
            )
        self._stack.set_visible_child_name(PAGE_PDF)
        return True

    @staticmethod
    def _draw_page(
        _area: Gtk.DrawingArea, cr, width: int, _height: int, data: tuple
    ) -> None:
        page, page_width = data
        cr.set_source_rgb(1, 1, 1)
        cr.paint()
        if page_width:
            scale = width / page_width
            cr.scale(scale, scale)
        page.render(cr)

    def _show_image(self, attachment: Attachment) -> bool:
        try:
            texture = Gdk.Texture.new_from_bytes(GLib.Bytes.new(attachment.content))
        except GLib.Error:
            return False
        self._picture.set_paintable(texture)
        self._stack.set_visible_child_name(PAGE_IMAGE)
        return True

    def _show_text(self, attachment: Attachment) -> bool:
        data = attachment.content[:MAX_TEXT_BYTES]
        text = data.decode("utf-8", "replace")
        if len(attachment.content) > MAX_TEXT_BYTES:
            text += "\n…"
        self._text_view.get_buffer().set_text(text)
        self._stack.set_visible_child_name(PAGE_TEXT)
        return True

    def _show_office(self, attachment: Attachment) -> bool:
        text = office_text(attachment)
        if text is None:
            return False
        if len(text) > MAX_TEXT_BYTES:
            text = text[:MAX_TEXT_BYTES] + "\n…"
        self._text_view.set_monospace(False)
        self._text_view.get_buffer().set_text(text)
        self._stack.set_visible_child_name(PAGE_TEXT)
        return True

    def _show_unsupported(self, attachment: Attachment) -> None:
        content_type, _uncertain = Gio.content_type_guess(attachment.filename, None)
        icon = Gio.content_type_get_symbolic_icon(content_type)
        names = icon.get_names() if hasattr(icon, "get_names") else []
        self._message.set_icon_name(names[0] if names else "text-x-generic-symbolic")
        self._message.set_title(GLib.markup_escape_text(attachment.filename))
        self._message.set_description(
            GLib.markup_escape_text(
                _("No preview for this type of file.")
                + "\n"
                + GLib.format_size(len(attachment.content))
            )
        )
        self._open_button.set_visible(True)
        self._text_view.set_monospace(True)
        self._stack.set_visible_child_name(PAGE_MESSAGE)
