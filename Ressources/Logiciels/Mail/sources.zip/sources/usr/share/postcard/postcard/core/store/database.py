import os
import sqlite3
import logging
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime

from gi.repository import GLib

from .. import threader
from ..mime.attachment_index import AttachmentInfo, attachments_from_raw
from ..models.account import (
    IMPLICIT_TLS_PORT,
    PROTOCOL_IMAP,
    SECURITY_STARTTLS,
    SECURITY_TLS,
    Account,
)
from ..models.conversation import Conversation
from ..models.email import Email
from ..models.folder import Folder
from ..models.message_header import MessageHeader

logger = logging.getLogger(__name__)

# Every column _email_from_row reads
_EMAIL_COLUMNS = """
    id, folder_id, server_id, sender, sender_address, recipient,
    recipient_address, subject, preview, date, unread, starred, message_id,
    in_reply_to, reference_ids, conversation_id
"""


def _fts_query(text: str) -> str:
    """Turn free text into a safe FTS5 query: each word matched as a prefix."""
    # A literal quote inside an FTS5 string is escaped by doubling it.
    words = [word.replace('"', '""') for word in text.split()]
    return " ".join(f'"{word}"*' for word in words)


def _arrival_key(mail: Email) -> float:
    """A proxy for when a message arrived, for ordering threads/messages.

    The IMAP UID (server_id) is guaranteed by the protocol to increase with
    arrival order within a folder, unlike our local autoincrement id: once
    load-on-scroll backfills older mail in a later fetch, that older mail gets
    a *newer* local id, so sorting by id would put it first instead of last.
    A message with no UID yet (a Sent copy saved right after sending, before
    the next sync confirms it) sorts as the newest.
    """
    if not mail.server_id:
        return 2**31 - 1
    if mail.server_id.isdigit():
        return int(mail.server_id)
    # A Graph message id is opaque and says nothing about order, so fall back
    # to the date. A folder is all one kind, so the two scales never meet.
    return _sent_key(mail)


def _sent_key(mail: Email) -> float:
    # A UID only counts up within one mailbox, so ordering a mixed list by
    # _arrival_key interleaves accounts by unrelated counters. Unlike a UID, a
    # Date header is written by the sender: an unreadable one sorts *last*, so
    # junk with "Date: whenever" can't pin itself to the top of every inbox.
    # astimezone matches format_date, which reads a zone-less stamp as local.
    try:
        return datetime.fromisoformat(mail.date).astimezone().timestamp()
    except (TypeError, ValueError):
        return 0.0


# Schema changes since the first release, applied in order. How many have run
# is stored in PRAGMA user_version. Only ever append -- editing or reordering
# these would give databases in the wild a different schema to new ones.
MIGRATIONS = [
    "ALTER TABLE folders ADD COLUMN parent_id INTEGER REFERENCES folders(id)",
    "ALTER TABLE folders ADD COLUMN delimiter TEXT NOT NULL DEFAULT '/'",
    # Backfill by display name is best effort -- two people can share one.
    """
    ALTER TABLE emails ADD COLUMN sender_address TEXT NOT NULL DEFAULT '';
    UPDATE emails SET sender_address = COALESCE(
        (SELECT address FROM contacts WHERE contacts.name = emails.sender), '');
    """,
    # No backfill: the To header of mail synced before this is not stored
    # anywhere, so old sent mail keeps showing the sender until it re-syncs.
    """
    ALTER TABLE emails ADD COLUMN recipient TEXT NOT NULL DEFAULT '';
    ALTER TABLE emails ADD COLUMN recipient_address TEXT NOT NULL DEFAULT '';
    """,
    "ALTER TABLE accounts ADD COLUMN goa_id TEXT NOT NULL DEFAULT ''",
    # Re-index rows that predate emails_fts. A migration rather than part of
    # _create_tables, which runs on every launch: no indexed column is ever
    # updated, so once is enough and a rebuild costs the whole table.
    "INSERT INTO emails_fts(emails_fts) VALUES ('rebuild')",
    # No backfill: empty already means "sign in as the email address", which is
    # what every account predating this column was doing.
    "ALTER TABLE accounts ADD COLUMN username TEXT NOT NULL DEFAULT ''",
    # No backfill: every account before this one was IMAP.
    "ALTER TABLE accounts ADD COLUMN protocol TEXT NOT NULL DEFAULT 'imap'",
    # Empty means "infer from the name", which is what every IMAP folder still
    # does; Graph folders are named by opaque id and state both outright.
    """
    ALTER TABLE folders ADD COLUMN role TEXT NOT NULL DEFAULT '';
    ALTER TABLE folders ADD COLUMN label TEXT NOT NULL DEFAULT '';
    """,
    # Index des pièces jointes : nom, type et taille seulement, jamais le
    # contenu. Supprimé avec le message (ON DELETE CASCADE).
    """
    CREATE TABLE IF NOT EXISTS attachments (
        id INTEGER PRIMARY KEY,
        email_id INTEGER NOT NULL REFERENCES emails(id) ON DELETE CASCADE,
        filename TEXT NOT NULL,
        mime_type TEXT NOT NULL DEFAULT '',
        size INTEGER NOT NULL DEFAULT 0,
        part TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_attachments_email ON attachments (email_id);
    """,
]

# Familles de fichiers du filtre « Type » : (motifs LIKE sur le type MIME,
# extensions). Les serveurs rangent souvent un PDF en octet-stream : l'extension
# complète le type.
ATTACHMENT_KINDS: dict[str, tuple[tuple[str, ...], tuple[str, ...]]] = {
    "documents": (
        (
            "application/pdf",
            "application/msword",
            "application/rtf",
            "text/plain",
            "text/csv",
            "application/vnd.ms-%",
            "application/vnd.openxmlformats-officedocument.%",
            "application/vnd.oasis.opendocument.%",
        ),
        ("pdf", "doc", "docx", "odt", "rtf", "txt", "xls", "xlsx", "ods", "csv",
         "ppt", "pptx", "odp", "md"),
    ),
    "images": (("image/%",), ("png", "jpg", "jpeg", "gif", "webp", "svg", "heic", "tif", "tiff", "bmp")),
    "archives": (
        ("application/zip", "application/x-%zip%", "application/x-rar%",
         "application/x-7z%", "application/x-tar", "application/gzip", "application/x-gtar"),
        ("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "zst"),
    ),
    "media": (("audio/%", "video/%"), ("mp3", "ogg", "flac", "wav", "m4a", "mp4", "mkv", "webm", "mov", "avi")),
}


def _like_escape(text: str) -> str:
    return text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


@dataclass(frozen=True)
class AttachmentRow:
    """Une pièce jointe de l'index, avec le message qui la porte."""

    id: int
    filename: str
    mime_type: str
    size: int
    part: str
    email_id: int
    folder_id: int
    account_id: int
    server_id: str | None
    sender: str
    sender_address: str
    subject: str
    date: str
    message_id: str


class Database:
    def __init__(self, path: str | None = None) -> None:
        if path is None:
            data_dir = os.path.join(GLib.get_user_data_dir(), "postcard")
            os.makedirs(data_dir, exist_ok=True)
            path = os.path.join(data_dir, "postcard.db")

        self._conn = sqlite3.connect(path)
        self._conn.row_factory = sqlite3.Row
        # A sync commits once per message it stores, and the default journal
        # fsyncs on every one of those. Under WAL a commit is an append, and
        # NORMAL leaves the fsync to the checkpoint -- the durability given up
        # is the last few seconds of a mailbox the server still has.
        self._conn.execute("PRAGMA journal_mode = WAL")
        self._conn.execute("PRAGMA synchronous = NORMAL")
        self._conn.execute("PRAGMA foreign_keys = ON")

        self._create_tables()
        self._migrate_schema()

    def close(self) -> None:
        self._conn.close()

    # --- schema -----------------------------------------------------------

    def _create_tables(self) -> None:
        self._conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS accounts (
                id INTEGER PRIMARY KEY,
                email TEXT NOT NULL,
                display_name TEXT NOT NULL,
                imap_host TEXT NOT NULL,
                imap_port INTEGER NOT NULL,
                smtp_host TEXT NOT NULL,
                smtp_port INTEGER NOT NULL,
                imap_security TEXT NOT NULL DEFAULT 'tls',
                smtp_security TEXT NOT NULL DEFAULT 'starttls'
            );

            CREATE TABLE IF NOT EXISTS folders (
                id INTEGER PRIMARY KEY,
                account_id INTEGER NOT NULL REFERENCES accounts(id),
                name TEXT NOT NULL,
                icon_name TEXT NOT NULL DEFAULT 'folder-symbolic'
            );

            CREATE TABLE IF NOT EXISTS emails (
                id INTEGER PRIMARY KEY,
                folder_id INTEGER NOT NULL REFERENCES folders(id),
                server_id TEXT,
                sender TEXT NOT NULL,
                subject TEXT NOT NULL,
                preview TEXT NOT NULL,
                date TEXT NOT NULL,
                unread INTEGER NOT NULL DEFAULT 1,
                starred INTEGER NOT NULL DEFAULT 0,
                raw_message BLOB,
                message_id TEXT,
                in_reply_to TEXT,
                reference_ids TEXT,
                conversation_id INTEGER
            );

            CREATE UNIQUE INDEX IF NOT EXISTS idx_emails_uid
                ON emails (folder_id, server_id);

            -- Every sidebar badge is a COUNT over one folder's unread mail;
            -- with only idx_emails_uid that reads every row of the folder.
            CREATE INDEX IF NOT EXISTS idx_emails_unread
                ON emails (folder_id, unread);

            -- Every address we've seen, for composer autocomplete.
            CREATE TABLE IF NOT EXISTS contacts (
                address TEXT PRIMARY KEY,
                name TEXT NOT NULL DEFAULT ''
            );

            -- Full-text search index over the searchable columns. It mirrors
            -- the emails table (content='emails'), so triggers keep it in sync.
            CREATE VIRTUAL TABLE IF NOT EXISTS emails_fts USING fts5(
                sender, subject, preview,
                content='emails', content_rowid='id'
            );

            CREATE TRIGGER IF NOT EXISTS emails_fts_insert AFTER INSERT ON emails BEGIN
                INSERT INTO emails_fts(rowid, sender, subject, preview)
                VALUES (new.id, new.sender, new.subject, new.preview);
            END;

            CREATE TRIGGER IF NOT EXISTS emails_fts_delete AFTER DELETE ON emails BEGIN
                INSERT INTO emails_fts(emails_fts, rowid, sender, subject, preview)
                VALUES ('delete', old.id, old.sender, old.subject, old.preview);
            END;
            """
        )

        self._conn.commit()

    def _migrate_schema(self) -> None:
        version = self._conn.execute("PRAGMA user_version").fetchone()[0]
        for i, sql in enumerate(MIGRATIONS[version:], start=version + 1):
            self._conn.executescript(sql)
            self._conn.execute(f"PRAGMA user_version = {i}")
        self._conn.commit()

    # --- accounts -----------------------------------------------------------

    def _account_from_row(self, row: sqlite3.Row) -> Account:
        return Account(
            id=row["id"],
            email=row["email"],
            display_name=row["display_name"],
            imap_host=row["imap_host"],
            imap_port=row["imap_port"],
            smtp_host=row["smtp_host"],
            smtp_port=row["smtp_port"],
            imap_security=row["imap_security"],
            smtp_security=row["smtp_security"],
            username=row["username"],
            goa_id=row["goa_id"],
            protocol=row["protocol"],
        )

    def accounts(self) -> list[Account]:
        rows = self._conn.execute("SELECT * FROM accounts ORDER BY id").fetchall()
        return [self._account_from_row(row) for row in rows]

    def save_account(
        self,
        email: str,
        display_name: str,
        imap_host: str,
        imap_port: int,
        smtp_host: str,
        smtp_port: int,
        imap_security: str = SECURITY_TLS,
        smtp_security: str | None = None,
        username: str = "",
        goa_id: str = "",
        protocol: str = PROTOCOL_IMAP,
    ) -> Account:
        if smtp_security is None:
            # Port 465 is implicit TLS (SMTPS); everything else is assumed to
            # negotiate up from plaintext with STARTTLS.
            smtp_security = (
                SECURITY_TLS if smtp_port == IMPLICIT_TLS_PORT else SECURITY_STARTTLS
            )
        cursor = self._conn.execute(
            """
            INSERT INTO accounts
                (email, display_name, imap_host, imap_port, smtp_host, smtp_port,
                 imap_security, smtp_security, username, goa_id, protocol)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                email,
                display_name,
                imap_host,
                imap_port,
                smtp_host,
                smtp_port,
                imap_security,
                smtp_security,
                username,
                goa_id,
                protocol,
            ),
        )
        self._conn.commit()

        row = self._conn.execute(
            "SELECT * FROM accounts WHERE id = ?", (cursor.lastrowid,)
        ).fetchone()
        return self._account_from_row(row)

    def rename_account(self, account_id: int, display_name: str) -> None:
        self._conn.execute(
            "UPDATE accounts SET display_name = ? WHERE id = ?",
            (display_name, account_id),
        )
        self._conn.commit()

    def delete_account(self, account_id: int) -> None:
        # Flatten the tree first: the parent_id FK rejects deleting a parent
        # while a child still points at it.
        self._conn.execute(
            "UPDATE folders SET parent_id = NULL WHERE account_id = ?", (account_id,)
        )
        self._conn.execute(
            """
            DELETE FROM emails WHERE folder_id IN (
                SELECT id FROM folders WHERE account_id = ?
            )
            """,
            (account_id,),
        )
        self._conn.execute("DELETE FROM folders WHERE account_id = ?", (account_id,))
        self._conn.execute("DELETE FROM accounts WHERE id = ?", (account_id,))
        self._conn.commit()

    # --- folders -----------------------------------------------------------

    def _folder_from_row(self, row: sqlite3.Row) -> Folder:
        return Folder(
            id=row["id"],
            account_id=row["account_id"],
            name=row["name"],
            icon_name=row["icon_name"],
            parent_id=row["parent_id"],
            delimiter=row["delimiter"],
            role=row["role"],
            label=row["label"],
        )

    def folders_for_account(self, account_id: int) -> list[Folder]:
        rows = self._conn.execute(
            "SELECT * FROM folders WHERE account_id = ? ORDER BY id", (account_id,)
        ).fetchall()
        return [self._folder_from_row(row) for row in rows]

    def get_folder_by_name(self, account_id: int, name: str) -> Folder | None:
        row = self._conn.execute(
            "SELECT * FROM folders WHERE account_id = ? AND name = ?",
            (account_id, name),
        ).fetchone()
        return self._folder_from_row(row) if row else None

    def get_or_create_folder(
        self, account_id: int, name: str, icon_name: str = "folder-symbolic"
    ) -> Folder:
        existing = self.get_folder_by_name(account_id, name)
        if existing is not None:
            return existing

        cursor = self._conn.execute(
            "INSERT INTO folders (account_id, name, icon_name) VALUES (?, ?, ?)",
            (account_id, name, icon_name),
        )
        self._conn.commit()
        assert cursor.lastrowid is not None
        return Folder(
            id=cursor.lastrowid,
            account_id=account_id,
            name=name,
            icon_name=icon_name,
        )

    # Only the sync knows a folder's real place in the server's hierarchy, so
    # it's set explicitly here rather than defaulted by get_or_create_folder.
    def set_folder_parent(
        self, folder_id: int, parent_id: int | None, delimiter: str
    ) -> None:
        self._conn.execute(
            "UPDATE folders SET parent_id = ?, delimiter = ? WHERE id = ?",
            (parent_id, delimiter, folder_id),
        )
        self._conn.commit()

    # Written on every sync, since a folder can be renamed on the server
    # without its Graph id changing.
    def set_folder_identity(self, folder_id: int, role: str, label: str) -> None:
        self._conn.execute(
            "UPDATE folders SET role = ?, label = ? WHERE id = ?",
            (role, label, folder_id),
        )
        self._conn.commit()

    def _delete_folder_tree(self, folder_id: int) -> None:
        # Deepest first, for the same FK reason as delete_account.
        children = self._conn.execute(
            "SELECT id FROM folders WHERE parent_id = ?", (folder_id,)
        ).fetchall()
        for child in children:
            self._delete_folder_tree(child["id"])
        self._conn.execute("DELETE FROM emails WHERE folder_id = ?", (folder_id,))
        self._conn.execute("DELETE FROM folders WHERE id = ?", (folder_id,))

    def prune_folders(self, account_id: int, keep_names: set[str]) -> None:
        """Delete an account's folders (and their emails) whose names aren't in
        keep_names. Used to mirror the server's folder list and clear stale rows
        such as a duplicate "INBOX" left by an earlier version."""
        rows = self._conn.execute(
            "SELECT id, name FROM folders WHERE account_id = ?", (account_id,)
        ).fetchall()
        for row in rows:
            if row["name"] in keep_names:
                continue
            self._delete_folder_tree(row["id"])
        self._conn.commit()

    # --- emails -----------------------------------------------------------

    def emails_in_folder(self, folder_id: int) -> list[Email]:
        rows = self._conn.execute(
            f"SELECT {_EMAIL_COLUMNS} FROM emails WHERE folder_id = ? ORDER BY id DESC",
            (folder_id,),
        ).fetchall()
        return [self._email_from_row(row) for row in rows]

    def prune_stale_emails(self, folder_id: int, active_server_uids: set[str]) -> int:
        """Remove server-backed emails no longer present in the authoritative set."""
        with self._conn:
            self._conn.execute(
                "CREATE TEMP TABLE prune_active_uids (uid TEXT PRIMARY KEY)"
            )
            try:
                self._conn.executemany(
                    "INSERT INTO prune_active_uids (uid) VALUES (?)",
                    ((uid,) for uid in active_server_uids),
                )
                cursor = self._conn.execute(
                    """
                    DELETE FROM emails
                    WHERE folder_id = ?
                      AND server_id IS NOT NULL
                      AND server_id != ''
                      AND NOT EXISTS (
                          SELECT 1 FROM prune_active_uids
                          WHERE prune_active_uids.uid = emails.server_id
                      )
                    """,
                    (folder_id,),
                )
                return cursor.rowcount
            finally:
                self._conn.execute("DROP TABLE prune_active_uids")

    def reassign_conversations(self, folder_id: int) -> None:
        """Recompute the thread grouping for a folder and store it on each row.

        This runs after every sync, where almost nothing has moved thread, so
        rows that already hold the right id are left alone.
        """
        emails = self.emails_in_folder(folder_id)
        groups = threader.group(emails)
        with self._conn:
            self._conn.executemany(
                "UPDATE emails SET conversation_id = ? WHERE id = ?",
                [
                    (groups[mail.id], mail.id)
                    for mail in emails
                    if groups[mail.id] != mail.conversation_id
                ],
            )

    def conversations_in_folders(self, folder_ids: Sequence[int]) -> list[Conversation]:
        """Group the folders' emails into threads, newest thread first."""
        if not folder_ids:
            return []

        places = ",".join("?" * len(folder_ids))
        rows = self._conn.execute(
            f"SELECT {_EMAIL_COLUMNS} FROM emails WHERE folder_id IN ({places})",
            tuple(folder_ids),
        ).fetchall()
        return self._conversations_from_rows(rows, is_multi_folder=len(folder_ids) > 1)

    def search_conversations(
        self, folder_ids: Sequence[int], query: str
    ) -> list[Conversation]:
        """Full-text search the folders; return each matching conversation whole.

        The subquery narrows to the threads a message matched in, so a search
        builds only those. Selecting the folders and filtering afterwards made
        every keystroke cost the same as opening them.
        """
        if not folder_ids:
            return []

        match = _fts_query(query)
        if not match:
            return self.conversations_in_folders(folder_ids)

        places = ",".join("?" * len(folder_ids))
        rows = self._conn.execute(
            f"""
            SELECT {_EMAIL_COLUMNS} FROM emails
            WHERE folder_id IN ({places}) AND COALESCE(conversation_id, id) IN (
                SELECT COALESCE(e.conversation_id, e.id)
                FROM emails_fts f
                JOIN emails e ON e.id = f.rowid
                WHERE e.folder_id IN ({places}) AND emails_fts MATCH ?
            )
            """,
            (*folder_ids, *folder_ids, match),
        ).fetchall()
        return self._conversations_from_rows(rows, is_multi_folder=len(folder_ids) > 1)

    def _conversations_from_rows(
        self, rows: Sequence[sqlite3.Row], *, is_multi_folder: bool
    ) -> list[Conversation]:
        groups: dict[int, list[Email]] = {}
        for row in rows:
            email = self._email_from_row(row)
            key = email.conversation_id or email.id
            groups.setdefault(key, []).append(email)

        conversations = []
        for mails in groups.values():
            mails.sort(key=_arrival_key)  # oldest first, so .latest is right
            conversations.append(Conversation(mails))
        thread_key = _sent_key if is_multi_folder else _arrival_key
        conversations.sort(key=lambda c: thread_key(c.latest), reverse=True)
        return conversations

    def unread_count_in_folder(self, folder_id: int) -> int:
        row = self._conn.execute(
            "SELECT COUNT(*) AS n FROM emails WHERE folder_id = ? AND unread = 1",
            (folder_id,),
        ).fetchone()
        return row["n"]

    def set_email_unread(self, email_id: int, is_unread: bool) -> None:
        self._conn.execute(
            "UPDATE emails SET unread = ? WHERE id = ?", (int(is_unread), email_id)
        )
        self._conn.commit()

    def set_email_starred(self, email_id: int, is_starred: bool) -> None:
        self._conn.execute(
            "UPDATE emails SET starred = ? WHERE id = ?", (int(is_starred), email_id)
        )
        self._conn.commit()

    def move_emails(self, email_ids: list[int], folder_id: int) -> None:
        """Atomically move emails as UID-less destination placeholders.

        UIDs are only unique within an IMAP mailbox. Clear the UID while the
        move is pending so changing mailboxes cannot collide with a cached
        destination row.
        """
        with self._conn:
            self._conn.executemany(
                "UPDATE emails SET folder_id = ?, server_id = NULL WHERE id = ?",
                [(folder_id, email_id) for email_id in email_ids],
            )

    def reconcile_moved_emails(
        self, moves: Sequence[tuple[int, int, str | None]]
    ) -> None:
        """Atomically place each moved email at a (folder, UID) the server gave.

        A missing UID means the server has accepted the move but did not tell
        us how to identify its new row. Remove that placeholder so a later
        mailbox sync can insert the authoritative row without a duplicate.
        """
        with self._conn:
            for email_id, folder_id, server_id in moves:
                if server_id is None:
                    self._conn.execute("DELETE FROM emails WHERE id = ?", (email_id,))
                    continue

                existing = self._conn.execute(
                    """
                    SELECT id FROM emails
                    WHERE folder_id = ? AND server_id = ? AND id != ?
                    """,
                    (folder_id, server_id, email_id),
                ).fetchone()
                if existing is not None:
                    # The destination sync already has the authoritative row.
                    # Never delete or replace it; remove only our placeholder.
                    self._conn.execute("DELETE FROM emails WHERE id = ?", (email_id,))
                else:
                    self._conn.execute(
                        """
                        UPDATE emails
                        SET folder_id = ?, server_id = ?
                        WHERE id = ?
                        """,
                        (folder_id, server_id, email_id),
                    )

    def get_raw_message(self, email_id: int) -> bytes | None:
        row = self._conn.execute(
            "SELECT raw_message FROM emails WHERE id = ?", (email_id,)
        ).fetchone()

        return row["raw_message"] if row else None

    # Les copies locales sont des caches : on ne touche qu'aux messages qui
    # existent aussi sur le serveur (identifiant serveur connu). Un brouillon ou
    # un message de la boîte d'envoi n'a que cette copie : l'effacer le perdrait.
    _CACHED_COPIES = (
        "raw_message IS NOT NULL AND server_id IS NOT NULL AND server_id != '' "
        "AND folder_id NOT IN (SELECT id FROM folders WHERE name = 'Outbox')"
    )

    def clear_cached_messages(self, email_ids: Sequence[int] | None = None) -> int:
        """Effacer les copies locales des messages ; renvoie combien l'étaient."""
        with self._conn:
            if email_ids is None:
                cursor = self._conn.execute(
                    f"UPDATE emails SET raw_message = NULL WHERE {self._CACHED_COPIES}"
                )
            else:
                ids = list(email_ids)
                total = 0
                for start in range(0, len(ids), 500):
                    chunk = ids[start : start + 500]
                    marks = ",".join("?" * len(chunk))
                    total += self._conn.execute(
                        f"UPDATE emails SET raw_message = NULL WHERE {self._CACHED_COPIES}"
                        f" AND id IN ({marks})",
                        chunk,
                    ).rowcount
                return total
        return cursor.rowcount

    def cached_messages_stats(self) -> tuple[int, int]:
        """(nombre, octets) des copies locales que clear_cached_messages effacerait."""
        row = self._conn.execute(
            f"SELECT COUNT(*), COALESCE(SUM(LENGTH(raw_message)), 0) FROM emails "
            f"WHERE {self._CACHED_COPIES}"
        ).fetchone()
        return int(row[0]), int(row[1])

    def compact(self) -> None:
        """Rendre au disque la place des copies effacées."""
        self._conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        self._conn.execute("VACUUM")

    def save_raw_message(self, email_id: int, raw: bytes) -> None:
        self._conn.execute(
            "UPDATE emails SET raw_message = ? where id = ?", (raw, email_id)
        )
        self._conn.commit()

    def save_email(
        self,
        folder_id: int,
        sender: str,
        subject: str,
        preview: str,
        date: str,
        is_unread: bool,
        server_id: str | None = None,
        sender_address: str = "",
        recipient: str = "",
        recipient_address: str = "",
    ) -> Email:
        cursor = self._conn.execute(
            """
            INSERT INTO emails
                (folder_id, server_id, sender, subject, preview, date, unread,
                 sender_address, recipient, recipient_address)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                folder_id,
                server_id,
                sender,
                subject,
                preview,
                date,
                int(is_unread),
                sender_address,
                recipient,
                recipient_address,
            ),
        )
        self._conn.commit()
        row = self._conn.execute(
            "SELECT * FROM emails WHERE id = ?", (cursor.lastrowid,)
        ).fetchone()
        return self._email_from_row(row)

    def save_incoming_email(self, folder_id: int, header: MessageHeader) -> bool:
        """Insert one fetched email, or update the flags of one we already have.

        Every local toggle is pushed to the server, so on a message we've seen
        before its \\Seen and \\Flagged are what another client did to it since.
        The recipient is rewritten too, not because it can change but because a
        row stored before those columns existed has none and would never get
        one. Returns True when the row was new, which is how a sync tells which
        messages to notify about.
        """
        row = self._conn.execute(
            "SELECT message_id FROM emails WHERE folder_id = ? AND server_id = ?",
            (folder_id, header.uid),
        ).fetchone()
        is_new = row is None
        if row is not None and (row["message_id"] or "") != (header.message_id or ""):
            # Another message at the same UID (a mailbox that reset its UIDs).
            # The upsert below never rewrites the headers, so replace the row --
            # which also drops its cached body, now the wrong message's.
            self._conn.execute(
                "DELETE FROM emails WHERE folder_id = ? AND server_id = ?",
                (folder_id, header.uid),
            )
            is_new = True
        self._conn.execute(
            """
            INSERT INTO emails
                (folder_id, server_id, sender, subject, preview, date, unread,
                 starred, message_id, in_reply_to, reference_ids, sender_address,
                 recipient, recipient_address)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (folder_id, server_id) DO UPDATE SET
                unread = excluded.unread, starred = excluded.starred,
                recipient = excluded.recipient,
                recipient_address = excluded.recipient_address
            """,
            (
                folder_id,
                header.uid,
                header.sender,
                header.subject,
                header.preview,
                header.date,
                int(header.is_unread),
                int(header.is_starred),
                header.message_id,
                header.in_reply_to,
                header.references,
                header.sender_address,
                header.recipient,
                header.recipient_address,
            ),
        )
        self._conn.commit()
        if header.attachments is not None:
            email_row = self._conn.execute(
                "SELECT id FROM emails WHERE folder_id = ? AND server_id = ?",
                (folder_id, header.uid),
            ).fetchone()
            if email_row is not None:
                self.replace_attachments(email_row["id"], header.attachments)
        return is_new

    # --- pièces jointes -----------------------------------------------------

    def replace_attachments(
        self, email_id: int, attachments: Sequence[AttachmentInfo]
    ) -> None:
        """Remplacer ce que l'index sait des pièces jointes d'un message."""
        with self._conn:
            self._conn.execute(
                "DELETE FROM attachments WHERE email_id = ?", (email_id,)
            )
            self._conn.executemany(
                """
                INSERT INTO attachments (email_id, filename, mime_type, size, part)
                VALUES (?, ?, ?, ?, ?)
                """,
                [
                    (email_id, a.filename, a.mime_type, a.size, a.part)
                    for a in attachments
                ],
            )

    def index_attachments_from_raw(self, email_id: int, raw: bytes) -> None:
        """Indexer d'après un message complet (il vient d'être téléchargé)."""
        try:
            attachments = attachments_from_raw(raw)
        except Exception:
            logger.warning("could not index attachments of email %s", email_id, exc_info=True)
            return
        self.replace_attachments(email_id, attachments)

    def get_email(self, email_id: int) -> Email | None:
        row = self._conn.execute(
            f"SELECT {_EMAIL_COLUMNS} FROM emails WHERE id = ?", (email_id,)
        ).fetchone()
        return self._email_from_row(row) if row else None

    def search_attachments(
        self,
        text: str = "",
        sender: str = "",
        since: str | None = None,
        kind: str = "",
        limit: int = 2000,
    ) -> list[AttachmentRow]:
        """Pièces jointes filtrées ; les plus récentes d'abord.

        `text` : chaque mot doit figurer dans le nom du fichier ou l'objet.
        `sender` : chaque mot doit figurer dans le nom ou l'adresse de l'expéditeur.
        `since` : date ISO ; plus ancien est écarté. `kind` : clé de ATTACHMENT_KINDS.
        """
        clauses: list[str] = []
        args: list[object] = []
        for word in text.split():
            like = f"%{_like_escape(word)}%"
            clauses.append(
                "(a.filename LIKE ? ESCAPE '\\' OR e.subject LIKE ? ESCAPE '\\')"
            )
            args += [like, like]
        for word in sender.split():
            like = f"%{_like_escape(word)}%"
            clauses.append(
                "(e.sender LIKE ? ESCAPE '\\' OR e.sender_address LIKE ? ESCAPE '\\')"
            )
            args += [like, like]
        if since:
            clauses.append("e.date >= ?")
            args.append(since)
        if kind in ATTACHMENT_KINDS:
            mimes, extensions = ATTACHMENT_KINDS[kind]
            parts = ["a.mime_type LIKE ?" for _ in mimes]
            parts += ["LOWER(a.filename) LIKE ?" for _ in extensions]
            clauses.append("(" + " OR ".join(parts) + ")")
            args += list(mimes) + [f"%.{ext}" for ext in extensions]
        where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
        rows = self._conn.execute(
            f"""
            SELECT a.id, a.filename, a.mime_type, a.size, a.part,
                   e.id AS email_id, e.folder_id, e.server_id, e.sender,
                   e.sender_address, e.subject, e.date, e.message_id,
                   f.account_id
            FROM attachments a
            JOIN emails e ON e.id = a.email_id
            JOIN folders f ON f.id = e.folder_id
            {where}
            ORDER BY e.date DESC, a.id
            LIMIT ?
            """,
            (*args, limit),
        ).fetchall()
        return [
            AttachmentRow(
                id=row["id"],
                filename=row["filename"],
                mime_type=row["mime_type"],
                size=row["size"],
                part=row["part"],
                email_id=row["email_id"],
                folder_id=row["folder_id"],
                account_id=row["account_id"],
                server_id=row["server_id"],
                sender=row["sender"],
                sender_address=row["sender_address"] or "",
                subject=row["subject"],
                date=row["date"],
                message_id=row["message_id"] or "",
            )
            for row in rows
        ]

    def delete_email(self, email_id: int) -> None:
        self._conn.execute("DELETE FROM emails WHERE id = ?", (email_id,))
        self._conn.commit()

    def _email_from_row(self, row: sqlite3.Row) -> Email:
        return Email(
            id=row["id"],
            folder_id=row["folder_id"],
            server_id=row["server_id"],
            sender=row["sender"],
            sender_address=row["sender_address"] or "",
            recipient=row["recipient"] or "",
            recipient_address=row["recipient_address"] or "",
            subject=row["subject"],
            preview=row["preview"],
            date=row["date"],
            is_unread=bool(row["unread"]),
            is_starred=bool(row["starred"]),
            message_id=row["message_id"] or "",
            in_reply_to=row["in_reply_to"] or "",
            references=row["reference_ids"] or "",
            conversation_id=row["conversation_id"],
        )

    # --- contacts -----------------------------------------------------------

    def save_contacts(self, addresses: list[tuple[str, str]]) -> None:
        """Remember (name, address) pairs -- the order email.utils.getaddresses
        returns them in. A later sighting fills in a missing display name, but
        an anonymous one never wipes a name we already have."""
        self._conn.executemany(
            """
            INSERT INTO contacts (address, name) VALUES (?, ?)
            ON CONFLICT(address) DO UPDATE SET name = excluded.name
                WHERE excluded.name != ''
            """,
            [(addr.lower(), name) for name, addr in addresses if addr],
        )
        self._conn.commit()

    def contact_addresses(self) -> list[str]:
        rows = self._conn.execute(
            "SELECT name, address FROM contacts ORDER BY name, address"
        ).fetchall()
        return [
            f"{row['name']} <{row['address']}>" if row["name"] else row["address"]
            for row in rows
        ]
