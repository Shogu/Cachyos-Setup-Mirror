'use strict';

// Un service worker MV3 n'a pas de DOM et ne peut donc pas ecrire dans le
// presse-papiers : ce document offscreen n'existe que pour cela.

const COPY_TIMEOUT_MS = 500;

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== 'clipboard-write') return false;
  writeClipboard(String(message.text ?? ''))
    .then(sendResponse)
    .catch((error) => sendResponse({ ok: false, error: String(error) }));
  return true;
});

// Deux chemins, dans cet ordre : l'API Clipboard reclame un document focalise,
// ce que ce document n'est jamais ; le delai evite d'attendre une promesse qui
// ne se resoudra pas. Sans focalisation, execCommand reste le chemin normal.
async function writeClipboard(text) {
  const viaApi = await withTimeout(writeWithClipboardApi(text), COPY_TIMEOUT_MS);
  if (viaApi === true) return { ok: true, method: 'clipboard' };

  if (copyWithSelection(text)) return { ok: true, method: 'execCommand' };
  return { ok: false, error: viaApi === null ? 'delai depasse' : String(viaApi) };
}

async function writeWithClipboardApi(text) {
  await navigator.clipboard.writeText(text);
  return true;
}

function withTimeout(promise, ms) {
  return Promise.race([
    promise.then(
      () => true,
      (error) => String(error),
    ),
    new Promise((resolve) => setTimeout(() => resolve(null), ms)),
  ]);
}

function copyWithSelection(text) {
  const field = document.createElement('textarea');
  field.value = text;
  field.setAttribute('readonly', '');
  field.style.position = 'fixed';
  field.style.top = '-1000px';
  document.body.appendChild(field);
  field.select();
  field.setSelectionRange(0, text.length);
  let copied = false;
  try {
    copied = document.execCommand('copy');
  } catch (error) {
    copied = false;
  }
  field.remove();
  return copied;
}
