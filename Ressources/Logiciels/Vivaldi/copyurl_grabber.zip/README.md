# Extension Vivaldi — CopierURL

Extension MV3 qui copie les URL des onglets dans le presse-papiers, une par
ligne, prêtes à être collées. Elle ne télécharge rien, ne lit pas le contenu des
pages et ne retient que les adresses `http(s)`.

## Copier, et une exception

Le gros de l’extension copie : elle écrit les URL (une par ligne) dans le
presse-papiers. Aucun dialogue de navigateur, aucune limite de longueur, aucune
requête vers un site.

Une seule entrée de menu fait autre chose : **Ouvrir avec Grabber** remet l’URL au
système par le schéma `grabber://`, ce qui réveille l’application si elle est
fermée. Elle est décrite plus bas.

Copier plutôt que passer par le schéma n’est pas une préférence : un schéma
externe est verrouillé de trois côtés par Chromium, et aucun réglage n’y change
rien :

| Verrou | Condition exigée |
| --- | --- |
| Case « Toujours autoriser » | une origine de page initiatrice *de confiance* |
| Politique `AutoLaunchProtocolsFromOrigins` | une origine initiatrice *non nulle* |
| Jeton anti-flood | réarmé par un geste ou un appel d’API d’extension |

Une copie déclenchée par l’extension n’a pas d’origine de page : les deux
premiers verrous restent fermés. Le presse-papiers n’en connaît aucun, et un
schéma externe ne se charge jamais sans ouvrir un onglet jetable.

## Prérequis

**Pour copier : aucun.** L’extension écrit dans le presse-papiers et s’arrête là.

**Pour « Ouvrir avec Grabber »**, l’application doit être joignable par le système
sous le schéma `grabber` :

```bash
./grabber.AppImage --install-desktop
```

Remplace `grabber.AppImage` par le nom réel de ton fichier : seul le chemin
compte, pas le nom. La commande écrit le lanceur `com.ogu.Grabber.desktop` (avec
`MimeType=x-scheme-handler/grabber`) dans `~/.local/share/applications` et associe
`grabber://`. À relancer seulement si l’AppImage change de chemin ou de nom.

Sans politique système, le navigateur demande confirmation la première fois
(« Ouvrir Grabber ? »). Le fichier `grabber-policy.json`, à la racine du dépôt,
porte l’exception qui l’évite : c’est un fichier de politique Chromium
(`AutoLaunchProtocolsFromOrigins`), à installer dans le dossier de politiques du
navigateur.

## Installation

`vivaldi://extensions` → activer le mode développeur → **Charger l’extension
non empaquetée** → choisir ce dossier.

## Utilisation

| Action | Résultat |
| --- | --- |
| Clic sur l’icône | Copie l’URL de l’onglet courant |
| `Alt+Maj+G` | Copie l’URL de l’onglet courant |
| `Alt+Maj+H` | Copie les URL de tous les onglets de la fenêtre |
| Clic droit sur l’onglet ou la page | Copie les URL de toute la fenêtre, onglet courant compris |
| Clic droit sur des onglets sélectionnés | Copie leurs URL |
| Clic droit sur du texte sélectionné | Copie les URL trouvées dans la sélection |
| Clic droit → **Ouvrir … avec Grabber** | Remet au système l’URL du lien, de l’onglet, des onglets sélectionnés, de la fenêtre ou du média cliqué |

Un badge vert affiche brièvement le nombre d’URL copiées. Un badge rouge `0`
signale qu’aucune adresse `http(s)` n’a été trouvée, ou que le presse-papiers a
refusé l’écriture.

### Menu contextuel

Dans l’ordre où Vivaldi les affiche :

| Entrée | Apparaît sur |
| --- | --- |
| **Ouvrir cet onglet avec Grabber** | page, onglet, bouton de la barre d’outils |
| **Ouvrir ce lien avec Grabber** | lien |
| — | |
| **Copier les URL des onglets sélectionnés** | onglets sélectionnés |
| **Ouvrir les URL des onglets sélectionnés avec Grabber** | onglets sélectionnés |
| **Copier les URL de cette fenêtre** | page, onglet |
| **Ouvrir les URL de cette fenêtre avec Grabber** | page, onglet |
| **Ouvrir cette image avec Grabber** | image |
| **Ouvrir cette vidéo avec Grabber** | vidéo |
| **Ouvrir cet audio avec Grabber** | audio |
| **Copier l’URL de cette sélection** | texte sélectionné |

Vivaldi filtre ces entrées selon ce qui est cliqué : sur une page tu n’en vois que
trois, l’onglet courant puis la paire de la fenêtre. Copier l’URL de l’onglet
courant n’a pas d’entrée de menu : le clic sur le bouton le fait déjà, et Vivaldi
affiche les entrées de page dans le menu du bouton, où une telle entrée aurait
doublonné avec lui. Les entrées « Ouvrir » remettent l’URL au système par le
schéma `grabber://` ; pour un média, c’est l’URL du **fichier**, pas celle de la page
qui l’affiche. Aucune entrée « Ouvrir » ne copie quoi que ce soit.

Le badge annonce le nombre d’URL remises, comme pour la copie. Mais contrairement
au presse-papiers, une URI a une longueur limitée : au-delà de 12 URL ou de 1800
caractères, l’envoi est découpé en plusieurs URI, donc en plusieurs remises.

L’extension ne peut pas savoir si l’application a réellement reçu les URL : le
navigateur lui rend la main dès que l’URI est remise au système. Le badge signale
donc une remise, pas un téléchargement commencé. Un badge rouge `0` signale
qu’aucune URL `http(s)` n’était exploitable, ou une remise refusée.

### Sélectionner plusieurs onglets

`Ctrl` + clic sur chaque onglet (ou `Maj` + clic pour une plage), puis clic droit
sur la barre d’onglets → **Copier les URL des onglets sélectionnés**. Le jeu
sélectionné reste affiché jusqu’au clic suivant sur un onglet.

### Onglets de la fenêtre ≠ workspace Vivaldi

L’extension ne voit que les **fenêtres** : un workspace Vivaldi est un
sous-ensemble d’onglets *dans* une fenêtre, et Vivaldi n’expose pas les
workspaces à l’API des extensions. Si une fenêtre contient plusieurs
workspaces, l’entrée « Copier les URL de tous les onglets de cette fenêtre » les
copiera tous les deux.

## Ce que l’extension ne fait pas

- Elle ne télécharge rien et n’analyse aucune page : elle copie des adresses.
- Elle ne surveille pas le presse-papiers et ne le relit jamais.
- Elle n’ouvre aucun onglet — sauf pour remettre une URI au système, via un
  onglet jetable retiré aussitôt (voir « Menu contextuel »). Et elle ne
  contacte aucun serveur.
- Une URL par ligne, dans l’ordre des onglets : le texte se colle tel quel, sans
  limite de longueur.

## Permissions

- `tabs` : nécessaire pour lire l’URL des autres onglets de la fenêtre.
- `contextMenus` : menus contextuels.
- `offscreen` + `clipboardWrite` : écrire les URL dans le presse-papiers. Un
  service worker MV3 n’a pas de DOM, d’où le document `offscreen.html`, créé une
  seule fois puis réutilisé.

Aucun accès au contenu des pages, aucun accès réseau vers des sites.

## Icône

L’icône de la barre d’outils est le glyphe **copie** symbolic du thème
(`actions/edit-copy-symbolic.svg`) : la feuille arrière et le carré avant, le
même dessin que « Copier » partout ailleurs dans le système. Au survol,
l’infobulle affiche **Copier l’URL**.

| Dossier | Couleur | Usage |
|---|---|---|
| `icons/symbolic-light/` | blanc `#f0f0f0` | barre d’outils sombre |
| `icons/` | bleu `#3584e4` | page des extensions |

Chromium ne recolore pas les icônes de barre d’outils : ni l’attribut
`theme_icons` (réservé à Firefox), ni les SVG ne sont pris en charge pour
`default_icon`. La barre d’outils de Vivaldi étant sombre, c’est la seule variante
embarquée ; une variante grise existe mais n’est plus livrée, faute d’usage.

Les PNG (`copie-16/32/48/128.png`) sont rasterisés depuis la source du thème,
sans redessiner le glyphe, par :

    python3 scripts/generer-icones-extension.py

Le script remplace la couleur du glyphe puis rasterise les deux variantes livrées ;
il utilise `cairosvg` s’il est installé, sinon `rsvg-convert`. À relancer après une
mise à jour du thème. Si la barre d’outils passe un jour en clair, remplacer la
couleur de `symbolic-light` par `#5c5c5c` dans `VARIANTES` et regénérer.

## Tests

    node ../tests/test-transport.mjs

Charge `background.js` et `offscreen.js` avec des doublures de `chrome`, `document`
et `navigator`, puis vérifie l’écriture du presse-papiers, la remise d’une URL au
protocole, et leurs dégradations : refus d’écriture, destinataire absent, création
d’onglet refusée, découpage en lots d’une fenêtre, aucune URL exploitable.
