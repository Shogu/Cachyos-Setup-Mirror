# Envoyer vers Spectacle

Extension Vivaldi : ouvre une vidéo YouTube dans Spectacle, à la même position.

## Utilisation
- **Sur YouTube** : bouton « Spectacle » sous la vidéo. La vidéo se met en pause dans le navigateur.
- **Partout** : clic droit sur un lien YouTube, puis « Ouvrir dans Spectacle ».

## Installation
1. `vivaldi://extensions`, activer le **mode développeur**.
2. **Charger l'extension non empaquetée** et choisir ce dossier (le laisser en place).
3. Au premier envoi, cocher « toujours autoriser » pour `spectacle://`.

Nécessite Spectacle 0.6.1 ou plus récent (gestion des liens `spectacle://`).
