'use strict';

importScripts('spectacle-url.js');

const MENU_ID = 'ouvrir-dans-spectacle';
const YOUTUBE_LINKS = [
    '*://*.youtube.com/watch*',
    '*://*.youtube.com/shorts/*',
    '*://*.youtube.com/playlist*',
    '*://youtu.be/*',
];

chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.removeAll(() => {
        chrome.contextMenus.create({
            id: MENU_ID,
            title: 'Ouvrir dans Spectacle',
            contexts: ['link'],
            targetUrlPatterns: YOUTUBE_LINKS,
        });
    });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId !== MENU_ID)
        return;

    const {url, seconds} = cleanYoutubeUrl(info.linkUrl);
    const target = buildSpectacleUrl(url, seconds);

    if (tab && tab.id >= 0)
        chrome.tabs.update(tab.id, {url: target});
    else
        chrome.tabs.update({url: target});
});
