'use strict';

const BUTTON_ID = 'spectacle-envoyer';
const CONTAINER_SELECTOR = 'ytd-watch-metadata #top-level-buttons-computed';
const RETRY_DELAY_MS = 500;
const MAX_RETRIES = 20;
const SVG_NS = 'http://www.w3.org/2000/svg';
const CURTAIN_PATHS = [
    'M1.8 1h12.4a.8.8 0 0 1 0 1.6H1.8a.8.8 0 0 1 0-1.6z',
    'M1.5 3.5H6.3C6.3 7.2 5.4 10.4 3.4 13.8H1.5Z',
    'M14.5 3.5H9.7C9.7 7.2 10.6 10.4 12.6 13.8H14.5Z',
    'M7 7.6L9.8 9.5L7 11.4Z',
];
const BUTTON_CLASSES = [
    'yt-spec-button-shape-next',
    'yt-spec-button-shape-next--tonal',
    'yt-spec-button-shape-next--mono',
    'yt-spec-button-shape-next--size-m',
    'yt-spec-button-shape-next--icon-leading',
];

let retryTimer = 0;
let observedContainer = null;
const observer = new MutationObserver(() => insertButton());

function createIcon() {
    const svg = document.createElementNS(SVG_NS, 'svg');
    svg.setAttribute('viewBox', '-2 -2 20 20');
    svg.setAttribute('width', '24');
    svg.setAttribute('height', '24');
    svg.setAttribute('fill', 'currentColor');
    svg.setAttribute('aria-hidden', 'true');

    for (const d of CURTAIN_PATHS) {
        const path = document.createElementNS(SVG_NS, 'path');
        path.setAttribute('d', d);
        svg.append(path);
    }
    return svg;
}

function createButton() {
    const wrapper = document.createElement('div');
    wrapper.id = BUTTON_ID;

    const button = document.createElement('button');
    button.className = BUTTON_CLASSES.join(' ');
    button.title = 'Ouvrir dans Spectacle';
    button.setAttribute('aria-label', 'Ouvrir dans Spectacle');

    const icon = document.createElement('div');
    icon.className = 'yt-spec-button-shape-next__icon';
    icon.append(createIcon());

    const label = document.createElement('div');
    label.className = 'yt-spec-button-shape-next__button-text-content';
    label.textContent = 'Spectacle';

    button.append(icon, label);
    button.addEventListener('click', sendToSpectacle);
    wrapper.append(button);
    return wrapper;
}

function sendToSpectacle() {
    const {url, seconds: urlSeconds} = cleanYoutubeUrl(location.href);
    const video = document.querySelector('#movie_player video');
    let seconds = urlSeconds;

    if (video) {
        video.pause();
        seconds = video.currentTime;
    }
    location.href = buildSpectacleUrl(url, seconds);
}

function observe(container) {
    if (container === observedContainer)
        return;
    observer.disconnect();
    observer.observe(container, {childList: true});
    observedContainer = container;
}

function insertButton() {
    if (location.pathname !== '/watch' || document.getElementById(BUTTON_ID))
        return true;

    const container = document.querySelector(CONTAINER_SELECTOR);
    if (!container)
        return false;

    container.append(createButton());
    observe(container);
    return true;
}

/* YouTube construit la barre d'actions après la navigation : on réessaie un moment. */
function scheduleInsert(attempt = 0) {
    clearTimeout(retryTimer);
    if (insertButton() || attempt >= MAX_RETRIES)
        return;
    retryTimer = setTimeout(() => scheduleInsert(attempt + 1), RETRY_DELAY_MS);
}

document.addEventListener('yt-navigate-finish', () => scheduleInsert());
scheduleInsert();
