'use strict';

const SPECTACLE_OPEN = 'spectacle://open';
const DROPPED_PARAMS = ['t', 'start', 'si', 'pp', 'feature'];

function parseYoutubeTime(value) {
    if (!value)
        return 0;
    if (/^\d+$/.test(value))
        return Number(value);

    const match = /^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s?)?$/.exec(value);
    if (!match)
        return 0;

    const [, hours = 0, minutes = 0, seconds = 0] = match;
    return Number(hours) * 3600 + Number(minutes) * 60 + Number(seconds);
}

/* Retire la position et les paramètres de pistage, en gardant v= et list=. */
function cleanYoutubeUrl(rawUrl) {
    const url = new URL(rawUrl);
    const seconds = parseYoutubeTime(url.searchParams.get('t') ?? url.searchParams.get('start'));

    for (const param of DROPPED_PARAMS)
        url.searchParams.delete(param);
    url.hash = '';

    return {url: url.href, seconds};
}

function buildSpectacleUrl(videoUrl, seconds) {
    const params = new URLSearchParams({url: videoUrl});
    const position = Math.floor(seconds);
    if (position > 0)
        params.set('t', String(position));

    return `${SPECTACLE_OPEN}?${params}`;
}
