'use strict';

importScripts('spectacle-url.js');

const MENU_ID = 'ouvrir-dans-spectacle';
const YOUTUBE_LINKS = [
    '*://*.youtube.com/watch*',
    '*://*.youtube.com/shorts/*',
    '*://*.youtube.com/playlist*',
    '*://youtu.be/*',
];

function openInSpectacle(tabId, url, seconds) {
    const target = buildSpectacleUrl(url, seconds);
    if (tabId >= 0)
        chrome.tabs.update(tabId, {url: target});
    else
        chrome.tabs.update({url: target});
}

chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.removeAll(() => {
        chrome.contextMenus.create({
            id: MENU_ID,
            title: 'Ouvrir dans Spectacle',
            contexts: ['link'],
            targetUrlPatterns: YOUTUBE_LINKS,
        });
    });
});

chrome.runtime.onMessage.addListener((message, sender) => {
    if (message.type === 'open')
        openInSpectacle(sender.tab.id, message.url, message.seconds);
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId !== MENU_ID)
        return;
    const {url, seconds} = cleanYoutubeUrl(info.linkUrl);
    openInSpectacle(tab ? tab.id : -1, url, seconds);
});
