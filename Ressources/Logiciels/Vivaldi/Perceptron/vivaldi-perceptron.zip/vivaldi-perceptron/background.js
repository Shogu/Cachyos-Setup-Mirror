const HOST = "io.gitlab.shogu.perceptron";
const MAX_LENGTH = 100000;

function buildPrompt(title, url, selection) {
  if (selection) {
    return `Extrait de « ${title} » (${url}) :\n\n${selection.slice(0, MAX_LENGTH)}`;
  }
  return `Lis cette page et résume-la : ${url}`;
}

function send(tab, title, url, selection) {
  chrome.runtime.sendNativeMessage(HOST, { title, prompt: buildPrompt(title, url, selection) }, (response) => {
    const error = chrome.runtime.lastError?.message || (response && !response.ok && response.error);
    chrome.action.setBadgeText({ tabId: tab.id, text: error ? "!" : "" });
    chrome.action.setTitle({ tabId: tab.id, title: error ? `Perceptron : ${error}` : "Envoyer vers Perceptron" });
  });
}

async function pageSelection(tab) {
  try {
    const [result] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => window.getSelection().toString(),
    });
    return result.result || "";
  } catch {
    return "";
  }
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: "selection", title: "Envoyer la sélection vers Perceptron", contexts: ["selection"] });
  chrome.contextMenus.create({ id: "link", title: "Envoyer le lien vers Perceptron", contexts: ["link"] });
  chrome.contextMenus.create({ id: "page", title: "Envoyer la page vers Perceptron", contexts: ["page"] });
});

chrome.action.onClicked.addListener(async (tab) => {
  send(tab, tab.title, tab.url, await pageSelection(tab));
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "link") {
    send(tab, info.linkUrl, info.linkUrl, "");
  } else if (info.menuItemId === "selection") {
    send(tab, tab.title, tab.url, (await pageSelection(tab)) || info.selectionText);
  } else {
    send(tab, tab.title, tab.url, "");
  }
});
