#![allow(clippy::missing_safety_doc)]

pub mod colors;
pub mod config;
pub mod bookmarks;
pub mod i18n;
pub mod icons;
pub mod location;
pub mod menus;
pub mod nautilus;
pub mod overrides;
pub mod package;
pub mod pane;
pub mod panel;
pub mod prefs;
pub mod ptyxis;
pub mod selection;
pub mod settings;
pub mod shell;
pub mod util;
pub mod vte;

use std::os::raw::c_int;
use std::ptr;

use gtk::glib::{self, ffi::GList, gobject_ffi, translate::{from_glib_none, FromGlibPtrContainer}};

use nautilus::{gpointer, GType, NautilusFileInfoC};
use util::guard;

static mut TYPES: [GType; 1] = [0];

unsafe extern "C" fn get_file_items(_p: gpointer, files: *mut GList) -> *mut GList {
    guard("file menu", ptr::null_mut(), || {
        let files: Vec<glib::Object> = FromGlibPtrContainer::from_glib_none(files);
        nautilus::menu_list(menus::file_items(&files))
    })
}

unsafe extern "C" fn get_background_items(_p: gpointer, f: *mut NautilusFileInfoC) -> *mut GList {
    guard("background menu", ptr::null_mut(), || {
        if f.is_null() {
            return ptr::null_mut();
        }
        let folder: glib::Object = from_glib_none(f as *mut gobject_ffi::GObject);
        nautilus::menu_list(menus::background_items(&folder))
    })
}

unsafe extern "C" fn menu_iface_init(iface: gpointer, _: gpointer) {
    let i = &mut *(iface as *mut nautilus::MenuProviderInterface);
    i.get_file_items = Some(get_file_items);
    i.get_background_items = Some(get_background_items);
}

unsafe extern "C" fn get_models(_p: gpointer, files: *mut GList) -> *mut GList {
    guard("properties", ptr::null_mut(), || {
        let files: Vec<glib::Object> = FromGlibPtrContainer::from_glib_none(files);
        nautilus::object_list(package::models(&files))
    })
}

unsafe extern "C" fn properties_iface_init(iface: gpointer, _: gpointer) {
    let i = &mut *(iface as *mut nautilus::PropertiesModelProviderInterface);
    i.get_models = Some(get_models);
}

unsafe fn register(module: *mut gobject_ffi::GTypeModule) -> GType {
    let mut q: gobject_ffi::GTypeQuery = std::mem::zeroed();
    gobject_ffi::g_type_query(gobject_ffi::G_TYPE_OBJECT, &mut q);
    let info = gobject_ffi::GTypeInfo {
        class_size: q.class_size as u16,
        base_init: None,
        base_finalize: None,
        class_init: None,
        class_finalize: None,
        class_data: ptr::null(),
        instance_size: q.instance_size as u16,
        n_preallocs: 0,
        instance_init: None,
        value_table: ptr::null(),
    };
    let t = gobject_ffi::g_type_module_register_type(
        module, gobject_ffi::G_TYPE_OBJECT, c"NautilusToolsOgu".as_ptr(), &info, 0);
    let iface = gobject_ffi::GInterfaceInfo {
        interface_init: Some(menu_iface_init),
        interface_finalize: None,
        interface_data: ptr::null_mut(),
    };
    gobject_ffi::g_type_module_add_interface(module, t, nautilus::nautilus_menu_provider_get_type(),
                                             &iface);
    let iface = gobject_ffi::GInterfaceInfo {
        interface_init: Some(properties_iface_init),
        interface_finalize: None,
        interface_data: ptr::null_mut(),
    };
    gobject_ffi::g_type_module_add_interface(
        module, t, nautilus::nautilus_properties_model_provider_get_type(), &iface);
    t
}

#[no_mangle]
pub unsafe extern "C" fn nautilus_module_initialize(module: *mut gobject_ffi::GTypeModule) {
    guard("initialization", (), || {
        i18n::init();
        let t = register(module);
        *ptr::addr_of_mut!(TYPES) = [t];
        log!("module loaded (nautilus-tools-ogu {})", env!("CARGO_PKG_VERSION"));
        panel::start();
    })
}

#[no_mangle]
pub unsafe extern "C" fn nautilus_module_list_types(types: *mut *const GType, n: *mut c_int) {
    *types = ptr::addr_of!(TYPES) as *const GType;
    *n = if (*ptr::addr_of!(TYPES))[0] == 0 { 0 } else { 1 };
}

#[no_mangle]
pub extern "C" fn nautilus_module_shutdown() {
    log!("module shutdown");
}
