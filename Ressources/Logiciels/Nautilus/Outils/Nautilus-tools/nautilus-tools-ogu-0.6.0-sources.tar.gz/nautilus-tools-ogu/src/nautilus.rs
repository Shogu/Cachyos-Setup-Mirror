#![allow(non_camel_case_types)]

use std::os::raw::c_char;
use std::path::PathBuf;

use gtk::gio::{self, prelude::FileExt};

use crate::util::cstr;
use gtk::glib::{self, ffi::GList, gobject_ffi, prelude::*, translate::*};

pub type GType = glib::ffi::GType;
pub type gpointer = glib::ffi::gpointer;

pub enum NautilusFileInfoC {}
pub enum NautilusMenuItemC {}

#[repr(C)]
pub struct MenuProviderInterface {
    pub g_iface: gobject_ffi::GTypeInterface,
    pub get_file_items: Option<unsafe extern "C" fn(gpointer, *mut GList) -> *mut GList>,
    pub get_background_items:
        Option<unsafe extern "C" fn(gpointer, *mut NautilusFileInfoC) -> *mut GList>,
}

#[repr(C)]
pub struct PropertiesModelProviderInterface {
    pub g_iface: gobject_ffi::GTypeInterface,
    pub get_models: Option<unsafe extern "C" fn(gpointer, *mut GList) -> *mut GList>,
}

pub enum NautilusPropertiesItemC {}
pub enum NautilusPropertiesModelC {}

#[link(name = "libnautilus-extension.so.4", kind = "dylib", modifiers = "+verbatim")]
extern "C" {
    pub fn nautilus_properties_model_provider_get_type() -> GType;
    fn nautilus_properties_item_get_type() -> GType;
    fn nautilus_properties_item_new(name: *const c_char, value: *const c_char)
                                    -> *mut NautilusPropertiesItemC;
    fn nautilus_properties_model_new(title: *const c_char, model: *mut gio::ffi::GListModel)
                                     -> *mut NautilusPropertiesModelC;
    pub fn nautilus_menu_provider_get_type() -> GType;
    fn nautilus_file_info_get_type() -> GType;
    fn nautilus_menu_item_new(name: *const c_char, label: *const c_char,
                              tip: *const c_char, icon: *const c_char) -> *mut NautilusMenuItemC;
    fn nautilus_file_info_get_location(f: *mut NautilusFileInfoC) -> *mut gio::ffi::GFile;
}


pub fn file_location(file: &glib::Object) -> Option<gio::File> {
    let iface = unsafe { glib::Type::from_glib(nautilus_file_info_get_type()) };
    if !file.type_().is_a(iface) {
        return None;
    }
    unsafe {
        from_glib_full(nautilus_file_info_get_location(file.as_ptr() as *mut NautilusFileInfoC))
    }
}

pub fn file_path(file: &glib::Object) -> Option<PathBuf> {
    file_location(file)?.path()
}

pub struct MenuItem(glib::Object);

impl MenuItem {
    pub fn new(name: &str, label: &str, tip: &str) -> MenuItem {
        let ptr = unsafe {
            nautilus_menu_item_new(cstr(name).as_ptr(), cstr(label).as_ptr(),
                                   cstr(tip).as_ptr(), std::ptr::null())
        };
        MenuItem(unsafe { from_glib_full(ptr as *mut gobject_ffi::GObject) })
    }

    pub fn on_activate(&self, f: impl Fn() + 'static) {
        self.0.connect_local("activate", false, move |_| {
            crate::util::guard("menu item", (), &f);
            None
        });
    }
}

pub fn menu_list(items: Vec<MenuItem>) -> *mut GList {
    let mut list = std::ptr::null_mut();
    for i in items {
        let p: *mut gobject_ffi::GObject = i.0.into_glib_ptr();
        list = unsafe { glib::ffi::g_list_append(list, p as gpointer) };
    }
    list
}

pub fn properties_item_type() -> glib::Type {
    unsafe { from_glib(nautilus_properties_item_get_type()) }
}

pub fn properties_item(name: &str, value: &str) -> glib::Object {
    unsafe {
        from_glib_full(nautilus_properties_item_new(cstr(name).as_ptr(), cstr(value).as_ptr())
                       as *mut gobject_ffi::GObject)
    }
}

pub fn properties_model(title: &str, model: &gio::ListModel) -> glib::Object {
    unsafe {
        from_glib_full(nautilus_properties_model_new(cstr(title).as_ptr(), model.to_glib_none().0)
                       as *mut gobject_ffi::GObject)
    }
}

/// GList (transfer full) of objects, as the provider interfaces return
pub fn object_list(items: Vec<glib::Object>) -> *mut GList {
    let mut list = std::ptr::null_mut();
    for i in items {
        let p: *mut gobject_ffi::GObject = i.into_glib_ptr();
        list = unsafe { glib::ffi::g_list_append(list, p as gpointer) };
    }
    list
}
