//! Context menu items: open in Ptyxis or OpenCode, open or edit as administrator,
//! copy the path.

use std::ffi::OsStr;
use std::path::{Path, PathBuf};

use gtk::gdk::{self, prelude::*};
use gtk::gio;
use gtk::glib;

use crate::i18n::tr;
use crate::log;
use crate::nautilus::{self, MenuItem};

const ID: &str = "NautilusToolsOgu";

/// gvfs admin backend (admin:// URIs), needed by the administrator items
fn admin_backend() -> bool {
    ["/usr/lib/gvfsd-admin", "/usr/libexec/gvfsd-admin", "/usr/lib/gvfs/gvfsd-admin"]
        .iter()
        .any(|p| Path::new(p).exists())
}

extern "C" {
    fn geteuid() -> u32;
}

fn is_root() -> bool {
    // SAFETY: geteuid cannot fail
    unsafe { geteuid() == 0 }
}

fn admin_on() -> bool {
    !is_root() && admin_backend()
}

/// admin:// URI of a local file, None for any other scheme
fn admin_uri(loc: &gio::File) -> Option<String> {
    if !loc.has_uri_scheme("file") {
        return None;
    }
    loc.uri().strip_prefix("file://").map(|rest| format!("admin://{rest}"))
}

fn is_dir(loc: &gio::File) -> bool {
    loc.query_file_type(gio::FileQueryInfoFlags::NONE, None::<&gio::Cancellable>)
        == gio::FileType::Directory
}

fn spawn(argv: &[&OsStr], what: &str) {
    match gio::Subprocess::newv(argv, gio::SubprocessFlags::NONE) {
        // GSubprocess reaps the child: no zombie left in Nautilus
        Ok(p) => p.wait_async(None::<&gio::Cancellable>, |_| ()),
        Err(e) => log!("{what}: {e}"),
    }
}

// ---------- Ptyxis

fn ptyxis_item(id: &str, dir: PathBuf) -> Option<MenuItem> {
    crate::ptyxis::program()?;
    let item = MenuItem::new(id, &tr("Open in Ptyxis"), &tr("Open a Ptyxis tab in this folder"));
    item.on_activate(move || crate::ptyxis::open(&dir));
    Some(item)
}

// ---------- OpenCode

fn opencode_item(id: &str, dir: PathBuf) -> Option<MenuItem> {
    let ptyxis = crate::ptyxis::program()?;
    let item = MenuItem::new(id, &tr("Open in OpenCode"), &tr("Open an OpenCode session in this folder"));
    item.on_activate(move || {
        // opencode may only be in the PATH of the login shell Ptyxis starts
        let command = glib::find_program_in_path("opencode")
            .map_or_else(|| "opencode".into(), |p| glib::shell_quote(p).to_string_lossy().into_owned());
        spawn(&[ptyxis.as_os_str(), "-d".as_ref(), dir.as_os_str(), "-x".as_ref(), command.as_ref()], "opencode");
    });
    Some(item)
}

// ---------- administrator

fn open_admin_item(id: &str, uri: String) -> MenuItem {
    let item = MenuItem::new(id, &tr("Open as Administrator"),
                             &tr("Open this folder with administrator privileges"));
    item.on_activate(move || {
        // a new Nautilus window: the admin:// backend asks for the password
        match glib::find_program_in_path("nautilus") {
            Some(n) => spawn(&[n.as_os_str(), uri.as_ref()], "open as administrator"),
            None => log!("open as administrator: nautilus not found"),
        }
    });
    item
}

fn edit_admin_item(id: &str, loc: gio::File, uri: String) -> MenuItem {
    let item = MenuItem::new(id, &tr("Edit as Administrator"),
                             &tr("Open this file in its default application with administrator privileges"));
    item.on_activate(move || {
        let ctype = loc
            .query_info(gio::FILE_ATTRIBUTE_STANDARD_CONTENT_TYPE, gio::FileQueryInfoFlags::NONE,
                        None::<&gio::Cancellable>)
            .ok()
            .and_then(|i| i.content_type())
            .map(|c| c.to_string())
            .unwrap_or_else(|| "text/plain".into());
        let app = gio::AppInfo::default_for_type(&ctype, true)
            .or_else(|| gio::AppInfo::default_for_type("text/plain", true));
        match app {
            Some(app) => {
                if let Err(e) = app.launch_uris(&[uri.as_str()], None::<&gio::AppLaunchContext>) {
                    log!("edit as administrator: {e}");
                }
            }
            None => log!("edit as administrator: no application for {ctype}"),
        }
    });
    item
}

// ---------- copy the path

fn copy_item(id: &str, paths: Vec<PathBuf>, tip: &str) -> Option<MenuItem> {
    if paths.is_empty() {
        return None;
    }
    let label = if paths.len() == 1 { tr("Copy the Path") } else { tr("Copy the Paths") };
    let item = MenuItem::new(id, &label, tip);
    item.on_activate(move || {
        let text = paths.iter().map(|p| p.to_string_lossy()).collect::<Vec<_>>().join("\n");
        match gdk::Display::default() {
            Some(d) => d.clipboard().set_text(&text),
            None => log!("copy the path: no display"),
        }
    });
    Some(item)
}

// ---------- menus

/// Items for a selection
pub fn file_items(files: &[glib::Object]) -> Vec<MenuItem> {
    let locs: Vec<gio::File> = files.iter().filter_map(nautilus::file_location).collect();
    if locs.is_empty() || locs.len() != files.len() {
        return Vec::new();
    }
    let paths: Vec<PathBuf> = locs.iter().filter_map(|l| l.path()).collect();
    let all_local = paths.len() == locs.len();
    let mut items = Vec::new();

    if let [loc] = locs.as_slice() {
        if is_dir(loc) {
            if let Some(p) = loc.path() {
                items.extend(ptyxis_item(&format!("{ID}::ptyxis_sel"), p.clone()));
                items.extend(opencode_item(&format!("{ID}::opencode_sel"), p));
            }
            if admin_on() {
                if let Some(uri) = admin_uri(loc) {
                    items.push(open_admin_item(&format!("{ID}::admin_sel"), uri));
                }
            }
        } else if admin_on() {
            if let Some(uri) = admin_uri(loc) {
                items.push(edit_admin_item(&format!("{ID}::edit_admin"), loc.clone(), uri));
            }
        }
    }
    if all_local {
        items.extend(copy_item(&format!("{ID}::copy_sel"), paths,
                               &tr("Copy the full path of the selected items")));
    }
    items
}

/// Items for the folder background
pub fn background_items(folder: &glib::Object) -> Vec<MenuItem> {
    let Some(loc) = nautilus::file_location(folder) else { return Vec::new() };
    let mut items = Vec::new();
    if let Some(p) = loc.path() {
        items.extend(ptyxis_item(&format!("{ID}::ptyxis_bg"), p.clone()));
        items.extend(opencode_item(&format!("{ID}::opencode_bg"), p.clone()));
        items.extend(copy_item(&format!("{ID}::copy_bg"), vec![p],
                               &tr("Copy the full path of this folder")));
    }
    if admin_on() {
        if let Some(uri) = admin_uri(&loc) {
            items.push(open_admin_item(&format!("{ID}::admin_bg"), uri));
        }
    }
    items
}
