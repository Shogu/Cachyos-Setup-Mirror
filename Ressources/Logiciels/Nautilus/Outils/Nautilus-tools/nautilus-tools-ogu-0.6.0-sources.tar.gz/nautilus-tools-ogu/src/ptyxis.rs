//! Settings taken from the user's Ptyxis profile, and handing a folder over to Ptyxis

use std::cell::RefCell;
use std::path::Path;

use gtk::gio::{self, prelude::*};
use gtk::glib;

use crate::log;
use crate::util::guard;

const APP: &str = "org.gnome.Ptyxis";
const PROFILE: &str = "org.gnome.Ptyxis.Profile";

/// What ShellMan applies from Ptyxis; None: Ptyxis has no such key
#[derive(Clone, Default, PartialEq, Debug)]
pub struct Profile {
    /// None: the system monospace font
    pub font: Option<String>,
    /// -1: unlimited
    pub scrollback: Option<i64>,
    pub cursor_shape: Option<i32>,
    pub cursor_blink: Option<i32>,
    pub bold_is_bright: Option<bool>,
    pub cell_height: Option<f64>,
    pub audible_bell: Option<bool>,
}

thread_local! {
    static WATCH: RefCell<Vec<gio::Settings>> = const { RefCell::new(Vec::new()) };
    static LOGGED: RefCell<Option<Profile>> = const { RefCell::new(None) };
}

fn schema(id: &str) -> Option<gio::SettingsSchema> {
    gio::SettingsSchemaSource::default()?.lookup(id, true)
}

pub fn installed() -> bool {
    schema(APP).is_some()
}

struct Opened(gio::Settings, gio::SettingsSchema);

impl Opened {
    fn new(id: &str, path: Option<&str>) -> Option<Opened> {
        let schema = schema(id)?;
        if schema.path().is_none() && path.is_none() {
            return None;
        }
        let s = gio::Settings::new_full(&schema, None::<&gio::SettingsBackend>, path);
        Some(Opened(s, schema))
    }
    fn has(&self, key: &str) -> bool {
        self.1.has_key(key)
    }
    fn boolean(&self, key: &str) -> Option<bool> {
        self.has(key).then(|| self.0.boolean(key))
    }
    fn string(&self, key: &str) -> Option<String> {
        self.has(key).then(|| self.0.string(key).to_string())
    }
    fn int(&self, key: &str) -> Option<i32> {
        self.has(key).then(|| self.0.int(key))
    }
    fn double(&self, key: &str) -> Option<f64> {
        self.has(key).then(|| self.0.double(key))
    }
    // the Ptyxis enums use the same values as the VTE ones
    fn enum_(&self, key: &str) -> Option<i32> {
        self.has(key).then(|| self.0.enum_(key)).filter(|v| (0..=2).contains(v))
    }
}

/// Reads the default Ptyxis profile, and watches it; None: Ptyxis is not installed
pub fn profile() -> Option<Profile> {
    let app = Opened::new(APP, None)?;
    let uuid = app.string("default-profile-uuid").unwrap_or_default();
    let prof = if !uuid.chars().all(|c| c.is_ascii_hexdigit() || c == '-') || uuid.is_empty() {
        None
    } else {
        Opened::new(PROFILE, Some(&format!("/org/gnome/Ptyxis/Profiles/{uuid}/")))
    };
    let font = match app.boolean("use-system-font") {
        Some(false) => app.string("font-name").filter(|f| !f.trim().is_empty()),
        _ => None,
    };
    let scrollback = prof.as_ref().and_then(|p| match p.boolean("limit-scrollback") {
        Some(false) => Some(-1),
        _ => p.int("scrollback-lines").map(i64::from),
    });
    let p = Profile {
        font,
        scrollback,
        cursor_shape: app.enum_("cursor-shape"),
        cursor_blink: app.enum_("cursor-blink-mode"),
        bold_is_bright: prof.as_ref().and_then(|p| p.boolean("bold-is-bright")),
        cell_height: prof.as_ref().and_then(|p| p.double("cell-height-scale"))
            .filter(|v| (1.0..=2.0).contains(v)),
        audible_bell: app.boolean("audible-bell"),
    };
    let mut watch = vec![app.0];
    watch.extend(prof.map(|p| p.0));
    for w in &watch {
        w.connect_changed(None, |_, _| guard("Ptyxis profile", (), || {
            glib::idle_add_local_once(|| guard("Ptyxis profile", (), crate::panel::apply_settings_all));
        }));
        // GSettings only reports keys read after connecting
        if let Some(schema) = w.settings_schema() {
            for key in schema.list_keys() {
                let _ = w.value(&key);
            }
        }
    }
    WATCH.with(|c| c.replace(watch));
    LOGGED.with(|l| {
        if l.borrow().as_ref() != Some(&p) {
            log!("Ptyxis profile: {p:?}");
            l.replace(Some(p.clone()));
        }
    });
    Some(p)
}

/// The Ptyxis command, if it can be launched
pub fn program() -> Option<std::path::PathBuf> {
    glib::find_program_in_path("ptyxis")
}

/// Opens a Ptyxis tab in `dir` (a new window if Ptyxis is not running yet)
pub fn open(dir: &Path) {
    run(dir, &[]);
}

/// Same, running `command` in the tab instead of the shell
pub fn run(dir: &Path, command: &[&std::ffi::OsStr]) {
    let Some(prog) = program() else {
        log!("ptyxis not found in PATH");
        return;
    };
    let mut argv = vec![prog.as_os_str(), "--tab".as_ref(), "-d".as_ref(), dir.as_os_str()];
    if !command.is_empty() {
        argv.push("--".as_ref());
        argv.extend_from_slice(command);
    }
    // GSubprocess reaps the child: no zombie left in Nautilus
    match gio::Subprocess::newv(&argv, gio::SubprocessFlags::NONE) {
        Ok(p) => p.wait_async(None::<&gio::Cancellable>, |r| {
            if let Err(e) = r {
                log!("ptyxis: {e}");
            }
        }),
        Err(e) => log!("cannot start ptyxis: {e}"),
    }
}
