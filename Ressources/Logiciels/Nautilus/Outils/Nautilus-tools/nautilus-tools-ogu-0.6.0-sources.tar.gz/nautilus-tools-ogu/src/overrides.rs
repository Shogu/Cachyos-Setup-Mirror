//! Changes to Nautilus' own context menu.
//!
//! - « Email… » (Nautilus) and « Extract Here » (file-roller extension, a
//!   duplicate of Nautilus' « Extract ») are removed.
//! - « Copy to… » and « Move to… » ask for the destination through the
//!   FileChooser portal. Nautilus provides that portal's dialog but turns the
//!   portal off for its own process (it would call itself), so its own items
//!   fall back to the legacy GtkFileChooser. The copy or move itself is left to
//!   Nautilus (FileOperations2 D-Bus API): progress, conflicts and undo as usual.
//!
//! The extension API gives no access to these menus: the menu model of each
//! context menu popover is patched when it opens, before it is drawn.

use std::cell::{Cell, RefCell};
use std::collections::HashMap;
use std::os::unix::ffi::OsStrExt;
use std::path::PathBuf;
use std::rc::Rc;
use std::time::Duration;

use gdk4_wayland::WaylandToplevel;
use gettextrs::dgettext;
use gtk::gio::{self, prelude::*};
use gtk::glib;
use gtk::prelude::*;

use crate::log;
use crate::selection;
use crate::util::{guard, type_name, walk};

const ATTACHED: &str = "nautilus-tools-ogu-overrides";
const PATCHED: &str = "nautilus-tools-ogu-patched";
const GROUP: &str = "ogu-tools";

fn hidden(action: &str) -> bool {
    action == "view.send-email"
        // file-roller: NautilusFr::extract_here, escaped in Nautilus' action name
        || (action.starts_with("view.extension_") && action.contains("extract_here"))
}

fn replacement(action: &str) -> Option<&'static str> {
    match action {
        "view.copy-to" => Some("ogu-tools.copy-to"),
        "view.move-to" => Some("ogu-tools.move-to"),
        _ => None,
    }
}

/// Patches a menu model in place; true if it has (or now has) our items
fn patch_model(model: &gio::MenuModel) -> bool {
    let mut ours = false;
    let menu = model.downcast_ref::<gio::Menu>();
    for i in (0..model.n_items()).rev() {
        for link in [gio::MENU_LINK_SECTION, gio::MENU_LINK_SUBMENU] {
            if let Some(sub) = model.item_link(i, link) {
                ours |= patch_model(&sub);
            }
        }
        let action = model
            .item_attribute_value(i, gio::MENU_ATTRIBUTE_ACTION, Some(glib::VariantTy::STRING))
            .and_then(|v| v.str().map(str::to_owned));
        let Some(action) = action else { continue };
        if action.starts_with(GROUP) {
            ours = true;
            continue;
        }
        let Some(menu) = menu else { continue };
        if hidden(&action) {
            menu.remove(i);
        } else if let Some(new) = replacement(&action) {
            let item = gio::MenuItem::from_model(model, i);
            item.set_action_and_target_value(Some(new), None);
            menu.remove(i);
            menu.insert_item(i, &item);
            ours = true;
        }
    }
    ours
}

fn actions(view: &gtk::Widget) -> gio::SimpleActionGroup {
    let group = gio::SimpleActionGroup::new();
    for (name, is_move) in [("copy-to", false), ("move-to", true)] {
        let action = gio::SimpleAction::new(name, None);
        let weak = view.downgrade();
        action.connect_activate(move |_, _| {
            if let Some(view) = weak.upgrade() {
                guard(name, (), || transfer(&view, is_move));
            }
        });
        group.add_action(&action);
    }
    group
}

fn patch_popovers(win: &gtk::Window) {
    for w in walk(win) {
        let Some(pop) = w.downcast_ref::<gtk::PopoverMenu>() else { continue };
        if unsafe { pop.data::<bool>(PATCHED) }.is_some() {
            continue;
        }
        let (Some(model), Some(view)) = (pop.menu_model(), pop.parent()) else { continue };
        unsafe { pop.set_data(PATCHED, true) };
        if patch_model(&model) {
            pop.insert_action_group(GROUP, Some(&actions(&view)));
        }
    }
}

fn schedule_patch(win: &gtk::Window) {
    // before the next frame (paint: HIGH_IDLE + 20), so the removed items never show
    for delay in [None, Some(Duration::from_millis(80))] {
        let weak = win.downgrade();
        let run = move || {
            if let Some(win) = weak.upgrade() {
                guard("context menu", (), || patch_popovers(&win));
            }
        };
        match delay {
            None => {
                glib::idle_add_local_full(glib::Priority::HIGH_IDLE, move || {
                    run();
                    glib::ControlFlow::Break
                });
            }
            Some(d) => {
                glib::timeout_add_local_once(d, run);
            }
        }
    }
}

fn opens_menu(event: &gtk::gdk::Event) -> bool {
    use gtk::gdk::{EventType, Key, ModifierType};
    match event.event_type() {
        EventType::ButtonPress => event
            .downcast_ref::<gtk::gdk::ButtonEvent>()
            .is_some_and(|b| b.button() == gtk::gdk::BUTTON_SECONDARY),
        EventType::KeyPress => event.downcast_ref::<gtk::gdk::KeyEvent>().is_some_and(|k| {
            let key = k.keyval();
            key == Key::Menu
                || (key == Key::F10 && k.modifier_state().contains(ModifierType::SHIFT_MASK))
        }),
        _ => false,
    }
}

pub fn attach(win: &gtk::Window) {
    if type_name(win) != "NautilusWindow" || unsafe { win.data::<bool>(ATTACHED) }.is_some() {
        return;
    }
    unsafe { win.set_data(ATTACHED, true) };
    let legacy = gtk::EventControllerLegacy::new();
    legacy.set_propagation_phase(gtk::PropagationPhase::Capture);
    let weak = win.downgrade();
    legacy.connect_event(move |_, event| {
        if opens_menu(event) {
            if let Some(win) = weak.upgrade() {
                schedule_patch(&win);
            }
        }
        glib::Propagation::Proceed
    });
    win.add_controller(legacy);
}

// ---------- Copy to… / Move to…

fn transfer(view: &gtk::Widget, is_move: bool) {
    let files = selection::selected_files(view);
    if files.is_empty() {
        log!("copy/move to: empty selection");
        return;
    }
    let Some(win) = view.root().and_downcast::<gtk::Window>() else { return };
    let title = dgettext("nautilus",
                         if is_move { "Select Move Destination" } else { "Select Copy Destination" });
    let accept = dgettext("nautilus", "_Select");
    let start = files[0].parent().and_then(|p| p.path());
    let uris: Vec<String> = files.iter().map(|f| f.uri().to_string()).collect();
    pick_folder(&win, &title, &accept, start, move |dest| {
        file_operation(if is_move { "MoveURIs" } else { "CopyURIs" }, uris, dest.uri().to_string());
    });
}

fn file_operation(method: &str, uris: Vec<String>, dest: String) {
    let Some(app) = gio::Application::default() else { return };
    let Some(id) = app.application_id() else { return };
    let path = format!("/{}/FileOperations2", id.replace('.', "/"));
    let Some(conn) = app.dbus_connection() else { return };
    let params = glib::Variant::tuple_from_iter([
        uris.to_variant(),
        dest.to_variant(),
        glib::VariantDict::new(None).end(),
    ]);
    let what = method.to_owned();
    conn.call(Some(id.as_str()), &path, "org.gnome.Nautilus.FileOperations2", method,
              Some(&params), None, gio::DBusCallFlags::NONE, -1, None::<&gio::Cancellable>,
              move |res| {
                  if let Err(e) = res {
                      log!("{what}: {e}");
                  }
              });
}

/// Wayland handle of the window, for the portal dialog to be attached to it
fn with_parent_handle(win: &gtk::Window, f: impl FnOnce(String, Option<WaylandToplevel>) + 'static) {
    let toplevel = win.surface().and_downcast::<WaylandToplevel>();
    let Some(toplevel) = toplevel else { return f(String::new(), None) };
    let f = Rc::new(Cell::new(Some(f)));
    let fallback = f.clone();
    let ok = toplevel.export_handle(move |t, handle| {
        let Some(f) = f.take() else { return };
        match handle {
            Ok(h) => f(format!("wayland:{h}"), Some(t.clone())),
            Err(e) => {
                log!("cannot export the window handle: {e}");
                f(String::new(), None)
            }
        }
    });
    if !ok {
        if let Some(f) = fallback.take() {
            f(String::new(), None);
        }
    }
}

thread_local! {
    static TOKEN: Cell<u32> = const { Cell::new(0) };
}

pub fn pick_folder(win: &gtk::Window, title: &str, accept: &str, start: Option<PathBuf>,
                   done: impl FnOnce(gio::File) + 'static) {
    let (title, accept) = (title.to_owned(), accept.to_owned());
    with_parent_handle(win, move |handle, toplevel| {
        guard("folder chooser", (), || open_portal(handle, toplevel, title, accept, start, done))
    });
}

fn open_portal(handle: String, toplevel: Option<WaylandToplevel>, title: String, accept: String,
               start: Option<PathBuf>, done: impl FnOnce(gio::File) + 'static) {
    let release = {
        let handle = handle.clone();
        move || {
            if let (Some(t), Some(h)) = (&toplevel, handle.strip_prefix("wayland:")) {
                t.drop_exported_handle(h);
            }
        }
    };
    let conn = match gio::bus_get_sync(gio::BusType::Session, None::<&gio::Cancellable>) {
        Ok(c) => c,
        Err(e) => {
            log!("session bus: {e}");
            return release();
        }
    };
    let Some(unique) = conn.unique_name() else { return release() };
    let sender = unique.trim_start_matches(':').replace('.', "_");
    let token = format!("nautilus_tools_ogu_{}", TOKEN.get());
    TOKEN.set(TOKEN.get().wrapping_add(1));
    let request = format!("/org/freedesktop/portal/desktop/request/{sender}/{token}");

    type State = (Option<gio::SignalSubscription>, Option<Box<dyn FnOnce(Option<gio::File>)>>);
    let state: Rc<RefCell<State>> = Rc::new(RefCell::new((None, None)));
    let finish = {
        let state = state.clone();
        move |dest: Option<gio::File>| {
            let (sub, cb) = {
                let mut s = state.borrow_mut();
                (s.0.take(), s.1.take())
            };
            drop(sub);
            if let Some(cb) = cb {
                cb(dest);
            }
        }
    };
    state.borrow_mut().1 = Some(Box::new(move |dest| {
        release();
        if let Some(dest) = dest {
            done(dest);
        }
    }));

    let on_response = finish.clone();
    let sub = conn.subscribe_to_signal(
        Some("org.freedesktop.portal.Desktop"), Some("org.freedesktop.portal.Request"),
        Some("Response"), Some(&request), None, gio::DBusSignalFlags::NONE,
        move |signal| {
            let dest = signal.parameters.get::<(u32, HashMap<String, glib::Variant>)>()
                .filter(|(code, _)| *code == 0)
                .and_then(|(_, results)| results.get("uris")?.get::<Vec<String>>())
                .and_then(|uris| uris.into_iter().next())
                .map(|uri| gio::File::for_uri(&uri));
            on_response(dest);
        });
    state.borrow_mut().0 = Some(sub);

    let options = glib::VariantDict::new(None);
    options.insert_value("handle_token", &token.to_variant());
    options.insert_value("accept_label", &accept.to_variant());
    options.insert_value("modal", &true.to_variant());
    options.insert_value("directory", &true.to_variant());
    if let Some(dir) = start {
        let mut bytes = dir.as_os_str().as_bytes().to_vec();
        bytes.push(0);
        options.insert_value("current_folder", &glib::Variant::array_from_fixed_array(&bytes));
    }
    let params = glib::Variant::tuple_from_iter([handle.to_variant(), title.to_variant(), options.end()]);
    conn.call(Some("org.freedesktop.portal.Desktop"), "/org/freedesktop/portal/desktop",
              "org.freedesktop.portal.FileChooser", "OpenFile", Some(&params),
              Some(glib::VariantTy::new("(o)").unwrap()), gio::DBusCallFlags::NONE, -1,
              None::<&gio::Cancellable>, move |res| {
                  if let Err(e) = res {
                      log!("FileChooser portal: {e}");
                      finish(None);
                  }
              });
}

#[cfg(test)]
mod tests {
    use super::*;

    fn actions_of(model: &gio::MenuModel) -> Vec<String> {
        let mut out = Vec::new();
        for i in 0..model.n_items() {
            if let Some(sub) = model.item_link(i, gio::MENU_LINK_SECTION) {
                out.extend(actions_of(&sub));
            }
            if let Some(a) = model.item_attribute_value(i, "action", None).and_then(|v| v.str().map(str::to_owned)) {
                out.push(a);
            }
        }
        out
    }

    #[test]
    fn patches_the_selection_menu() {
        let root = gio::Menu::new();
        let a = gio::Menu::new();
        a.append(Some("Copier vers…"), Some("view.copy-to"));
        a.append(Some("Déplacer vers…"), Some("view.move-to"));
        let b = gio::Menu::new();
        b.append(Some("Compresser…"), Some("view.compress"));
        b.append(Some("Courriel…"), Some("view.send-email"));
        b.append(Some("Mettre à la corbeille"), Some("view.move-to-trash"));
        let ext = gio::Menu::new();
        ext.append(Some("Extraire ici"), Some("view.extension_0_0_NautilusFr%3A%3Aextract_here"));
        ext.append(Some("Copier le chemin"), Some("view.extension_1_0_NautilusToolsOgu%3A%3Acopy"));
        root.append_section(None, &a);
        root.append_section(None, &b);
        root.append_section(None, &ext);
        assert!(patch_model(root.upcast_ref()));
        assert_eq!(actions_of(root.upcast_ref()), [
            "ogu-tools.copy-to", "ogu-tools.move-to", "view.compress", "view.move-to-trash",
            "view.extension_1_0_NautilusToolsOgu%3A%3Acopy",
        ]);
        // label kept, second pass is a no-op
        let label = a.item_attribute_value(0, "label", None).and_then(|v| v.str().map(str::to_owned));
        assert_eq!(label.as_deref(), Some("Copier vers…"));
        assert!(patch_model(root.upcast_ref()));
        assert_eq!(a.n_items(), 2);
    }
}
