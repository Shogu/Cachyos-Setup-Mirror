//! « Package » tab in the Properties of a pacman package (.pkg.tar.zst):
//! its .PKGINFO, compared with the installed version.
//!
//! Nautilus asks for the models synchronously: the tab is returned empty and
//! filled once bsdtar, pacman and vercmp have answered (asynchronously).

use std::collections::HashMap;
use std::path::{Path, PathBuf};

use gtk::gio::{self, prelude::*};
use gtk::glib;

use crate::i18n::tr;
use crate::log;
use crate::nautilus;

const SUFFIXES: [&str; 3] = [".pkg.tar.zst", ".pkg.tar.xz", ".pkg.tar.gz"];

pub fn is_package(path: &Path) -> bool {
    path.file_name()
        .and_then(|n| n.to_str())
        .is_some_and(|n| SUFFIXES.iter().any(|s| n.ends_with(s)))
}

/// Properties models for the selected files (none unless a single package)
pub fn models(files: &[glib::Object]) -> Vec<glib::Object> {
    let [file] = files else { return Vec::new() };
    let Some(path) = nautilus::file_path(file).filter(|p| is_package(p)) else { return Vec::new() };
    let store = gio::ListStore::with_type(nautilus::properties_item_type());
    fill(store.clone(), path);
    vec![nautilus::properties_model(&tr("Package"), store.upcast_ref())]
}

type Info = HashMap<String, Vec<String>>;

fn parse(pkginfo: &str) -> Info {
    let mut info = Info::new();
    for line in pkginfo.lines() {
        if line.starts_with('#') {
            continue;
        }
        if let Some((k, v)) = line.split_once(" = ") {
            info.entry(k.trim().to_owned()).or_default().push(v.trim().to_owned());
        }
    }
    info
}

fn run(argv: &[&str], done: impl FnOnce(Option<String>) + 'static) {
    let argv: Vec<&std::ffi::OsStr> = argv.iter().map(std::ffi::OsStr::new).collect();
    let proc = match gio::Subprocess::newv(
        &argv, gio::SubprocessFlags::STDOUT_PIPE | gio::SubprocessFlags::STDERR_SILENCE) {
        Ok(p) => p,
        Err(e) => {
            log!("{:?}: {e}", argv[0]);
            return done(None);
        }
    };
    let p = proc.clone();
    proc.communicate_utf8_async(None, None::<&gio::Cancellable>, move |res| {
        let ok = p.is_successful();
        done(res.ok().filter(|_| ok).and_then(|(out, _)| out.map(|s| s.to_string())));
    });
}

fn fill(store: gio::ListStore, path: PathBuf) {
    let file = path.to_string_lossy().into_owned();
    run(&["bsdtar", "-xOqf", &file, ".PKGINFO"], move |out| {
        let Some(out) = out else {
            store.append(&nautilus::properties_item(&tr("Error"), &tr("Cannot read the package information")));
            return;
        };
        let info = parse(&out);
        let first = |k: &str| info.get(k).and_then(|v| v.first()).cloned().unwrap_or_default();
        let (name, version) = (first("pkgname"), first("pkgver"));
        let q = ["pacman", "-Q", "--", name.as_str()];
        run(&q, move |installed| {
            let installed = installed
                .and_then(|l| l.split_whitespace().nth(1).map(str::to_owned));
            match installed {
                None => show(&store, &info, &version, tr("Not installed")),
                Some(inst) => {
                    let v = version.clone();
                    let i = inst.clone();
                    run(&["vercmp", &v, &i], move |cmp| {
                        let cmp = cmp.and_then(|c| c.trim().parse::<i32>().ok());
                        let note = match cmp {
                            Some(0) => tr("same version"),
                            Some(n) if n > 0 => tr("this file is newer"),
                            Some(_) => tr("this file is older"),
                            None => String::new(),
                        };
                        let text = if note.is_empty() { inst } else { format!("{inst} ({note})") };
                        show(&store, &info, &version, text);
                    });
                }
            }
        });
    });
}

fn show(store: &gio::ListStore, info: &Info, version: &str, installed: String) {
    let join = |k: &str, sep: &str| info.get(k).map(|v| v.join(sep)).unwrap_or_default();
    let mut rows: Vec<(String, String)> = vec![
        (tr("Name"), join("pkgname", "")),
        (tr("Version"), version.to_owned()),
        (tr("Installed Version"), installed),
        (tr("Description"), join("pkgdesc", " ")),
    ];
    if let Some(size) = info.get("size").and_then(|v| v.first()).and_then(|s| s.parse::<u64>().ok()) {
        rows.push((tr("Installed Size"), glib::format_size(size).to_string()));
    }
    if let Some(date) = info.get("builddate").and_then(|v| v.first())
        .and_then(|s| s.parse::<i64>().ok())
        .and_then(|t| glib::DateTime::from_unix_local(t).ok())
        .and_then(|d| d.format("%x %H:%M").ok()) {
        rows.push((tr("Build Date"), date.to_string()));
    }
    rows.extend([
        (tr("Packager"), join("packager", "")),
        (tr("Architecture"), join("arch", ", ")),
        (tr("License"), join("license", ", ")),
        (tr("Website"), join("url", "")),
        (tr("Dependencies"), join("depend", ", ")),
        (tr("Optional Dependencies"), join("optdepend", "\n")),
        (tr("Provides"), join("provides", ", ")),
        (tr("Conflicts With"), join("conflict", ", ")),
        (tr("Replaces"), join("replaces", ", ")),
    ]);
    let items: Vec<glib::Object> = rows.into_iter()
        .filter(|(_, v)| !v.is_empty())
        .map(|(k, v)| nautilus::properties_item(&k, &v))
        .collect();
    store.splice(0, store.n_items(), &items);
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_pkginfo() {
        let info = parse("# Generated by makepkg\npkgname = foo\npkgver = 1.0-1\ndepend = a\ndepend = b>=2\noptdepend = c: does things\n");
        assert_eq!(info["pkgname"], ["foo"]);
        assert_eq!(info["depend"], ["a", "b>=2"]);
        assert_eq!(info["optdepend"], ["c: does things"]);
        assert!(is_package(Path::new("/x/foo-1.0-1-x86_64.pkg.tar.zst")));
        assert!(!is_package(Path::new("/x/foo.tar.zst")));
    }
}

