//! Custom icons for the sidebar bookmarks: « Change Icon… » in a bookmark's
//! context menu, kept in GSettings and applied again whenever Nautilus rebuilds
//! its sidebar.
//!
//! Adapted from Nautilus My Computer, Copyright (c) 2026 Yann Masoch (MIT License).

use std::cell::{Cell, OnceCell};
use std::collections::{HashMap, HashSet};
use std::time::Duration;

use gtk::gio::{self, prelude::*};
use gtk::glib;
use gtk::prelude::*;

use crate::i18n::tr;
use crate::log;
use crate::util::{guard, type_name, walk};

const SCHEMA: &str = "io.github.ogu.nautilus-bookmark-icons";
const KEY: &str = "custom-bookmark-icons";
const ATTACHED: &str = "nautilus-tools-ogu-bookmarks";
const OBSERVER: &str = "nautilus-tools-ogu-bookmarks-observer";
const WATCHED: &str = "nautilus-tools-ogu-bookmark-watched";
const NATIVE: &str = "nautilus-tools-ogu-bookmark-native-icon";
const PATCHED: &str = "nautilus-tools-ogu-bookmark-menu";
const LAST_ROW: &str = "nautilus-tools-ogu-bookmark-last-row";
const GROUP: &str = "ogu-bookmark";
const COLUMNS: u32 = 6;
const CELL: i32 = 36;

thread_local! {
    static SETTINGS: OnceCell<Option<gio::Settings>> = const { OnceCell::new() };
    static LISTS: std::cell::RefCell<Vec<glib::WeakRef<gtk::ListBox>>> = const { std::cell::RefCell::new(Vec::new()) };
}

fn settings() -> Option<gio::Settings> {
    SETTINGS.with(|cell| {
        cell.get_or_init(|| {
            gio::SettingsSchemaSource::default()?.lookup(SCHEMA, true)?;
            let settings = gio::Settings::new(SCHEMA);
            settings.connect_changed(Some(KEY), |_, _| refresh_all());
            Some(settings)
        })
        .clone()
    })
}

fn key(uri: &str) -> &str {
    uri.trim_end_matches('/')
}

fn custom_icons() -> HashMap<String, String> {
    settings().and_then(|s| s.value(KEY).get()).unwrap_or_default()
}

fn store(uri: &str, icon: Option<&str>) {
    let Some(settings) = settings() else { return };
    let mut icons = custom_icons();
    match icon {
        Some(name) => icons.insert(key(uri).to_owned(), name.to_owned()),
        None => icons.remove(key(uri)),
    };
    if let Err(e) = settings.set_value(KEY, &icons.to_variant()) {
        log!("bookmark icons: {e}");
    }
}

fn bookmarks() -> HashSet<String> {
    let path = glib::user_config_dir().join("gtk-3.0").join("bookmarks");
    std::fs::read_to_string(path)
        .unwrap_or_default()
        .lines()
        .filter_map(|l| l.split_whitespace().next())
        .map(|uri| key(uri).to_owned())
        .collect()
}

fn row_uri(row: &gtk::Widget) -> Option<String> {
    row.find_property("uri")?;
    row.property::<Option<String>>("uri")
}

fn icon_name(icon: Option<gio::Icon>) -> Option<String> {
    let themed = icon?.downcast::<gio::ThemedIcon>().ok()?;
    themed.names().first().map(|n| n.to_string())
}

fn has_icon(row: &gtk::Widget, name: &str) -> bool {
    gtk::IconTheme::for_display(&row.display()).has_icon(name)
}

/// Shows the custom icon of a bookmark row (or its own icon again)
fn apply(row: &gtk::Widget, wanted: Option<&str>) {
    let current: Option<gio::Icon> = row.property("start-icon");
    match wanted.filter(|name| has_icon(row, name)) {
        Some(name) => {
            if icon_name(current.clone()).as_deref() == Some(name) {
                return;
            }
            if unsafe { row.data::<Option<gio::Icon>>(NATIVE) }.is_none() {
                unsafe { row.set_data(NATIVE, current) };
            }
            row.set_property("start-icon", gio::ThemedIcon::new(name).upcast::<gio::Icon>());
        }
        None => {
            if let Some(native) = unsafe { row.steal_data::<Option<gio::Icon>>(NATIVE) } {
                row.set_property("start-icon", native);
            }
        }
    }
}

fn watch(row: &gtk::Widget) {
    if unsafe { row.data::<bool>(WATCHED) }.is_some() {
        return;
    }
    unsafe { row.set_data(WATCHED, true) };
    // Nautilus may set the icon again without rebuilding the sidebar
    row.connect_notify_local(Some("start-icon"), |row, _| {
        let Some(uri) = row_uri(row) else { return };
        if let Some(name) = custom_icons().get(key(&uri)) {
            apply(row, Some(name));
        }
    });
}

fn refresh(list: &gtk::ListBox) {
    let marked = bookmarks();
    let icons = custom_icons();
    let mut i = 0;
    while let Some(row) = list.row_at_index(i) {
        i += 1;
        let row = row.upcast::<gtk::Widget>();
        let Some(uri) = row_uri(&row) else { continue };
        if !marked.contains(key(&uri)) {
            continue;
        }
        watch(&row);
        apply(&row, icons.get(key(&uri)).map(String::as_str));
    }
}

fn refresh_all() {
    let lists: Vec<gtk::ListBox> = LISTS.with(|l| {
        let mut l = l.borrow_mut();
        l.retain(|w| w.upgrade().is_some());
        l.iter().filter_map(|w| w.upgrade()).collect()
    });
    for list in lists {
        refresh(&list);
    }
}

fn sidebar_list(win: &gtk::Window) -> Option<(gtk::Widget, gtk::ListBox)> {
    let sidebar = walk(win).into_iter().find(|w| type_name(w) == "NautilusSidebar")?;
    let list = walk(&sidebar).into_iter().filter_map(|w| w.downcast::<gtk::ListBox>().ok())
        .find(|l| l.has_css_class("navigation-sidebar"))?;
    Some((sidebar, list))
}

fn follow(list: &gtk::ListBox) {
    let pending = std::rc::Rc::new(Cell::new(false));
    let weak = list.downgrade();
    let children = list.observe_children();
    children.connect_items_changed(move |_, _, _, _| {
        if pending.replace(true) {
            return;
        }
        let (pending, weak) = (pending.clone(), weak.clone());
        glib::idle_add_local_once(move || {
            pending.set(false);
            if let Some(list) = weak.upgrade() {
                guard("bookmark icons", (), || refresh(&list));
            }
        });
    });
    unsafe { list.set_data(OBSERVER, children) };
    LISTS.with(|l| l.borrow_mut().push(list.downgrade()));
    refresh(list);
}

// ---------- context menu

fn bookmark_row_at(win: &gtk::Window, event: &gtk::gdk::Event) -> Option<gtk::Widget> {
    let start = match event.event_type() {
        gtk::gdk::EventType::ButtonPress | gtk::gdk::EventType::ButtonRelease => {
            let (x, y) = event.position()?;
            let (dx, dy) = win.surface_transform();
            win.pick(x - dx, y - dy, gtk::PickFlags::DEFAULT)?
        }
        _ => gtk::prelude::GtkWindowExt::focus(win)?,
    };
    let row = std::iter::successors(Some(start), |w| w.parent())
        .find(|w| w.is::<gtk::ListBoxRow>() && row_uri(w).is_some())?;
    bookmarks().contains(key(&row_uri(&row)?)).then_some(row)
}

fn opens_menu(event: &gtk::gdk::Event) -> bool {
    use gtk::gdk::{EventType, Key, ModifierType};
    match event.event_type() {
        // the sidebar opens its row menu on release
        EventType::ButtonRelease => event.downcast_ref::<gtk::gdk::ButtonEvent>()
            .is_some_and(|b| b.button() == gtk::gdk::BUTTON_SECONDARY),
        EventType::KeyPress => event.downcast_ref::<gtk::gdk::KeyEvent>().is_some_and(|k| {
            k.keyval() == Key::Menu
                || (k.keyval() == Key::F10 && k.modifier_state().contains(ModifierType::SHIFT_MASK))
        }),
        _ => false,
    }
}

fn rename_section(model: &gio::MenuModel) -> Option<gio::Menu> {
    (0..model.n_items()).filter_map(|i| model.item_link(i, gio::MENU_LINK_SECTION)).find(|section| {
        (0..section.n_items()).any(|j| {
            section.item_attribute_value(j, gio::MENU_ATTRIBUTE_ACTION, Some(glib::VariantTy::STRING))
                .is_some_and(|v| v.str() == Some("row.rename"))
        })
    })?.downcast().ok()
}

fn patch_menu(sidebar: &gtk::Widget, row: &gtk::Widget) {
    for w in walk(sidebar) {
        let Some(pop) = w.downcast_ref::<gtk::PopoverMenu>() else { continue };
        if !pop.is_mapped() || unsafe { pop.data::<bool>(PATCHED) }.is_some() {
            continue;
        }
        unsafe { pop.set_data(PATCHED, true) };
        let Some(section) = pop.menu_model().as_ref().and_then(rename_section) else { continue };
        section.append(Some(&tr("Change Icon…")), Some(&format!("{GROUP}.change-icon")));
        let group = gio::SimpleActionGroup::new();
        let action = gio::SimpleAction::new("change-icon", None);
        let weak = row.downgrade();
        action.connect_activate(move |_, _| {
            if let Some(row) = weak.upgrade() {
                guard("icon picker", (), || picker(&row));
            }
        });
        group.add_action(&action);
        pop.insert_action_group(GROUP, Some(&group));
    }
}

pub fn attach(win: &gtk::Window) {
    if type_name(win) != "NautilusWindow" || unsafe { win.data::<bool>(ATTACHED) }.is_some() {
        return;
    }
    if settings().is_none() {
        log!("bookmark icons: schema {SCHEMA} not installed");
        return;
    }
    unsafe { win.set_data(ATTACHED, true) };

    let tries = std::rc::Rc::new(Cell::new(0u32));
    let weak = win.downgrade();
    glib::timeout_add_local(Duration::from_millis(250), move || {
        let Some(win) = weak.upgrade() else { return glib::ControlFlow::Break };
        if let Some((_, list)) = sidebar_list(&win) {
            guard("bookmark icons", (), || follow(&list));
            return glib::ControlFlow::Break;
        }
        tries.set(tries.get() + 1);
        if tries.get() >= 40 {
            log!("bookmark icons: sidebar not found");
            return glib::ControlFlow::Break;
        }
        glib::ControlFlow::Continue
    });

    let legacy = gtk::EventControllerLegacy::new();
    legacy.set_propagation_phase(gtk::PropagationPhase::Capture);
    let weak = win.downgrade();
    legacy.connect_event(move |_, event| {
        let Some(win) = weak.upgrade() else { return glib::Propagation::Proceed };
        if opens_menu(event) {
            let row = bookmark_row_at(&win, event);
            unsafe { win.set_data(LAST_ROW, row.map(|r| r.downgrade())) };
            let weak = win.downgrade();
            glib::idle_add_local_full(glib::Priority::HIGH_IDLE, move || {
                if let Some(win) = weak.upgrade() {
                    guard("bookmark menu", (), || {
                        let row = unsafe { win.data::<Option<glib::WeakRef<gtk::Widget>>>(LAST_ROW) }
                            .and_then(|r| unsafe { r.as_ref() }.as_ref()?.upgrade());
                        if let (Some(row), Some((sidebar, _))) = (row, sidebar_list(&win)) {
                            patch_menu(&sidebar, &row);
                        }
                    });
                }
                glib::ControlFlow::Break
            });
        }
        glib::Propagation::Proceed
    });
    win.add_controller(legacy);
}

// ---------- icon picker

fn symbolic_icons(row: &gtk::Widget) -> gtk::StringList {
    let mut names: Vec<String> = gtk::IconTheme::for_display(&row.display()).icon_names().into_iter()
        .map(|n| n.to_string())
        .filter(|n| n.ends_with("-symbolic"))
        .collect();
    names.sort();
    names.dedup();
    let names: Vec<&str> = names.iter().map(String::as_str).collect();
    gtk::StringList::new(&names)
}

fn picker(row: &gtk::Widget) {
    let Some(uri) = row_uri(row) else { return };
    let current = custom_icons().get(key(&uri)).cloned();

    let pop = gtk::Popover::new();
    pop.set_parent(row);
    pop.set_position(gtk::PositionType::Right);
    pop.connect_closed(|p| p.unparent());

    let content = gtk::Box::new(gtk::Orientation::Vertical, 8);
    content.set_margin_top(10);
    content.set_margin_bottom(10);
    content.set_margin_start(10);
    content.set_margin_end(10);

    let title = gtk::Label::new(Some(&tr("Icon")));
    title.add_css_class("heading");
    title.set_xalign(0.0);
    content.append(&title);

    let search = gtk::SearchEntry::new();
    search.set_placeholder_text(Some(&tr("Search icons…")));
    content.append(&search);

    let names = symbolic_icons(row);
    let filter = gtk::StringFilter::new(Some(gtk::PropertyExpression::new(
        gtk::StringObject::static_type(), None::<gtk::Expression>, "string")));
    filter.set_match_mode(gtk::StringFilterMatchMode::Substring);
    filter.set_ignore_case(true);
    let filtered = gtk::FilterListModel::new(Some(names.clone()), Some(filter.clone()));
    let selection = gtk::SingleSelection::new(Some(filtered.clone()));
    selection.set_autoselect(false);
    selection.set_can_unselect(true);
    selection.set_selected(gtk::INVALID_LIST_POSITION);
    if let Some(cur) = &current {
        if let Some(pos) = (0..names.n_items()).find(|&i| names.string(i).as_deref() == Some(cur.as_str())) {
            selection.set_selected(pos);
        }
    }

    let factory = gtk::SignalListItemFactory::new();
    factory.connect_setup(|_, item| {
        let item = item.downcast_ref::<gtk::ListItem>().expect("list item");
        let image = gtk::Image::new();
        image.set_size_request(CELL, CELL);
        item.set_child(Some(&image));
    });
    factory.connect_bind(|_, item| {
        let item = item.downcast_ref::<gtk::ListItem>().expect("list item");
        let (Some(image), Some(name)) = (
            item.child().and_downcast::<gtk::Image>(),
            item.item().and_downcast::<gtk::StringObject>(),
        ) else { return };
        image.set_icon_name(Some(&name.string()));
        image.set_tooltip_text(Some(&name.string()));
    });

    let grid = gtk::GridView::new(Some(selection.clone()), Some(factory));
    grid.set_min_columns(COLUMNS);
    grid.set_max_columns(COLUMNS);
    grid.set_single_click_activate(true);

    let scroll = gtk::ScrolledWindow::new();
    scroll.set_policy(gtk::PolicyType::Never, gtk::PolicyType::Automatic);
    scroll.set_size_request(COLUMNS as i32 * (CELL + 8), 5 * (CELL + 8));
    scroll.set_child(Some(&grid));
    content.append(&scroll);

    let reset = gtk::Button::with_label(&tr("Reset"));
    reset.set_sensitive(current.is_some());
    content.append(&reset);

    {
        let (uri, row, reset) = (uri.clone(), row.downgrade(), reset.downgrade());
        grid.connect_activate(move |grid, pos| {
            let Some(name) = grid.model().and_then(|m| m.item(pos)).and_downcast::<gtk::StringObject>() else {
                return;
            };
            store(&uri, Some(&name.string()));
            if let Some(row) = row.upgrade() {
                apply(&row, Some(&name.string()));
            }
            if let Some(reset) = reset.upgrade() {
                reset.set_sensitive(true);
            }
        });
    }
    {
        let (row, selection) = (row.downgrade(), selection.clone());
        reset.connect_clicked(move |button| {
            store(&uri, None);
            if let Some(row) = row.upgrade() {
                apply(&row, None);
            }
            selection.set_selected(gtk::INVALID_LIST_POSITION);
            button.set_sensitive(false);
        });
    }
    search.connect_search_changed(move |entry| filter.set_search(Some(&entry.text())));
    {
        let pop = pop.downgrade();
        search.connect_stop_search(move |_| {
            if let Some(pop) = pop.upgrade() {
                pop.popdown();
            }
        });
    }

    pop.set_child(Some(&content));
    pop.popup();
    search.grab_focus();
}
