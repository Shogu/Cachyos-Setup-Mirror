# Mémoire / Règles OpenCode

Ce fichier est la **mémoire persistante** d'OpenCode. Il est relu à chaque
nouvelle session. Tout ce qui doit être retenu durablement doit y être noté.

## 1. Image dans le prompt ⇒ sous-agent Vision **Nemotron** (gratuit)
Dès qu'une tâche implique de **lire / interpréter / vérifier / identifier une
image** (capture d'écran, screenshot, image, photo, document scanné), et que le
modèle principal n'a pas de vision (ex. DeepSeek V4 Flash) :
1. Ne pas deviner ni ouvrir l'image soi-même.
2. Lancer un sous-agent `general` avec le modèle vision gratuit :
   `opencode/nemotron-3.5-super-vl-free`
   ⚠️ ID correct **sans préfixe doublé** (ne pas écrire `opencode/opencode/…`
   ni `openrouter/…`, ils ne sont pas sélectionnables comme sous-agent).
3. Prompt : demander d'**ouvrir chaque fichier image avec l'outil de lecture
   (read)** et de décrire précisément son contenu.

Méthodo éprouvée :
- Fournir les **chemins absolus** des images au sous-agent.
- **Traiter par petits lots (≈ 4 à 6 max)** : l'endpoint free est instable et
  timeout sur les gros lots.
- En cas d'`Endpoint is unavailable` / `Upstream request failed` → **réessayer**
  (souvent transitoire), éventuellement en réduisant le lot.
- Pour classifier en série (« en action vs interface vide ») : demander, pour
  chaque image, l'appli vue + la présence de contenu réel, en tableau.

Alternative payante (sur accord de l'utilisateur uniquement) :
`openrouter/nvidia/nemotron-3.5-super-vl` (plus stable).

## 2. Aucune installation sans accord préalable
**Ne jamais installer de paquet système (pacman), de dépendance Python
(pip/venv), ni aucun outil/binaire** sans l'accord explicite de l'utilisateur.

## 3. Règles de design GNOME / Adwaita (GTK4 / Libadwaita)
- **Contraintes Adwaita** : forme géométrique 3D douce, éclairage par le haut,
  perspective axonométrique ou vue frontale directe, zoom extrême sur un
  objet/détail, zéro scène contextuelle, aucun fond de type carte/feuille
  blanche derrière.
- **Nommage** : clarté + français direct (ex. Fichiers, Disques, Cartes) ou
  métaphores courtes et élégantes (ex. Loupe, Fragments).
- **Design moderne GNOME = libadwaita + GTK4**, suivant les Human Interface
  Guidelines :
  - *Adaptabilité & Responsivité* : passage fluide de la taille d'ordinateur à
    celle d'un smartphone (mouvements fluides, vues rétractables, volets
    latéraux pliables).
  - *Sobriété & clarté* : interface épurée, pas de barres de menus
    traditionnelles (File, Edit…) au profit des **Header Bars** intégrées qui
    concentrent navigation et actions principales.
  - *Uniformité visuelle* : widgets standardisés (onglets arrondis, cartes
    d'options, dialogues modaux attachés), typographie unifiée (**Adwaita Sans**
    et **Adwaita Mono**).
  - *Thèmes sombres & accentuation* : bascule fluide clair/sombre, personnalisation
    des teintes système.

## 4. Organisation du dépôt et des projets
- **Dépôt GitLab local** : `/home/ogu/Gitlab` (contient `CACHYOS-Setup`).
- **Ne jamais créer de dépôt pacman local.**
- **Règle de travail sur les paquets/sources** : dès qu'on travaille sur un
  paquet du repo ou sur des sources, **dupliquer d'abord les fichiers dans
  `/home/ogu/Projets`** et travailler sur la copie — **ne pas modifier
  directement** les fichiers du dépôt GitLab local.

## 5. Mémorisation définitive
Quand l'utilisateur dit « **mémorise définitivement** » (ou « mémorise » /
« retiens ça pour de bon »), cela signifie : **ajouter la consigne/le fait dans
ce fichier `AGENTS.md`** (en règle numérotée ou en note), afin qu'il soit
persisté pour toutes les sessions futures. Si l'utilisateur demande une
validation préalable, présenter d'abord le brouillon et n'écrire qu'après son
accord.

L'utilisateur peut ajouter des choses à retenir à tout moment, au fil de la
conversation ; il suffit de le dire (ou de le demander explicitement).

## 6. Tâche en attente — Backup OpenCode + config Copilot (à faire plus tard)
Quand l'utilisateur disposera de l'accès **GitHub Copilot** (abonnement prof,
activation 72 h après acceptation du dossier) :
1. **Configurer OpenCode avec Copilot** via `/connect` → « GitHub Copilot » →
   « Login with GitHub Copilot » (OAuth appareil, pas de clé manuelle).
2. **Mettre à jour le dossier de config OpenCode dans le repo CACHYOS-Setup** :
   `Ressources/Logiciels/Opencode/` (recopier opencode.json une fois Copilot
   configuré, actualiser README.md si besoin). Ce dossier sert de backup/sauvegarde.
3. **Faire le backup complet OpenCode** sous forme d'un **zip normal**
   (opencode.json, cli.json, AGENTS.md, command/, README-RESTAURATION.md) →
   **sans clés API / infos privées** (exclure secrets/, service.json, opencode.db).
4. Créer **un second zip ENCRYPTÉ par mot de passe** contenant les clés API
   (albert.key, gemini.key, groq.key, cloudflare.key, openrouter.key) et les
   mots de passe.
   → Le zip crypté ira sur la **Dropbox** de l'utilisateur (PAS sur GitLab).
   → Le **mot de passe du zip est demandé à l'utilisateur au moment voulu**
   (NE PAS le stocker en clair ici), puis l'effacer aussitôt le zip créé.

Atteinte : le zip actuel a été supprimé sur demande ; on repartira de zéro,
config Copilot active, quand l'utilisateur donnera le feu vert. Le dossier de
config OpenCode a été déplacé de `Ressources/Configs/opencode/` vers
`Ressources/Logiciels/Opencode/` le 15/11/2026.

### Nettoyage du sous-dossier après l'étape maj + zip (quand Copilot actif)
Une fois la mise à jour et le zip faits, **supprimer dans
`Ressources/Logiciels/Opencode/` les fichiers devenus redondants, trop vieux
ou inutiles**. État actuel (créés le 02/11/2026) :
`plugins/`, `.gitignore`, `albert.key.example`, `opencode.json`, `README.md`,
`restore.sh`.
→ Ne conserver que ce qui reste utile (ex. opencode.json + restore.sh +
README + éventuels plugins). À valider par l'utilisateur avant suppression.
