---
description: Transcrit un fichier/dossier audio via l'API Groq Whisper (cloud)
argument: path (fichier audio ou dossier à transcrire)
---
# Transcription audio — Groq Whisper (cloud)

Transcrit un fichier audio (mp3, aac, m4a, ogg, flac, wav) ou un dossier entier avec l'API **Groq Whisper** (`whisper-large-v3`). Cloud, gratuit, excellent en français.

**Prérequis :**
- Clé API Groq lue dans `~/.config/opencode/secrets/groq.key` (déjà stockée). Si absente : `$(cat ~/.config/opencode/secrets/groq.key)` vide → rappeler à l'utilisateur de mettre sa clé (https://console.groq.com/keys).
- `ffmpeg` installé (utilisé pour découper les gros fichiers).
- `jq` installé (parsage de la réponse).

## Endpoint
```
POST https://api.groq.com/openai/v1/audio/transcriptions
```

## Procédure par fichier

### 1. Découper si le fichier dépasse 25 Mo
Groq limite chaque upload à **25 Mo**. Si le fichier dépasse (~25 Mo en MP3 128k ≈ 10 min) :
```
mkdir -p chunk_dir
ffmpeg -y -i "<input>" -f segment -segment_time 600 -c copy "chunk_dir/chunk_%03d.mp3"
```
Puis transcrire chaque morceau, et concaténer les résultats dans l'ordre.

### 2. Envoyer à l'API
```
curl -s https://api.groq.com/openai/v1/audio/transcriptions \
  -H "Authorization: Bearer $(cat ~/.config/opencode/secrets/groq.key)" \
  -F file=@"<input>" \
  -F model="whisper-large-v3" \
  -F language="fr" \
  -F response_format="verbose_json" \
  | jq -r '.segments[] | "[" + (.start|tostring) + "s] " + .text' > "<output>.txt"
```

### 3. Sortie
- Écrire le résultat dans `<nom_original>.txt` (même dossier que l'entrée).
- Format avec timestamps : `[Xs] texte` (une ligne par segment).
- Supprimer `chunk_dir/` après traitement si découpage fait.

## Règles
- Si l'argument est un **dossier**, traiter tous les fichiers audio (`.mp3 .aac .m4a .ogg .flac .wav`) en batch, chacun dans son `<nom>.txt`.
- Limite gratuite Groq : ~28 800 s d'audio/jour (~8 h), ok pour quelques dizaines de minutes/semaine.
- Vérifier la réussite de l'appel (code HTTP) avant d'accepter le texte.
