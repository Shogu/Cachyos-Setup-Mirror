---
description: Remaster audio -> MP4 avec sauts de 10s propres (ffmpeg)
argument: path (fichier audio ou dossier à traiter)
---
# Remaster audio -> MP4

Traite un fichier audio (mp3, aac, m4a, ogg, flac, wav) ou un dossier entier, via ce pipeline en 3 étapes.

**Prérequis :** `ffmpeg` doit être installé (`ffmpeg -version`).

## Pipeline (par fichier)

### ÉTAPE 1 — Remaster audio (en FLAC lossless, pas de double compression)
```
ffmpeg -y -i "<input>" \
  -af "highpass=f=80,lowpass=f=12000,compand=attacks=0.02:decays=0.3:points=-80/-80|-45/-25|-27/-15|0/-5:gain=3,loudnorm=I=-14:TP=-1:LRA=11" \
  -c:a flac "temp_remastered.flac"
```

### ÉTAPE 2 — Supprimer le silence de fin
Détecter le dernier silence :
```
ffmpeg -i "temp_remastered.flac" -af "silencedetect=n=-50dB:d=2" -f null -
```
Lire la dernière ligne `silence_start: X` dans la sortie (sur stderr). Puis tronquer :
```
ffmpeg -y -i "temp_remastered.flac" -t "<X>" -c:a copy "temp_trimmed.flac"
```
Si aucun silence n'est détecté, garder le fichier remasteré tel quel.

### ÉTAPE 3 — Emballer en MP4 (sauts de 10s instantanés)
```
ffmpeg -y -i "temp_trimmed.flac" -vn \
  -c:a aac -b:a 192k -ar 44100 \
  -movflags +faststart "<nom>_remastered.mp4"
```
`-movflags +faststart` place le `moov` atom au début : c'est ce qui rend les sauts (seek) instantanés dans tout lecteur.

## Règles
- Nom de sortie : `<nom_original>_remastered.mp4` (même dossier que l'entrée).
- Supprimer les fichiers temporaires (`temp_remastered.flac`, `temp_trimmed.flac`) après chaque fichier.
- Si l'argument est un **dossier**, traiter tous les fichiers audio (`.mp3 .aac .m4a .ogg .flac .wav`) en batch.
- Traiter le fichier/flux un à un, en vérifiant la réussite de chaque étape avant la suivante.
