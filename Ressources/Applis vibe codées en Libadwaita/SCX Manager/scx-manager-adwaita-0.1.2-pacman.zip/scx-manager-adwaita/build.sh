#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
build_dir="$project_dir/build"

if [[ -d "$build_dir" ]]; then
    meson setup "$build_dir" --reconfigure
else
    meson setup "$build_dir"
fi

meson compile -C "$build_dir"
printf 'Binaire : %s\n' "$build_dir/scx-manager-adwaita"
