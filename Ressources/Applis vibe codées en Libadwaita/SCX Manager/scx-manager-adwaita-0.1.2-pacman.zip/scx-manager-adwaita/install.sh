#!/usr/bin/env bash
set -euo pipefail

# Outils nécessaires uniquement pour compiler cette application.
# Ils peuvent être retirés après l'installation si aucun autre projet ne les
# utilise : meson ninja pkgconf.
BUILD_ONLY_PACKAGES=(
    meson
    ninja
    pkgconf
)

# base-devel fournit le compilateur et la chaîne de compilation Arch/CachyOS.
# C'est aussi le groupe habituellement utilisé pour compiler des paquets AUR.
TOOLCHAIN_GROUP=(base-devel)

# Ces bibliothèques sont nécessaires à la compilation ET à l'exécution : ne pas
# les désinstaller tant que SCX Manager est utilisé.
GUI_PACKAGES=(gtk4 libadwaita)

# Dépendances d'exécution attendues, volontairement non installées ni modifiées
# par ce script.
RUNTIME_PACKAGES=(scx-tools scx-scheds)

project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
build_dir="$project_dir/build"
install_prefix="${PREFIX:-$HOME/.local}"

printf 'Outils de compilation temporaires : %s\n' "${BUILD_ONLY_PACKAGES[*]}"
printf 'Chaîne de compilation générale : %s\n' "${TOOLCHAIN_GROUP[*]}"
printf 'Bibliothèques nécessaires à l’exécution : %s\n' "${GUI_PACKAGES[*]}"
printf 'Dépendances SCX conservées séparément : %s\n' "${RUNTIME_PACKAGES[*]}"

# Sur Arch/CachyOS, installer uniquement les paquets de compilation manquants.
# Définir SKIP_BUILD_DEPS=1 pour ignorer cette étape si les dépendances sont déjà
# fournies par un autre moyen.
if [[ "${SKIP_BUILD_DEPS:-0}" != "1" ]] && command -v pacman >/dev/null 2>&1; then
    pacman_packages=(
        "${TOOLCHAIN_GROUP[@]}"
        "${BUILD_ONLY_PACKAGES[@]}"
        "${GUI_PACKAGES[@]}"
    )

    if (( EUID == 0 )); then
        pacman -S --needed "${pacman_packages[@]}"
    elif command -v sudo >/dev/null 2>&1; then
        sudo pacman -S --needed "${pacman_packages[@]}"
    else
        printf 'Erreur : sudo est nécessaire pour installer les dépendances de compilation.\n' >&2
        exit 1
    fi
fi

required_commands=(meson ninja cc pkg-config)
for command_name in "${required_commands[@]}"; do
    if ! command -v "$command_name" >/dev/null 2>&1; then
        printf 'Erreur : commande requise absente : %s\n' "$command_name" >&2
        printf 'Installez les paquets suivants puis relancez le script : %s %s\n' \
            "${TOOLCHAIN_GROUP[*]}" "${BUILD_ONLY_PACKAGES[*]}" >&2
        exit 1
    fi
done

if ! pkg-config --exists gtk4 libadwaita-1; then
    printf 'Erreur : GTK4 et/ou libadwaita sont introuvables via pkg-config.\n' >&2
    printf 'Paquets nécessaires : gtk4 libadwaita pkgconf\n' >&2
    exit 1
fi

meson setup "$build_dir" --prefix="$install_prefix" --wipe
meson compile -C "$build_dir"
meson install -C "$build_dir"

if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$install_prefix/share/applications" >/dev/null 2>&1 || true
fi

printf 'SCX Manager installé dans %s\n' "$install_prefix"
printf 'Binaire : %s/bin/scx-manager-adwaita\n' "$install_prefix"
printf 'Après vérification, les outils de compilation retirables sont : %s\n' "${BUILD_ONLY_PACKAGES[*]}"
printf 'Ne désinstallez pas gtk4/libadwaita : elles sont nécessaires à l’application.\n'
