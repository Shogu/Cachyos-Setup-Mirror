#!/usr/bin/env bash
set -euo pipefail

# Ce script retire uniquement les fichiers installés par SCX Manager.
# Il ne supprime ni scx-tools, ni scx-scheds, ni les paquets de compilation.
# Outils de compilation utilisés par install.sh : meson ninja pkgconf.
# base-devel est la chaîne de compilation générale d'Arch/CachyOS.
# gtk4 et libadwaita sont nécessaires à l'exécution et doivent être conservés.

install_prefix="${PREFIX:-$HOME/.local}"

installed_files=(
    "$install_prefix/bin/scx-manager-adwaita"
    "$install_prefix/share/applications/org.cachyos.scx-manager-adwaita.desktop"
    "$install_prefix/share/icons/hicolor/scalable/apps/org.cachyos.scx-manager-adwaita.svg"
    "$install_prefix/share/icons/hicolor/scalable/status/org.cachyos.scx-manager-adwaita-active-symbolic.svg"
)

removed=0
for file in "${installed_files[@]}"; do
    if [[ -e "$file" || -L "$file" ]]; then
        rm -f -- "$file"
        printf 'Supprimé : %s\n' "$file"
        removed=$((removed + 1))
    fi
done

if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$install_prefix/share/applications" >/dev/null 2>&1 || true
fi

if (( removed == 0 )); then
    printf 'Aucun fichier installé de SCX Manager trouvé dans %s\n' "$install_prefix"
else
    printf 'SCX Manager désinstallé de %s\n' "$install_prefix"
fi

printf 'Les paquets système et les dépendances de compilation n’ont pas été modifiés.\n'
