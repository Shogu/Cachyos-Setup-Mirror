#!/bin/sh
exec python3 /usr/lib/carrousel/main.py "$@"
