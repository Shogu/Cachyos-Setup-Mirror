from gi.repository import Adw, Gio, GObject, Gtk, WebKit

from carrousel import APP_NAME
from carrousel.browser import DownloadManager, PhotosView, downloads_dir, open_in_browser
from carrousel.sections import HOME, SECTIONS, search_uri, section_index_for

ZOOM_STEP = 0.1
ZOOM_MIN = 0.5
ZOOM_MAX = 2.0
MOUSE_BACK = 8
MOUSE_FORWARD = 9


def section_row(section):
    row = Gtk.ListBoxRow()
    box = Gtk.Box(spacing=12)
    box.append(Gtk.Image.new_from_icon_name(section.icon_name))
    box.append(Gtk.Label(label=section.title, xalign=0))
    row.set_child(box)
    return row


class CarrouselWindow(Adw.ApplicationWindow):
    def __init__(self, application, network_session, settings):
        super().__init__(application=application, title=APP_NAME)
        self._settings = settings
        self._network_session = network_session

        settings.bind("window-width", self, "default-width", Gio.SettingsBindFlags.DEFAULT)
        settings.bind("window-height", self, "default-height", Gio.SettingsBindFlags.DEFAULT)
        settings.bind("window-maximized", self, "maximized", Gio.SettingsBindFlags.DEFAULT)

        self._toasts = Adw.ToastOverlay()
        self._view = PhotosView(network_session)
        self._view.set_zoom_level(settings.get_double("zoom-level"))
        self._view.set_hide_google_menu(settings.get_boolean("hide-google-menu"))
        self._settings_handler = settings.connect("changed::hide-google-menu", self._on_hide_menu_changed)
        self._downloads = DownloadManager(network_session, self._show_toast)

        self._split = Adw.OverlaySplitView(sidebar=self._build_sidebar(), content=self._build_content())
        self._split.bind_property(
            "show-sidebar", self._sidebar_button, "active", GObject.BindingFlags.BIDIRECTIONAL | GObject.BindingFlags.SYNC_CREATE
        )

        breakpoint = Adw.Breakpoint.new(Adw.BreakpointCondition.parse("max-width: 640sp"))
        breakpoint.add_setter(self._split, "collapsed", True)
        self.add_breakpoint(breakpoint)
        self.set_size_request(360, 400)
        self.set_content(self._split)

        self._view_handlers = [
            self._view.connect("notify::uri", self._on_uri_changed),
            self._view.connect("notify::title", self._on_title_changed),
            self._view.connect("notify::estimated-load-progress", self._on_progress),
            self._view.connect("notify::is-loading", self._on_progress),
            self._view.connect("load-changed", self._on_load_changed),
        ]
        self._install_actions()
        mouse_buttons = Gtk.GestureClick(button=0, propagation_phase=Gtk.PropagationPhase.CAPTURE)
        mouse_buttons.connect("pressed", self._on_mouse_button)
        self.add_controller(mouse_buttons)
        self.connect("close-request", self._on_close_request)
        self._view.load_uri(HOME.uri)

    def _build_sidebar(self):
        self._sidebar_list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE)
        self._sidebar_list.add_css_class("navigation-sidebar")
        for section in SECTIONS:
            self._sidebar_list.append(section_row(section))
        self._sidebar_list.connect("row-activated", self._on_section_activated)

        header = Adw.HeaderBar(show_title=True)
        header.set_title_widget(Adw.WindowTitle(title=APP_NAME))

        toolbar = Adw.ToolbarView()
        toolbar.add_top_bar(header)
        toolbar.set_content(Gtk.ScrolledWindow(child=self._sidebar_list, hscrollbar_policy=Gtk.PolicyType.NEVER))
        return toolbar

    def _build_content(self):
        self._sidebar_button = Gtk.ToggleButton(icon_name="sidebar-show-symbolic", tooltip_text="Barre latérale (F9)")
        sidebar_button = self._sidebar_button

        back = Gtk.Button(icon_name="go-previous-symbolic", tooltip_text="Précédent", action_name="win.back")
        forward = Gtk.Button(icon_name="go-next-symbolic", tooltip_text="Suivant", action_name="win.forward")
        reload_button = Gtk.Button(icon_name="view-refresh-symbolic", tooltip_text="Recharger", action_name="win.reload")

        self._search = Gtk.SearchEntry(placeholder_text="Rechercher dans vos photos", hexpand=True)
        self._search.connect("activate", self._on_search_activate)

        menu = Gio.Menu()
        page_section = Gio.Menu()
        page_section.append("Ouvrir dans le navigateur", "win.open-in-browser")
        page_section.append("Ouvrir le dossier Images", "win.open-downloads")
        menu.append_section(None, page_section)
        page_section.append("Masquer le menu de Google", "win.hide-google-menu")
        zoom_section = Gio.Menu()
        zoom_section.append("Zoom avant", "win.zoom-in")
        zoom_section.append("Zoom arrière", "win.zoom-out")
        zoom_section.append("Taille normale", "win.zoom-reset")
        menu.append_section(None, zoom_section)
        account_section = Gio.Menu()
        account_section.append("Se déconnecter…", "win.sign-out")
        account_section.append("À propos de Carrousel", "app.about")
        menu.append_section(None, account_section)
        menu_button = Gtk.MenuButton(icon_name="open-menu-symbolic", menu_model=menu, tooltip_text="Menu principal", primary=True)

        header = Adw.HeaderBar()
        header.pack_start(sidebar_button)
        header.pack_start(back)
        header.pack_start(forward)
        header.pack_end(menu_button)
        header.pack_end(reload_button)
        header.set_title_widget(Adw.Clamp(maximum_size=480, child=self._search))

        self._progress = Gtk.ProgressBar(valign=Gtk.Align.START, visible=False, can_target=False)
        self._progress.add_css_class("osd")
        overlay = Gtk.Overlay(child=self._view)
        overlay.add_overlay(self._progress)
        self._toasts.set_child(overlay)

        toolbar = Adw.ToolbarView()
        toolbar.add_top_bar(header)
        toolbar.set_content(self._toasts)
        return toolbar

    def _install_actions(self):
        entries = (
            ("back", lambda *_: self._view.go_back()),
            ("forward", lambda *_: self._view.go_forward()),
            ("reload", lambda *_: self._view.reload()),
            ("home", lambda *_: self._view.load_uri(HOME.uri)),
            ("focus-search", lambda *_: self._search.grab_focus()),
            ("toggle-sidebar", lambda *_: self._split.set_show_sidebar(not self._split.get_show_sidebar())),
            ("open-in-browser", lambda *_: open_in_browser(self._view.get_uri() or HOME.uri, self)),
            ("open-downloads", self._on_open_downloads),
            ("zoom-in", lambda *_: self._set_zoom(self._view.get_zoom_level() + ZOOM_STEP)),
            ("zoom-out", lambda *_: self._set_zoom(self._view.get_zoom_level() - ZOOM_STEP)),
            ("zoom-reset", lambda *_: self._set_zoom(1.0)),
            ("sign-out", self._on_sign_out),
        )
        self._actions = {}
        for name, callback in entries:
            action = Gio.SimpleAction.new(name, None)
            action.connect("activate", callback)
            self.add_action(action)
            self._actions[name] = action
        self.add_action(self._settings.create_action("hide-google-menu"))
        self._update_navigation_actions()

    def _update_navigation_actions(self):
        self._actions["back"].set_enabled(self._view.can_go_back())
        self._actions["forward"].set_enabled(self._view.can_go_forward())

    def _set_zoom(self, level):
        level = round(min(ZOOM_MAX, max(ZOOM_MIN, level)), 2)
        self._view.set_zoom_level(level)
        self._settings.set_double("zoom-level", level)

    def _show_toast(self, message, file):
        toast = Adw.Toast(title=message, timeout=4)
        if file is not None:
            toast.set_button_label("Ouvrir")
            toast.connect("button-clicked", lambda _toast: Gtk.FileLauncher.new(file).launch(self, None, None, None))
        self._toasts.add_toast(toast)

    def _on_section_activated(self, _list, row):
        self._view.load_uri(SECTIONS[row.get_index()].uri)
        if self._split.get_collapsed():
            self._split.set_show_sidebar(False)

    def _on_search_activate(self, entry):
        text = entry.get_text().strip()
        if text:
            self._view.load_uri(search_uri(text))
            self._view.grab_focus()

    def _on_uri_changed(self, view, _pspec):
        self._update_navigation_actions()
        index = section_index_for(view.get_uri() or "")
        if index is None:
            self._sidebar_list.unselect_all()
        else:
            self._sidebar_list.select_row(self._sidebar_list.get_row_at_index(index))

    def _on_title_changed(self, view, _pspec):
        title = view.get_title()
        self.set_title(f"{title} – {APP_NAME}" if title else APP_NAME)

    def _on_progress(self, view, _pspec):
        loading = view.is_loading()
        self._progress.set_visible(loading)
        if loading:
            self._progress.set_fraction(view.get_estimated_load_progress())

    def _on_load_changed(self, _view, _event):
        self._update_navigation_actions()

    def _on_hide_menu_changed(self, settings, key):
        self._view.set_hide_google_menu(settings.get_boolean(key))
        self._view.reload()

    def _on_mouse_button(self, gesture, _n_press, _x, _y):
        button = gesture.get_current_button()
        if button == MOUSE_BACK:
            self._view.go_back()
        elif button == MOUSE_FORWARD:
            self._view.go_forward()
        else:
            return
        gesture.set_state(Gtk.EventSequenceState.CLAIMED)

    def _on_open_downloads(self, *_args):
        Gtk.FileLauncher.new(Gio.File.new_for_path(str(downloads_dir()))).launch(self, None, None, None)

    def _on_sign_out(self, *_args):
        dialog = Adw.AlertDialog(
            heading="Se déconnecter ?",
            body="Les cookies et toutes les données de Google Photos enregistrées par Carrousel seront effacés.",
        )
        dialog.add_response("cancel", "Annuler")
        dialog.add_response("sign-out", "Se déconnecter")
        dialog.set_response_appearance("sign-out", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.set_default_response("cancel")
        dialog.set_close_response("cancel")
        dialog.connect("response", self._on_sign_out_response)
        dialog.present(self)

    def _on_sign_out_response(self, _dialog, response):
        if response != "sign-out":
            return
        manager = self._network_session.get_website_data_manager()
        manager.clear(WebKit.WebsiteDataTypes.ALL, 0, None, self._on_data_cleared)

    def _on_data_cleared(self, manager, result):
        manager.clear_finish(result)
        self._view.load_uri(HOME.uri)
        self._show_toast("Déconnecté", None)

    def _on_close_request(self, _window):
        for handler in self._view_handlers:
            self._view.disconnect(handler)
        self._view_handlers = []
        self._settings.disconnect(self._settings_handler)
        self._downloads.destroy()
        self._downloads = None
        return False
