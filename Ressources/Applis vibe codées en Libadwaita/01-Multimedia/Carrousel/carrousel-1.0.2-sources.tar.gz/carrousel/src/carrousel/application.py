from gi.repository import Adw, Gio, GLib

from carrousel import APP_ID, APP_NAME, VERSION
from carrousel.browser import create_network_session
from carrousel.window import CarrouselWindow

ACCELERATORS = {
    "win.back": ["<Alt>Left", "Back"],
    "win.forward": ["<Alt>Right", "Forward"],
    "win.reload": ["<Control>r", "F5"],
    "win.home": ["<Alt>Home"],
    "win.focus-search": ["<Control>f", "<Control>l"],
    "win.toggle-sidebar": ["F9"],
    "win.zoom-in": ["<Control>plus", "<Control>equal", "<Control>KP_Add"],
    "win.zoom-out": ["<Control>minus", "<Control>KP_Subtract"],
    "win.zoom-reset": ["<Control>0", "<Control>KP_0"],
    "window.close": ["<Control>w"],
    "app.quit": ["<Control>q"],
}


class CarrouselApplication(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.DEFAULT_FLAGS)
        GLib.set_application_name(APP_NAME)
        self._network_session = None
        self._settings = None

    def do_startup(self):
        Adw.Application.do_startup(self)
        self._settings = Gio.Settings.new(APP_ID)
        self._network_session = create_network_session("carrousel")
        for name, callback in (("quit", lambda *_: self.quit()), ("about", self._on_about)):
            action = Gio.SimpleAction.new(name, None)
            action.connect("activate", callback)
            self.add_action(action)
        for action, accels in ACCELERATORS.items():
            self.set_accels_for_action(action, accels)

    def do_activate(self):
        window = self.get_active_window() or CarrouselWindow(self, self._network_session, self._settings)
        window.present()

    def _on_about(self, *_args):
        Adw.AboutDialog(
            application_name=APP_NAME,
            application_icon=APP_ID,
            version=VERSION,
            developer_name="Shogu",
            comments="Google Photos dans une fenêtre GNOME",
            website="https://photos.google.com",
        ).present(self.get_active_window())
