(() => {
    const MAX_CLICKS = 3;
    let clicks = 0;
    let scheduled = false;

    const isVisible = element => {
        const rect = element.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0 && getComputedStyle(element).visibility !== 'hidden';
    };

    const findSideMenu = () => {
        for (const nav of document.querySelectorAll('[role="navigation"], nav')) {
            const rect = nav.getBoundingClientRect();
            if (rect.left <= 8 && rect.width >= 48 && rect.width <= 400 && rect.height >= window.innerHeight * 0.5 && isVisible(nav))
                return nav;
        }
        return null;
    };

    const findToggle = menu => {
        if (menu.id) {
            const controller = document.querySelector(`[aria-controls="${CSS.escape(menu.id)}"][aria-expanded="true"]`);
            if (controller)
                return controller;
        }
        for (const button of document.querySelectorAll('[aria-expanded="true"]')) {
            const label = button.getAttribute('aria-label') ?? '';
            if (/menu/i.test(label) && button.getBoundingClientRect().top < 80)
                return button;
        }
        return null;
    };

    const hideSideMenu = () => {
        scheduled = false;
        const menu = findSideMenu();
        if (!menu)
            return;
        const toggle = findToggle(menu);
        if (toggle && clicks < MAX_CLICKS) {
            clicks += 1;
            toggle.click();
            return;
        }
        menu.style.setProperty('display', 'none', 'important');
    };

    const schedule = () => {
        if (scheduled)
            return;
        scheduled = true;
        requestAnimationFrame(hideSideMenu);
    };

    new MutationObserver(schedule).observe(document.documentElement, {childList: true, subtree: true});
    window.addEventListener('resize', schedule);
    schedule();
})();
