APP_ID = "io.gitlab.shogu.Carrousel"
APP_NAME = "Carrousel"
VERSION = "1.0.2"
