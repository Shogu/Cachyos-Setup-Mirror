import os
import re
from pathlib import Path
from urllib.parse import urlsplit

from gi.repository import Gio, GLib, Gtk, WebKit

HIDE_MENU_SCRIPT = (Path(__file__).parent / "hide_menu.js").read_text()
GOOGLE_HOST = re.compile(r"(^|\.)(google\.[a-z.]+|googleusercontent\.com|gstatic\.com|youtube\.com)$")


def is_google_uri(uri):
    host = urlsplit(uri).hostname or ""
    return GOOGLE_HOST.search(host) is not None


def is_web_uri(uri):
    return urlsplit(uri).scheme in ("http", "https")


def open_in_browser(uri, parent):
    Gtk.UriLauncher.new(uri).launch(parent, None, None, None)


def create_network_session(app_dir_name):
    data_dir = os.path.join(GLib.get_user_data_dir(), app_dir_name)
    cache_dir = os.path.join(GLib.get_user_cache_dir(), app_dir_name)
    session = WebKit.NetworkSession.new(data_dir, cache_dir)
    session.get_cookie_manager().set_persistent_storage(
        os.path.join(data_dir, "cookies.sqlite"), WebKit.CookiePersistentStorage.SQLITE
    )
    return session


def downloads_dir():
    pictures = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_PICTURES)
    return Path(pictures or GLib.get_home_dir())


def unique_destination(folder, suggested_name):
    name = Path(suggested_name).name or "photo"
    stem, suffix = Path(name).stem, Path(name).suffix
    candidate = folder / name
    counter = 2
    while candidate.exists():
        candidate = folder / f"{stem} ({counter}){suffix}"
        counter += 1
    return candidate


class PhotosView(WebKit.WebView):
    def __init__(self, network_session):
        super().__init__(network_session=network_session)
        settings = self.get_settings()
        settings.set_enable_back_forward_navigation_gestures(True)
        settings.set_enable_developer_extras(os.environ.get("CARROUSEL_INSPECTOR") == "1")
        self.connect("decide-policy", self._on_decide_policy)

    def set_hide_google_menu(self, hidden):
        manager = self.get_user_content_manager()
        manager.remove_all_scripts()
        if hidden:
            manager.add_script(WebKit.UserScript.new(
                HIDE_MENU_SCRIPT,
                WebKit.UserContentInjectedFrames.TOP_FRAME,
                WebKit.UserScriptInjectionTime.END,
                ["https://photos.google.com/*"],
                None,
            ))

    def _on_decide_policy(self, _view, decision, decision_type):
        if decision_type == WebKit.PolicyDecisionType.RESPONSE:
            return self._decide_response(decision)
        uri = decision.get_navigation_action().get_request().get_uri()
        if decision_type == WebKit.PolicyDecisionType.NEW_WINDOW_ACTION:
            decision.ignore()
            if is_google_uri(uri):
                self.load_uri(uri)
            elif is_web_uri(uri):
                open_in_browser(uri, self.get_root())
            return True
        action = decision.get_navigation_action()
        if action.get_navigation_type() == WebKit.NavigationType.LINK_CLICKED and is_web_uri(uri) and not is_google_uri(uri):
            decision.ignore()
            open_in_browser(uri, self.get_root())
            return True
        return False

    def _decide_response(self, decision):
        disposition = decision.get_response().get_http_headers().get_one("Content-Disposition") or ""
        if disposition.lower().startswith("attachment") or not decision.is_mime_type_supported():
            decision.download()
            return True
        return False


class DownloadManager:
    def __init__(self, network_session, notify):
        self._notify = notify
        self._session = network_session
        self._handler = network_session.connect("download-started", self._on_download_started)

    def destroy(self):
        self._session.disconnect(self._handler)
        self._session = None

    def _on_download_started(self, _session, download):
        download.set_allow_overwrite(False)
        download.connect("decide-destination", self._on_decide_destination)
        download.connect("finished", self._on_finished)
        download.connect("failed", self._on_failed)

    def _on_decide_destination(self, download, suggested_name):
        folder = downloads_dir()
        folder.mkdir(parents=True, exist_ok=True)
        destination = unique_destination(folder, suggested_name)
        download.set_destination(str(destination))
        self._notify(f"Téléchargement de « {destination.name} »…", None)
        return True

    def _on_finished(self, download):
        destination = download.get_destination()
        if destination is None or not os.path.exists(destination):
            return
        self._notify(f"« {os.path.basename(destination)} » enregistré dans Images", Gio.File.new_for_path(destination))

    def _on_failed(self, download, error):
        if error.matches(WebKit.download_error_quark(), WebKit.DownloadError.CANCELLED_BY_USER):
            return
        self._notify(f"Échec du téléchargement : {error.message}", None)
