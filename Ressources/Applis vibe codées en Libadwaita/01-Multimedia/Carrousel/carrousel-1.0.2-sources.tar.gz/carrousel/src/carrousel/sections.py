from dataclasses import dataclass
from urllib.parse import quote, urlsplit

BASE_URL = "https://photos.google.com"


@dataclass(frozen=True)
class Section:
    title: str
    icon_name: str
    path: str
    extra_prefixes: tuple = ()

    @property
    def uri(self):
        return BASE_URL + self.path


SECTIONS = (
    Section("Photos", "image-x-generic-symbolic", "/", ("/photo",)),
    Section("Explorer", "system-search-symbolic", "/search"),
    Section("Albums", "view-grid-symbolic", "/albums", ("/album",)),
    Section("Partages", "emblem-shared-symbolic", "/sharing", ("/share",)),
    Section("Archives", "package-x-generic-symbolic", "/archive"),
    Section("Dossier verrouillé", "changes-prevent-symbolic", "/lockedfolder"),
    Section("Corbeille", "user-trash-symbolic", "/trash"),
)

HOME = SECTIONS[0]


def search_uri(text):
    return f"{BASE_URL}/search/{quote(text.strip(), safe='')}"


def section_index_for(uri):
    parts = urlsplit(uri)
    if parts.hostname != "photos.google.com":
        return None
    path = parts.path.rstrip("/") or "/"
    best, best_len = None, -1
    for index, section in enumerate(SECTIONS):
        for prefix in (section.path, *section.extra_prefixes):
            if path_matches(path, prefix) and len(prefix) > best_len:
                best, best_len = index, len(prefix)
    return best


def path_matches(path, prefix):
    if prefix == "/":
        return path == "/"
    return path == prefix or path.startswith(prefix + "/")
