import ctypes
import sys

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("WebKit", "6.0")

from carrousel.application import CarrouselApplication

PR_SET_NAME = 15


def main():
    ctypes.CDLL(None).prctl(PR_SET_NAME, b"carrousel", 0, 0, 0)
    return CarrouselApplication().run(sys.argv)


if __name__ == "__main__":
    sys.exit(main())
