import sys

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gio, GLib, Gtk

APP_ID = "io.gitlab.shogu.Spectacle"


class Application(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.DEFAULT_FLAGS)
        self.set_accels_for_action("win.fullscreen", ["F11"])
        self.set_accels_for_action("win.leave-fullscreen", ["Escape"])
        self.set_accels_for_action("win.focus-search", ["<Control>l", "<Control>f"])
        self.set_accels_for_action("window.close", ["<Control>w"])
        self.set_accels_for_action("app.quit", ["<Control>q"])
        quit_action = Gio.SimpleAction.new("quit", None)
        quit_action.connect("activate", lambda *_: self._quit())
        self.add_action(quit_action)

    def _window(self):
        windows = self.get_windows()
        return windows[0] if windows else None

    def _quit(self):
        window = self._window()
        if window:
            window.quit()
        else:
            self.quit()

    def do_activate(self):
        from .window import Window

        window = self._window()
        if window:
            window.restore()
        else:
            Window(self).present()


def main():
    GLib.set_prgname(APP_ID)
    GLib.set_application_name("Spectacle")
    Gtk.Window.set_default_icon_name(APP_ID)
    return Application().run(sys.argv)
