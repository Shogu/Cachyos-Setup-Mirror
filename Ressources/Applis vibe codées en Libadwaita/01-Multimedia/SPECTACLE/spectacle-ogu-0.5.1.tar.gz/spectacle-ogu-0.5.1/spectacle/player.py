"""Lecture d'un flux réseau, rendu dans un Gdk.Paintable GTK4.

Player : un seul flux (image + son mêlés, ou son seul), avec playbin.
DualPlayer : image et son en deux flux séparés (HD de YouTube), lus en synchronie dans un même pipeline.
"""

import gi

gi.require_version("Gst", "1.0")
gi.require_version("GstPbutils", "1.0")
from gi.repository import GLib, GObject, Gst, GstPbutils

Gst.init(None)

PLAY_FLAG_VIDEO = 1 << 0
PLAY_FLAG_TEXT = 1 << 2


class SinkMissingError(RuntimeError):
    pass


def _make_video_sink():
    sink = Gst.ElementFactory.make("gtk4paintablesink", None)
    if sink is None:
        raise SinkMissingError("Greffon gtk4paintablesink absent (paquet gst-plugin-gtk4).")
    paintable = sink.props.paintable
    if paintable.props.gl_context is None:
        return sink, paintable
    glsink = Gst.ElementFactory.make("glsinkbin", None)
    glsink.props.sink = sink
    return glsink, paintable


class Player(GObject.Object):
    """Enveloppe minimale de playbin. Les erreurs remontent par le signal « error »."""

    __gsignals__ = {
        "state-changed": (GObject.SignalFlags.RUN_FIRST, None, (bool,)),
        "buffering": (GObject.SignalFlags.RUN_FIRST, None, (int,)),
        "position": (GObject.SignalFlags.RUN_FIRST, None, (float, float)),
        "ended": (GObject.SignalFlags.RUN_FIRST, None, ()),
        "error": (GObject.SignalFlags.RUN_FIRST, None, (str, str)),
    }

    def __init__(self):
        super().__init__()
        self._playbin = Gst.ElementFactory.make("playbin", None)
        sink, self.paintable = _make_video_sink()
        self._playbin.props.video_sink = sink
        self._all_flags = self._playbin.props.flags
        self._start_at = 0.0
        self._headers = {}
        self._wants_play = False
        self._buffering = False
        self._failed = False
        self._tick_id = 0
        self._source_setup_id = self._playbin.connect("source-setup", self._on_source_setup)
        bus = self._playbin.get_bus()
        bus.add_signal_watch()
        self._bus_id = bus.connect("message", self._on_message)

    @property
    def playing(self):
        return self._wants_play

    def open(self, uri, headers, audio_only=False, start_at=0.0):
        """audio_only : ni décodage ni affichage vidéo (mode Rideau). start_at : reprise à cette position (s)."""
        self.stop()
        flags = self._all_flags
        if audio_only:
            flags &= ~(PLAY_FLAG_VIDEO | PLAY_FLAG_TEXT)
        self._playbin.props.flags = flags
        self._start_at = start_at
        self._headers = headers
        self._failed = False
        self._playbin.props.uri = uri
        self._wants_play = True
        self._playbin.set_state(Gst.State.PAUSED)
        self._start_ticks()
        self.emit("state-changed", True)

    def set_video_enabled(self, enabled):
        """Coupe ou rétablit le décodage et l'affichage de l'image sans interrompre la lecture (Rideau)."""
        flags = self._playbin.props.flags
        self._playbin.props.flags = flags | PLAY_FLAG_VIDEO if enabled else flags & ~(PLAY_FLAG_VIDEO | PLAY_FLAG_TEXT)

    @property
    def muted(self):
        return self._playbin.props.mute

    @muted.setter
    def muted(self, value):
        self._playbin.props.mute = value

    def play(self):
        self._wants_play = True
        if not self._buffering:
            self._playbin.set_state(Gst.State.PLAYING)
        self.emit("state-changed", True)

    def pause(self):
        self._wants_play = False
        self._playbin.set_state(Gst.State.PAUSED)
        self.emit("state-changed", False)

    def stop(self):
        self._wants_play = False
        self._buffering = False
        self._stop_ticks()
        self._playbin.set_state(Gst.State.NULL)
        self.emit("state-changed", False)
        self.emit("position", 0.0, 0.0)

    def seek(self, seconds):
        self._playbin.seek_simple(Gst.Format.TIME, Gst.SeekFlags.FLUSH | Gst.SeekFlags.KEY_UNIT | Gst.SeekFlags.SNAP_BEFORE, int(seconds * Gst.SECOND))

    @property
    def volume(self):
        return self._playbin.props.volume

    @volume.setter
    def volume(self, value):
        self._playbin.props.volume = value

    def shutdown(self):
        self._stop_ticks()
        self._playbin.set_state(Gst.State.NULL)
        bus = self._playbin.get_bus()
        bus.disconnect(self._bus_id)
        bus.remove_signal_watch()
        self._playbin.disconnect(self._source_setup_id)

    def _start_ticks(self):
        self._stop_ticks()
        self._tick_id = GLib.timeout_add(500, self._on_tick)

    def _stop_ticks(self):
        if self._tick_id:
            GLib.source_remove(self._tick_id)
            self._tick_id = 0

    def _on_tick(self):
        ok_pos, pos = self._playbin.query_position(Gst.Format.TIME)
        ok_dur, dur = self._playbin.query_duration(Gst.Format.TIME)
        if ok_pos:
            self.emit("position", pos / Gst.SECOND, dur / Gst.SECOND if ok_dur else 0.0)
        return GLib.SOURCE_CONTINUE

    def _on_source_setup(self, _element, source):
        if source.find_property("user-agent") is None:
            return
        headers = dict(self._headers)
        agent = headers.pop("User-Agent", None)
        if agent:
            source.props.user_agent = agent
        if headers and source.find_property("extra-headers") is not None:
            structure = Gst.Structure.new_empty("extra-headers")
            for key, value in headers.items():
                structure.set_value(key, value)
            source.props.extra_headers = structure

    def _fail(self, text, debug):
        if self._failed:
            return
        self._failed = True
        self.stop()
        self.emit("error", text, debug)

    def _on_message(self, _bus, message):
        kind = message.type
        if kind == Gst.MessageType.EOS:
            self.stop()
            self.emit("ended")
        elif kind == Gst.MessageType.ERROR:
            error, debug = message.parse_error()
            self._fail(error.message, debug or "")
        elif kind == Gst.MessageType.BUFFERING:
            percent = message.parse_buffering()
            self._buffering = percent < 100
            target = Gst.State.PLAYING if self._wants_play and not self._buffering else Gst.State.PAUSED
            self._playbin.set_state(target)
            self.emit("buffering", percent)
        elif kind == Gst.MessageType.ELEMENT and GstPbutils.is_missing_plugin_message(message):
            detail = GstPbutils.missing_plugin_message_get_description(message)
            self._fail(f"Greffon GStreamer manquant : {detail}", "")
        elif kind == Gst.MessageType.ASYNC_DONE:
            if self._start_at:
                start, self._start_at = self._start_at, 0.0
                self.seek(start)
            if self._wants_play and not self._buffering:
                self._playbin.set_state(Gst.State.PLAYING)


class DualPlayer(Player):
    """Deux uridecodebin (image, son) dans un pipeline : une seule horloge, donc image et son restent synchrones.

    Rideau : l'image est bloquée en sortie de décodage (sonde bloquante). Le téléchargement et le décodage de l'image
    s'arrêtent par contre-pression, le son continue. Le lever relance l'image par un déplacement à la position courante.
    """

    def __init__(self):
        GObject.Object.__init__(self)
        self._playbin = Gst.Pipeline.new("spectacle-hd")
        sink, self.paintable = _make_video_sink()
        sink.set_property("async", False)
        self._vsrc = Gst.ElementFactory.make("uridecodebin", None)
        self._asrc = Gst.ElementFactory.make("uridecodebin", None)
        vqueue, vconvert = Gst.ElementFactory.make("queue", None), Gst.ElementFactory.make("videoconvert", None)
        aqueue, aconvert = Gst.ElementFactory.make("queue", None), Gst.ElementFactory.make("audioconvert", None)
        aresample, self._volume = Gst.ElementFactory.make("audioresample", None), Gst.ElementFactory.make("volume", None)
        asink = Gst.ElementFactory.make("autoaudiosink", None)
        for element in (self._vsrc, vqueue, vconvert, sink, self._asrc, aqueue, aconvert, aresample, self._volume, asink):
            self._playbin.add(element)
        vqueue.link(vconvert)
        vconvert.link(sink)
        for upstream, downstream in ((aqueue, aconvert), (aconvert, aresample), (aresample, self._volume), (self._volume, asink)):
            upstream.link(downstream)
        self._targets = {"video": vqueue.get_static_pad("sink"), "audio": aqueue.get_static_pad("sink")}
        self._block_pad = None
        self._block_id = 0
        self._video_wanted = True
        self._levels = {}
        self._start_at = 0.0
        self._headers = {}
        self._wants_play = False
        self._buffering = False
        self._failed = False
        self._tick_id = 0
        self._handlers = [(src, src.connect("pad-added", self._on_pad_added)) for src in (self._vsrc, self._asrc)]
        self._handlers += [(src, src.connect("source-setup", self._on_source_setup)) for src in (self._vsrc, self._asrc)]
        for src in (self._vsrc, self._asrc):
            src.props.use_buffering = True
        aqueue.get_static_pad("sink").add_probe(Gst.PadProbeType.EVENT_DOWNSTREAM, self._on_audio_event)
        bus = self._playbin.get_bus()
        bus.add_signal_watch()
        self._bus_id = bus.connect("message", self._on_message)

    def open(self, uri, headers, audio_only=False, start_at=0.0, audio_uri=""):
        self.stop()
        self._unblock()
        self._block_pad = None
        self._video_wanted = True
        self._start_at = start_at
        self._headers = headers
        self._failed = False
        self._levels = {}
        self._vsrc.props.uri = uri
        self._asrc.props.uri = audio_uri
        self._wants_play = True
        self._playbin.set_state(Gst.State.PAUSED)
        self._start_ticks()
        self.emit("state-changed", True)

    def set_video_enabled(self, enabled):
        self._video_wanted = enabled
        if enabled:
            if self._block_id:
                self._unblock()
                ok, position = self._playbin.query_position(Gst.Format.TIME)
                if ok:
                    self._playbin.seek_simple(Gst.Format.TIME, Gst.SeekFlags.FLUSH | Gst.SeekFlags.KEY_UNIT, position)
        elif not self._block_id and self._block_pad is not None:
            self._block()

    def _block(self):
        self._block_id = self._block_pad.add_probe(Gst.PadProbeType.BLOCK_DOWNSTREAM | Gst.PadProbeType.BUFFER, lambda *_: Gst.PadProbeReturn.OK)

    @property
    def muted(self):
        return self._volume.props.mute

    @muted.setter
    def muted(self, value):
        self._volume.props.mute = value

    @property
    def volume(self):
        return self._volume.props.volume

    @volume.setter
    def volume(self, value):
        self._volume.props.volume = value

    def shutdown(self):
        self._unblock()
        self._stop_ticks()
        self._playbin.set_state(Gst.State.NULL)
        for obj, handler in self._handlers:
            obj.disconnect(handler)
        bus = self._playbin.get_bus()
        bus.disconnect(self._bus_id)
        bus.remove_signal_watch()

    def _unblock(self):
        if self._block_id:
            self._block_pad.remove_probe(self._block_id)
            self._block_id = 0

    def _on_pad_added(self, _src, pad):
        caps = pad.get_current_caps() or pad.query_caps(None)
        kind = "video" if caps.to_string().startswith("video/") else "audio" if caps.to_string().startswith("audio/") else None
        target = self._targets.get(kind)
        if target is None or target.is_linked():
            return
        pad.link(target)
        if kind == "video":
            self._block_pad = pad
            if not self._video_wanted:
                self._block()

    def _on_audio_event(self, _pad, info):
        # Rideau : l'image bloquée n'atteint jamais sa fin, le pipeline n'annoncerait pas la fin de lecture.
        if info.get_event().type == Gst.EventType.EOS and self._block_id:
            GLib.idle_add(self._finish_blocked)
        return Gst.PadProbeReturn.OK

    def _finish_blocked(self):
        self.stop()
        self.emit("ended")
        return GLib.SOURCE_REMOVE

    def _on_message(self, bus, message):
        if message.type == Gst.MessageType.BUFFERING:
            self._levels[message.src] = message.parse_buffering()
            percent = min(self._levels.values())
            self._buffering = percent < 100
            self._playbin.set_state(Gst.State.PLAYING if self._wants_play and not self._buffering else Gst.State.PAUSED)
            self.emit("buffering", percent)
            return
        if message.type == Gst.MessageType.ASYNC_DONE and message.src is not self._playbin:
            return
        super()._on_message(bus, message)
