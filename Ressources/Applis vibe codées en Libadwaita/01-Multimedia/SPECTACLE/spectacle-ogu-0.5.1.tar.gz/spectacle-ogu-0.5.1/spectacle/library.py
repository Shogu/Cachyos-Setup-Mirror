"""Historique des vidéos vues et positions de reprise, dans ~/.local/share/spectacle-ogu/."""

import json
import re
from pathlib import Path

from gi.repository import GLib

DIR = Path(GLib.get_user_data_dir()) / "spectacle-ogu"
HISTORY_MAX = 200
POSITIONS_MAX = 300
RESUME_MIN = 30.0
ID_RE = re.compile(r"(?:v=|youtu\.be/|/shorts/|/live/)([\w-]{6,20})")


def video_id(url):
    match = ID_RE.search(url or "")
    return match.group(1) if match else ""


def _load(name, default):
    try:
        return json.loads((DIR / name).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _save(name, data):
    DIR.mkdir(parents=True, exist_ok=True)
    tmp = DIR / f".{name}.tmp"
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(DIR / name)


class History:
    def __init__(self):
        self.items = _load("historique.json", [])

    def add(self, title, channel, url):
        self.items = [item for item in self.items if item["url"] != url]
        self.items.insert(0, {"title": title, "channel": channel, "url": url})
        del self.items[HISTORY_MAX:]
        _save("historique.json", self.items)

    def clear(self):
        self.items = []
        _save("historique.json", self.items)


class Positions:
    """Position de reprise par vidéo : seulement après 30 s de lecture et avant les 30 dernières secondes."""

    def __init__(self):
        self._data = _load("positions.json", {})

    def get(self, url):
        return float(self._data.get(url, 0.0))

    def remember(self, url, position, duration):
        if not url:
            return
        if position >= RESUME_MIN and (duration <= 0 or duration - position > RESUME_MIN):
            self._data.pop(url, None)
            self._data[url] = round(position, 1)
            while len(self._data) > POSITIONS_MAX:
                self._data.pop(next(iter(self._data)))
        elif url in self._data:
            del self._data[url]
        else:
            return
        _save("positions.json", self._data)

    def forget(self, url):
        if self._data.pop(url, None) is not None:
            _save("positions.json", self._data)
