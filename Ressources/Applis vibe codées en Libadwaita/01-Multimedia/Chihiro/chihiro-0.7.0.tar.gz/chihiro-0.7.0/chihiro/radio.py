"""Bande son : un direct YouTube en audio seul, résolu par yt-dlp, lu par playbin. Silence possible."""

import json
from pathlib import Path

import gi

gi.require_version("Gst", "1.0")
from gi.repository import Gio, GLib, Gst

from .ytdlp import YtDlp

QJS = Path("/usr/bin/qjs")
PLAY_FLAG_AUDIO = 1 << 1
STATE = Path(GLib.get_user_state_dir()) / "chihiro" / "radio"
# « pick » : mot à chercher parmi les directs de la chaîne (l'adresse d'un direct change de temps en temps).
STATIONS = {
    "lofi": {"name": "Lofi hip hop", "url": "https://www.youtube.com/@LofiGirl/live"},
    "synthwave": {"name": "Synthwave", "url": "https://www.youtube.com/@LofiGirl/streams", "pick": "synthwave"},
    "silence": {"name": "Silence", "url": ""},
}
DEFAULT = "lofi"


def saved_station():
    try:
        station = STATE.read_text(encoding="utf-8").strip()
    except OSError:
        return DEFAULT
    return station if station in STATIONS else DEFAULT


class Radio:
    def __init__(self):
        self._playbin = Gst.ElementFactory.make("playbin", None)
        self._playbin.props.flags = PLAY_FLAG_AUDIO
        self._playbin.props.video_sink = Gst.ElementFactory.make("fakesink", None)
        self.station = saved_station()
        self._uri = None
        self._retried = False
        self._wanted = False
        self._cancellable = Gio.Cancellable()
        self._ytdlp = YtDlp()
        bus = self._playbin.get_bus()
        bus.add_signal_watch()
        self._bus_id = bus.connect("message", self._on_message)

    def set_station(self, station):
        if station not in STATIONS or station == self.station:
            return
        self.station = station
        STATE.parent.mkdir(parents=True, exist_ok=True)
        STATE.write_text(station, encoding="utf-8")
        self._cancellable.cancel()
        self._cancellable = Gio.Cancellable()
        self._playbin.set_state(Gst.State.NULL)
        self._uri = None
        if self._wanted:
            self.play()

    def play(self):
        self._wanted = True
        if not STATIONS[self.station]["url"]:
            return
        if self._uri:
            self._start()
        else:
            self._resolve()

    def pause(self):
        self._wanted = False
        self._playbin.set_state(Gst.State.NULL)

    def shutdown(self):
        self._cancellable.cancel()
        self._ytdlp.cancel()
        self._playbin.set_state(Gst.State.NULL)
        bus = self._playbin.get_bus()
        bus.disconnect(self._bus_id)
        bus.remove_signal_watch()

    def _start(self):
        self._playbin.set_state(Gst.State.NULL)
        self._playbin.props.uri = self._uri
        self._playbin.set_state(Gst.State.PLAYING)

    def _resolve(self):
        station = self.station
        self._ytdlp.get(lambda ytdlp, error: self._spawn(ytdlp, error, station))

    def _run(self, ytdlp, args, callback):
        argv = [str(ytdlp), "--no-warnings", "--ignore-config", "--no-cache-dir", "--no-js-runtimes", "--js-runtimes", f"quickjs:{QJS}", *args]
        process = Gio.Subprocess.new(argv, Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_PIPE)
        process.communicate_utf8_async(None, self._cancellable, callback)

    def _spawn(self, ytdlp, error, station):
        if error:
            print(f"Chihiro : {error} Pas de bande son.", flush=True)
            return
        if station != self.station:
            return
        info = STATIONS[station]
        if info.get("pick"):
            self._run(ytdlp, ["--flat-playlist", "-J", info["url"]], lambda p, r: self._on_listed(p, r, ytdlp, station))
        else:
            self._run(ytdlp, ["-g", "-f", "bestaudio/best", info["url"]], lambda p, r: self._on_resolved(p, r, station))

    def _finish(self, process, result, station):
        try:
            _ok, stdout, stderr = process.communicate_utf8_finish(result)
        except GLib.Error:
            return None
        if station != self.station:
            return None
        if process.get_exit_status() != 0 or not stdout:
            print(f"Chihiro : radio « {STATIONS[station]['name']} » indisponible.\n{(stderr or '').strip()[-400:]}", flush=True)
            return None
        return stdout

    def _on_listed(self, process, result, ytdlp, station):
        stdout = self._finish(process, result, station)
        if stdout is None:
            return
        word = STATIONS[station]["pick"]
        entries = json.loads(stdout).get("entries") or []
        chosen = next((e for e in entries if word in (e.get("title") or "").casefold() and e.get("live_status") in (None, "is_live")), None)
        if chosen is None:
            print(f"Chihiro : aucun direct « {word} » trouvé sur la chaîne.", flush=True)
            return
        url = chosen.get("url") or f"https://www.youtube.com/watch?v={chosen['id']}"
        self._run(ytdlp, ["-g", "-f", "bestaudio/best", url], lambda p, r: self._on_resolved(p, r, station))

    def _on_resolved(self, process, result, station):
        stdout = self._finish(process, result, station)
        if stdout is None:
            return
        self._uri = stdout.split()[0]
        if self._wanted:
            self._start()

    def _on_message(self, _bus, message):
        if message.type == Gst.MessageType.ERROR:
            error, _debug = message.parse_error()
            self._playbin.set_state(Gst.State.NULL)
            print(f"Chihiro : lecture du direct impossible ({error.message}).", flush=True)
            if not self._retried and self._wanted:
                self._retried = True
                self._uri = None
                self._resolve()
        elif message.type == Gst.MessageType.STREAM_START:
            self._retried = False
