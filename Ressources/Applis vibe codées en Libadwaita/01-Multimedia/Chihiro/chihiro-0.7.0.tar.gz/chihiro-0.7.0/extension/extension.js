// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.

import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import * as QuickSettings from 'resource:///org/gnome/shell/ui/quickSettings.js';

const APP_ID = 'fr.ogu.Chihiro';
const APP_PATH = '/fr/ogu/Chihiro';
const ACTIONS_IFACE = 'org.gtk.Actions';
const STATIONS = [['lofi', 'Lofi hip hop'], ['synthwave', 'Synthwave'], ['silence', 'Silence']];

function callApp(method, parameters, onResult = null) {
    Gio.DBus.session.call(APP_ID, APP_PATH, ACTIONS_IFACE, method, parameters, null, Gio.DBusCallFlags.NO_AUTO_START, -1, null,
        (connection, result) => {
            try {
                const reply = connection.call_finish(result);
                onResult?.(reply);
            } catch (error) {
                console.warn(`[Chihiro] ${method} : ${error.message}`);
            }
        });
}

const ChihiroToggle = GObject.registerClass(
class ChihiroToggle extends QuickSettings.QuickMenuToggle {
    constructor(gicon) {
        super({title: 'Chihiro', gicon, toggleMode: false});
        this._running = false;
        this._pendingStation = null;
        this.menu.setHeader(gicon, 'Chihiro', 'Radio');
        this._items = new Map();
        for (const [id, name] of STATIONS) {
            const item = this.menu.addAction(name, () => this._chooseStation(id));
            this._items.set(id, item);
        }
        this._watchId = Gio.bus_watch_name(Gio.BusType.SESSION, APP_ID, Gio.BusNameWatcherFlags.NONE,
            () => this._setRunning(true), () => this._setRunning(false));
        this._signalId = Gio.DBus.session.signal_subscribe(APP_ID, ACTIONS_IFACE, 'Changed', APP_PATH, null,
            Gio.DBusSignalFlags.NONE, () => this._readStation());
        this.connect('clicked', () => this._toggle());
    }

    _setRunning(running) {
        this._running = running;
        this.checked = running;
        if (!running) {
            this._markStation(null);
            return;
        }
        if (this._pendingStation !== null) {
            this._setStation(this._pendingStation);
            this._pendingStation = null;
        } else {
            this._readStation();
        }
    }

    _readStation() {
        callApp('Describe', new GLib.Variant('(s)', ['radio']), reply => {
            const [, , state] = reply.recursiveUnpack()[0];
            this._markStation(state[0] ?? null);
        });
    }

    _markStation(current) {
        for (const [id, item] of this._items)
            item.setOrnament(id === current ? PopupMenu.Ornament.CHECK : PopupMenu.Ornament.NO_DOT);
    }

    _setStation(id) {
        callApp('SetState', new GLib.Variant('(sva{sv})', ['radio', new GLib.Variant('s', id), {}]));
    }

    _chooseStation(id) {
        if (this._running) {
            this._setStation(id);
        } else {
            this._pendingStation = id;
            this._launch();
        }
    }

    _toggle() {
        if (this._running)
            callApp('Activate', new GLib.Variant('(sava{sv})', ['quit', [], {}]));
        else
            this._launch();
    }

    _launch() {
        const app = Gio.DesktopAppInfo.new(`${APP_ID}.desktop`);
        if (app === null) {
            Main.notifyError('Chihiro', "L'application Chihiro n'est pas installée.");
            return;
        }
        app.launch([], global.create_app_launch_context(0, -1));
    }

    destroy() {
        Gio.bus_unwatch_name(this._watchId);
        Gio.DBus.session.signal_unsubscribe(this._signalId);
        super.destroy();
    }
});

const ChihiroIndicator = GObject.registerClass(
class ChihiroIndicator extends QuickSettings.SystemIndicator {
    constructor(gicon) {
        super();
        this.quickSettingsItems.push(new ChihiroToggle(gicon));
    }

    destroy() {
        for (const item of this.quickSettingsItems)
            item.destroy();
        super.destroy();
    }
});

export default class ChihiroQuickSettingsLaunchToggleExtension extends Extension {
    enable() {
        const gicon = new Gio.FileIcon({file: this.dir.resolve_relative_path('icons/chihiro-symbolic.svg')});
        this._indicator = new ChihiroIndicator(gicon);
        Main.panel.statusArea.quickSettings.addExternalIndicator(this._indicator);
    }

    disable() {
        this._indicator.destroy();
        this._indicator = null;
    }
}
