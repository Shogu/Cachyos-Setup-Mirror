"""Bande son : une radio lue par playbin (audio seul). Silence possible.

Trois sortes de stations : un direct YouTube (résolu par yt-dlp), un flux radio direct, ou une liste .pls à lire d'abord.
"""

import json
from pathlib import Path

import gi

gi.require_version("Gst", "1.0")
gi.require_version("Soup", "3.0")
from gi.repository import Gio, GLib, Gst, Soup

from .ytdlp import YtDlp

QJS = Path("/usr/bin/qjs")
PLAY_FLAG_AUDIO = 1 << 1
STATE = Path(GLib.get_user_state_dir()) / "chihiro" / "radio"
# « pick » : mot à chercher parmi les directs de la chaîne (l'adresse d'un direct change de temps en temps).
STATIONS = {
    "lofi": {"name": "Lofi hip hop", "url": "https://www.youtube.com/@LofiGirl/live"},
    "synthwave": {"name": "Synthwave", "url": "https://www.youtube.com/@LofiGirl/streams", "pick": "synthwave"},
    "roots": {"name": "Roots reggae", "pls": "https://somafm.com/reggae130.pls"},
    "fipreggae": {"name": "FIP Reggae", "stream": "https://icecast.radiofrance.fr/fipreggae-hifi.aac?id=radiofrance"},
    "groovesalad": {"name": "Électro détendue", "pls": "https://somafm.com/groovesalad130.pls"},
    "fipelectro": {"name": "FIP Électro", "stream": "https://icecast.radiofrance.fr/fipelectro-hifi.aac?id=radiofrance"},
    "silence": {"name": "Silence"},
}
DEFAULT = "lofi"


def saved_station():
    try:
        station = STATE.read_text(encoding="utf-8").strip()
    except OSError:
        return DEFAULT
    return station if station in STATIONS else DEFAULT


class Radio:
    def __init__(self):
        self._playbin = Gst.ElementFactory.make("playbin", None)
        self._playbin.props.flags = PLAY_FLAG_AUDIO
        self._playbin.props.video_sink = Gst.ElementFactory.make("fakesink", None)
        self.station = saved_station()
        self._uri = None
        self._retried = False
        self._wanted = False
        self._cancellable = Gio.Cancellable()
        self._ytdlp = YtDlp()
        self._session = Soup.Session(timeout=15)
        bus = self._playbin.get_bus()
        bus.add_signal_watch()
        self._bus_id = bus.connect("message", self._on_message)

    def set_station(self, station):
        if station not in STATIONS or station == self.station:
            return
        self.station = station
        STATE.parent.mkdir(parents=True, exist_ok=True)
        STATE.write_text(station, encoding="utf-8")
        self._cancellable.cancel()
        self._cancellable = Gio.Cancellable()
        self._playbin.set_state(Gst.State.NULL)
        self._uri = None
        if self._wanted:
            self.play()

    def play(self):
        self._wanted = True
        if self.station == "silence":
            return
        if self._uri:
            self._start()
        else:
            self._resolve()

    def pause(self):
        self._wanted = False
        self._playbin.set_state(Gst.State.NULL)

    def shutdown(self):
        self._cancellable.cancel()
        self._ytdlp.cancel()
        self._session.abort()
        self._playbin.set_state(Gst.State.NULL)
        bus = self._playbin.get_bus()
        bus.disconnect(self._bus_id)
        bus.remove_signal_watch()

    def _start(self):
        self._playbin.set_state(Gst.State.NULL)
        self._playbin.props.uri = self._uri
        self._playbin.set_state(Gst.State.PLAYING)

    def _resolve(self):
        station = self.station
        info = STATIONS[station]
        if "stream" in info:
            self._uri = info["stream"]
            self._start()
        elif "pls" in info:
            message = Soup.Message.new("GET", info["pls"])
            self._session.send_and_read_async(message, GLib.PRIORITY_DEFAULT, self._cancellable, self._on_playlist, message, station)
        else:
            self._ytdlp.get(lambda ytdlp, error: self._spawn(ytdlp, error, station))

    def _on_playlist(self, session, result, message, station):
        try:
            text = session.send_and_read_finish(result).get_data().decode("utf-8", "replace")
        except GLib.Error as error:
            if not error.matches(Gio.io_error_quark(), Gio.IOErrorEnum.CANCELLED):
                print(f"Chihiro : liste de la radio « {STATIONS[station]['name']} » inaccessible ({error.message}).", flush=True)
            return
        urls = [line.split("=", 1)[1].strip() for line in text.splitlines() if line.lower().startswith("file") and "=" in line]
        if station != self.station or not urls:
            return
        self._uri = urls[0]
        if self._wanted:
            self._start()

    def _run(self, ytdlp, args, callback):
        argv = [str(ytdlp), "--no-warnings", "--ignore-config", "--no-cache-dir", "--no-js-runtimes", "--js-runtimes", f"quickjs:{QJS}", *args]
        process = Gio.Subprocess.new(argv, Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_PIPE)
        process.communicate_utf8_async(None, self._cancellable, callback)

    def _spawn(self, ytdlp, error, station):
        if error:
            print(f"Chihiro : {error} Pas de bande son.", flush=True)
            return
        if station != self.station:
            return
        info = STATIONS[station]
        if info.get("pick"):
            self._run(ytdlp, ["--flat-playlist", "-J", info["url"]], lambda p, r: self._on_listed(p, r, ytdlp, station))
        else:
            self._run(ytdlp, ["-g", "-f", "bestaudio/best", info["url"]], lambda p, r: self._on_resolved(p, r, station))

    def _finish(self, process, result, station):
        try:
            _ok, stdout, stderr = process.communicate_utf8_finish(result)
        except GLib.Error:
            return None
        if station != self.station:
            return None
        if process.get_exit_status() != 0 or not stdout:
            print(f"Chihiro : radio « {STATIONS[station]['name']} » indisponible.\n{(stderr or '').strip()[-400:]}", flush=True)
            return None
        return stdout

    def _on_listed(self, process, result, ytdlp, station):
        stdout = self._finish(process, result, station)
        if stdout is None:
            return
        word = STATIONS[station]["pick"]
        entries = json.loads(stdout).get("entries") or []
        chosen = next((e for e in entries if word in (e.get("title") or "").casefold() and e.get("live_status") in (None, "is_live")), None)
        if chosen is None:
            print(f"Chihiro : aucun direct « {word} » trouvé sur la chaîne.", flush=True)
            return
        url = chosen.get("url") or f"https://www.youtube.com/watch?v={chosen['id']}"
        self._run(ytdlp, ["-g", "-f", "bestaudio/best", url], lambda p, r: self._on_resolved(p, r, station))

    def _on_resolved(self, process, result, station):
        stdout = self._finish(process, result, station)
        if stdout is None:
            return
        self._uri = stdout.split()[0]
        if self._wanted:
            self._start()

    def _on_message(self, _bus, message):
        if message.type == Gst.MessageType.ERROR:
            error, _debug = message.parse_error()
            self._playbin.set_state(Gst.State.NULL)
            print(f"Chihiro : lecture du direct impossible ({error.message}).", flush=True)
            if not self._retried and self._wanted:
                self._retried = True
                self._uri = None
                self._resolve()
        elif message.type == Gst.MessageType.STREAM_START:
            self._retried = False
