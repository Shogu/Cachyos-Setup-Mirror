// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import Gio from 'gi://Gio';
import Graphene from 'gi://Graphene';
import Mtk from 'gi://Mtk';
import Pango from 'gi://Pango';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';

import type CopyousExtension from '../../extension.js';
import { ItemType } from '../common/constants.js';
import { registerClass } from '../common/gjs.js';
import { Icon, loadIcon } from '../common/icons.js';
import { ClipboardEntry } from '../database/database.js';
import { formatCompactTimeSpan } from './items/clipboardItemHeader.js';

const SHOWN = 10;
const WIDTH = 380;
const MARGIN = 12;

const TypeIcons: Record<ItemType, Icon> = {
	[ItemType.Text]: Icon.Text,
	[ItemType.Code]: Icon.Code,
	[ItemType.Image]: Icon.Image,
	[ItemType.File]: Icon.File,
	[ItemType.Files]: Icon.Folder,
	[ItemType.Link]: Icon.Link,
	[ItemType.Character]: Icon.Character,
	[ItemType.Color]: Icon.Color,
};

const TypeNames: Record<ItemType, string> = {
	[ItemType.Text]: 'Texte',
	[ItemType.Code]: 'Code',
	[ItemType.Image]: 'Image',
	[ItemType.File]: 'Fichier',
	[ItemType.Files]: 'Fichiers',
	[ItemType.Link]: 'Lien',
	[ItemType.Character]: 'Caractère',
	[ItemType.Color]: 'Couleur',
};

type Area = { x: number; y: number; width: number; height: number };

function fileUris(entry: ClipboardEntry): string[] {
	return entry.content.split('\n').filter((uri) => uri.length > 0);
}

function shortPath(path: string): string {
	const home = GLib.get_home_dir();
	return path.startsWith(home) ? `~${path.slice(home.length)}` : path;
}

function titleText(entry: ClipboardEntry): string {
	if (entry.title) return entry.title;
	switch (entry.type) {
		case ItemType.Image:
			return 'Image';
		case ItemType.File:
			return Gio.File.new_for_uri(entry.content).get_basename() ?? 'Fichier';
		case ItemType.Files: {
			const uris = fileUris(entry);
			const first = Gio.File.new_for_uri(uris[0] ?? '').get_basename() ?? 'Fichiers';
			return uris.length > 1 ? `${first} et ${uris.length - 1} autre${uris.length > 2 ? 's' : ''}` : first;
		}
		case ItemType.Link:
		case ItemType.Character:
		case ItemType.Color:
			return entry.content;
		default:
			break;
	}
	const line = entry.content.split('\n').find((l) => l.trim().length > 0) ?? '';
	return line.replace(/\s+/g, ' ').trim().slice(0, 300);
}

function subtitleText(entry: ClipboardEntry): string {
	const time = formatCompactTimeSpan(entry.datetime);
	if (entry.type === ItemType.File || entry.type === ItemType.Files) {
		const parent = Gio.File.new_for_uri(fileUris(entry)[0] ?? '')
			.get_parent()
			?.get_path();
		if (parent) return `${shortPath(parent)} · ${time}`;
	}
	return `${TypeNames[entry.type] ?? 'Texte'} · ${time}`;
}

function matchesEntry(entry: ClipboardEntry, query: string): boolean {
	if (!query) return true;
	const fields = [entry.title, entry.content, TypeNames[entry.type]];
	return fields.some((field) => field && field.toLowerCase().includes(query));
}

function accentTint(): string {
	const [accent] = St.ThemeContext.get_for_stage(global.stage).get_accent_color();
	if (!accent) return 'transparent';
	return `rgba(${accent.red}, ${accent.green}, ${accent.blue}, 0.22)`;
}

// Row: round selection check (always visible), type icon or thumbnail, title and subtitle,
// accent pin for pinned entries. A click on the row pastes it; a click on the check (or Space)
// toggles the selection without closing the popup.
@registerClass()
class PastePickerItem extends PopupMenu.PopupBaseMenuItem {
	private readonly _check: St.Button;

	constructor(
		private readonly picker: PastePicker,
		readonly entry: ClipboardEntry,
	) {
		super({ style_class: 'copyous-picker-item' });
		this.setOrnament(PopupMenu.Ornament.HIDDEN);

		this._check = new St.Button({
			style_class: 'copyous-picker-check',
			toggle_mode: true,
			can_focus: false,
			y_align: Clutter.ActorAlign.CENTER,
			child: new St.Icon({ icon_name: 'object-select-symbolic', style_class: 'copyous-picker-check-mark' }),
		});
		this._check.connect('clicked', () => this.toggle());
		this.add_child(this._check);

		this.add_child(this.buildLead());

		const text = new St.BoxLayout({
			orientation: Clutter.Orientation.VERTICAL,
			x_expand: true,
			y_align: Clutter.ActorAlign.CENTER,
		});
		const title = new St.Label({ style_class: 'copyous-picker-title', text: titleText(entry) });
		title.clutter_text.ellipsize = Pango.EllipsizeMode.END;
		const subtitle = new St.Label({ style_class: 'copyous-picker-subtitle', text: subtitleText(entry) });
		subtitle.clutter_text.ellipsize = Pango.EllipsizeMode.END;
		text.add_child(title);
		text.add_child(subtitle);
		this.label_actor = title;
		this.add_child(text);

		if (entry.pinned) {
			this.add_child(
				new St.Icon({
					style_class: 'copyous-picker-pin',
					gicon: loadIcon(picker.ext, Icon.Pin),
					y_align: Clutter.ActorAlign.CENTER,
				}),
			);
		}

		this.updateSelected();
	}

	private buildLead(): St.Widget {
		if (this.entry.type === ItemType.Image) {
			const path = Gio.File.new_for_uri(this.entry.content).get_path();
			if (path) {
				return new St.Widget({
					style_class: 'copyous-picker-thumb',
					style: `background-image: url("${path}");`,
					y_align: Clutter.ActorAlign.CENTER,
				});
			}
		}
		return new St.Icon({
			style_class: 'copyous-picker-icon',
			gicon: loadIcon(this.picker.ext, TypeIcons[this.entry.type] ?? Icon.Text),
			y_align: Clutter.ActorAlign.CENTER,
		});
	}

	toggle() {
		this.picker.toggleSelected(this.entry);
	}

	updateSelected() {
		const selected = this.picker.isSelected(this.entry);
		this._check.checked = selected;
		this.style = selected ? `background-color: ${this.picker.tint};` : '';
	}

	override activate(event: Clutter.Event) {
		if (event?.type() === Clutter.EventType.KEY_PRESS && event.get_key_symbol() === Clutter.KEY_space) {
			this.toggle();
			return;
		}
		super.activate(event);
	}
}

type PickerUi = {
	menu: PopupMenu.PopupMenu;
	anchor: St.Widget;
	manager: PopupMenu.PopupMenuManager;
	list: PopupMenu.PopupMenuSection;
	filter: St.Entry;
	footer: PopupMenu.PopupBaseMenuItem;
	count: St.Label;
};

// Multi-paste popup opened by its shortcut at the text cursor or the pointer.
export class PastePicker {
	tint: string | null = null;
	private _cursor: Area | null = null;
	private _ui: PickerUi | null = null;
	private readonly _selected: Set<number> = new Set();
	private readonly _pending: Map<number, [PopupMenu.PopupMenu, St.Widget]> = new Map();
	private readonly _onPaste: (entries: ClipboardEntry[]) => void;

	constructor(
		readonly ext: CopyousExtension,
		{ onPaste }: { onPaste: (entries: ClipboardEntry[]) => void },
	) {
		this._onPaste = onPaste;

		(Main.inputMethod as Clutter.InputMethod).connectObject(
			'cursor-location-changed',
			(_source: Clutter.InputMethod, rect: Graphene.Rect) => {
				if (isNaN(rect.get_x()) || isNaN(rect.get_y())) return;
				const p = rect.get_bottom_right();
				this._cursor = { x: p.x + 4, y: p.y + 4, width: 1, height: 1 };
			},
			this,
		);
	}

	get isOpen(): boolean {
		return this._ui?.menu.isOpen ?? false;
	}

	toggle() {
		if (this.isOpen) this.close();
		else this.open();
	}

	isSelected(entry: ClipboardEntry): boolean {
		return this._selected.has(entry.id);
	}

	toggleSelected(entry: ClipboardEntry) {
		if (this._selected.has(entry.id)) this._selected.delete(entry.id);
		else this._selected.add(entry.id);
		this.refreshSelection();
	}

	clearSelection() {
		this._selected.clear();
		this.refreshSelection();
	}

	private entries(): ClipboardEntry[] {
		return this.ext.entryTracker?.entries ?? [];
	}

	private filteredEntries(ui: PickerUi): ClipboardEntry[] {
		const query = ui.filter.get_text().trim().toLowerCase();
		const found = this.entries().filter((entry) => matchesEntry(entry, query));
		return [...found.filter((e) => e.pinned), ...found.filter((e) => !e.pinned)];
	}

	private selectedEntries(): ClipboardEntry[] {
		const byId = new Map(this.entries().map((entry) => [entry.id, entry]));
		return [...this._selected].map((id) => byId.get(id)).filter((e): e is ClipboardEntry => e !== undefined);
	}

	open() {
		this.close();
		this._selected.clear();
		this.tint = accentTint();

		const [pointerX, pointerY] = global.get_pointer();
		const area = this._cursor ?? { x: pointerX, y: pointerY, width: 1, height: 1 };

		const anchor = new St.Widget({ width: 1, height: 1, x: area.x, y: area.y });
		Main.uiGroup.add_child(anchor);

		const menu = new PopupMenu.PopupMenu(anchor, 0.0, St.Side.TOP);
		menu.actor.add_style_class_name('copyous-paste-picker');
		if (Main.getStyleVariant() === 'light') menu.actor.add_style_class_name('copyous-picker-light');
		const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
		const monitor = global.display.get_monitor_index_for_rect(
			new Mtk.Rectangle({ x: Math.round(area.x), y: Math.round(area.y), width: 1, height: 1 }),
		);
		const workArea = Main.layoutManager.getWorkAreaForMonitor(Math.max(0, monitor));
		menu.box.width = Math.min(WIDTH * scale, workArea.width - 2 * MARGIN * scale);
		Main.uiGroup.add_child(menu.actor);
		menu.actor.hide();
		const manager = new PopupMenu.PopupMenuManager(anchor);
		manager.addMenu(menu);
		menu.connect('open-state-changed', (_menu: PopupMenu.PopupMenu, isOpen: boolean) => {
			if (!isOpen) this.destroyLater();
			return undefined;
		});

		this._ui = this.build(menu, anchor, manager);
		this.show();
		menu.open();
		this._ui.filter.clutter_text.grab_key_focus();
	}

	private build(menu: PopupMenu.PopupMenu, anchor: St.Widget, manager: PopupMenu.PopupMenuManager): PickerUi {
		const filterItem = new PopupMenu.PopupBaseMenuItem({
			reactive: false,
			can_focus: false,
			style_class: 'copyous-picker-filter-item',
		});
		filterItem.setOrnament(PopupMenu.Ornament.HIDDEN);
		const filter = new St.Entry({
			style_class: 'copyous-picker-filter',
			hint_text: 'Filtrer',
			can_focus: true,
			x_expand: true,
			primary_icon: new St.Icon({ style_class: 'copyous-picker-filter-icon', icon_name: 'edit-find-symbolic' }),
		});
		filterItem.add_child(filter);
		menu.addMenuItem(filterItem);

		filter.clutter_text.connect('text-changed', () => this.show());
		filter.clutter_text.connect('activate', () => this.onEnter());
		filter.clutter_text.connect('key-press-event', (_actor: Clutter.Actor, event: Clutter.Event) => {
			if (event.get_key_symbol() !== Clutter.KEY_Down) return Clutter.EVENT_PROPAGATE;
			this.items()[0]?.grab_key_focus();
			return Clutter.EVENT_STOP;
		});

		const list = new PopupMenu.PopupMenuSection();
		menu.addMenuItem(list);
		list.connect('activate', (_section: PopupMenu.PopupMenuSection, item: PopupMenu.PopupBaseMenuItem | null) => {
			if (item instanceof PastePickerItem) this.paste([item.entry]);
			return undefined;
		});

		const footer = new PopupMenu.PopupBaseMenuItem({
			reactive: false,
			can_focus: false,
			style_class: 'copyous-picker-footer',
		});
		footer.setOrnament(PopupMenu.Ornament.HIDDEN);

		const actions = new St.BoxLayout({ style_class: 'copyous-picker-actions', x_expand: true });
		const count = new St.Label({
			style_class: 'copyous-picker-count',
			x_expand: true,
			y_align: Clutter.ActorAlign.CENTER,
		});
		const cancel = new St.Button({ style_class: 'copyous-picker-pill', label: 'Annuler', can_focus: true });
		cancel.connect('clicked', () => this.clearSelection());
		const paste = new St.Button({
			style_class: 'copyous-picker-pill copyous-picker-pill-accent',
			label: 'Coller',
			can_focus: true,
		});
		paste.connect('clicked', () => this.paste(this.selectedEntries()));
		actions.add_child(count);
		actions.add_child(cancel);
		actions.add_child(paste);
		footer.add_child(actions);
		menu.addMenuItem(footer);

		return { menu, anchor, manager, list, filter, footer, count };
	}

	private items(): PastePickerItem[] {
		const ui = this._ui;
		if (!ui) return [];
		return ui.list._getMenuItems().filter((item): item is PastePickerItem => item instanceof PastePickerItem);
	}

	private show() {
		const ui = this._ui;
		if (!ui) return;
		ui.list.removeAll();
		const found = this.filteredEntries(ui);
		if (found.length === 0) {
			const empty = this.entries().length === 0 ? 'Aucun élément copié pour le moment' : 'Aucun résultat';
			const item = new PopupMenu.PopupMenuItem(empty, { reactive: false });
			item.setOrnament(PopupMenu.Ornament.HIDDEN);
			ui.list.addMenuItem(item);
		} else {
			let separated = !found[0]!.pinned;
			for (const entry of found.slice(0, SHOWN)) {
				if (!separated && !entry.pinned) {
					ui.list.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
					separated = true;
				}
				ui.list.addMenuItem(new PastePickerItem(this, entry));
			}
		}
		this.refreshSelection();
	}

	private refreshSelection() {
		const ui = this._ui;
		if (!ui) return;
		for (const item of this.items()) item.updateSelected();
		const n = this.selectedEntries().length;
		ui.footer.visible = n > 0;
		ui.count.text = n === 1 ? '1 sélectionné' : `${n} sélectionnés`;
	}

	private onEnter() {
		const selected = this.selectedEntries();
		const first = this.items()[0];
		if (selected.length > 0) this.paste(selected);
		else if (first) this.paste([first.entry]);
	}

	private paste(entries: ClipboardEntry[]) {
		if (entries.length === 0) return;
		this.close();
		this._onPaste(entries);
	}

	close() {
		if (this._ui?.menu.isOpen) this._ui.menu.close();
		this.destroyLater();
	}

	// Destroy the menu outside of its own signal handlers.
	private destroyLater() {
		const ui = this._ui;
		if (!ui) return;
		this._ui = null;
		ui.menu.actor.hide();
		const id = GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
			this._pending.delete(id);
			ui.menu.destroy();
			ui.anchor.destroy();
			return GLib.SOURCE_REMOVE;
		});
		this._pending.set(id, [ui.menu, ui.anchor]);
	}

	destroy() {
		this.close();
		for (const [id, [menu, anchor]] of this._pending) {
			GLib.source_remove(id);
			menu.destroy();
			anchor.destroy();
		}
		this._pending.clear();
		(Main.inputMethod as Clutter.InputMethod).disconnectObject(this);
		this._selected.clear();
	}
}
