import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import GdkPixbuf from 'gi://GdkPixbuf';
import Gio from 'gi://Gio';
import Pango from 'gi://Pango';
import St from 'gi://St';

import { gettext as _, ngettext } from 'resource:///org/gnome/shell/extensions/extension.js';
import * as animationUtils from 'resource:///org/gnome/shell/misc/animationUtils.js';
import * as CheckBox from 'resource:///org/gnome/shell/ui/checkBox.js';
import * as Dialog from 'resource:///org/gnome/shell/ui/dialog.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as ModalDialog from 'resource:///org/gnome/shell/ui/modalDialog.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';

import type CopyousExtension from '../../extension.js';
import { Color } from '../common/color.js';
import { ItemType } from '../common/constants.js';
import { registerClass } from '../common/gjs.js';
import { Icon, loadIcon } from '../common/icons.js';
import { ClipboardHistory, IndicatorDisplay } from '../common/settings.js';
import { ClipboardEntry } from '../database/database.js';
import { VERSION } from '../misc/compatibility.js';

@registerClass({
	Signals: {
		'clear-history': {
			param_types: [GObject.TYPE_INT],
		},
	},
})
export class ConfirmClearHistoryDialog extends ModalDialog.ModalDialog {
	constructor() {
		super();

		const content = new Dialog.MessageDialogContent({
			title: _('Clear Clipboard History?'),
			description: _('Are you sure you want to clear your clipboard history?'),
		});
		this.contentLayout.add_child(content);

		const checkbox = new CheckBox.CheckBox(_('Clear Pinned/Tagged Items'));
		content.add_child(checkbox);

		this.addButton({
			label: _('Cancel'),
			action: this.close.bind(this),
			default: true,
			key: Clutter.KEY_Escape,
		});

		this.addButton({
			label: _('Clear'),
			action: () => {
				this.emit(
					'clear-history',
					checkbox.checked ? ClipboardHistory.Clear : ClipboardHistory.KeepPinnedAndTagged,
				);
				this.close();
			},
		});
	}
}

@registerClass({
	Properties: {
		incognito: GObject.ParamSpec.boolean('incognito', null, null, GObject.ParamFlags.READWRITE, false),
	},
	Signals: {
		'open-dialog': {},
		'clear-history': {
			param_types: [GObject.TYPE_INT],
		},
	},
})
export class ClipboardIndicator extends PanelMenu.Button {
	private _incognito: boolean = false;

	declare menu: PopupMenu.PopupMenu;
	private readonly _box: St.BoxLayout;
	private readonly _icon: St.Icon;
	private readonly _accumulateSwitch: PopupMenu.PopupSwitchMenuItem;
	private readonly _incognitoSwitch: PopupMenu.PopupSwitchMenuItem;
	private readonly _pastePickerSwitch: PopupMenu.PopupSwitchMenuItem;
	private _previewWidget?: St.Widget;
	private _hoverTimeoutId: number = 0;
	private _hoverSuppressed: boolean = false;

	constructor(private ext: CopyousExtension) {
		super(0.5, ext.metadata.name, false);
		this.configurePanelMenuClickGesture();

		this._box = new St.BoxLayout({
			style_class: 'copyous-indicator-box',
			orientation: Clutter.Orientation.HORIZONTAL,
		});
		this.add_child(this._box);

		this._icon = new St.Icon({
			gicon: loadIcon(ext, Icon.Clipboard),
			style_class: 'system-status-icon',
		});
		this._box.add_child(this._icon);

		this._accumulateSwitch = new PopupMenu.PopupSwitchMenuItem(
			_('Accumulate Mode'),
			ext.settings.get_boolean('accumulate'),
		);
		this._accumulateSwitch.connect('toggled', (_item: PopupMenu.PopupSwitchMenuItem, state: boolean) =>
			this.ext.settings.set_boolean('accumulate', state),
		);
		this.menu.addMenuItem(this._accumulateSwitch);

		this._incognitoSwitch = new PopupMenu.PopupSwitchMenuItem(_('Incognito Mode'), false);
		this.menu.addMenuItem(this._incognitoSwitch);

		this._pastePickerSwitch = new PopupMenu.PopupSwitchMenuItem(
			_('Multi-Paste Picker'),
			ext.settings.get_boolean('paste-picker-enabled'),
		);
		this._pastePickerSwitch.connect('toggled', (_item: PopupMenu.PopupSwitchMenuItem, state: boolean) =>
			this.ext.settings.set_boolean('paste-picker-enabled', state),
		);
		this.menu.addMenuItem(this._pastePickerSwitch);
		this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
		this.menu.addAction(_('Clear History'), () => this.confirmClearHistory());
		this.menu.addAction(_('Settings'), () => ext.openPreferences());

		// GNOME Shell's panel menu manager opens a panel button's menu when the pointer slides
		// onto it while another panel menu (e.g. Quick Settings) is open. For Copyous this would pop
		// up the right-click menu. Only allow the menu to open from our own click (menu.toggle) or
		// from keyboard navigation between panel menus.
		type AnyFn = (...args: unknown[]) => unknown;
		const menu = this.menu as unknown as { open: AnyFn; toggle: AnyFn };
		const origToggle = menu.toggle.bind(this.menu);
		const origOpen = menu.open.bind(this.menu);
		let allowOpen = false;
		menu.toggle = (...args: unknown[]) => {
			allowOpen = true;
			try {
				return origToggle(...args);
			} finally {
				allowOpen = false;
			}
		};
		menu.open = (...args: unknown[]) => {
			const type = Clutter.get_current_event()?.type();
			const fromKeyboard = type === Clutter.EventType.KEY_PRESS || type === Clutter.EventType.KEY_RELEASE;
			if (!allowOpen && !fromKeyboard) return;
			return origOpen(...args);
		};

		// Add to panel
		Main.panel.addToStatusArea(ext.uuid, this, 1, 'right');

		// Bind properties
		this.ext.settings.connectObject(
			'changed::indicator-display',
			this.updateSettings.bind(this),
			'changed::incognito',
			this.updateSettings.bind(this),
			'changed::accumulate',
			() => {
				this._accumulateSwitch.setToggleState(this.ext.settings.get_boolean('accumulate'));
				this.updateIcon();
			},
			'changed::paste-picker-enabled',
			() => this._pastePickerSwitch.setToggleState(this.ext.settings.get_boolean('paste-picker-enabled')),
			this,
		);

		this.bind_property('incognito', this._incognitoSwitch, 'state', GObject.BindingFlags.BIDIRECTIONAL);

		this.updateSettings();
		this.updateIcon();
	}

	/** Panel icon: accumulate mode first, then incognito, then the normal clipboard. */
	private updateIcon() {
		let icon: Icon = Icon.Clipboard;
		if (this.ext.settings.get_boolean('accumulate')) icon = Icon.ClipboardAdd;
		else if (this._incognito) icon = Icon.ClipboardDisabled;
		this._icon.gicon = loadIcon(this.ext, icon);
	}

	private configurePanelMenuClickGesture() {
		if (VERSION < 50) return;

		(
			this as ClipboardIndicator & {
				_clickGesture?: { set_required_button: (button: number) => void };
			}
		)._clickGesture?.set_required_button(Clutter.BUTTON_SECONDARY);
	}

	get incognito() {
		return this._incognito;
	}

	set incognito(value: boolean) {
		if (this._incognito === value) return;
		this._incognitoSwitch.state = value;
		this._incognito = value;
		this.updateIcon();
		this.ext.settings.set_boolean('incognito', value);
		this.notify('incognito');
	}

	private set previewWidget(widget: St.Widget) {
		this._previewWidget?.destroy();
		this._previewWidget = widget;
		this._box.add_child(widget);
		this.updateSettings();
	}

	private updateSettings() {
		const indicatorDisplay = this.ext.settings.get_enum('indicator-display');
		const showContentIndicator =
			indicatorDisplay === IndicatorDisplay.ClipboardContentOnly ||
			indicatorDisplay === IndicatorDisplay.IconAndClipboardContent;
		const showIconIndicator =
			indicatorDisplay === IndicatorDisplay.IconOnly ||
			indicatorDisplay === IndicatorDisplay.IconAndClipboardContent ||
			(showContentIndicator && !this._previewWidget);

		this.visible = indicatorDisplay !== IndicatorDisplay.Hidden;
		this._icon.visible = showIconIndicator;
		if (this._previewWidget) this._previewWidget.visible = showContentIndicator;
		this.incognito = this.ext.settings.get_boolean('incognito');
	}

	toggleIncognito() {
		this.incognito = !this.incognito;
	}

	animate() {
		if (this._icon.visible && this.ext.settings.get_boolean('wiggle-indicator')) {
			animationUtils.wiggle(this._icon, { offset: 2, duration: 65, wiggleCount: 3 });
		}
	}

	showEntry(entry: ClipboardEntry) {
		switch (entry.type) {
			case ItemType.Text:
			case ItemType.Code:
			case ItemType.Link:
			case ItemType.Character:
				this.showText(entry.content.split('\n')[0] ?? '');
				break;
			case ItemType.Image:
				this.showImageFile(Gio.File.new_for_uri(entry.content));
				break;
			case ItemType.File: {
				const file = Gio.File.new_for_uri(entry.content).get_basename();
				this.showText(file ?? '', true);
				break;
			}
			case ItemType.Files: {
				const n = entry.content.split('\n').length;
				this.showText(ngettext('%d File', '%d Files', n).format(n));
				break;
			}
			case ItemType.Color: {
				const color = Color.parse(entry.content)?.hex();
				if (!color) return;

				const pixbuf = GdkPixbuf.Pixbuf.new(GdkPixbuf.Colorspace.RGB, false, 8, 32, 32);
				pixbuf.fill(parseInt(color.toString().padEnd(9, 'f').replace('#', '0x')));
				const [, buffer] = pixbuf.save_to_bufferv('png', null, null);
				this.showImageBytes(buffer);
				break;
			}
		}
	}

	showText(text: string, start: boolean = false) {
		const label = new St.Label({
			style_class: 'indicator-label',
			y_align: Clutter.ActorAlign.CENTER,
			text,
		});
		label.clutter_text.ellipsize = start ? Pango.EllipsizeMode.START : Pango.EllipsizeMode.END;
		this.previewWidget = label;
	}

	showImageFile(file: Gio.File) {
		if (!file.query_exists(null)) return;
		this.previewWidget = new St.Icon({
			style_class: 'system-status-icon',
			gicon: Gio.FileIcon.new(file),
			y_align: Clutter.ActorAlign.CENTER,
		});
	}

	showImageBytes(bytes: Uint8Array) {
		this.previewWidget = new St.Icon({
			style_class: 'system-status-icon',
			gicon: Gio.BytesIcon.new(bytes),
			y_align: Clutter.ActorAlign.CENTER,
		});
	}

	private confirmClearHistory() {
		const dialog = new ConfirmClearHistoryDialog();
		dialog.connect('clear-history', (_dialog, history) => this.emit('clear-history', history));
		dialog.open();
	}

	private cancelHoverOpen() {
		if (this._hoverTimeoutId) {
			GLib.source_remove(this._hoverTimeoutId);
			this._hoverTimeoutId = 0;
		}
	}

	private isPointerInside(): boolean {
		const [x, y] = global.get_pointer();
		const box = this.get_transformed_extents();
		return (
			x >= box.get_x() &&
			x < box.get_x() + box.get_width() &&
			y >= box.get_y() &&
			y < box.get_y() + box.get_height()
		);
	}

	/**
	 * Called when the clipboard dialog closes. If the pointer is still resting on the
	 * indicator (e.g. the dialog was closed by clicking the icon), do not reopen it by
	 * hover until the pointer has left the indicator.
	 */
	suppressHoverOpen() {
		this.cancelHoverOpen();
		this._hoverSuppressed = this.isPointerInside();
	}

	override vfunc_enter_event(event: Clutter.Event): boolean {
		this.cancelHoverOpen();
		if (this._hoverSuppressed) return super.vfunc_enter_event(event);

		// Open the dialog after the pointer has rested on the indicator for a short delay,
		// so that merely crossing the top bar does not open it.
		const delay = this.ext.settings.get_int('hover-open-delay');
		if (this.ext.settings.get_boolean('open-on-hover') && delay > 0) {
			this._hoverTimeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, delay, () => {
				this._hoverTimeoutId = 0;
				const buttons =
					Clutter.ModifierType.BUTTON1_MASK |
					Clutter.ModifierType.BUTTON2_MASK |
					Clutter.ModifierType.BUTTON3_MASK;
				if (this.hover && !this.menu.isOpen && (global.get_pointer()[2] & buttons) === 0) {
					this.emit('open-dialog');
				}
				return GLib.SOURCE_REMOVE;
			});
		}

		return super.vfunc_enter_event(event);
	}

	override vfunc_leave_event(event: Clutter.Event): boolean {
		this.cancelHoverOpen();
		// Grabs can emit spurious leave events: only re-arm hover once the pointer is really outside
		if (this._hoverSuppressed && !this.isPointerInside()) this._hoverSuppressed = false;
		return super.vfunc_leave_event(event);
	}

	override vfunc_button_press_event(event: Clutter.Event): boolean {
		if (event.get_button() === Clutter.BUTTON_PRIMARY) {
			// Open on release: opening during the press competes with the implicit
			// pointer grab, which could make the modal grab fail silently.
			this.cancelHoverOpen();
			return Clutter.EVENT_STOP;
		}

		if (event.get_button() === Clutter.BUTTON_MIDDLE) {
			this.ext.openPreferences();
			return Clutter.EVENT_STOP;
		}

		return Clutter.EVENT_PROPAGATE;
	}

	override vfunc_button_release_event(event: Clutter.Event): boolean {
		if (event.get_button() === Clutter.BUTTON_PRIMARY) {
			this.emit('open-dialog');
			return Clutter.EVENT_STOP;
		}

		return Clutter.EVENT_PROPAGATE;
	}

	override vfunc_touch_event(event: Clutter.Event): boolean {
		if (event.type() === Clutter.EventType.TOUCH_BEGIN) {
			this.emit('open-dialog');
			return Clutter.EVENT_STOP;
		}

		return Clutter.EVENT_PROPAGATE;
	}

	override destroy() {
		this.cancelHoverOpen();
		this.ext.settings.disconnectObject(this);

		super.destroy();
	}
}
