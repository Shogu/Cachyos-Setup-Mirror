// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import GLib from 'gi://GLib';

import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import {FEATURES, SELF_WRITTEN} from './features.js';
import {TileOrder} from './tileOrder.js';

export default class QuickSettingsExtension extends Extension {
    enable() {
        this._settings = this.getSettings();
        this._built = new Map();
        this._tileOrder = new TileOrder();
        this._placeId = 0;
        this._build();
        this._placeTiles();
        // Tuiles d'autres extensions activées après celle-ci : reclassement dès leur arrivée.
        this._grid = Main.panel.statusArea.quickSettings.menu._grid;
        this._childAddedId = this._grid.connect('child-added', () => this._schedulePlaceTiles());
        this._settingsId = this._settings.connect('changed', (_settings, key) => this._settingChanged(key));
    }

    disable() {
        if (this._placeId)
            GLib.Source.remove(this._placeId);
        this._placeId = 0;
        this._grid.disconnect(this._childAddedId);
        this._grid = null;
        this._settings.disconnect(this._settingsId);
        this._teardown();
        this._tileOrder.restore();
        this._tileOrder = null;
        this._built = null;
        this._settings = null;
    }

    _enabled(feature) {
        return feature.switches.some(key => this._settings.get_boolean(key));
    }

    _create(feature) {
        if (!this._enabled(feature))
            return;
        // Chaque module est indépendant : un échec est journalisé sans bloquer les suivants.
        try {
            this._built.set(feature.id, feature.create(this._settings, this._built));
        } catch (error) {
            console.error(`Quick Settings : ${feature.id} — ${error.message}`, error);
        }
    }

    _build() {
        FEATURES.forEach(feature => this._create(feature));
    }

    _teardown() {
        for (const id of [...this._built.keys()].reverse())
            this._built.get(id).destroy();
        this._built.clear();
    }

    // Un réglage ne touche que son module : appliqué sur place s'il le permet, sinon le module
    // (et ceux qui en dépendent) est détruit puis recréé. Le reste de Quick Settings ne bouge pas.
    _settingChanged(key) {
        if (SELF_WRITTEN.includes(key))
            return;
        if (key === 'tile-order') {
            this._placeTiles();
            return;
        }
        const affected = new Set();
        for (const feature of FEATURES) {
            if (key in feature.live) {
                if (this._built.has(feature.id))
                    feature.live[key](this._built.get(feature.id), this._settings);
            } else if (feature.switches.includes(key) || feature.options.includes(key)) {
                affected.add(feature.id);
            }
        }
        if (affected.size)
            this._recreate(affected);
    }

    _recreate(ids) {
        for (const feature of FEATURES) {
            if (feature.needs.some(id => ids.has(id)))
                ids.add(feature.id);
        }
        const features = FEATURES.filter(feature => ids.has(feature.id));
        for (const feature of [...features].reverse()) {
            this._built.get(feature.id)?.destroy();
            this._built.delete(feature.id);
        }
        features.forEach(feature => this._create(feature));
        this._placeTiles();
    }

    _schedulePlaceTiles() {
        if (this._placeId)
            return;
        this._placeId = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
            this._placeId = 0;
            this._placeTiles();
            return GLib.SOURCE_REMOVE;
        });
    }

    // Ordre choisi dans les préférences (« Ordre des tuiles »). Sans ordre enregistré, la tuile
    // Ressources est seulement remontée juste avant « Éclairage nocturne » (comportement d'origine).
    // Les titres des tuiles d'autres extensions sont publiés pour que les préférences les listent.
    _placeTiles() {
        try {
            const others = this._tileOrder.others(this._built);
            const titles = [...others.keys()];
            if (titles.join('\n') !== this._settings.get_strv('other-tiles').join('\n'))
                this._settings.set_strv('other-tiles', titles);
            const order = this._settings.get_strv('tile-order');
            if (order.length)
                this._tileOrder.apply(order, this._built, others);
            else
                this._placeResources();
        } catch (error) {
            console.error(`Quick Settings : classement des tuiles — ${error.message}`, error);
        }
    }

    _placeResources() {
        const quickSettings = Main.panel.statusArea.quickSettings;
        const resources = this._built.get('resources-toggle')?.quickSettingsItems[0];
        const night = quickSettings._nightLight?.quickSettingsItems[0];
        if (resources && night && resources.get_parent() === night.get_parent())
            night.get_parent().set_child_below_sibling(resources, night);
    }
}
