// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';

Gio._promisify(Gio.SocketClient.prototype, 'connect_async');
Gio._promisify(Gio.OutputStream.prototype, 'write_bytes_async');
Gio._promisify(Gio.DataInputStream.prototype, 'read_line_async');
Gio._promisify(Gio.File.prototype, 'load_contents_async');
Gio._promisify(Gio.File.prototype, 'enumerate_children_async');
Gio._promisify(Gio.FileEnumerator.prototype, 'next_files_async');

const encoder = new TextEncoder();
const decoder = new TextDecoder();
const DROPBOX_DIR = GLib.build_filenamev([GLib.get_home_dir(), '.dropbox']);
const SOCKET_TIMEOUT_S = 5;
const MAX_SCANNED = 30000;

// Le protocole de la commande `dropbox` (dropbox.py) sur ~/.dropbox/command_socket :
// « commande », lignes « clé\tvaleur… », « done » ; réponse « ok », lignes, « done ».
export async function dropboxCommand(command, args, cancellable) {
    const client = new Gio.SocketClient({timeout: SOCKET_TIMEOUT_S});
    const address = Gio.UnixSocketAddress.new(GLib.build_filenamev([DROPBOX_DIR, 'command_socket']));
    const connection = await client.connect_async(address, cancellable);
    try {
        const lines = [command, ...Object.entries(args).map(([key, values]) => [key, ...[].concat(values)].join('\t')), 'done'];
        await connection.get_output_stream().write_bytes_async(new GLib.Bytes(encoder.encode(`${lines.join('\n')}\n`)),
            GLib.PRIORITY_DEFAULT, cancellable);

        const input = new Gio.DataInputStream({base_stream: connection.get_input_stream()});
        const readLine = async () => {
            const [line] = await input.read_line_async(GLib.PRIORITY_DEFAULT, cancellable);
            if (line === null)
                throw new Error('Dropbox a fermé la connexion');
            return decoder.decode(line);
        };
        if (await readLine() !== 'ok')
            throw new Error(`Dropbox a refusé « ${command} »`);
        const reply = {};
        for (let line = await readLine(); line !== 'done'; line = await readLine()) {
            const [key, ...values] = line.split('\t');
            reply[key] = values;
        }
        return reply;
    } finally {
        connection.close(null);
    }
}

export async function dropboxFolder(cancellable) {
    try {
        const [bytes] = await Gio.File.new_for_path(GLib.build_filenamev([DROPBOX_DIR, 'info.json']))
            .load_contents_async(cancellable);
        const info = JSON.parse(decoder.decode(bytes));
        return (info.personal ?? info.business).path;
    } catch {
        return GLib.build_filenamev([GLib.get_home_dir(), 'Dropbox']);
    }
}

// Les `count` fichiers modifiés le plus récemment (dossiers cachés ignorés).
export async function recentFiles(root, count, cancellable) {
    const attributes = 'standard::name,standard::type,standard::is-hidden,standard::display-name,standard::symbolic-icon,time::modified';
    const recent = [];
    const queue = [Gio.File.new_for_path(root)];
    let scanned = 0;
    while (queue.length && scanned < MAX_SCANNED) {
        const dir = queue.shift();
        let enumerator;
        try {
            enumerator = await dir.enumerate_children_async(attributes, Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS,
                GLib.PRIORITY_LOW, cancellable);
        } catch {
            continue;
        }
        for (let infos = await enumerator.next_files_async(200, GLib.PRIORITY_LOW, cancellable); infos.length;
            infos = await enumerator.next_files_async(200, GLib.PRIORITY_LOW, cancellable)) {
            scanned += infos.length;
            for (const info of infos) {
                if (info.get_is_hidden())
                    continue;
                const child = dir.get_child(info.get_name());
                if (info.get_file_type() === Gio.FileType.DIRECTORY)
                    queue.push(child);
                else if (info.get_file_type() === Gio.FileType.REGULAR)
                    recent.push({file: child, info, time: info.get_modification_date_time().to_unix()});
            }
            recent.sort((a, b) => b.time - a.time);
            recent.length = Math.min(recent.length, count);
        }
        enumerator.close(null);
    }
    return recent;
}
