// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';

const RESIZE_GRACE_US = 500000;
const POINTER_POLL_MS = 120;
const BUTTONS = Clutter.ModifierType.BUTTON1_MASK | Clutter.ModifierType.BUTTON2_MASK | Clutter.ModifierType.BUTTON3_MASK;

// Ferme un menu de la barre du haut quand le pointeur en sort, après `delay` ms.
// Le menu reste ouvert tant qu'un bouton de la souris est enfoncé ou qu'on tape
// dans un de ses champs ; un menu qui rétrécit sous un pointeur immobile ne
// compte pas comme une sortie.
export class HoverAutoClose {
    constructor(menu, close, delay) {
        this._menu = menu;
        this._actor = menu.actor;
        this._close = close;
        this._delay = delay;
        this._closeId = 0;
        this._pollId = 0;
        this._entered = false;
        this._resize = null;

        this._previousTrackHover = this._actor.track_hover;
        this._actor.track_hover = true;
        this._hoverId = this._actor.connect('notify::hover', () => this._hoverChanged());
        this._heightId = this._actor.connect('notify::height', () => {
            if (this._actor.hover)
                this._resize = {pointer: global.get_pointer().slice(0, 2), time: GLib.get_monotonic_time()};
        });
        this._openId = menu.connect('open-state-changed', (_menu, open) => {
            this._cancel();
            this._actor.sync_hover();
            this._entered = open && this._actor.hover;
        });
    }

    set delay(delay) {
        this._delay = delay;
    }

    _pointerStill() {
        const [x, y] = global.get_pointer();
        return this._resize !== null && x === this._resize.pointer[0] && y === this._resize.pointer[1];
    }

    _hoverChanged() {
        if (!this._menu.isOpen)
            return;
        if (this._actor.hover) {
            this._entered = true;
            this._cancel();
            return;
        }
        if (!this._entered)
            return;
        if (this._resize && GLib.get_monotonic_time() - this._resize.time < RESIZE_GRACE_US && this._pointerStill())
            this._watchPointer();
        else
            this._scheduleClose(this._delay);
    }

    // Après un redimensionnement : on attend que le pointeur bouge pour décider.
    _watchPointer() {
        if (this._pollId)
            return;
        this._pollId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, POINTER_POLL_MS, () => {
            this._actor.sync_hover();
            if (!this._menu.isOpen || this._actor.hover) {
                this._pollId = 0;
                return GLib.SOURCE_REMOVE;
            }
            if (this._pointerStill())
                return GLib.SOURCE_CONTINUE;
            this._pollId = 0;
            this._scheduleClose(this._delay);
            return GLib.SOURCE_REMOVE;
        });
    }

    _scheduleClose(delay) {
        if (this._closeId)
            GLib.Source.remove(this._closeId);
        this._closeId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, delay, () => {
            this._closeId = 0;
            this._actor.sync_hover();
            if (!this._menu.isOpen || this._actor.hover || this._typing())
                return GLib.SOURCE_REMOVE;
            const [, , modifiers] = global.get_pointer();
            if (modifiers & BUTTONS)
                this._scheduleClose(POINTER_POLL_MS);
            else
                this._close();
            return GLib.SOURCE_REMOVE;
        });
    }

    _typing() {
        const focus = global.stage.get_key_focus();
        return focus instanceof Clutter.Text && focus.editable && this._actor.contains(focus);
    }

    _cancel() {
        if (this._closeId)
            GLib.Source.remove(this._closeId);
        if (this._pollId)
            GLib.Source.remove(this._pollId);
        this._closeId = 0;
        this._pollId = 0;
        this._resize = null;
    }

    destroy() {
        this._cancel();
        this._actor.disconnect(this._hoverId);
        this._actor.disconnect(this._heightId);
        this._menu.disconnect(this._openId);
        this._actor.track_hover = this._previousTrackHover;
        this._actor = null;
        this._menu = null;
        this._close = null;
    }
}
