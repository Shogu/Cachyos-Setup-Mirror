// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import {InjectionManager} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as EndSessionDialog from 'resource:///org/gnome/shell/ui/endSessionDialog.js';

import {LOGOUT_TITLE} from './splitButtons.js';

const LOGOUT_DIALOG_TYPE = 0;

// Fenêtre de confirmation « Fermer la session » : titre et bouton deviennent « Reconnexion ».
export class LogoutDialogLabel {
    constructor() {
        this._injections = new InjectionManager();
        const proto = EndSessionDialog.EndSessionDialog.prototype;
        this._injections.overrideMethod(proto, '_sync', nativeSync => function (...args) {
            nativeSync.apply(this, args);
            if (this._type === LOGOUT_DIALOG_TYPE)
                this._messageDialogContent.title = LOGOUT_TITLE;
        });
        this._injections.overrideMethod(proto, '_updateButtons', nativeUpdate => function (...args) {
            nativeUpdate.apply(this, args);
            const buttons = this.buttonLayout.get_children();
            // Le bouton de confirmation est le dernier, après « Annuler ».
            if (this._type === LOGOUT_DIALOG_TYPE && buttons.length > 1)
                buttons.at(-1).label = LOGOUT_TITLE;
        });
    }

    destroy() {
        this._injections.clear();
        this._injections = null;
    }
}
