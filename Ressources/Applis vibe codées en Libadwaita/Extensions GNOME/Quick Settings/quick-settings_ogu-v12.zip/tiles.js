// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
// Aucune importation GNOME Shell ici : ce fichier est aussi chargé par les préférences.
// Tuiles que l'on peut classer : identifiant → libellé (préférences) et origine.
// `native` : indicateur de GNOME Shell ; `feature` : clé de la fonction de l'extension.
export const TILES = [
    {id: 'network', title: 'Wi-Fi et réseau', native: '_network'},
    {id: 'bluetooth', title: 'Bluetooth', native: '_bluetooth'},
    {id: 'power-profiles', title: 'Énergie', native: '_powerProfiles'},
    {id: 'resources', title: 'Ressources', feature: 'resources-toggle'},
    {id: 'night-light', title: 'Éclairage nocturne', native: '_nightLight', feature: 'night-light-split'},
    {id: 'keyboard', title: 'Clavier', native: '_backlight'},
    {id: 'dark-mode', title: 'Style sombre', native: '_darkMode'},
    {id: 'rfkill', title: 'Mode avion', native: '_rfkill'},
    {id: 'auto-rotate', title: 'Rotation automatique', native: '_autoRotate'},
    {id: 'dropbox', title: 'Dropbox', feature: 'dropbox-toggle'},
    {id: 'update', title: 'Mise à jour', feature: 'update-toggle'},
    {id: 'usb', title: 'Clé USB', feature: 'usb-toggle'},
    {id: 'timer', title: 'Minuteur', feature: 'timer-toggle'},
    {id: 'close-apps', title: 'Tout fermer', feature: 'close-apps-toggle'},
    {id: 'projector', title: 'Projecteur', feature: 'projector-toggle'},
];

// Tuiles d'autres extensions (Caféine, Session, Chihiro…), repérées par leur titre.
const OTHER_PREFIX = 'other:';
export const otherId = title => `${OTHER_PREFIX}${title}`;
export const otherTitle = id => (id.startsWith(OTHER_PREFIX) ? id.slice(OTHER_PREFIX.length) : null);

// Complète un ordre enregistré : tuiles inconnues retirées, tuiles absentes ajoutées à la fin.
// `others` : titres des tuiles d'autres extensions vues par GNOME Shell (clé other-tiles).
export function completeOrder(order, others = []) {
    const known = [...TILES.map(tile => tile.id), ...others.map(otherId)];
    const kept = order.filter(id => known.includes(id));
    return [...kept, ...known.filter(id => !kept.includes(id))];
}
