// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {QuickMenuToggle, SystemIndicator} from 'resource:///org/gnome/shell/ui/quickSettings.js';

import {SEPARATOR, countdown, minutesLabel} from './format.js';
import {bundledIcon} from './icons.js';
import {showOsd} from './osd.js';

const PRESETS = [5, 10, 15, 30, 60];
const MAX_MINUTES = 180;
const SOUND = 'alarm-clock-elapsed';

const Mode = {IDLE: 0, RUNNING: 1, PAUSED: 2};

// Pas du réglage « Autre durée » : 1 min jusqu'à 10 min, puis 5 min jusqu'à 3 h.
const stepUp = minutes => Math.min(MAX_MINUTES, minutes < 10 ? minutes + 1 : minutes + 5 - (minutes % 5));
const stepDown = minutes => Math.max(1, minutes <= 10 ? minutes - 1 : minutes - 5 + ((5 - (minutes % 5)) % 5));

function iconButton(iconName, accessibleName, callback) {
    const button = new St.Button({
        style_class: 'icon-button',
        can_focus: true,
        accessible_name: accessibleName,
        child: new St.Icon({icon_name: iconName}),
    });
    button.connect('clicked', callback);
    return button;
}

// Ligne « Autre durée  [−] 20 min [+] [▶] » du menu du minuteur.
const CustomDuration = GObject.registerClass(
class CustomDuration extends St.BoxLayout {
    _init(minutes, onStart) {
        super._init({style_class: 'fb-timer-custom', x_expand: true});
        this._minutes = minutes;
        this.add_child(new St.Label({text: 'Autre durée', x_expand: true, y_align: Clutter.ActorAlign.CENTER}));
        this.add_child(iconButton('list-remove-symbolic', 'Moins', () => this._set(stepDown(this._minutes))));
        this._value = new St.Label({style_class: 'fb-timer-custom-value', y_align: Clutter.ActorAlign.CENTER});
        this.add_child(this._value);
        this.add_child(iconButton('list-add-symbolic', 'Plus', () => this._set(stepUp(this._minutes))));
        this.add_child(iconButton('media-playback-start-symbolic', 'Lancer', () => onStart(this._minutes)));
        this._set(minutes);
    }

    _set(minutes) {
        this._minutes = minutes;
        this._value.text = minutesLabel(minutes);
    }
});

// Tuile « Minuteur » : clic = lancer la dernière durée, mettre en pause ou reprendre ; flèche =
// 5, 10, 15, 30 min, 1 h, une autre durée (jusqu'à 3 h) et Arrêter. Le décompte s'affiche en
// sous-titre et, si on le veut, dans la barre du haut ; à la fin, un son, une bulle et une notification.
export const TimerIndicator = GObject.registerClass(
class TimerIndicator extends SystemIndicator {
    _init(settings) {
        super._init();
        this._settings = settings;
        this._minutes = settings.get_uint('timer-minutes');
        this._panelCountdown = settings.get_boolean('timer-panel-countdown');
        this._remaining = 0;
        this._endTime = 0;
        this._tickId = 0;
        this._mode = Mode.IDLE;

        this._indicator = this._addIndicator();
        this._indicator.gicon = bundledIcon('timer');
        this._label = new St.Label({style_class: 'fb-timer-label', y_align: Clutter.ActorAlign.CENTER});
        this.add_child(this._label);

        this._toggle = new QuickMenuToggle({title: 'Minuteur', gicon: bundledIcon('timer'), toggleMode: false});
        const menu = this._toggle.menu;
        menu.setHeader(bundledIcon('timer'), 'Minuteur');
        for (const minutes of PRESETS)
            menu.addAction(minutesLabel(minutes), () => this._start(minutes));
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        menu.box.add_child(new CustomDuration(this._minutes, minutes => this._start(minutes)));
        this._stopItem = menu.addAction('Arrêter', () => this._stop());
        this._toggle.connect('clicked', () => this._clicked());
        this.quickSettingsItems.push(this._toggle);
        this._sync();
    }

    set panelCountdown(shown) {
        this._panelCountdown = shown;
        this._sync();
    }

    _clicked() {
        if (this._mode === Mode.RUNNING)
            this._pause();
        else if (this._mode === Mode.PAUSED)
            this._resume();
        else
            this._start(this._minutes);
    }

    _start(minutes) {
        this._minutes = minutes;
        this._settings.set_uint('timer-minutes', minutes);
        this._remaining = minutes * 60;
        this._resume();
    }

    _resume() {
        this._mode = Mode.RUNNING;
        this._endTime = GLib.get_monotonic_time() + this._remaining * 1e6;
        if (this._tickId)
            GLib.Source.remove(this._tickId);
        this._tickId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 1, () => this._tick());
        this._sync();
    }

    _pause() {
        this._remaining = this._left();
        this._removeTick();
        this._mode = Mode.PAUSED;
        this._sync();
    }

    _stop() {
        this._removeTick();
        this._mode = Mode.IDLE;
        this._sync();
    }

    _left() {
        return Math.max(0, Math.ceil((this._endTime - GLib.get_monotonic_time()) / 1e6));
    }

    _tick() {
        this._remaining = this._left();
        if (this._remaining > 0) {
            this._sync();
            return GLib.SOURCE_CONTINUE;
        }
        this._tickId = 0;
        this._mode = Mode.IDLE;
        this._sync();
        global.display.get_sound_player().play_from_theme(SOUND, 'Minuteur écoulé', null);
        showOsd(bundledIcon('timer'), 'Temps écoulé');
        Main.notify('Minuteur terminé', `${minutesLabel(this._minutes)} écoulé${this._minutes >= 60 ? 'e' : 'es'}`);
        return GLib.SOURCE_REMOVE;
    }

    _removeTick() {
        if (this._tickId)
            GLib.Source.remove(this._tickId);
        this._tickId = 0;
    }

    _sync() {
        const active = this._mode !== Mode.IDLE;
        const time = countdown(this._remaining);
        this._toggle.checked = this._mode === Mode.RUNNING;
        if (this._mode === Mode.RUNNING)
            this._toggle.subtitle = time;
        else if (this._mode === Mode.PAUSED)
            this._toggle.subtitle = `En pause${SEPARATOR}${time}`;
        else
            this._toggle.subtitle = minutesLabel(this._minutes);
        this._stopItem.visible = active;
        this._label.text = time;
        this._label.visible = active && this._panelCountdown;
        this._indicator.visible = active;
    }

    destroy() {
        this._removeTick();
        this.quickSettingsItems.forEach(item => item.destroy());
        this.quickSettingsItems.length = 0;
        this._settings = null;
        super.destroy();
    }
});
