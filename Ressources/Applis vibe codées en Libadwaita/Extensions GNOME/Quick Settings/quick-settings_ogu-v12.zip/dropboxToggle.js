// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {QuickMenuToggle, SystemIndicator} from 'resource:///org/gnome/shell/ui/quickSettings.js';

import {bundledIcon} from './icons.js';

import {dropboxCommand, dropboxFolder, recentFiles} from './dropboxClient.js';

const DROPBOX_APP_ID = 'dropbox.desktop';
const WEBSITE = 'https://www.dropbox.com/home';
const RUNNING_POLL_S = 3;
const STOPPED_POLL_S = 10;
const RECENT_COUNT = 5;
const COPIED_FEEDBACK_S = 2;

// Dropbox écrit son état dans la langue de son interface : on reconnaît les deux.
const PAUSED = /paus|suspend/i;
const UP_TO_DATE = /up to date|à jour/i;
const SYNCING = /sync|upload|download|index|envoi|téléchargement|import/i;

const dropboxIcon = () => bundledIcon('cloud');
const launchContext = () => global.create_app_launch_context(0, -1);

// « Synchronisation de 1 234 fichiers… » → 1234 ; un seul fichier en cours sinon.
function remainingFiles(status) {
    const digits = status.match(/(\d[\d\u00a0\u202f ]*)\s*(?:files?|fichiers?)/i)?.[1];
    return digits ? Number(digits.replace(/\D/g, '')) : 1;
}

const RecentFileItem = GObject.registerClass(
class RecentFileItem extends PopupMenu.PopupBaseMenuItem {
    _init({file, info}, cancellable) {
        super._init({style_class: 'fb-dropbox-recent'});
        this._file = file;
        this._cancellable = cancellable;
        this._feedbackId = 0;
        this.add_child(new St.Icon({gicon: info.get_symbolic_icon(), style_class: 'popup-menu-icon'}));
        this.add_child(new St.Label({text: info.get_display_name(), x_expand: true, style_class: 'fb-dropbox-name'}));
        this._linkIcon = new St.Icon({icon_name: 'insert-link-symbolic'});
        this._linkButton = new St.Button({style_class: 'icon-button fb-dropbox-link', child: this._linkIcon,
            accessible_name: 'Copier le lien de partage'});
        this._linkButton.connect('clicked', () => this._copyLink());
        this.add_child(this._linkButton);
        this.connect('activate', () => {
            Main.panel.closeQuickSettings();
            Gio.AppInfo.launch_default_for_uri(this._file.get_uri(), launchContext());
        });
    }

    async _copyLink() {
        let iconName = 'object-select-symbolic';
        try {
            const reply = await dropboxCommand('get_shared_link', {path: this._file.get_path()}, this._cancellable);
            St.Clipboard.get_default().set_text(St.ClipboardType.CLIPBOARD, reply.link[0]);
        } catch (error) {
            if (error.matches?.(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED))
                return;
            iconName = 'dialog-error-symbolic';
        }
        this._linkIcon.icon_name = iconName;
        if (this._feedbackId)
            GLib.Source.remove(this._feedbackId);
        this._feedbackId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, COPIED_FEEDBACK_S, () => {
            this._feedbackId = 0;
            this._linkIcon.icon_name = 'insert-link-symbolic';
            return GLib.SOURCE_REMOVE;
        });
    }

    destroy() {
        if (this._feedbackId)
            GLib.Source.remove(this._feedbackId);
        this._feedbackId = 0;
        super.destroy();
    }
});

const DropboxToggle = GObject.registerClass(
class DropboxToggle extends QuickMenuToggle {
    _init(actions) {
        super._init({title: 'Dropbox', subtitle: '…', gicon: dropboxIcon(), toggleMode: false});
        this.menu.setHeader(dropboxIcon(), 'Dropbox');
        this.recentSection = new PopupMenu.PopupMenuSection();
        this.menu.addMenuItem(this.recentSection);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this._runItem = this.menu.addAction('', () => actions.toggleRunning());
        this.menu.addAction('Ouvrir le site web', () => {
            Main.panel.closeQuickSettings();
            Gio.AppInfo.launch_default_for_uri(WEBSITE, launchContext());
        });
        this.connect('clicked', () => actions.openFolder());
    }

    setState({running, paused, pausedByUs, status}) {
        this.checked = running && !paused;
        if (running)
            this.subtitle = status || 'Démarrage…';
        else
            this.subtitle = pausedByUs ? 'En pause' : 'Arrêté';
        this.menu.setHeader(dropboxIcon(), 'Dropbox', this.subtitle);
        if (running)
            this._runItem.label.text = 'Mettre en pause';
        else
            this._runItem.label.text = pausedByUs ? 'Reprendre' : 'Démarrer Dropbox';
    }
});

// Tuile Dropbox : bleue quand Dropbox tourne, clic = dossier Dropbox, flèche =
// fichiers récents (avec lien de partage), pause et site web. La synchro en
// cours alimente l'anneau des transferts, s'il est activé.
export const DropboxIndicator = GObject.registerClass(
class DropboxIndicator extends SystemIndicator {
    _init(transferIndicator) {
        super._init();
        this._transferIndicator = transferIndicator;
        this._cancellable = new Gio.Cancellable();
        this._appInfo = Gio.DesktopAppInfo.new(DROPBOX_APP_ID);
        this._pollId = 0;
        this._folder = null;
        this._state = {running: false, paused: false, pausedByUs: false, status: ''};
        this._syncStart = 0;

        this._toggle = new DropboxToggle({
            openFolder: () => this._openFolder(),
            toggleRunning: () => this._toggleRunning(),
        });
        this.quickSettingsItems.push(this._toggle);
        this._menuId = this._toggle.menu.connect('open-state-changed', (_menu, open) => {
            if (open)
                this._fillRecent();
        });

        dropboxFolder(this._cancellable).then(folder => (this._folder = folder));
        this._poll();
    }

    _schedule(seconds) {
        if (this._pollId)
            GLib.Source.remove(this._pollId);
        this._pollId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, seconds, () => {
            this._pollId = 0;
            this._poll();
            return GLib.SOURCE_REMOVE;
        });
    }

    async _poll() {
        let status = null;
        try {
            const reply = await dropboxCommand('get_dropbox_status', {}, this._cancellable);
            status = (reply.status ?? []).join(' ').trim();
        } catch (error) {
            if (error.matches?.(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED))
                return;
        }
        const running = status !== null;
        this._state = {
            running,
            paused: running && PAUSED.test(status),
            pausedByUs: !running && this._state.pausedByUs,
            status: status ?? '',
        };
        this._toggle.setState(this._state);
        this._publishSync();
        this._schedule(running ? RUNNING_POLL_S : STOPPED_POLL_S);
    }

    _publishSync() {
        const {running, paused, status} = this._state;
        const syncing = running && !paused && !UP_TO_DATE.test(status) && SYNCING.test(status);
        if (!syncing) {
            this._syncStart = 0;
            this._transferIndicator?.setLocal('dropbox', this._appInfo, 'Dropbox', null);
            return;
        }
        const remaining = remainingFiles(status);
        this._syncStart = Math.max(this._syncStart, remaining);
        this._transferIndicator?.setLocal('dropbox', this._appInfo, 'Dropbox', {
            progress: (this._syncStart - remaining) / this._syncStart,
            title: 'Synchronisation Dropbox',
            detail: status,
        });
    }

    _openFolder() {
        Main.panel.closeQuickSettings();
        const folder = this._folder ?? GLib.build_filenamev([GLib.get_home_dir(), 'Dropbox']);
        Gio.AppInfo.launch_default_for_uri(Gio.File.new_for_path(folder).get_uri(), launchContext());
    }

    async _toggleRunning() {
        if (this._state.running) {
            // Dropbox pour Linux n'a pas de pause : on le quitte, « Reprendre » le relance.
            try {
                await dropboxCommand('tray_action_hard_exit', {}, this._cancellable);
            } catch (error) {
                if (error.matches?.(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED))
                    return;
            }
            this._state.pausedByUs = true;
        } else {
            this._appInfo?.launch([], launchContext());
        }
        this._schedule(1);
    }

    async _fillRecent() {
        this._toggle.recentSection.removeAll();
        if (!this._folder)
            return;
        let files;
        try {
            files = await recentFiles(this._folder, RECENT_COUNT, this._cancellable);
        } catch {
            return;
        }
        if (!this._toggle.menu.isOpen)
            return;
        this._toggle.recentSection.removeAll();
        for (const entry of files)
            this._toggle.recentSection.addMenuItem(new RecentFileItem(entry, this._cancellable));
    }

    destroy() {
        if (this._pollId)
            GLib.Source.remove(this._pollId);
        this._pollId = 0;
        this._cancellable.cancel();
        this._toggle.menu.disconnect(this._menuId);
        this._transferIndicator?.setLocal('dropbox', this._appInfo, 'Dropbox', null);
        this._transferIndicator = null;
        this.quickSettingsItems.forEach(item => item.destroy());
        this.quickSettingsItems.length = 0;
        super.destroy();
    }
});
