// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GObject from 'gi://GObject';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {QuickMenuToggle} from 'resource:///org/gnome/shell/ui/quickSettings.js';
import {Slider} from 'resource:///org/gnome/shell/ui/slider.js';

const ICON = 'night-light-symbolic';
// Mêmes bornes que le curseur de Paramètres (Kelvin) : à droite, plus chaud.
const COLDEST = 4700;
const WARMEST = 1700;

const toSlider = kelvin => (COLDEST - kelvin) / (COLDEST - WARMEST);
const toKelvin = value => Math.round(COLDEST - value * (COLDEST - WARMEST));

// Pilule Éclairage nocturne scindée : clic = allumer/éteindre, flèche =
// curseur de température. Elle remplace la pilule native, remise en place à la
// désactivation.
const NightLightToggle = GObject.registerClass(
class NightLightToggle extends QuickMenuToggle {
    _init(title) {
        super._init({title, iconName: ICON, toggleMode: true});
        this._settings = new Gio.Settings({schema_id: 'org.gnome.settings-daemon.plugins.color'});
        this._settings.bind('night-light-enabled', this, 'checked', Gio.SettingsBindFlags.DEFAULT);
        global.backend.get_monitor_manager().bind_property('night-light-supported', this, 'visible',
            GObject.BindingFlags.SYNC_CREATE);

        this.menu.setHeader(ICON, title, 'Température des couleurs');
        this._slider = new Slider(toSlider(this._settings.get_uint('night-light-temperature')));
        this._slider.accessible_name = 'Température de l’éclairage nocturne';
        this._sliderId = this._slider.connect('notify::value', () => {
            if (!this._syncing)
                this._settings.set_uint('night-light-temperature', toKelvin(this._slider.value));
        });
        const sliderItem = new PopupMenu.PopupBaseMenuItem({activate: false, style_class: 'fb-night-slider-item'});
        sliderItem.add_child(new St.Icon({icon_name: 'weather-clear-symbolic', style_class: 'popup-menu-icon'}));
        this._slider.x_expand = true;
        sliderItem.add_child(this._slider);
        sliderItem.add_child(new St.Icon({icon_name: ICON, style_class: 'popup-menu-icon'}));
        this.menu.addMenuItem(sliderItem);
        this._temperatureId = this._settings.connect('changed::night-light-temperature', () => this._syncSlider());
    }

    _syncSlider() {
        this._syncing = true;
        this._slider.value = toSlider(this._settings.get_uint('night-light-temperature'));
        this._syncing = false;
    }

    destroy() {
        this._settings.disconnect(this._temperatureId);
        this._settings = null;
        super.destroy();
    }
});

function findNative(grid) {
    return grid.get_children().find(child => child.icon_name === ICON && !(child instanceof NightLightToggle)) ?? null;
}

export class NightLightSplit {
    constructor() {
        this._menu = Main.panel.statusArea.quickSettings.menu;
        this._native = findNative(this._menu._grid);
        if (!this._native)
            throw new Error('pilule Éclairage nocturne introuvable');
        this._toggle = new NightLightToggle(this._native.title);
        this._menu.insertItemBefore(this._toggle, this._native);
        this._menu._grid.remove_child(this._native);
    }

    get quickSettingsItems() {
        return this._toggle ? [this._toggle] : [];
    }

    destroy() {
        this._menu._grid.insert_child_above(this._native, this._toggle);
        this._toggle.destroy();
        this._toggle = null;
        this._native = null;
        this._menu = null;
    }
}
