// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import Gtk from 'gi://Gtk';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

import {KeepAppsGroup} from './prefs/keepAppsGroup.js';
import {TileOrderGroup} from './prefs/tileOrderGroup.js';

const BATTERY_FORMATS = [
    ['time-percent', 'Temps · pourcentage (2 h 30 · 85 %)'],
    ['percent-time', 'Pourcentage · temps (85 % · 2 h 30)'],
    ['time', 'Temps seul'],
    ['percent', 'Pourcentage seul'],
];

function switchGroup(settings, title, rows) {
    const group = new Adw.PreferencesGroup({title});
    for (const [key, rowTitle, subtitle] of rows) {
        const row = new Adw.SwitchRow({title: rowTitle, subtitle});
        settings.bind(key, row, 'active', Gio.SettingsBindFlags.DEFAULT);
        group.add(row);
    }
    return group;
}

function delayRow(settings) {
    const row = new Adw.SpinRow({
        title: 'Délai de fermeture',
        subtitle: 'En millisecondes, 350 par défaut',
        adjustment: new Gtk.Adjustment({lower: 100, upper: 2000, step_increment: 50, page_increment: 100}),
    });
    settings.bind('close-delay-ms', row, 'value', Gio.SettingsBindFlags.DEFAULT);
    return row;
}

function updateCommandRow(settings) {
    const row = new Adw.EntryRow({title: 'Script de la tuile Mise à jour', text: settings.get_string('update-command'),
        show_apply_button: true});
    row.connect('apply', () => settings.set_string('update-command', row.text));
    return row;
}

function batteryFormatRow(settings) {
    const row = new Adw.ComboRow({
        title: 'Affichage dans la barre du haut',
        model: Gtk.StringList.new(BATTERY_FORMATS.map(([, label]) => label)),
        selected: Math.max(0, BATTERY_FORMATS.findIndex(([nick]) => nick === settings.get_string('battery-panel-format'))),
    });
    row.connect('notify::selected', () => settings.set_string('battery-panel-format', BATTERY_FORMATS[row.selected][0]));
    return row;
}

export default class QuickSettingsPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();

        const quickPage = new Adw.PreferencesPage({title: 'Réglages rapides', icon_name: 'emblem-system-symbolic'});
        const focus = switchGroup(settings, 'Fermeture automatique', [
            ['auto-close', 'Fermer Quick Settings', 'Quand le pointeur sort du panneau.'],
        ]);
        focus.add(delayRow(settings));
        quickPage.add(focus);

        quickPage.add(switchGroup(settings, 'Rangée système', [
            ['hide-screenshot', 'Masquer Capture d’écran', 'La capture reste disponible avec les raccourcis GNOME.'],
            ['split-settings-button', 'Bouton Réglages scindé', 'Clic : Paramètres. Chevron : Ajustements, dconf et Extensions.'],
            ['split-power-button', 'Bouton Power scindé', 'Clic : Éteindre. Chevron : Suspendre, Redémarrer, Reconnexion et Verrouiller.'],
            ['logout-dialog-label', 'Fenêtre « Reconnexion »', 'Dans la confirmation de GNOME, « Reconnexion » à la place de « Fermer la session ».'],
        ]));

        const tiles = switchGroup(settings, 'Tuiles et pilules', [
            ['resources-toggle', 'Ressources', 'Clic : appli Ressources. Flèche : le détail. Bleue quand le processeur dépasse 80 %.'],
            ['dropbox-toggle', 'Dropbox', 'Bleue quand Dropbox tourne. Clic : dossier. Flèche : fichiers récents, pause, site web.'],
            ['update-toggle', 'Mise à jour', 'Un clic lance le script ci-dessous ; bleue tant qu’il tourne.'],
            ['close-apps-toggle', 'Tout fermer', 'Sous-titre : nombre de fenêtres ouvertes. Premier clic : « Fermer N fenêtres ? ». Second clic : chaque fenêtre se ferme comme avec sa croix.'],
            ['usb-toggle', 'Clé USB', 'Visible quand une clé est branchée, avec une icône dans la barre du haut. Clic : éjecter. Flèche : Ouvrir, Ouvrir dans Fret.'],
            ['timer-toggle', 'Minuteur', 'Clic : relancer la dernière durée, pause, reprise. Flèche : 5, 10, 15, 30 min, 1 h ou une autre durée. Un son à la fin.'],
            ['timer-panel-countdown', 'Décompte dans la barre du haut', 'Sinon, seule l’icône du minuteur s’y affiche.'],
            ['night-light-split', 'Éclairage nocturne scindé', 'Clic : allumer ou éteindre. Flèche : température.'],
            ['charge-limit-toggle', 'Limite de charge', 'Interrupteur « Limiter la charge à 80 % » dans le menu Énergie (réglage « Préserver la santé de la batterie »).'],
            ['projector-toggle', 'Projecteur', 'Dupliquer, Étendre ou un seul écran, quand un deuxième écran est branché.'],
        ]);
        tiles.add(updateCommandRow(settings));
        quickPage.add(tiles);
        quickPage.add(new TileOrderGroup(settings));
        quickPage.add(new KeepAppsGroup(settings));

        quickPage.add(switchGroup(settings, 'Libellés, icônes et son', [
            ['rename-power-profile', 'Libellé « Énergie »', '« Énergie » pour le mode d’alimentation, « Économie » pour l’économie d’énergie.'],
            ['keyboard-icon', 'Icône « Clavier »', 'Un clavier éclairé au lieu du soleil sur la tuile d’éclairage du clavier.'],
            ['hide-audio-outputs', 'Masquer les sorties audio', 'Plus de chevron sur le volume : seule la sortie par défaut est utilisée.'],
            ['volume-osd', 'OSD du volume', 'Afficher l’OSD de GNOME quand on bouge le curseur de volume.'],
        ]));
        quickPage.add(switchGroup(settings, 'Bulles OSD', [
            ['osd-lock-keys', 'Verr. Maj et Verr. Num', 'À chaque appui : le Zenbook n’a pas de voyant.'],
            ['osd-charger', 'Chargeur', 'Branché : « En charge · 64 % ». Retiré : « Sur batterie · 5 h 20 ».'],
            ['osd-charge-limit', 'Charge arrêtée', 'Quand la charge s’arrête à la limite choisie.'],
            ['osd-usb', 'Clé USB', '« Clé prête » au branchement, « Vous pouvez la retirer » après l’éjection.'],
            ['osd-power-profile', 'Mode d’énergie', 'Quand il change hors de Quick Settings (raccourci, passage automatique).'],
        ]));
        window.add(quickPage);

        const panelPage = new Adw.PreferencesPage({title: 'Barre du haut', icon_name: 'video-display-symbolic'});
        const battery = switchGroup(settings, 'Batterie', [
            ['battery-labels', 'Textes de la batterie', 'Temps restant et pourcentage dans la barre, temps et watts dans Quick Settings.'],
            ['battery-quick-watts', 'Watts dans Quick Settings', 'La consommation instantanée après le temps restant.'],
        ]);
        battery.add(batteryFormatRow(settings));
        panelPage.add(battery);
        panelPage.add(switchGroup(settings, 'Transferts', [
            ['transfer-indicator', 'Anneau des transferts', 'Pendant une copie de Fret, un téléchargement de Grabber ou une synchro Dropbox ; disparaît à la fin.'],
        ]));
        window.add(panelPage);
    }
}
