// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
// Aucune importation GNOME Shell ici : formats français communs (batterie, Ressources, préférences).
export const NNBSP = ' ';
export const SEPARATOR = ' · ';

export const decimal = (value, digits = 1) => value.toFixed(digits).replace('.', ',');
export const percent = fraction => `${Math.round(fraction * 100)}${NNBSP}%`;

export function duration(hours) {
    const minutes = Math.round(hours * 60);
    return `${Math.floor(minutes / 60)}${NNBSP}h${NNBSP}${String(minutes % 60).padStart(2, '0')}`;
}

export function gigabytes(bytes) {
    const value = bytes / 1e9;
    return `${value >= 100 ? Math.round(value) : decimal(value)}${NNBSP}Go`;
}

// Décompte du minuteur : « 4:05 », « 1:02:30 ».
export function countdown(seconds) {
    const pad = value => String(value).padStart(2, '0');
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return hours ? `${hours}:${pad(minutes)}:${pad(seconds % 60)}` : `${minutes}:${pad(seconds % 60)}`;
}

// Durée en minutes : « 20 min », « 1 h », « 1 h 30 ».
export function minutesLabel(total) {
    const hours = Math.floor(total / 60);
    const minutes = total % 60;
    if (!hours)
        return `${minutes}${NNBSP}min`;
    return minutes ? `${hours}${NNBSP}h${NNBSP}${String(minutes).padStart(2, '0')}` : `${hours}${NNBSP}h`;
}
