// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import UPower from 'gi://UPowerGlib';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import {NNBSP, SEPARATOR, duration} from './format.js';

const UPOWER = 'org.freedesktop.UPower';
const DISPLAY_DEVICE = '/org/freedesktop/UPower/devices/DisplayDevice';
const PROFILES_BUS = 'org.freedesktop.UPower.PowerProfiles';
const PROFILES_PATH = '/org/freedesktop/UPower/PowerProfiles';

const PROFILES = {
    'power-saver': ['Économie', 'power-profile-power-saver-symbolic'],
    'balanced': ['Équilibré', 'power-profile-balanced-symbolic'],
    'performance': ['Performance', 'power-profile-performance-symbolic'],
};

const BatteryProxy = Gio.DBusProxy.makeProxyWrapper(`
<node>
  <interface name="org.freedesktop.UPower.Device">
    <property name="IsPresent" type="b" access="read"/>
    <property name="State" type="u" access="read"/>
    <property name="Percentage" type="d" access="read"/>
    <property name="TimeToEmpty" type="x" access="read"/>
  </interface>
</node>`);

const ProfilesProxy = Gio.DBusProxy.makeProxyWrapper(`
<node>
  <interface name="org.freedesktop.UPower.PowerProfiles">
    <property name="ActiveProfile" type="s" access="read"/>
  </interface>
</node>`);

// Bulle OSD de GNOME sur l'écran principal, comme celles du volume ou de la luminosité.
// `icon` : nom d'icône du thème ou Gio.Icon.
export function showOsd(icon, label, level = null) {
    const gicon = typeof icon === 'string' ? Gio.ThemedIcon.new(icon) : icon;
    Main.osdWindowManager.showOne(Main.layoutManager.primaryIndex, gicon, label, level);
}

function batteryIcon(percentage, charging) {
    const level = Math.min(100, Math.round(percentage / 10) * 10);
    return `battery-level-${level}${charging ? '-charging' : ''}-symbolic`;
}

// Verr. Maj et Verr. Num : le Zenbook n'a pas de voyant.
export class LockKeysOsd {
    constructor() {
        this._keymap = global.stage.context.get_backend().get_default_seat().get_keymap();
        this._caps = this._keymap.get_caps_lock_state();
        this._num = this._keymap.get_num_lock_state();
        this._keymapId = this._keymap.connect('state-changed', () => this._changed());
    }

    _changed() {
        const caps = this._keymap.get_caps_lock_state();
        const num = this._keymap.get_num_lock_state();
        if (caps !== this._caps)
            showOsd('input-keyboard-symbolic', caps ? 'Majuscules verrouillées' : 'Majuscules déverrouillées');
        else if (num !== this._num)
            showOsd('input-keyboard-symbolic', num ? 'Pavé numérique activé' : 'Pavé numérique désactivé');
        this._caps = caps;
        this._num = num;
    }

    destroy() {
        this._keymap.disconnect(this._keymapId);
        this._keymap = null;
    }
}

// Bulles liées à l'alimentation : chargeur branché ou retiré, charge arrêtée à la limite, mode
// d'énergie changé hors de Quick Settings (raccourci, Power Total, passage automatique).
// Quand le mode change juste après un branchement (Power Total), une seule bulle les réunit :
// « En charge · 64 % · Performance ».
const MERGE_WINDOW_US = 3 * GLib.USEC_PER_SEC;

export class PowerOsd {
    constructor({charger, chargeLimit, profile}) {
        this._charger = charger;
        this._chargeLimit = chargeLimit;
        this._profile = profile;
        this._quickMenu = Main.panel.statusArea.quickSettings.menu;
        this._battery = null;
        this._batteryId = 0;
        this._state = null;
        this._profiles = null;
        this._profilesId = 0;
        this._activeProfile = null;
        this._lastPlug = null;
        this._cancellable = new Gio.Cancellable();

        if (charger || chargeLimit) {
            new BatteryProxy(Gio.DBus.system, UPOWER, DISPLAY_DEVICE, (proxy, error) => {
                if (error)
                    return;
                this._battery = proxy;
                this._state = proxy.State;
                this._batteryId = proxy.connect('g-properties-changed', () => this._batteryChanged());
            }, this._cancellable);
        }
        if (profile) {
            new ProfilesProxy(Gio.DBus.system, PROFILES_BUS, PROFILES_PATH, (proxy, error) => {
                if (error)
                    return;
                this._profiles = proxy;
                this._activeProfile = proxy.ActiveProfile;
                this._profilesId = proxy.connect('g-properties-changed', () => this._profileChanged());
            }, this._cancellable);
        }
    }

    _batteryChanged() {
        const {State: state, Percentage: percentage, IsPresent: present} = this._battery;
        const previous = this._state;
        this._state = state;
        if (!present || state === previous || state === UPower.DeviceState.UNKNOWN)
            return;
        const level = `${Math.round(percentage)}${NNBSP}%`;
        const plugged = state !== UPower.DeviceState.DISCHARGING;
        const wasPlugged = previous !== UPower.DeviceState.DISCHARGING && previous !== UPower.DeviceState.UNKNOWN;
        const limited = state === UPower.DeviceState.PENDING_CHARGE;

        if (this._charger && plugged !== wasPlugged) {
            let text;
            if (plugged)
                text = limited ? `Branché${SEPARATOR}charge limitée à ${level}` : `En charge${SEPARATOR}${level}`;
            else if (this._battery.TimeToEmpty > 0)
                text = `Sur batterie${SEPARATOR}${duration(this._battery.TimeToEmpty / 3600)}`;
            else
                text = `Sur batterie${SEPARATOR}${level}`;
            this._lastPlug = {icon: batteryIcon(percentage, plugged), text, level: percentage / 100, time: GLib.get_monotonic_time()};
            showOsd(this._lastPlug.icon, text, this._lastPlug.level);
        } else if (this._chargeLimit && limited && wasPlugged) {
            showOsd(batteryIcon(percentage, false), `Charge arrêtée à ${level}`, percentage / 100);
        }
    }

    _profileChanged() {
        const profile = this._profiles.ActiveProfile;
        if (profile === this._activeProfile)
            return;
        this._activeProfile = profile;
        if (this._quickMenu.isOpen || !(profile in PROFILES))
            return;
        const [name, icon] = PROFILES[profile];
        const plug = this._lastPlug;
        if (plug && GLib.get_monotonic_time() - plug.time < MERGE_WINDOW_US)
            showOsd(plug.icon, `${plug.text}${SEPARATOR}${name}`, plug.level);
        else
            showOsd(icon, `Énergie${SEPARATOR}${name}`);
    }

    destroy() {
        this._cancellable.cancel();
        if (this._batteryId)
            this._battery.disconnect(this._batteryId);
        if (this._profilesId)
            this._profiles.disconnect(this._profilesId);
        this._battery = null;
        this._profiles = null;
        this._quickMenu = null;
    }
}
