// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Gio from 'gi://Gio';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as Volume from 'resource:///org/gnome/shell/ui/status/volume.js';

// Retire le chevron du curseur de volume : GNOME recalcule `menuEnabled` à
// chaque branchement de sortie, on le remet donc à faux à chaque fois.
export class HiddenAudioOutputs {
    constructor() {
        this._slider = Main.panel.statusArea.quickSettings._volumeOutput._output;
        this._menuId = this._slider.connect('notify::menu-enabled', () => {
            if (this._slider.menuEnabled)
                this._slider.menuEnabled = false;
        });
        this._slider.menu.close(false);
        this._slider.menuEnabled = false;
    }

    destroy() {
        this._slider.disconnect(this._menuId);
        this._slider._sync();
        this._slider = null;
    }
}

function volumeIcon(level, muted) {
    if (muted || level === 0)
        return 'audio-volume-muted-symbolic';
    if (level < 0.34)
        return 'audio-volume-low-symbolic';
    return level < 0.67 ? 'audio-volume-medium-symbolic' : 'audio-volume-high-symbolic';
}

// OSD de GNOME quand on bouge le curseur de volume de Quick Settings (les
// touches du clavier ont déjà le leur) : on suit la sortie par défaut.
export class VolumeOsd {
    constructor() {
        this._quickMenu = Main.panel.statusArea.quickSettings.menu;
        this._mixer = Volume.getMixerControl();
        this._sink = null;
        this._sinkIds = [];
        this._mixerIds = [
            this._mixer.connect('default-sink-changed', () => this._attach()),
            this._mixer.connect('state-changed', () => this._attach()),
        ];
        this._attach();
    }

    _attach() {
        this._detach();
        this._sink = this._mixer.get_default_sink();
        if (!this._sink)
            return;
        this._sinkIds = ['notify::volume', 'notify::is-muted'].map(signal => this._sink.connect(signal, () => this._show()));
    }

    _detach() {
        this._sinkIds.forEach(id => this._sink.disconnect(id));
        this._sinkIds = [];
        this._sink = null;
    }

    _show() {
        if (!this._quickMenu.isOpen)
            return;
        const level = Math.max(0, this._sink.volume / this._mixer.get_vol_max_norm());
        const muted = this._sink.is_muted;
        Main.osdWindowManager.showOne(Main.layoutManager.primaryIndex, Gio.ThemedIcon.new(volumeIcon(level, muted)),
            `${Math.round(level * 100)} %`, muted ? 0 : level, Math.max(1, level));
    }

    destroy() {
        this._detach();
        this._mixerIds.forEach(id => this._mixer.disconnect(id));
        this._mixerIds = [];
        this._mixer = null;
        this._quickMenu = null;
    }
}
