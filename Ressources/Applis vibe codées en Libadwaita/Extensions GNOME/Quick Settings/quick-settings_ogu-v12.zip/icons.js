// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Gio from 'gi://Gio';
import St from 'gi://St';

// Icônes symboliques livrées avec l'extension (icons/<nom>-symbolic.svg) : GNOME Shell les
// recolore comme les autres icônes symboliques, quel que soit le thème d'icônes installé.
const DIR = Gio.File.new_for_uri(import.meta.url).get_parent();

export function bundledIcon(name) {
    return new Gio.FileIcon({file: DIR.get_child('icons').get_child(`${name}-symbolic.svg`)});
}

// Première icône symbolique du thème parmi `names` ; à défaut, celle livrée avec l'extension.
export function themedOrBundledIcon(names, fallback) {
    const theme = new St.IconTheme();
    const found = names.find(name => theme.has_icon(name));
    return found ? Gio.ThemedIcon.new(found) : bundledIcon(fallback);
}
