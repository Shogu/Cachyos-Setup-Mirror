// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Gio from 'gi://Gio';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';

Gio._promisify(Gio.DBusConnection.prototype, 'call');

const UPOWER = 'org.freedesktop.UPower';
const BATTERY_TYPE = 2;
// Position dans le menu Énergie : après les profils et leur séparateur, avant « Paramètres d'énergie ».
const MENU_POSITION = 2;

const DeviceProxy = Gio.DBusProxy.makeProxyWrapper(`
<node>
  <interface name="org.freedesktop.UPower.Device">
    <method name="EnableChargeThreshold"><arg type="b" direction="in"/></method>
    <property name="Type" type="u" access="read"/>
    <property name="PowerSupply" type="b" access="read"/>
    <property name="ChargeThresholdSupported" type="b" access="read"/>
    <property name="ChargeThresholdEnabled" type="b" access="read"/>
    <property name="ChargeEndThreshold" type="u" access="read"/>
  </interface>
</node>`);

function deviceProxy(path, cancellable) {
    return new Promise((resolve, reject) => {
        new DeviceProxy(Gio.DBus.system, UPOWER, path,
            (proxy, error) => (error ? reject(error) : resolve(proxy)), cancellable);
    });
}

// Batterie interne qui accepte une limite de charge (UPower), ou null.
export async function findChargeLimitBattery(cancellable) {
    const reply = await Gio.DBus.system.call(UPOWER, '/org/freedesktop/UPower', UPOWER, 'EnumerateDevices',
        null, null, Gio.DBusCallFlags.NONE, -1, cancellable);
    for (const path of reply.deepUnpack()[0]) {
        const device = await deviceProxy(path, cancellable);
        if (device.Type === BATTERY_TYPE && device.PowerSupply && device.ChargeThresholdSupported)
            return device;
    }
    return null;
}

// Interrupteur « Limiter la charge à 80 % » dans le menu de la tuile Énergie : le même réglage
// que « Préserver la santé de la batterie » dans Paramètres. Absent si la batterie ne le gère pas.
export class ChargeLimitMenuItem {
    constructor() {
        this._menu = Main.panel.statusArea.quickSettings._powerProfiles.quickSettingsItems[0].menu;
        this._item = null;
        this._device = null;
        this._propertiesId = 0;
        this._cancellable = new Gio.Cancellable();
        this._attach();
    }

    async _attach() {
        try {
            this._device = await findChargeLimitBattery(this._cancellable);
        } catch (error) {
            if (!error.matches(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED))
                console.warn(`Quick Settings : limite de charge indisponible — ${error.message}`);
            return;
        }
        if (!this._device)
            return;
        this._item = new PopupMenu.PopupSwitchMenuItem('', false);
        this._item.connect('toggled', (_item, state) => {
            if (state !== this._device.ChargeThresholdEnabled)
                this._device.EnableChargeThresholdAsync(state).catch(logError);
        });
        this._menu.addMenuItem(this._item, MENU_POSITION);
        this._propertiesId = this._device.connect('g-properties-changed', () => this._sync());
        this._sync();
    }

    _sync() {
        const end = this._device.ChargeEndThreshold;
        this._item.label.text = `Limiter la charge à ${end <= 100 ? end : 80} %`;
        this._item.setToggleState(this._device.ChargeThresholdEnabled);
    }

    destroy() {
        this._cancellable.cancel();
        if (this._propertiesId)
            this._device.disconnect(this._propertiesId);
        this._item?.destroy();
        this._item = null;
        this._device = null;
        this._menu = null;
    }
}
