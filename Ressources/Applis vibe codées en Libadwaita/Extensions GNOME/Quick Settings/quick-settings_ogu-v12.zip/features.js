// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import {HiddenAudioOutputs, VolumeOsd} from './audio.js';
import {HoverAutoClose} from './autoClose.js';
import {BatteryLabels} from './batteryLabels.js';
import {ChargeLimitMenuItem} from './chargeLimit.js';
import {CloseAppsIndicator} from './closeAppsToggle.js';
import {DropboxIndicator} from './dropboxToggle.js';
import {LogoutDialogLabel} from './logoutDialog.js';
import {NightLightSplit} from './nightLightToggle.js';
import {LockKeysOsd, PowerOsd} from './osd.js';
import {ProjectorIndicator} from './projectorToggle.js';
import {HiddenScreenshotButton} from './quickSettingsUtils.js';
import {ResourcesIndicator} from './resourcesToggle.js';
import {powerSplit, settingsSplit} from './splitButtons.js';
import {TimerIndicator} from './timerToggle.js';
import {KeyboardIcon, PowerProfileLabel} from './toggleLabels.js';
import {addTransferIndicator} from './transferIndicator.js';
import {UpdateIndicator} from './updateToggle.js';
import {UsbIndicator} from './usbToggle.js';

function tile(indicator) {
    Main.panel.statusArea.quickSettings.addExternalIndicator(indicator);
    return indicator;
}

// Fiche d'un module :
//   id       identifiant (aussi utilisé par tiles.js pour le classement des tuiles) ;
//   switches interrupteurs qui l'allument (au moins un actif), par défaut [id] ;
//   options  réglages lus à la création : leur changement recrée ce seul module ;
//   live     réglages appliqués sur place, sans recréer le module ;
//   needs    modules dont il dépend : recréés, ils entraînent sa recréation ;
//   create   fabrique ; l'objet renvoyé défait tout ce qu'il a changé dans destroy().
function feature({id, switches = [id], options = [], live = {}, needs = [], create}) {
    return {id, switches, options, live, needs, create};
}

const POWER_OSD_SWITCHES = ['osd-charger', 'osd-charge-limit', 'osd-power-profile'];

// L'ordre compte : un module est créé après ceux dont il dépend.
export const FEATURES = [
    feature({
        id: 'auto-close',
        live: {'close-delay-ms': (autoClose, settings) => (autoClose.delay = settings.get_uint('close-delay-ms'))},
        create: settings => new HoverAutoClose(Main.panel.statusArea.quickSettings.menu,
            () => Main.panel.closeQuickSettings(), settings.get_uint('close-delay-ms')),
    }),
    feature({
        id: 'transfer-indicator',
        options: ['transfer-apps'],
        create: settings => addTransferIndicator(settings.get_strv('transfer-apps')),
    }),
    feature({
        id: 'battery-labels',
        live: {
            'battery-panel-format': labels => labels.refresh(),
            'battery-quick-watts': labels => labels.refresh(),
        },
        create: settings => new BatteryLabels(settings),
    }),
    feature({id: 'hide-screenshot', create: () => new HiddenScreenshotButton()}),
    feature({id: 'split-settings-button', create: () => settingsSplit()}),
    feature({id: 'split-power-button', create: () => powerSplit()}),
    feature({id: 'logout-dialog-label', create: () => new LogoutDialogLabel()}),
    feature({id: 'charge-limit-toggle', create: () => new ChargeLimitMenuItem()}),
    feature({id: 'projector-toggle', create: () => tile(new ProjectorIndicator())}),
    feature({
        id: 'update-toggle',
        options: ['update-command'],
        create: settings => tile(new UpdateIndicator(settings.get_string('update-command'))),
    }),
    feature({
        id: 'usb-toggle',
        options: ['osd-usb'],
        create: settings => tile(new UsbIndicator(settings.get_boolean('osd-usb'))),
    }),
    feature({
        id: 'timer-toggle',
        live: {'timer-panel-countdown': (timer, settings) => (timer.panelCountdown = settings.get_boolean('timer-panel-countdown'))},
        create: settings => tile(new TimerIndicator(settings)),
    }),
    feature({
        id: 'close-apps-toggle',
        options: ['close-apps-keep'],
        create: settings => tile(new CloseAppsIndicator(settings.get_strv('close-apps-keep'))),
    }),
    feature({id: 'resources-toggle', create: () => tile(new ResourcesIndicator())}),
    feature({
        id: 'dropbox-toggle',
        needs: ['transfer-indicator'],
        create: (_settings, built) => tile(new DropboxIndicator(built.get('transfer-indicator') ?? null)),
    }),
    feature({id: 'night-light-split', create: () => new NightLightSplit()}),
    feature({id: 'rename-power-profile', create: () => new PowerProfileLabel()}),
    feature({id: 'keyboard-icon', create: () => new KeyboardIcon()}),
    feature({id: 'hide-audio-outputs', create: () => new HiddenAudioOutputs()}),
    feature({id: 'volume-osd', create: () => new VolumeOsd()}),
    feature({id: 'osd-lock-keys', create: () => new LockKeysOsd()}),
    feature({
        id: 'power-osd',
        switches: POWER_OSD_SWITCHES,
        options: POWER_OSD_SWITCHES,
        create: settings => new PowerOsd({
            charger: settings.get_boolean('osd-charger'),
            chargeLimit: settings.get_boolean('osd-charge-limit'),
            profile: settings.get_boolean('osd-power-profile'),
        }),
    }),
];

// Réglages écrits par l'extension elle-même : rien à recréer quand ils changent.
export const SELF_WRITTEN = ['other-tiles', 'timer-minutes'];
