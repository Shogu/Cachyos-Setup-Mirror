// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Shell from 'gi://Shell';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {QuickMenuToggle, SystemIndicator} from 'resource:///org/gnome/shell/ui/quickSettings.js';

import {NNBSP, decimal, duration, gigabytes, percent} from './format.js';
import {themedOrBundledIcon} from './icons.js';
import {MeterBar} from './meterBar.js';
import {ResourcesSampler} from './resourcesSampler.js';

const RESOURCES_APP_ID = 'org.gnome.Resources.desktop';
const FIRST_DELAY_MS = 600;
const INTERVAL_MS = 2000;
const BUSY_CPU = 0.8;
const NETWORK_FLOOR = 1e6;

function speed(bytesPerSecond) {
    if (bytesPerSecond >= 1e6)
        return `${decimal(bytesPerSecond / 1e6)}${NNBSP}Mo/s`;
    return `${Math.round(bytesPerSecond / 1e3)}${NNBSP}ko/s`;
}

function batteryText({watts, state, hoursLeft}) {
    const power = `${decimal(watts)}${NNBSP}W`;
    if (state === 'Full')
        return 'Chargée';
    if (state === 'Charging')
        return hoursLeft === null ? `${power} · en charge` : `${power} · pleine dans ${duration(hoursLeft)}`;
    return hoursLeft === null ? power : `${power} · ${duration(hoursLeft)} restantes`;
}

const resourcesIcon = () => themedOrBundledIcon(
    ['org.gnome.Resources-symbolic', 'net.nokyan.Resources-symbolic', 'utilities-system-monitor-symbolic'], 'resources');

// L'appli Ressources (net.nokyan.Resources) : identifiant connu d'abord, puis recherche par
// identifiant ou par nom (« Resources » / « Ressources ») si elle est installée autrement.
const RESOURCES_NAMES = ['resources', 'ressources'];

function findResourcesApp() {
    const system = Shell.AppSystem.get_default();
    for (const id of [RESOURCES_APP_ID, 'net.nokyan.Resources.desktop', 'resources.desktop']) {
        const app = system.lookup_app(id);
        if (app)
            return {shellApp: app};
    }
    const info = Gio.AppInfo.get_all().find(candidate => {
        const id = (candidate.get_id() ?? '').toLowerCase();
        const name = (candidate.get_name() ?? '').toLowerCase();
        return RESOURCES_NAMES.includes(name) || id.endsWith('.resources.desktop') || id === 'resources.desktop';
    });
    return info ? {info} : null;
}

function openResources() {
    Main.panel.closeQuickSettings();
    Main.overview.hide();
    try {
        const found = findResourcesApp();
        if (found?.shellApp) {
            found.shellApp.activate();
            return;
        }
        if (found?.info) {
            found.info.launch([], global.create_app_launch_context(0, -1));
            return;
        }
        GLib.spawn_command_line_async('resources');
    } catch (error) {
        console.error(`Quick Settings : ouverture de Ressources impossible — ${error.message}`, error);
        Main.notify('Ressources', 'L’application Ressources est introuvable (net.nokyan.Resources).');
    }
}

// Une ligne du détail : nom, valeur à droite, barre facultative en dessous.
const ResourceRow = GObject.registerClass(
class ResourceRow extends St.BoxLayout {
    _init(title, withBar) {
        super._init({orientation: Clutter.Orientation.VERTICAL, x_expand: true, style_class: 'fb-resource-row'});
        const box = this;
        const line = new St.BoxLayout();
        line.add_child(new St.Label({text: title, x_expand: true, style_class: 'fb-resource-title'}));
        this._value = new St.Label({style_class: 'fb-resource-value'});
        line.add_child(this._value);
        box.add_child(line);
        if (withBar) {
            this._bar = new MeterBar();
            box.add_child(this._bar);
        }
    }

    update(text, fraction = null) {
        this.visible = text !== null;
        this._value.text = text ?? '';
        if (fraction !== null)
            this._bar?.setFraction(fraction);
    }
});

// Tuile « Ressources » : clic = appli Ressources, flèche = détail. Les compteurs
// ne sont lus que pendant que Quick Settings est ouvert.
const ResourcesToggle = GObject.registerClass(
class ResourcesToggle extends QuickMenuToggle {
    _init() {
        super._init({title: 'Ressources', subtitle: '…', gicon: resourcesIcon(), toggleMode: false});
        this._networkPeak = NETWORK_FLOOR;
        this.menu.setHeader(resourcesIcon(), 'Ressources');
        this._rows = {
            cpu: new ResourceRow('Processeur', true),
            temperature: new ResourceRow('Température', true),
            memory: new ResourceRow('Mémoire', true),
            gpu: new ResourceRow('Carte graphique', true),
            disk: new ResourceRow('Disque personnel', true),
            network: new ResourceRow('Réseau', true),
            battery: new ResourceRow('Batterie', true),
            health: new ResourceRow('Santé de la batterie', true),
            busiest: new ResourceRow('Le plus gourmand', false),
        };
        // Les lignes défilent dans un cadre dont la hauteur suit l'écran : la tuile étant en bas
        // du menu, le détail ne doit jamais dépasser de l'écran.
        const list = new St.BoxLayout({orientation: Clutter.Orientation.VERTICAL, x_expand: true, style_class: 'fb-resource-list'});
        for (const row of Object.values(this._rows))
            list.add_child(row);
        this._scroll = new St.ScrollView({
            style_class: 'fb-resource-scroll',
            child: list,
            hscrollbar_policy: St.PolicyType.NEVER,
            vscrollbar_policy: St.PolicyType.AUTOMATIC,
            overlay_scrollbars: true,
        });
        // Ajouté directement au menu (pas dans un élément de menu inactif, que GNOME grise) :
        // les libellés gardent la couleur du texte des autres menus.
        this._scroll.x_expand = true;
        this.menu.box.add_child(this._scroll);
        this.menu.connect('open-state-changed', (_menu, open) => {
            if (!open)
                return;
            const monitor = Main.layoutManager.primaryMonitor;
            const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
            this._scroll.style = `max-height: ${Math.round(monitor.height / scale * 0.42)}px;`;
        });
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this.menu.addAction('Ouvrir Ressources', () => openResources());

        this.connect('clicked', () => openResources());
    }

    show(sample) {
        const {cpu, memory, temperature, gpu, disk, network, battery, busiest} = sample;
        const memoryFraction = memory.used / memory.total;
        // Une seule ligne ne contient pas tout : CPU et RAM alternent à chaque relevé (2 s).
        this._showRam = !this._showRam;
        this.subtitle = this._showRam || cpu === null
            ? `RAM ${percent(memoryFraction)}` : `CPU ${percent(cpu)}`;
        this.checked = cpu !== null && cpu >= BUSY_CPU;

        const rows = this._rows;
        rows.cpu.update(cpu === null ? '…' : percent(cpu), cpu ?? 0);
        rows.temperature.update(temperature === null ? null : `${Math.round(temperature)}${NNBSP}°C`, (temperature ?? 0) / 100);
        rows.memory.update(`${gigabytes(memory.used)} sur ${gigabytes(memory.total)}`, memoryFraction);
        rows.gpu.update(gpu === null ? null : percent(gpu), gpu ?? 0);
        rows.disk.update(disk ? `${gigabytes(disk.free)} libres sur ${gigabytes(disk.total)}` : null,
            disk ? 1 - disk.free / disk.total : 0);
        // Barre du réseau : débit total rapporté au plus fort débit vu depuis l'ouverture de la session (1 Mo/s au moins).
        const traffic = network ? network.rx + network.tx : 0;
        this._networkPeak = Math.max(this._networkPeak, traffic);
        rows.network.update(network ? `↓ ${speed(network.rx)}   ↑ ${speed(network.tx)}` : '…', traffic / this._networkPeak);
        rows.battery.update(battery ? batteryText(battery) : null, (battery?.percent ?? 0) / 100);
        rows.health.update(battery?.health ? percent(battery.health) : null, battery?.health ?? 0);
        rows.busiest.update(busiest ? `${busiest.name} · ${percent(busiest.fraction)}` : '…');
    }
});

export const ResourcesIndicator = GObject.registerClass(
class ResourcesIndicator extends SystemIndicator {
    _init() {
        super._init();
        this._toggle = new ResourcesToggle();
        this.quickSettingsItems.push(this._toggle);
        this._sampler = new ResourcesSampler();
        this._timeoutId = 0;
        this._busy = false;

        this._quickSettingsMenu = Main.panel.statusArea.quickSettings.menu;
        this._openId = this._quickSettingsMenu.connect('open-state-changed', (_menu, open) => {
            if (open)
                this._start();
            else
                this._stop();
        });
        // Le plus gourmand demande de lire tous les processus : seulement détail ouvert.
        this._detailId = this._toggle.menu.connect('open-state-changed', (_menu, open) => {
            if (open)
                this._sample();
        });
    }

    _start() {
        this._sampler.reset();
        this._sample();
    }

    _stop() {
        if (this._timeoutId)
            GLib.Source.remove(this._timeoutId);
        this._timeoutId = 0;
    }

    _schedule(delay) {
        this._stop();
        this._timeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, delay, () => {
            this._timeoutId = 0;
            this._sample();
            return GLib.SOURCE_REMOVE;
        });
    }

    async _sample() {
        if (this._busy)
            return;
        this._busy = true;
        const detailOpen = this._toggle.menu.isOpen;
        const sample = await this._sampler.sample(detailOpen);
        this._busy = false;
        if (!sample || !this._quickSettingsMenu.isOpen)
            return;
        this._toggle.show(sample);
        const primed = sample.cpu !== null && (!detailOpen || sample.busiest !== undefined);
        this._schedule(primed ? INTERVAL_MS : FIRST_DELAY_MS);
    }

    destroy() {
        this._stop();
        this._quickSettingsMenu.disconnect(this._openId);
        this._toggle.menu.disconnect(this._detailId);
        this._quickSettingsMenu = null;
        this._sampler.destroy();
        this._sampler = null;
        this.quickSettingsItems.forEach(item => item.destroy());
        this.quickSettingsItems.length = 0;
        super.destroy();
    }
});
