// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Gio from 'gi://Gio';
import GObject from 'gi://GObject';
import Shell from 'gi://Shell';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as SystemActions from 'resource:///org/gnome/shell/misc/systemActions.js';
import {QuickSettingsItem} from 'resource:///org/gnome/shell/ui/quickSettings.js';

import {findButton, systemRow} from './quickSettingsUtils.js';

const SETTINGS_APP_ID = 'org.gnome.Settings.desktop';
const SCREENSHOT_ICON = 'screenshooter-symbolic';
const SETTINGS_MENU = [
    ['Ajustements', 'org.gnome.tweaks.desktop'],
    ['Éditeur dconf', 'ca.desrt.dconf-editor.desktop'],
    ['Extensions', 'com.mattjakeman.ExtensionManager.desktop'],
];
const LOCK_ICON = 'system-lock-screen-symbolic';
const SHUTDOWN_ICON = 'system-shutdown-symbolic';
export const LOGOUT_TITLE = 'Reconnexion';

function launchApp(app) {
    Main.overview.hide();
    Main.panel.closeQuickSettings();
    app.activate();
}

// Bouton rond scindé de la rangée système : icône = action principale,
// chevron = sous-menu. Le sous-menu s'ouvre dans Quick Settings comme ceux des
// tuiles ; le temps qu'il est ouvert, il remplace le menu de la rangée système,
// que la mise en page de Quick Settings surveille pour lui réserver la place.
const SplitButton = GObject.registerClass(
class SplitButton extends QuickSettingsItem {
    _init({gicon, accessibleName, menuAccessibleName, title, onPrimary}) {
        super._init({hasMenu: true, reactive: false, can_focus: false, style_class: 'qs-split-item'});
        const box = new St.BoxLayout({style_class: 'qs-split-box'});
        this.set_child(box);
        this.primaryButton = new St.Button({style_class: 'icon-button qs-split-primary', can_focus: true,
            accessible_name: accessibleName, child: new St.Icon({gicon})});
        this.primaryButton.connect('clicked', onPrimary);
        const menuButton = new St.Button({style_class: 'icon-button qs-split-menu', can_focus: true,
            accessible_name: menuAccessibleName, child: new St.Icon({icon_name: 'go-next-symbolic'})});
        menuButton.connect('clicked', () => this.menu.open());
        box.add_child(this.primaryButton);
        box.add_child(menuButton);
        this.menu.setHeader(gicon, title);
        this.bindings = [];

        const quickSettings = Main.panel.statusArea.quickSettings;
        this._quickMenu = quickSettings.menu;
        this._systemItem = quickSettings._system._systemItem;
        this._nativeMenu = this._systemItem.menu;
        this._quickMenu._overlay.add_child(this.menu.actor);
        this._openId = this.menu.connect('open-state-changed', (_menu, open) => this._openChanged(open));
    }

    _openChanged(open) {
        if (open) {
            this.add_style_class_name('qs-split-open');
            if (this._quickMenu._activeMenu && this._quickMenu._activeMenu !== this.menu)
                this._quickMenu._activeMenu.close();
            this._systemItem.menu = this.menu;
            this._quickMenu._activeMenu = this.menu;
            this._quickMenu._setDimmed(true);
        } else {
            this.remove_style_class_name('qs-split-open');
            this._release();
        }
        this._quickMenu._grid.queue_relayout();
    }

    _release() {
        if (this._systemItem.menu === this.menu)
            this._systemItem.menu = this._nativeMenu;
        if (this._quickMenu._activeMenu === this.menu) {
            this._quickMenu._activeMenu = null;
            this._quickMenu._setDimmed(false);
        }
    }

    destroy() {
        this.bindings.forEach(binding => binding.unbind());
        this.bindings = null;
        this.menu.disconnect(this._openId);
        this._release();
        this._quickMenu._grid.queue_relayout();
        this._quickMenu = null;
        this._systemItem = null;
        this._nativeMenu = null;
        super.destroy();
    }
});

// Bouton natif remplacé par un bouton scindé, remis en place à la destruction.
class ReplacedButton {
    constructor(natives, splitButton) {
        this._natives = natives.map(button => [button, button.visible]);
        this._split = splitButton;
        const anchor = natives.at(-1);
        anchor.get_parent().insert_child_above(splitButton, anchor);
        natives.forEach(button => button.hide());
    }

    destroy() {
        for (const [button, visible] of this._natives)
            button.visible = visible;
        this._split.destroy();
        this._split = null;
        this._natives = null;
    }
}

// Roue dentée : clic = Paramètres ; chevron = Ajustements, dconf, Extensions.
export function settingsSplit() {
    const appSystem = Shell.AppSystem.get_default();
    const settingsApp = appSystem.lookup_app(SETTINGS_APP_ID);
    const buttons = systemRow().get_children().filter(child => child instanceof St.Button);
    // Le bouton natif porte le nom de Paramètres ; à défaut, c'est celui qui suit Capture d'écran.
    const screenshotIndex = buttons.findIndex(button => button.icon_name === SCREENSHOT_ICON);
    const native = buttons.find(button => button.accessible_name === settingsApp.get_name()) ??
        (screenshotIndex >= 0 ? buttons[screenshotIndex + 1] : null);
    if (!native)
        throw new Error('bouton Paramètres introuvable');

    const split = new SplitButton({
        gicon: settingsApp.get_icon(),
        accessibleName: settingsApp.get_name(),
        menuAccessibleName: 'Autres réglages GNOME',
        title: 'Réglages',
        onPrimary: () => launchApp(settingsApp),
    });
    for (const [label, appId] of SETTINGS_MENU) {
        const app = appSystem.lookup_app(appId);
        if (app)
            split.menu.addAction(label, () => launchApp(app), app.get_icon());
    }
    return new ReplacedButton([native], split);
}

// Power : clic = Éteindre ; chevron = Suspendre, Redémarrer, Reconnexion, Verrouiller.
export function powerSplit() {
    const row = systemRow();
    const lock = findButton(row, LOCK_ICON);
    const shutdown = findButton(row, SHUTDOWN_ICON);
    if (!lock || !shutdown)
        throw new Error('boutons Verrouiller et Éteindre introuvables');

    const actions = SystemActions.getDefault();
    const split = new SplitButton({
        gicon: Gio.ThemedIcon.new(SHUTDOWN_ICON),
        accessibleName: 'Éteindre',
        menuAccessibleName: 'Options d’alimentation et de session',
        title: 'Alimentation',
        onPrimary: () => {
            Main.panel.closeQuickSettings();
            actions.activatePowerOff();
        },
    });
    split.bindings.push(actions.bind_property('can-power-off', split.primaryButton, 'reactive', GObject.BindingFlags.SYNC_CREATE));
    for (const [label, property, iconName, activate] of [
        ['Suspendre', 'can-suspend', 'media-playback-pause-symbolic', () => actions.activateSuspend()],
        ['Redémarrer…', 'can-restart', 'system-reboot-symbolic', () => actions.activateRestart()],
        [LOGOUT_TITLE, 'can-logout', 'system-log-out-symbolic', () => actions.activateLogout()],
        ['Verrouiller la session', 'can-lock-screen', LOCK_ICON, () => actions.activateLockScreen()],
    ]) {
        const item = split.menu.addAction(label, () => {
            Main.panel.closeQuickSettings();
            activate();
        }, iconName);
        split.bindings.push(actions.bind_property(property, item, 'visible', GObject.BindingFlags.SYNC_CREATE));
    }
    return new ReplacedButton([lock, shutdown], split);
}
