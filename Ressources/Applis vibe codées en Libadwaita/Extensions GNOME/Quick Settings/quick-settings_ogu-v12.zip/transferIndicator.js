// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Cairo from 'cairo';
import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GObject from 'gi://GObject';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';

import {MeterBar} from './meterBar.js';

// Fret et Grabber exportent cet objet sur leur nom D-Bus (= identifiant de
// l'appli) pendant un transfert. Quand l'appli se ferme, son nom disparaît du
// bus et sa ligne aussi : rien ne peut rester affiché à tort.
const OBJECT_PATH = '/io/github/ogu/TransferProgress';
const ProgressProxy = Gio.DBusProxy.makeProxyWrapper(`
<node>
  <interface name="io.github.ogu.TransferProgress">
    <property name="Active" type="b" access="read"/>
    <property name="Progress" type="d" access="read"/>
    <property name="Title" type="s" access="read"/>
    <property name="Detail" type="s" access="read"/>
  </interface>
</node>`);

const RING_WIDTH = 2.4;

// Anneau dessiné au Cairo : la couleur d'accent vient du style (color: -st-accent-color),
// le fond de l'anneau est la même couleur, atténuée.
const ProgressRing = GObject.registerClass(
class ProgressRing extends St.DrawingArea {
    _init() {
        super._init({style_class: 'fb-transfer-ring', y_align: Clutter.ActorAlign.CENTER});
        this._fraction = 0;
        this.connect('repaint', () => this._draw());
    }

    setFraction(fraction) {
        this._fraction = fraction;
        this.queue_repaint();
    }

    _draw() {
        const cr = this.get_context();
        const [width, height] = this.get_surface_size();
        const node = this.get_theme_node();
        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor;
        const radius = Math.min(width, height) / 2 - RING_WIDTH * scale;
        const [cx, cy] = [width / 2, height / 2];
        cr.setLineWidth(RING_WIDTH * scale);

        const accent = node.get_foreground_color();
        const [red, green, blue] = [accent.red / 255, accent.green / 255, accent.blue / 255];
        cr.setSourceRGBA(red, green, blue, 0.3);
        cr.arc(cx, cy, radius, 0, 2 * Math.PI);
        cr.stroke();

        if (this._fraction > 0) {
            cr.setSourceRGBA(red, green, blue, 1);
            cr.setLineCap(Cairo.LineCap.ROUND);
            cr.arc(cx, cy, radius, -Math.PI / 2, -Math.PI / 2 + 2 * Math.PI * this._fraction);
            cr.stroke();
        }
        cr.$dispose();
    }
});

// Une ligne du menu : nom de l'appli, ce qui se passe, petite barre et pourcentage.
const TransferItem = GObject.registerClass(
class TransferItem extends PopupMenu.PopupBaseMenuItem {
    _init(appName) {
        super._init({style_class: 'fb-transfer-item'});
        const box = new St.BoxLayout({orientation: Clutter.Orientation.VERTICAL, x_expand: true});
        this._app = new St.Label({text: appName, style_class: 'fb-transfer-app'});
        this._title = new St.Label({style_class: 'fb-transfer-title'});
        const line = new St.BoxLayout({style_class: 'fb-transfer-line'});
        this._bar = new MeterBar();
        this._percent = new St.Label({style_class: 'fb-transfer-percent', y_align: Clutter.ActorAlign.CENTER});
        line.add_child(this._bar);
        line.add_child(this._percent);
        this._detail = new St.Label({style_class: 'fb-transfer-detail'});
        for (const child of [this._app, this._title, line, this._detail])
            box.add_child(child);
        this.add_child(box);
    }

    update({progress, title, detail}) {
        this._title.text = title;
        this._detail.text = detail;
        this._detail.visible = Boolean(detail);
        this._percent.text = `${Math.round(progress * 100)}\u202f%`;
        this._bar.setFraction(progress);
    }
});

export const TransferIndicator = GObject.registerClass(
class TransferIndicator extends PanelMenu.Button {
    _init(appIds) {
        super._init(0.5, 'Transferts', false);
        this.add_style_class_name('fb-transfer-indicator');
        const box = new St.BoxLayout({style_class: 'panel-status-indicators-box'});
        this._ring = new ProgressRing();
        this._label = new St.Label({style_class: 'fb-transfer-label', y_align: Clutter.ActorAlign.CENTER});
        box.add_child(this._ring);
        box.add_child(this._label);
        this.add_child(box);
        this.visible = false;

        this._apps = new Map();
        this._cancellable = new Gio.Cancellable();
        this._watchIds = appIds.map(appId => Gio.bus_watch_name(Gio.BusType.SESSION, appId,
            Gio.BusNameWatcherFlags.NONE,
            () => this._appeared(appId),
            () => this._vanished(appId)));
    }

    _appeared(appId) {
        if (this._apps.has(appId))
            return;
        const appInfo = Gio.DesktopAppInfo.new(`${appId}.desktop`);
        const entry = {proxy: null, signalId: 0, item: null, state: null, appInfo, name: appInfo?.get_name() ?? appId};
        this._apps.set(appId, entry);
        new ProgressProxy(Gio.DBus.session, appId, OBJECT_PATH, (proxy, error) => {
            // Ancienne version de l'appli, sans l'objet : on l'ignore simplement.
            if (error || this._apps.get(appId) !== entry)
                return;
            entry.proxy = proxy;
            entry.signalId = proxy.connect('g-properties-changed', () => this._readProxy(entry));
            this._readProxy(entry);
        }, this._cancellable, Gio.DBusProxyFlags.DO_NOT_AUTO_START);
    }

    _readProxy(entry) {
        const {Active, Progress, Title, Detail} = entry.proxy;
        entry.state = Active ? {progress: Progress, title: Title, detail: Detail} : null;
        this._sync();
    }

    // Transfert suivi par l'extension elle-même (synchro Dropbox) : state = null le retire.
    setLocal(id, appInfo, name, state) {
        let entry = this._apps.get(id);
        if (!entry && !state)
            return;
        if (!entry) {
            entry = {proxy: null, signalId: 0, item: null, state: null, appInfo, name};
            this._apps.set(id, entry);
        }
        entry.state = state;
        this._sync();
    }

    _vanished(appId) {
        const entry = this._apps.get(appId);
        if (!entry)
            return;
        if (entry.signalId)
            entry.proxy.disconnect(entry.signalId);
        entry.item?.destroy();
        this._apps.delete(appId);
        this._sync();
    }

    _sync() {
        const active = [...this._apps.values()].filter(entry => entry.state);
        for (const entry of this._apps.values()) {
            if (!active.includes(entry)) {
                entry.item?.destroy();
                entry.item = null;
            }
        }
        for (const entry of active) {
            if (!entry.item) {
                entry.item = new TransferItem(entry.name);
                entry.item.connect('activate', () => entry.appInfo?.launch([], global.create_app_launch_context(0, -1)));
                this.menu.addMenuItem(entry.item);
            }
            entry.item.update(entry.state);
        }

        this.visible = active.length > 0;
        if (!active.length) {
            this.menu.close();
            return;
        }
        const fraction = active.reduce((sum, entry) => sum + entry.state.progress, 0) / active.length;
        this._ring.setFraction(fraction);
        this._label.text = `${Math.round(fraction * 100)}\u202f%`;
        this.accessible_name = `Transferts : ${this._label.text}`;
    }

    destroy() {
        this._cancellable.cancel();
        for (const id of this._watchIds)
            Gio.bus_unwatch_name(id);
        this._watchIds = [];
        for (const appId of [...this._apps.keys()])
            this._vanished(appId);
        super.destroy();
    }
});

export function addTransferIndicator(appIds) {
    const indicator = new TransferIndicator(appIds);
    Main.panel.addToStatusArea('quick-settings-transfers', indicator, 0, 'right');
    return indicator;
}
