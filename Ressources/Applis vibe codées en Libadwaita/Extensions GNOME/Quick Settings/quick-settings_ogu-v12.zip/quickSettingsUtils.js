// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';

// Rangée du haut de Quick Settings (batterie, capture, Paramètres, verrouillage, Power).
export function systemRow() {
    return Main.panel.statusArea.quickSettings._system._systemItem.child;
}

export function findButton(actor, iconName) {
    if (actor instanceof St.Button && actor.icon_name === iconName)
        return actor;
    for (const child of actor.get_children()) {
        const found = findButton(child, iconName);
        if (found)
            return found;
    }
    return null;
}

// Masque le bouton Capture d'écran de la rangée système (les raccourcis restent).
export class HiddenScreenshotButton {
    constructor() {
        this._button = findButton(systemRow(), 'screenshooter-symbolic');
        if (!this._button)
            throw new Error('bouton Capture d’écran introuvable');
        this._wasVisible = this._button.visible;
        this._button.hide();
    }

    destroy() {
        this._button.visible = this._wasVisible;
        this._button = null;
    }
}
