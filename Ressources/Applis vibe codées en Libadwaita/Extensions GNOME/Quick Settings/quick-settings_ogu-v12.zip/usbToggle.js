// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {QuickMenuToggle, SystemIndicator} from 'resource:///org/gnome/shell/ui/quickSettings.js';
import * as ShellMountOperation from 'resource:///org/gnome/shell/ui/shellMountOperation.js';

import {gigabytes} from './format.js';
import {showOsd} from './osd.js';

Gio._promisify(Gio.Mount.prototype, 'eject_with_operation');
Gio._promisify(Gio.Mount.prototype, 'unmount_with_operation');
Gio._promisify(Gio.File.prototype, 'query_filesystem_info_async');

const USB_ICON = 'media-removable-symbolic';
const FRET_ID = 'io.github.fret.Fret.desktop';

function isRemovable(mount) {
    const drive = mount.get_drive();
    return !mount.is_shadowed() && drive !== null && drive.is_removable() && (mount.can_eject() || mount.can_unmount());
}

const UsbToggle = GObject.registerClass(
class UsbToggle extends QuickMenuToggle {
    _init(actions) {
        super._init({title: 'Clé USB', iconName: USB_ICON, toggleMode: false, checked: true, visible: false});
        this._actions = actions;
        this._section = new PopupMenu.PopupMenuSection();
        this.menu.addMenuItem(this._section);
    }

    sync(mounts, free) {
        const single = mounts.length === 1;
        this.title = single ? mounts[0].get_name() : `${mounts.length} clés USB`;
        this.subtitle = single ? free.get(mounts[0]) || null : mounts.map(mount => mount.get_name()).join(', ');
        this.menu.setHeader(USB_ICON, this.title, this.subtitle);
        this._section.removeAll();
        for (const mount of mounts) {
            if (!single)
                this._section.addMenuItem(new PopupMenu.PopupSeparatorMenuItem(mount.get_name()));
            this._section.addAction('Ouvrir', () => this._actions.open(mount));
            if (this._actions.hasFret)
                this._section.addAction('Ouvrir dans Fret', () => this._actions.openInFret(mount));
            this._section.addAction('Éjecter', () => this._actions.eject(mount));
        }
    }
});

// Tuile « Clé USB » : visible et bleue tant qu'une clé est montée, avec la place libre en sous-titre.
// Clic : éjecter (GNOME demande quelles applis bloquent si un fichier est encore ouvert).
// Flèche : Ouvrir (Fichiers), Ouvrir dans Fret, Éjecter. Une icône de clé dans la barre du haut.
export const UsbIndicator = GObject.registerClass(
class UsbIndicator extends SystemIndicator {
    _init(osd) {
        super._init();
        this._osd = osd;
        this._mounts = [];
        this._free = new Map();
        this._cancellable = new Gio.Cancellable();
        this._fret = Gio.DesktopAppInfo.new(FRET_ID);

        this._indicator = this._addIndicator();
        this._indicator.icon_name = USB_ICON;
        this._toggle = new UsbToggle({
            hasFret: this._fret !== null,
            open: mount => this._open(mount),
            openInFret: mount => this._openInFret(mount),
            eject: mount => this._eject(mount),
        });
        this._toggle.connect('clicked', () => this._eject(this._mounts[0]));
        this.quickSettingsItems.push(this._toggle);

        this._monitor = Gio.VolumeMonitor.get();
        this._monitorIds = [
            this._monitor.connect('mount-added', (_monitor, mount) => this._added(mount)),
            this._monitor.connect('mount-removed', () => this._sync()),
            this._monitor.connect('mount-changed', () => this._sync()),
        ];
        this._sync();
    }

    _added(mount) {
        if (this._osd && isRemovable(mount))
            showOsd(USB_ICON, `${mount.get_name()} prête`);
        this._sync();
    }

    _sync() {
        this._mounts = this._monitor.get_mounts().filter(isRemovable);
        for (const mount of [...this._free.keys()]) {
            if (!this._mounts.includes(mount))
                this._free.delete(mount);
        }
        for (const mount of this._mounts) {
            if (!this._free.has(mount))
                this._queryFree(mount);
        }
        const present = this._mounts.length > 0;
        this._indicator.visible = present;
        this._toggle.visible = present;
        if (present)
            this._toggle.sync(this._mounts, this._free);
    }

    async _queryFree(mount) {
        this._free.set(mount, '');
        try {
            const info = await mount.get_root().query_filesystem_info_async('filesystem::free', GLib.PRIORITY_DEFAULT,
                this._cancellable);
            if (!this._free.has(mount))
                return;
            this._free.set(mount, `${gigabytes(info.get_attribute_uint64('filesystem::free'))} libres`);
            this._toggle.sync(this._mounts, this._free);
        } catch (error) {
            if (!error.matches(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED))
                console.warn(`Quick Settings : place libre de ${mount.get_name()} — ${error.message}`);
        }
    }

    _open(mount) {
        Main.panel.closeQuickSettings();
        Gio.AppInfo.launch_default_for_uri(mount.get_root().get_uri(), global.create_app_launch_context(0, -1));
    }

    _openInFret(mount) {
        Main.panel.closeQuickSettings();
        this._fret.launch([mount.get_root()], global.create_app_launch_context(0, -1));
    }

    async _eject(mount) {
        const name = mount.get_name();
        const operation = new ShellMountOperation.ShellMountOperation(mount);
        try {
            if (mount.can_eject())
                await mount.eject_with_operation(Gio.MountUnmountFlags.NONE, operation.mountOp, this._cancellable);
            else
                await mount.unmount_with_operation(Gio.MountUnmountFlags.NONE, operation.mountOp, this._cancellable);
            if (this._osd)
                showOsd(USB_ICON, `Vous pouvez retirer ${name}`);
        } catch (error) {
            if (!error.matches(Gio.IOErrorEnum, Gio.IOErrorEnum.FAILED_HANDLED) &&
                !error.matches(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED))
                Main.notifyError(`Impossible d’éjecter ${name}`, error.message);
        } finally {
            operation.close();
        }
    }

    destroy() {
        this._cancellable.cancel();
        this._monitorIds.forEach(id => this._monitor.disconnect(id));
        this._monitorIds = [];
        this._monitor = null;
        this._free.clear();
        this.quickSettingsItems.forEach(item => item.destroy());
        this.quickSettingsItems.length = 0;
        super.destroy();
    }
});
