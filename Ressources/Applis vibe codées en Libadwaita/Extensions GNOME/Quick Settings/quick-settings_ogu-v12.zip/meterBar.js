// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Clutter from 'gi://Clutter';
import GObject from 'gi://GObject';
import St from 'gi://St';

// Barre de niveau fine (remplissage collé à gauche) (fond atténué, remplissage à la couleur d'accent).
export const MeterBar = GObject.registerClass(
class MeterBar extends St.BoxLayout {
    _init() {
        super._init({style_class: 'fb-meter-bar', x_expand: true, y_align: Clutter.ActorAlign.CENTER});
        this._fraction = 0;
        this._fill = new St.Widget({style_class: 'fb-meter-fill', x_expand: false, x_align: Clutter.ActorAlign.START,
            y_align: Clutter.ActorAlign.FILL});
        this.add_child(this._fill);
        this.connect('notify::width', () => this._sizeFill());
    }

    setFraction(fraction) {
        this._fraction = Math.min(1, Math.max(0, fraction));
        this._sizeFill();
    }

    _sizeFill() {
        this._fill.width = Math.round(this.width * this._fraction);
    }
});
