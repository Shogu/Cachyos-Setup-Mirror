// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {QuickMenuToggle, SystemIndicator} from 'resource:///org/gnome/shell/ui/quickSettings.js';

import {MeterBar} from './meterBar.js';
import {ResourcesSampler} from './resourcesSampler.js';

const RESOURCES_APP_ID = 'net.nokyan.Resources.desktop';
const FIRST_DELAY_MS = 600;
const INTERVAL_MS = 2000;
const BUSY_CPU = 0.8;
const NNBSP = ' ';

const decimal = (value, digits = 1) => value.toFixed(digits).replace('.', ',');
const percent = fraction => `${Math.round(fraction * 100)}${NNBSP}%`;

function gigabytes(bytes) {
    const value = bytes / 1e9;
    return `${value >= 100 ? Math.round(value) : decimal(value)}${NNBSP}Go`;
}

function speed(bytesPerSecond) {
    if (bytesPerSecond >= 1e6)
        return `${decimal(bytesPerSecond / 1e6)}${NNBSP}Mo/s`;
    return `${Math.round(bytesPerSecond / 1e3)}${NNBSP}ko/s`;
}

function duration(hours) {
    const minutes = Math.round(hours * 60);
    return `${Math.floor(minutes / 60)}${NNBSP}h${NNBSP}${String(minutes % 60).padStart(2, '0')}`;
}

function batteryText({watts, state, hoursLeft}) {
    const power = `${decimal(watts)}${NNBSP}W`;
    if (state === 'Full')
        return 'Chargée';
    if (state === 'Charging')
        return hoursLeft === null ? `${power} · en charge` : `${power} · pleine dans ${duration(hoursLeft)}`;
    return hoursLeft === null ? power : `${power} · ${duration(hoursLeft)} restantes`;
}

function resourcesIcon() {
    return Gio.ThemedIcon.new_from_names(['net.nokyan.Resources-symbolic', 'utilities-system-monitor-symbolic']);
}

// Une ligne du détail : nom, valeur à droite, barre facultative en dessous.
const ResourceRow = GObject.registerClass(
class ResourceRow extends PopupMenu.PopupBaseMenuItem {
    _init(title, withBar) {
        super._init({activate: false, reactive: false, can_focus: false, style_class: 'fb-resource-row'});
        const box = new St.BoxLayout({orientation: Clutter.Orientation.VERTICAL, x_expand: true});
        const line = new St.BoxLayout();
        line.add_child(new St.Label({text: title, x_expand: true, style_class: 'fb-resource-title'}));
        this._value = new St.Label({style_class: 'fb-resource-value'});
        line.add_child(this._value);
        box.add_child(line);
        if (withBar) {
            this._bar = new MeterBar();
            box.add_child(this._bar);
        }
        this.add_child(box);
    }

    update(text, fraction = null) {
        this.visible = text !== null;
        this._value.text = text ?? '';
        if (fraction !== null)
            this._bar?.setFraction(fraction);
    }
});

// Tuile « Ressources » : clic = appli Ressources, flèche = détail. Les compteurs
// ne sont lus que pendant que Quick Settings est ouvert.
const ResourcesToggle = GObject.registerClass(
class ResourcesToggle extends QuickMenuToggle {
    _init() {
        super._init({title: 'Ressources', subtitle: '…', gicon: resourcesIcon(), toggleMode: false});
        this.menu.setHeader(resourcesIcon(), 'Ressources');
        this._rows = {
            cpu: new ResourceRow('Processeur', true),
            temperature: new ResourceRow('Température', true),
            memory: new ResourceRow('Mémoire', true),
            gpu: new ResourceRow('Carte graphique', true),
            disk: new ResourceRow('Disque personnel', true),
            network: new ResourceRow('Réseau', false),
            battery: new ResourceRow('Batterie', true),
            busiest: new ResourceRow('Le plus gourmand', false),
        };
        for (const row of Object.values(this._rows))
            this.menu.addMenuItem(row);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this.menu.addSettingsAction('Ouvrir Ressources', RESOURCES_APP_ID);

        this.connect('clicked', () => {
            Main.panel.closeQuickSettings();
            Gio.DesktopAppInfo.new(RESOURCES_APP_ID)?.launch([], global.create_app_launch_context(0, -1));
        });
    }

    show(sample) {
        const {cpu, memory, temperature, gpu, disk, network, battery, busiest} = sample;
        const memoryFraction = memory.used / memory.total;
        const summary = [`RAM ${percent(memoryFraction)}`];
        if (cpu !== null)
            summary.unshift(`CPU ${percent(cpu)}`);
        if (temperature !== null)
            summary.push(`${Math.round(temperature)}${NNBSP}°C`);
        this.subtitle = summary.join(' · ');
        this.checked = cpu !== null && cpu >= BUSY_CPU;

        const rows = this._rows;
        rows.cpu.update(cpu === null ? '…' : percent(cpu), cpu ?? 0);
        rows.temperature.update(temperature === null ? null : `${Math.round(temperature)}${NNBSP}°C`, (temperature ?? 0) / 100);
        rows.memory.update(`${gigabytes(memory.used)} sur ${gigabytes(memory.total)}`, memoryFraction);
        rows.gpu.update(gpu === null ? null : percent(gpu), gpu ?? 0);
        rows.disk.update(disk ? `${gigabytes(disk.free)} libres sur ${gigabytes(disk.total)}` : null,
            disk ? 1 - disk.free / disk.total : 0);
        rows.network.update(network ? `↓ ${speed(network.rx)}   ↑ ${speed(network.tx)}` : '…');
        rows.battery.update(battery ? batteryText(battery) : null, (battery?.percent ?? 0) / 100);
        rows.busiest.update(busiest ? `${busiest.name} · ${percent(busiest.fraction)}` : '…');
    }
});

export const ResourcesIndicator = GObject.registerClass(
class ResourcesIndicator extends SystemIndicator {
    _init() {
        super._init();
        this._toggle = new ResourcesToggle();
        this.quickSettingsItems.push(this._toggle);
        this._sampler = new ResourcesSampler();
        this._timeoutId = 0;
        this._busy = false;

        this._quickSettingsMenu = Main.panel.statusArea.quickSettings.menu;
        this._openId = this._quickSettingsMenu.connect('open-state-changed', (_menu, open) => {
            if (open)
                this._start();
            else
                this._stop();
        });
        // Le plus gourmand demande de lire tous les processus : seulement détail ouvert.
        this._detailId = this._toggle.menu.connect('open-state-changed', (_menu, open) => {
            if (open)
                this._sample();
        });
    }

    _start() {
        this._sampler.reset();
        this._sample();
    }

    _stop() {
        if (this._timeoutId)
            GLib.Source.remove(this._timeoutId);
        this._timeoutId = 0;
    }

    _schedule(delay) {
        this._stop();
        this._timeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, delay, () => {
            this._timeoutId = 0;
            this._sample();
            return GLib.SOURCE_REMOVE;
        });
    }

    async _sample() {
        if (this._busy)
            return;
        this._busy = true;
        const detailOpen = this._toggle.menu.isOpen;
        const sample = await this._sampler.sample(detailOpen);
        this._busy = false;
        if (!sample || !this._quickSettingsMenu.isOpen)
            return;
        this._toggle.show(sample);
        const primed = sample.cpu !== null && (!detailOpen || sample.busiest !== undefined);
        this._schedule(primed ? INTERVAL_MS : FIRST_DELAY_MS);
    }

    destroy() {
        this._stop();
        this._quickSettingsMenu.disconnect(this._openId);
        this._toggle.menu.disconnect(this._detailId);
        this._quickSettingsMenu = null;
        this._sampler.destroy();
        this._sampler = null;
        this.quickSettingsItems.forEach(item => item.destroy());
        this.quickSettingsItems.length = 0;
        super.destroy();
    }
});
