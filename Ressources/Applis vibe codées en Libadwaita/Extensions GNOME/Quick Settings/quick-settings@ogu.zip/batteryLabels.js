// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Gio from 'gi://Gio';
import UPower from 'gi://UPowerGlib';

import {InjectionManager} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {Indicator as SystemIndicator} from 'resource:///org/gnome/shell/ui/status/system.js';

const DISPLAY_DEVICE = '/org/freedesktop/UPower/devices/DisplayDevice';

// Le proxy UPower de GNOME ne déclare pas EnergyRate : proxy à part sur le même objet.
const RateProxy = Gio.DBusProxy.makeProxyWrapper(`
<node>
  <interface name="org.freedesktop.UPower.Device">
    <property name="EnergyRate" type="d" access="read"/>
  </interface>
</node>`);

function clock(seconds) {
    if (!(seconds > 0))
        return '…';
    const minutes = Math.round(seconds / 60);
    return `${Math.floor(minutes / 60)}:${String(minutes % 60).padStart(2, '0')}`;
}

function remaining(proxy) {
    switch (proxy.State) {
    case UPower.DeviceState.FULLY_CHARGED:
        return '∞';
    case UPower.DeviceState.CHARGING:
        return clock(proxy.TimeToFull);
    case UPower.DeviceState.DISCHARGING:
        return clock(proxy.TimeToEmpty);
    default:
        return '…';
    }
}

function panelText(format, time, percent) {
    switch (format) {
    case 'percent-time':
        return `${percent} - ${time}`;
    case 'time':
        return time;
    case 'percent':
        return percent;
    default:
        return `${time} - ${percent}`;
    }
}

// Barre du haut : « 9:27 - 56% » ; bouton batterie de Quick Settings : « 9:27 - 4.2 W ».
// Les textes sont reposés juste après chaque mise à jour native de GNOME.
export class BatteryLabels {
    constructor(settings) {
        this._settings = settings;
        this._system = Main.panel.statusArea.quickSettings._system;
        this._powerToggle = this._system._systemItem.powerToggle;
        this._rate = null;
        this._rateId = 0;
        this._cancellable = new Gio.Cancellable();

        const labels = this;
        this._injections = new InjectionManager();
        this._injections.overrideMethod(Object.getPrototypeOf(this._powerToggle), '_sync', nativeSync => function (...args) {
            nativeSync.apply(this, args);
            labels._apply();
        });
        this._injections.overrideMethod(SystemIndicator.prototype, '_sync', nativeSync => function (...args) {
            nativeSync.apply(this, args);
            labels._apply();
        });

        new RateProxy(Gio.DBus.system, 'org.freedesktop.UPower', DISPLAY_DEVICE, (proxy, error) => {
            if (error)
                return;
            this._rate = proxy;
            this._rateId = proxy.connect('g-properties-changed', () => this._apply());
            this._apply();
        }, this._cancellable);
        this._resync();
    }

    _apply() {
        const proxy = this._powerToggle._proxy;
        if (!proxy?.IsPresent)
            return;
        const time = remaining(proxy);
        const watts = Math.abs(this._rate?.EnergyRate ?? 0);
        const showWatts = this._settings.get_boolean('battery-quick-watts') && watts > 0;
        // Le titre du bouton suit le texte de la barre : le titre d'abord, la barre ensuite.
        this._powerToggle.title = showWatts ? `${time} - ${watts.toFixed(1)} W` : time;
        this._system._percentageLabel.text = panelText(this._settings.get_string('battery-panel-format'), time,
            `${Math.round(proxy.Percentage)}%`);
        this._system._percentageLabel.visible = true;
    }

    _resync() {
        this._powerToggle._sync();
        this._system._sync();
    }

    destroy() {
        this._cancellable.cancel();
        if (this._rateId)
            this._rate.disconnect(this._rateId);
        this._rate = null;
        this._injections.clear();
        this._injections = null;
        this._resync();
        this._settings = null;
        this._powerToggle = null;
        this._system = null;
    }
}
