// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import GObject from 'gi://GObject';
import Gtk from 'gi://Gtk';

const KEY = 'close-apps-keep';

function installedApps() {
    return Gio.AppInfo.get_all()
        .filter(app => app.should_show() && app.get_id())
        .sort((a, b) => a.get_display_name().localeCompare(b.get_display_name()));
}

function appRow(app, suffix) {
    const row = new Adw.ActionRow({title: app.get_display_name(), subtitle: app.get_id()});
    row.add_prefix(new Gtk.Image({gicon: app.get_icon() ?? Gio.ThemedIcon.new('application-x-executable'),
        pixel_size: 32}));
    if (suffix)
        row.add_suffix(suffix);
    return row;
}

// Liste des applications installées avec une recherche, comme le sélecteur
// « Applications au démarrage » d'Ajustements.
const AppPickerDialog = GObject.registerClass(
class AppPickerDialog extends Adw.Dialog {
    _init(exclude, onPick) {
        super._init({title: 'Ajouter une appli', content_width: 420, content_height: 560});
        const view = new Adw.ToolbarView();
        view.add_top_bar(new Adw.HeaderBar());
        const search = new Gtk.SearchEntry({placeholder_text: 'Rechercher une appli', margin_start: 12,
            margin_end: 12, margin_bottom: 6});
        const list = new Gtk.ListBox({selection_mode: Gtk.SelectionMode.NONE, css_classes: ['boxed-list'],
            margin_start: 12, margin_end: 12, margin_bottom: 12, valign: Gtk.Align.START});
        const apps = installedApps().filter(app => !exclude.has(app.get_id()));
        for (const app of apps) {
            const row = appRow(app, null);
            row.activatable = true;
            row.connect('activated', () => {
                onPick(app.get_id());
                this.close();
            });
            row.appName = app.get_display_name().toLowerCase();
            list.append(row);
        }
        list.set_filter_func(row => row.appName.includes(search.text.toLowerCase()));
        search.connect('search-changed', () => list.invalidate_filter());
        const box = new Gtk.Box({orientation: Gtk.Orientation.VERTICAL});
        box.append(search);
        box.append(new Gtk.ScrolledWindow({child: list, vexpand: true, hscrollbar_policy: Gtk.PolicyType.NEVER}));
        view.set_content(box);
        this.set_child(view);
        this.set_focus(search);
    }
});

// Groupe de préférences : les applis que la tuile « Fermer les applis » ne ferme pas.
export const KeepAppsGroup = GObject.registerClass(
class KeepAppsGroup extends Adw.PreferencesGroup {
    _init(settings) {
        super._init({
            title: 'Applis à laisser ouvertes',
            description: 'La tuile « Fermer les applis » ne touche pas à leurs fenêtres.',
        });
        this._settings = settings;
        this._rows = [];
        const add = new Gtk.Button({icon_name: 'list-add-symbolic', tooltip_text: 'Ajouter une appli',
            valign: Gtk.Align.CENTER, css_classes: ['flat']});
        add.connect('clicked', () => {
            const kept = new Set(settings.get_strv(KEY));
            new AppPickerDialog(kept, id => settings.set_strv(KEY, [...kept, id])).present(this);
        });
        this.set_header_suffix(add);
        settings.connect(`changed::${KEY}`, () => this._fill());
        this._fill();
    }

    _fill() {
        for (const row of this._rows)
            this.remove(row);
        this._rows = [];
        const ids = this._settings.get_strv(KEY);
        if (!ids.length) {
            const row = new Adw.ActionRow({title: 'Aucune', subtitle: 'Toutes les fenêtres sont fermées.'});
            this._rows.push(row);
            this.add(row);
            return;
        }
        for (const id of ids) {
            const app = Gio.DesktopAppInfo.new(id);
            const remove = new Gtk.Button({icon_name: 'user-trash-symbolic', tooltip_text: 'Retirer',
                valign: Gtk.Align.CENTER, css_classes: ['flat']});
            remove.connect('clicked', () => this._settings.set_strv(KEY, ids.filter(other => other !== id)));
            const row = app ? appRow(app, remove) : new Adw.ActionRow({title: id, subtitle: 'Appli introuvable'});
            if (!app)
                row.add_suffix(remove);
            this._rows.push(row);
            this.add(row);
        }
    }
});
