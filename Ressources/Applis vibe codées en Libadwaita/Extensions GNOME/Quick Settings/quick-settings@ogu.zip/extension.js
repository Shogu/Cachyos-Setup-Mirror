// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import {HiddenAudioOutputs, VolumeOsd} from './audio.js';
import {HoverAutoClose} from './autoClose.js';
import {BatteryLabels} from './batteryLabels.js';
import {ChargeLimitIndicator} from './chargeLimitToggle.js';
import {CloseAppsIndicator} from './closeAppsToggle.js';
import {DropboxIndicator} from './dropboxToggle.js';
import {LogoutDialogLabel} from './logoutDialog.js';
import {NightLightSplit} from './nightLightToggle.js';
import {ProjectorIndicator} from './projectorToggle.js';
import {HiddenScreenshotButton} from './quickSettingsUtils.js';
import {ResourcesIndicator} from './resourcesToggle.js';
import {powerSplit, settingsSplit} from './splitButtons.js';
import {DarkStyleLabel, PowerProfileLabel} from './toggleLabels.js';
import {addTransferIndicator} from './transferIndicator.js';
import {UpdateIndicator} from './updateToggle.js';

function tile(indicator) {
    Main.panel.statusArea.quickSettings.addExternalIndicator(indicator);
    return indicator;
}

// Clé GSettings → fabrique. Chaque fonction renvoie un objet dont destroy()
// défait tout ce qu'elle a changé. L'ordre compte : l'anneau des transferts
// existe avant la tuile Dropbox, qui l'alimente.
const FEATURES = [
    ['auto-close', settings => new HoverAutoClose(Main.panel.statusArea.quickSettings.menu,
        () => Main.panel.closeQuickSettings(), settings.get_uint('close-delay-ms'))],
    ['transfer-indicator', settings => addTransferIndicator(settings.get_strv('transfer-apps'))],
    ['battery-labels', settings => new BatteryLabels(settings)],
    ['hide-screenshot', () => new HiddenScreenshotButton()],
    ['split-settings-button', () => settingsSplit()],
    ['split-power-button', () => powerSplit()],
    ['logout-dialog-label', () => new LogoutDialogLabel()],
    ['charge-limit-toggle', () => new ChargeLimitIndicator(Main.panel.statusArea.quickSettings)],
    ['projector-toggle', () => tile(new ProjectorIndicator())],
    ['update-toggle', settings => tile(new UpdateIndicator(settings.get_string('update-command')))],
    ['close-apps-toggle', settings => tile(new CloseAppsIndicator(settings.get_strv('close-apps-keep')))],
    ['resources-toggle', () => tile(new ResourcesIndicator())],
    ['dropbox-toggle', (_settings, built) => tile(new DropboxIndicator(built.get('transfer-indicator') ?? null))],
    ['night-light-split', () => new NightLightSplit()],
    ['rename-power-profile', () => new PowerProfileLabel()],
    ['rename-dark-style', () => new DarkStyleLabel()],
    ['hide-audio-outputs', () => new HiddenAudioOutputs()],
    ['volume-osd', () => new VolumeOsd()],
];

export default class QuickSettingsExtension extends Extension {
    enable() {
        this._settings = this.getSettings();
        this._built = new Map();
        this._build();
        this._placeResources();
        this._settingsId = this._settings.connect('changed', (_settings, key) => {
            // Le délai se règle à chaud, sans tout reconstruire à chaque cran.
            if (key === 'close-delay-ms' && this._built.has('auto-close'))
                this._built.get('auto-close').delay = this._settings.get_uint(key);
            else
                this._rebuild();
        });
    }

    disable() {
        this._settings.disconnect(this._settingsId);
        this._teardown();
        this._built = null;
        this._settings = null;
    }

    _build() {
        for (const [key, create] of FEATURES) {
            if (!this._settings.get_boolean(key))
                continue;
            // Chaque réglage est indépendant : un échec est journalisé sans bloquer les suivants.
            try {
                this._built.set(key, create(this._settings, this._built));
            } catch (error) {
                console.error(`Quick Settings : ${key} — ${error.message}`, error);
            }
        }
    }

    _teardown() {
        for (const key of [...this._built.keys()].reverse())
            this._built.get(key).destroy();
        this._built.clear();
    }

    _rebuild() {
        this._teardown();
        this._build();
        this._placeResources();
    }

    // La tuile Ressources s'ouvre en bas de l'écran : on la remonte juste avant « Éclairage nocturne »
    // pour que son détail ait la place de se déplier.
    _placeResources() {
        try {
            const quickSettings = Main.panel.statusArea.quickSettings;
            const resources = this._built.get('resources-toggle')?.quickSettingsItems[0];
            const night = quickSettings._nightLight?.quickSettingsItems[0];
            if (resources && night && resources.get_parent() === night.get_parent())
                night.get_parent().set_child_below_sibling(resources, night);
        } catch (error) {
            console.error(`Quick Settings : placement de Ressources — ${error.message}`, error);
        }
    }
}
