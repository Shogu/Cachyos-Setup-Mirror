// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

const ENERGY_TITLE = 'Énergie';
const POWER_SAVER_TITLE = 'Powersave';
const DARK_STYLE_TITLE = 'Thème Dark';

function nativeToggle(indicatorName) {
    const toggle = Main.panel.statusArea.quickSettings[indicatorName]?.quickSettingsItems[0];
    if (!toggle)
        throw new Error(`tuile ${indicatorName} introuvable`);
    return toggle;
}

// « Mode d'alimentation » → « Énergie », et « Économie d'énergie » → « Powersave »
// dans le sous-titre et dans le menu (GNOME les réécrit à chaque changement).
export class PowerProfileLabel {
    constructor() {
        this._toggle = nativeToggle('_powerProfiles');
        this._title = this._toggle.title;
        this._toggle.title = ENERGY_TITLE;
        this._saverItem = this._toggle._profileItems.get('power-saver');
        this._saverName = this._saverItem.label.text;
        this._subtitleId = this._toggle.connect('notify::subtitle', () => this._relabel());
        this._menuId = this._toggle.menu.connect('open-state-changed', () => this._relabel());
        this._relabel();
    }

    _relabel() {
        this._saverItem.label.text = POWER_SAVER_TITLE;
        if (this._toggle.subtitle === this._saverName)
            this._toggle.subtitle = POWER_SAVER_TITLE;
    }

    destroy() {
        this._toggle.disconnect(this._subtitleId);
        this._toggle.menu.disconnect(this._menuId);
        this._saverItem.label.text = this._saverName;
        if (this._toggle.subtitle === POWER_SAVER_TITLE)
            this._toggle.subtitle = this._saverName;
        this._toggle.title = this._title;
        this._toggle = null;
        this._saverItem = null;
    }
}

// « Style sombre » → « Thème Dark ».
export class DarkStyleLabel {
    constructor() {
        this._toggle = nativeToggle('_darkMode');
        this._title = this._toggle.title;
        this._toggle.title = DARK_STYLE_TITLE;
    }

    destroy() {
        this._toggle.title = this._title;
        this._toggle = null;
    }
}
