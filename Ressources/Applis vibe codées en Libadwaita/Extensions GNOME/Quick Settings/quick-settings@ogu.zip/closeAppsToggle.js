// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';

import {QuickToggle, SystemIndicator} from 'resource:///org/gnome/shell/ui/quickSettings.js';

const CONFIRM_TIMEOUT_S = 4;
const IDLE_SUBTITLE = 'Toutes les fenêtres';

// Fenêtres d'applications ordinaires, hors applis à garder (préférences).
function windowsToClose(keep) {
    const tracker = Shell.WindowTracker.get_default();
    return global.get_window_actors()
        .map(actor => actor.meta_window)
        .filter(window => window.get_window_type() === Meta.WindowType.NORMAL && !window.is_skip_taskbar())
        .filter(window => !keep.has(tracker.get_window_app(window)?.get_id() ?? ''));
}

// Tuile « Fermer les applis » : un premier clic demande confirmation (« Fermer
// 5 fenêtres ? »), un second ferme chaque fenêtre comme sa croix le ferait :
// une appli avec un document non enregistré pose sa question habituelle.
const CloseAppsToggle = GObject.registerClass(
class CloseAppsToggle extends QuickToggle {
    _init(keep) {
        super._init({title: 'Fermer les applis', subtitle: IDLE_SUBTITLE, iconName: 'window-close-symbolic',
            toggleMode: false});
        this._keep = new Set(keep);
        this._confirmId = 0;
        this.connect('clicked', () => this._clicked());
    }

    _clicked() {
        const windows = windowsToClose(this._keep);
        if (!this._confirmId) {
            if (!windows.length) {
                this.subtitle = 'Aucune fenêtre';
                this._armReset();
                return;
            }
            this.checked = true;
            this.subtitle = `Fermer ${windows.length} fenêtre${windows.length > 1 ? 's' : ''} ?`;
            this._armReset();
            return;
        }
        const time = global.get_current_time();
        for (const window of windows)
            window.delete(time);
        this._reset();
    }

    _armReset() {
        if (this._confirmId)
            GLib.Source.remove(this._confirmId);
        this._confirmId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, CONFIRM_TIMEOUT_S, () => {
            this._confirmId = 0;
            this._reset();
            return GLib.SOURCE_REMOVE;
        });
    }

    _reset() {
        if (this._confirmId)
            GLib.Source.remove(this._confirmId);
        this._confirmId = 0;
        this.checked = false;
        this.subtitle = IDLE_SUBTITLE;
    }

    destroy() {
        if (this._confirmId)
            GLib.Source.remove(this._confirmId);
        this._confirmId = 0;
        super.destroy();
    }
});

export const CloseAppsIndicator = GObject.registerClass(
class CloseAppsIndicator extends SystemIndicator {
    _init(keep) {
        super._init();
        this.quickSettingsItems.push(new CloseAppsToggle(keep));
    }

    destroy() {
        this.quickSettingsItems.forEach(item => item.destroy());
        this.quickSettingsItems.length = 0;
        super.destroy();
    }
});
