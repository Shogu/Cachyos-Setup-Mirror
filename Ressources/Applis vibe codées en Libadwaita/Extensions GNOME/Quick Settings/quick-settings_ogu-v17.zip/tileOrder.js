// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {QuickMenuToggle, QuickToggle} from 'resource:///org/gnome/shell/ui/quickSettings.js';

import {TILES, completeOrder, otherId, otherTitle} from './tiles.js';

// Classe les tuiles de la grille de Quick Settings, y compris celles d'autres extensions.
// Seules les tuiles connues changent de place (elles échangent leurs emplacements) ;
// curseurs et autres éléments ne bougent pas.
export class TileOrder {
    constructor() {
        this._quickSettings = Main.panel.statusArea.quickSettings;
        this._grid = this._quickSettings.menu._grid;
        this._original = this._grid.get_children();
    }

    _knownActors(tile, built) {
        const items = [];
        const feature = tile.feature && built.get(tile.feature);
        if (feature)
            items.push(...(feature.quickSettingsItems ?? []));
        if (tile.native && !items.length)
            items.push(...(this._quickSettings[tile.native]?.quickSettingsItems ?? []));
        return items.filter(item => item.get_parent() === this._grid);
    }

    // Tuiles de la grille qui n'appartiennent ni à GNOME (connues) ni à cette extension, visibles ou
    // non : une tuile encore masquée au moment du classement (Session au démarrage) doit quand même
    // recevoir sa place, sinon elle reste en bas quand elle apparaît.
    others(built) {
        const known = new Set(TILES.flatMap(tile => this._knownActors(tile, built)));
        const others = new Map();
        for (const child of this._grid.get_children()) {
            if (!(child instanceof QuickToggle || child instanceof QuickMenuToggle) || known.has(child))
                continue;
            if (child.title && !others.has(child.title))
                others.set(child.title, child);
        }
        return others;
    }

    // Identifiants des tuiles affichées en ce moment, pour l'aperçu des préférences.
    visibleIds(built, others) {
        const ids = TILES.filter(tile => this._knownActors(tile, built).some(actor => actor.visible)).map(tile => tile.id);
        for (const [title, actor] of others) {
            if (actor.visible)
                ids.push(otherId(title));
        }
        return ids;
    }

    apply(order, built, others) {
        if (!order.length)
            return;
        const grid = this._grid;
        const byId = new Map(TILES.map(tile => [tile.id, tile]));
        const wanted = [];
        for (const id of completeOrder(order, [...others.keys()])) {
            const title = otherTitle(id);
            const actors = title === null ? this._knownActors(byId.get(id), built) : [others.get(title)];
            for (const actor of actors) {
                if (!wanted.includes(actor))
                    wanted.push(actor);
            }
        }
        const children = grid.get_children();
        const result = [...children];
        const slots = children.flatMap((child, index) => (wanted.includes(child) ? [index] : []));
        slots.forEach((slot, i) => {
            result[slot] = wanted[i];
        });
        result.forEach((actor, index) => grid.set_child_at_index(actor, index));
        // Le détail déroulant d'une tuile reste juste après elle.
        for (const actor of wanted) {
            const menu = actor.menu?.actor;
            if (menu && menu.get_parent() === grid)
                grid.set_child_above_sibling(menu, actor);
        }
    }

    restore() {
        const grid = this._grid;
        this._original.filter(actor => actor.get_parent() === grid)
            .forEach((actor, index) => grid.set_child_at_index(actor, index));
        this._original = [];
    }
}
