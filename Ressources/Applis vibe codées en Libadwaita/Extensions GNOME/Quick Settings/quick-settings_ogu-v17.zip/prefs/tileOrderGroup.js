// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Adw from 'gi://Adw';
import Gdk from 'gi://Gdk';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Gtk from 'gi://Gtk';
import Pango from 'gi://Pango';

import {TILES, TRANSIENT, completeOrder, otherTitle} from '../tiles.js';

const KEY = 'tile-order';
const OTHERS_KEY = 'other-tiles';
const VISIBLE_KEY = 'visible-tiles';
const TITLES = new Map(TILES.map(tile => [tile.id, tile.title]));

const CSS = `
.fb-tile { border-radius: 999px; padding: 10px 16px; }
.fb-tile:drop(active) { box-shadow: inset 0 0 0 2px var(--accent-bg-color); }
.fb-tile.dragging { opacity: 0.4; }
`;

const titleOf = id => otherTitle(id) ?? TITLES.get(id) ?? id;
// Tuiles de l'extension qui n'existent que si leur interrupteur est activé.
const SWITCHED = TILES.filter(tile => tile.feature && !tile.native);

// Aperçu de la grille de Quick Settings (deux colonnes, comme le vrai menu), limité aux tuiles
// affichées : on glisse une tuile sur une autre pour la déplacer ; au clavier, Ctrl + flèches.
// Seules ces tuiles sont enregistrées : une tuile coupée puis réactivée, ou la Clé USB, s'ajoute en bas.
// En dessous, deux lignes d'information : tuiles désactivées (liens vers leur interrupteur) et
// tuiles absentes en ce moment (matériel, clé débranchée, tuile masquée par une autre extension).
export const TileOrderGroup = GObject.registerClass(
class TileOrderGroup extends Adw.PreferencesGroup {
    _init(settings, showSwitch) {
        super._init({
            title: 'Ordre des tuiles',
            description: 'Glisser une tuile sur une autre pour la déplacer (au clavier : Ctrl + flèches). '
                + 'L’aperçu montre les tuiles affichées, sur deux colonnes comme Quick Settings ; '
                + 'une tuile réactivée et la Clé USB s’ajoutent en bas. Ouvrir Quick Settings une fois '
                + 'met l’aperçu à jour.',
        });
        this._settings = settings;
        this._focus = null;

        const provider = new Gtk.CssProvider();
        provider.load_from_string(CSS);
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION);

        const reset = new Gtk.Button({icon_name: 'edit-undo-symbolic', tooltip_text: 'Revenir à l’ordre d’origine',
            valign: Gtk.Align.CENTER, css_classes: ['flat']});
        reset.connect('clicked', () => settings.set_strv(KEY, []));
        this.set_header_suffix(reset);

        this._grid = new Gtk.FlowBox({
            min_children_per_line: 2,
            max_children_per_line: 2,
            homogeneous: true,
            column_spacing: 12,
            row_spacing: 12,
            selection_mode: Gtk.SelectionMode.NONE,
        });
        this.add(this._grid);
        this._disabled = new Gtk.Label({xalign: 0, wrap: true, margin_top: 12, css_classes: ['dim-label', 'caption']});
        this._disabled.connect('activate-link', (_label, key) => {
            showSwitch(key);
            return true;
        });
        this.add(this._disabled);
        this._absent = new Gtk.Label({xalign: 0, wrap: true, margin_top: 4, css_classes: ['dim-label', 'caption']});
        this.add(this._absent);

        for (const key of [KEY, OTHERS_KEY, VISIBLE_KEY, ...SWITCHED.map(tile => tile.feature)])
            settings.connect(`changed::${key}`, () => this._fill());
        this._fill();
    }

    // Tuiles affichées, dans l'ordre (toutes, hors Clé USB, tant que Quick Settings n'a rien publié).
    get _order() {
        const order = completeOrder(this._settings.get_strv(KEY), this._settings.get_strv(OTHERS_KEY))
            .filter(id => !TRANSIENT.includes(id));
        const visible = new Set(this._settings.get_strv(VISIBLE_KEY));
        return visible.size ? order.filter(id => visible.has(id)) : order;
    }

    // Place `id` juste avant `target` s'il venait d'après, juste après s'il venait d'avant :
    // la tuile prend la case visée et les autres se décalent d'un cran.
    _moveTo(id, target) {
        const order = this._order;
        const from = order.indexOf(id);
        const to = order.indexOf(target);
        if (from < 0 || to < 0 || from === to)
            return;
        order.splice(from, 1);
        order.splice(order.indexOf(target) + (from < to ? 1 : 0), 0, id);
        this._settings.set_strv(KEY, order);
    }

    _card(id, shown, index) {
        const box = new Gtk.Box({spacing: 10, css_classes: ['card', 'fb-tile']});
        box.append(new Gtk.Image({icon_name: 'list-drag-handle-symbolic', css_classes: ['dim-label']}));
        const labels = new Gtk.Box({orientation: Gtk.Orientation.VERTICAL, valign: Gtk.Align.CENTER});
        labels.append(new Gtk.Label({label: titleOf(id), xalign: 0, ellipsize: Pango.EllipsizeMode.END, css_classes: ['heading']}));
        if (otherTitle(id) !== null)
            labels.append(new Gtk.Label({label: 'Autre extension', xalign: 0, css_classes: ['dim-label', 'caption']}));
        box.append(labels);

        const source = new Gtk.DragSource({actions: Gdk.DragAction.MOVE});
        source.connect('prepare', () => Gdk.ContentProvider.new_for_value(id));
        source.connect('drag-begin', (_source, drag) => {
            Gtk.DragIcon.get_for_drag(drag).child = new Gtk.Label({label: titleOf(id), css_classes: ['card', 'fb-tile', 'heading']});
            box.add_css_class('dragging');
        });
        source.connect('drag-end', () => box.remove_css_class('dragging'));
        box.add_controller(source);

        const target = Gtk.DropTarget.new(GObject.TYPE_STRING, Gdk.DragAction.MOVE);
        target.connect('drop', (_target, value) => {
            this._moveTo(value, id);
            return true;
        });
        box.add_controller(target);

        const child = new Gtk.FlowBoxChild({child: box, focusable: true, tooltip_text: 'Glisser pour déplacer'});
        const keys = new Gtk.EventControllerKey();
        keys.connect('key-pressed', (_keys, keyval, _code, state) => {
            if (!(state & Gdk.ModifierType.CONTROL_MASK))
                return false;
            const step = {[Gdk.KEY_Left]: -1, [Gdk.KEY_Up]: -2, [Gdk.KEY_Right]: 1, [Gdk.KEY_Down]: 2}[keyval];
            const neighbour = step && shown[index + step];
            if (!neighbour)
                return false;
            this._focus = id;
            this._moveTo(id, neighbour);
            return true;
        });
        child.add_controller(keys);
        return child;
    }

    _fill() {
        this._grid.remove_all();
        const shown = this._order;
        let focus = null;
        shown.forEach((id, index) => {
            const child = this._card(id, shown, index);
            this._grid.append(child);
            if (id === this._focus)
                focus = child;
        });
        focus?.grab_focus();
        this._focus = null;
        this._fillInfo(shown);
    }

    _fillInfo(shown) {
        const disabled = SWITCHED.filter(tile => !this._settings.get_boolean(tile.feature));
        this._disabled.visible = disabled.length > 0;
        const links = disabled.map(tile => `<a href="${tile.feature}">${GLib.markup_escape_text(tile.title, -1)}</a>`);
        this._disabled.set_markup(`Désactivées : ${links.join(', ')} — elles s’ajouteront en bas si tu les réactives.`);

        const visible = new Set(this._settings.get_strv(VISIBLE_KEY));
        const off = new Set(disabled.map(tile => tile.id));
        const all = completeOrder([], this._settings.get_strv(OTHERS_KEY));
        const absent = visible.size ? all.filter(id => !shown.includes(id) && !visible.has(id) && !off.has(id)) : [];
        this._absent.visible = absent.length > 0;
        this._absent.label = `Absentes en ce moment : ${absent.map(titleOf).join(', ')}.`;
    }
});
