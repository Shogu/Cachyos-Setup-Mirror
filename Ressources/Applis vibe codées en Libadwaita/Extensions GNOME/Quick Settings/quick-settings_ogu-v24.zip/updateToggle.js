// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {QuickToggle, SystemIndicator} from 'resource:///org/gnome/shell/ui/quickSettings.js';

Gio._promisify(Gio.File.prototype, 'load_contents_async');
Gio._promisify(Gio.File.prototype, 'query_info_async');
Gio._promisify(Gio.File.prototype, 'delete_async');

// Le script de mise à jour crée ce fichier au début (en y écrivant son PID : echo $$ > …) et le
// supprime à la fin : tant qu'il existe et que ce processus vit, la tuile est bleue.
const SCRIPT_NAME = 'update-system';
const RUNNING_FILE = `${SCRIPT_NAME}.running`;
// Témoin sans PID (ancien script) : considéré comme orphelin passé ce délai.
const STALE_AFTER_S = 10 * 60;
// La mort d'un processus ne déclenche aucun événement : tant que le témoin existe, on vérifie
// régulièrement que le script vit encore (terminal fermé, script tué sans nettoyage).
const CHECK_S = 5;

const IDLE_SUBTITLE = 'Lancer Pacman';

const decoder = new TextDecoder();
const cancelled = error => error.matches(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED);

// Symbolique de Pamac ; replis si le thème ne la fournit pas.
function upgradeIcon() {
    return Gio.ThemedIcon.new_from_names([
        'org.manjaro.pamac.manager-symbolic',
        'system-software-install-symbolic',
        'software-update-available-symbolic',
    ]);
}

const UpdateToggle = GObject.registerClass(
class UpdateToggle extends QuickToggle {
    _init(onLaunch) {
        super._init({title: 'Mise à jour', subtitle: IDLE_SUBTITLE, gicon: upgradeIcon(), toggle_mode: false});
        this.connect('clicked', () => {
            if (!this.checked)
                onLaunch();
        });
    }

    setRunning(running) {
        this.checked = running;
        this.subtitle = running ? 'En cours…' : IDLE_SUBTITLE;
    }
});

// Tuile « Mise à jour » de Quick Settings : un clic lance le script choisi dans
// les préférences ; elle reste bleue tant que le script tourne.
export const UpdateIndicator = GObject.registerClass(
class UpdateIndicator extends SystemIndicator {
    _init(command) {
        super._init();
        this._command = command.replace(/^~(?=\/)/, GLib.get_home_dir());
        this._pollId = 0;
        this._checkId = 0;
        this._serial = 0;
        this._cancellable = new Gio.Cancellable();
        this._runningFile = Gio.File.new_for_path(GLib.build_filenamev([GLib.get_user_runtime_dir(), RUNNING_FILE]));

        this._toggle = new UpdateToggle(() => this._launch());
        this.quickSettingsItems.push(this._toggle);

        this._monitor = Gio.File.new_for_path(GLib.get_user_runtime_dir())
            .monitor_directory(Gio.FileMonitorFlags.NONE, null);
        this._monitor.connect('changed', (_monitor, file) => {
            if (file.get_basename() === RUNNING_FILE)
                this._sync();
        });
        this._sync();
    }

    async _sync() {
        const serial = ++this._serial;
        const running = await this._scriptRunning();
        if (running === null || serial !== this._serial)
            return;
        this._toggle.setRunning(running);
        this._watch(running);
    }

    _watch(running) {
        if (running && !this._checkId) {
            this._checkId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, CHECK_S, () => {
                this._sync();
                return GLib.SOURCE_CONTINUE;
            });
        } else if (!running && this._checkId) {
            GLib.Source.remove(this._checkId);
            this._checkId = 0;
        }
    }

    // true / false, ou null si annulé. Un témoin orphelin est supprimé au passage.
    async _scriptRunning() {
        let contents, info;
        try {
            [contents] = await this._runningFile.load_contents_async(this._cancellable);
            info = await this._runningFile.query_info_async('time::modified', Gio.FileQueryInfoFlags.NONE,
                GLib.PRIORITY_DEFAULT, this._cancellable);
        } catch (error) {
            return cancelled(error) ? null : false;
        }
        const pid = Number.parseInt(decoder.decode(contents), 10);
        const age = GLib.DateTime.new_now_utc().difference(info.get_modification_date_time()) / GLib.USEC_PER_SEC;
        const running = pid > 0 ? await this._scriptAlive(pid) : age <= STALE_AFTER_S;
        if (running === false)
            this._runningFile.delete_async(GLib.PRIORITY_DEFAULT, this._cancellable).catch(() => {});
        return running;
    }

    // Le PID doit exister et être encore celui du script (un PID peut être réattribué).
    async _scriptAlive(pid) {
        try {
            const [cmdline] = await Gio.File.new_for_path(`/proc/${pid}/cmdline`).load_contents_async(this._cancellable);
            return decoder.decode(cmdline).includes(SCRIPT_NAME);
        } catch (error) {
            return cancelled(error) ? null : false;
        }
    }

    _launch() {
        const command = this._command;
        if (!GLib.file_test(command, GLib.FileTest.IS_EXECUTABLE)) {
            Main.notify('Mise à jour', `Script introuvable ou non exécutable : ${command}`);
            return;
        }
        try {
            Gio.Subprocess.new([command], Gio.SubprocessFlags.NONE);
        } catch (error) {
            Main.notify('Mise à jour', error.message);
            return;
        }
        // La tuile devient bleue sans attendre le fichier témoin ; elle
        // revient à l'état réel si celui-ci n'apparaît pas.
        this._toggle.setRunning(true);
        if (this._pollId)
            GLib.Source.remove(this._pollId);
        this._pollId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 10, () => {
            this._pollId = 0;
            this._sync();
            return GLib.SOURCE_REMOVE;
        });
        Main.panel.closeQuickSettings();
    }

    destroy() {
        if (this._pollId)
            GLib.Source.remove(this._pollId);
        this._pollId = 0;
        this._watch(false);
        this._cancellable.cancel();
        this._monitor.cancel();
        this.quickSettingsItems.forEach(item => item.destroy());
        this.quickSettingsItems.length = 0;
        super.destroy();
    }
});
