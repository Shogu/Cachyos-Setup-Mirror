// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';

Gio._promisify(Gio.File.prototype, 'load_contents_async');
Gio._promisify(Gio.File.prototype, 'query_filesystem_info_async');
Gio._promisify(Gio.File.prototype, 'enumerate_children_async');
Gio._promisify(Gio.FileEnumerator.prototype, 'next_files_async');

const decoder = new TextDecoder();
const CPU_SENSORS = ['k10temp', 'zenpower', 'coretemp'];

async function readText(path, cancellable) {
    try {
        const [bytes] = await Gio.File.new_for_path(path).load_contents_async(cancellable);
        return decoder.decode(bytes);
    } catch {
        return null;
    }
}

async function readNumber(path, cancellable) {
    const text = await readText(path, cancellable);
    return text === null ? null : Number(text.trim());
}

async function listDir(path, cancellable) {
    try {
        const enumerator = await Gio.File.new_for_path(path).enumerate_children_async('standard::name',
            Gio.FileQueryInfoFlags.NONE, GLib.PRIORITY_DEFAULT, cancellable);
        const names = [];
        for (;;) {
            const infos = await enumerator.next_files_async(256, GLib.PRIORITY_DEFAULT, cancellable);
            if (!infos.length)
                break;
            names.push(...infos.map(info => info.get_name()));
        }
        enumerator.close(null);
        return names;
    } catch {
        return [];
    }
}

// Capteurs et périphériques cherchés une seule fois.
async function findDevices(cancellable) {
    const devices = {temperature: null, gpu: null, battery: null};

    for (const hwmon of await listDir('/sys/class/hwmon', cancellable)) {
        const name = (await readText(`/sys/class/hwmon/${hwmon}/name`, cancellable))?.trim();
        if (CPU_SENSORS.includes(name)) {
            devices.temperature = `/sys/class/hwmon/${hwmon}/temp1_input`;
            break;
        }
    }

    for (const card of await listDir('/sys/class/drm', cancellable)) {
        const path = `/sys/class/drm/${card}/device/gpu_busy_percent`;
        if (/^card\d+$/.test(card) && await readNumber(path, cancellable) !== null) {
            devices.gpu = path;
            break;
        }
    }

    for (const supply of await listDir('/sys/class/power_supply', cancellable)) {
        if ((await readText(`/sys/class/power_supply/${supply}/type`, cancellable))?.trim() === 'Battery') {
            devices.battery = `/sys/class/power_supply/${supply}`;
            break;
        }
    }
    return devices;
}

function parseCpu(stat) {
    const fields = stat.split('\n', 1)[0].trim().split(/\s+/).slice(1, 9).map(Number);
    const total = fields.reduce((sum, value) => sum + value, 0);
    return {total, idle: fields[3] + fields[4]};
}

function parseMemory(meminfo) {
    const value = key => Number(meminfo.match(new RegExp(`^${key}:\\s+(\\d+)`, 'm'))?.[1] ?? 0) * 1024;
    const total = value('MemTotal');
    return {total, used: total - value('MemAvailable')};
}

function parseNetwork(netdev) {
    let rx = 0, tx = 0;
    for (const line of netdev.split('\n').slice(2)) {
        const [iface, data] = line.split(':');
        if (!data || iface.trim() === 'lo')
            continue;
        const fields = data.trim().split(/\s+/).map(Number);
        rx += fields[0];
        tx += fields[8];
    }
    return {rx, tx};
}

async function readBattery(path, cancellable) {
    const [status, capacity, powerNow, currentNow, voltageNow, energyNow, energyFull, energyDesign] = await Promise.all([
        readText(`${path}/status`, cancellable),
        readNumber(`${path}/capacity`, cancellable),
        readNumber(`${path}/power_now`, cancellable),
        readNumber(`${path}/current_now`, cancellable),
        readNumber(`${path}/voltage_now`, cancellable),
        readNumber(`${path}/energy_now`, cancellable),
        readNumber(`${path}/energy_full`, cancellable),
        readNumber(`${path}/energy_full_design`, cancellable),
    ]);
    const watts = powerNow !== null ? powerNow / 1e6 : (currentNow ?? 0) * (voltageNow ?? 0) / 1e12;
    const state = status?.trim() ?? 'Unknown';
    let hoursLeft = null;
    if (watts > 0.1 && energyNow !== null && state === 'Discharging')
        hoursLeft = energyNow / 1e6 / watts;
    else if (watts > 0.1 && energyNow !== null && energyFull !== null && state === 'Charging')
        hoursLeft = (energyFull - energyNow) / 1e6 / watts;
    // Santé : capacité actuelle rapportée à la capacité d'origine.
    const health = energyFull && energyDesign ? Math.min(1, energyFull / energyDesign) : null;
    return {watts, percent: capacity ?? 0, state, hoursLeft, health};
}

// Lecture des compteurs du noyau ; les valeurs qui demandent deux mesures
// (processeur, réseau) sont null au premier appel.
export class ResourcesSampler {
    constructor() {
        this._cancellable = new Gio.Cancellable();
        this._devices = null;
        this._home = Gio.File.new_for_path(GLib.get_home_dir());
        this.reset();
    }

    reset() {
        this._cpu = null;
        this._net = null;
        this._time = 0;
    }

    async sample() {
        const cancellable = this._cancellable;
        this._devices ??= await findDevices(cancellable);
        const {temperature, gpu, battery} = this._devices;

        const [stat, meminfo, netdev, temp, gpuBusy, batteryInfo, fsInfo] = await Promise.all([
            readText('/proc/stat', cancellable),
            readText('/proc/meminfo', cancellable),
            readText('/proc/net/dev', cancellable),
            temperature ? readNumber(temperature, cancellable) : null,
            gpu ? readNumber(gpu, cancellable) : null,
            battery ? readBattery(battery, cancellable) : null,
            this._home.query_filesystem_info_async('filesystem::size,filesystem::free', GLib.PRIORITY_DEFAULT, cancellable)
                .catch(() => null),
        ]);
        if (cancellable.is_cancelled())
            return null;

        const now = GLib.get_monotonic_time();
        const seconds = (now - this._time) / GLib.USEC_PER_SEC;
        const cpu = parseCpu(stat);
        const net = parseNetwork(netdev);
        const cpuTicks = this._cpu ? cpu.total - this._cpu.total : 0;
        const result = {
            cpu: this._cpu && cpuTicks > 0 ? 1 - (cpu.idle - this._cpu.idle) / cpuTicks : null,
            memory: parseMemory(meminfo),
            temperature: temp === null ? null : temp / 1000,
            gpu: gpuBusy === null ? null : gpuBusy / 100,
            disk: fsInfo ? {
                total: fsInfo.get_attribute_uint64('filesystem::size'),
                free: fsInfo.get_attribute_uint64('filesystem::free'),
            } : null,
            network: this._net ? {
                rx: Math.max(0, net.rx - this._net.rx) / seconds,
                tx: Math.max(0, net.tx - this._net.tx) / seconds,
            } : null,
            battery: batteryInfo,
        };
        this._cpu = cpu;
        this._net = net;
        this._time = now;
        return result;
    }

    destroy() {
        this._cancellable.cancel();
        this._cancellable = null;
    }
}
