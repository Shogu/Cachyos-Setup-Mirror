// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import {TILES, completeOrder} from './tiles.js';

// Classe les tuiles de la grille de Quick Settings. Seules les tuiles connues changent de
// place (elles échangent leurs emplacements) ; curseurs et autres éléments ne bougent pas.
export class TileOrder {
    constructor() {
        this._quickSettings = Main.panel.statusArea.quickSettings;
        this._grid = this._quickSettings.menu._grid;
        this._original = this._grid.get_children();
    }

    _actors(tile, built) {
        const grid = this._grid;
        const items = [];
        const feature = tile.feature && built.get(tile.feature);
        if (feature)
            items.push(...(feature.quickSettingsItems ?? []));
        if (tile.native && !items.length)
            items.push(...(this._quickSettings[tile.native]?.quickSettingsItems ?? []));
        return items.filter(item => item.get_parent() === grid);
    }

    apply(order, built) {
        if (!order.length)
            return;
        const grid = this._grid;
        const byId = new Map(TILES.map(tile => [tile.id, tile]));
        const wanted = [];
        for (const id of completeOrder(order)) {
            for (const actor of this._actors(byId.get(id), built)) {
                if (!wanted.includes(actor))
                    wanted.push(actor);
            }
        }
        const children = grid.get_children();
        const result = [...children];
        const slots = children.flatMap((child, index) => (wanted.includes(child) ? [index] : []));
        slots.forEach((slot, i) => {
            result[slot] = wanted[i];
        });
        result.forEach((actor, index) => grid.set_child_at_index(actor, index));
        // Le détail déroulant d'une tuile reste juste après elle.
        for (const actor of wanted) {
            const menu = actor.menu?.actor;
            if (menu && menu.get_parent() === grid)
                grid.set_child_above_sibling(menu, actor);
        }
    }

    restore() {
        const grid = this._grid;
        this._original.filter(actor => actor.get_parent() === grid)
            .forEach((actor, index) => grid.set_child_at_index(actor, index));
        this._original = [];
    }
}
