// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
// Aucune importation GNOME Shell ici : ce fichier est aussi chargé par les préférences.
// Tuiles que l'on peut classer : identifiant → libellé (préférences) et origine.
// `native` : indicateur de GNOME Shell ; `feature` : clé de la fonction de l'extension.
export const TILES = [
    {id: 'network', title: 'Wi-Fi et réseau', native: '_network'},
    {id: 'bluetooth', title: 'Bluetooth', native: '_bluetooth'},
    {id: 'power-profiles', title: 'Énergie', native: '_powerProfiles'},
    {id: 'resources', title: 'Ressources', feature: 'resources-toggle'},
    {id: 'night-light', title: 'Éclairage nocturne', native: '_nightLight', feature: 'night-light-split'},
    {id: 'dark-mode', title: 'Thème Dark', native: '_darkMode'},
    {id: 'rfkill', title: 'Mode avion', native: '_rfkill'},
    {id: 'auto-rotate', title: 'Rotation automatique', native: '_autoRotate'},
    {id: 'dropbox', title: 'Dropbox', feature: 'dropbox-toggle'},
    {id: 'update', title: 'Upgrade', feature: 'update-toggle'},
    {id: 'close-apps', title: 'Fermer les applications', feature: 'close-apps-toggle'},
    {id: 'charge-limit', title: 'Charge batterie', feature: 'charge-limit-toggle'},
    {id: 'projector', title: 'Projecteur', feature: 'projector-toggle'},
];

// Complète un ordre enregistré : tuiles inconnues retirées, tuiles absentes ajoutées à la fin.
export function completeOrder(order) {
    const known = TILES.map(tile => tile.id);
    const kept = order.filter(id => known.includes(id));
    return [...kept, ...known.filter(id => !kept.includes(id))];
}
