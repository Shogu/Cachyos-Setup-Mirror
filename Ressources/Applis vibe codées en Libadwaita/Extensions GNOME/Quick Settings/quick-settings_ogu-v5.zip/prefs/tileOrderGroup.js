// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Adw from 'gi://Adw';
import GObject from 'gi://GObject';
import Gtk from 'gi://Gtk';

import {TILES, completeOrder} from '../tiles.js';

const KEY = 'tile-order';
const TITLES = new Map(TILES.map(tile => [tile.id, tile.title]));

// Groupe de préférences : classer les tuiles de Quick Settings (haut/bas). La grille compte
// deux colonnes : la liste se lit de gauche à droite, puis de haut en bas.
export const TileOrderGroup = GObject.registerClass(
class TileOrderGroup extends Adw.PreferencesGroup {
    _init(settings) {
        super._init({
            title: 'Ordre des tuiles',
            description: 'Les tuiles se rangent sur deux colonnes, de gauche à droite puis de haut en bas. Remonter Ressources lui laisse la place de se déplier.',
        });
        this._settings = settings;
        this._rows = [];

        const reset = new Gtk.Button({icon_name: 'edit-undo-symbolic', tooltip_text: 'Revenir à l’ordre d’origine',
            valign: Gtk.Align.CENTER, css_classes: ['flat']});
        reset.connect('clicked', () => settings.set_strv(KEY, []));
        this.set_header_suffix(reset);

        settings.connect(`changed::${KEY}`, () => this._fill());
        this._fill();
    }

    _move(order, index, delta) {
        const target = index + delta;
        if (target < 0 || target >= order.length)
            return;
        const next = [...order];
        [next[index], next[target]] = [next[target], next[index]];
        this._settings.set_strv(KEY, next);
    }

    _fill() {
        for (const row of this._rows)
            this.remove(row);
        this._rows = [];
        const saved = this._settings.get_strv(KEY);
        const order = completeOrder(saved);
        order.forEach((id, index) => {
            const row = new Adw.ActionRow({title: TITLES.get(id), subtitle: saved.length ? '' : 'Ordre d’origine'});
            const box = new Gtk.Box({spacing: 2, valign: Gtk.Align.CENTER});
            const up = new Gtk.Button({icon_name: 'go-up-symbolic', tooltip_text: 'Monter',
                css_classes: ['flat'], sensitive: index > 0});
            const down = new Gtk.Button({icon_name: 'go-down-symbolic', tooltip_text: 'Descendre',
                css_classes: ['flat'], sensitive: index < order.length - 1});
            up.connect('clicked', () => this._move(order, index, -1));
            down.connect('clicked', () => this._move(order, index, 1));
            box.append(up);
            box.append(down);
            row.add_suffix(box);
            this._rows.push(row);
            this.add(row);
        });
    }
});
