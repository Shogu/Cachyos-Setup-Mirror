import {
    Extension as BaseExtension,
    InjectionManager,
} from 'resource:///org/gnome/shell/extensions/extension.js';
import {panel} from 'resource:///org/gnome/shell/ui/main.js';
import {Indicator} from 'resource:///org/gnome/shell/ui/status/system.js';
import UPower from 'gi://UPowerGlib';

function _formatTime(seconds) {
    if (!Number.isFinite(seconds) || seconds <= 0)
        return '…';

    const totalMinutes = Math.round(seconds / 60);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${hours}:${minutes.toString().padStart(2, '0')}`;
}

function _formatWatts(proxy) {
    const rawWatts = Number(proxy?.EnergyRate);
    if (!Number.isFinite(rawWatts) || rawWatts === 0)
        return null;

    return `${Math.abs(rawWatts).toFixed(1)} W`;
}

function _batteryTexts(proxy) {
    if (!proxy?.IsPresent)
        return null;

    const percentage = `${Math.round(proxy.Percentage)}%`;
    let timeText = '…';

    switch (proxy.State) {
    case UPower.DeviceState.FULLY_CHARGED:
        timeText = '∞';
        break;
    case UPower.DeviceState.CHARGING:
        timeText = _formatTime(proxy.TimeToFull);
        break;
    case UPower.DeviceState.DISCHARGING:
        timeText = _formatTime(proxy.TimeToEmpty);
        break;
    default:
        break;
    }

    const watts = _formatWatts(proxy);
    return {
        panel: `${timeText} - ${percentage}`,
        quickSettings: watts ? `${timeText} - ${watts}` : timeText,
    };
}

function _system() {
    return panel.statusArea?.quickSettings?._system ?? null;
}

// Pose les textes personnalisés juste après la mise à jour native de GNOME.
function _applyTexts(system) {
    const powerToggle = system?._systemItem?.powerToggle;
    const texts = _batteryTexts(powerToggle?._proxy);
    if (!texts)
        return;

    // Le titre du bouton est lié au texte de l'étiquette de la barre : on pose
    // d'abord le titre, puis le texte de la barre.
    powerToggle.title = texts.quickSettings;
    system._percentageLabel.text = texts.panel;
    system._percentageLabel.visible = true;
}

export default class BatteryTimePercentageOguExtension extends BaseExtension {
    enable() {
        const powerToggle = _system()?._systemItem?.powerToggle;
        if (!powerToggle)
            return;

        this._im = new InjectionManager();

        // PowerToggle._sync est appelé à chaque changement de propriété d'UPower
        // (pourcentage, durée restante, puissance instantanée) : les textes sont
        // donc réappliqués à chaque mise à jour, sans écoute supplémentaire.
        this._im.overrideMethod(Object.getPrototypeOf(powerToggle), '_sync', nativeSync => {
            return function (...args) {
                nativeSync.apply(this, args);
                _applyTexts(_system());
            };
        });

        // Indicator._sync repose la visibilité de l'étiquette selon le réglage GNOME.
        this._im.overrideMethod(Indicator.prototype, '_sync', nativeSync => {
            return function (...args) {
                nativeSync.apply(this, args);
                _applyTexts(this);
            };
        });

        powerToggle._sync();
    }

    disable() {
        this._im?.clear();
        this._im = null;

        // Retour immédiat aux textes natifs.
        const system = _system();
        system?._systemItem?.powerToggle?._sync();
        system?._sync();
    }
}
