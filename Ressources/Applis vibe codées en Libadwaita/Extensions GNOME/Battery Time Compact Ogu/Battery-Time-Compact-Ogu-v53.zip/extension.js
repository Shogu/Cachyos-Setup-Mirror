import {
    Extension as BaseExtension,
    InjectionManager,
} from 'resource:///org/gnome/shell/extensions/extension.js';
import {panel} from 'resource:///org/gnome/shell/ui/main.js';
import {Indicator} from 'resource:///org/gnome/shell/ui/status/system.js';
import UPower from 'gi://UPowerGlib';

function _formatTime(seconds) {
    if (!Number.isFinite(seconds) || seconds <= 0)
        return '…';

    const totalMinutes = Math.round(seconds / 60);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${hours}:${minutes.toString().padStart(2, '0')}`;
}

function _formatWatts(proxy) {
    const rawWatts = Number(proxy?.EnergyRate);
    if (!Number.isFinite(rawWatts) || rawWatts === 0)
        return null;

    return `${Math.abs(rawWatts).toFixed(1)} W`;
}

function _batteryTexts(proxy) {
    if (!proxy?.IsPresent)
        return null;

    const percentage = `${Math.round(proxy.Percentage)}%`;
    let timeText = '…';

    switch (proxy.State) {
    case UPower.DeviceState.FULLY_CHARGED:
        timeText = '∞';
        break;
    case UPower.DeviceState.CHARGING:
        timeText = _formatTime(proxy.TimeToFull);
        break;
    case UPower.DeviceState.DISCHARGING:
        timeText = _formatTime(proxy.TimeToEmpty);
        break;
    default:
        break;
    }

    const watts = _formatWatts(proxy);
    return {
        panel: `${timeText} - ${percentage}`,
        quickSettings: watts ? `${timeText} - ${watts}` : timeText,
    };
}

export default class BatteryTimePercentageOguExtension extends BaseExtension {
    enable() {
        this._im = new InjectionManager();
        this._proxy = null;
        this._proxyNotifyId = 0;

        this._im.overrideMethod(Indicator.prototype, '_sync', function (nativeSync) {
            return function () {
                // GNOME met d'abord à jour son état natif. Notre texte est posé
                // ensuite afin qu'il ne soit pas remplacé par le pourcentage natif.
                nativeSync.call(this);

                const {powerToggle} = this._systemItem;
                const texts = _batteryTexts(powerToggle?._proxy);
                if (!texts)
                    return;

                powerToggle.title = texts.quickSettings;
                this._percentageLabel.text = texts.panel;
                this._percentageLabel.visible = true;
            };
        });

        this._connectEnergyRate();
        this._syncNow();
    }

    disable() {
        if (this._proxy && this._proxyNotifyId)
            this._proxy.disconnect(this._proxyNotifyId);

        this._proxyNotifyId = 0;
        this._proxy = null;

        this._im?.clear();
        this._im = null;

        this._syncNow();
    }

    _connectEnergyRate() {
        const system = panel.statusArea?.quickSettings?._system;
        const proxy = system?._systemItem?.powerToggle?._proxy;
        if (!proxy)
            return;

        this._proxy = proxy;
        this._proxyNotifyId = proxy.connect('notify::energy-rate', () => {
            this._syncNow();
        });
    }

    _syncNow() {
        const system = panel.statusArea?.quickSettings?._system;
        if (!system)
            return;

        // Indicator._sync() est surchargé pendant que l'extension est active ;
        // il réapplique donc à la fois le texte top bar et le titre Quick Settings.
        system._sync();
    }
}
