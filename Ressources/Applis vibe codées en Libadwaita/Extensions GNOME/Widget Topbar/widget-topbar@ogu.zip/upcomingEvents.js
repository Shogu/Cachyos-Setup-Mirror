// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
/* Widget Topbar — section « À venir » sous la grille du calendrier.
 *
 * La liste native ne montre que le jour sélectionné : cette section occupe la
 * place laissée vide sous la grille et annonce le reste de la semaine.
 *
 * Elle lit la même source que la liste native (`_eventsItem._eventSource`) et
 * n'appelle jamais `requestRange()` : la grille demande déjà les six semaines
 * affichées, et redemander une autre plage effacerait ses pastilles de jour.
 */

import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import {assignColors, rgba, sourceKey} from './eventModel.js';

const MAX_ROWS = 10;
const DOT_STYLE = 'width: 9px; height: 9px; border-radius: 999px; margin-top: 6px; margin-right: 2px;';

// Le shell ne sait pas ouvrir un rendez-vous précis : comme la liste native, on
// ouvre Agenda sur le jour voulu, avec repli sur le lancement simple de l'appli.
function openCalendarAt(day) {
    Main.overview?.hide();
    Main.panel.closeCalendar();
    const appInfo = Gio.AppInfo.get_default_for_type('text/calendar', false);
    const launch = () => appInfo?.launch([], global.create_app_launch_context(0, -1));
    if (appInfo?.get_id() !== 'org.gnome.Calendar.desktop') {
        launch();
        return;
    }
    Gio.DBus.session.call(
        'org.gnome.Calendar', '/org/gnome/Calendar', 'org.freedesktop.Application', 'ActivateAction',
        new GLib.Variant('(sava{sv})',
            ['show-date', [new GLib.Variant('x', Math.floor(day.getTime() / 1000))], {}]),
        null, Gio.DBusCallFlags.NONE, -1, null, (bus, result) => {
            try {
                bus.call_finish(result);
            } catch (error) {
                console.warn(`Widget Topbar : ouverture d'Agenda sur la date impossible — ${error.message}`);
                launch();
            }
        });
}

const midnight = d => new Date(d.getFullYear(), d.getMonth(), d.getDate());
const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);

/**
 * Demain → dimanche inclus. Le dimanche, toute la semaine suivante.
 *
 * @param {Date} now
 * @returns {{begin: Date, end: Date}} bornes à minuit, fin exclue
 */
export function weekRange(now) {
    const today = midnight(now);
    const mondayIndex = (today.getDay() + 6) % 7;
    const begin = addDays(today, 1);
    return {begin, end: addDays(begin, mondayIndex === 6 ? 7 : 6 - mondayIndex)};
}

function dayLabel(day) {
    return day.toLocaleDateString(undefined, {weekday: 'long', day: 'numeric'});
}

function timeLabel(event, day) {
    const dayEnd = addDays(day, 1);
    if (event.end > dayEnd) {
        // La fin d'une plage est le minuit suivant : on affiche le dernier jour réel.
        const last = new Date(event.end.getTime() - 1000);
        return `jusqu’au ${last.toLocaleDateString(undefined, {day: 'numeric', month: 'short'})}`;
    }
    if (event.date <= day && event.end >= dayEnd)
        return 'journée';
    return event.date.toLocaleTimeString(undefined, {hour: '2-digit', minute: '2-digit'});
}

export class UpcomingEvents {
    constructor(dateMenu) {
        this._dateMenu = dateMenu;
        this._source = dateMenu._eventsItem?._eventSource ?? null;

        this._box = new St.BoxLayout({style_class: 'tcw-upcoming', orientation: Clutter.Orientation.VERTICAL});
        dateMenu._calendar.get_parent()?.add_child(this._box);

        this._sourceId = this._source?.connect('changed', () => this._rebuild()) ?? 0;
        this._menuId = dateMenu.menu.connect('open-state-changed', (_menu, open) => {
            if (open)
                this._rebuild();
        });
        this._rebuild();
    }

    _rebuild() {
        this._box.destroy_all_children();
        if (!this._source)
            return;

        const {begin, end} = weekRange(new Date());
        let events = [];
        try {
            events = this._source.getEvents(begin, end) ?? [];
        } catch (error) {
            console.warn(`Widget Topbar : rendez-vous à venir illisibles — ${error.message}`);
            return;
        }

        const title = new St.Label({style_class: 'tcw-upcoming-title', text: 'À venir'});
        this._box.add_child(title);

        // Une plage de plusieurs jours ne se répète pas : elle apparaît le
        // premier jour où elle tombe dans la fenêtre affichée.
        const byDay = new Map();
        const seen = new Set();
        for (const event of events) {
            const id = event.id ?? `${event.summary}-${event.date?.getTime()}`;
            if (seen.has(id))
                continue;
            seen.add(id);
            const day = event.date < begin ? begin : midnight(event.date);
            const key = day.getTime();
            if (!byDay.has(key))
                byDay.set(key, {day, events: []});
            byDay.get(key).events.push(event);
        }

        if (!byDay.size) {
            const last = addDays(end, -1).toLocaleDateString(undefined, {weekday: 'long'});
            this._box.add_child(new St.Label({
                style_class: 'tcw-upcoming-empty',
                text: `Aucun rendez-vous d’ici ${last}.`,
            }));
            return;
        }

        const colors = assignColors(events);
        let rows = 0;
        let skipped = 0;
        for (const {day, events: dayEvents} of [...byDay.values()].sort((a, b) => a.day - b.day)) {
            if (rows >= MAX_ROWS) {
                skipped += dayEvents.length;
                continue;
            }
            this._box.add_child(new St.Label({style_class: 'tcw-upcoming-day', text: dayLabel(day)}));
            for (const event of dayEvents) {
                if (rows >= MAX_ROWS) {
                    skipped++;
                    continue;
                }
                rows++;
                const line = new St.BoxLayout({x_expand: true});
                const row = new St.Button({
                    style_class: 'tcw-upcoming-row',
                    child: line,
                    can_focus: true,
                    x_expand: true,
                    accessible_name: `${event.summary ?? ''}, ${dayLabel(day)}`,
                });
                row.set_x_align(Clutter.ActorAlign.FILL);
                row.connect('clicked', () => openCalendarAt(day));
                const color = colors.get(sourceKey(event));
                line.add_child(new St.Widget({
                    style: color ? `background-color: ${rgba(color, 1)}; ${DOT_STYLE}` : DOT_STYLE,
                    y_align: Clutter.ActorAlign.START,
                }));
                line.add_child(new St.Label({text: event.summary ?? '', x_expand: true}));
                line.add_child(new St.Label({
                    style_class: 'tcw-upcoming-time',
                    text: timeLabel(event, day),
                    y_align: Clutter.ActorAlign.CENTER,
                }));
                this._box.add_child(row);
            }
        }
        if (skipped) {
            this._box.add_child(new St.Label({
                style_class: 'tcw-upcoming-empty',
                text: skipped === 1 ? '+ 1 autre' : `+ ${skipped} autres`,
            }));
        }
    }

    destroy() {
        if (this._sourceId)
            this._source.disconnect(this._sourceId);
        this._sourceId = 0;
        this._dateMenu.menu.disconnect(this._menuId);
        this._box.destroy();
        this._box = null;
        this._source = null;
        this._dateMenu = null;
    }
}
