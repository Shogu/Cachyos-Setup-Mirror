// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
// SPDX-License-Identifier: GPL-3.0-only
import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import GObject from 'gi://GObject';
import Gtk from 'gi://Gtk';

const PROFILES = [['performance', 'Performance'], ['balanced', 'Équilibré'], ['power-saver', 'Économie']];
const THEMES = [['default', 'Clair'], ['prefer-dark', 'Sombre'], ['prefer-light', 'Préférer clair']];

// Une ligne par réglage automatique : interrupteur, puis valeur sur secteur et sur batterie.
const ROWS = [
    {title: 'Mode d’énergie', key: 'profiles-enabled', ac: 'ac', battery: 'bat', choices: PROFILES},
    {title: 'Luminosité de l’écran', key: 'screen-enabled', ac: 'power-brightness', battery: 'battery-brightness', percent: 'double'},
    {title: 'Thème', key: 'theme-enabled', ac: 'power-theme', battery: 'battery-theme', choices: THEMES},
    {title: 'Clavier rétroéclairé', subtitle: '0 l’éteint', key: 'keyboard-enabled', ac: 'power-keyboard',
        battery: 'battery-keyboard', percent: 'int'},
];

// Groupe « Secteur et batterie » : chaque réglage sur une ligne, valeur secteur à gauche,
// valeur batterie à droite, pour comparer d'un coup d'œil. release() à la fermeture.
export const PowerTable = GObject.registerClass(
class PowerTable extends Adw.PreferencesGroup {
    _init(settings) {
        super._init({
            title: 'Secteur et batterie',
            description: 'Chaque réglage s’applique automatiquement quand son interrupteur est activé.',
        });
        this._settings = settings;
        this._signals = [];
        for (const row of ROWS)
            this.add(this._row(row));
    }

    _row({title, subtitle = '', key, ac, battery, choices, percent}) {
        const row = new Adw.ActionRow({title, subtitle});
        const toggle = new Gtk.Switch({valign: Gtk.Align.CENTER});
        this._settings.bind(key, toggle, 'active', Gio.SettingsBindFlags.DEFAULT);
        row.add_prefix(toggle);
        row.activatable_widget = toggle;
        const values = new Gtk.Box({spacing: 12, valign: Gtk.Align.CENTER});
        this._settings.bind(key, values, 'sensitive', Gio.SettingsBindFlags.GET);
        for (const [settingKey, icon, tooltip] of [[ac, 'ac-adapter-symbolic', 'Sur secteur'], [battery, 'battery-symbolic', 'Sur batterie']]) {
            const cell = new Gtk.Box({spacing: 6, tooltip_text: tooltip});
            cell.append(new Gtk.Image({icon_name: icon}));
            cell.append(choices ? this._dropDown(settingKey, choices) : this._spin(settingKey, percent));
            values.append(cell);
        }
        row.add_suffix(values);
        return row;
    }

    _watch(key, callback) {
        this._signals.push(this._settings.connect(`changed::${key}`, callback));
        callback();
    }

    _dropDown(key, choices) {
        const ids = choices.map(([id]) => id);
        const dropDown = Gtk.DropDown.new_from_strings(choices.map(([, label]) => label));
        dropDown.valign = Gtk.Align.CENTER;
        this._watch(key, () => {
            dropDown.selected = Math.max(0, ids.indexOf(this._settings.get_string(key)));
        });
        dropDown.connect('notify::selected', () => {
            if (this._settings.get_string(key) !== ids[dropDown.selected])
                this._settings.set_string(key, ids[dropDown.selected]);
        });
        return dropDown;
    }

    // percent : 'double' (fraction 0–1 en GSettings) ou 'int' (0–100).
    _spin(key, percent) {
        const read = () => (percent === 'double' ? this._settings.get_double(key) * 100 : this._settings.get_int(key));
        const spin = new Gtk.SpinButton({
            adjustment: new Gtk.Adjustment({lower: 0, upper: 100, step_increment: 5, page_increment: 10}),
            valign: Gtk.Align.CENTER,
            width_chars: 3,
        });
        this._watch(key, () => {
            spin.value = read();
        });
        spin.connect('value-changed', () => {
            if (Math.abs(spin.value - read()) < 0.001)
                return;
            if (percent === 'double')
                this._settings.set_double(key, spin.value / 100);
            else
                this._settings.set_int(key, Math.round(spin.value));
        });
        const box = new Gtk.Box({spacing: 4});
        box.append(spin);
        box.append(new Gtk.Label({label: '%', css_classes: ['dim-label']}));
        return box;
    }

    release() {
        this._signals.forEach(id => this._settings.disconnect(id));
        this._signals = [];
    }
});
