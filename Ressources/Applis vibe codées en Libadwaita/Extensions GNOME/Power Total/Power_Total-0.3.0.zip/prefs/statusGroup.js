// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
// SPDX-License-Identifier: GPL-3.0-only
import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import GObject from 'gi://GObject';

import {Endpoint, PROFILES_SERVICE, isCancelled} from '../lib/dbus.js';
import {PROFILE_LABELS} from '../lib/policy.js';

Gio._promisify(Gio.DBusConnection.prototype, 'call');

const UPOWER = 'org.freedesktop.UPower';
const UPOWER_PATH = '/org/freedesktop/UPower';
const DEVICE = 'org.freedesktop.UPower.Device';
const STATE_CHARGING = 1;
const STATE_FULL = 4;
const STATE_PENDING_CHARGE = 5;

function propertyRow(title) {
    const row = new Adw.ActionRow({title, subtitle: '…', css_classes: ['property']});
    row.subtitle_selectable = true;
    return row;
}

function powerText(onBattery, state, percentage) {
    const level = `${Math.round(percentage)} %`;
    if (onBattery)
        return `Batterie · ${level}`;
    if (state === STATE_CHARGING)
        return `Secteur · en charge ${level}`;
    if (state === STATE_PENDING_CHARGE)
        return `Secteur · charge limitée à ${level}`;
    return state === STATE_FULL ? 'Secteur · chargée' : `Secteur · ${level}`;
}

// Groupe « État actuel » : alimentation, mode d'énergie, ce qui l'a choisi (publié par
// l'extension) et santé de la batterie. Mis à jour en direct ; release() à la fermeture.
export const StatusGroup = GObject.registerClass(
class StatusGroup extends Adw.PreferencesGroup {
    _init(settings) {
        super._init({title: 'État actuel'});
        this._settings = settings;
        this._cancellable = new Gio.Cancellable();
        this._power = propertyRow('Alimentation');
        this._profile = propertyRow('Mode d’énergie');
        this._reason = propertyRow('Choisi par');
        this._health = propertyRow('Santé de la batterie');
        [this._power, this._profile, this._reason, this._health].forEach(row => this.add(row));

        const report = error => console.warn(`[Power Total] État actuel : ${error.message}`);
        this._root = new Endpoint(Gio.BusType.SYSTEM, UPOWER, UPOWER_PATH, UPOWER, () => this._syncPower(), report);
        this._display = new Endpoint(Gio.BusType.SYSTEM, UPOWER, `${UPOWER_PATH}/devices/DisplayDevice`, DEVICE,
            () => this._syncPower(), report);
        const [name, path] = PROFILES_SERVICE;
        this._profiles = new Endpoint(Gio.BusType.SYSTEM, name, path, name, () => this._syncProfile(), report);
        this._battery = null;
        this._settingsIds = ['changed::current-reason', 'changed::profiles-enabled']
            .map(signal => settings.connect(signal, () => this._syncReason()));
        this._syncReason();
        this._findBattery();
    }

    async _findBattery() {
        try {
            const reply = await Gio.DBus.system.call(UPOWER, UPOWER_PATH, UPOWER, 'EnumerateDevices',
                null, null, Gio.DBusCallFlags.NONE, -1, this._cancellable);
            const path = reply.deepUnpack()[0].find(device => device.includes('/battery_'));
            if (!path) {
                this._health.subtitle = 'Pas de batterie';
                return;
            }
            this._battery = new Endpoint(Gio.BusType.SYSTEM, UPOWER, path, DEVICE, () => this._syncHealth(),
                error => console.warn(`[Power Total] Batterie : ${error.message}`));
        } catch (error) {
            if (!isCancelled(error))
                this._health.subtitle = 'Indisponible';
        }
    }

    _syncPower() {
        const onBattery = this._root.get('OnBattery');
        if (onBattery !== null)
            this._power.subtitle = powerText(onBattery, this._display.get('State', 0), this._display.get('Percentage', 0));
    }

    _syncProfile() {
        const active = this._profiles.get('ActiveProfile');
        this._profile.subtitle = active ? PROFILE_LABELS[active] ?? active : 'Service des modes d’énergie indisponible';
    }

    _syncReason() {
        const reason = this._settings.get_string('current-reason');
        if (!this._settings.get_boolean('profiles-enabled'))
            this._reason.subtitle = 'Changement automatique désactivé';
        else
            this._reason.subtitle = reason || '…';
    }

    _syncHealth() {
        const capacity = this._battery.get('Capacity', 0);
        if (capacity <= 0)
            return;
        const cycles = this._battery.get('ChargeCycles', -1);
        const health = `${Math.round(capacity)} % de la capacité d’origine`;
        this._health.subtitle = cycles > 0 ? `${health} · ${cycles} cycles` : health;
    }

    release() {
        this._cancellable.cancel();
        this._settingsIds.forEach(id => this._settings.disconnect(id));
        [this._root, this._display, this._profiles, this._battery].filter(Boolean).forEach(endpoint => endpoint.destroy());
    }
});
