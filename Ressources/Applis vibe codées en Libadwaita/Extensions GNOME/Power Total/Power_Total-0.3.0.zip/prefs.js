// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
// SPDX-License-Identifier: GPL-3.0-only
import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

import {Endpoint, PROFILES_SERVICE} from './lib/dbus.js';
import {PROFILE_LABELS} from './lib/policy.js';
import {PowerTable} from './prefs/powerTable.js';
import {StatusGroup} from './prefs/statusGroup.js';

export default class PowerTotalPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();
        window.set_title('Power Total');
        window.set_default_size(700, 760);
        window.search_enabled = true;
        const enabled = (row, key) => settings.bind(key, row, 'sensitive', Gio.SettingsBindFlags.GET);
        const toggle = (group, title, key, subtitle = '') => {
            const row = new Adw.SwitchRow({title, subtitle});
            settings.bind(key, row, 'active', Gio.SettingsBindFlags.DEFAULT);
            group.add(row);
            return row;
        };
        const page = new Adw.PreferencesPage({title: 'Alimentation', icon_name: 'battery-symbolic'});
        window.add(page);
        const status = new StatusGroup(settings);
        page.add(status);
        const table = new PowerTable(settings);
        page.add(table);
        const profiles = new Adw.PreferencesGroup({
            title: 'Modes d’énergie',
            description: 'Un changement manuel reste en place jusqu’au prochain changement d’alimentation ou de réglage.',
        });
        page.add(profiles);
        enabled(toggle(profiles, 'Mémoriser les changements manuels', 'remember-user-profile',
            'Le mode choisi devient le réglage par défaut pour cette alimentation.'), 'profiles-enabled');
        enabled(toggle(profiles, 'Respecter l’économie à batterie faible', 'low-battery-saver',
            'Passe en Économie d’énergie au niveau « batterie faible », si cette option est aussi activée dans GNOME.'), 'profiles-enabled');
        const availability = new Adw.ActionRow({title: 'Profils disponibles', subtitle: 'Détection du service…'});
        profiles.add(availability);
        const [serviceName, servicePath] = PROFILES_SERVICE;
        const service = new Endpoint(Gio.BusType.SYSTEM, serviceName, servicePath, serviceName, () => {
            const available = service.get('Profiles', []).map(entry => entry.Profile.deepUnpack());
            availability.subtitle = available.length
                ? available.map(id => PROFILE_LABELS[id] ?? id).join(' · ')
                : 'Service de profils indisponible. Le thème et la luminosité restent indépendants.';
        }, error => {
            availability.subtitle = `Service de profils indisponible : ${error.message}`;
        });

        const advanced = new Adw.PreferencesGroup({title: 'Options'});
        page.add(advanced);
        enabled(toggle(advanced, 'Protection contre un chargeur insuffisant', 'weak-adapter-protection',
            'Après 30 secondes de décharge sur secteur, conserve l’économie d’énergie jusqu’au débranchement. Expérimental.'), 'profiles-enabled');
        toggle(advanced, 'Couper les animations en mode Économie', 'saver-animations',
            'Quelle qu’en soit la raison (batterie faible, choix manuel…). Rallumées en sortant de ce mode.');
        toggle(advanced, 'Signaler les erreurs', 'notifications');

        window.connect('close-request', () => {
            service.destroy();
            status.release();
            table.release();
            return false;
        });
    }
}
