// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
// SPDX-License-Identifier: GPL-3.0-only
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import {Appearance} from './lib/appearance.js';
import {PowerState} from './lib/powerState.js';
import {Profiles} from './lib/profiles.js';
import {SaverAnimations} from './lib/saverAnimations.js';

// Interrupteur → nom affiché dans les erreurs, fabrique, et si le module suit l'alimentation
// (secteur/batterie) via update(state).
const MODULES = [
    ['profiles-enabled', 'Profils', true, (settings, report) => new Profiles(settings, report)],
    ['screen-enabled', 'Écran', true, (settings, report) => new Appearance('brightness', settings, report)],
    ['theme-enabled', 'Thème', true, (settings, report) => new Appearance('theme', settings, report)],
    ['keyboard-enabled', 'Clavier', true, (settings, report) => new Appearance('keyboard', settings, report)],
    ['saver-animations', 'Animations', false, (settings, report) => new SaverAnimations(settings, report)],
];
const SWITCHES = MODULES.map(([key]) => key);
const FOLLOW_POWER = new Set(MODULES.filter(([, , follows]) => follows).map(([key]) => key));

export default class PowerTotal extends Extension {
    enable() {
        this._settings = this.getSettings();
        this._modules = new Map();
        this._reported = new Set();
        this._state = null;
        this._sensor = new PowerState(state => {
            this._state = state;
            for (const [key, module] of this._modules) {
                if (FOLLOW_POWER.has(key))
                    module.update(state);
            }
        }, error => this._report('Alimentation', error));
        this._settingsId = this._settings.connect('changed', (_settings, key) => {
            if (SWITCHES.includes(key))
                this._syncModules();
        });
        this._syncModules();
    }

    disable() {
        this._settings.disconnect(this._settingsId);
        this._sensor.destroy();
        this._sensor = null;
        for (const module of this._modules.values())
            module.destroy();
        this._modules = null;
        this._state = null;
        this._reported = null;
        this._settings = null;
    }

    _report(name, error) {
        const message = `${name} : ${error.message}`;
        if (this._reported.has(message))
            return;
        this._reported.add(message);
        console.warn(`[Power Total] ${message}`);
        if (this._settings.get_boolean('notifications'))
            Main.notify('Power Total', message);
    }

    _syncModules() {
        for (const [key, name, followsPower, create] of MODULES) {
            if (!this._settings.get_boolean(key)) {
                this._modules.get(key)?.destroy();
                this._modules.delete(key);
            } else if (!this._modules.has(key)) {
                try {
                    const module = create(this._settings, error => this._report(name, error));
                    this._modules.set(key, module);
                    if (followsPower)
                        module.update(this._state);
                } catch (error) {
                    this._report(name, error);
                }
            }
        }
    }
}
