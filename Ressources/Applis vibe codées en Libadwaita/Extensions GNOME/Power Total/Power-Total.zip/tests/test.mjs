import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {chooseProfile, supportedProfile, canRemember} from '../lib/policy.js';

const config = {ac: 'performance', battery: 'balanced', appsAC: 'performance', appsBattery: 'performance', remember: true, lowBatterySaver: true};
assert.equal(chooseProfile({onBattery: false}, config, false, false), 'performance');
assert.equal(chooseProfile({onBattery: true}, config, false, false), 'balanced');
assert.equal(chooseProfile({onBattery: true, lowBattery: true}, config, true, false), 'power-saver');
assert.equal(chooseProfile({onBattery: false}, config, true, true), 'power-saver');
assert.equal(chooseProfile({onBattery: true, lowBattery: true}, {...config, lowBatterySaver: false}, true, false), 'performance');
assert.equal(supportedProfile('performance', ['balanced', 'power-saver']), 'balanced');
assert.equal(supportedProfile('performance', []), null);
assert.equal(canRemember({lowBattery: true}, config, false, false), false);
assert.equal(canRemember({}, config, true, false), false);

class Settings {
    constructor(values = {}) {
        this.values = {ac: 'performance', bat: 'balanced', 'performance-apps-ac': 'performance', 'performance-apps-bat': 'performance', 'apps-enabled': false, 'performance-apps': [], 'remember-user-profile': false, 'low-battery-saver': true, 'weak-adapter-protection': false, ...values};
        this.signals = new Map(); this.next = 1;
    }
    connect(signal, cb) { const id = this.next++; this.signals.set(id, cb); return id; }
    disconnect(id) { this.signals.delete(id); }
    get_string(key) { return this.values[key]; }
    get_boolean(key) { return this.values[key]; }
    get_strv(key) { return this.values[key]; }
    set_string(key, value) { this.values[key] = value; for (const cb of [...this.signals.values()]) cb(this, key); }
}
const timers = new Map(); let nextTimer = 0;
const GLib = {PRIORITY_DEFAULT: 0, SOURCE_REMOVE: false, timeout_add_seconds(_priority, seconds, cb) { assert.equal(seconds, 30); const id = ++nextTimer; timers.set(id, cb); return id; }, Source: {remove(id) { timers.delete(id); }}};
const Gio = {BusType: {SYSTEM: 0}, SettingsSchemaSource: {get_default: () => ({lookup: () => null})}};
class Endpoint {
    static instances = [];
    constructor(bus, name, path, iface, changed) {
        Object.assign(this, {name, changed, ready: false, proxy: {g_name_owner: ':1.1'}, values: {ActiveProfile: 'balanced', Profiles: [{Profile: 'performance'}, {Profile: 'balanced'}, {Profile: 'power-saver'}]}, writes: [], pending: []});
        Endpoint.instances.push(this);
    }
    get(key, fallback) { return this.ready ? this.values[key] ?? fallback : fallback; }
    set(key, type, value) { this.writes.push(value); return new Promise((resolve, reject) => this.pending.push({key, value, resolve, reject})); }
    complete() { const p = this.pending.shift(); this.values[p.key] = p.value; this.changed(); p.resolve(); }
    destroy() { this.ready = false; this.destroyed = true; this.changed = () => {}; for (const p of this.pending) p.reject(new Error('cancelled')); this.pending = []; }
}
class PerformanceAppTracker { initialize(cb) { this.cb = cb; } setPerformanceApps() {} destroy() { this.destroyed = true; } hasActiveApps = false; }
let source = await readFile(new URL('../lib/profiles.js', import.meta.url), 'utf8');
source = source.replace(/^import .*;\n/gm, '');
source = `const {Gio,GLib,Endpoint,PROFILE_SERVICES,unpack,PerformanceAppTracker,chooseProfile,supportedProfile,canRemember}=globalThis.__powerTest;\n${source}`;
globalThis.__powerTest = {Gio, GLib, Endpoint, PROFILE_SERVICES: [['one','/one'],['two','/two']], unpack: v => v, PerformanceAppTracker, chooseProfile, supportedProfile, canRemember};
const {Profiles} = await import('data:text/javascript;base64,' + Buffer.from(source).toString('base64'));
const flush = async () => { await Promise.resolve(); await Promise.resolve(); };
function start(values = {}) {
    Endpoint.instances = [];
    const settings = new Settings(values);
    const errors = [];
    const module = new Profiles(settings, e => errors.push(e));
    const endpoint = Endpoint.instances[0]; endpoint.ready = true; endpoint.changed();
    return {settings, errors, module, endpoint};
}
// A transition while the first write is in flight must end on the latest state.
{
    const {module, endpoint, settings} = start();
    module.update({onBattery: false, lowBattery: false});
    assert.deepEqual(endpoint.writes, ['performance']);
    module.update({onBattery: true, lowBattery: false});
    endpoint.complete(); await flush();
    assert.deepEqual(endpoint.writes, ['performance', 'balanced']);
    endpoint.complete(); await flush();
    // A manual choice persists even when battery metrics emit more signals.
    endpoint.values.ActiveProfile = 'power-saver'; endpoint.changed();
    module.update({onBattery: true, lowBattery: false});
    assert.equal(endpoint.writes.length, 2);
    // Unrelated preferences cannot reset the manual profile.
    settings.set_string('power-theme', 'prefer-dark');
    assert.equal(endpoint.writes.length, 2);
    module.destroy(); assert.equal(settings.signals.size, 0);
}
// Remember manual changes, but never learn automatic requests as new defaults.
{
    const {module, endpoint, settings} = start({'remember-user-profile': true});
    module.update({onBattery: false, lowBattery: false}); endpoint.complete(); await flush();
    assert.equal(settings.values.ac, 'performance');
    endpoint.values.ActiveProfile = 'balanced'; endpoint.changed();
    assert.equal(settings.values.ac, 'balanced');
    module.destroy();
}
// Weak charger confirmation is timed, not counted from unrelated notifications.
{
    const {module, endpoint} = start({'weak-adapter-protection': true});
    module.update({onBattery: false, weakAdapterSuspected: true});
    endpoint.complete(); await flush();
    module.update({onBattery: false, weakAdapterSuspected: true});
    assert.equal(timers.size, 1);
    const [id, cb] = [...timers][0];timers.delete(id);cb();
    assert.equal(endpoint.writes.at(-1), 'power-saver'); endpoint.complete(); await flush();
    module.update({onBattery: false, weakAdapterSuspected: false});
    assert.equal(endpoint.writes.at(-1), 'power-saver');
    module.update({onBattery: true, weakAdapterSuspected: false});
    assert.equal(endpoint.writes.at(-1), 'balanced');
    module.destroy(); await flush();
    assert.equal(timers.size, 0);
}
// Destroy during an in-flight write: no follow-up write or error notification.
{
    const {module, endpoint, errors, settings} = start();
    module.update({onBattery: false}); module.update({onBattery: true});
    module.destroy(); await flush();
    assert.equal(endpoint.writes.length, 1);
    assert.equal(errors.length, 0);
    assert.equal(settings.signals.size, 0);
}
console.log('Power Total: policy, manual changes, write ordering, weak charger and shutdown tests passed (mocked services).');
