// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.

// Met automatiquement « Toujours au premier plan » sur les fenêtres des applis
// choisies dans les préférences (clé auto-above-apps), dès leur
// première apparition. Une appli ne peut pas le demander elle-même sous Wayland.
import Shell from 'gi://Shell';

const APPS_KEY = 'auto-above-apps';

export class AutoAbove {
    constructor(settings) {
        this._settings = settings;
        this._pending = new Map();

        this._createdId = global.display.connect('window-created', (_display, win) => this._watch(win));

        for (const actor of global.get_window_actors())
            this._apply(actor.meta_window);
    }

    // Entries are desktop ids (as picked in the preferences); bare application ids also match.
    _matches(win) {
        const apps = this._settings.get_strv(APPS_KEY).map(id => id.replace(/\.desktop$/, ''));
        const app = Shell.WindowTracker.get_default().get_window_app(win);
        const ids = [app?.get_id()?.replace(/\.desktop$/, ''), win.get_gtk_application_id(), win.get_wm_class()];
        return ids.some(id => id && apps.includes(id));
    }

    _apply(win) {
        if (this._matches(win) && !win.is_above())
            win.make_above();
    }

    // L'identifiant de l'appli n'est pas encore connu à la création de la fenêtre :
    // on attend qu'elle soit affichée.
    _watch(win) {
        const shownId = win.connect('shown', () => {
            this._unwatch(win);
            this._apply(win);
        });
        const unmanagingId = win.connect('unmanaging', () => this._unwatch(win));
        this._pending.set(win, [shownId, unmanagingId]);
    }

    _unwatch(win) {
        for (const id of this._pending.get(win))
            win.disconnect(id);
        this._pending.delete(win);
    }

    destroy() {
        global.display.disconnect(this._createdId);
        for (const win of [...this._pending.keys()])
            this._unwatch(win);
        this._settings = null;
    }
}
