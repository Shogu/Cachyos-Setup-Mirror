// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Adw from 'gi://Adw';
import GObject from 'gi://GObject';
import Gio from 'gi://Gio';
import Gtk from 'gi://Gtk';

import {gettext as _} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

// Searchable list of installed applications; emits "app-picked" with the desktop id.
export const AppPicker = GObject.registerClass({
    Signals: {'app-picked': {param_types: [GObject.TYPE_STRING]}},
}, class AppPicker extends Adw.Dialog {
    _init(excluded) {
        super._init({title: _('Choose an Application'), content_width: 380, content_height: 520});

        const search = new Gtk.SearchEntry({placeholder_text: _('Search applications'), hexpand: true});
        const header = new Adw.HeaderBar({title_widget: search});

        const list = new Gtk.ListBox({selection_mode: Gtk.SelectionMode.NONE});
        list.add_css_class('boxed-list');

        const apps = Gio.AppInfo.get_all()
            .filter(app => app.should_show() && !excluded.includes(app.get_id()))
            .sort((a, b) => a.get_display_name().localeCompare(b.get_display_name()));

        for (const app of apps) {
            const row = new Adw.ActionRow({title: app.get_display_name(), activatable: true});
            row.add_prefix(new Gtk.Image({gicon: app.get_icon(), pixel_size: 32}));
            row.connect('activated', () => {
                this.emit('app-picked', app.get_id());
                this.close();
            });
            row._searchText = `${app.get_display_name()} ${app.get_id()}`.toLowerCase();
            list.append(row);
        }

        list.set_filter_func(row => row._searchText.includes(search.get_text().toLowerCase()));
        search.connect('search-changed', () => list.invalidate_filter());
        search.connect('activate', () => {
            const first = list.get_first_child();
            let row = first;
            while (row && !row.get_child_visible())
                row = row.get_next_sibling();
            row?.activate();
        });

        const clamp = new Adw.Clamp({child: list, margin_top: 12, margin_bottom: 12, margin_start: 12, margin_end: 12});
        const toolbar = new Adw.ToolbarView({content: new Gtk.ScrolledWindow({child: clamp, vexpand: true})});
        toolbar.add_top_bar(header);
        this.set_child(toolbar);
        this.set_focus(search);
    }
});
