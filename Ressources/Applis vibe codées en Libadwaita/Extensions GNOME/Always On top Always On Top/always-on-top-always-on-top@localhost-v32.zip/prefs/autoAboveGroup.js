// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Adw from 'gi://Adw';
import GObject from 'gi://GObject';
import Gio from 'gi://Gio';
import Gtk from 'gi://Gtk';

import {gettext as _} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

import {AppPicker} from './appPicker.js';

const APPS_KEY = 'auto-above-apps';

// Applications whose windows open Always on Top: one row per app, + to add one with the picker.
export const AutoAboveGroup = GObject.registerClass(
class AutoAboveGroup extends Adw.PreferencesGroup {
    _init(settings) {
        super._init({
            title: _('Always on Top at Launch'),
            description: _('Windows of these applications are put Always on Top as soon as they open.'),
        });
        this._settings = settings;
        this._rows = [];

        const add = new Gtk.Button({icon_name: 'list-add-symbolic', valign: Gtk.Align.CENTER, tooltip_text: _('Add an Application')});
        add.add_css_class('flat');
        add.connect('clicked', () => this._pickApp());
        this.set_header_suffix(add);

        this._empty = new Adw.ActionRow({title: _('No application')});
        this._empty.add_css_class('dim-label');

        this._changedId = settings.connect(`changed::${APPS_KEY}`, () => this._rebuild());
        this.connect('unrealize', () => settings.disconnect(this._changedId));
        this._rebuild();
    }

    _apps() {
        return this._settings.get_strv(APPS_KEY);
    }

    _rebuild() {
        for (const row of this._rows)
            this.remove(row);
        this._rows = [];

        const ids = this._apps();
        if (ids.length === 0) {
            this.add(this._empty);
            this._rows.push(this._empty);
            return;
        }

        for (const id of ids) {
            const row = this._rowFor(id);
            this.add(row);
            this._rows.push(row);
        }
    }

    _rowFor(id) {
        const desktopId = id.endsWith('.desktop') ? id : `${id}.desktop`;
        const info = Gio.DesktopAppInfo.new(desktopId);
        const row = new Adw.ActionRow({title: info ? info.get_display_name() : id, subtitle: info ? '' : _('Application not found')});
        row.add_prefix(new Gtk.Image({
            gicon: info ? info.get_icon() : Gio.ThemedIcon.new('application-x-executable-symbolic'),
            pixel_size: 32,
        }));

        const remove = new Gtk.Button({icon_name: 'user-trash-symbolic', valign: Gtk.Align.CENTER, tooltip_text: _('Remove')});
        remove.add_css_class('flat');
        remove.connect('clicked', () => this._settings.set_strv(APPS_KEY, this._apps().filter(app => app !== id)));
        row.add_suffix(remove);
        return row;
    }

    _pickApp() {
        const picker = new AppPicker(this._apps());
        picker.connect('app-picked', (_picker, id) => this._settings.set_strv(APPS_KEY, [...this._apps(), id]));
        picker.present(this.get_root());
    }
});
