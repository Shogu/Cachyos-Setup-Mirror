# Always on top always on top

Une extension GNOME Shell libadwaita ultra-basique : **une seule icône native**
dans la topbar qui active/désactive la fonction native GNOME « Toujours au
premier plan » (*always on top*) sur la fenêtre active.

Clin d'œil au nom : l'extension est elle-même « toujours au premier plan » dans
la liste... et son unique boulot, c'est le *always on top*. 😄

## Ce que ça fait

- **Une icône, un rôle.** Clic gauche = bascule `make_above()` / `unmake_above()`
  de Mutter sur la fenêtre active — exactement la fonction native derrière le
  clic droit sur la barre de titre → « Toujours au premier plan ». Zéro
  réinvention.
- **État lisible par l'icône elle-même :**
  - *Inactif* → icône **symbolic Always on top 16 × 16 px**, composée d’un carré plein avec une petite découpe carrée intérieure, optimisée pour la topbar GNOME.
  - *Actif (fenêtre épinglée)* → l'icône **passe le relais à l'icône de
    l'application épinglée** : mapping prioritaire pour quelques apps
    (Ptyxis, GNOME Text Editor, Nautilus, Clapper, Grimoire), sinon variante
    monochrome `-symbolic` de l'icône déclarée par l'app si elle existe, sinon
    repli générique (`application-x-executable-symbolic`).
- **Géométrie de panel native**, calée sur Copyous : le bouton garde les espacements
  standards de `PanelMenu.Button`; seul le `padding/margin` de l’icône est neutralisé,
  comme dans Copyous. Le pictogramme embarqué reste sur un canevas symbolic 16 × 16,
  mais sa masse visuelle a été réduite d’environ 10 % pour s’aligner humainement sur
  l’icône Copyous voisine.
- **Suit la fenêtre épinglée, pas le focus** : l'icône reste sur l'app
  épinglée même quand tu changes de fenêtre, et se resynchronise si l'état
  est changé autrement (menu de la fenêtre, fermeture de la fenêtre
  épinglée). S'il y a plusieurs fenêtres épinglées, l'icône montre la plus
  récente.
- **Icône inactive Always on top embarquée** en SVG symbolic natif 16 × 16 ; les icônes d'applications actives restent issues du thème système et monochromes.
- **Zéro dépendance, zéro préférence, zéro menu.** Un seul fichier
  `extension.js`.
- **Position simple et stable** dans la zone d'état (droite), sans API interne
  non documentée.

## Installation

```bash
gnome-extensions install --force "always-on-top-always-on-top@localhost.shell-extension.zip"
# X11 : Alt+F2 puis « r » — Wayland : déconnexion/reconnexion
gnome-extensions enable always-on-top-always-on-top@localhost
```

## Notes

- Compatible GNOME Shell 45 → 50 (ESM / `gi://`).
- L’icône inactive est embarquée dans l’extension ; les icônes affichées lorsqu’une fenêtre est épinglée viennent du thème système (Adwaita ou équivalent).
