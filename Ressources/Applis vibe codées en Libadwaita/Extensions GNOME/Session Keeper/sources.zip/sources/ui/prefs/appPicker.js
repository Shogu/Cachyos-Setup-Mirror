import Gtk from 'gi://Gtk';
import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import { gettext as _ } from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

function listApps(excluded) {
    return Gio.AppInfo.get_all()
        .filter(info => info.should_show() && info.get_id() && !excluded.includes(info.get_id()))
        .sort((a, b) => a.get_display_name().localeCompare(b.get_display_name()));
}

function buildAppRow(info) {
    const row = new Adw.ActionRow({ title: info.get_display_name(), activatable: true });
    row.add_prefix(new Gtk.Image({
        gicon: info.get_icon() ?? Gio.ThemedIcon.new('application-x-executable-symbolic'),
        pixel_size: 32,
    }));
    row.appId = info.get_id();
    return row;
}

export function pickApplication(parent, excluded, onPicked) {
    const search = new Gtk.SearchEntry({ placeholder_text: _('Rechercher une application'), hexpand: true });
    const list = new Gtk.ListBox({ selection_mode: Gtk.SelectionMode.NONE, css_classes: ['boxed-list'] });

    for (const info of listApps(excluded))
        list.append(buildAppRow(info));

    const query = () => search.get_text().trim().toLowerCase();
    list.set_filter_func(row => row.title.toLowerCase().includes(query()));
    search.connect('search-changed', () => list.invalidate_filter());

    const header = new Adw.HeaderBar({ show_title: false });
    header.set_title_widget(search);

    const content = new Gtk.ScrolledWindow({
        hscrollbar_policy: Gtk.PolicyType.NEVER,
        propagate_natural_height: true,
        child: new Adw.Clamp({
            margin_top: 12,
            margin_bottom: 12,
            margin_start: 12,
            margin_end: 12,
            child: list,
        }),
    });

    const view = new Adw.ToolbarView({ content });
    view.add_top_bar(header);

    const dialog = new Adw.Dialog({
        title: _('Exclure une application'),
        content_width: 480,
        content_height: 600,
        child: view,
        focus_widget: search,
    });

    list.connect('row-activated', (_list, row) => {
        onPicked(row.appId);
        dialog.close();
    });

    dialog.present(parent);
}
