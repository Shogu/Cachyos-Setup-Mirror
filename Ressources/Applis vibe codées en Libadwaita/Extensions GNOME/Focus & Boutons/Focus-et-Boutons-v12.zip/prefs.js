import Adw from 'gi://Adw';
import Gtk from 'gi://Gtk';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

export default class FocusButtonsPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();

        const page = new Adw.PreferencesPage({
            title: 'Focus & Boutons',
            icon_name: 'preferences-system-symbolic',
        });
        window.add(page);

        const focusGroup = new Adw.PreferencesGroup({
            title: 'Focus',
            description: 'Fermeture automatique des panneaux quand le pointeur en sort.',
        });
        page.add(focusGroup);

        this._addSwitchRow(
            focusGroup,
            settings,
            'auto-close-quick-settings',
            'Quick Settings',
            'Fermer automatiquement Quick Settings.'
        );
        this._addSwitchRow(
            focusGroup,
            settings,
            'auto-close-calendar',
            'Calendrier et notifications',
            'Fermer automatiquement le panneau central.'
        );

        const delayRow = new Adw.ActionRow({
            title: 'Délai de fermeture',
            subtitle: '100 à 2000 ms — 350 ms par défaut',
        });
        const adjustment = new Gtk.Adjustment({
            lower: 100,
            upper: 2000,
            step_increment: 50,
            page_increment: 100,
            value: settings.get_uint('close-delay-ms'),
        });
        const spin = new Gtk.SpinButton({
            adjustment,
            numeric: true,
            valign: Gtk.Align.CENTER,
        });
        spin.connect('value-changed', widget => {
            settings.set_uint('close-delay-ms', widget.get_value_as_int());
        });
        delayRow.add_suffix(spin);
        delayRow.activatable_widget = spin;
        focusGroup.add(delayRow);

        const quickGroup = new Adw.PreferencesGroup({
            title: 'Quick Settings',
            description: 'Simplifier la rangée système sans toucher au volume ni aux sorties audio.',
        });
        page.add(quickGroup);

        this._addSwitchRow(
            quickGroup,
            settings,
            'hide-screenshot',
            'Masquer Capture d’écran',
            'La capture reste disponible avec les raccourcis GNOME.'
        );
        this._addSwitchRow(
            quickGroup,
            settings,
            'split-settings-button',
            'Bouton Réglages scindé',
            'Clic sur la roue dentée : Paramètres. Chevron : Ajustements, dconf et Extensions.'
        );
        this._addSwitchRow(
            quickGroup,
            settings,
            'rename-power-profile',
            'Libellé « Énergie »',
            'Remplacer le titre du profil de puissance par « Énergie ». '
        );
        this._addSwitchRow(
            quickGroup,
            settings,
            'split-power-button',
            'Bouton Power scindé',
            'Clic principal : Éteindre. Chevron : Suspendre, Redémarrer, Redémarrer la session et Verrouiller.'
        );

        const calendarGroup = new Adw.PreferencesGroup({
            title: 'Calendrier et notifications',
            description: 'Rendre le panneau central plus lisible et plus compact.',
        });
        page.add(calendarGroup);

        this._addSwitchRow(
            calendarGroup,
            settings,
            'calendar-blue-accent',
            'Carte des rendez-vous bleue',
            'Afficher la carte des rendez-vous en bleu Adwaita, sans modifier la date.'
        );
        this._addSwitchRow(
            calendarGroup,
            settings,
            'hide-empty-notifications',
            'Masquer la zone Notifications vide',
            'Supprimer la grande colonne « Aucune notification » tant qu’aucune notification n’est présente.'
        );
    }

    _addSwitchRow(group, settings, key, title, subtitle) {
        const row = new Adw.SwitchRow({
            title,
            subtitle,
        });
        settings.bind(key, row, 'active', 0);
        group.add(row);
    }
}
