import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Shell from 'gi://Shell';
import St from 'gi://St';

import * as SystemActions from 'resource:///org/gnome/shell/misc/systemActions.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import {QuickSettingsItem} from 'resource:///org/gnome/shell/ui/quickSettings.js';

const SCREENSHOT_ICON = 'screenshooter-symbolic';
const LOCK_ICON = 'system-lock-screen-symbolic';
const SHUTDOWN_ICON = 'system-shutdown-symbolic';

const SETTINGS_FALLBACK_ICON = 'preferences-system-symbolic';
const TWEAKS_ICON = 'preferences-system-symbolic';
const DCONF_ICON = 'preferences-desktop-apps-symbolic';
const EXTENSIONS_ICON = 'com.mattjakeman.ExtensionManager-symbolic';

const ENERGY_TITLE = 'Énergie';
const LOGOUT_TITLE = 'Redémarrer la session';
const LOCK_TITLE = 'Verrouiller la session';

const SETTINGS_APP_ID = 'org.gnome.Settings.desktop';
const TWEAKS_APP_ID = 'org.gnome.tweaks.desktop';
const DCONF_APP_ID = 'ca.desrt.dconf-editor.desktop';
const EXTENSIONS_APP_ID = 'com.mattjakeman.ExtensionManager.desktop';

const CompactSplitItem = GObject.registerClass(
class CompactSplitItem extends QuickSettingsItem {
    _init(params = {}) {
        const {
            iconName = null,
            gicon = null,
            accessibleName = '',
            menuAccessibleName = 'Ouvrir les options',
            onPrimary = null,
        } = params;

        super._init({
            hasMenu: true,
            reactive: false,
            can_focus: false,
            style_class: 'focus-buttons-split-item',
        });

        const box = new St.BoxLayout({
            style_class: 'focus-buttons-split-box',
        });
        this.set_child(box);

        const iconProps = {};
        if (gicon)
            iconProps.gicon = gicon;
        else if (iconName)
            iconProps.icon_name = iconName;

        this.primaryButton = new St.Button({
            style_class: 'icon-button focus-buttons-split-primary',
            can_focus: true,
            accessible_name: accessibleName,
            child: new St.Icon(iconProps),
        });
        box.add_child(this.primaryButton);

        this.menuButton = new St.Button({
            style_class: 'icon-button focus-buttons-split-menu',
            can_focus: true,
            accessible_name: menuAccessibleName,
            child: new St.Icon({icon_name: 'go-next-symbolic'}),
        });
        box.add_child(this.menuButton);

        if (onPrimary)
            this.primaryButton.connect('clicked', onPrimary);

        this.menuButton.connect('clicked', () => this.menu.open());
        this.menuButton.connect('popup-menu', () => this.menu.open());
    }
});

class HoverAutoCloseController {
    constructor(menu, closeCallback, delay) {
        this._menu = menu;
        this._actor = menu?.actor ?? null;
        this._closeCallback = closeCallback;
        this._delay = delay;

        this._timeoutId = 0;
        this._openStateId = 0;
        this._hoverId = 0;
        this._hasEnteredMenu = false;
        this._previousTrackHover = false;
    }

    enable() {
        if (!this._menu || !this._actor)
            return false;

        this._previousTrackHover = this._actor.track_hover;
        this._actor.track_hover = true;

        this._hoverId = this._actor.connect('notify::hover', () => {
            this._onHoverChanged();
        });

        this._openStateId = this._menu.connect('open-state-changed', (_menu, isOpen) => {
            this._onOpenStateChanged(isOpen);
        });

        return true;
    }

    disable() {
        this._cancelClose();

        if (this._actor && this._hoverId)
            this._actor.disconnect(this._hoverId);

        if (this._menu && this._openStateId)
            this._menu.disconnect(this._openStateId);

        if (this._actor)
            this._actor.track_hover = this._previousTrackHover;

        this._hoverId = 0;
        this._openStateId = 0;
        this._menu = null;
        this._actor = null;
        this._closeCallback = null;
    }

    _onOpenStateChanged(isOpen) {
        this._cancelClose();
        this._hasEnteredMenu = false;

        if (!isOpen)
            return;

        this._actor.sync_hover();
        if (this._actor.hover)
            this._hasEnteredMenu = true;
    }

    _onHoverChanged() {
        if (!this._menu?.isOpen)
            return;

        if (this._actor.hover) {
            this._hasEnteredMenu = true;
            this._cancelClose();
            return;
        }

        if (this._hasEnteredMenu)
            this._scheduleClose();
    }

    _scheduleClose(delay = this._delay) {
        this._cancelClose();

        this._timeoutId = GLib.timeout_add(
            GLib.PRIORITY_DEFAULT,
            delay,
            () => {
                this._timeoutId = 0;

                if (!this._menu?.isOpen)
                    return GLib.SOURCE_REMOVE;

                this._actor.sync_hover();
                if (this._actor.hover)
                    return GLib.SOURCE_REMOVE;

                const [, , modifiers] = global.get_pointer();
                const buttonMask =
                    Clutter.ModifierType.BUTTON1_MASK |
                    Clutter.ModifierType.BUTTON2_MASK |
                    Clutter.ModifierType.BUTTON3_MASK;

                if (modifiers & buttonMask) {
                    this._scheduleClose(120);
                    return GLib.SOURCE_REMOVE;
                }

                this._closeCallback?.();
                return GLib.SOURCE_REMOVE;
            }
        );
    }

    _cancelClose() {
        if (!this._timeoutId)
            return;

        GLib.source_remove(this._timeoutId);
        this._timeoutId = 0;
    }
}

export default class FocusButtonsExtension extends Extension {
    enable() {
        this._settings = this.getSettings();
        this._settingsChangedId = this._settings.connect('changed', () => {
            this._refreshFeatures();
        });

        this._quickSettings = Main.panel.statusArea.quickSettings;
        this._quickSettingsMenu = this._quickSettings?.menu ?? null;
        this._quickSettingsActor = this._quickSettingsMenu?.actor ?? null;
        this._dateMenu = Main.panel.statusArea.dateMenu ?? null;
        this._calendarMenu = this._dateMenu?.menu ?? null;
        this._systemActions = SystemActions.getDefault();
        this._systemItem = this._quickSettings?._system?._systemItem ?? null;
        this._nativeSystemMenu = this._systemItem?.menu ?? null;

        this._resetFeatureState();
        this._applyFeatures();
    }

    disable() {
        if (this._settings && this._settingsChangedId)
            this._settings.disconnect(this._settingsChangedId);

        this._settingsChangedId = 0;
        this._clearFeatures();

        this._settings = null;
        this._systemActions = null;
        this._calendarMenu = null;
        this._dateMenu = null;
        this._quickSettingsActor = null;
        this._quickSettingsMenu = null;
        this._quickSettings = null;
        this._nativeSystemMenu = null;
        this._systemItem = null;
    }

    _resetFeatureState() {
        this._quickSettingsAutoClose = null;
        this._calendarAutoClose = null;

        this._screenshotButton = null;
        this._screenshotWasVisible = false;
        this._nativeSettingsButton = null;
        this._nativeSettingsWasVisible = false;
        this._nativeLockButton = null;
        this._nativeLockWasVisible = false;
        this._nativeShutdownButton = null;
        this._nativeShutdownWasVisible = false;

        this._settingsSplitItem = null;
        this._powerSplitItem = null;
        this._nestedMenus = new Map();
        this._powerBindings = [];

        this._powerProfileToggle = null;
        this._powerProfileOriginalTitle = null;

        this._calendarEventsActor = null;

        this._messageList = null;
        this._messageView = null;
        this._messageListWasVisible = false;
        this._messageEmptyId = 0;
        this._messageMenuOpenId = 0;
    }

    _refreshFeatures() {
        this._clearFeatures();
        this._resetFeatureState();
        this._applyFeatures();
    }

    _applyFeatures() {
        const delay = this._settings.get_uint('close-delay-ms');

        if (this._settings.get_boolean('auto-close-quick-settings') && this._quickSettingsMenu) {
            this._quickSettingsAutoClose = new HoverAutoCloseController(
                this._quickSettingsMenu,
                () => Main.panel.closeQuickSettings(),
                delay
            );
            this._quickSettingsAutoClose.enable();
        }

        if (this._settings.get_boolean('auto-close-calendar') && this._calendarMenu) {
            this._calendarAutoClose = new HoverAutoCloseController(
                this._calendarMenu,
                () => Main.panel.closeCalendar(),
                delay
            );
            this._calendarAutoClose.enable();
        }

        if (this._settings.get_boolean('calendar-blue-accent'))
            this._enableCalendarBlueCard();

        if (this._settings.get_boolean('hide-empty-notifications'))
            this._enableEmptyNotificationsHiding();

        if (!this._quickSettingsMenu || !this._quickSettingsActor)
            return;

        this._configureSystemRow();

        if (this._settings.get_boolean('rename-power-profile'))
            this._renamePowerProfile();
    }

    _clearFeatures() {
        this._restoreNativeSystemMenu();

        this._quickSettingsAutoClose?.disable();
        this._calendarAutoClose?.disable();
        this._quickSettingsAutoClose = null;
        this._calendarAutoClose = null;

        this._disableEmptyNotificationsHiding();
        this._disableCalendarBlueCard();

        for (const binding of this._powerBindings)
            binding.unbind();
        this._powerBindings = [];

        this._destroySplitItem(this._settingsSplitItem);
        this._destroySplitItem(this._powerSplitItem);
        this._settingsSplitItem = null;
        this._powerSplitItem = null;

        if (this._screenshotButton)
            this._screenshotButton.visible = this._screenshotWasVisible;
        if (this._nativeSettingsButton)
            this._nativeSettingsButton.visible = this._nativeSettingsWasVisible;
        if (this._nativeLockButton)
            this._nativeLockButton.visible = this._nativeLockWasVisible;
        if (this._nativeShutdownButton)
            this._nativeShutdownButton.visible = this._nativeShutdownWasVisible;

        if (this._powerProfileToggle && this._powerProfileOriginalTitle !== null)
            this._powerProfileToggle.title = this._powerProfileOriginalTitle;
    }

    _configureSystemRow() {
        const root = this._quickSettings?._system?._systemItem?.child ?? this._quickSettingsActor;
        const screenshotButton = this._findButtonByIcon(root, SCREENSHOT_ICON);
        const lockButton = this._findButtonByIcon(root, LOCK_ICON);
        const shutdownButton = this._findButtonByIcon(root, SHUTDOWN_ICON);

        if (!screenshotButton)
            return false;

        const parent = screenshotButton.get_parent();
        if (!parent || typeof parent.insert_child_at_index !== 'function')
            return false;

        const settingsButton = this._findNativeSettingsButton(parent, screenshotButton);

        this._screenshotButton = screenshotButton;
        this._screenshotWasVisible = screenshotButton.visible;
        if (this._settings.get_boolean('hide-screenshot'))
            screenshotButton.hide();

        if (settingsButton && this._settings.get_boolean('split-settings-button'))
            this._installSettingsSplitButton(parent, settingsButton);

        if (lockButton && shutdownButton && this._settings.get_boolean('split-power-button'))
            this._installPowerSplitButton(parent, lockButton, shutdownButton);

        return true;
    }

    _findNativeSettingsButton(parent, screenshotButton) {
        const settingsApp = Shell.AppSystem.get_default().lookup_app(SETTINGS_APP_ID);
        const expectedName = settingsApp?.get_name() ?? null;
        const children = parent.get_children();

        if (expectedName) {
            const byName = children.find(child =>
                child instanceof St.Button && child.accessible_name === expectedName);
            if (byName)
                return byName;
        }

        const screenshotIndex = children.indexOf(screenshotButton);
        if (screenshotIndex >= 0) {
            const candidate = children[screenshotIndex + 1];
            if (candidate instanceof St.Button)
                return candidate;
        }

        return null;
    }

    _installSettingsSplitButton(parent, settingsButton) {
        const app = Shell.AppSystem.get_default().lookup_app(SETTINGS_APP_ID);
        if (!app)
            return false;

        const index = parent.get_children().indexOf(settingsButton);
        if (index < 0)
            return false;

        this._nativeSettingsButton = settingsButton;
        this._nativeSettingsWasVisible = settingsButton.visible;
        settingsButton.hide();

        this._settingsSplitItem = new CompactSplitItem({
            gicon: app.get_icon(),
            iconName: SETTINGS_FALLBACK_ICON,
            accessibleName: 'Paramètres',
            menuAccessibleName: 'Autres réglages GNOME',
            onPrimary: () => this._launchApp(SETTINGS_APP_ID),
        });
        this._settingsSplitItem.menu.setHeader(app.get_icon() ?? SETTINGS_FALLBACK_ICON, 'Réglages');

        this._addAppMenuAction(this._settingsSplitItem.menu, 'Ajustements', TWEAKS_APP_ID, TWEAKS_ICON);
        this._addAppMenuAction(this._settingsSplitItem.menu, 'Éditeur dconf', DCONF_APP_ID, DCONF_ICON);
        this._addAppMenuAction(this._settingsSplitItem.menu, 'Extensions', EXTENSIONS_APP_ID, EXTENSIONS_ICON);

        parent.insert_child_at_index(this._settingsSplitItem, index);
        this._attachNestedMenu(this._settingsSplitItem);
        return true;
    }

    _installPowerSplitButton(parent, lockButton, shutdownButton) {
        const index = parent.get_children().indexOf(shutdownButton);
        if (index < 0)
            return false;

        this._nativeLockButton = lockButton;
        this._nativeLockWasVisible = lockButton.visible;
        this._nativeShutdownButton = shutdownButton;
        this._nativeShutdownWasVisible = shutdownButton.visible;
        lockButton.hide();
        shutdownButton.hide();

        this._powerSplitItem = new CompactSplitItem({
            iconName: SHUTDOWN_ICON,
            accessibleName: 'Éteindre',
            menuAccessibleName: 'Options d’alimentation et de session',
            onPrimary: () => {
                this._systemActions.activatePowerOff();
                Main.panel.closeQuickSettings();
            },
        });
        this._powerSplitItem.menu.setHeader(SHUTDOWN_ICON, 'Alimentation');

        this._addBoundSystemAction(
            this._powerSplitItem.menu,
            'Suspendre',
            'can-suspend',
            'media-playback-pause-symbolic',
            () => this._systemActions.activateSuspend()
        );
        this._addBoundSystemAction(
            this._powerSplitItem.menu,
            'Redémarrer…',
            'can-restart',
            'system-reboot-symbolic',
            () => this._systemActions.activateRestart()
        );
        this._addBoundSystemAction(
            this._powerSplitItem.menu,
            LOGOUT_TITLE,
            'can-logout',
            'system-log-out-symbolic',
            () => this._logoutSession()
        );
        this._addBoundSystemAction(
            this._powerSplitItem.menu,
            LOCK_TITLE,
            'can-lock-screen',
            LOCK_ICON,
            () => this._systemActions.activateLockScreen()
        );

        const powerOffBinding = this._systemActions.bind_property(
            'can-power-off',
            this._powerSplitItem.primaryButton,
            'reactive',
            GObject.BindingFlags.DEFAULT | GObject.BindingFlags.SYNC_CREATE
        );
        this._powerBindings.push(powerOffBinding);

        parent.insert_child_at_index(this._powerSplitItem, index);
        this._attachNestedMenu(this._powerSplitItem);
        return true;
    }

    _addAppMenuAction(menu, label, appId, fallbackIcon) {
        const app = Shell.AppSystem.get_default().lookup_app(appId);
        if (!app)
            return null;

        return menu.addAction(
            label,
            () => this._launchApp(appId),
            app.get_icon() ?? fallbackIcon
        );
    }

    _addBoundSystemAction(menu, label, propertyName, iconName, callback) {
        const item = menu.addAction(label, () => {
            callback();
            Main.panel.closeQuickSettings();
        }, iconName);

        const binding = this._systemActions.bind_property(
            propertyName,
            item,
            'visible',
            GObject.BindingFlags.DEFAULT | GObject.BindingFlags.SYNC_CREATE
        );
        this._powerBindings.push(binding);
        return item;
    }

    _launchApp(appId) {
        const app = Shell.AppSystem.get_default().lookup_app(appId);
        if (!app) {
            console.warn(`Focus & Boutons: application introuvable: ${appId}`);
            return;
        }

        Main.overview.hide();
        Main.panel.closeQuickSettings();
        app.activate();
    }

    _attachNestedMenu(item) {
        const menu = item?.menu;
        const overlay = this._quickSettingsMenu?._overlay;
        if (!menu || !overlay)
            return false;

        overlay.add_child(menu.actor);
        const openStateId = menu.connect('open-state-changed', (_menu, isOpen) => {
            if (isOpen) {
                item.add_style_class_name('focus-buttons-split-open');
                const activeMenu = this._quickSettingsMenu?._activeMenu;
                if (activeMenu && activeMenu !== menu)
                    activeMenu.close();

                // SystemItem is the direct child of the Quick Settings grid. Its
                // `menu` property is what the native layout watches to reserve
                // vertical space for an opened submenu. Temporarily expose our
                // nested split-button menu there so it expands the panel instead
                // of painting over the rows below it.
                if (this._systemItem)
                    this._systemItem.menu = menu;

                this._queueQuickSettingsRelayout();

                if (this._quickSettingsMenu) {
                    this._quickSettingsMenu._activeMenu = menu;
                    this._quickSettingsMenu._setDimmed?.(true);
                }
            } else {
                item.remove_style_class_name('focus-buttons-split-open');

                if (this._systemItem?.menu === menu)
                    this._systemItem.menu = this._nativeSystemMenu;

                this._queueQuickSettingsRelayout();

                if (this._quickSettingsMenu?._activeMenu === menu) {
                    this._quickSettingsMenu._activeMenu = null;
                    this._quickSettingsMenu._setDimmed?.(false);
                }
            }
        });

        this._nestedMenus.set(item, {menu, openStateId});
        return true;
    }

    _queueQuickSettingsRelayout() {
        this._systemItem?.queue_relayout?.();
        this._quickSettingsMenu?._grid?.queue_relayout?.();
        this._quickSettingsActor?.queue_relayout?.();
    }

    _restoreNativeSystemMenu() {
        if (!this._systemItem)
            return;

        this._systemItem.menu = this._nativeSystemMenu;
        this._queueQuickSettingsRelayout();
    }

    _destroySplitItem(item) {
        if (!item)
            return;

        item.remove_style_class_name?.('focus-buttons-split-open');

        const registration = this._nestedMenus.get(item);
        if (registration) {
            const {menu, openStateId} = registration;

            if (this._systemItem?.menu === menu) {
                this._systemItem.menu = this._nativeSystemMenu;
                this._queueQuickSettingsRelayout();
            }

            if (this._quickSettingsMenu?._activeMenu === menu) {
                this._quickSettingsMenu._activeMenu = null;
                this._quickSettingsMenu._setDimmed?.(false);
            }
            if (openStateId)
                menu.disconnect(openStateId);
            menu.destroy();
            this._nestedMenus.delete(item);
        }

        item.destroy();
    }

    _enableCalendarBlueCard() {
        const eventsActor = this._dateMenu?._eventsItem ?? null;
        if (!eventsActor)
            return false;

        this._calendarEventsActor = eventsActor;
        eventsActor.add_style_class_name('focus-buttons-calendar-events-blue');
        return true;
    }

    _disableCalendarBlueCard() {
        this._calendarEventsActor?.remove_style_class_name('focus-buttons-calendar-events-blue');
        this._calendarEventsActor = null;
    }

    _enableEmptyNotificationsHiding() {
        const messageList = this._dateMenu?._messageList ?? null;
        const messageView = messageList?._messageView ?? null;
        if (!messageList || !messageView)
            return false;

        this._messageList = messageList;
        this._messageView = messageView;
        this._messageListWasVisible = messageList.visible;
        this._messageEmptyId = messageView.connect('notify::empty', () => {
            this._syncEmptyNotificationsVisibility();
        });
        if (this._calendarMenu) {
            this._messageMenuOpenId = this._calendarMenu.connect(
                'open-state-changed',
                (_menu, isOpen) => {
                    if (isOpen)
                        this._syncEmptyNotificationsVisibility();
                }
            );
        }
        this._syncEmptyNotificationsVisibility();
        return true;
    }

    _disableEmptyNotificationsHiding() {
        if (this._messageView && this._messageEmptyId)
            this._messageView.disconnect(this._messageEmptyId);
        this._messageEmptyId = 0;

        if (this._calendarMenu && this._messageMenuOpenId)
            this._calendarMenu.disconnect(this._messageMenuOpenId);
        this._messageMenuOpenId = 0;

        if (this._messageList)
            this._messageList.visible = this._messageListWasVisible;

        this._messageList = null;
        this._messageView = null;
    }

    _syncEmptyNotificationsVisibility() {
        if (!this._messageList || !this._messageView)
            return;

        this._messageList.visible = !this._messageView.empty;
    }

    _renamePowerProfile() {
        const toggle = this._findPowerProfileToggle(this._quickSettingsActor);
        if (!toggle)
            return false;

        this._powerProfileToggle = toggle;
        this._powerProfileOriginalTitle = toggle.title;
        toggle.title = ENERGY_TITLE;
        return true;
    }

    _logoutSession() {
        if (this._systemActions?.canLogout) {
            this._systemActions.activateLogout();
            return;
        }

        Gio.DBus.session.call(
            'org.gnome.SessionManager',
            '/org/gnome/SessionManager',
            'org.gnome.SessionManager',
            'Logout',
            new GLib.Variant('(u)', [0]),
            null,
            Gio.DBusCallFlags.NONE,
            -1,
            null,
            (connection, result) => {
                try {
                    connection.call_finish(result);
                } catch (error) {
                    console.error(`Focus & Boutons: échec de la fermeture de session: ${error.message}`);
                }
            }
        );
    }

    _findButtonByIcon(actor, iconName) {
        if (!actor)
            return null;

        if (actor instanceof St.Button && actor.icon_name === iconName)
            return actor;

        if (typeof actor.get_children !== 'function')
            return null;

        for (const child of actor.get_children()) {
            const found = this._findButtonByIcon(child, iconName);
            if (found)
                return found;
        }

        return null;
    }

    _findPowerProfileToggle(actor) {
        if (!actor)
            return null;

        const iconName = actor.icon_name ?? '';
        const headerIconName = actor.menu?._headerIcon?.icon_name ?? '';

        if (typeof actor.title === 'string' &&
            (iconName.startsWith('power-profile-') ||
             headerIconName === 'power-profile-balanced-symbolic'))
            return actor;

        if (typeof actor.get_children !== 'function')
            return null;

        for (const child of actor.get_children()) {
            const found = this._findPowerProfileToggle(child);
            if (found)
                return found;
        }

        return null;
    }
}
