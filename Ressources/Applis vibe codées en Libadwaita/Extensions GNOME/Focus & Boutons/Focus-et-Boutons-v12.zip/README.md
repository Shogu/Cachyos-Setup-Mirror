# Focus & Boutons v12

Extension GNOME Shell ciblant GNOME 50 et 51.

## Fonctions

- Ferme automatiquement **Quick Settings** quand le pointeur en sort, après un délai réglable (350 ms par défaut).
- Applique le même comportement au panneau **Calendrier / Notifications**.
- Masque optionnellement le bouton **Capture d’écran** de la rangée système.
- Remplace le bouton Réglages par un **bouton scindé** :
  - clic sur la roue dentée : ouvre **Paramètres GNOME** ;
  - clic sur le chevron : ouvre un menu avec **Ajustements**, **Éditeur dconf** et **Extensions Manager**.
  - le bouton scindé devient **bleu Adwaita uniquement tant que ce menu est ouvert**.
- Renomme optionnellement le profil de puissance en **Énergie**.
- Remplace Power par un **bouton scindé** :
  - clic principal : ouvre le dialogue GNOME **Éteindre** ;
  - clic sur le chevron : **Suspendre**, **Redémarrer**, **Redémarrer la session**, **Verrouiller la session**.
  - le bouton scindé devient **bleu Adwaita uniquement tant que ce menu est ouvert**.
- Retire le cadenas séparé de la rangée lorsque le bouton Power scindé est actif.
- Peut afficher la carte des rendez-vous en **bleu Adwaita**, sans modifier le style de la date ni ajouter de bordure d’accent.
- Peut masquer complètement la grande colonne **Aucune notification** lorsque la liste est vide ; elle réapparaît automatiquement dès qu’une notification existe.

## Hors périmètre

L’extension ne modifie pas le curseur de volume, le microphone ni le sélecteur de sortie audio. Elle ne change pas non plus la sortie audio par défaut (par exemple JamesDSP).

## Préférences

```bash
gnome-extensions prefs focus-et-boutons@ogu
```

Toutes les options sont appliquées immédiatement.

## Installation

```bash
gnome-extensions install --force ./Focus-et-Boutons-v12.zip
```

Sous Wayland, une déconnexion/reconnexion peut être nécessaire après remplacement des fichiers de l’extension.
