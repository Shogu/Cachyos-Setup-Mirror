// Generated with AI for personal use. Do NOT upload to extensions.gnome.org (EGO) unless you understand JavaScript and can maintain this code.
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {QuickMenuToggle, SystemIndicator} from 'resource:///org/gnome/shell/ui/quickSettings.js';

Gio._promisify(Gio.File.prototype, 'load_contents_async');
Gio._promisify(Gio.File.prototype, 'query_info_async');

// Le service utilisateur du paquet upgrade-check écrit la sortie de checkupdates
// dans ~/.cache/upgrade-check/updates.txt ; son hook pacman touche
// /var/lib/upgrade-check/last-transaction après chaque transaction. C'est la
// pilule qui décide quand lancer le service (intervalle réglable).
const CHECK_UNIT = 'upgrade-check.service';
const RESULT_NAME = 'updates.txt';
const TRANSACTION_DIR = '/var/lib/upgrade-check';
const TRANSACTION_FILE = 'last-transaction';
const STARTUP_DELAY_S = 60;
const RETRY_DELAY_S = 30 * 60;
const MAX_LISTED = 15;
const DEBOUNCE_MS = 800;
const CHECK_TIMEOUT_S = 120;
// Après une vérification demandée depuis le menu, le résultat reste visible.
const RESULT_VISIBLE_MS = 3000;
// Le hook passe avant les derniers hooks (snapper…) et pendant que Shelly
// enchaîne sur l'AUR : on laisse la transaction se terminer avant de vérifier.
const TRANSACTION_DELAY_S = 30;

function upgradeIcon() {
    return Gio.ThemedIcon.new_from_names(['io.gitlab.shogu.Upgrade-symbolic', 'software-update-available-symbolic']);
}

function plural(count, word) {
    return `${count} ${word}${count > 1 ? 's' : ''}`;
}

const UpdatesToggle = GObject.registerClass(
class UpdatesToggle extends QuickMenuToggle {
    _init(onUpgrade, onCheck) {
        super._init({title: 'Updates', subtitle: 'En attente', gicon: upgradeIcon(), toggle_mode: false});
        this.menu.setHeader(upgradeIcon(), 'Updates');
        // Bouton d'en-tête plutôt qu'une entrée de menu : il ne ferme pas la
        // liste, qui se met à jour sous les yeux.
        const refresh = new St.Button({
            style_class: 'icon-button',
            child: new St.Icon({icon_name: 'view-refresh-symbolic'}),
            accessible_name: 'Vérifier maintenant',
            can_focus: true,
        });
        refresh.connect('clicked', onCheck);
        this.menu.addHeaderSuffix(refresh);
        this._list = new PopupMenu.PopupMenuSection();
        this.menu.addMenuItem(this._list);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this.menu.addAction('Mettre à jour', onUpgrade);
        this.connect('clicked', onUpgrade);
    }

    showUpdates(lines, checkedAt) {
        this.checked = lines.length > 0;
        this.subtitle = lines.length ? plural(lines.length, 'disponible') : 'OS à jour';
        this.menu.setHeader(upgradeIcon(), 'Updates', checkedAt ? `Vérifié à ${checkedAt.format('%H:%M')}` : '');
        this._list.removeAll();
        for (const line of lines.slice(0, MAX_LISTED)) {
            const [name, oldVersion, , newVersion] = line.split(/\s+/);
            this._list.addMenuItem(new PopupMenu.PopupMenuItem(`${name}  ${oldVersion} → ${newVersion}`,
                {reactive: false, can_focus: false}));
        }
        if (lines.length > MAX_LISTED) {
            this._list.addMenuItem(new PopupMenu.PopupMenuItem(`… et ${plural(lines.length - MAX_LISTED, 'autre')}`,
                {reactive: false, can_focus: false}));
        }
    }

    showStatus(text) {
        this.subtitle = text;
    }
});

// Pilule « Updates » de Quick Settings : en couleur d'accent tant que des
// mises à jour attendent ; clic = script de mise à jour, flèche = liste.
export const UpdatesIndicator = GObject.registerClass(
class UpdatesIndicator extends SystemIndicator {
    _init(upgradeCommand, intervalHours, autoClose) {
        super._init();
        this._command = upgradeCommand;
        this._autoClose = autoClose;
        this._holding = false;
        this._intervalS = intervalHours * 3600;
        this._scheduleId = 0;
        this._planned = false;
        this._resultDir = Gio.File.new_for_path(GLib.build_filenamev([GLib.get_user_cache_dir(), 'upgrade-check']));
        this._debounceId = 0;
        this._checkTimeoutId = 0;
        this._transactionId = 0;
        this._cancellable = new Gio.Cancellable();

        this._toggle = new UpdatesToggle(() => this._upgrade(), () => this._checkFromMenu());
        this.quickSettingsItems.push(this._toggle);

        GLib.mkdir_with_parents(this._resultDir.get_path(), 0o755);
        this._resultMonitor = this._resultDir.monitor_directory(Gio.FileMonitorFlags.WATCH_MOVES, null);
        this._resultMonitor.connect('changed', () => this._queueReload());
        const transactions = Gio.File.new_for_path(TRANSACTION_DIR);
        this._transactionMonitor = transactions.query_exists(null)
            ? transactions.monitor_directory(Gio.FileMonitorFlags.NONE, null) : null;
        this._transactionMonitor?.connect('changed', () => this._queueTransactionCheck());
        this._reload();
    }

    _queueReload() {
        if (this._debounceId)
            GLib.Source.remove(this._debounceId);
        this._debounceId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, DEBOUNCE_MS, () => {
            this._debounceId = 0;
            this._reload();
            return GLib.SOURCE_REMOVE;
        });
    }

    _queueTransactionCheck() {
        if (this._transactionId)
            GLib.Source.remove(this._transactionId);
        this._toggle.showStatus('MAJ en cours');
        this._transactionId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, TRANSACTION_DELAY_S, () => {
            this._transactionId = 0;
            this._startCheck();
            return GLib.SOURCE_REMOVE;
        });
    }

    async _reload() {
        const file = this._resultDir.get_child(RESULT_NAME);
        try {
            const [contents] = await file.load_contents_async(this._cancellable);
            const info = await file.query_info_async('time::modified', Gio.FileQueryInfoFlags.NONE,
                GLib.PRIORITY_DEFAULT, this._cancellable);
            const lines = new TextDecoder().decode(contents).split('\n').filter(line => line.trim());
            this._stopChecking();
            this._toggle.showUpdates(lines, info.get_modification_date_time().to_local());
        } catch (error) {
            if (error.matches(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED))
                return;
            this._toggle.showStatus(error.matches(Gio.IOErrorEnum, Gio.IOErrorEnum.NOT_FOUND)
                ? 'En attente' : 'Lecture impossible');
        }
        this._planCheck();
    }

    async _modified(file) {
        try {
            const info = await file.query_info_async('time::modified', Gio.FileQueryInfoFlags.NONE,
                GLib.PRIORITY_DEFAULT, this._cancellable);
            return info.get_modification_date_time();
        } catch (error) {
            if (error.matches(Gio.IOErrorEnum, Gio.IOErrorEnum.NOT_FOUND))
                return null;
            throw error;
        }
    }

    // Prochaine vérification : l'intervalle compté depuis la dernière réussie,
    // ou une minute après l'ouverture de session si le résultat est absent ou
    // antérieur à la dernière transaction pacman (résultat périmé).
    async _planCheck() {
        let delay = RETRY_DELAY_S;
        try {
            const result = await this._modified(this._resultDir.get_child(RESULT_NAME));
            const transaction = await this._modified(
                Gio.File.new_for_path(GLib.build_filenamev([TRANSACTION_DIR, TRANSACTION_FILE])));
            const stale = !result || (transaction !== null && transaction.compare(result) > 0);
            if (stale) {
                delay = this._planned ? RETRY_DELAY_S : STARTUP_DELAY_S;
            } else {
                const age = GLib.DateTime.new_now_utc().difference(result) / GLib.USEC_PER_SEC;
                delay = Math.max(STARTUP_DELAY_S, this._intervalS - age);
            }
        } catch (error) {
            if (error.matches(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED))
                return;
        }
        this._planned = true;
        this._scheduleCheck(delay);
    }

    _scheduleCheck(delay) {
        if (this._scheduleId)
            GLib.Source.remove(this._scheduleId);
        this._scheduleId = GLib.timeout_add_seconds(GLib.PRIORITY_LOW, Math.round(delay), () => {
            this._scheduleId = 0;
            this._startCheck();
            this._scheduleCheck(RETRY_DELAY_S);
            return GLib.SOURCE_REMOVE;
        });
    }

    _startCheck() {
        this._toggle.showStatus('Vérification…');
        if (this._checkTimeoutId)
            GLib.Source.remove(this._checkTimeoutId);
        this._checkTimeoutId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, CHECK_TIMEOUT_S, () => {
            this._checkTimeoutId = 0;
            this._stopChecking();
            this._reload();
            return GLib.SOURCE_REMOVE;
        });
        Gio.DBus.session.call('org.freedesktop.systemd1', '/org/freedesktop/systemd1',
            'org.freedesktop.systemd1.Manager', 'StartUnit', new GLib.Variant('(ss)', [CHECK_UNIT, 'replace']),
            null, Gio.DBusCallFlags.NONE, -1, this._cancellable, (connection, result) => {
                try {
                    connection.call_finish(result);
                } catch (error) {
                    if (error.matches(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED))
                        return;
                    this._stopChecking();
                    this._toggle.showStatus('Paquet upgrade-check absent');
                }
            });
    }

    _checkFromMenu() {
        if (!this._holding) {
            this._holding = true;
            this._autoClose?.hold();
        }
        this._startCheck();
    }

    _stopChecking() {
        if (this._checkTimeoutId)
            GLib.Source.remove(this._checkTimeoutId);
        this._checkTimeoutId = 0;
        if (this._holding) {
            this._holding = false;
            this._autoClose?.release(RESULT_VISIBLE_MS);
        }
    }

    _upgrade() {
        const command = this._command.replace(/^~(?=\/)/, GLib.get_home_dir());
        Gio.AppInfo.create_from_commandline(GLib.shell_quote(command), 'Upgrade', Gio.AppInfoCreateFlags.NONE)
            .launch([], global.create_app_launch_context(0, -1));
        Main.panel.closeQuickSettings();
    }

    destroy() {
        if (this._debounceId)
            GLib.Source.remove(this._debounceId);
        this._debounceId = 0;
        if (this._transactionId)
            GLib.Source.remove(this._transactionId);
        this._transactionId = 0;
        if (this._scheduleId)
            GLib.Source.remove(this._scheduleId);
        this._scheduleId = 0;
        this._stopChecking();
        this._cancellable.cancel();
        this._resultMonitor.cancel();
        this._transactionMonitor?.cancel();
        this.quickSettingsItems.forEach(item => item.destroy());
        this.quickSettingsItems.length = 0;
        super.destroy();
    }
});
