// docx_float.rs — les images flottantes de Word, ramenées dans le fil du
// texte sans casser la page.
//
// Dactylo n'a pas d'images flottantes : chaque image ancrée devient une
// image dans la ligne (docx_alt). Deux défauts en découlaient :
// 1. Dans Word, on réserve la place d'une image flottante avec des
//    paragraphes vides, que l'image recouvre. Ramenée dans la ligne, l'image
//    prend sa hauteur ET les paragraphes vides restent : grands trous,
//    pages repoussées. Les paragraphes vides que l'image recouvrait sont
//    retirés.
// 2. Deux images côte à côte (ancrées dans deux paragraphes voisins, à la
//    même hauteur) se retrouvaient l'une sous l'autre, dans l'ordre du
//    fichier. Elles sont réunies sur une ligne, de gauche à droite.
// L'image (ou la rangée) prend aussi sa place horizontale : centrée, à
// droite, ou décalée depuis la marge.
// SPDX-License-Identifier: GPL-3.0-or-later

use crate::docx_alt::{find_open, matching_close, MARK, MARK_END};

/// Marque d'une image flottante, devant son <w:drawing> : `left` ou `right`.
pub(crate) const FLOAT: &str = "<!--dactylo-float:";

/// 1 cm en EMU.
const CM: i64 = 360_000;
/// Hauteur d'une ligne vide par défaut (Calibri 11, interligne 1,15).
pub(crate) const LINE_EMU: i64 = 166_000;

struct Pic {
    /// Le <w:drawing> complet.
    xml: String,
    x: i64,
    align: Option<String>,
    y: i64,
    w: i64,
    h: i64,
    /// Placée par rapport au paragraphe (ou à la ligne) : on sait où elle
    /// tombe dans le fil.
    flows: bool,
    /// Habillage « carré », « rapproché » ou « au travers » : le texte
    /// coule à côté.
    beside: bool,
}

pub(crate) struct Para {
    pub(crate) start: usize,
    pub(crate) end: usize,
    /// Rien d'écrit, aucun dessin, aucun saut de page ni de section.
    pub(crate) empty: bool,
    pub(crate) text: bool,
    /// Hauteur estimée en EMU.
    pub(crate) height: i64,
    pics: Vec<Pic>,
}

fn attr<'a>(tag: &'a str, k: &str) -> Option<&'a str> {
    let pat = format!(" {k}=\"");
    let i = tag.find(&pat)? + pat.len();
    tag[i..].split('"').next()
}

fn tag_at<'a>(xml: &'a str, name: &str) -> Option<&'a str> {
    let s = find_open(xml, name, 0)?;
    Some(&xml[s..s + xml[s..].find('>')?])
}

/// Le contenu du premier `<name>…</name>`.
fn text_of<'a>(xml: &'a str, name: &str) -> Option<&'a str> {
    let s = find_open(xml, name, 0)?;
    let o = s + xml[s..].find('>')? + 1;
    let e = o + xml[o..].find(&format!("</{name}>"))?;
    Some(&xml[o..e])
}

fn has_text(p: &str) -> bool {
    let mut at = 0;
    while let Some(s) = find_open(p, "w:t", at) {
        let Some(o) = p[s..].find('>').map(|i| s + i + 1) else { break };
        if p.as_bytes()[o - 2] == b'/' {
            at = o;
            continue;
        }
        let e = p[o..].find("</w:t>").map_or(p.len(), |i| o + i);
        if !p[o..e].trim().is_empty() {
            return true;
        }
        at = e;
    }
    false
}

/// Une image flottante du paragraphe : (début, fin) de son <w:drawing>.
fn pics_of(p: &str) -> Vec<(usize, usize, Pic)> {
    let mut out = Vec::new();
    let mut at = 0;
    while let Some(s) = find_open(p, "w:drawing", at) {
        let Some(e) = matching_close(p, "w:drawing", s) else { break };
        at = e;
        let d = &p[s..e];
        if !d.contains("<wp:anchor") || !d.contains("<pic:pic") || d.contains("<wps:") || d.contains("<wpg:") {
            continue;
        }
        let Some(ext) = tag_at(d, "wp:extent") else { continue };
        let num = |v: Option<&str>| v.and_then(|v| v.trim().parse::<f64>().ok()).unwrap_or(0.0) as i64;
        let (w, h) = (num(attr(ext, "cx")), num(attr(ext, "cy")));
        let hblock = find_open(d, "wp:positionH", 0).and_then(|s| matching_close(d, "wp:positionH", s).map(|e| &d[s..e])).unwrap_or("");
        let vblock = find_open(d, "wp:positionV", 0).and_then(|s| matching_close(d, "wp:positionV", s).map(|e| &d[s..e])).unwrap_or("");
        let hrel = tag_at(hblock, "wp:positionH").and_then(|t| attr(t, "relativeFrom")).unwrap_or("column");
        let vrel = tag_at(vblock, "wp:positionV").and_then(|t| attr(t, "relativeFrom")).unwrap_or("paragraph");
        let x = num(text_of(hblock, "wp:posOffset"));
        let align = text_of(hblock, "wp:align").map(|a| a.trim().to_string());
        let y = num(text_of(vblock, "wp:posOffset"));
        // Seuls les décalages par rapport à la colonne (ou à la marge) disent
        // où l'image est dans la largeur du texte.
        let x = if matches!(hrel, "column" | "margin" | "character") { x } else { 0 };
        let beside = d.contains("<wp:wrapSquare") || d.contains("<wp:wrapTight") || d.contains("<wp:wrapThrough");
        out.push((s, e, Pic { xml: d.to_string(), x, align, y, w, h, flows: matches!(vrel, "paragraph" | "line"), beside }));
    }
    out
}

/// Hauteur d'un paragraphe sans texte : sa taille de police, ses espaces.
fn empty_height(p: &str) -> i64 {
    let sz = tag_at(p, "w:sz").and_then(|t| attr(t, "w:val")).and_then(|v| v.parse::<f64>().ok()).unwrap_or(22.0);
    let mut emu = (sz / 22.0 * LINE_EMU as f64) as i64;
    if let Some(sp) = tag_at(p, "w:spacing") {
        for k in ["w:before", "w:after"] {
            if let Some(tw) = attr(sp, k).and_then(|v| v.parse::<f64>().ok()) {
                emu += (tw * 635.0) as i64;
            }
        }
    }
    emu
}

/// Largeur du texte (EMU), d'après la dernière section.
pub(crate) fn column_width(xml: &str) -> i64 {
    let Some(s) = xml.rfind("<w:sectPr") else { return 9638 * 635 };
    let sect = &xml[s..];
    let tw = |name: &str, k: &str| tag_at(sect, name).and_then(|t| attr(t, k)).and_then(|v| v.parse::<f64>().ok());
    let w = tw("w:pgSz", "w:w").unwrap_or(11906.0);
    let l = tw("w:pgMar", "w:left").unwrap_or(1134.0);
    let r = tw("w:pgMar", "w:right").unwrap_or(1134.0);
    ((w - l - r).max(2000.0) * 635.0) as i64
}

/// Les paragraphes de premier niveau du corps (les tableaux et blocs sont
/// des séparations : `None`).
pub(crate) fn top_level(xml: &str) -> (Vec<Option<Para>>, Vec<usize>) {
    let Some(body) = find_open(xml, "w:body", 0) else { return (Vec::new(), Vec::new()) };
    let mut at = body + 8;
    let mut out = Vec::new();
    let mut starts = Vec::new();
    loop {
        let next = ["w:p", "w:tbl", "w:sdt"].iter().filter_map(|n| find_open(xml, n, at).map(|i| (i, *n))).min();
        let Some((s, name)) = next else { break };
        let Some(e) = matching_close(xml, name, s) else { break };
        at = e;
        starts.push(s);
        if name != "w:p" {
            out.push(None);
            continue;
        }
        let p = &xml[s..e];
        let text = has_text(p);
        let barrier = p.contains("<w:sectPr") || p.contains("w:type=\"page\"");
        let drawing = p.contains("<w:drawing") || p.contains("<w:pict") || p.contains("<w:object") || p.contains("<mc:AlternateContent");
        let pics = pics_of(p).into_iter().map(|(_, _, pic)| pic).collect();
        out.push(Some(Para { start: s, end: e, empty: !text && !drawing && !barrier, text, height: if text { 2 * LINE_EMU } else { empty_height(p) }, pics }));
    }
    (out, starts)
}

/// Le paragraphe qui porte une rangée d'images, placée dans la largeur.
fn row_paragraph(mut pics: Vec<Pic>, col: i64) -> String {
    for p in &mut pics {
        match p.align.as_deref() {
            Some("center") => p.x = (col - p.w) / 2,
            Some("right" | "outside") => p.x = col - p.w,
            Some(_) => p.x = 0,
            None => {}
        }
    }
    pics.sort_by_key(|p| p.x);
    // Une rangée plus large que le texte (Word la laisse déborder dans la
    // marge) : réduite pour tenir, sinon elle passerait à la ligne.
    if pics.len() > 1 {
        let mut end = i64::MIN;
        let mut need = 0i64;
        for p in &pics {
            need += p.w + if end > i64::MIN && p.x > end { CM / 5 } else { 0 };
            end = p.x.max(end) + p.w;
        }
        let room = col - pics[0].x.max(0);
        if need > room {
            let f = (col as f64 * 0.98) / need as f64;
            let x0 = pics[0].x;
            for p in &mut pics {
                p.x = ((p.x - x0) as f64 * f) as i64;
                p.xml = scale_drawing(&p.xml, f);
                p.w = (p.w as f64 * f) as i64;
                p.h = (p.h as f64 * f) as i64;
            }
        }
    }
    let twips = |emu: i64| emu.max(0) / 635;
    let mut ppr = String::new();
    let mut runs = String::new();
    if pics.len() == 1 {
        let p = &pics[0];
        let centre = p.x + p.w / 2 - col / 2;
        if p.align.as_deref() == Some("center") || centre.abs() < CM * 6 / 10 || p.w >= col {
            ppr.push_str("<w:jc w:val=\"center\"/>");
        } else if p.x > CM && p.x + p.w > col - CM * 3 / 10 {
            ppr.push_str("<w:jc w:val=\"right\"/>");
        } else if p.x > CM * 3 / 10 {
            ppr.push_str(&format!("<w:ind w:left=\"{}\"/>", twips(p.x)));
        }
    } else {
        // Chaque image suivante à son abscisse : un taquet de tabulation.
        let first = pics[0].x.max(0);
        let mut tabs = String::new();
        let mut end = first + pics[0].w;
        for p in &pics[1..] {
            if p.x > end {
                tabs.push_str(&format!("<w:tab w:val=\"left\" w:pos=\"{}\"/>", twips(p.x)));
            }
            end = p.x.max(end) + p.w;
        }
        if !tabs.is_empty() {
            ppr.push_str(&format!("<w:tabs>{tabs}</w:tabs>"));
        }
        if first > CM * 3 / 10 {
            ppr.push_str(&format!("<w:ind w:left=\"{}\"/>", twips(first)));
        }
    }
    let mut end = i64::MIN;
    for (i, p) in pics.iter().enumerate() {
        if i > 0 {
            runs.push_str(if p.x > end { "<w:r><w:tab/></w:r>" } else { "<w:r><w:t xml:space=\"preserve\"> </w:t></w:r>" });
        }
        end = p.x.max(end) + p.w;
        runs.push_str(&format!("<w:r>{}</w:r>", p.xml));
    }
    // (l'ordre du schéma : tabs, spacing, ind, jc)
    let (tabs, rest) = match ppr.find("</w:tabs>") {
        Some(i) => (&ppr[..i + 9], &ppr[i + 9..]),
        None => ("", ppr.as_str()),
    };
    // Plusieurs images : alignées par le haut, comme flottantes dans Word.
    let top = if pics.len() > 1 { "<w:textAlignment w:val=\"top\"/>" } else { "" };
    format!("<w:p><w:pPr>{tabs}<w:spacing w:before=\"0\" w:after=\"0\"/>{rest}{top}</w:pPr>{runs}</w:p>")
}

/// Le dessin à `f` fois sa taille (wp:extent et a:ext).
fn scale_drawing(xml: &str, f: f64) -> String {
    let mut cur = xml.to_string();
    for key in [" cx=\"", " cy=\""] {
        let mut out = String::with_capacity(cur.len());
        let mut rest = cur.as_str();
        while let Some(i) = rest.find(key) {
            let v0 = i + key.len();
            let Some(len) = rest[v0..].find('"') else { break };
            // (seulement dans <wp:extent …> et <a:ext …>)
            let tag = &rest[rest[..i].rfind('<').unwrap_or(0)..i];
            out.push_str(&rest[..v0]);
            match rest[v0..v0 + len].parse::<f64>() {
                Ok(n) if tag.starts_with("<wp:extent") || tag.starts_with("<a:ext") => out.push_str(&((n * f).round() as i64).to_string()),
                _ => out.push_str(&rest[v0..v0 + len]),
            }
            rest = &rest[v0 + len..];
        }
        out.push_str(rest);
        cur = out;
    }
    cur
}

/// Le paragraphe sans ses images flottantes.
fn without_pics(p: &str) -> String {
    let mut out = p.to_string();
    for (s, e, _) in pics_of(p).into_iter().rev() {
        out.replace_range(s..e, "");
    }
    out
}

/// Le document remis en ordre, ou `None` s'il n'y avait rien à changer.
pub fn reflow(xml: &str) -> Option<String> {
    if !xml.contains("<wp:anchor") || !(xml.contains("<pic:pic") || xml.contains(MARK)) {
        return None;
    }
    let (paras, starts) = top_level(xml);
    let col = column_width(xml);
    // Remplacements : (début, fin, nouveau texte), dans l'ordre.
    let mut edits: Vec<(usize, usize, String)> = Vec::new();
    let mut i = 0;
    while i < paras.len() {
        let Some(host) = paras[i].as_ref().filter(|p| !p.pics.is_empty()) else {
            // Des zones de texte seules (sans image) : leurs cartouches
            // prennent leur place dans le fil ; les paragraphes vides qui la
            // leur réservaient dans Word sont retirés.
            if let Some(p) = paras[i].as_ref().filter(|p| xml[p.end..].trim_start().starts_with(MARK)) {
                let (box_end, bottom) = boxes_after(xml, p.end);
                let mut k = i + 1;
                while starts.get(k).is_some_and(|&s| s < box_end) {
                    k += 1;
                }
                let mut covered = if p.text { 0 } else { p.height };
                while let Some(Some(q)) = paras.get(k) {
                    if !q.empty || covered + q.height > bottom + CM / 5 {
                        break;
                    }
                    covered += q.height;
                    edits.push((q.start, q.end, String::new()));
                    k += 1;
                }
                i = k;
                continue;
            }
            i += 1;
            continue;
        };
        // Les images voisines à la même hauteur, ancrées dans les paragraphes
        // suivants (vides entre deux), rejoignent la rangée.
        let mut group = vec![i];
        let mut offset = host.height;
        let mut j = i + 1;
        while j < paras.len() && j <= i + 3 {
            let Some(p) = paras[j].as_ref() else { break };
            if !p.pics.is_empty() {
                let top = offset + p.pics.iter().map(|q| q.y).min().unwrap_or(0);
                let bottom = group.iter().flat_map(|&g| paras[g].as_ref().unwrap().pics.iter().map(move |q| (g, q))).map(|(g, q)| rel(&paras, i, g) + q.y + q.h).max().unwrap_or(0);
                let flows = p.pics.iter().all(|q| q.flows) && host.pics.iter().all(|q| q.flows);
                if flows && top < bottom - CM / 2 && !p.text {
                    group.push(j);
                } else {
                    break;
                }
            } else if !p.empty {
                break;
            }
            offset += p.height;
            j += 1;
        }
        let last = *group.last().unwrap();
        let all: Vec<&Pic> = group.iter().flat_map(|&g| paras[g].as_ref().unwrap().pics.iter()).collect();
        let flows = all.iter().all(|q| q.flows);
        // Bas de la rangée, compté depuis le haut du dernier paragraphe hôte.
        let bottom = group.iter().flat_map(|&g| paras[g].as_ref().unwrap().pics.iter().map(move |q| (g, q))).map(|(g, q)| rel(&paras, last, g) + q.y + q.h).max().unwrap_or(0);
        // Une image étroite, seule, avec du texte à côté (habillage carré) :
        // elle reste flottante, au bord de la colonne, et le texte coule à
        // côté. Elle passe en tête de son paragraphe, marquée du bord.
        // (une zone de texte posée à côté compte comme du texte : elle longe
        // l'image elle aussi)
        let boxes_follow = xml[host.end..].trim_start().starts_with(MARK);
        if group.len() == 1 && host.pics.len() == 1 {
            let q = &host.pics[0];
            let x = match q.align.as_deref() {
                Some("center") => (col - q.w) / 2,
                Some("right" | "outside") => col - q.w,
                Some(_) => 0,
                None => q.x,
            };
            let text_near = host.text || boxes_follow || (i + 1..(i + 4).min(paras.len())).any(|k| paras[k].as_ref().is_some_and(|p| p.text));
            let centred = (x + q.w / 2 - col / 2).abs() < CM / 2;
            // (posée bien plus bas que le haut de son paragraphe : pas ici)
            if q.beside && q.flows && q.w < col * 62 / 100 && text_near && !centred && q.y.abs() < 2 * CM {
                let side = if x + q.w / 2 <= col / 2 { "left" } else { "right" };
                let p = &xml[host.start..host.end];
                let stripped = without_pics(p);
                // Après <w:pPr>…</w:pPr>, ou après la balise ouvrante.
                let at = match stripped.find("</w:pPr>") {
                    Some(k) => k + "</w:pPr>".len(),
                    None => stripped.find('>').map_or(0, |k| k + 1),
                };
                let mut out = stripped.clone();
                out.insert_str(at, &format!("<w:r>{FLOAT}{side}-->{}</w:r>", q.xml));
                edits.push((host.start, host.end, out));
                i += 1;
                continue;
            }
        }
        // Hauteur de chaque image depuis le haut du dernier hôte ; des
        // images l'une sous l'autre font des rangées distinctes.
        let mut pics: Vec<Pic> = group
            .iter()
            .flat_map(|&g| paras[g].as_ref().unwrap().pics.iter().map(move |q| (g, q)))
            .map(|(g, q)| Pic { xml: q.xml.clone(), x: q.x, align: q.align.clone(), y: rel(&paras, last, g) + q.y, w: q.w, h: q.h, flows: q.flows, beside: q.beside })
            .collect();
        pics.sort_by_key(|p| p.y);
        let mut rows: Vec<Vec<Pic>> = Vec::new();
        let mut row_bottom = i64::MIN;
        for p in pics {
            let (top, bottom) = (p.y, p.y + p.h);
            match rows.last_mut() {
                Some(r) if top < row_bottom - CM / 2 => {
                    r.push(p);
                    row_bottom = row_bottom.max(bottom);
                }
                _ => {
                    rows.push(vec![p]);
                    row_bottom = bottom;
                }
            }
        }
        // Les cartouches des zones de texte ancrées dans le dernier hôte
        // (posés juste après lui, marqués de leur hauteur) : rangés avec les
        // images, de haut en bas.
        let host_end = paras[last].as_ref().unwrap().end;
        let mut boxes: Vec<(i64, String)> = Vec::new();
        let mut box_end = host_end;
        let mut bottom = bottom;
        while xml[box_end..].trim_start().starts_with(MARK) {
            let s0 = box_end + (xml[box_end..].len() - xml[box_end..].trim_start().len());
            let Some(head) = xml[s0..].find("-->").map(|e| s0 + e + 3) else { break };
            let Some(close) = xml[head..].find(MARK_END).map(|e| head + e) else { break };
            let mut nums = xml[s0 + MARK.len()..head - 3].split(':').map(|n| n.parse::<i64>().unwrap_or(0));
            let (y, h) = (nums.next().unwrap_or(0), nums.next().unwrap_or(0));
            bottom = bottom.max(y + h);
            boxes.push((y, xml[head..close].to_string()));
            box_end = close + MARK_END.len();
        }
        let mut items: Vec<(i64, String)> = rows.into_iter().map(|r| (r.iter().map(|p| p.y).min().unwrap_or(0), row_paragraph(r, col))).collect();
        items.extend(boxes);
        items.sort_by_key(|(y, _)| *y);
        let row: String = items.into_iter().map(|(_, t)| t).collect();
        // Les hôtes perdent leurs images ; la rangée prend la place du
        // dernier s'il est vide, sinon elle vient juste après.
        for &g in &group {
            let p = paras[g].as_ref().unwrap();
            let stripped = without_pics(&xml[p.start..p.end]);
            if g == last {
                let alone = !p.text && !stripped.contains("<w:drawing") && !stripped.contains("<w:pict") && !stripped.contains("<w:sectPr");
                edits.push((p.start, box_end, if alone { row.clone() } else { format!("{stripped}{row}") }));
            } else {
                edits.push((p.start, p.end, stripped));
            }
        }
        // Les paragraphes vides que la rangée recouvrait.
        let mut k = last + 1;
        while starts.get(k).is_some_and(|&s| s < box_end) {
            k += 1;
        }
        let mut covered = if paras[last].as_ref().unwrap().text { 0 } else { paras[last].as_ref().unwrap().height };
        if flows {
            while let Some(Some(p)) = paras.get(k) {
                if !p.empty || covered + p.height > bottom + CM / 5 {
                    break;
                }
                covered += p.height;
                edits.push((p.start, p.end, String::new()));
                k += 1;
            }
        }
        i = k.max(last + 1);
    }
    if edits.is_empty() {
        return None;
    }
    let mut out = String::with_capacity(xml.len());
    let mut at = 0;
    for (s, e, t) in edits {
        out.push_str(&xml[at..s]);
        out.push_str(&t);
        at = e;
    }
    out.push_str(&xml[at..]);
    Some(out)
}

/// Pour chaque image (pic:pic), dans l'ordre du document mis à plat
/// (`docx_alt::unwrap`), le bord où elle flotte.
pub fn floats(xml: &str) -> Vec<Option<crate::model::ImageFloat>> {
    let mut out = Vec::new();
    let mut at = 0usize;
    while let Some(s) = find_open(xml, "pic:pic", at) {
        let Some(e) = matching_close(xml, "pic:pic", s) else { break };
        at = e;
        let side = xml[..s].rfind("<w:drawing").and_then(|d| {
            let before = xml[..d].trim_end();
            let m = before.rfind(FLOAT)?;
            // (la marque juste devant ce dessin, pas une plus ancienne)
            (before.len() - m < FLOAT.len() + 12 && before.ends_with("-->")).then(|| before[m + FLOAT.len()..].trim_end_matches("-->").to_string())
        });
        out.push(match side.as_deref() {
            Some("left") => Some(crate::model::ImageFloat::Left),
            Some("right") => Some(crate::model::ImageFloat::Right),
            _ => None,
        });
    }
    out
}

/// La fin des cartouches marqués posés à `at` (docx_alt::placed), et le
/// bas du plus bas, depuis le haut de leur paragraphe (EMU).
fn boxes_after(xml: &str, mut at: usize) -> (usize, i64) {
    let mut bottom = 0;
    while xml[at..].trim_start().starts_with(MARK) {
        let s0 = at + (xml[at..].len() - xml[at..].trim_start().len());
        let Some(head) = xml[s0..].find("-->").map(|e| s0 + e + 3) else { break };
        let Some(close) = xml[head..].find(MARK_END).map(|e| head + e) else { break };
        let mut nums = xml[s0 + MARK.len()..head - 3].split(':').map(|n| n.parse::<i64>().unwrap_or(0));
        let (y, h) = (nums.next().unwrap_or(0), nums.next().unwrap_or(0));
        bottom = bottom.max(y + h);
        at = close + MARK_END.len();
    }
    (at, bottom)
}

/// Distance estimée (EMU) du haut du paragraphe `to` au haut de `from`
/// (positive si `from` est plus bas).
fn rel(paras: &[Option<Para>], to: usize, from: usize) -> i64 {
    let (a, b, sign) = if from >= to { (to, from, 1) } else { (from, to, -1) };
    sign * (a..b).filter_map(|k| paras[k].as_ref()).map(|p| p.height).sum::<i64>()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn pic(x: &str, y: i64, w: i64, h: i64) -> String {
        format!(
            "<w:r><w:drawing><wp:anchor><wp:positionH relativeFrom=\"column\">{x}</wp:positionH><wp:positionV relativeFrom=\"paragraph\"><wp:posOffset>{y}</wp:posOffset></wp:positionV><wp:extent cx=\"{w}\" cy=\"{h}\"/><wp:wrapSquare wrapText=\"bothSides\"/><a:graphic><a:graphicData><pic:pic/></a:graphicData></a:graphic></wp:anchor></w:drawing></w:r>"
        )
    }

    fn doc(body: &str) -> String {
        format!("<w:document><w:body>{body}<w:sectPr><w:pgSz w:w=\"11906\"/><w:pgMar w:left=\"1134\" w:right=\"1134\"/></w:sectPr></w:body></w:document>")
    }

    #[test]
    fn reserved_empty_paragraphs_are_absorbed() {
        // Une image de 2 cm de haut, puis 6 paragraphes vides (≈ 2,8 cm) et du texte.
        let body = format!("<w:p>{}</w:p>{}<w:p><w:r><w:t>Suite</w:t></w:r></w:p>", pic("<wp:align>center</wp:align>", 0, 5 * CM, 2 * CM), "<w:p/>".repeat(6));
        let out = reflow(&doc(&body)).unwrap();
        let empties = out.matches("<w:p/>").count();
        assert!((1..=3).contains(&empties), "{empties} paragraphes vides restent : {out}");
        assert!(out.contains("<w:jc w:val=\"center\"/>"), "{out}");
        assert!(out.contains("Suite"));
    }

    #[test]
    fn side_by_side_pictures_share_a_line_left_to_right() {
        // La droite ancrée d'abord (paragraphe avec légende), la gauche ensuite.
        let body = format!(
            "<w:p><w:r><w:t>Légende</w:t></w:r>{}</w:p><w:p>{}</w:p>{}",
            pic("<wp:posOffset>3000000</wp:posOffset>", 100_000, 3_000_000, 1_800_000),
            pic("<wp:posOffset>-200000</wp:posOffset>", 80_000, 2_300_000, 3_200_000),
            "<w:p/>".repeat(20)
        );
        let out = reflow(&doc(&body)).unwrap();
        let a = out.find("3000000").unwrap();
        let b = out.find("-200000").unwrap();
        assert!(b < a, "la gauche d'abord : {out}");
        assert_eq!(out.matches("<w:drawing>").count(), 2);
        // Les deux images dans le même paragraphe.
        let row = &out[out.rfind("<w:p>").unwrap()..];
        let _ = row;
        assert!(out.contains("<w:tab/>"), "{out}");
        assert!(out.contains("Légende"));
        assert!(out.matches("<w:p/>").count() < 20);
    }

    #[test]
    fn text_after_the_picture_is_kept() {
        let body = format!("<w:p>{}</w:p><w:p/><w:p><w:r><w:t>Question</w:t></w:r></w:p><w:p/>", pic("<wp:posOffset>0</wp:posOffset>", 0, 2 * CM, 10 * CM));
        let out = reflow(&doc(&body)).unwrap();
        assert!(out.contains("Question"));
        // Le vide après la question n'est pas touché.
        assert!(out.ends_with("<w:p/><w:sectPr><w:pgSz w:w=\"11906\"/><w:pgMar w:left=\"1134\" w:right=\"1134\"/></w:sectPr></w:body></w:document>"), "{out}");
    }

    #[test]
    fn text_boxes_and_pictures_keep_their_height_order() {
        // Dans un même paragraphe : une image en bas (y = 15 cm), un
        // cartouche en haut (y = 1 cm), posé après le paragraphe par docx_alt.
        let body = format!(
            "<w:p><w:r><w:t>Doc 1</w:t></w:r>{}</w:p>{MARK}{}:{}-->BOITE{MARK_END}<w:p/>",
            pic("<wp:posOffset>0</wp:posOffset>", 15 * CM, 5 * CM, 3 * CM),
            CM,
            4 * CM
        );
        let out = reflow(&doc(&body)).unwrap();
        let b = out.find("BOITE").unwrap();
        let p = out.find("<w:drawing>").unwrap();
        assert!(b < p, "le cartouche d'abord : {out}");
        assert_eq!(out.matches("BOITE").count(), 1);
    }
}
