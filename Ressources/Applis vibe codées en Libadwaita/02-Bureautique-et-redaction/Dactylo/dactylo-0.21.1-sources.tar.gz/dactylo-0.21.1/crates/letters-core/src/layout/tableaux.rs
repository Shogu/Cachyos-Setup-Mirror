// SPDX-License-Identifier: GPL-3.0-or-later
// Les tableaux : colonnes, lignes, cases fusionnées, lignes coupées en bas de page.

use super::*;

/// A shaped paragraph of a table cell: its index, lines and height.
pub(super) type CellParagraph = (usize, Shaped, f64);

/// Lay out the table made of cell paragraphs `range`: equal-width columns
/// across the column box, rows as tall as their tallest cell, and a row
/// never split across pages.
pub(super) fn layout_table(flow: &mut Flow, doc: &Document, range: std::ops::Range<usize>, shaper: &mut dyn Shaper) {
    let cells: Vec<(usize, crate::model::TableCell)> =
        range.clone().filter_map(|i| doc.paragraphs[i].style.table_cell.map(|c| (i, c))).collect();
    let Some(&(_, first)) = cells.first() else { return };
    let cols = cells.iter().map(|(_, c)| c.col).max().unwrap_or(0) + 1;
    let rows = cells.iter().map(|(_, c)| c.row).max().unwrap_or(0) + 1;
    // Samizdat : à côté d'une image flottante, la place qui reste.
    let (dx, table_w) = flow.squeeze.take().unwrap_or((0.0, flow.column_width()));
    let squeezed = dx > 0.0 || table_w < flow.column_width();
    let col_w = table_w / f64::from(cols);
    let opts = flow.opts.clone();
    flow.y += std::mem::take(&mut flow.pending_after);
    // Samizdat : un bandeau remonté dans la marge du haut (espace avant
    // négatif, docx_alt::lift), en haut de page seulement, jamais au-delà
    // du bord de la feuille.
    let lift = doc.paragraphs[cells[0].0].style.space_before_pt;
    if lift < 0.0 && flow.column_is_empty() {
        flow.y = (flow.y + lift).max(flow.y.min(14.0));
    }
    let cell_of = |row: u32, col: u32| cells.iter().find(|(_, c)| c.row == row && c.col == col).map(|(_, c)| *c);

    // Samizdat : la largeur de chaque case, d'après le document (réduite
    // si le tableau dépasse), sinon un partage égal. Une case fusionnée
    // couvre plusieurs colonnes ; les cases masquées ne prennent rien.
    let mut grid: Vec<Option<f64>> = (0..cols)
        .map(|c| cells.iter().find(|(_, t)| t.col == c && !t.covered && t.span() == 1 && t.width_tw > 0).map(|(_, t)| f64::from(t.width_tw) / 20.0))
        .collect();
    // A column only ever covered by a merged cell: its width is what the
    // merged cell leaves to it.
    for (_, t) in cells.iter().filter(|(_, t)| !t.covered && t.span() > 1 && t.width_tw > 0) {
        let range = t.col as usize..((t.col + t.span()) as usize).min(grid.len());
        let missing: Vec<usize> = range.clone().filter(|&c| grid[c].is_none()).collect();
        if missing.len() == 1 {
            let known: f64 = range.filter_map(|c| grid[c]).sum();
            grid[missing[0]] = Some((f64::from(t.width_tw) / 20.0 - known).max(1.0));
        }
    }
    let grid: Vec<f64> = if grid.iter().all(Option::is_some) {
        grid.into_iter().map(|w| w.unwrap_or(col_w)).collect()
    } else {
        vec![col_w; cols as usize]
    };
    let widths: Vec<Vec<(u32, f64)>> = (0..rows)
        .map(|row| {
            (0..cols)
                .filter_map(|c| cell_of(row, c))
                .filter(|c| !c.covered)
                .map(|c| (c.col, (c.col..(c.col + c.span()).min(cols)).map(|g| grid[g as usize]).sum()))
                .collect()
        })
        .collect();
    let widest = widths.iter().map(|r| r.iter().map(|(_, w)| w).sum::<f64>()).fold(0.0, f64::max);
    // Samizdat : un tableau plus large que le texte déborde dans les marges
    // (comme dans Word), jusqu'à 1 cm du bord de la page, centré sur le
    // texte ; au-delà seulement, il est réduit.
    let (ml, mr) = (flow.geometry.margin_left_pt, flow.geometry.margin_right_pt);
    let max_w = if flow.columns() == 1 && !squeezed { table_w + (ml - TABLE_EDGE_PT).max(0.0) + (mr - TABLE_EDGE_PT).max(0.0) } else { table_w };
    let k = if widest > max_w + 2.0 * CELL_PADDING_PT { max_w / widest } else { 1.0 };
    let over = (widest * k - table_w - 2.0 * CELL_PADDING_PT).max(0.0);
    let shift = (over / 2.0).min((ml - TABLE_EDGE_PT).max(0.0)).max(over - (mr - TABLE_EDGE_PT).max(0.0)).max(0.0);

    // A one-cell table is a text box: room above and below its text.
    let pad_v = if rows == 1 && cols == 1 { BOX_PADDING_PT } else { 0.0 };

    // Shape every row first: a cell merged downwards needs the heights of
    // the rows below it.
    struct RowCell {
        cell: crate::model::TableCell,
        x: f64,
        w: f64,
        paras: Vec<CellParagraph>,
    }
    let mut shaped: Vec<(Vec<RowCell>, f64)> = Vec::with_capacity(rows as usize);
    for row in 0..rows {
        let mut row_cells = Vec::new();
        let mut row_h: f64 = 0.0;
        let mut x = 0.0;
        for &(col, w) in &widths[row as usize] {
            let w = w * k;
            let Some(cell) = cell_of(row, col) else { continue };
            let inner_w = (w - 2.0 * CELL_PADDING_PT).max(1.0);
            let mut h = 0.0;
            let mut paras = Vec::new();
            for &(i, _) in cells.iter().filter(|(_, c)| c.row == row && c.col == col) {
                let p = &doc.paragraphs[i];
                let s = shape_paragraph(p, inner_w, &opts, shaper);
                let ph: f64 = s.lines.iter().map(|l| l.natural_height() * spacing(p)).sum::<f64>()
                    + p.style.space_before_pt.max(0.0)
                    + p.style.space_after_pt.max(0.0);
                paras.push((i, s, ph));
                h += ph;
            }
            // Le texte d'une case fusionnée vers le bas se répartit sur
            // ses lignes : il ne grandit pas la première seule.
            if cell.vmerge != 1 {
                row_h = row_h.max(h + CELL_RULE_PT + 2.0 * pad_v);
            }
            row_cells.push(RowCell { cell, x, w, paras });
            x += w;
        }
        if let Some(c) = cell_of(row, 0).or_else(|| row_cells.first().map(|r| r.cell)) {
            let min = f64::from(c.height_tw) / 20.0;
            if c.height_exact && min > 0.0 {
                row_h = min;
            } else {
                row_h = row_h.max(min);
            }
        }
        shaped.push((row_cells, row_h));
    }
    // A downward merge whose text needs more room than its rows: the last
    // row grows.
    for row in 0..shaped.len() {
        for ci in 0..shaped[row].0.len() {
            let c = &shaped[row].0[ci];
            if c.cell.vmerge != 1 {
                continue;
            }
            let need: f64 = c.paras.iter().map(|(_, _, h)| h).sum::<f64>() + CELL_RULE_PT;
            let col = c.cell.col;
            let mut last = row;
            while cell_of(last as u32 + 1, col).is_some_and(|n| n.vmerge == 2) {
                last += 1;
            }
            let have: f64 = shaped[row..=last].iter().map(|r| r.1).sum();
            if need > have {
                shaped[last].1 += need - have;
            }
        }
    }
    let heights: Vec<f64> = shaped.iter().map(|r| r.1).collect();
    for (row, (row_cells, row_h)) in shaped.into_iter().enumerate() {
        // Samizdat : une ligne qui ne tient pas se coupe en bas de page,
        // comme dans Word (sauf une case fusionnée vers le bas) : s'il
        // reste de la place ici, ou si elle est plus haute qu'une page.
        let room = flow.bottom() - flow.y;
        let page_room = flow.foot() - flow.top();
        let merged = row_cells.iter().any(|c| c.cell.vmerge != 0);
        if flow.y + row_h > flow.bottom() && !merged && (room >= SPLIT_MIN_PT || row_h > page_room) {
            if room < SPLIT_MIN_PT && !flow.column_is_empty() {
                flow.next_column();
            }
            split_row(flow, doc, first.table, row as u32, row_cells.into_iter().map(|c| (c.cell, c.x - shift + dx, c.w, c.paras)).collect(), row_h, pad_v);
            continue;
        }
        if flow.y + row_h > flow.bottom() && !flow.column_is_empty() {
            flow.next_column();
        }
        let top = flow.y;
        let x0 = flow.column_x() - shift + dx;
        for RowCell { cell, x, w, paras } in row_cells {
            // The table hangs one cell padding into the left margin, so
            // cell text lines up with the body text (Word's and
            // LibreOffice's default table indent).
            let cx = x0 - CELL_PADDING_PT + x;
            if cell.vmerge == 2 {
                continue;
            }
            let mut height = row_h;
            if cell.vmerge == 1 {
                let mut r = row + 1;
                while cell_of(r as u32, cell.col).is_some_and(|n| n.vmerge == 2) {
                    height += heights[r];
                    r += 1;
                }
            }
            flow.push(Item::Cell {
                table: first.table,
                row: row as u32,
                col: cell.col,
                x_pt: cx,
                y_pt: top,
                width_pt: w,
                height_pt: height,
                fill: cell.fill,
                rule: !cell.no_border,
            });
            let mut y = top + pad_v;
            for (i, s, _) in paras {
                let p = &doc.paragraphs[i];
                y += p.style.space_before_pt.max(0.0);
                let text: Vec<char> = layout_text(&p.runs).chars().collect();
                for (k, lb) in s.lines.iter().enumerate() {
                    let h = lb.natural_height() * spacing(p);
                    emit_line(flow, i, p, &text, k, lb, cx + CELL_PADDING_PT + s.box_x, s.box_w, y, h);
                    y += h;
                }
                y += p.style.space_after_pt.max(0.0);
            }
        }
        flow.y = top + row_h;
    }
    // Samizdat : un peu d'air sous un cartouche.
    if pad_v > 0.0 {
        flow.pending_after = flow.pending_after.max(BOX_PADDING_PT);
    }
}

/// Samizdat : la marge que garde un tableau qui déborde, au bord de la page.
pub(super) const TABLE_EDGE_PT: f64 = 28.0;

/// Samizdat : place minimale pour commencer une ligne de tableau coupée en
/// bas de page (environ trois lignes de texte).
pub(super) const SPLIT_MIN_PT: f64 = 40.0;

/// Samizdat : une ligne de tableau sur plusieurs pages. Chaque case se
/// remplit ligne à ligne jusqu'au bas de la page ; la suite reprend en haut
/// de la page suivante. Chaque morceau a son cadre.
#[allow(clippy::type_complexity)]
pub(super) fn split_row(flow: &mut Flow, doc: &Document, table: u32, row: u32, cells: Vec<(crate::model::TableCell, f64, f64, Vec<CellParagraph>)>, row_h: f64, pad_v: f64) {
    // (paragraphe, ligne, espace avant, hauteur, espace après) de chaque case.
    let entries: Vec<Vec<(usize, usize, f64, f64, f64)>> = cells
        .iter()
        .map(|(_, _, _, paras)| {
            let mut v = Vec::new();
            for (i, s, _) in paras {
                let p = &doc.paragraphs[*i];
                let n = s.lines.len();
                for (k, lb) in s.lines.iter().enumerate() {
                    let before = if k == 0 { p.style.space_before_pt.max(0.0) } else { 0.0 };
                    let after = if k + 1 == n { p.style.space_after_pt.max(0.0) } else { 0.0 };
                    v.push((*i, k, before, lb.natural_height() * spacing(p), after));
                }
            }
            v
        })
        .collect();
    let mut next = vec![0usize; cells.len()];
    let mut used = 0.0;
    loop {
        let top = flow.y;
        let limit = flow.bottom() - CELL_RULE_PT - pad_v;
        let x0 = flow.column_x();
        let mut seg_h: f64 = 0.0;
        // Les cadres d'abord (leur fond sous le texte) ; leur hauteur est
        // connue ensuite.
        let first_cell = flow.pages.last().map_or(0, |p| p.items.len());
        for (cell, x, w, _) in &cells {
            flow.push(Item::Cell {
                table,
                row,
                col: cell.col,
                x_pt: x0 - CELL_PADDING_PT + x,
                y_pt: top,
                width_pt: *w,
                height_pt: 0.0,
                fill: cell.fill,
                rule: !cell.no_border,
            });
        }
        for (ci, (_, x, _, paras)) in cells.iter().enumerate() {
            let cx = x0 - CELL_PADDING_PT + x;
            let mut y = top + pad_v;
            let mut placed = 0;
            while let Some(&(i, k, before, h, after)) = entries[ci].get(next[ci]) {
                if y + before + h > limit && (placed > 0 || top > flow.top() + 1.0) {
                    break;
                }
                let p = &doc.paragraphs[i];
                let Some((_, s, _)) = paras.iter().find(|(pi, _, _)| *pi == i) else { break };
                let text: Vec<char> = layout_text(&p.runs).chars().collect();
                y += before;
                emit_line(flow, i, p, &text, k, &s.lines[k], cx + CELL_PADDING_PT + s.box_x, s.box_w, y, h);
                y += h + after;
                next[ci] += 1;
                placed += 1;
            }
            seg_h = seg_h.max(y - top + pad_v + CELL_RULE_PT);
        }
        let done = next.iter().zip(&entries).all(|(n, e)| *n >= e.len());
        if done {
            // La hauteur minimale de la ligne, pour le dernier morceau.
            seg_h = seg_h.max(row_h - used);
        } else {
            seg_h = seg_h.max(limit + pad_v + CELL_RULE_PT - top);
        }
        if let Some(page) = flow.pages.last_mut() {
            for item in page.items.iter_mut().skip(first_cell).take(cells.len()) {
                if let Item::Cell { height_pt, .. } = item {
                    *height_pt = seg_h;
                }
            }
        }
        used += seg_h;
        flow.y = top + seg_h;
        if done {
            break;
        }
        flow.next_column();
    }
}
