// docx_diagram.rs — les schémas de Word : formes, flèches et zones de texte
// posées les unes à côté des autres, dessinés ensemble.
//
// Un schéma (schéma actantiel, carte mentale…) est fait de dizaines de
// formes et de zones de texte placées librement, ancrées dans un ou
// plusieurs paragraphes, au-dessus de paragraphes vides qui leur gardent la
// place. Dactylo ne sait pas placer librement : chaque zone devenait un
// cadre dans le fil, chaque forme un morceau de croquis, et le schéma
// s'éparpillait.
//
// Ici, les éléments voisins forment un schéma (au moins deux, dont une
// forme visible) : ils sont retirés du texte, avec les paragraphes vides
// qu'ils recouvraient, et remplacés par une étiquette « ⟦schéma N⟧ ».
// L'étiquette est gardée (docx_keep) : à l'enregistrement en .docx, le
// schéma d'origine et ses paragraphes reviennent tels quels. À l'écran,
// l'étiquette porte l'image du schéma dessiné (`render`).
// SPDX-License-Identifier: GPL-3.0-or-later

//
// Découpage : lecture (les formes du XML), detection (les schémas du
// document), dessin (l'image), edition (le texte des cases).

use crate::docx_alt::{find_open, matching_close};

mod detection;
#[cfg(feature = "render")]
mod dessin;
mod edition;
mod lecture;
#[cfg(test)]
mod tests;

pub use detection::extract;
#[cfg(feature = "render")]
pub use dessin::render;
#[cfg(feature = "render")]
pub use edition::render_kept;
pub use edition::{box_texts, set_box_texts};
use lecture::*;

pub(super) const CM: i64 = 360_000;

/// Un élément de schéma, en EMU, dans le repère du document (x depuis la
/// marge gauche, y depuis le haut estimé du premier paragraphe).
#[derive(Clone, Debug, Default)]
pub struct Elem {
    pub x: i64,
    pub y: i64,
    pub w: i64,
    pub h: i64,
    pub z: i64,
    /// Forme prédéfinie (`a:prstGeom`), "pic" pour une image.
    pub geom: String,
    pub flip_h: bool,
    pub flip_v: bool,
    /// Rotation en degrés.
    pub rot: f64,
    pub fill: Option<[u8; 3]>,
    /// Trait : couleur, épaisseur (pt), pointillé.
    pub line: Option<([u8; 3], f64, bool)>,
    /// Pointes de flèche au début (`headEnd`) et à la fin (`tailEnd`).
    pub head: bool,
    pub tail: bool,
    pub text: Vec<TextPara>,
    /// Marges intérieures du texte (EMU) : gauche, haut, droite, bas.
    pub insets: [i64; 4],
    /// Texte en haut (0), au milieu (1), en bas (2).
    pub v_anchor: u8,
    /// Image : son identifiant de relation (`r:embed`).
    pub embed: Option<String>,
    /// Forme libre (`a:custGeom`) : ses tracés, chacun dans son repère
    /// (largeur, hauteur), rempli ou non, tracé ou non.
    pub paths: Vec<Path>,
}

#[derive(Clone, Debug, Default)]
pub struct Path {
    pub w: f64,
    pub h: f64,
    pub fill: bool,
    pub stroke: bool,
    pub cmds: Vec<Cmd>,
}

#[derive(Clone, Debug)]
pub enum Cmd {
    Move(f64, f64),
    Line(f64, f64),
    Cubic(f64, f64, f64, f64, f64, f64),
    Quad(f64, f64, f64, f64),
    /// Arc d'ellipse : rayons, angle de départ et balayage (degrés).
    Arc(f64, f64, f64, f64),
    Close,
}

#[derive(Clone, Debug, Default)]
pub struct TextPara {
    /// (texte, taille en pt, gras, italique, couleur, souligné)
    pub runs: Vec<(String, f64, bool, bool, Option<[u8; 3]>, bool)>,
    /// 0 gauche, 1 centre, 2 droite, 3 justifié.
    pub align: u8,
}

pub struct Diagram {
    pub label: String,
    /// Ce que l'étiquette redevient à l'enregistrement : le run des formes,
    /// puis les paragraphes qu'elles recouvraient.
    pub keep_xml: String,
    pub elems: Vec<Elem>,
}

/// Un bloc ancré dans un paragraphe : (début, fin) dans le document, et
/// ses éléments.
pub(super) struct Block {
    start: usize,
    end: usize,
    host: usize,
    elems: Vec<Elem>,
    /// Une image seule (rattachée à un schéma seulement si elle le touche).
    pic: bool,
    /// Une forme qui se voit (pas seulement une zone de texte).
    drawn: bool,
    /// Placée par rapport au paragraphe (sa hauteur est ajustée au retour).
    para_rel: bool,
}

