// Tests des schémas.

use super::*;

fn shape(x: i64, y: i64, w: i64, h: i64, extra: &str) -> String {
    format!(
        "<w:r><w:drawing><wp:anchor behindDoc=\"0\" relativeHeight=\"1\"><wp:positionH relativeFrom=\"column\"><wp:posOffset>{x}</wp:posOffset></wp:positionH><wp:positionV relativeFrom=\"paragraph\"><wp:posOffset>{y}</wp:posOffset></wp:positionV><wp:extent cx=\"{w}\" cy=\"{h}\"/><wp:wrapNone/><a:graphic><a:graphicData><wps:wsp><wps:spPr><a:prstGeom prst=\"rect\"/><a:solidFill><a:srgbClr val=\"FFCC00\"/></a:solidFill></wps:spPr>{extra}</wps:wsp></a:graphicData></a:graphic></wp:anchor></w:drawing></w:r>"
    )
}

fn doc(body: &str) -> String {
    format!("<w:document><w:body>{body}<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:left=\"1134\" w:right=\"1134\" w:top=\"1134\" w:bottom=\"1134\"/></w:sectPr></w:body></w:document>")
}

#[test]
fn neighbouring_shapes_and_boxes_become_one_kept_diagram() {
    let tb = "<wps:txbx><w:txbxContent><w:p><w:r><w:t>SUJET</w:t></w:r></w:p></w:txbxContent></wps:txbx><wps:bodyPr/>";
    let body = format!(
        "<w:p><w:r><w:t>Titre</w:t></w:r>{}{}</w:p>{}<w:p><w:r><w:t>Suite</w:t></w:r></w:p>",
        shape(0, 0, 2 * CM, CM, ""),
        shape(2 * CM, 0, 3 * CM, CM, tb),
        "<w:p/>".repeat(4)
    );
    let (out, d) = extract(&doc(&body)).unwrap();
    assert_eq!(d.len(), 1);
    assert_eq!(d[0].elems.len(), 2);
    assert!(d[0].elems.iter().any(|e| e.text.first().is_some_and(|p| p.runs[0].0 == "SUJET")));
    assert!(out.contains("⟦schéma 1⟧") && out.contains("Titre") && out.contains("Suite"));
    assert!(!out.contains("<wps:wsp"), "{out}");
    // Les paragraphes vides recouverts sont partis, et reviendront.
    assert!(out.matches("<w:p/>").count() < 4, "{out}");
    assert_eq!(d[0].keep_xml.matches("<w:p/>").count() + out.matches("<w:p/>").count(), 4);
    assert!(d[0].keep_xml.starts_with("<w:r>") && d[0].keep_xml.ends_with("<w:p>"));
}

#[test]
fn a_lone_text_box_is_not_a_diagram() {
    let tb = "<wps:txbx><w:txbxContent><w:p><w:r><w:t>Doc 1</w:t></w:r></w:p></w:txbxContent></wps:txbx>";
    let body = format!("<w:p>{}</w:p><w:p/>", shape(0, 0, 5 * CM, 3 * CM, tb).replace("<a:solidFill><a:srgbClr val=\"FFCC00\"/></a:solidFill>", "<a:noFill/>"));
    assert!(extract(&doc(&body)).is_none());
}

#[test]
fn box_texts_are_edited_in_both_variants() {
    let tb = |t: &str| format!("<w:txbxContent><w:p><w:pPr><w:jc w:val=\"center\"/></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>{t}</w:t></w:r></w:p></w:txbxContent>");
    let keep = format!(
        "<w:r><mc:AlternateContent><mc:Choice Requires=\"wps\"><w:drawing><wp:anchor><wps:wsp><wps:txbx>{}</wps:txbx></wps:wsp></wp:anchor></w:drawing></mc:Choice><mc:Fallback><w:pict><v:shape><v:textbox>{}</v:textbox></v:shape></w:pict></mc:Fallback></mc:AlternateContent></w:r></w:p><w:p/><w:p>",
        tb("SUJET"),
        tb("SUJET")
    );
    assert_eq!(box_texts(&keep), vec!["SUJET".to_string()]);
    let out = set_box_texts(&keep, &["Chihiro\nOgino".to_string()]);
    assert_eq!(box_texts(&out), vec!["Chihiro\nOgino".to_string()]);
    assert_eq!(out.matches("Ogino").count(), 2, "les deux variantes : {out}");
    assert!(out.contains("<w:b/>") && out.contains("<w:jc w:val=\"center\"/>"));
    assert!(out.ends_with("</w:p><w:p/><w:p>"));
    // Inchangé : identique.
    assert_eq!(set_box_texts(&keep, &["SUJET".to_string()]), keep);
}

