// odt.rs — OpenDocument Text (.odt) read/write for the Letters model.
// SPDX-License-Identifier: GPL-3.0-or-later
//
// Scope (first slice, PARITY #20): paragraphs, headings 1–6, inline
// bold/italic/underline/strikethrough/highlight, font size, color,
// links, alignment, flat bullet/numbered lists, page breaks, and the
// document header/footer. Fidelity is measured against the LibreOffice
// oracle (tests/soffice_oracle.rs pattern), never ported from it.

#[allow(unused_imports)]
use crate::model::*;
#[allow(unused_imports)]
use quick_xml::events::{BytesRef, BytesText, Event};
#[allow(unused_imports)]
use quick_xml::Reader;
#[allow(unused_imports)]
use std::io::Write;
#[allow(unused_imports)]
use suite_common_core::zip_guard::{BoundedArchive, ZipBudget};

mod ecriture;
mod styles;
mod tableaux;
mod lecture;
#[allow(unused_imports)]
pub use self::ecriture::*;
#[allow(unused_imports)]
pub use self::styles::*;
#[allow(unused_imports)]
pub use self::tableaux::*;
#[allow(unused_imports)]
pub use self::lecture::*;

const MIMETYPE: &str = "application/vnd.oasis.opendocument.text";

/// Read an ODT with a structured report and package parts that can be copied
/// through an unrelated edit.
pub fn read_with_report(path: &str) -> Result<(Document, suite_common_core::interop::CompatibilityReport, suite_common_core::interop::OpaquePackage), String> {
    let (document, pictures) = read_parts(path)?;
    let mut recognized = vec!["mimetype", "META-INF/manifest.xml", "content.xml", "styles.xml", "settings.xml"];
    recognized.extend(pictures.iter().map(String::as_str));
    let opaque = suite_common_core::interop::OpaquePackage::capture(path, &recognized)?;
    let mut report = suite_common_core::interop::CompatibilityReport::new("odt");
    for name in opaque.part_names() {
        report.record(suite_common_core::interop::UnsupportedFeature::new("uninterpreted-package-part", "Uninterpreted package part", name, suite_common_core::interop::FeatureDisposition::OpaquePassThrough, "will be copied through on an opaque save"));
    }
    Ok((document, report, opaque))
}

fn unescape_text(t: &BytesText) -> String {
    // quick-xml 0.42 dropped `decode()`: event payloads are already `&str`.
    quick_xml::escape::unescape(t)
        .map(|s| s.into_owned())
        .unwrap_or_else(|_| t.to_string())
}

// quick-xml 0.41 stopped inlining `&entity;`/`&#NN;` references into
// Event::Text — they now arrive as a separate Event::GeneralRef that must
// be resolved and appended alongside surrounding text, or escaped
// characters silently vanish from read documents.
fn resolve_general_ref(r: &BytesRef) -> String {
    if let Ok(Some(c)) = r.resolve_char_ref() {
        return c.to_string();
    }
    let name: &str = r;
    quick_xml::escape::resolve_predefined_entity(name)
        .map(|s| s.to_string())
        .unwrap_or_else(|| format!("&{name};"))
}

// ── XML helpers ──────────────────────────────────────────────────────

fn esc(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}

// ── Writing ──────────────────────────────────────────────────────────

/// An ODF length ("2.5cm", "1in", "72pt", "10mm", "6pc", "96px") in EMU.
fn length_emu(s: &str) -> Option<u64> {
    let s = s.trim();
    let split = s.find(|c: char| c.is_ascii_alphabetic())?;
    let (n, unit) = s.split_at(split);
    let n: f64 = n.trim().parse().ok()?;
    let inches = match unit {
        "in" => n,
        "cm" => n / 2.54,
        "mm" => n / 25.4,
        "pt" => n / 72.0,
        "pc" => n / 6.0,
        "px" => n / 96.0,
        _ => return None,
    };
    (inches > 0.0).then(|| (inches * EMU_PER_INCH).round() as u64)
}

/// Prefix of a chip content control's tag.
const CHIP_NAME_PREFIX: &str = "letters-chip:";

/// The chip a content control's tag stands for.
fn chip_from_name(name: &str) -> Option<crate::chips::Chip> {
    use crate::chips::{Chip, ChipKind};
    let (kind, value) = name.strip_prefix(CHIP_NAME_PREFIX)?.split_once(':')?;
    let kind = match kind {
        "date" => ChipKind::Date,
        "link" => ChipKind::Link,
        "person" => ChipKind::Person,
        _ => return None,
    };
    Some(Chip { kind, value: value.to_string() })
}

fn attr_val(e: &quick_xml::events::BytesStart, name: &str) -> Option<String> {
    e.attributes().filter_map(|a| a.ok()).find_map(|a| {
        if a.key.into_inner() == name {
            // Attribute values are escaped XML too: a link to "?a=1&b=2"
            // is written "&amp;" and read back as "&amp;" without this.
            let raw = a.value.to_string();
            Some(quick_xml::escape::unescape(&raw).map(|s| s.into_owned()).unwrap_or(raw))
        } else {
            None
        }
    })
}

/// Parse an ODF length ("595.3pt", "21cm", "210mm", "8.5in") to points.
fn parse_length_pt(v: &str) -> Option<f64> {
    let v = v.trim();
    let (num, unit) = v.split_at(v.find(|c: char| c.is_ascii_alphabetic())?);
    let n: f64 = num.parse().ok()?;
    Some(match unit {
        "pt" => n,
        "cm" => n * 72.0 / 2.54,
        "mm" => n * 72.0 / 25.4,
        "in" => n * 72.0,
        _ => return None,
    })
}


#[cfg(test)]
mod tests;

