// Tests de docx (lecture, écriture, allers-retours).

/// 31 nested tables, inside rdocx's own cap of 32, read on whichever
/// thread asks: on a 2 MiB test thread they overflowed the stack before
/// the read moved to its own. Deeper, up to [`super::MAX_XML_DEPTH`],
/// is refused by rdocx rather than crashing, and one level past it is
/// refused unread (#1206).
/// A docx Letters wrote, with `body` in place of its `w:body`'s content.
fn docx_with_body(dir: &std::path::Path, body: &str, name: &str) -> std::path::PathBuf {
    use std::io::{Read, Write};
    let base = dir.join("base.docx");
    if !base.exists() {
        super::write(&Document::from_plain_text("x"), &base).unwrap();
    }
    let xml = format!(
        "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>{body}</w:body></w:document>"
    );
    let mut source = zip::ZipArchive::new(std::fs::File::open(&base).unwrap()).unwrap();
    let path = dir.join(name);
    let mut writer = zip::ZipWriter::new(std::fs::File::create(&path).unwrap());
    for i in 0..source.len() {
        let mut entry = source.by_index(i).unwrap();
        let entry_name = entry.name().to_string();
        let mut bytes = Vec::new();
        entry.read_to_end(&mut bytes).unwrap();
        if entry_name == "word/document.xml" {
            bytes = xml.clone().into_bytes();
        }
        writer.start_file(entry_name, zip::write::SimpleFileOptions::default()).unwrap();
        writer.write_all(&bytes).unwrap();
    }
    writer.finish().unwrap();
    path
}

fn para(text: &str) -> String {
    format!("<w:p><w:r><w:t>{text}</w:t></w:r></w:p>")
}

/// Samizdat : un cartouche garde son allure, et un texte ses lignes
/// numérotées, d'un enregistrement à la relecture.
#[test]
fn cartouche_and_line_numbers_round_trip() {
    use crate::model::{Cartouche, CartoucheLine, Paragraph, Run, TableCell};
    let dir = tempfile::tempdir().unwrap();
    let path = dir.path().join("c.docx");
    let mut doc = Document::new();
    doc.footer = Some("BAC Blanc\t{page} sur {total}\tLP Amédée Gasquet\nSeconde ligne".into());
    doc.header = Some("\tEn-tête centré".into());
    let look = Cartouche { square: true, line: CartoucheLine::None, white: true };
    let p = |text: &str, f: &dyn Fn(&mut ParaStyle)| {
        let mut para = Paragraph { style: ParaStyle::default(), runs: vec![Run::plain(text)] };
        f(&mut para.style);
        para
    };
    doc.paragraphs = vec![
        p("Titre", &|_| {}),
        p("Ligne un", &|s| s.line_numbers = true),
        p("Ligne deux", &|s| { s.line_numbers = true; s.heading = None; s.alignment = Alignment::Center; }),
        p("Dans le cartouche", &|s| { s.table_cell = Some(TableCell { table: 0, row: 0, col: 0, ..Default::default() }); s.cartouche = Some(look); }),
        p("Après", &|_| {}),
        p("Ligne A\u{2028}Ligne B", &|s| { s.table_cell = Some(TableCell { table: 1, row: 0, col: 0, ..Default::default() }); }),
        p("Fin", &|_| {}),
    ];
    // Une image et son texte de remplacement (une frise y garde ses données).
    let png = dir.path().join("i.png");
    std::fs::write(&png, [
        0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0, 0, 0, 0x0D, 0x49, 0x48, 0x44, 0x52, 0, 0, 0, 1, 0, 0, 0, 1, 8, 6, 0, 0, 0, 0x1F, 0x15, 0xC4,
        0x89, 0, 0, 0, 0x0A, 0x49, 0x44, 0x41, 0x54, 0x78, 0x9C, 0x63, 0, 1, 0, 0, 5, 0, 1, 0x0D, 0x0A, 0x2D, 0xB4, 0, 0, 0, 0, 0x49, 0x45, 0x4E, 0x44, 0xAE,
        0x42, 0x60, 0x82,
    ]).unwrap();
    let mut img = Run::plain("Frise chronologique — Titre | 1914 : « début »");
    img.style.image = Some(png.to_string_lossy().to_string());
    img.style.image_extent_emu = Some((360000, 360000));
    doc.paragraphs.push(Paragraph { style: ParaStyle::default(), runs: vec![img] });
    super::write(&doc, &path).unwrap();
    let xml = {
        let mut z = zip::ZipArchive::new(std::fs::File::open(&path).unwrap()).unwrap();
        let mut x = String::new();
        std::io::Read::read_to_string(&mut z.by_name("word/document.xml").unwrap(), &mut x).unwrap();
        x
    };
    assert!(!xml.contains("samizdat-lignes"), "{xml}");
    assert!(xml.contains("w:lnNumType"), "{xml}");
    let back = super::read(path.to_str().unwrap()).unwrap();
    let numbered: Vec<String> = back.paragraphs.iter().filter(|p| p.style.line_numbers).map(|p| p.text()).collect();
    assert_eq!(numbered, ["Ligne un", "Ligne deux"]);
    let boxed = back.paragraphs.iter().find(|p| p.text() == "Dans le cartouche").unwrap();
    assert_eq!(boxed.style.cartouche, Some(look));
    assert_eq!(back.footer, doc.footer);
    assert_eq!(back.header, doc.header);
    assert!(back.paragraphs.iter().any(|p| p.text() == "Ligne A\u{2028}Ligne B"), "{:?}", back.paragraphs.iter().map(|p| p.text()).collect::<Vec<_>>());
    let alt = back.paragraphs.iter().flat_map(|p| &p.runs).find(|r| r.style.image.is_some()).map(|r| r.text.clone());
    assert_eq!(alt.as_deref(), Some("Frise chronologique — Titre | 1914 : « début »"));
}

/// A table nested in a cell keeps its text, in its outer cell, in
/// document order (#1419): its two cells used to be dropped.
#[test]
fn a_nested_tables_text_is_read_into_its_outer_cell() {
    let dir = tempfile::tempdir().unwrap();
    let body = format!(
        "{}<w:tbl><w:tr><w:tc>{}<w:tbl><w:tr><w:tc>{}</w:tc><w:tc>{}</w:tc></w:tr></w:tbl>{}</w:tc><w:tc>{}</w:tc></w:tr></w:tbl>{}",
        para("before"), para("outer A"), para("inner one"), para("inner two"), para("outer A, after"), para("outer B"), para("after")
    );
    let path = docx_with_body(dir.path(), &body, "nested.docx");
    let doc = super::read(path.to_str().unwrap()).unwrap();
    let cell = |row, col| -> Vec<String> {
        doc.paragraphs
            .iter()
            .filter(|p| p.style.table_cell.is_some_and(|c| (c.table, c.row, c.col) == (0, row, col)))
            .map(|p| p.text())
            .collect()
    };
    assert_eq!(cell(0, 0), ["outer A", "inner one", "inner two", "outer A, after"]);
    assert_eq!(cell(0, 1), ["outer B"]);
}

/// 31 nested tables, inside rdocx's own cap of 32, read on whichever
/// thread asks: on a 2 MiB test thread they overflowed the stack before
/// the read moved to its own. Deeper, up to [`super::MAX_XML_DEPTH`],
/// is refused by rdocx rather than crashing, and one level past it is
/// refused unread (#1206).
#[test]
fn nesting_is_read_up_to_the_limit_and_refused_past_it() {
    let dir = tempfile::tempdir().unwrap();
    let with_tables = |levels: usize, name: &str| {
        let body = format!(
            "{}<w:p><w:r><w:t>x</w:t></w:r></w:p>{}",
            "<w:tbl><w:tr><w:tc>".repeat(levels),
            "</w:tc></w:tr></w:tbl>".repeat(levels)
        );
        docx_with_body(dir.path(), &body, name)
    };
    let nested = with_tables(31, "nested.docx");
    let doc = super::read(nested.to_str().unwrap()).expect("31 nested tables read");
    // The innermost cell's text, in the outermost cell (#1419).
    let texts: Vec<String> = doc.paragraphs.iter().filter(|p| p.style.table_cell.is_some()).map(|p| p.text()).collect();
    assert_eq!(texts, ["x"]);

    // Three elements a level, between <w:document><w:body> and the
    // innermost cell's <w:p><w:r><w:t>.
    let deepest = (super::MAX_XML_DEPTH - 5) / 3;
    let inside = with_tables(deepest, "inside.docx");
    if let Err(error) = super::read(inside.to_str().unwrap()) {
        assert!(!error.contains("nests its elements"), "refused inside the limit: {error}");
    }
    let past = with_tables(deepest + 1, "past.docx");
    let error = super::read(past.to_str().unwrap()).expect_err("a docx past the limit is refused");
    assert!(error.contains("nests its elements"), "{error}");
}

use super::*;
use crate::model::{Paragraph, Run, RunStyle};

// ── style_id_to_heading ───────────────────────────────────────────────────

#[test]
fn style_id_heading_1_to_6_parse() {
    assert_eq!(style_id_to_heading("Heading1"), Some(1));
    assert_eq!(style_id_to_heading("Heading3"), Some(3));
    assert_eq!(style_id_to_heading("Heading6"), Some(6));
}

#[test]
fn style_id_heading_out_of_range_is_none() {
    assert_eq!(style_id_to_heading("Heading0"), None);
    assert_eq!(style_id_to_heading("Heading7"), None);
}

#[test]
fn style_id_heading_non_numeric_or_malformed_is_none() {
    assert_eq!(style_id_to_heading("HeadingX"), None);
    assert_eq!(style_id_to_heading("heading1"), None);
    assert_eq!(style_id_to_heading("Subtitle"), None);
}

// ── normalize ─────────────────────────────────────────────────────────────

fn para_with(runs: Vec<Run>) -> Paragraph {
    Paragraph { style: Default::default(), runs }
}

fn run(text: &str, style: RunStyle) -> Run {
    Run { text: text.to_string(), style }
}

#[test]
fn normalize_merges_adjacent_runs_with_same_style() {
    let mut p = para_with(vec![
        run("foo", RunStyle::default()),
        run("bar", RunStyle::default()),
    ]);
    normalize(&mut p);
    assert_eq!(p.runs.len(), 1);
    assert_eq!(p.runs[0].text, "foobar");
}

#[test]
fn normalize_keeps_runs_with_different_styles() {
    let mut p = para_with(vec![
        run("foo", RunStyle { bold: true, ..Default::default() }),
        run("bar", RunStyle::default()),
    ]);
    normalize(&mut p);
    assert_eq!(p.runs.len(), 2);
}

#[test]
fn normalize_drops_empty_runs() {
    let mut p = para_with(vec![
        run("", RunStyle::default()),
        run("kept", RunStyle::default()),
    ]);
    normalize(&mut p);
    assert_eq!(p.runs.len(), 1);
    assert_eq!(p.runs[0].text, "kept");
}

#[test]
fn normalize_does_not_merge_footnote_runs() {
    let mut p = para_with(vec![
        run("a", RunStyle { footnote: Some(0), ..Default::default() }),
        run("b", RunStyle::default()),
    ]);
    normalize(&mut p);
    assert_eq!(p.runs.len(), 2);
}
