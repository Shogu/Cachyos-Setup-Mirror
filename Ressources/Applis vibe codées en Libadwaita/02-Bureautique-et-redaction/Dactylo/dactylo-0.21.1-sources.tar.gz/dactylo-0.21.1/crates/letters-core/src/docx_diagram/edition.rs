// Modifier un schéma gardé : le texte de ses cases.
// SPDX-License-Identifier: GPL-3.0-or-later

use super::*;

/// La partie « run » d'un schéma gardé (`Diagram::keep_xml`) : ses formes.
pub(super) fn keep_run(keep_xml: &str) -> &str {
    match matching_close(keep_xml, "w:r", 0) {
        Some(e) => &keep_xml[..e],
        None => keep_xml,
    }
}

/// Les zones de texte du schéma, dans l'ordre : pour chacune, l'emplacement
/// (intérieur de `w:txbxContent`) dans la variante DrawingML et, s'il y en
/// a une, dans la variante de secours VML.
pub(super) fn box_slots(run: &str) -> Vec<((usize, usize), Option<(usize, usize)>)> {
    let inner_ranges = |xml: &str, base: usize| -> Vec<(usize, usize)> {
        let mut v = Vec::new();
        let mut at = 0;
        while let Some(s) = find_open(xml, "w:txbxContent", at) {
            let Some(e) = matching_close(xml, "w:txbxContent", s) else { break };
            let open_end = s + xml[s..].find('>').unwrap_or(0) + 1;
            let close = e - "</w:txbxContent>".len();
            v.push((base + open_end, base + close));
            at = e;
        }
        v
    };
    let mut out = Vec::new();
    let mut at = 0;
    loop {
        let next = ["mc:AlternateContent", "w:drawing"].iter().filter_map(|n| find_open(run, n, at).map(|i| (i, *n))).min();
        let Some((bs, name)) = next else { break };
        let Some(be) = matching_close(run, name, bs) else { break };
        at = be;
        let block = &run[bs..be];
        let (choice, fallback) = if name == "mc:AlternateContent" {
            let c = find_open(block, "mc:Choice", 0).and_then(|s| matching_close(block, "mc:Choice", s).map(|e| (s, e)));
            let f = find_open(block, "mc:Fallback", 0).and_then(|s| matching_close(block, "mc:Fallback", s).map(|e| (s, e)));
            (c.unwrap_or((0, block.len())), f)
        } else {
            ((0, block.len()), None)
        };
        let cs = inner_ranges(&block[choice.0..choice.1], bs + choice.0);
        let fs = fallback.map(|f| inner_ranges(&block[f.0..f.1], bs + f.0)).unwrap_or_default();
        let same = fs.len() == cs.len();
        for (i, c) in cs.into_iter().enumerate() {
            out.push((c, if same { Some(fs[i]) } else { None }));
        }
    }
    out
}

/// Le texte d'une zone (`w:txbxContent` intérieur) : une ligne par
/// paragraphe.
pub(super) fn box_text(content: &str) -> String {
    text_paras(&format!("<w:txbxContent>{content}</w:txbxContent>"))
        .iter()
        .map(|p| p.runs.iter().map(|r| r.0.as_str()).collect::<String>())
        .collect::<Vec<_>>()
        .join("\n")
}

/// Le texte de chaque case du schéma gardé (une ligne par paragraphe).
pub fn box_texts(keep_xml: &str) -> Vec<String> {
    let run = keep_run(keep_xml);
    box_slots(run).iter().map(|((s, e), _)| box_text(&run[*s..*e])).collect()
}

pub(super) fn escape(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;")
}

/// Le contenu d'une zone réécrit avec `text` : un paragraphe par ligne,
/// chacun avec la mise en forme du paragraphe d'origine de même rang (le
/// dernier pour les lignes en plus) et de son premier morceau de texte.
pub(super) fn rewrite_box(content: &str, text: &str) -> String {
    let mut paras: Vec<&str> = Vec::new();
    let mut at = 0;
    while let Some(s) = find_open(content, "w:p", at) {
        let Some(e) = matching_close(content, "w:p", s) else { break };
        paras.push(&content[s..e]);
        at = e;
    }
    let mut out = String::new();
    for (i, line) in text.split('\n').enumerate() {
        let model = paras.get(i.min(paras.len().saturating_sub(1))).copied().unwrap_or("");
        let ppr = element(model, "w:pPr").unwrap_or("");
        let rpr = element(model, "w:r").and_then(|r| element(r, "w:rPr")).unwrap_or("");
        if line.is_empty() {
            out.push_str(&format!("<w:p>{ppr}</w:p>"));
        } else {
            out.push_str(&format!("<w:p>{ppr}<w:r>{rpr}<w:t xml:space=\"preserve\">{}</w:t></w:r></w:p>", escape(line)));
        }
    }
    out
}

/// Le schéma gardé avec le nouveau texte de ses cases (`texts`, dans
/// l'ordre de `box_texts`). Une case inchangée garde son XML d'origine.
pub fn set_box_texts(keep_xml: &str, texts: &[String]) -> String {
    let run_len = keep_run(keep_xml).len();
    let run = &keep_xml[..run_len];
    let mut edits: Vec<(usize, usize, String)> = Vec::new();
    for (i, (c, f)) in box_slots(run).into_iter().enumerate() {
        let Some(new) = texts.get(i) else { continue };
        let old = &run[c.0..c.1];
        if &box_text(old) == new {
            continue;
        }
        edits.push((c.0, c.1, rewrite_box(old, new)));
        if let Some(f) = f {
            edits.push((f.0, f.1, rewrite_box(&run[f.0..f.1], new)));
        }
    }
    edits.sort_by_key(|e| e.0);
    let mut out = String::with_capacity(keep_xml.len());
    let mut at = 0;
    for (s, e, t) in edits {
        out.push_str(&keep_xml[at..s]);
        out.push_str(&t);
        at = e;
    }
    out.push_str(&keep_xml[at..]);
    out
}

/// Le schéma gardé redessiné (après une modification) : l'image PNG, sa
/// largeur et sa hauteur en points.
#[cfg(feature = "render")]
pub fn render_kept(k: &crate::model::Keepsake) -> Option<(Vec<u8>, f64, f64)> {
    let run = keep_run(&k.xml);
    let wrapped = format!("<w:p>{run}</w:p>");
    let blocks = blocks_of(&wrapped, 0, wrapped.len(), 0, 0, 0, (0, 0), 9638 * 635);
    let elems: Vec<Elem> = blocks.into_iter().flat_map(|b| b.elems).collect();
    let d = Diagram { label: k.label.clone(), keep_xml: k.xml.clone(), elems };
    let image = |id: &str| -> Option<Vec<u8>> {
        let (_, _, target, _) = k.rels.iter().find(|r| r.0 == id)?;
        let name = target.rsplit('/').next()?;
        k.parts.iter().find(|p| p.path.ends_with(&format!("/{name}")) || p.path == *target).map(|p| p.data.clone())
    };
    render(&d, &image)
}

