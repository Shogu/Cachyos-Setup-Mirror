// Tests de odt (lecture, écriture, allers-retours).

/// Samizdat : cartouche et lignes numérotées, aller et retour en .odt.
#[test]
fn samizdat_cartouche_and_line_numbers_round_trip() {
    use crate::model::{Cartouche, CartoucheLine, Paragraph, Run, TableCell};
    let dir = tempfile::tempdir().unwrap();
    let path = dir.path().join("c.odt");
    let mut doc = Document::new();
    doc.footer = Some("BAC Blanc\t{page} sur {total}\tLP\nSeconde ligne".into());
    let look = Cartouche { square: false, line: CartoucheLine::Thick, white: false };
    let mk = |text: &str, n: bool, cell: bool| {
        let mut para = Paragraph { style: ParaStyle::default(), runs: vec![Run::plain(text)] };
        para.style.line_numbers = n;
        if cell {
            para.style.table_cell = Some(TableCell { table: 0, row: 0, col: 0, ..Default::default() });
            para.style.cartouche = Some(look);
        }
        para
    };
    doc.paragraphs = vec![mk("Titre", false, false), mk("Un", true, false), mk("Deux", true, false), mk("Case", false, true), mk("Fin", false, false), mk("A\u{2028}B", false, false)];
    super::write(&doc, &path).unwrap();
    let back = super::read(path.to_str().unwrap()).unwrap();
    let numbered: Vec<String> = back.paragraphs.iter().filter(|p| p.style.line_numbers).map(|p| p.text()).collect();
    assert_eq!(numbered, ["Un", "Deux"]);
    assert_eq!(back.paragraphs.iter().find(|p| p.text() == "Case").unwrap().style.cartouche, Some(look));
    assert!(back.paragraphs.iter().any(|p| p.text() == "A\u{2028}B"));
    assert_eq!(back.footer, doc.footer);
}

use super::*;

/// A 3x2 red PNG.
const PNG: [u8; 78] = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d, 0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x02, 0x08, 0x02, 0x00, 0x00, 0x00, 0x12, 0x16, 0xf1, 0x4d, 0x00, 0x00, 0x00, 0x15, 0x49, 0x44, 0x41, 0x54, 0x78, 0x9c, 0x63, 0x3c, 0x21, 0x27, 0xc7, 0xc0, 0xc0, 0xc0, 0xc0, 0xc0, 0xc0, 0xc4, 0x00, 0x03, 0x00, 0x13, 0x2e, 0x01, 0x08, 0x6a, 0xc0, 0x65, 0x61, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82];

/// Pictures are written as frames with their bytes in Pictures/ and
/// read back in place, with their size and alt text (#1292). They used
/// to be dropped on every save.
#[test]
fn pictures_round_trip_in_place_with_size_and_alt_text() {
    let dir = tempfile::tempdir().unwrap();
    let src = dir.path().join("red.png");
    std::fs::write(&src, PNG).unwrap();
    let image = |extent| Run {
        text: "A red square".into(),
        style: RunStyle { image: Some(src.to_string_lossy().into_owned()), image_extent_emu: extent, ..Default::default() },
    };
    let mut d = Document::from_plain_text("");
    d.paragraphs = vec![
        Paragraph { style: ParaStyle::default(), runs: vec![Run::plain("before "), image(Some((914_400, 457_200))), Run::plain(" after")] },
        // No size: the PNG's own 3x2 pixels at 96 dpi.
        Paragraph { style: ParaStyle::default(), runs: vec![image(None)] },
        // The same picture again is stored once.
        Paragraph { style: ParaStyle::default(), runs: vec![image(Some((914_400, 457_200)))] },
    ];
    let out = dir.path().join("pics.odt");
    write(&d, &out).unwrap();

    let mut zip = zip::ZipArchive::new(std::fs::File::open(&out).unwrap()).unwrap();
    let members: Vec<String> = zip.file_names().filter(|n| n.starts_with("Pictures/")).map(str::to_string).collect();
    assert_eq!(members.len(), 1, "one picture used three times is stored once: {members:?}");
    let mut manifest = String::new();
    std::io::Read::read_to_string(&mut zip.by_name("META-INF/manifest.xml").unwrap(), &mut manifest).unwrap();
    assert!(manifest.contains(&format!("manifest:full-path=\"{}\" manifest:media-type=\"image/png\"", members[0])), "{manifest}");

    let (rt, _, opaque) = read_with_report(out.to_str().unwrap()).unwrap();
    let pics: Vec<&Run> = rt.paragraphs.iter().flat_map(|p| &p.runs).filter(|r| r.style.image.is_some()).collect();
    assert_eq!(pics.len(), 3);
    for r in &pics {
        assert_eq!(std::fs::read(r.style.image.as_ref().unwrap()).unwrap(), PNG, "the picture's bytes");
        assert_eq!(r.text, "A red square", "alt text");
    }
    assert_eq!(pics[0].style.image_extent_emu, Some((914_400, 457_200)));
    assert_eq!(pics[1].style.image_extent_emu, Some((3 * 9525, 2 * 9525)));
    let first: Vec<&str> = rt.paragraphs[0].runs.iter().map(|r| if r.style.image.is_some() { "[pic]" } else { r.text.as_str() }).collect();
    assert_eq!(first, ["before ", "[pic]", " after"], "the picture stays where it is in the line");
    assert!(opaque.is_empty(), "a picture we read is not an opaque part: {:?}", opaque.part_names().collect::<Vec<_>>());
}

/// Tables cross as tables (#1296): every cell in its grid position, an
/// empty cell included, a cell of two paragraphs, run styling inside a
/// cell, the text around the table, and a second table straight after.
#[test]
fn tables_round_trip_cell_by_cell() {
    let cell = |table, row, col, text: &str| Paragraph {
        style: ParaStyle { table_cell: Some(crate::model::TableCell::at(table, row, col)), ..Default::default() },
        runs: if text.is_empty() { Vec::new() } else { vec![Run::plain(text)] },
    };
    let mut bold = cell(0, 1, 2, "");
    bold.runs = vec![Run { text: "bold total".into(), style: RunStyle { bold: true, ..Default::default() } }];
    let mut d = Document::from_plain_text("before");
    d.paragraphs.extend([
        cell(0, 0, 0, "a1"), cell(0, 0, 1, "b1"), cell(0, 0, 2, "c1"),
        cell(0, 1, 0, "a2 first"), cell(0, 1, 0, "a2 second"), cell(0, 1, 1, ""), bold,
        cell(1, 0, 0, "second table"), cell(1, 0, 1, "x"),
    ]);
    d.paragraphs.push(Paragraph { style: ParaStyle::default(), runs: vec![Run::plain("after")] });
    let rt = round_trip(&d);
    type Shape = Vec<(Option<(u32, u32, u32)>, String, bool)>;
    let shape = |doc: &Document| -> Shape {
        doc.paragraphs.iter().map(|p| (p.style.table_cell.map(|c| (c.table, c.row, c.col)), p.text(), p.runs.iter().any(|r| r.style.bold))).collect()
    };
    assert_eq!(shape(&rt), shape(&d));
}

/// How headings look crosses an odt save (#1297): it used to be lost,
/// so every heading reopened in Letters' default look.
#[test]
fn heading_looks_round_trip() {
    let mut d = Document::from_plain_text("Title\nbody");
    d.paragraphs[0].style.heading = Some(1);
    d.heading_styles = (1..=6)
        .map(|n| RunStyle { bold: n == 1, italic: n == 2, color: Some("c00000".into()), font_size_hp: Some(48 - 4 * n), font_family: Some("DejaVu Serif".into()), ..Default::default() })
        .collect();
    let rt = round_trip(&d);
    assert_eq!(rt.heading_styles, d.heading_styles);
    assert_eq!(rt.paragraphs[0].style.heading, Some(1));
}

/// An image whose file has gone is written as its alt text, as docx does.
#[test]
fn an_unreadable_picture_is_written_as_its_alt_text() {
    let dir = tempfile::tempdir().unwrap();
    let mut d = Document::from_plain_text("");
    d.paragraphs = vec![Paragraph {
        style: ParaStyle::default(),
        runs: vec![Run { text: "missing chart".into(), style: RunStyle { image: Some("/nonexistent/x.png".into()), ..Default::default() } }],
    }];
    let out = dir.path().join("gone.odt");
    write(&d, &out).unwrap();
    let rt = read(out.to_str().unwrap()).unwrap();
    assert_eq!(rt.paragraphs[0].text(), "missing chart");
    assert!(rt.paragraphs[0].runs.iter().all(|r| r.style.image.is_none()));
}

fn round_trip(doc: &Document) -> Document {
    let dir = tempfile::tempdir().unwrap();
    let path = dir.path().join("t.odt");
    write(doc, path.to_str().unwrap()).expect("write odt");
    read(path.to_str().unwrap()).expect("read odt")
}

/// Smart chips reopen as chips: a date is a fixed `text:date`, a link
/// or person chip a named `text:a` (a name-only person a bookmark).
#[test]
fn smart_chips_survive() {
    let d = crate::chips::sample_document();
    let rt = round_trip(&d);
    assert_eq!(rt.paragraphs[0].runs, d.paragraphs[0].runs);
}

/// Tracked changes reopen as they were, deleted text included (ODF keeps
/// it in the change region, not the body), and a deletion of someone
/// else's insertion too.
#[test]
fn tracked_changes_survive() {
    let d = crate::track::sample_document();
    let rt = round_trip(&d);
    assert_eq!(rt.paragraphs[0].runs, d.paragraphs[0].runs);
}

/// A table of contents is LibreOffice's index, and reopens as the same
/// entries; a tab is written as an ODF tab, which a raw tab is not.
#[test]
fn a_table_of_contents_and_tabs_survive() {
    let mut d = crate::toc::sample_document();
    d.paragraphs[5].runs = vec![Run::plain("Why\tit matters.")];
    let rt = round_trip(&d);
    let entries = |d: &Document| crate::toc::blocks(d).into_iter().flat_map(|b| d.paragraphs[b].to_vec()).collect::<Vec<_>>();
    assert_eq!(entries(&rt), entries(&d));
    assert_eq!(rt.paragraphs[5].text(), "Why\tit matters.");
    assert_eq!(rt.paragraphs.len(), d.paragraphs.len());
}

/// Comments reopen as they were: overlapping annotations, a reply in
/// its thread, a resolved thread, one of two lines, and one whose text
/// was deleted (an annotation without an end).
#[test]
fn comments_survive() {
    let mut d = crate::comments::sample_document();
    let (ops, _) = crate::comments::add(&d, 0, 3, "Ada Lovelace", "2026-09-26T11:00:00Z", "Two lines\nof comment").unwrap();
    crate::edit::apply_all(&mut d, &ops).unwrap();
    crate::edit::apply_all(&mut d, &[crate::edit::Op::Delete { at: 0, len: 3 }]).unwrap();
    let rt = round_trip(&d);
    assert_eq!(crate::comments::threads(&rt), crate::comments::threads(&d));
    assert_eq!(rt.paragraphs, d.paragraphs);
}

/// An .odt made of these `content.xml` and `styles.xml`, read.
fn read_package(content: &str, styles: &str) -> Document {
    let dir = tempfile::tempdir().unwrap();
    let path = dir.path().join("t.odt");
    let mut out = zip::ZipWriter::new(std::fs::File::create(&path).unwrap());
    for (name, data) in [("mimetype", "application/vnd.oasis.opendocument.text"), ("content.xml", content), ("styles.xml", styles)] {
        out.start_file(name, zip::write::SimpleFileOptions::default()).unwrap();
        out.write_all(data.as_bytes()).unwrap();
    }
    out.finish().unwrap();
    read(path.to_str().unwrap()).unwrap()
}

/// How Writer resolves a paragraph's look, as LibreOffice's own files
/// rely on it: text written straight into a paragraph takes the
/// paragraph style's text properties (a title in a bold 12pt
/// paragraph style is bold 12pt), a span adds its own over them, a
/// paragraph's space after and line height come from its parent
/// "Standard" style when its own style leaves them unset, and the body
/// font is the default style's, named by its font face. All four were
/// lost: a Calibri agenda opened in the serif fallback with a plain
/// title and tight table rows.
#[test]
fn paragraph_and_default_styles_are_inherited() {
    let content = "<office:document-content><office:automatic-styles>\
        <style:style style:name=\"P1\" style:parent-style-name=\"Standard\" style:family=\"paragraph\">\
          <style:paragraph-properties fo:text-align=\"center\" fo:margin-bottom=\"0in\"/>\
          <style:text-properties fo:font-weight=\"bold\" fo:font-size=\"12pt\"/></style:style>\
        <style:style style:name=\"P2\" style:parent-style-name=\"Standard\" style:family=\"paragraph\">\
          <style:paragraph-properties fo:text-align=\"center\"/></style:style>\
        <style:style style:name=\"T1\" style:family=\"text\"><style:text-properties fo:font-style=\"italic\"/></style:style>\
        </office:automatic-styles><office:body><office:text>\
        <text:p text:style-name=\"P1\">Title <text:span text:style-name=\"T1\">and more</text:span></text:p>\
        <text:p text:style-name=\"P2\">body</text:p>\
        </office:text></office:body></office:document-content>";
    let styles = "<office:document-styles><office:font-face-decls>\
        <style:font-face style:name=\"Calibri\" svg:font-family=\"Calibri\"/></office:font-face-decls><office:styles>\
        <style:default-style style:family=\"paragraph\"><style:text-properties style:font-name=\"Calibri\" fo:font-size=\"11pt\"/></style:default-style>\
        <style:style style:name=\"Standard\" style:family=\"paragraph\"><style:paragraph-properties fo:margin-bottom=\"0.1111in\" fo:line-height=\"103%\"/></style:style>\
        </office:styles></office:document-styles>";
    let d = read_package(content, styles);
    assert_eq!((d.base_font.family.as_deref(), d.base_font.size_hp), (Some("Calibri"), Some(22)));
    let title = &d.paragraphs[0];
    let runs: Vec<(&str, bool, bool, Option<u16>)> = title.runs.iter().map(|r| (r.text.as_str(), r.style.bold, r.style.italic, r.style.font_size_hp)).collect();
    assert_eq!(runs, [("Title ", true, false, Some(24)), ("and more", true, true, Some(24))]);
    assert_eq!(title.style.space_after_pt, 0.0, "its own style's zero wins over Standard's");
    let body = &d.paragraphs[1];
    assert!((body.style.space_after_pt - 8.0).abs() < 0.01, "Standard's space after: {}", body.style.space_after_pt);
    assert!((body.style.line_spacing - 1.03).abs() < 1e-4, "Standard's line height: {}", body.style.line_spacing);
    assert!(!body.runs[0].style.bold, "a paragraph style's text properties stay in its paragraph");
}

/// A standard ODF date field from another application opens as a date
/// chip, keeping the text it shows.
#[test]
fn a_date_field_opens_as_a_date_chip() {
    let dir = tempfile::tempdir().unwrap();
    let ours = dir.path().join("ours.odt");
    write(&Document::from_plain_text("Due MARK."), ours.to_str().unwrap()).unwrap();
    // The same package, with a date field where MARK was.
    let theirs = dir.path().join("theirs.odt");
    let mut zin = zip::ZipArchive::new(std::fs::File::open(&ours).unwrap()).unwrap();
    let mut out = zip::ZipWriter::new(std::fs::File::create(&theirs).unwrap());
    for i in 0..zin.len() {
        let mut f = zin.by_index(i).unwrap();
        let name = f.name().to_string();
        let mut data = String::new();
        std::io::Read::read_to_string(&mut f, &mut data).unwrap();
        if name == "content.xml" {
            data = data.replace(
                "MARK",
                "<text:date style:data-style-name=\"N37\" text:date-value=\"2025-01-31T00:00:00\">31/01/2025</text:date>",
            );
        }
        out.start_file(name, zip::write::SimpleFileOptions::default()).unwrap();
        out.write_all(data.as_bytes()).unwrap();
    }
    out.finish().unwrap();
    let rt = read(theirs.to_str().unwrap()).unwrap();
    let chip = rt.paragraphs[0].runs.iter().find(|r| r.style.chip.is_some()).expect("a chip");
    assert_eq!(chip.text, "31/01/2025");
    assert_eq!(chip.style.chip.as_ref().unwrap().value, "2025-01-31");
}

/// A section's column count, which lives in content.xml.
///
/// LibreOffice models a docx `w:cols` as an ODF section rather than a
/// page-wide layout, so this is the shape a converted file arrives
/// in. The gap is optional: a section may state a count alone.
#[test]
fn section_columns_are_read_from_content() {
    let xml = "<office:document-content><office:automatic-styles>\
               <style:style style:name=\"Sect1\" style:family=\"section\">\
               <style:section-properties style:editable=\"false\">\
               <style:columns fo:column-count=\"2\" fo:column-gap=\"0.3335in\"/>\
               </style:section-properties></style:style>\
               </office:automatic-styles></office:document-content>";
    let (count, gap) = parse_section_columns(xml).expect("section columns");
    assert_eq!(count, 2);
    assert!((gap.expect("gap") - 24.0).abs() < 0.1, "gap: {gap:?}");
}

/// One column is not a column layout, and must not displace the page's.
#[test]
fn a_single_column_section_is_not_a_column_layout() {
    let xml = "<office:document-content>\
               <style:section-properties>\
               <style:columns fo:column-count=\"1\"/>\
               </style:section-properties></office:document-content>";
    assert!(parse_section_columns(xml).is_none());
}

/// `style:columns` outside a section is the page's, read elsewhere.
#[test]
fn page_layout_columns_are_not_mistaken_for_a_section() {
    let xml = "<office:document-styles><style:page-layout-properties>\
               <style:columns fo:column-count=\"3\"/>\
               </style:page-layout-properties></office:document-styles>";
    assert!(parse_section_columns(xml).is_none());
}

/// Footnotes, which ODF nests inside the referencing paragraph.
///
/// The writer and reader both ignored `text:note` entirely, so a
/// footnote's text — authored content, not layout — was dropped on
/// every odt save. The body paragraph must come back unchanged too:
/// the note's own `text:p` children are nested *inside* it, so a
/// reader that treats them as body text either splits the paragraph
/// or pulls the footnote into it.
#[test]
fn footnotes_survive() {
    let mut d = Document::from_plain_text("");
    d.footnotes = vec!["the note text".to_string()];
    d.paragraphs[0] = Paragraph {
        style: ParaStyle::default(),
        runs: vec![
            Run::plain("body before"),
            Run { text: String::new(), style: RunStyle { footnote: Some(0), ..Default::default() } },
            Run::plain(" and after"),
        ],
    };
    let rt = round_trip(&d);
    assert_eq!(rt.footnotes, vec!["the note text".to_string()]);
    assert_eq!(rt.paragraphs.len(), 1, "note body leaked into the body stream: {:?}", rt.paragraphs);
    let text: String = rt.paragraphs[0].runs.iter().map(|r| r.text.as_str()).collect();
    assert_eq!(text, "body before and after");
    assert_eq!(
        rt.paragraphs[0].runs.iter().filter_map(|r| r.style.footnote).collect::<Vec<_>>(),
        vec![0],
        "the reference run did not come back"
    );
}

/// Two notes keep their own text and their own order.
#[test]
fn two_footnotes_keep_their_indexes() {
    let mut d = Document::from_plain_text("");
    d.footnotes = vec!["first".to_string(), "second".to_string()];
    d.paragraphs[0] = Paragraph {
        style: ParaStyle::default(),
        runs: vec![
            Run::plain("a"),
            Run { text: String::new(), style: RunStyle { footnote: Some(0), ..Default::default() } },
            Run::plain("b"),
            Run { text: String::new(), style: RunStyle { footnote: Some(1), ..Default::default() } },
        ],
    };
    let rt = round_trip(&d);
    assert_eq!(rt.footnotes, vec!["first".to_string(), "second".to_string()]);
    assert_eq!(
        rt.paragraphs[0].runs.iter().filter_map(|r| r.style.footnote).collect::<Vec<_>>(),
        vec![0, 1]
    );
}

/// Tab stops, which ODF puts in a child element of the paragraph
/// properties rather than an attribute.
///
/// Neither writer persisted these, so a paragraph's stops were lost
/// on every save in both formats. Because `style:tab-stops` is a
/// child, a paragraph carrying stops cannot be written as a
/// self-closing `style:paragraph-properties` — which is what this
/// writer emitted for every style it had.
#[test]
fn tab_stops_survive() {
    let mut d = Document::from_plain_text("tabbed");
    d.paragraphs[0].style.tab_stops_pt = vec![36.0, 108.0];
    let rt = round_trip(&d);
    assert_eq!(rt.paragraphs[0].style.tab_stops_pt.len(), 2, "stops lost");
    for (got, want) in rt.paragraphs[0].style.tab_stops_pt.iter().zip([36.0, 108.0]) {
        assert!((got - want).abs() < 0.01, "stop {got} != {want}");
    }
}

/// Stops belong to the paragraph that declared them.
///
/// Paragraph automatic styles are deduplicated, and the key used to
/// be the attribute string alone — which every paragraph here shares.
/// Two paragraphs with different stops would then have collapsed onto
/// one style and both read back with the first one's stops.
#[test]
fn different_tab_stops_do_not_share_one_style() {
    let mut d = Document::from_plain_text("first\nsecond");
    d.paragraphs[0].style.tab_stops_pt = vec![36.0];
    d.paragraphs[1].style.tab_stops_pt = vec![144.0];
    let rt = round_trip(&d);
    assert_eq!(rt.paragraphs[0].style.tab_stops_pt.len(), 1);
    assert_eq!(rt.paragraphs[1].style.tab_stops_pt.len(), 1);
    assert!((rt.paragraphs[0].style.tab_stops_pt[0] - 36.0).abs() < 0.01);
    assert!(
        (rt.paragraphs[1].style.tab_stops_pt[0] - 144.0).abs() < 0.01,
        "second paragraph got the first one's stops: {:?}",
        rt.paragraphs[1].style.tab_stops_pt
    );
}

#[test]
fn plain_paragraphs() {
    let d = Document::from_plain_text("first\nsecond\n\nfourth");
    assert_eq!(round_trip(&d).to_plain_text(), d.to_plain_text());
}

#[test]
fn headings_survive() {
    let mut d = Document::from_plain_text("Title\nSection\nbody");
    d.set_heading(0, Some(1));
    d.set_heading(1, Some(3));
    let rt = round_trip(&d);
    assert_eq!(rt.paragraphs[0].style.heading, Some(1));
    assert_eq!(rt.paragraphs[1].style.heading, Some(3));
    assert_eq!(rt.paragraphs[2].style.heading, None);
    assert_eq!(rt.to_plain_text(), d.to_plain_text());
}

#[test]
fn inline_styles_survive() {
    let mut d = Document::from_plain_text("normal bold italic under strike");
    d.apply_run_style(7, 11, &StylePatch::set_bold(true));
    d.apply_run_style(12, 18, &StylePatch::set_italic(true));
    d.apply_run_style(19, 24, &StylePatch::set_underline(true));
    d.apply_run_style(25, 31, &StylePatch::set_strikethrough(true));
    let rt = round_trip(&d);
    assert_eq!(rt.to_plain_text(), d.to_plain_text());
    assert_eq!(rt.paragraphs[0].runs, d.paragraphs[0].runs);
}

#[test]
fn font_size_color_highlight_survive() {
    let mut d = Document::from_plain_text("");
    d.paragraphs[0].runs = vec![
        Run {
            text: "sized".into(),
            style: RunStyle { font_size_hp: Some(28), ..Default::default() },
        },
        Run::plain(" "),
        Run {
            text: "colored".into(),
            style: RunStyle { color: Some("ff0000".into()), ..Default::default() },
        },
        Run::plain(" "),
        Run {
            text: "marked".into(),
            style: RunStyle { highlight: true, ..Default::default() },
        },
    ];
    let rt = round_trip(&d);
    assert_eq!(rt.paragraphs[0].runs, d.paragraphs[0].runs);
}

#[test]
fn links_survive() {
    let mut d = Document::from_plain_text("");
    d.paragraphs[0].runs = vec![
        Run::plain("visit "),
        Run {
            text: "gnome".into(),
            style: RunStyle { link: Some("https://gnome.org".into()), ..Default::default() },
        },
        Run::plain(" now"),
    ];
    let rt = round_trip(&d);
    assert_eq!(rt.paragraphs[0].runs, d.paragraphs[0].runs);
}

#[test]
fn alignment_and_page_break_survive() {
    let mut d = Document::from_plain_text("centered\nright\njustified\nbroken");
    d.paragraphs[0].style.alignment = Alignment::Center;
    d.paragraphs[1].style.alignment = Alignment::Right;
    d.paragraphs[2].style.alignment = Alignment::Justify;
    d.paragraphs[3].style.page_break_before = true;
    let rt = round_trip(&d);
    assert_eq!(rt.paragraphs[0].style.alignment, Alignment::Center);
    assert_eq!(rt.paragraphs[1].style.alignment, Alignment::Right);
    assert_eq!(rt.paragraphs[2].style.alignment, Alignment::Justify);
    assert!(rt.paragraphs[3].style.page_break_before);
}

#[test]
fn lists_survive() {
    let mut d = Document::from_plain_text("intro\none\ntwo\nfirst\nsecond\noutro");
    d.paragraphs[1].style.list = ListKind::Bullet;
    d.paragraphs[2].style.list = ListKind::Bullet;
    d.paragraphs[3].style.list = ListKind::Numbered;
    d.paragraphs[4].style.list = ListKind::Numbered;
    let rt = round_trip(&d);
    let kinds: Vec<ListKind> = rt.paragraphs.iter().map(|p| p.style.list).collect();
    assert_eq!(
        kinds,
        vec![
            ListKind::None,
            ListKind::Bullet,
            ListKind::Bullet,
            ListKind::Numbered,
            ListKind::Numbered,
            ListKind::None
        ]
    );
    assert_eq!(rt.to_plain_text(), d.to_plain_text());
}

#[test]
fn header_footer_survive() {
    let mut d = Document::from_plain_text("body");
    d.header = Some("Report — {page} of {total}".into());
    d.footer = Some("Confidential".into());
    let rt = round_trip(&d);
    assert_eq!(rt.header.as_deref(), Some("Report — {page} of {total}"));
    assert_eq!(rt.footer.as_deref(), Some("Confidential"));
}

#[test]
fn special_chars_escaped() {
    let d = Document::from_plain_text("a < b & c > \"d\"");
    assert_eq!(round_trip(&d).to_plain_text(), d.to_plain_text());
}

#[test]
fn page_geometry_survives() {
    let mut d = Document::from_plain_text("body");
    d.page = Some(PageGeometry {
        width_pt: 612.0,   // US Letter
        height_pt: 792.0,
        margin_top_pt: 36.0,
        margin_bottom_pt: 54.0,
        margin_left_pt: 90.0,
        margin_right_pt: 45.0,
        columns: 1,
        column_gap_pt: 18.0,
    });
    let rt = round_trip(&d);
    let pg = rt.page.expect("page geometry lost");
    assert!(pg.approx_eq(&d.page.unwrap()), "geometry drifted: {pg:?}");
}

#[test]
fn structured_paragraph_layout_survives() {
    let mut d = Document::from_plain_text("layout");
    d.paragraphs[0].style.space_before_pt = 6.0;
    d.paragraphs[0].style.space_after_pt = 9.0;
    d.paragraphs[0].style.left_indent_pt = 24.0;
    d.paragraphs[0].style.first_line_indent_pt = -12.0;
    let rt = round_trip(&d);
    let st = &rt.paragraphs[0].style;
    assert!((st.space_before_pt - 6.0).abs() < 0.01);
    assert!((st.space_after_pt - 9.0).abs() < 0.01);
    assert!((st.left_indent_pt - 24.0).abs() < 0.01);
    assert!((st.first_line_indent_pt + 12.0).abs() < 0.01);
}

#[test]
fn no_page_geometry_reads_none() {
    let d = Document::from_plain_text("body");
    assert_eq!(round_trip(&d).page, None);
}

#[test]
fn font_family_survives() {
    let mut d = Document::from_plain_text("");
    d.paragraphs[0].runs = vec![
        Run::plain("sans "),
        Run {
            text: "serif".into(),
            style: RunStyle {
                font_family: Some("Liberation Serif".into()),
                ..Default::default()
            },
        },
    ];
    let rt = round_trip(&d);
    assert_eq!(rt.paragraphs[0].runs, d.paragraphs[0].runs);
}

#[test]
fn line_spacing_survives() {
    let mut d = Document::from_plain_text("single\ndouble");
    d.paragraphs[1].style.line_spacing = 2.0;
    let rt = round_trip(&d);
    assert!((rt.paragraphs[0].style.line_spacing - 1.0).abs() < 0.01);
    assert!((rt.paragraphs[1].style.line_spacing - 2.0).abs() < 0.01);
}

#[test]
fn empty_paragraphs_preserved() {
    let d = Document::from_plain_text("a\n\n\nb");
    assert_eq!(round_trip(&d).to_plain_text(), "a\n\n\nb");
}
