// lecture.rs — partie de docx.rs, découpé par thème.
// SPDX-License-Identifier: GPL-3.0-or-later

#![allow(unused_imports)]
use super::*;
use crate::model::{Alignment, Document, ListKind, PageGeometry, Paragraph, ParaStyle, Run, RunStyle};
use rdocx_oxml::shared::ST_Jc;

pub(crate) fn read_opened(path: &str, doc: rdocx::Document) -> Result<Document, String> {
    THEME.with(|t| *t.borrow_mut() = theme_fonts(path));
    RESTARTED.with(|r| r.borrow_mut().clear());
    STYLE_FONTS.with(|s| *s.borrow_mut() = style_fonts(path));

    // Paragraph properties rdocx cannot hand back: strict-spelled indents
    // and tab-stop positions. The scan is positional, so it is only
    // trusted when it found exactly as many body paragraphs as rdocx did;
    // otherwise the two disagree about what a paragraph is and pairing
    // them would misattribute a property to its neighbour.
    let body = doc.paragraphs();
    let RawParas { body: raw, cells: raw_cells, table_at, line_numbering, .. } = raw_paragraph_props(path);
    let raw = (raw.len() == body.len()).then_some(raw);
    let raw_trusted = raw.is_some();
    // Samizdat : position dans `paragraphs` de chaque paragraphe du corps, pour
    // remettre les tableaux à leur place au lieu de les ajouter à la fin.
    let mut body_pos: Vec<usize> = Vec::with_capacity(body.len() + 1);

    let mut paragraphs = Vec::new();
    // Per kept body paragraph: its style id and whether it has contextual
    // spacing, for the pass after this loop.
    let mut contextual: Vec<(Option<String>, bool)> = Vec::new();
    let contextual_ids = contextual_styles(path);
    // Set when a paragraph ends with a run-level page break, and consumed
    // by the next paragraph this loop keeps.
    let mut carried_break = false;
    for (i, p) in body.iter().enumerate() {
        body_pos.push(paragraphs.len());
        let mut pending_break = false;
        // Decorative rules (LibreOffice's HorizontalLine style) carry no text.
        if p.style_id() == Some("HorizontalLine") && p.text().is_empty() {
            continue;
        }
        let mut para = map_paragraph(&doc, p);
        // A run-level break after this paragraph's text belongs to the
        // paragraph that follows, which is where LibreOffice puts the
        // break it converts from an ODF `fo:break-before`. The trailing
        // newline it leaves behind is the break itself, not content: this
        // model's paragraphs never contain one.
        let breaks = run_page_break(p);
        if breaks.trailing {
            if let Some(last) = para.runs.last_mut() {
                if last.text.ends_with('\n') {
                    last.text.pop();
                }
            }
            para.runs.retain(|r| {
                !r.text.is_empty() || r.style.image.is_some() || r.style.footnote.is_some()
            });
            pending_break = true;
        }
        if std::mem::take(&mut carried_break) {
            para.style.page_break_before = true;
        }
        // A paragraph holding nothing but a page break (python-docx's
        // `add_run().add_break(WD_BREAK.PAGE)`, Word's Ctrl+Enter on an
        // empty line) is the break, not a line of its own: LibreOffice
        // starts the next paragraph at the top of the new page. Kept, it
        // put an empty line there instead.
        // (rdocx gives the break's run the text "\n".)
        let only_break = para.runs.iter().all(|r| {
            r.style.image.is_none() && r.style.footnote.is_none() && r.text.chars().all(|c| c == '\n')
        });
        if only_break && breaks.leading && !pending_break && i + 1 < body.len() {
            carried_break = true;
            continue;
        }
        let style_id = p.style_id().map(str::to_string);
        let direct_contextual = raw.as_ref().and_then(|s| s.get(i)).is_some_and(|r| r.contextual);
        let is_contextual = direct_contextual || style_id.as_deref().is_some_and(|id| contextual_ids.contains(id));
        contextual.push((style_id, is_contextual));
        if let Some(r) = raw.as_ref().and_then(|s| s.get(i)) {
            apply_strict_indents(&mut para.style, r);
            para.style.line_numbers = line_numbering && !r.suppress_lines;
        }
        // Samizdat : la section précédente s'est terminée : nouvelle page.
        if i > 0 && raw.as_ref().and_then(|s| s.get(i - 1)).is_some_and(|r| r.section_end) {
            para.style.page_break_before = true;
        }
        list_indent_from_declared(&doc, p, &mut para.style);
        paragraphs.push(para);
        carried_break = pending_break;
    }

    body_pos.push(paragraphs.len());

    // Contextual spacing: no space between two paragraphs of one style
    // when the paragraph asks for it (Word's and LibreOffice's rule).
    for k in 1..contextual.len().min(paragraphs.len()) {
        let same = contextual[k - 1].0 == contextual[k].0;
        if same && contextual[k - 1].1 {
            paragraphs[k - 1].style.space_after_pt = 0.0;
        }
        if same && contextual[k].1 {
            paragraphs[k].style.space_before_pt = 0.0;
        }
    }

    // Table cells become paragraphs tagged with (table, row, col) — the
    // document stays flat (offset invariants intact) and the grid is fully
    // recoverable. Position limitation: rdocx exposes tables separately
    // from the paragraph stream, so tables append after body paragraphs.
    let tables = doc.tables();
    // Samizdat : où va chaque tableau (si le balayage brut est fiable).
    let table_pos: Option<Vec<usize>> = (raw_trusted && table_at.len() == tables.len())
        .then(|| table_at.iter().map(|i| body_pos.get(*i).copied().unwrap_or(paragraphs.len())).collect());
    if !tables.is_empty() {
        // OOXML mandates an (empty) paragraph after each table; with the
        // tables appended at the end it is pure noise — drop it. Placed
        // tables keep the empty paragraphs before them.
        let floor = table_pos.as_ref().and_then(|v| v.last().copied()).unwrap_or(0);
        while paragraphs.len() > floor && paragraphs.last().map(|p: &Paragraph| p.runs.is_empty()).unwrap_or(false) {
            paragraphs.pop();
        }
    }
    let mut table_paras: Vec<Vec<Paragraph>> = Vec::with_capacity(tables.len());
    // The cell half of the scan, trusted on the same terms as the body
    // half: only when it counted exactly the paragraphs rdocx walks here.
    let mut cell_paragraphs = 0usize;
    for table in &tables {
        for row in (0..table.row_count()).filter_map(|ri| table.row(ri)) {
            for ci in 0..row.cell_count() {
                cell_paragraphs += row.cell(ci).map_or(0, |c| c.paragraphs().count());
            }
        }
    }
    let raw_cells = (raw_cells.len() == cell_paragraphs).then_some(raw_cells);
    let mut cell_index = 0usize;
    for (ti, table) in tables.iter().enumerate() {
        let mut this_table: Vec<Paragraph> = Vec::new();
        // Samizdat : l'allure d'un cartouche, dans le nom de son style.
        let cartouche = table.style_id().and_then(crate::model::Cartouche::parse);
        // Samizdat : la grille (largeur des colonnes), les fusions, les
        // hauteurs de ligne, les fonds et les bordures.
        let grid: Vec<u32> = table.grid_widths().iter().map(|l| (l.to_emu().max(0) / 635) as u32).collect();
        let grid_cols = grid.len().max(1);
        let visible = |b: Option<rdocx::TableBorderRef<'_>>| b.is_some_and(|b| !matches!(b.style(), "none" | "nil"));
        use rdocx::TableBorderEdge as TE;
        let table_borders = if table.has_borders() {
            [TE::Top, TE::Bottom, TE::Left, TE::Right, TE::InsideHorizontal, TE::InsideVertical].into_iter().any(|e| visible(table.border(e)))
        } else {
            // Sans bordure directe : celles du style ; le style par défaut
            // de Word (« Normal Table ») n'en a pas.
            table.style_id().is_some_and(|s| !matches!(s, "TableNormal" | "NormalTable" | "a1"))
        };
        for ri in 0..table.row_count() {
            let Some(row) = table.row(ri) else { continue };
            let (height_tw, height_exact) = match row.height() {
                Some(rdocx::RowHeight::AtLeast(l)) => ((l.to_emu().max(0) / 635) as u32, false),
                Some(rdocx::RowHeight::Exact(l)) => ((l.to_emu().max(0) / 635) as u32, true),
                None => (0, false),
            };
            let mut g = row.grid_before().unwrap_or(0) as usize;
            // Colonnes omises en tête de ligne : des cases vides.
            for c in 0..g.min(grid_cols) {
                this_table.push(Paragraph {
                    style: ParaStyle {
                        table_cell: Some(crate::model::TableCell { table: ti as u32, row: ri as u32, col: c as u32, width_tw: grid.get(c).copied().unwrap_or(0), height_tw, height_exact, no_border: true, ..Default::default() }),
                        cartouche,
                        ..Default::default()
                    },
                    runs: vec![],
                });
            }
            for ci in 0..row.cell_count() {
                let Some(cell) = row.cell(ci) else { continue };
                let span = cell.grid_span().unwrap_or(1).max(1) as usize;
                // La largeur de la case d'abord (Word recalcule la grille
                // d'après elle), sinon celle de ses colonnes de grille.
                let width_tw = cell.width().map_or(0, |l| (l.to_emu().max(0) / 635) as u32);
                let width_tw = if width_tw > 0 { width_tw } else { grid.get(g..(g + span).min(grid.len())).map_or(0, |w| w.iter().sum()) };
                let vmerge = match cell.v_merge() {
                    Some(rdocx::VMerge::Restart) => 1,
                    Some(rdocx::VMerge::Continue) => 2,
                    None => 0,
                };
                let fill = cell.shading_fill().or(table.shading_fill()).and_then(hex_rgb);
                use rdocx::CellBorderEdge as CE;
                let cell_borders = cell.has_borders()
                    && [CE::Top, CE::Bottom, CE::Left, CE::Right].into_iter().any(|e| visible(cell.border(e)));
                let props = crate::model::TableCell {
                    table: ti as u32, row: ri as u32, col: g as u32,
                    width_tw, height_tw, height_exact,
                    span: span as u16, covered: false, vmerge, fill,
                    no_border: !(table_borders || cell_borders),
                };
                let col_g = g;
                g += span;
                let mut wrote_any = false;
                let mut keep = |para: Paragraph| {
                    let mut para = para;
                    para.style.table_cell = Some(props);
                    para.style.cartouche = cartouche;
                    this_table.push(para);
                    wrote_any = true;
                };
                for item in cell.items() {
                    match item {
                        rdocx::CellItemRef::Paragraph(cp) => {
                            let raw_cell = raw_cells.as_ref().and_then(|s| s.get(cell_index));
                            cell_index += 1;
                            // Samizdat : les lignes vides d'une case (la place pour écrire
                            // sur une fiche) sont gardées ; le writer retire celle que rdocx
                            // crée dans chaque case.
                            let mut para = map_paragraph(&doc, &cp);
                            if let Some(r) = raw_cell {
                                apply_strict_indents(&mut para.style, r);
                            }
                            keep(para);
                        }
                        // A table nested in a cell belongs to its outer
                        // cell, as in the ODT reader: the model has no
                        // nesting, and dropping it lost its text (#1419).
                        // The save asks before it flattens one
                        // (`loss::content_a_save_drops`).
                        rdocx::CellItemRef::Table(nested) => {
                            for_each_nested_paragraph(&nested, &mut |cp| {
                                if !cp.text().is_empty() {
                                    keep(map_paragraph(&doc, cp));
                                }
                            });
                        }
                        _ => {}
                    }
                }
                // Empty cells still occupy a grid position.
                if !wrote_any {
                    this_table.push(Paragraph {
                        style: ParaStyle { table_cell: Some(props), cartouche, ..Default::default() },
                        runs: vec![],
                    });
                }
                // Les colonnes qu'elle couvre : des cases masquées, pour
                // garder la grille rectangulaire.
                for c in col_g + 1..col_g + span {
                    let hidden = crate::model::TableCell { col: c as u32, width_tw: 0, span: 1, covered: true, ..props };
                    this_table.push(Paragraph {
                        style: ParaStyle { table_cell: Some(hidden), cartouche, ..Default::default() },
                        runs: vec![],
                    });
                }
            }
            // Colonnes omises en fin de ligne.
            while g < grid_cols && grid.len() > 1 {
                this_table.push(Paragraph {
                    style: ParaStyle {
                        table_cell: Some(crate::model::TableCell { table: ti as u32, row: ri as u32, col: g as u32, width_tw: grid[g], height_tw, height_exact, no_border: true, ..Default::default() }),
                        cartouche,
                        ..Default::default()
                    },
                    runs: vec![],
                });
                g += 1;
            }
        }
        table_paras.push(this_table);
    }
    match table_pos {
        // De la fin vers le début : les positions restantes ne bougent pas.
        Some(pos) => {
            for (t, at) in table_paras.into_iter().zip(pos).rev() {
                let at = at.min(paragraphs.len());
                paragraphs.splice(at..at, t);
            }
        }
        None => {
            for t in table_paras {
                paragraphs.extend(t);
            }
        }
    }

    // Samizdat : un saut de ligne dans un paragraphe (`w:br`) est U+2028 ;
    // en « \n », l'éditeur en aurait fait deux paragraphes.
    for p in &mut paragraphs {
        for r in &mut p.runs {
            if r.text.contains('\n') {
                r.text = r.text.replace('\n', "\u{2028}");
            }
        }
    }
    if paragraphs.is_empty() {
        let mut d = Document::new();
        d.header = doc.header_text();
        d.footer = doc.footer_text();
        return Ok(d);
    }
    // Footnote texts land in the document list; docx ids remap to
    // zero-based indexes on the referencing runs (see map_paragraph).
    let footnotes: Vec<String> = doc.footnotes().into_iter().map(|(_, t)| t).collect();

    Ok(Document {
        paragraphs,
        footnotes,
        header: doc.header_text(),
        footer: doc.footer_text(),
        page: read_page_geometry(&doc),
        base_font: read_base_font(&doc),
        heading_styles: read_heading_styles(&doc),
        comments: Vec::new(),
        kept: Vec::new(),
    })
}

/// Page geometry from the docx section properties, when present.
pub(crate) fn read_page_geometry(doc: &rdocx::Document) -> Option<PageGeometry> {
    let sect = doc.section_properties()?;
    // Twips (1/20 pt) → points; the Twips newtype is not re-exported, so
    // work through the tuple field.
    let w = sect.page_width.map(|v| v.0 as f64 / 20.0)?;
    let h = sect.page_height.map(|v| v.0 as f64 / 20.0)?;
    let default = PageGeometry::default();
    Some(PageGeometry {
        width_pt: w,
        height_pt: h,
        margin_top_pt: sect.margin_top.map(|v| v.0 as f64 / 20.0).unwrap_or(default.margin_top_pt),
        margin_bottom_pt: sect.margin_bottom.map(|v| v.0 as f64 / 20.0).unwrap_or(default.margin_bottom_pt),
        margin_left_pt: sect.margin_left.map(|v| v.0 as f64 / 20.0).unwrap_or(default.margin_left_pt),
        margin_right_pt: sect.margin_right.map(|v| v.0 as f64 / 20.0).unwrap_or(default.margin_right_pt),
        // `w:cols` is absent for a single-column section, which is the
        // default this falls back to.
        columns: sect
            .columns
            .as_ref()
            .and_then(|c| c.num)
            .and_then(|n| u8::try_from(n).ok())
            .filter(|n| *n > 0)
            .unwrap_or(default.columns),
        column_gap_pt: sect
            .columns
            .as_ref()
            .and_then(|c| c.space)
            .map(|v| v.0 as f64 / 20.0)
            .unwrap_or(default.column_gap_pt),
    })
}

/// La couleur de surlignage d'un run (None = jaune ou pas de surlignage), à
/// partir de ce que rdocx lit : un nom Word (`w:highlight`) ou une trame.
pub(crate) fn read_highlight_color(value: Option<String>) -> Option<String> {
    let v = value?;
    let hex = match WORD_HIGHLIGHTS.iter().find(|(n, _)| n.eq_ignore_ascii_case(&v)) {
        Some((_, h)) => h.to_string(),
        None if v.len() == 6 && v.chars().all(|c| c.is_ascii_hexdigit()) => v.to_uppercase(),
        None => return None,
    };
    (hex != "FFFF00").then_some(hex)
}

/// Map one rdocx paragraph (body or table cell) into a model paragraph.
/// Where a run-level page break sits in a paragraph, if there is one.
///
/// OOXML expresses a page break two ways: `w:pageBreakBefore` in the
/// paragraph properties, and a `<w:br w:type="page"/>` inside a run.
/// LibreOffice writes the second when it converts an ODF
/// `fo:break-before="page"` — as the *last* run of the paragraph
/// *before* the break, which is the same thing as this model's
/// `page_break_before` on the paragraph that follows.
///
/// A break before any text in its own paragraph means the same flag on
/// that paragraph, which is how Word writes a break the user inserted at
/// the start of a line. A break with text on both sides of it splits one
/// paragraph across pages, which this model cannot express and which
/// this therefore ignores rather than misreport as a paragraph break.
#[derive(Clone, Copy, Default, PartialEq, Debug)]
pub(crate) struct RunPageBreak {
    /// Before any text in this paragraph.
    pub(crate) leading: bool,
    /// After all of this paragraph's text, so the break belongs to the
    /// next paragraph.
    pub(crate) trailing: bool,
}

pub(crate) fn run_page_break(p: &rdocx::ParagraphRef<'_>) -> RunPageBreak {
    let mut seen_text = false;
    let mut break_after_text = false;
    let mut leading = false;
    for r in p.runs() {
        for item in r.items() {
            match item {
                rdocx::RunItemRef::Break(rdocx::BreakKind::Page) => {
                    if seen_text {
                        break_after_text = true;
                    } else {
                        leading = true;
                    }
                }
                rdocx::RunItemRef::Text(t) if !t.is_empty() => {
                    seen_text = true;
                    // Text after a break means it was not trailing after all.
                    break_after_text = false;
                }
                _ => {}
            }
        }
    }
    RunPageBreak { leading, trailing: break_after_text }
}

/// A paragraph's list numbering as `(num_id, level)`, wherever it is set.
///
/// Word's built-in list styles ("List Bullet", "List Number 2", …) carry
/// their `w:numPr` on the *style*, not the paragraph: python-docx, Word's
/// own style gallery and many templates write list items that way. Reading
/// only the paragraph's direct `w:numPr` turned every such list into plain
/// paragraphs with no marker at all.
///
/// The level is the paragraph's own `w:ilvl` when it has one. Otherwise a
/// numbered built-in style names its level ("List Bullet 3" is the third
/// level: Word gives each its own `numId` at `ilvl` 0, indented one step
/// further), and failing that the style's inherited `w:ilvl`. `numId` 0
/// means "no numbering" and switches an inherited list off.
pub(crate) fn paragraph_numbering(doc: &rdocx::Document, p: &rdocx::ParagraphRef<'_>) -> Option<(u32, u32)> {
    if let Some((num_id, level)) = p.numbering() {
        return (num_id != 0).then_some((num_id, level));
    }
    let style_id = p.style_id()?;
    let resolved = doc.resolve_paragraph_properties(Some(style_id));
    let num_id = resolved.num_id.filter(|&id| id != 0)?;
    let level = doc
        .style(style_id)
        .and_then(|s| s.name().and_then(builtin_list_style_level))
        .or(resolved.num_ilvl)
        .unwrap_or(0);
    Some((num_id, level))
}

/// A directly numbered list paragraph's indent, as the model keeps it: the
/// declared left edge of its text (the paragraph's own `w:ind`, else its
/// numbering level's) less the list indent the layout adds for its level.
/// The writer declares exactly `left_indent + text_indent(level)`, so its
/// own lists come back as written; a Word toolbar list (0.5in per level)
/// keeps the extra depth it is drawn with in Word and LibreOffice. A list's
/// hanging indent is the list's own, not a first-line indent.
///
/// Paragraphs numbered through a built-in list style ("List Bullet") are
/// left alone: those styles' 0.25in levels are what the layout already
/// draws, and their level is the style's, not the numbering's.
pub(crate) fn list_indent_from_declared(doc: &rdocx::Document, p: &rdocx::ParagraphRef<'_>, style: &mut ParaStyle) {
    if style.list == ListKind::None {
        return;
    }
    let Some((num_id, level)) = p.numbering().filter(|&(id, _)| id != 0) else { return };
    let text = crate::lists::text_indent_pt(style.list_level);
    let declared = if style.left_indent_pt != 0.0 {
        style.left_indent_pt
    } else {
        doc.numbering_level(num_id, level).and_then(|l| l.indent_left).map(twips_pt).unwrap_or(text)
    };
    style.left_indent_pt = (declared - text).max(0.0);
    if style.first_line_indent_pt < 0.0 {
        style.first_line_indent_pt = 0.0;
    }
}

/// The level a Word built-in list style name implies: "List Bullet" and
/// "List Number" are level 0, "List Bullet 2" … "List Bullet 5" levels 1–4.
pub(crate) fn builtin_list_style_level(name: &str) -> Option<u32> {
    let rest = name
        .strip_prefix("List Bullet")
        .or_else(|| name.strip_prefix("List Number"))?
        .trim();
    if rest.is_empty() {
        return Some(0);
    }
    rest.parse::<u32>().ok().filter(|n| (2..=9).contains(n)).map(|n| n - 1)
}

/// Every paragraph of `table`, its own nested tables' included, in
/// document order.
pub(crate) fn for_each_nested_paragraph(table: &rdocx::TableRef<'_>, f: &mut dyn FnMut(&rdocx::ParagraphRef<'_>)) {
    for ri in 0..table.row_count() {
        let Some(row) = table.row(ri) else { continue };
        for ci in 0..row.cell_count() {
            let Some(cell) = row.cell(ci) else { continue };
            for item in cell.items() {
                match item {
                    rdocx::CellItemRef::Paragraph(p) => f(&p),
                    rdocx::CellItemRef::Table(t) => for_each_nested_paragraph(&t, f),
                    _ => {}
                }
            }
        }
    }
}

pub(crate) fn map_paragraph(doc: &rdocx::Document, p: &rdocx::ParagraphRef<'_>) -> Paragraph {
    let heading = p.style_id().and_then(style_id_to_heading);
    // LO uses "Quotations"; Word uses "Quote"/"IntenseQuote".
    let block_quote = matches!(p.style_id(), Some("Quote") | Some("Quotations") | Some("IntenseQuote") | Some("BlockQuote") | Some("BlockQuotation"));
    // LibreOffice emits PreformattedText for <pre>/code blocks.
    let code_block = matches!(p.style_id(), Some("PreformattedText") | Some("HTMLPreformatted"))
        .then(String::new);
    // What the paragraph's style chain (docDefaults, basedOn, its style)
    // says, for everything the paragraph does not set itself. Numbering
    // indents are left out: the model's list level carries them.
    let styled = doc.resolve_paragraph_properties(p.style_id());
    let alignment = match p.alignment() {
        Some(rdocx::Alignment::Center) => Alignment::Center,
        Some(rdocx::Alignment::Right) => Alignment::Right,
        Some(rdocx::Alignment::Justify) => Alignment::Justify,
        Some(_) => Alignment::Left,
        None => match styled.jc {
            Some(ST_Jc::Center) => Alignment::Center,
            Some(ST_Jc::Right | ST_Jc::End) => Alignment::Right,
            Some(ST_Jc::Both | ST_Jc::Distribute) => Alignment::Justify,
            _ => Alignment::Left,
        },
    };
    let named_style = match p.style_id() {
        Some(id @ ("Title" | "Subtitle" | "Caption")) => Some(id.to_string()),
        _ => None,
    };
    // Either spelling counts: the paragraph property, or a run-level
    // break before this paragraph's own text.
    let page_break_before = p.is_page_break_before() || run_page_break(p).leading;
    // Keep with next: the paragraph's own setting, else its style's.
    let keep_with_next = p.keep_with_next_value().or(styled.keep_next).unwrap_or(false);
    let numbering = paragraph_numbering(doc, p);
    let (list, list_level) = match numbering {
        // Samizdat : le format de CE niveau (une liste numérotée peut avoir
        // des puces au niveau 2), sinon celui de la liste.
        Some((num_id, level)) => (match doc.numbering_level(num_id, level).map(|l| l.format_name == "bullet").or_else(|| doc.numbering_is_bullet(num_id)) {
            Some(false) => ListKind::Numbered,
            // Unknown num_id defaults to bullet — the safer visual guess.
            _ => ListKind::Bullet,
        }, level.min(8) as u8),
        None => (ListKind::None, 0),
    };
    // Samizdat : le symbole propre de la puce de ce niveau (« o », « ▪ »…).
    let bullet_glyph = numbering
        .filter(|_| list == ListKind::Bullet)
        .and_then(|(num_id, level)| doc.numbering_level(num_id, level)?.level_text.map(str::to_string))
        .and_then(|t| crate::lists::bullet_glyph(&t));
    // Where a list restarts: a start override on this instance at this
    // level (#1205). Only the first item of that instance carries it.
    let list_start = numbering.and_then(|(num_id, level)| {
        let start = doc.numbering_instance(num_id)?.level_overrides.iter().find(|o| o.level == level)?.start?;
        RESTARTED.with(|r| r.borrow_mut().insert((num_id, level))).then_some(start)
    });

    // Per-run link URLs from hyperlink spans (indexes into the runs vec).
    let spans = p.hyperlink_spans();
    let link_for = |idx: usize| -> Option<String> {
        spans.iter()
            .find(|(start, end, _)| idx >= *start && idx < *end)
            .and_then(|(_, _, rel_id)| rel_id.as_deref().and_then(|id| doc.hyperlink_url(id)))
    };

    let base = read_base_font(doc);
    let mut runs = Vec::new();
    for (idx, r) in p.runs().enumerate() {
        // Inline images: extract bytes to a cache file so the model's
        // image path is always locally readable.
        if let Some((rel_id, alt)) = r.inline_image() {
            if let Some(bytes) = doc.image_data(rel_id) {
                // EMF/WMF (schémas collés depuis Excel, PowerPoint…) : aucun
                // décodeur ; un cadre gris le signale au lieu d'un vide.
                #[cfg(feature = "render")]
                let placeholder = metafile_placeholder(&bytes);
                #[cfg(feature = "render")]
                let bytes = placeholder.unwrap_or(bytes);
                // gh-268: the previous code wrote to a predictable
                // /tmp/letters-images/<content-hash>.png via fs::write, which
                // follows a pre-created symlink — a local user could point the
                // write anywhere. The media cache writes into a private 0700
                // per-process directory under an unpredictable name. The file
                // is NOT deleted when the model is done: it lives as long as
                // this process, identical bytes share one file, and the next
                // process sweeps the directory once this one is gone (#455).
                let path = match suite_common_core::media_cache::persist(&bytes) {
                    Ok(p) => p,
                    Err(_) => continue,
                };
                // The displayed size is the drawing's extent, not the
                // image's pixels: a 200px picture placed 2in wide is 2in.
                let extent = r.items().into_iter().find_map(|item| match item {
                    rdocx::RunItemRef::Drawing(d) => d.width().zip(d.height()),
                    _ => None,
                });
                runs.push(Run {
                    text: alt.unwrap_or("").to_string(),
                    style: RunStyle {
                        image: Some(path.to_string_lossy().into_owned()),
                        image_extent_emu: extent
                            .map(|(w, h)| (w.to_emu().max(0) as u64, h.to_emu().max(0) as u64))
                            .filter(|(w, h)| *w > 0 && *h > 0),
                        ..Default::default()
                    },
                });
                continue;
            }
        }
        if let Some(fid) = r.footnote_id() {
            if let Some(idx) = doc.footnotes().iter().position(|(id, _)| *id == fid) {
                runs.push(Run {
                    text: String::new(),
                    style: RunStyle { footnote: Some(idx), ..Default::default() },
                });
            }
            continue;
        }
        let text = r.text();
        if text.is_empty() { continue; }
        // A style's font, size and colour (a heading style's 16pt blue)
        // are the run's too; only what differs from the body font is
        // recorded, so an ordinary run stays unstyled.
        let eff = if heading.is_some() {
            // A heading's look is its level (layout::heading_scale); the
            // file's heading style is not copied onto every run.
            rdocx_oxml::properties::CT_RPr::default()
        } else {
            doc.effective_run_properties(p, &r)
        };
        let family = r.font_name().map(|f| f.to_string()).or_else(|| {
            heading.is_none().then(|| style_family(p.style_id())).flatten().filter(|f| Some(f) != base.family.as_ref())
        });
        let size_hp = r
            .size()
            .map(|pt| (pt * 2.0).round() as u16)
            .or_else(|| eff.sz.map(|s| s.0.min(u32::from(u16::MAX)) as u16).filter(|hp| Some(*hp) != base.size_hp));
        // "auto" is Word's automatic (default) text colour, not a colour:
        // on the run itself it must not hide the style's either.
        let color = r
            .color()
            .filter(|c| !c.eq_ignore_ascii_case("auto"))
            .map(|c| c.trim_start_matches('#').to_uppercase())
            .or_else(|| eff.color.as_deref().filter(|c| !c.eq_ignore_ascii_case("auto")).map(|c| c.to_uppercase()));
        runs.push(Run {
            text,
            style: RunStyle {
                bold: r.is_bold() || eff.bold == Some(true),
                italic: r.is_italic() || eff.italic == Some(true),
                underline: r.is_underline(),
                strikethrough: r.is_strike(),
                // Samizdat : « none » ou un fond « auto »/blanc ne sont pas
                // un surlignage (Word écrit <w:highlight w:val="none"/>).
                highlight: real_highlight(r.highlight()).is_some(),
                highlight_color: read_highlight_color(real_highlight(r.highlight())),
                code: r.style_id() == Some("SourceText"),
                link: link_for(idx),
                image: None,
                image_extent_emu: None,
                image_float: None,
                footnote: None,
                html: false,
                chip: None,
                revision: None,
                comments: Vec::new(),
                font_family: family,
                font_size_hp: size_hp,
                color,
                vert_align: match r.vert_align() {
                    Some("superscript") => Some(crate::model::VertAlign::Superscript),
                    Some("subscript") => Some(crate::model::VertAlign::Subscript),
                    // LibreOffice encodes super/subscript as raised/lowered
                    // position instead of vertAlign.
                    _ => match r.position() {
                        Some(p) if p > 0 => Some(crate::model::VertAlign::Superscript),
                        Some(p) if p < 0 => Some(crate::model::VertAlign::Subscript),
                        _ => None,
                    },
                },
            },
        });
    }
    let mut para = Paragraph {
        style: ParaStyle {
            heading, alignment, list, code_block, block_quote,
            list_level, list_start, bullet_glyph,
            named_style, page_break_before, keep_with_next,
            // Absent means "inherit": the paragraph looks the way its style
            // chain says, which the model has no styles to express, so the
            // inherited value is read into the paragraph. Reading only
            // direct values drew every paragraph of a python-docx or Word
            // document without its style's 10pt spacing and 1.15 lines.
            line_spacing: p
                .line_spacing_multiple()
                .or_else(|| styled_line_multiple(&styled))
                .map(|m| m as f32)
                .unwrap_or(1.0),
            left_indent_pt: p
                .indent_left()
                .map(|l| l.to_pt())
                .or_else(|| styled.ind_left.or(styled.ind_start).map(twips_pt))
                .unwrap_or(0.0),
            right_indent_pt: p
                .indent_right()
                .map(|l| l.to_pt())
                .or_else(|| styled.ind_right.or(styled.ind_end).map(twips_pt))
                .unwrap_or(0.0),
            first_line_indent_pt: p
                .first_line_indent()
                .map(|l| l.to_pt())
                .or_else(|| {
                    styled.ind_first_line.map(twips_pt).or_else(|| styled.ind_hanging.map(|h| -twips_pt(h)))
                })
                .unwrap_or(0.0),
            space_before_pt: p.space_before().map(|l| l.to_pt()).or_else(|| styled.space_before.map(twips_pt)).unwrap_or(0.0),
            space_after_pt: p.space_after().map(|l| l.to_pt()).or_else(|| styled.space_after.map(twips_pt)).unwrap_or(0.0),
            ..Default::default()
        },
        runs,
    };
    normalize(&mut para);
    para
}

pub(crate) fn twips_pt(t: rdocx_oxml::Twips) -> f64 {
    f64::from(t.0) / 20.0
}

/// A style's "auto" line spacing as a multiple of single (240 = 1.0).
/// Exact and at-least spacing have no multiple and read as unset.
pub(crate) fn styled_line_multiple(ppr: &rdocx_oxml::properties::CT_PPr) -> Option<f64> {
    let line = ppr.line_spacing?;
    match ppr.line_rule.as_deref() {
        None | Some("auto") if line.0 > 0 => Some(f64::from(line.0) / 240.0),
        _ => None,
    }
}

/// The theme's major (headings) and minor (body) Latin fonts, from
/// `word/theme/theme1.xml`; Office's current defaults when the file has no
/// theme or names none.
#[derive(Clone, Debug)]
pub(crate) struct ThemeFonts {
    pub(crate) major: String,
    pub(crate) minor: String,
}

pub(crate) fn theme_fonts(path: &str) -> ThemeFonts {
    let read = || -> Option<String> {
        let mut zip = zip::ZipArchive::new(std::fs::File::open(path).ok()?).ok()?;
        let mut xml = String::new();
        std::io::Read::read_to_string(&mut zip.by_name("word/theme/theme1.xml").ok()?, &mut xml).ok()?;
        Some(xml)
    };
    let xml = read().unwrap_or_default();
    let face = |which: &str| {
        let at = xml.find(&format!("<a:{which}>"))?;
        let latin = xml[at..].find("<a:latin ")? + at;
        let tf = xml[latin..].find("typeface=\"")? + latin + "typeface=\"".len();
        let end = xml[tf..].find('"')? + tf;
        Some(xml[tf..end].to_string()).filter(|f| !f.is_empty())
    };
    ThemeFonts {
        major: face("majorFont").unwrap_or_else(|| "Calibri Light".into()),
        minor: face("minorFont").unwrap_or_else(|| "Calibri".into()),
    }
}

thread_local! {
    /// The theme of the document being read (set by `read`).
    pub(crate) static THEME: std::cell::RefCell<ThemeFonts> =
        std::cell::RefCell::new(ThemeFonts { major: "Calibri Light".into(), minor: "Calibri".into() });
}

/// One `w:rFonts`: a theme font (which wins over an explicit face on the
/// same element, ISO/IEC 29500 §17.3.2.26) or a named face.
#[derive(Clone, Debug, PartialEq)]
pub(crate) enum FontRef {
    Major,
    Minor,
    Named(String),
}

/// The fonts styles.xml names, for resolving a style's font family through
/// its `w:basedOn` chain the way Word does: the most derived style that
/// names a font decides, whether by name or by theme. rdocx's merged
/// properties keep both a base style's explicit face and a derived style's
/// theme font, and cannot say which came from where (Heading 1's theme
/// "major" font lost to Normal's "Liberation Serif").
#[derive(Default)]
pub(crate) struct StyleFonts {
    /// style id -> (basedOn, its own run font)
    pub(crate) styles: std::collections::HashMap<String, (Option<String>, Option<FontRef>)>,
    pub(crate) default_para: Option<String>,
    pub(crate) doc_default: Option<FontRef>,
}

pub(crate) fn style_fonts(path: &str) -> StyleFonts {
    fn scan(path: &str) -> Result<StyleFonts, Box<dyn std::error::Error>> {
        let mut zip = zip::ZipArchive::new(std::fs::File::open(path)?)?;
        let mut xml = String::new();
        std::io::Read::read_to_string(&mut zip.by_name("word/styles.xml")?, &mut xml)?;
        let mut reader = quick_xml::Reader::from_str(&xml);
        reader.config_mut().trim_text(true);
        let mut out = StyleFonts::default();
        let attr = |e: &quick_xml::events::BytesStart<'_>, key: &str| {
            e.attributes().with_checks(false).flatten().find(|a| a.key.as_ref() == key).map(|a| a.value.to_string())
        };
        // Where we are: inside a style (its id), inside docDefaults'
        // rPrDefault, and inside a pPr (whose rPr is the paragraph mark's).
        let (mut style, mut in_defaults, mut in_ppr) = (None::<String>, false, false);
        loop {
            let ev = reader.read_event()?;
            let (e, empty) = match &ev {
                quick_xml::events::Event::Eof => break,
                quick_xml::events::Event::Start(e) => (e.clone(), false),
                quick_xml::events::Event::Empty(e) => (e.clone(), true),
                quick_xml::events::Event::End(e) => {
                    match e.name().as_ref() {
                        "w:style" => style = None,
                        "w:rPrDefault" => in_defaults = false,
                        "w:pPr" => in_ppr = false,
                        _ => {}
                    }
                    continue;
                }
                _ => continue,
            };
            match e.name().as_ref() {
                "w:style" if !empty => {
                    let id = attr(&e, "w:styleId").unwrap_or_default();
                    let is_para = attr(&e, "w:type").as_deref() == Some("paragraph");
                    if is_para && matches!(attr(&e, "w:default").as_deref(), Some("1" | "true")) {
                        out.default_para = Some(id.clone());
                    }
                    out.styles.entry(id.clone()).or_default();
                    style = Some(id);
                }
                "w:rPrDefault" if !empty => in_defaults = true,
                "w:pPr" if !empty => in_ppr = true,
                "w:basedOn" => {
                    if let Some(id) = &style {
                        out.styles.entry(id.clone()).or_default().0 = attr(&e, "w:val");
                    }
                }
                "w:rFonts" if !in_ppr => {
                    let font = match attr(&e, "w:asciiTheme").or_else(|| attr(&e, "w:hAnsiTheme")) {
                        Some(t) if t.starts_with("major") => Some(FontRef::Major),
                        Some(t) if t.starts_with("minor") => Some(FontRef::Minor),
                        _ => attr(&e, "w:ascii").or_else(|| attr(&e, "w:hAnsi")).map(FontRef::Named),
                    };
                    if let Some(id) = &style {
                        out.styles.entry(id.clone()).or_default().1 = font;
                    } else if in_defaults {
                        out.doc_default = font;
                    }
                }
                _ => {}
            }
        }
        Ok(out)
    }
    scan(path).unwrap_or_default()
}

thread_local! {
    /// The `(num_id, level)` list restarts already given to a paragraph in
    /// the document being read: only the first item of a restart carries it.
    pub(crate) static RESTARTED: std::cell::RefCell<std::collections::HashSet<(u32, u32)>> = Default::default();
}

thread_local! {
    /// The styles' fonts of the document being read (set by `read`).
    pub(crate) static STYLE_FONTS: std::cell::RefCell<StyleFonts> = std::cell::RefCell::new(StyleFonts::default());
}

/// The font family paragraph style `id` (or the default paragraph style)
/// gives its text, resolved through `w:basedOn` and docDefaults.
pub(crate) fn style_family(id: Option<&str>) -> Option<String> {
    STYLE_FONTS.with(|sf| {
        let sf = sf.borrow();
        let mut cur = id.map(str::to_string).or_else(|| sf.default_para.clone());
        let mut found = None;
        for _ in 0..32 {
            let Some(c) = cur else { break };
            let Some((based_on, font)) = sf.styles.get(&c) else { break };
            if font.is_some() {
                found = font.clone();
                break;
            }
            cur = based_on.clone();
        }
        let font = found.or_else(|| sf.doc_default.clone())?;
        THEME.with(|t| {
            let t = t.borrow();
            Some(match font {
                FontRef::Major => t.major.clone(),
                FontRef::Minor => t.minor.clone(),
                FontRef::Named(n) => n,
            })
        })
    })
}

/// How the document's Heading 1–6 styles look, as `RunStyle`s; empty when
/// it defines none (then Letters' own heading look applies).
pub(crate) fn read_heading_styles(doc: &rdocx::Document) -> Vec<RunStyle> {
    if !(1..=6).any(|n| doc.style(&format!("Heading{n}")).is_some()) {
        return Vec::new();
    }
    (1..=6)
        .map(|n| {
            let id = format!("Heading{n}");
            let rpr = doc.resolve_run_properties(Some(&id), None);
            RunStyle {
                bold: rpr.bold == Some(true),
                italic: rpr.italic == Some(true),
                font_family: style_family(Some(&id)),
                font_size_hp: rpr.sz.map(|s| s.0.min(u32::from(u16::MAX)) as u16),
                color: rpr.color.as_deref().filter(|c| !c.eq_ignore_ascii_case("auto")).map(|c| c.to_uppercase()),
                ..Default::default()
            }
        })
        .collect()
}

/// The body font: docDefaults run properties plus the default paragraph
/// style's (python-docx and Word put "Liberation Serif 12pt" or "Calibri
/// 11pt" there, never on the runs).
pub(crate) fn read_base_font(doc: &rdocx::Document) -> crate::model::BaseFont {
    let rpr = doc.resolve_run_properties(None, None);
    crate::model::BaseFont { family: style_family(None), size_hp: rpr.sz.map(|s| s.0.min(u32::from(u16::MAX)) as u16) }
}

pub(crate) fn style_id_to_heading(id: &str) -> Option<u8> {
    let level = id.strip_prefix("Heading")?.parse::<u8>().ok()?;
    (1..=6).contains(&level).then_some(level)
}

pub(crate) fn normalize(p: &mut Paragraph) {
    p.runs
        .retain(|r| !r.text.is_empty() || r.style.image.is_some() || r.style.footnote.is_some());
    crate::model::merge_adjacent_runs(&mut p.runs, |a, b| {
        a.style.footnote.is_none() && b.style.footnote.is_none() && a.style == b.style
    });
}
