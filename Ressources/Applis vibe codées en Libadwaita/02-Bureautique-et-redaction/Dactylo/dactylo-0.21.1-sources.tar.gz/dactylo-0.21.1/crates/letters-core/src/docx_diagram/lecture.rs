// Lecture des formes : DrawingML (wps, wpg, pic), couleurs, texte des zones.
// SPDX-License-Identifier: GPL-3.0-or-later

use super::*;

/// Les tracés d'une forme libre (`a:pathLst`).
pub(super) fn cust_paths(sp: &str) -> Vec<Path> {
    let Some(list) = element(sp, "a:pathLst") else { return Vec::new() };
    let mut out = Vec::new();
    let mut at = 0;
    while let Some(s) = find_open(list, "a:path", at) {
        let Some(e) = matching_close(list, "a:path", s) else { break };
        at = e;
        let p = &list[s..e];
        let tag = &p[..p.find('>').unwrap_or(0)];
        let mut path = Path {
            w: num(attr(tag, "w")) as f64,
            h: num(attr(tag, "h")) as f64,
            fill: attr(tag, "fill") != Some("none"),
            stroke: attr(tag, "stroke") != Some("0") && attr(tag, "stroke") != Some("false"),
            cmds: Vec::new(),
        };
        let pts = |seg: &str| -> Vec<(f64, f64)> {
            let mut v = Vec::new();
            let mut i = 0;
            while let Some(k) = seg[i..].find("<a:pt ") {
                let t = &seg[i + k..i + k + seg[i + k..].find('>').unwrap_or(0)];
                v.push((num(attr(t, "x")) as f64, num(attr(t, "y")) as f64));
                i += k + 5;
            }
            v
        };
        let mut i = p.find('>').map_or(p.len(), |k| k + 1);
        while i < p.len() {
            let Some(k) = p[i..].find('<') else { break };
            let st = i + k;
            let name_end = p[st..].find([' ', '>', '/']).map_or(p.len(), |n| st + n);
            let name = &p[st + 1..name_end];
            let open_end = p[st..].find('>').map_or(p.len(), |n| st + n + 1);
            let close = |n: &str| p[st..].find(&format!("</{n}>")).map_or(open_end, |c| st + c + n.len() + 3);
            match name {
                "a:moveTo" | "a:lnTo" | "a:cubicBezTo" | "a:quadBezTo" => {
                    let end = close(name);
                    let v = pts(&p[st..end]);
                    match (name, v.as_slice()) {
                        ("a:moveTo", [a, ..]) => path.cmds.push(Cmd::Move(a.0, a.1)),
                        ("a:lnTo", [a, ..]) => path.cmds.push(Cmd::Line(a.0, a.1)),
                        ("a:cubicBezTo", [a, b, c, ..]) => path.cmds.push(Cmd::Cubic(a.0, a.1, b.0, b.1, c.0, c.1)),
                        ("a:quadBezTo", [a, b, ..]) => path.cmds.push(Cmd::Quad(a.0, a.1, b.0, b.1)),
                        _ => {}
                    }
                    i = end;
                }
                "a:arcTo" => {
                    let t = &p[st..open_end];
                    path.cmds.push(Cmd::Arc(num(attr(t, "wR")) as f64, num(attr(t, "hR")) as f64, num(attr(t, "stAng")) as f64 / 60_000.0, num(attr(t, "swAng")) as f64 / 60_000.0));
                    i = open_end;
                }
                "a:close" => {
                    path.cmds.push(Cmd::Close);
                    i = open_end;
                }
                _ => i = open_end,
            }
        }
        if !path.cmds.is_empty() {
            out.push(path);
        }
    }
    out
}

pub(super) fn attr<'a>(tag: &'a str, k: &str) -> Option<&'a str> {
    let pat = format!(" {k}=\"");
    let i = tag.find(&pat)? + pat.len();
    tag[i..].split('"').next()
}

pub(super) fn tag_at<'a>(xml: &'a str, name: &str) -> Option<&'a str> {
    let s = find_open(xml, name, 0)?;
    Some(&xml[s..s + xml[s..].find('>')?])
}

pub(super) fn text_of<'a>(xml: &'a str, name: &str) -> Option<&'a str> {
    let s = find_open(xml, name, 0)?;
    let o = s + xml[s..].find('>')? + 1;
    let e = o + xml[o..].find(&format!("</{name}>"))?;
    Some(&xml[o..e])
}

pub(super) fn element<'a>(xml: &'a str, name: &str) -> Option<&'a str> {
    let s = find_open(xml, name, 0)?;
    let e = matching_close(xml, name, s)?;
    Some(&xml[s..e])
}

pub(super) fn num(v: Option<&str>) -> i64 {
    v.and_then(|v| v.trim().parse::<f64>().ok()).unwrap_or(0.0) as i64
}

pub(super) fn hex(v: &str) -> Option<[u8; 3]> {
    let v = v.trim().trim_start_matches('#');
    if v.len() != 6 {
        return None;
    }
    let c = |i: usize| u8::from_str_radix(&v[i..i + 2], 16).ok();
    Some([c(0)?, c(2)?, c(4)?])
}

/// La couleur d'un remplissage (`a:solidFill` …) : RVB, ou `None` pour
/// « aucun ». Les couleurs du thème sont approchées par celles d'Office.
pub(super) fn color(fill: &str) -> Option<[u8; 3]> {
    if let Some(t) = tag_at(fill, "a:srgbClr") {
        return attr(t, "val").and_then(hex);
    }
    if let Some(t) = tag_at(fill, "a:schemeClr") {
        return Some(match attr(t, "val").unwrap_or("") {
            "bg1" | "lt1" => [255, 255, 255],
            "tx1" | "dk1" => [0, 0, 0],
            "tx2" | "dk2" => [0x44, 0x54, 0x6A],
            "bg2" | "lt2" => [0xE7, 0xE6, 0xE6],
            "accent2" => [0xED, 0x7D, 0x31],
            "accent3" => [0xA5, 0xA5, 0xA5],
            "accent4" => [0xFF, 0xC0, 0x00],
            "accent5" => [0x5B, 0x9B, 0xD5],
            "accent6" => [0x70, 0xAD, 0x47],
            _ => [0x44, 0x72, 0xC4],
        });
    }
    if let Some(t) = tag_at(fill, "a:prstClr") {
        return Some(match attr(t, "val").unwrap_or("") {
            "white" => [255, 255, 255],
            "red" => [255, 0, 0],
            "blue" => [0, 0, 255],
            "green" => [0, 128, 0],
            _ => [0, 0, 0],
        });
    }
    None
}

/// Remplissage et trait d'une forme (`wps:spPr` ou `pic:spPr`), avec les
/// valeurs du style de la forme quand elle n'en dit rien.
pub(super) fn paint(sp: &str, style: &str, e: &mut Elem) {
    let (body, ln) = match find_open(sp, "a:ln", 0) {
        Some(l) => (&sp[..l], matching_close(sp, "a:ln", l).map_or(&sp[l..], |end| &sp[l..end])),
        None => (sp, ""),
    };
    e.fill = if body.contains("<a:noFill") {
        None
    } else if let Some(f) = element(body, "a:solidFill") {
        color(f)
    } else if body.contains("<a:gradFill") {
        element(body, "a:gs").and_then(color)
    } else {
        // Le style : fillRef idx 0 = aucun.
        tag_at(style, "a:fillRef").filter(|t| attr(t, "idx").is_some_and(|i| i != "0")).map(|_| element(style, "a:fillRef").and_then(color).unwrap_or([0x44, 0x72, 0xC4]))
    };
    let style_line = tag_at(style, "a:lnRef").is_some_and(|t| attr(t, "idx").is_some_and(|i| i != "0"));
    let width = tag_at(ln, "a:ln").and_then(|t| attr(t, "w")).map(|w| num(Some(w)) as f64 / 12_700.0);
    e.line = if ln.contains("<a:noFill") {
        None
    } else if let Some(f) = element(ln, "a:solidFill") {
        color(f).map(|c| (c, width.unwrap_or(0.75).max(0.25), ln.contains("<a:prstDash") && !ln.contains("val=\"solid\"")))
    } else if !ln.is_empty() || style_line {
        let c = element(style, "a:lnRef").and_then(color).unwrap_or([0, 0, 0]);
        Some((c, width.unwrap_or(0.75).max(0.25), ln.contains("<a:prstDash") && !ln.contains("val=\"solid\"")))
    } else {
        None
    };
    let end = |name: &str| tag_at(ln, name).and_then(|t| attr(t, "type")).is_some_and(|t| t != "none");
    e.head = end("a:headEnd");
    e.tail = end("a:tailEnd");
}

/// Le texte d'une zone de texte (`w:txbxContent`).
pub(super) fn text_paras(content: &str) -> Vec<TextPara> {
    let mut out = Vec::new();
    let mut at = 0;
    while let Some(s) = find_open(content, "w:p", at) {
        let Some(e) = matching_close(content, "w:p", s) else { break };
        at = e;
        let p = &content[s..e];
        let align = match tag_at(p, "w:jc").and_then(|t| attr(t, "w:val")) {
            Some("center") => 1,
            Some("right" | "end") => 2,
            Some("both" | "distribute") => 3,
            _ => 0,
        };
        // La taille de la marque de paragraphe, pour les runs qui n'en ont pas.
        let base = element(p, "w:pPr").and_then(|ppr| tag_at(ppr, "w:sz")).and_then(|t| attr(t, "w:val")).map_or(11.0, |v| num(Some(v)) as f64 / 2.0);
        let mut runs = Vec::new();
        let mut ra = 0;
        while let Some(rs) = find_open(p, "w:r", ra) {
            let Some(re) = matching_close(p, "w:r", rs) else { break };
            ra = re;
            let r = &p[rs..re];
            let rpr = element(r, "w:rPr").unwrap_or("");
            let on = |name: &str| tag_at(rpr, name).is_some_and(|t| !matches!(attr(t, "w:val"), Some("0" | "false")));
            let size = tag_at(rpr, "w:sz").and_then(|t| attr(t, "w:val")).map_or(base, |v| num(Some(v)) as f64 / 2.0);
            let color = tag_at(rpr, "w:color").and_then(|t| attr(t, "w:val")).and_then(hex);
            let mut text = String::new();
            let mut ta = 0;
            loop {
                let next = ["w:t", "w:tab", "w:br"].iter().filter_map(|n| find_open(r, n, ta).map(|i| (i, *n))).min();
                let Some((ts, n)) = next else { break };
                let open_end = ts + r[ts..].find('>').unwrap_or(0) + 1;
                match n {
                    "w:t" if !r[..open_end].ends_with("/>") => {
                        let te = r[open_end..].find("</w:t>").map_or(r.len(), |i| open_end + i);
                        text.push_str(&unescape(&r[open_end..te]));
                        ta = te;
                    }
                    "w:tab" => {
                        text.push('\t');
                        ta = open_end;
                    }
                    "w:br" => {
                        text.push('\n');
                        ta = open_end;
                    }
                    _ => ta = open_end,
                }
            }
            if !text.is_empty() {
                runs.push((text, size, on("w:b"), on("w:i"), color, tag_at(rpr, "w:u").is_some_and(|t| attr(t, "w:val") != Some("none"))));
            }
        }
        out.push(TextPara { runs, align });
    }
    out
}

pub(super) fn unescape(s: &str) -> String {
    s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")
}

/// Une forme (`wps:wsp`) ou une image (`pic:pic`) à (x, y, w, h).
pub(super) fn shape_elem(xml: &str, x: i64, y: i64, w: i64, h: i64, z: i64) -> Elem {
    let mut e = Elem { x, y, w, h, z, insets: [91_440, 45_720, 91_440, 45_720], ..Default::default() };
    let sp = element(xml, "wps:spPr").or_else(|| element(xml, "pic:spPr")).unwrap_or("");
    let style = element(xml, "wps:style").unwrap_or("");
    e.geom = tag_at(sp, "a:prstGeom").and_then(|t| attr(t, "prst")).unwrap_or("rect").to_string();
    if sp.contains("<a:custGeom") {
        e.paths = cust_paths(sp);
        if !e.paths.is_empty() {
            e.geom = "cust".into();
        }
    }
    if let Some(t) = tag_at(sp, "a:xfrm") {
        e.flip_h = attr(t, "flipH") == Some("1");
        e.flip_v = attr(t, "flipV") == Some("1");
        e.rot = num(attr(t, "rot")) as f64 / 60_000.0;
    }
    if xml.contains("<pic:pic") || xml.starts_with("<pic:") {
        e.geom = "pic".into();
        e.embed = tag_at(xml, "a:blip").and_then(|t| attr(t, "r:embed")).map(str::to_string);
        return e;
    }
    paint(sp, style, &mut e);
    if let Some(content) = element(xml, "w:txbxContent") {
        e.text = text_paras(content);
    }
    if let Some(b) = tag_at(xml, "wps:bodyPr") {
        for (i, k) in ["lIns", "tIns", "rIns", "bIns"].iter().enumerate() {
            if let Some(v) = attr(b, k) {
                e.insets[i] = num(Some(v));
            }
        }
        e.v_anchor = match attr(b, "anchor") {
            Some("ctr") => 1,
            Some("b") => 2,
            _ => 0,
        };
    }
    e
}

/// Les éléments d'un groupe (`wpg:wgp` ou `wpg:grpSp`), ramenés de son
/// repère intérieur (chOff, chExt) à (x, y, w, h).
pub(super) fn group_elems(g: &str, x: i64, y: i64, w: i64, h: i64, z: i64, out: &mut Vec<Elem>) {
    let gsp = element(g, "wpg:grpSpPr").unwrap_or("");
    let xf = tag_at(gsp, "a:chOff").map(|t| (num(attr(t, "x")), num(attr(t, "y")))).unwrap_or((0, 0));
    let ext = tag_at(gsp, "a:chExt").map(|t| (num(attr(t, "cx")), num(attr(t, "cy")))).unwrap_or((w, h));
    let (sx, sy) = (w as f64 / ext.0.max(1) as f64, h as f64 / ext.1.max(1) as f64);
    let map = |cx: i64, cy: i64| (x + ((cx - xf.0) as f64 * sx) as i64, y + ((cy - xf.1) as f64 * sy) as i64);
    // Les enfants directs, dans l'ordre (le dernier dessus).
    let inner_start = g.find('>').map_or(0, |i| i + 1);
    let mut at = inner_start;
    let mut k = 0;
    loop {
        let next = ["wps:wsp", "pic:pic", "wpg:grpSp"].iter().filter_map(|n| find_open(g, n, at).map(|i| (i, *n))).min();
        let Some((s, name)) = next else { break };
        let Some(e) = matching_close(g, name, s) else { break };
        at = e;
        let child = &g[s..e];
        let spr = if name == "wpg:grpSp" { element(child, "wpg:grpSpPr").unwrap_or("") } else { element(child, "wps:spPr").or_else(|| element(child, "pic:spPr")).unwrap_or("") };
        let off = tag_at(spr, "a:off").map(|t| (num(attr(t, "x")), num(attr(t, "y")))).unwrap_or((0, 0));
        let ex = tag_at(spr, "a:ext").map(|t| (num(attr(t, "cx")), num(attr(t, "cy")))).unwrap_or((0, 0));
        let (cx, cy) = map(off.0, off.1);
        let (cw, ch) = ((ex.0 as f64 * sx) as i64, (ex.1 as f64 * sy) as i64);
        k += 1;
        if name == "wpg:grpSp" {
            group_elems(child, cx, cy, cw, ch, z * 1000 + k, out);
        } else {
            out.push(shape_elem(child, cx, cy, cw, ch, z * 1000 + k));
        }
    }
}

/// Les blocs ancrés (formes, zones de texte, groupes, images) d'un
/// paragraphe du corps, hors zones de texte imbriquées.
pub(super) fn blocks_of(xml: &str, s: usize, e: usize, host: usize, para_y: i64, page_start: i64, margin: (i64, i64), col: i64) -> Vec<Block> {
    let p = &xml[s..e];
    let mut out = Vec::new();
    let mut at = 0;
    loop {
        let next = ["mc:AlternateContent", "w:drawing"].iter().filter_map(|n| find_open(p, n, at).map(|i| (i, *n))).min();
        let Some((bs, name)) = next else { break };
        let Some(be) = matching_close(p, name, bs) else { break };
        at = be;
        let block = &p[bs..be];
        // (un dessin dans une zone de texte d'un autre : laissé)
        if p[..bs].matches("<w:txbxContent").count() > p[..bs].matches("</w:txbxContent>").count() {
            continue;
        }
        let choice = if name == "mc:AlternateContent" { element(block, "mc:Choice").unwrap_or(block) } else { block };
        let Some(anchor) = element(choice, "wp:anchor") else { continue };
        let atag = &anchor[..anchor.find('>').unwrap_or(0)];
        let hblock = element(anchor, "wp:positionH").unwrap_or("");
        let vblock = element(anchor, "wp:positionV").unwrap_or("");
        let hrel = tag_at(hblock, "wp:positionH").and_then(|t| attr(t, "relativeFrom")).unwrap_or("column");
        let vrel = tag_at(vblock, "wp:positionV").and_then(|t| attr(t, "relativeFrom")).unwrap_or("paragraph");
        let ext = tag_at(anchor, "wp:extent");
        let (w, h) = (num(ext.and_then(|t| attr(t, "cx"))), num(ext.and_then(|t| attr(t, "cy"))));
        let mut x = num(text_of(hblock, "wp:posOffset"));
        match text_of(hblock, "wp:align").map(str::trim) {
            Some("center") => x = (col - w) / 2,
            Some("right" | "outside") => x = col - w,
            Some(_) => x = 0,
            None => {}
        }
        if matches!(hrel, "page" | "leftMargin") {
            x -= margin.0;
        }
        let off_v = num(text_of(vblock, "wp:posOffset"));
        let para_rel = matches!(vrel, "paragraph" | "line");
        let y = if para_rel { para_y + off_v } else { page_start + off_v - if vrel == "page" { margin.1 } else { 0 } };
        let behind = attr(atag, "behindDoc") == Some("1");
        let z = num(attr(atag, "relativeHeight")) + if behind { 0 } else { 1 << 40 };
        let mut elems = Vec::new();
        let pic = anchor.contains("<pic:pic") && !anchor.contains("<wps:") && !anchor.contains("<wpg:");
        if let Some(g) = element(anchor, "wpg:wgp") {
            group_elems(g, x, y, w, h, z, &mut elems);
        } else if let Some(wsp) = element(anchor, "wps:wsp") {
            elems.push(shape_elem(wsp, x, y, w, h, z));
        } else if let Some(pp) = element(anchor, "pic:pic") {
            elems.push(shape_elem(pp, x, y, w, h, z));
        } else {
            continue;
        }
        let drawn = elems.iter().any(|e| e.geom != "pic" && (e.text.iter().all(|t| t.runs.is_empty())) && visible(e));
        out.push(Block { start: s + bs, end: s + be, host, elems, pic, drawn, para_rel });
    }
    out
}

/// Une forme qui se voit sur une page blanche.
pub(super) fn visible(e: &Elem) -> bool {
    let white = |c: [u8; 3]| c == [255, 255, 255];
    e.fill.is_some_and(|c| !white(c)) || e.line.is_some_and(|(c, w, _)| !white(c) && w > 0.0)
}

pub(super) fn bbox(elems: &[Elem]) -> (i64, i64, i64, i64) {
    let x0 = elems.iter().map(|e| e.x).min().unwrap_or(0);
    let y0 = elems.iter().map(|e| e.y).min().unwrap_or(0);
    let x1 = elems.iter().map(|e| e.x + e.w).max().unwrap_or(0);
    let y1 = elems.iter().map(|e| e.y + e.h).max().unwrap_or(0);
    (x0, y0, x1, y1)
}

