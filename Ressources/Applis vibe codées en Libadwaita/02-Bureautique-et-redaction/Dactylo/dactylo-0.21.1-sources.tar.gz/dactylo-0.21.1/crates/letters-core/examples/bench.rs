//! Banc d'essai : lit un document, l'enregistre en .docx et en .odt, relit
//! chaque copie et signale ce qui a changé ; écrit aussi l'Aperçu en PDF.
//! Usage : bench <fichier> <dossier de sortie>
use letters_core::model::Document;
use std::path::Path;

fn summary(d: &Document) -> Vec<String> {
    d.paragraphs
        .iter()
        .map(|p| {
            let t: String = p.text().split_whitespace().collect::<Vec<_>>().join(" ");
            let img = p.runs.iter().filter(|r| r.style.image.is_some()).count();
            let cell = p.style.table_cell.map(|c| format!(" cell{}:{}:{} span{} v{} w{} h{} cov{}", c.table, c.row, c.col, c.span(), c.vmerge, c.width_tw / 20, c.height_tw / 20, c.covered as u8)).unwrap_or_default();
            let bx = match (p.style.shading, p.style.border) { (None, None) => String::new(), (s, b) => format!(" box{:?}{:?}", s, b.map(|b| (b.sides, b.width, b.color))) };
            format!("h{:?} l{:?}{}{}{} img{} | {}", p.style.heading, p.style.list, p.style.list_level, cell, bx, img, t)
        })
        .collect()
}

fn diff(a: &[String], b: &[String]) -> Vec<String> {
    let mut out = Vec::new();
    let n = a.len().max(b.len());
    for i in 0..n {
        let (x, y) = (a.get(i), b.get(i));
        if x != y {
            out.push(format!("  #{i}\n    avant : {}\n    après : {}", x.map_or("—", |s| s.as_str()), y.map_or("—", |s| s.as_str())));
            if out.len() >= 4 {
                out.push(format!("  … ({} paragraphes avant, {} après)", a.len(), b.len()));
                break;
            }
        }
    }
    out
}

fn main() {
    let a: Vec<String> = std::env::args().collect();
    let src = Path::new(&a[1]);
    let out = Path::new(&a[2]);
    let stem = src.file_stem().unwrap().to_string_lossy().to_string();
    let t0 = std::time::Instant::now();
    let doc = match letters_core::save::read(src) {
        Ok(d) => d,
        Err(e) => return println!("LECTURE ÉCHOUÉE : {e}"),
    };
    let s0 = summary(&doc);
    let words: usize = doc.paragraphs.iter().map(|p| p.text().split_whitespace().count()).sum();
    let tables = doc.paragraphs.iter().filter_map(|p| p.style.table_cell.map(|c| c.table)).collect::<std::collections::BTreeSet<_>>().len();
    let imgs: usize = doc.paragraphs.iter().map(|p| p.runs.iter().filter(|r| r.style.image.is_some()).count()).sum();
    println!("lu en {} ms : {} paragraphes, {} mots, {} tableaux, {} images, {} objets gardés", t0.elapsed().as_millis(), doc.paragraphs.len(), words, tables, imgs, doc.kept.len());
    std::fs::write(out.join(format!("{stem}.words")), doc.paragraphs.iter().map(|p| p.text()).collect::<Vec<_>>().join("\n")).ok();
    for ext in ["docx", "odt"] {
        let p = out.join(format!("{stem}.{ext}"));
        if let Err(e) = letters_core::save::write(&doc, &p) {
            println!("{ext} : ENREGISTREMENT ÉCHOUÉ : {e}");
            continue;
        }
        match letters_core::save::read(&p) {
            Err(e) => println!("{ext} : RELECTURE ÉCHOUÉE : {e}"),
            Ok(d2) => {
                let d = diff(&s0, &summary(&d2));
                if d.is_empty() {
                    println!("{ext} : aller-retour identique");
                } else {
                    println!("{ext} : DIFFÉRENCES\n{}", d.join("\n"));
                }
            }
        }
    }
    let ts = letters_core::layout::pango::Typeset::new(doc, Default::default());
    if let Err(e) = ts.write_pdf(out.join(format!("{stem}.pdf"))) {
        println!("PDF ÉCHOUÉ : {e}");
    }
}
