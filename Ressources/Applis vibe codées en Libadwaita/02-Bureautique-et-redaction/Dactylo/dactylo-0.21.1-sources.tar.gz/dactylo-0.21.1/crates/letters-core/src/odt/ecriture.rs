// ecriture.rs — partie de odt.rs, découpé par thème.
// SPDX-License-Identifier: GPL-3.0-or-later

#![allow(unused_imports)]
use super::*;
use crate::model::*;
use quick_xml::events::{BytesRef, BytesText, Event};
use quick_xml::Reader;
use std::io::Write;
use suite_common_core::zip_guard::{BoundedArchive, ZipBudget};

/// Collect the distinct run styles used, in first-use order.
pub(crate) fn collect_run_styles(doc: &Document) -> Vec<RunStyle> {
    let mut styles: Vec<RunStyle> = Vec::new();
    for p in &doc.paragraphs {
        for r in &p.runs {
            let style = RunStyle { revision: None, comments: Vec::new(), ..r.style.clone() };
            if style != RunStyle::default() && style.chip.is_none() && !styles.contains(&style) {
                styles.push(style);
            }
        }
    }
    styles
}

pub(crate) fn run_style_props(st: &RunStyle) -> String {
    let mut props = String::new();
    if st.bold {
        props.push_str(" fo:font-weight=\"bold\"");
    }
    if st.italic {
        props.push_str(" fo:font-style=\"italic\"");
    }
    if st.underline {
        props.push_str(" style:text-underline-style=\"solid\"");
    }
    if st.strikethrough {
        props.push_str(" style:text-line-through-style=\"solid\"");
    }
    if st.highlight {
        let hex = st.highlight_color.as_deref().unwrap_or("ffff00").to_lowercase();
        props.push_str(&format!(" fo:background-color=\"#{hex}\""));
    }
    if let Some(hp) = st.font_size_hp {
        props.push_str(&format!(" fo:font-size=\"{}pt\"", hp as f32 / 2.0));
    }
    if let Some(color) = &st.color {
        props.push_str(&format!(" fo:color=\"#{color}\""));
    }
    if let Some(va) = st.vert_align {
        let pos = match va {
            VertAlign::Superscript => "super 58%",
            VertAlign::Subscript => "sub 58%",
        };
        props.push_str(&format!(" style:text-position=\"{pos}\""));
    }
    if st.code {
        props.push_str(" style:font-name=\"Monospace\"");
    }
    if let Some(fam) = &st.font_family {
        props.push_str(&format!(" fo:font-family=\"{}\"", esc(fam)));
    }
    props
}

pub(crate) fn para_style_props(st: &ParaStyle) -> String {
    let mut props = String::new();
    match st.alignment {
        Alignment::Left => {}
        Alignment::Center => props.push_str(" fo:text-align=\"center\""),
        Alignment::Right => props.push_str(" fo:text-align=\"end\""),
        Alignment::Justify => props.push_str(" fo:text-align=\"justify\""),
    }
    if st.page_break_before {
        props.push_str(" fo:break-before=\"page\"");
    }
    if st.keep_with_next {
        props.push_str(" fo:keep-with-next=\"always\"");
    }
    // Samizdat : fond et bordure (des paragraphes voisins identiques
    // forment un seul cadre dans LibreOffice aussi).
    if let Some([r, g, b]) = st.shading {
        props.push_str(&format!(" fo:background-color=\"#{r:02x}{g:02x}{b:02x}\""));
    }
    if st.align_top {
        props.push_str(" style:vertical-align=\"top\"");
    }
    if let Some(bd) = st.border {
        let line = format!("{:.2}pt solid #{:02x}{:02x}{:02x}", f64::from(bd.width.max(2)) / 8.0, bd.color[0], bd.color[1], bd.color[2]);
        if bd.sides == crate::model::ParaBorder::ALL {
            props.push_str(&format!(" fo:border=\"{line}\""));
        } else {
            for (bit, side) in [(crate::model::ParaBorder::TOP, "top"), (crate::model::ParaBorder::BOTTOM, "bottom"), (crate::model::ParaBorder::LEFT, "left"), (crate::model::ParaBorder::RIGHT, "right")] {
                props.push_str(&format!(" fo:border-{side}=\"{}\"", if bd.sides & bit != 0 { line.as_str() } else { "none" }));
            }
        }
        props.push_str(" fo:padding=\"0.1cm\"");
    }
    if (st.line_spacing - 1.0).abs() > 0.01 {
        props.push_str(&format!(" fo:line-height=\"{:.0}%\"", st.line_spacing * 100.0));
    }
    // ODF spells paragraph spacing `fo:margin-top`/`fo:margin-bottom`,
    // the same XSL-FO properties the page geometry below already uses.
    // This wrote `fo:space-before`/`fo:space-after`, which our own reader
    // understood and LibreOffice does not: the self round trip passed
    // because both halves shared an attribute nothing else reads, and the
    // spacing was silently gone the moment the file reached Writer.
    if st.space_before_pt > 0.01 { props.push_str(&format!(" fo:margin-top=\"{:.2}pt\"", st.space_before_pt)); }
    if st.space_after_pt.abs() > 0.01 { props.push_str(&format!(" fo:margin-bottom=\"{:.2}pt\"", st.space_after_pt)); }
    if st.left_indent_pt.abs() > 0.01 { props.push_str(&format!(" fo:margin-left=\"{:.2}pt\"", st.left_indent_pt)); }
    if st.right_indent_pt.abs() > 0.01 { props.push_str(&format!(" fo:margin-right=\"{:.2}pt\"", st.right_indent_pt)); }
    if st.first_line_indent_pt.abs() > 0.01 { props.push_str(&format!(" fo:text-indent=\"{:.2}pt\"", st.first_line_indent_pt)); }
    props
}

/// Child elements of `style:paragraph-properties`, as opposed to its
/// attributes.
///
/// ODF puts tab stops in a `style:tab-stops` child rather than an
/// attribute, so a paragraph style carrying them cannot be written as a
/// self-closing element. Returns the empty string when there are none,
/// which keeps every other style exactly as it was.
pub(crate) fn para_style_children(st: &ParaStyle) -> String {
    if st.tab_stops_pt.is_empty() {
        return String::new();
    }
    let mut out = String::from("<style:tab-stops>");
    for pos in &st.tab_stops_pt {
        // `style:type` defaults to left, which is the only kind the model
        // has; a position is all a stop needs.
        out.push_str(&format!("<style:tab-stop style:position=\"{pos:.2}pt\"/>"));
    }
    out.push_str("</style:tab-stops>");
    out
}

/// An image run's picture as the package stores it (#1292): its member
/// name under `Pictures/`, named by a hash of its bytes so a picture used
/// twice is stored once, its bytes and its media type. None when the
/// source can't be read; the run is then written as its alt text, as the
/// docx writer does.
pub(crate) fn picture(src: &str) -> Option<(String, Vec<u8>, &'static str)> {
    use std::hash::{Hash, Hasher};
    let bytes = std::fs::read(src).ok()?;
    let ext = std::path::Path::new(src)
        .extension()
        .and_then(|e| e.to_str())
        .map(|e| e.to_ascii_lowercase())
        .unwrap_or_else(|| "png".into());
    let mime = match ext.as_str() {
        "png" => "image/png",
        "jpg" | "jpeg" => "image/jpeg",
        "gif" => "image/gif",
        "svg" => "image/svg+xml",
        "bmp" => "image/bmp",
        "webp" => "image/webp",
        "tif" | "tiff" => "image/tiff",
        _ => "application/octet-stream",
    };
    let mut h = std::collections::hash_map::DefaultHasher::new();
    bytes.hash(&mut h);
    Some((format!("Pictures/{:016x}.{ext}", h.finish()), bytes, mime))
}

/// EMU per inch (OOXML's unit, which the model keeps image sizes in).
pub(crate) const EMU_PER_INCH: f64 = 914_400.0;

/// The size an image run is drawn at, in EMU: the size it was shown at,
/// else a PNG's own pixels at 96 dpi, else 4in x 3in (the docx writer's
/// fallback).
pub(crate) fn picture_extent(run: &Run, bytes: &[u8]) -> (u64, u64) {
    if let Some(e) = run.style.image_extent_emu {
        return e;
    }
    if bytes.len() >= 24 && bytes.starts_with(b"\x89PNG\r\n\x1a\n") {
        let px = |at: usize| u32::from_be_bytes([bytes[at], bytes[at + 1], bytes[at + 2], bytes[at + 3]]) as u64;
        let (w, h) = (px(16), px(20));
        if w > 0 && h > 0 {
            return (w * 9525, h * 9525);
        }
    }
    (4 * 914_400, 3 * 914_400)
}

/// A table being written (#1296): its size and the cell being filled.
pub(crate) struct OpenTable {
    pub(crate) id: u32,
    pub(crate) rows: u32,
    pub(crate) cols: u32,
    pub(crate) row: u32,
    pub(crate) col: u32,
    /// Whether the current cell has a paragraph yet (ODF wants one).
    pub(crate) filled: bool,
    /// Samizdat : le style de ses cases (celui d'un cartouche).
    pub(crate) cell_style: String,
    /// Samizdat : la mise en forme de chaque case (largeur, fusion, fond…).
    pub(crate) props: Vec<crate::model::TableCell>,
    /// Le nom des styles automatiques propres à ce tableau (`Table3`).
    pub(crate) name: String,
    /// La case ouverte est une case masquée par une fusion.
    pub(crate) covered: bool,
}

impl OpenTable {
    fn prop(&self, row: u32, col: u32) -> Option<crate::model::TableCell> {
        self.props.iter().find(|c| c.row == row && c.col == col).copied()
    }

    /// La case courante : masquée (par une fusion) ou ordinaire, avec son
    /// étendue et son style.
    fn cell(&mut self) -> String {
        let p = self.prop(self.row, self.col).unwrap_or_default();
        self.covered = p.covered || p.vmerge == 2;
        if self.covered {
            return "<table:covered-table-cell>".to_string();
        }
        let mut extra = String::new();
        if p.span() > 1 {
            extra.push_str(&format!(" table:number-columns-spanned=\"{}\"", p.span()));
        }
        if p.vmerge == 1 {
            let mut n = 1;
            while self.prop(self.row + n, self.col).is_some_and(|c| c.vmerge == 2) {
                n += 1;
            }
            extra.push_str(&format!(" table:number-rows-spanned=\"{n}\""));
        }
        let style = if p.fill.is_some() || p.no_border { format!("{}.{}.{}", self.name, self.row, self.col) } else { self.cell_style.clone() };
        format!("<table:table-cell table:style-name=\"{style}\" office:value-type=\"string\"{extra}>")
    }

    fn row_open(&self) -> String {
        match self.prop(self.row, 0).filter(|c| c.height_tw > 0) {
            Some(_) => format!("<table:table-row table:style-name=\"{}.R{}\">", self.name, self.row),
            None => "<table:table-row>".to_string(),
        }
    }

    /// Ses styles automatiques : colonnes, lignes, cases.
    fn styles(&self) -> String {
        let mut out = String::new();
        let widths: Vec<Option<u32>> = (0..self.cols)
            .map(|c| self.props.iter().find(|t| t.col == c && !t.covered && t.span() == 1 && t.width_tw > 0).map(|t| t.width_tw))
            .collect();
        if self.cols > 0 && widths.iter().all(Option::is_some) {
            for (c, w) in widths.iter().enumerate() {
                out.push_str(&format!(
                    "<style:style style:name=\"{}.C{c}\" style:family=\"table-column\"><style:table-column-properties style:column-width=\"{:.2}pt\"/></style:style>",
                    self.name,
                    f64::from(w.unwrap_or(0)) / 20.0
                ));
            }
        }
        for r in 0..self.rows {
            if let Some(c) = self.prop(r, 0).filter(|c| c.height_tw > 0) {
                let key = if c.height_exact { "style:row-height" } else { "style:min-row-height" };
                out.push_str(&format!(
                    "<style:style style:name=\"{}.R{r}\" style:family=\"table-row\"><style:table-row-properties {key}=\"{:.2}pt\"/></style:style>",
                    self.name,
                    f64::from(c.height_tw) / 20.0
                ));
            }
        }
        for c in self.props.iter().filter(|c| !c.covered && (c.fill.is_some() || c.no_border)) {
            let border = if c.no_border { "none" } else { "0.5pt solid #808080" };
            let bg = c.fill.map(|[r, g, b]| format!(" fo:background-color=\"#{r:02X}{g:02X}{b:02X}\"")).unwrap_or_default();
            out.push_str(&format!(
                "<style:style style:name=\"{}.{}.{}\" style:family=\"table-cell\"><style:table-cell-properties fo:border=\"{border}\" fo:padding=\"0.1cm\"{bg}/></style:style>",
                self.name, c.row, c.col
            ));
        }
        out
    }

    /// Les colonnes, avec leur largeur si elle est connue.
    fn columns(&self) -> String {
        if self.styles().contains("table-column\"") {
            (0..self.cols).map(|c| format!("<table:table-column table:style-name=\"{}.C{c}\"/>", self.name)).collect()
        } else {
            format!("<table:table-column table:number-columns-repeated=\"{}\"/>", self.cols)
        }
    }

    fn close_cell(&mut self, body: &mut String) {
        if !self.filled && !self.covered {
            body.push_str("<text:p/>");
        }
        body.push_str(if self.covered { "</table:covered-table-cell>" } else { "</table:table-cell>" });
    }

    /// Move to cell (row, col), closing the ones before it; a paragraph
    /// out of grid order stays in the current cell.
    fn move_to(&mut self, body: &mut String, row: u32, col: u32) {
        while (self.row, self.col) < (row, col) && self.row < self.rows {
            self.close_cell(body);
            if self.col + 1 < self.cols {
                self.col += 1;
            } else {
                body.push_str("</table:table-row>");
                self.row += 1;
                self.col = 0;
                if self.row == self.rows {
                    return;
                }
                body.push_str(&self.row_open());
            }
            let cell = self.cell();
            body.push_str(&cell);
            self.filled = false;
        }
    }

    fn close(mut self, body: &mut String) {
        let (last_row, last_col) = (self.rows - 1, self.cols - 1);
        self.move_to(body, last_row, last_col);
        if self.row < self.rows {
            self.close_cell(body);
            body.push_str("</table:table-row>");
        }
        body.push_str("</table:table>");
    }
}

pub(crate) fn content_xml(doc: &Document) -> String {
    let run_styles = collect_run_styles(doc);
    let mut pictures_written = 0usize;

    let mut auto = String::new();
    for (i, st) in run_styles.iter().enumerate() {
        auto.push_str(&format!(
            "<style:style style:name=\"T{}\" style:family=\"text\">\
             <style:text-properties{}/></style:style>",
            i + 1,
            run_style_props(st)
        ));
    }
    // Samizdat : le style de case de chaque allure de cartouche employée.
    let mut looks: Vec<crate::model::Cartouche> = Vec::new();
    for p in &doc.paragraphs {
        if p.style.table_cell.is_some() {
            let look = p.style.cartouche.unwrap_or_default();
            if !looks.contains(&look) {
                looks.push(look);
            }
        }
    }
    for look in looks {
        let border = if look.line_pt() > 0.0 {
            format!("{:.2}pt solid #{}", look.line_pt(), crate::model::Cartouche::LINE_HEX)
        } else {
            "none".to_string()
        };
        auto.push_str(&format!(
            "<style:style style:name=\"{}\" style:family=\"table-cell\"><style:table-cell-properties fo:border=\"{border}\" \
             fo:background-color=\"#{}\" fo:padding-top=\"{p}pt\" fo:padding-bottom=\"{p}pt\" fo:padding-left=\"{s}pt\" fo:padding-right=\"{s}pt\"/></style:style>",
            look.name(),
            look.fill_hex(),
            p = crate::layout::BOX_PADDING_PT,
            s = crate::layout::CELL_PADDING_PT,
        ));
    }
    // Samizdat : des lignes numérotées ; chaque paragraphe dit s'il l'est.
    let numbered = doc.paragraphs.iter().any(|p| p.style.line_numbers);
    // Paragraph automatic styles: one per used (alignment, break) combo.
    let mut para_autos: Vec<(String, String, Option<u8>)> = Vec::new();
    let mut para_style_idx: Vec<Option<usize>> = Vec::new();
    for p in &doc.paragraphs {
        let mut props = para_style_props(&p.style);
        if numbered {
            props.push_str(if p.style.line_numbers { " text:number-lines=\"true\"" } else { " text:number-lines=\"false\"" });
        }
        let kids = para_style_children(&p.style);
        if props.is_empty() && kids.is_empty() {
            para_style_idx.push(None);
            continue;
        }
        // Keyed on the whole element: two paragraphs share a style only
        // when their attributes *and* their tab stops match. A heading's
        // inherits its level's look (#1297).
        let parent = p.style.heading.filter(|_| p.style.named_style.is_none() && p.style.toc.is_none());
        let elem = (props, kids, parent);
        let pos = para_autos.iter().position(|x| *x == elem).unwrap_or_else(|| {
            para_autos.push(elem.clone());
            para_autos.len() - 1
        });
        para_style_idx.push(Some(pos));
    }
    for (i, (props, kids, parent)) in para_autos.iter().enumerate() {
        let body = if kids.is_empty() {
            format!("<style:paragraph-properties{props}/>")
        } else {
            format!("<style:paragraph-properties{props}>{kids}</style:paragraph-properties>")
        };
        let parent = parent.map(|n| format!(" style:parent-style-name=\"Heading_20_{n}\"")).unwrap_or_default();
        auto.push_str(&format!(
            "<style:style style:name=\"P{}\" style:family=\"paragraph\"{parent}>{}</style:style>",
            i + 1,
            body
        ));
    }
    // Every level of both lists: a nested item takes its level's style,
    // and a level a style doesn't define draws unindented and unmarked.
    let bullets = ["•", "◦", "▪"];
    let level_props = |level: usize| {
        let indent = crate::lists::text_indent_pt(level as u8);
        format!(
            "<style:list-level-properties text:list-level-position-and-space-mode=\"label-alignment\">\
             <style:list-level-label-alignment text:label-followed-by=\"listtab\" fo:text-indent=\"-{h}pt\" fo:margin-left=\"{indent}pt\"/>\
             </style:list-level-properties>",
            h = crate::lists::HANGING_PT,
        )
    };
    auto.push_str("<text:list-style style:name=\"LB\">");
    for level in 0..10 {
        auto.push_str(&format!(
            "<text:list-level-style-bullet text:level=\"{}\" text:bullet-char=\"{}\">{}</text:list-level-style-bullet>",
            level + 1, bullets[level % bullets.len()], level_props(level)
        ));
    }
    auto.push_str("</text:list-style><text:list-style style:name=\"LN\">");
    for level in 0..10 {
        auto.push_str(&format!(
            "<text:list-level-style-number text:level=\"{}\" style:num-format=\"1\" style:num-suffix=\".\">{}</text:list-level-style-number>",
            level + 1, level_props(level)
        ));
    }
    auto.push_str("</text:list-style>");

    let mut body = String::new();
    // Tracked changes: one changed region per change (text:tracked-changes).
    let mut regions: Vec<String> = Vec::new();
    // Comment threads: an annotation (with its replies) where a thread's
    // text starts, an annotation end where it ends; a thread with no text
    // is an annotation without an end, first.
    let roots = crate::docx_comments::roots(doc);
    let mut open: Vec<u32> = Vec::new();
    let mut orphans: Vec<u32> = {
        let marked: std::collections::HashSet<u32> = doc.paragraphs.iter().flat_map(|p| &p.runs).flat_map(|r| r.style.comments.iter().copied()).collect();
        roots.iter().copied().filter(|id| !marked.contains(id)).collect()
    };
    let wanted = |run: &Run| -> Vec<u32> { crate::docx_comments::threads_of(&roots, &run.style.comments).collect() };
    let annotate = |id: u32, start: bool| -> String {
        let thread = doc.comments.iter().filter(|c| c.id == id || c.parent == Some(id));
        if start {
            thread.map(annotation_xml).collect()
        } else {
            thread.map(|c| format!("<office:annotation-end office:name=\"__Annotation__{}\"/>", c.id)).collect()
        }
    };
    // List grouping: consecutive items of one kind share one text:list,
    // and an item at level n sits in a text:list nested n deep (#1205: the
    // writer used to put every level in one flat list, so a nested item
    // came back at the top level). `depth` lists are open, each with an
    // open item.
    let mut open_list = ListKind::None;
    let mut depth = 0usize;
    // Tables: consecutive paragraphs of one table id are its cells, in
    // grid order, as the docx writer groups them (#1296).
    let mut table: Option<OpenTable> = None;
    let mut tables_written = 0u32;
    let mut table_auto = String::new();
    for (pi, p) in doc.paragraphs.iter().enumerate() {
        let cell = p.style.table_cell;
        let here = table.as_ref().map(|t| (t.id, t.row, t.col));
        if cell.map(|c| (c.table, c.row, c.col)) != here {
            // Lists don't cross a cell boundary.
            body.push_str(&"</text:list-item></text:list>".repeat(depth));
            depth = 0;
            open_list = ListKind::None;
            if table.as_ref().is_some_and(|t| cell.map(|c| c.table) != Some(t.id)) {
                table.take().expect("checked").close(&mut body);
            }
            if let Some(c) = cell {
                if table.is_none() {
                    let group = doc.paragraphs[pi..].iter().map_while(|q| q.style.table_cell.filter(|qc| qc.table == c.table));
                    let (rows, cols) = group.fold((0, 0), |(r, k), qc| (r.max(qc.row + 1), k.max(qc.col + 1)));
                    tables_written += 1;
                    let cell_style = if (rows, cols) == (1, 1) { p.style.cartouche.unwrap_or_default().name() } else { "DactyloCell".to_string() };
                    let props = doc.paragraphs[pi..].iter().map_while(|q| q.style.table_cell.filter(|qc| qc.table == c.table)).collect();
                    let mut t = OpenTable { id: c.table, rows, cols, row: 0, col: 0, filled: false, cell_style, props, name: format!("Table{tables_written}"), covered: false };
                    table_auto.push_str(&t.styles());
                    let (columns, row, cell) = (t.columns(), t.row_open(), t.cell());
                    body.push_str(&format!("<table:table table:name=\"Table{tables_written}\">{columns}{row}{cell}"));
                    table = Some(t);
                }
                if let Some(t) = table.as_mut() {
                    t.move_to(&mut body, c.row, c.col);
                }
            }
        }
        if let Some(t) = table.as_mut() {
            t.filled = true;
        }
        let kind = p.style.list;
        if kind != open_list {
            body.push_str(&"</text:list-item></text:list>".repeat(depth));
            depth = 0;
            open_list = kind;
        }
        if kind != ListKind::None {
            let target = usize::from(p.style.list_level) + 1;
            let start = p.style.list_start.map(|n| format!(" text:start-value=\"{n}\"")).unwrap_or_default();
            if depth == 0 {
                let style = if kind == ListKind::Numbered { "LN" } else { "LB" };
                body.push_str(&format!("<text:list text:style-name=\"{style}\">"));
                depth = 1;
                if target == 1 {
                    body.push_str(&format!("<text:list-item{start}>"));
                } else {
                    body.push_str("<text:list-item>");
                }
            } else {
                while depth > target {
                    body.push_str("</text:list-item></text:list>");
                    depth -= 1;
                }
                if depth == target {
                    body.push_str(&format!("</text:list-item><text:list-item{start}>"));
                }
            }
            while depth < target {
                depth += 1;
                let attr = if depth == target { start.as_str() } else { "" };
                body.push_str(&format!("<text:list><text:list-item{attr}>"));
            }
        }

        // LO built-in named styles win over our automatic styles; the
        // names (Title, Subtitle, Quotations) are ODF/LO conventions.
        let style_attr = if let Some(level) = p.style.toc {
            format!(" text:style-name=\"Contents_20_{}\"", level.clamp(1, 10))
        } else if let Some(name) = &p.style.named_style {
            format!(" text:style-name=\"{}\"", esc(name))
        } else if p.style.block_quote {
            " text:style-name=\"Quotations\"".to_string()
        } else if p.style.code_block.is_some() && p.style.heading.is_none() {
            " text:style-name=\"Preformatted_20_Text\"".to_string()
        } else {
            match (para_style_idx[pi], p.style.heading) {
                (Some(i), _) => format!(" text:style-name=\"P{}\"", i + 1),
                (None, Some(n)) => format!(" text:style-name=\"Heading_20_{n}\""),
                (None, None) => String::new(),
            }
        };

        let mut inner = String::new();
        for id in std::mem::take(&mut orphans) {
            inner.push_str(&annotate(id, true));
        }
        for r in &p.runs {
            for (id, start) in crate::docx_comments::transition(&mut open, &wanted(r)) {
                inner.push_str(&annotate(id, start));
            }
            // A picture is a frame anchored as a character, so it stays
            // where it is in the line; its bytes are in Pictures/ (#1292).
            if let Some(src) = &r.style.image {
                match picture(src) {
                    Some((name, bytes, _)) => {
                        pictures_written += 1;
                        let (w, h) = picture_extent(r, &bytes);
                        let title = if r.text.trim().is_empty() { String::new() } else { format!("<svg:title>{}</svg:title>", esc(&r.text)) };
                        // Samizdat : une image flottante, ancrée au paragraphe, le texte à côté.
                        let anchor = match r.style.image_float {
                            Some(crate::model::ImageFloat::Left) => "draw:style-name=\"DactyloFloatLeft\" text:anchor-type=\"paragraph\"",
                            Some(crate::model::ImageFloat::Right) => "draw:style-name=\"DactyloFloatRight\" text:anchor-type=\"paragraph\"",
                            None => "text:anchor-type=\"as-char\"",
                        };
                        inner.push_str(&format!(
                            "<draw:frame draw:name=\"Picture {pictures_written}\" {anchor} \
                             svg:width=\"{:.6}in\" svg:height=\"{:.6}in\">\
                             <draw:image xlink:href=\"{name}\" xlink:type=\"simple\" xlink:show=\"embed\" xlink:actuate=\"onLoad\"/>\
                             {title}</draw:frame>",
                            w as f64 / EMU_PER_INCH,
                            h as f64 / EMU_PER_INCH,
                        ));
                    }
                    None => inner.push_str(&esc(&r.text)),
                }
                continue;
            }
            // A footnote reference is an element, not text: ODF puts the
            // note's whole body inline at the reference point, and the
            // consumer renders the citation and the note area itself. The
            // run's own text carries nothing (the docx writer likewise
            // writes a reference and drops it), so it is not escaped in.
            if let Some(idx) = r.style.footnote {
                if let Some(text) = doc.footnotes.get(idx) {
                    let n = idx + 1;
                    inner.push_str(&format!(
                        "<text:note text:id=\"ftn{n}\" text:note-class=\"footnote\">\
                         <text:note-citation>{n}</text:note-citation>\
                         <text:note-body><text:p>{}</text:p></text:note-body>\
                         </text:note>",
                        esc(text)
                    ));
                }
                continue;
            }
            // A smart chip: a date is a fixed date field, which LibreOffice
            // and Word keep as a date; a link or person chip is its link,
            // named so it reopens as a chip.
            if let Some(chip) = &r.style.chip {
                inner.push_str(&chip_xml(chip, &r.text, r.style.link.as_deref()));
                continue;
            }
            // A tab is an element in ODF: a raw one is only whitespace.
            let mut run_xml = esc(&r.text).replace('\t', "<text:tab/>").replace('\u{2028}', "<text:line-break/>");
            let plain = RunStyle { revision: None, comments: Vec::new(), ..r.style.clone() };
            if plain != RunStyle::default() {
                let ti = run_styles.iter().position(|s| *s == plain).unwrap() + 1;
                run_xml = format!("<text:span text:style-name=\"T{ti}\">{run_xml}</text:span>");
            }
            // Inline code as Writer's "Source Text" (#1205): the monospace
            // font alone named a face the file never declared, so Writer
            // dropped it and the run came back as plain text.
            if r.style.code {
                run_xml = format!("<text:span text:style-name=\"Source_20_Text\">{run_xml}</text:span>");
            }
            if let Some(href) = &r.style.link {
                run_xml = format!(
                    "<text:a xlink:type=\"simple\" xlink:href=\"{}\">{}</text:a>",
                    esc(href),
                    run_xml
                );
            }
            match &r.style.revision {
                None => inner.push_str(&run_xml),
                Some(rev) => inner.push_str(&tracked_xml(&mut regions, rev, &run_xml)),
            }
        }

        // The threads the next paragraph's text is not in end here.
        let next: Vec<u32> = doc.paragraphs.get(pi + 1).and_then(|n| n.runs.first()).map(wanted).unwrap_or_default();
        let keep: Vec<u32> = open.iter().copied().filter(|id| next.contains(id)).collect();
        for (id, start) in crate::docx_comments::transition(&mut open, &keep) {
            inner.push_str(&annotate(id, start));
        }
        // A table of contents: LibreOffice's index, whose source says how
        // to regenerate it (headings 1-3: text, a dotted right tab, the
        // page), around the entries.
        let toc_at = |k: usize| doc.paragraphs.get(k).is_some_and(|q| q.style.toc.is_some());
        if p.style.toc.is_some() && (pi == 0 || !toc_at(pi - 1)) {
            body.push_str(&toc_open());
        }
        if let Some(level) = p.style.heading {
            body.push_str(&format!(
                "<text:h text:outline-level=\"{level}\"{style_attr}>{inner}</text:h>"
            ));
        } else {
            body.push_str(&format!("<text:p{style_attr}>{inner}</text:p>"));
        }
        if p.style.toc.is_some() && !toc_at(pi + 1) {
            body.push_str("</text:index-body></text:table-of-content>");
        }
    }
    body.push_str(&"</text:list-item></text:list>".repeat(depth));
    if let Some(t) = table.take() {
        t.close(&mut body);
    }
    let changes = if regions.is_empty() {
        String::new()
    } else {
        format!("<text:tracked-changes text:track-changes=\"false\">{}</text:tracked-changes>", regions.concat())
    };

    format!(
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\
         <office:document-content \
         xmlns:office=\"urn:oasis:names:tc:opendocument:xmlns:office:1.0\" \
         xmlns:text=\"urn:oasis:names:tc:opendocument:xmlns:text:1.0\" \
         xmlns:style=\"urn:oasis:names:tc:opendocument:xmlns:style:1.0\" \
         xmlns:fo=\"urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0\" \
         xmlns:xlink=\"http://www.w3.org/1999/xlink\" \
         xmlns:draw=\"urn:oasis:names:tc:opendocument:xmlns:drawing:1.0\" \
         xmlns:table=\"urn:oasis:names:tc:opendocument:xmlns:table:1.0\" \
         xmlns:svg=\"urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0\" \
         xmlns:loext=\"urn:org:documentfoundation:names:experimental:office:xmlns:loext:1.0\" \
         xmlns:dc=\"http://purl.org/dc/elements/1.1/\" \
         office:version=\"1.2\">\
         <office:font-face-decls>\
         <style:font-face style:name=\"Monospace\" \
         svg:font-family=\"&apos;Liberation Mono&apos;, monospace\" \
         style:font-family-generic=\"modern\" style:font-pitch=\"fixed\"/>\
         </office:font-face-decls>\
         <office:automatic-styles><style:style style:name=\"DactyloCell\" style:family=\"table-cell\"><style:table-cell-properties fo:border=\"0.5pt solid #808080\" fo:padding=\"0.1cm\"/></style:style>\
         <style:style style:name=\"DactyloFloatLeft\" style:family=\"graphic\"><style:graphic-properties style:wrap=\"right\" style:number-wrapped-paragraphs=\"no-limit\" fo:margin-right=\"0.32cm\" style:vertical-pos=\"top\" style:vertical-rel=\"paragraph\" style:horizontal-pos=\"left\" style:horizontal-rel=\"paragraph\"/></style:style>\
         <style:style style:name=\"DactyloFloatRight\" style:family=\"graphic\"><style:graphic-properties style:wrap=\"left\" style:number-wrapped-paragraphs=\"no-limit\" fo:margin-left=\"0.32cm\" style:vertical-pos=\"top\" style:vertical-rel=\"paragraph\" style:horizontal-pos=\"right\" style:horizontal-rel=\"paragraph\"/></style:style>{auto}{table_auto}</office:automatic-styles>\
         <office:body><office:text>{changes}{body}</office:text></office:body>\
         </office:document-content>"
    )
}

/// A table of contents index's start: how to regenerate it, then its body.
pub(crate) fn toc_open() -> String {
    let templates: String = (1..=crate::toc::LEVELS)
        .map(|n| {
            format!(
                "<text:table-of-content-entry-template text:outline-level=\"{n}\" text:style-name=\"Contents_20_{n}\"><text:index-entry-text/><text:index-entry-tab-stop style:type=\"right\" style:leader-char=\".\"/><text:index-entry-page-number/></text:table-of-content-entry-template>"
            )
        })
        .collect();
    format!(
        "<text:table-of-content text:name=\"Table of Contents1\"><text:table-of-content-source text:outline-level=\"{}\">{templates}</text:table-of-content-source><text:index-body>",
        crate::toc::LEVELS
    )
}

/// The "Contents 1".."Contents 10" paragraph styles a table of contents'
/// entries name: each level indented one step more, with a dotted right
/// tab at the text column's edge for the page number.
pub(crate) fn contents_styles(doc: &Document) -> String {
    let g = doc.page.unwrap_or_default();
    let width = g.width_pt - g.margin_left_pt - g.margin_right_pt;
    (1..=10u8)
        .map(|n| {
            let indent = crate::toc::INDENT_PT * f64::from(n - 1);
            format!(
                "<style:style style:name=\"Contents_20_{n}\" style:display-name=\"Contents {n}\" style:family=\"paragraph\" style:class=\"index\"><style:paragraph-properties fo:margin-left=\"{indent:.2}pt\" fo:margin-right=\"0pt\" fo:text-indent=\"0pt\"><style:tab-stops><style:tab-stop style:position=\"{:.2}pt\" style:type=\"right\" style:leader-style=\"dotted\" style:leader-text=\".\"/></style:tab-stops></style:paragraph-properties></style:style>",
                width - indent
            )
        })
        .collect()
}

/// A comment as an ODF annotation; a reply names its thread as
/// LibreOffice does (`loext:parent-name`).
pub(crate) fn annotation_xml(c: &crate::model::Comment) -> String {
    let parent = c.parent.map(|p| format!(" loext:parent-name=\"__Annotation__{p}\"")).unwrap_or_default();
    let paras: String = c.text.split('\n').map(|l| format!("<text:p>{}</text:p>", esc(l))).collect();
    format!(
        "<office:annotation office:name=\"__Annotation__{}\"{parent} loext:resolved=\"{}\"><dc:creator>{}</dc:creator><dc:date>{}</dc:date>{paras}</office:annotation>",
        c.id,
        c.resolved,
        esc(&c.author),
        esc(&c.date)
    )
}

/// A centered paragraph style for a header or footer that numbers the
/// pages (`layout::page_field_alignment`).
pub(crate) const PAGE_NUMBER_STYLE: &str = "<style:style style:name=\"Dactylo_20_Page_20_Number\" style:display-name=\"Dactylo Page Number\" style:family=\"paragraph\"><style:paragraph-properties fo:text-align=\"center\"/></style:style>";

pub(crate) fn page_number_style(text: &str) -> &'static str {
    if text.contains("{page}") { " text:style-name=\"Dactylo_20_Page_20_Number\"" } else { "" }
}

/// Samizdat : un en-tête ou un pied de page, une ligne par paragraphe ; une
/// ligne en zones (« gauche\tcentre\tdroite ») prend le style à taquets.
pub(crate) fn page_lines(text: &str) -> String {
    text.split('\n')
        .map(|l| {
            let style = if l.contains('\t') { " text:style-name=\"Dactylo_20_Zones\"" } else { page_number_style(l) };
            format!("<text:p{style}>{}</text:p>", page_fields(&esc(l)).replace('\t', "<text:tab/>"))
        })
        .collect()
}

/// Samizdat : le style des lignes en zones, un taquet centré au milieu du
/// texte et un taquet droit à sa fin.
pub(crate) fn zones_style(doc: &Document) -> String {
    let width = doc.page.as_ref().map_or(481.89, |g| g.width_pt - g.margin_left_pt - g.margin_right_pt);
    format!(
        "<style:style style:name=\"Dactylo_20_Zones\" style:display-name=\"Dactylo Zones\" style:family=\"paragraph\"><style:paragraph-properties><style:tab-stops>\
         <style:tab-stop style:position=\"{:.2}pt\" style:type=\"center\"/><style:tab-stop style:position=\"{:.2}pt\" style:type=\"right\"/>\
         </style:tab-stops></style:paragraph-properties></style:style>",
        width / 2.0,
        width
    )
}

/// "{page}" and "{total}" in escaped header or footer text as ODF's page
/// number and page count fields.
pub(crate) fn page_fields(text: &str) -> String {
    text.replace("{page}", "<text:page-number text:select-page=\"current\">1</text:page-number>")
        .replace("{total}", "<text:page-count>1</text:page-count>")
}

/// A tracked change's body markup: the run between change marks for an
/// insertion, a change mark alone for a deletion (whose text goes into its
/// region, as ODF keeps deleted text out of the body). The region is added
/// to `regions`. A deletion of someone else's insertion is one region with
/// the deletion and then the insertion it deleted, as LibreOffice writes it.
pub(crate) fn tracked_xml(regions: &mut Vec<String>, rev: &crate::model::Revision, run_xml: &str) -> String {
    let id = format!("ct{}", regions.len() + 1);
    let info_of = |r: &crate::model::Revision| {
        format!(
            "<office:change-info><dc:creator>{}</dc:creator><dc:date>{}</dc:date></office:change-info>",
            esc(&r.author),
            esc(&r.date)
        )
    };
    let info = info_of(rev);
    let under = rev.under.as_deref().map(|u| format!("<text:insertion>{}</text:insertion>", info_of(u))).unwrap_or_default();
    let (region, body) = match rev.kind {
        crate::model::RevisionKind::Insert => (
            format!("<text:insertion>{info}</text:insertion>"),
            format!("<text:change-start text:change-id=\"{id}\"/>{run_xml}<text:change-end text:change-id=\"{id}\"/>"),
        ),
        crate::model::RevisionKind::Delete => (
            format!("<text:deletion>{info}<text:p>{run_xml}</text:p></text:deletion>{under}"),
            format!("<text:change text:change-id=\"{id}\"/>"),
        ),
    };
    regions.push(format!("<text:changed-region xml:id=\"{id}\" text:id=\"{id}\">{region}</text:changed-region>"));
    body
}

/// A smart chip's ODF: LibreOffice's own content control
/// (`loext:content-control`, what Writer makes of a Word content control),
/// tagged with what the chip is, holding its label (inside its link for a
/// link or person). A date chip is also a date control, so Writer shows a
/// date picker and saves it to .docx as a Word date control. A reader that
/// does not know the element still shows its text.
pub(crate) fn chip_xml(chip: &crate::chips::Chip, label: &str, link: Option<&str>) -> String {
    use crate::chips::ChipKind;
    let kind = match chip.kind {
        ChipKind::Date => "date",
        ChipKind::Person => "person",
        ChipKind::Link => "link",
    };
    let date = match chip.kind {
        ChipKind::Date => format!(
            " loext:date=\"true\" loext:date-format=\"d MMM yyyy\" loext:date-rfc-language-tag=\"en-GB\" loext:current-date=\"{}T00:00:00Z\"",
            esc(&chip.value)
        ),
        _ => String::new(),
    };
    let inner = match link {
        Some(href) => format!("<text:a xlink:type=\"simple\" xlink:href=\"{}\">{}</text:a>", esc(href), esc(label)),
        None => esc(label),
    };
    format!(
        "<loext:content-control loext:tag=\"{}\"{date}>{inner}</loext:content-control>",
        esc(&format!("{CHIP_NAME_PREFIX}{kind}:{}", chip.value))
    )
}

pub(crate) fn styles_xml(doc: &Document) -> String {
    let layout = match &doc.page {
        Some(pg) => format!(
            "<style:page-layout-properties \
             fo:page-width=\"{:.2}pt\" fo:page-height=\"{:.2}pt\" \
             fo:margin-top=\"{:.2}pt\" fo:margin-bottom=\"{:.2}pt\" \
             fo:margin-left=\"{:.2}pt\" fo:margin-right=\"{:.2}pt\">\
             <style:columns fo:column-count=\"{}\" fo:column-gap=\"{:.2}pt\"/>\
             </style:page-layout-properties>",
            pg.width_pt, pg.height_pt, pg.margin_top_pt, pg.margin_bottom_pt,
            pg.margin_left_pt, pg.margin_right_pt, pg.columns.max(1), pg.column_gap_pt
        ),
        None => "<style:page-layout-properties/>".to_string(),
    };
    let mut hf = String::new();
    if doc.header.is_some() || doc.footer.is_some() {
        hf.push_str("<office:master-styles><style:master-page style:name=\"Standard\" style:page-layout-name=\"pm1\">");
        if let Some(h) = &doc.header {
            hf.push_str(&format!("<style:header>{}</style:header>", page_lines(h)));
        }
        if let Some(f) = &doc.footer {
            hf.push_str(&format!("<style:footer>{}</style:footer>", page_lines(f)));
        }
        hf.push_str("</style:master-page></office:master-styles>");
    } else {
        hf.push_str("<office:master-styles><style:master-page style:name=\"Standard\" style:page-layout-name=\"pm1\"/></office:master-styles>");
    }
    // Samizdat : une ligne sur cinq, de nouveau à 1 à chaque page.
    let numbering = if doc.paragraphs.iter().any(|p| p.style.line_numbers) {
        "<text:linenumbering-configuration text:number-lines=\"true\" text:increment=\"5\" text:restart-on-page=\"true\" \
         text:number-position=\"left\" text:offset=\"0.3cm\" style:num-format=\"1\" text:count-empty-lines=\"false\"/>"
    } else {
        ""
    };
    format!(
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\
         <office:document-styles \
         xmlns:office=\"urn:oasis:names:tc:opendocument:xmlns:office:1.0\" \
         xmlns:text=\"urn:oasis:names:tc:opendocument:xmlns:text:1.0\" \
         xmlns:style=\"urn:oasis:names:tc:opendocument:xmlns:style:1.0\" \
         xmlns:fo=\"urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0\" \
         xmlns:svg=\"urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0\" \
         office:version=\"1.2\">{faces}\
         <office:styles>{base}{contents}{numbering}</office:styles>\
         <office:automatic-styles>\
         <style:page-layout style:name=\"pm1\">{layout}\
         </style:page-layout></office:automatic-styles>{hf}\
         </office:document-styles>",
        faces = base_font_faces(doc),
        base = base_font_style(doc),
        contents = CODE_STYLES.to_string()
            + CAPTION_STYLE
            + PAGE_NUMBER_STYLE
            + &zones_style(doc)
            + &heading_styles(doc)
            + &if doc.paragraphs.iter().any(|p| p.style.toc.is_some()) { contents_styles(doc) } else { String::new() }
    )
}

/// `Heading_20_1`..`6`, the styles headings name (#1297): the document's
/// own heading look if it has one, else Letters' (bold, scaled from the
/// body size), as the docx writer does. The odt used to carry no heading
/// look at all.
pub(crate) fn heading_styles(doc: &Document) -> String {
    let base_hp = doc.base_font.size_hp.unwrap_or((crate::layout::LayoutOptions::default().font_size_pt * 2.0) as u16);
    (1u8..=6)
        .map(|n| {
            let look = doc.heading_styles.get(usize::from(n) - 1).cloned().unwrap_or_else(|| RunStyle {
                bold: true,
                font_size_hp: Some((f64::from(base_hp) * crate::layout::heading_scale(n)).round() as u16),
                ..Default::default()
            });
            let look = RunStyle { font_size_hp: look.font_size_hp.or(Some(base_hp)), ..look };
            format!(
                "<style:style style:name=\"Heading_20_{n}\" style:display-name=\"Heading {n}\" style:family=\"paragraph\" \
                 style:default-outline-level=\"{n}\" style:class=\"text\"><style:paragraph-properties fo:keep-with-next=\"always\"/>\
                 <style:text-properties{}/></style:style>",
                run_style_props(&look)
            )
        })
        .collect()
}

/// Writer's code block and inline code styles, which code paragraphs and
/// runs name (#1205). Writer drops a reference to a spaced built-in name
/// ("Preformatted Text") that the file doesn't define, so a code block
/// came back from Writer as plain text.
/// Légende d'image : centrée, droite (sans l'italique de la « Caption » de
/// LibreOffice).
pub(crate) const CAPTION_STYLE: &str = "<style:style style:name=\"Caption\" style:family=\"paragraph\" style:parent-style-name=\"Standard\" style:class=\"extra\"><style:paragraph-properties fo:text-align=\"center\"/><style:text-properties fo:font-style=\"normal\" fo:font-size=\"11pt\"/></style:style>";

pub(crate) const CODE_STYLES: &str = "<style:style style:name=\"Preformatted_20_Text\" style:display-name=\"Preformatted Text\" \
     style:family=\"paragraph\" style:class=\"html\"><style:paragraph-properties fo:margin-top=\"0pt\" fo:margin-bottom=\"0pt\"/>\
     <style:text-properties fo:font-family=\"'Liberation Mono'\" fo:font-size=\"10pt\"/></style:style>\
     <style:style style:name=\"Source_20_Text\" style:display-name=\"Source Text\" style:family=\"text\">\
     <style:text-properties fo:font-family=\"'Liberation Mono'\"/></style:style>";

pub(crate) const MANIFEST: &str = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\
<manifest:manifest xmlns:manifest=\"urn:oasis:names:tc:opendocument:xmlns:manifest:1.0\" manifest:version=\"1.2\">\
<manifest:file-entry manifest:full-path=\"/\" manifest:media-type=\"application/vnd.oasis.opendocument.text\"/>\
<manifest:file-entry manifest:full-path=\"content.xml\" manifest:media-type=\"text/xml\"/>\
<manifest:file-entry manifest:full-path=\"styles.xml\" manifest:media-type=\"text/xml\"/>\
</manifest:manifest>";

/// Write the document as .odt. Built fully in memory, then placed
/// atomically (see suite_common_core::atomic_save) — a rename before the
/// ZipWriter flushes its central directory would leave a corrupt archive.
pub fn write(doc: &Document, path: impl AsRef<std::path::Path>) -> Result<(), String> {
    let buf = std::io::Cursor::new(Vec::new());
    let mut z = zip::ZipWriter::new(buf);
    // Per ODF spec the mimetype entry comes first and uncompressed.
    z.start_file(
        "mimetype",
        zip::write::SimpleFileOptions::default().compression_method(zip::CompressionMethod::Stored),
    )
    .map_err(|e| e.to_string())?;
    z.write_all(MIMETYPE.as_bytes()).map_err(|e| e.to_string())?;
    let opt = zip::write::SimpleFileOptions::default();
    // Every readable picture once, in the order the document uses them.
    let mut pictures: Vec<(String, Vec<u8>, &'static str)> = Vec::new();
    for src in doc.paragraphs.iter().flat_map(|p| &p.runs).filter_map(|r| r.style.image.as_deref()) {
        if let Some(pic) = picture(src).filter(|pic| !pictures.iter().any(|seen| seen.0 == pic.0)) {
            pictures.push(pic);
        }
    }
    let entries: String = pictures
        .iter()
        .map(|(name, _, mime)| format!("<manifest:file-entry manifest:full-path=\"{name}\" manifest:media-type=\"{mime}\"/>"))
        .collect();
    z.start_file("META-INF/manifest.xml", opt).map_err(|e| e.to_string())?;
    z.write_all(MANIFEST.replace("</manifest:manifest>", &format!("{entries}</manifest:manifest>")).as_bytes()).map_err(|e| e.to_string())?;
    for (name, bytes, _) in &pictures {
        z.start_file(name.as_str(), opt).map_err(|e| e.to_string())?;
        z.write_all(bytes).map_err(|e| e.to_string())?;
    }
    z.start_file("content.xml", opt).map_err(|e| e.to_string())?;
    z.write_all(content_xml(doc).as_bytes()).map_err(|e| e.to_string())?;
    z.start_file("styles.xml", opt).map_err(|e| e.to_string())?;
    z.write_all(styles_xml(doc).as_bytes()).map_err(|e| e.to_string())?;
    let bytes = z.finish().map_err(|e| e.to_string())?.into_inner();
    suite_common_core::atomic_save::atomic_write_bytes(path.as_ref(), &bytes)
}

/// Write an ODT while preserving package members captured by
/// [`read_with_report`].
pub fn write_with_opaque(doc: &Document, path: impl AsRef<std::path::Path>, opaque: &suite_common_core::interop::OpaquePackage) -> Result<(), String> {
    let path = path.as_ref();
    write(doc, path)?;
    opaque.append_to(path)
}

// ── Reading ──────────────────────────────────────────────────────────

/// Samizdat : la police et la taille de base du document (le style par
/// défaut des paragraphes), que l'odt ne portait pas — LibreOffice
/// rouvrait le texte dans sa propre police.
pub(crate) fn base_font_faces(doc: &Document) -> String {
    match doc.base_font.family.as_deref() {
        Some(f) => {
            let f = xml_attr(f);
            format!("<office:font-face-decls><style:font-face style:name=\"{f}\" svg:font-family=\"&apos;{f}&apos;\"/></office:font-face-decls>")
        }
        None => String::new(),
    }
}

pub(crate) fn base_font_style(doc: &Document) -> String {
    let mut props = String::new();
    if let Some(f) = doc.base_font.family.as_deref() {
        props.push_str(&format!(" style:font-name=\"{}\"", xml_attr(f)));
    }
    if let Some(hp) = doc.base_font.size_hp {
        props.push_str(&format!(" fo:font-size=\"{}pt\"", f64::from(hp) / 2.0));
    }
    if props.is_empty() {
        return String::new();
    }
    format!("<style:default-style style:family=\"paragraph\"><style:text-properties{props}/></style:default-style>")
}

pub(crate) fn xml_attr(s: &str) -> String {
    s.replace('&', "&amp;").replace('"', "&quot;").replace('<', "&lt;").replace('\'', "&apos;")
}
