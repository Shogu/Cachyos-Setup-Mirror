// SPDX-License-Identifier: GPL-3.0-or-later
// Un metteur en forme sans police, aux mesures exactes (tests, mise en page sans polices).

use super::*;

/// A font-free shaper with exact, predictable metrics: every char is
/// `0.5 × size` wide, a line is `size` ascent plus `0.25 × size` descent,
/// breaks fall at spaces (greedy), headings are scaled by `heading_scale`.
/// For tests of the engine, and for layout without fonts.
#[derive(Clone, Debug, Default)]
pub struct MonoShaper;

impl MonoShaper {
    fn size(req: &ShapeRequest<'_>, run: Option<&Run>) -> f64 {
        let base = match req.heading {
            Some(l) => req.defaults.heading_size_pt(l),
            None => req.defaults.font_size_pt * req.look.scale(),
        };
        run.and_then(|r| r.style.font_size_hp).map_or(base, |hp| f64::from(hp) / 2.0)
    }
}

impl Shaper for MonoShaper {
    fn shape(&mut self, req: &ShapeRequest<'_>) -> Vec<LineBox> {
        // Flatten to (char, advance, ascent); an image is one char.
        let chars: Vec<(char, f64, f64)> = req
            .runs
            .iter()
            .flat_map(|r| -> Vec<(char, f64, f64)> {
                let s = Self::size(req, Some(r));
                if r.style.image.is_some() {
                    let (w, h) = if r.style.image_float.is_some() { (0.0, 0.0) } else { image_size_pt(r, req.width_pt) };
                    vec![(OBJECT, w, h)]
                } else if let Some(n) = r.style.footnote {
                    let digits = (n + 1).to_string().len() as f64;
                    vec![(OBJECT, digits * s * NOTE_REF_SCALE * 0.5, 0.0)]
                } else if r.style.chip.is_some() {
                    let w = r.text.chars().count() as f64 * s * 0.5 + 2.0 * (CHIP_PAD_PT + CHIP_GAP_PT);
                    vec![(OBJECT, w, s)]
                } else {
                    r.text.chars().map(|c| (c, s * 0.5, s)).collect()
                }
            })
            .collect();
        let empty_size = Self::size(req, req.runs.first());
        let line = |start: usize, end: usize, width: f64, indent: f64| {
            let ascent = chars[start..end].iter().map(|c| c.2).fold(0.0, f64::max);
            let ascent = if ascent > 0.0 { ascent } else { empty_size };
            let text_size = chars[start..end].iter().filter(|c| c.0 != OBJECT).map(|c| c.2).fold(0.0, f64::max);
            let size = if text_size > 0.0 { text_size } else { empty_size };
            let free = (req.width_pt - indent - width).max(0.0);
            let align = match req.alignment {
                crate::model::Alignment::Center => free / 2.0,
                crate::model::Alignment::Right => free,
                _ => 0.0,
            };
            let mut x = indent + align;
            let mut objects = Vec::new();
            for (k, c) in chars.iter().enumerate().take(end).skip(start) {
                if c.0 == OBJECT {
                    objects.push((k, x));
                }
                x += c.1;
            }
            LineBox { start, end, x_pt: indent + align, width_pt: width, ascent_pt: ascent, descent_pt: size * 0.25, objects }
        };
        let mut out = Vec::new();
        let mut start = 0;
        while start < chars.len() || out.is_empty() {
            let indent = if out.is_empty() { req.first_line_indent_pt } else { 0.0 };
            let avail = req.width_pt - indent;
            let mut w = 0.0;
            let mut end = start;
            let mut last_break: Option<usize> = None;
            while end < chars.len() {
                let cw = chars[end].1;
                if w + cw > avail + 1e-9 && end > start {
                    break;
                }
                w += cw;
                if chars[end].0 == ' ' {
                    last_break = Some(end + 1);
                }
                end += 1;
            }
            if end < chars.len() {
                if let Some(b) = last_break {
                    end = b;
                }
            }
            // Trailing spaces hang past the edge and take no width.
            let ink_end = (start..end).rev().find(|&k| chars[k].0 != ' ').map_or(start, |k| k + 1);
            let width: f64 = chars[start..ink_end].iter().map(|c| c.1).sum();
            out.push(line(start, end, width, indent));
            if end == start {
                break;
            }
            start = end;
        }
        out
    }
}
