// tableaux.rs — partie de odt.rs, découpé par thème.
// SPDX-License-Identifier: GPL-3.0-or-later

#![allow(unused_imports)]
use super::*;
use crate::model::*;
use quick_xml::events::{BytesRef, BytesText, Event};
use quick_xml::Reader;
use std::io::Write;
use suite_common_core::zip_guard::{BoundedArchive, ZipBudget};

/// Samizdat : la mise en forme d'une colonne, d'une ligne ou d'une case de
/// tableau, lue dans les styles automatiques.
#[derive(Clone, Copy, Debug, Default)]
pub(crate) struct TableStyle {
    pub(crate) width_tw: u32,
    pub(crate) height_tw: u32,
    pub(crate) exact: bool,
    pub(crate) fill: Option<[u8; 3]>,
    pub(crate) no_border: bool,
}

pub(crate) fn length_tw(v: &str) -> u32 {
    length_emu(v).map_or(0, |emu| (emu / 635) as u32)
}

pub(crate) fn table_styles(xml: &str) -> std::collections::HashMap<String, TableStyle> {
    let mut out = std::collections::HashMap::new();
    let mut reader = Reader::from_str(xml);
    let mut name: Option<String> = None;
    loop {
        match reader.read_event() {
            Ok(Event::Start(e)) | Ok(Event::Empty(e)) => match e.name().as_ref() {
                "style:style" => name = attr_val(&e, "style:name"),
                "style:table-column-properties" => {
                    if let (Some(n), Some(w)) = (name.clone(), attr_val(&e, "style:column-width")) {
                        out.entry(n).or_insert_with(TableStyle::default).width_tw = length_tw(&w);
                    }
                }
                "style:table-row-properties" => {
                    if let Some(n) = name.clone() {
                        let st = out.entry(n).or_insert_with(TableStyle::default);
                        if let Some(h) = attr_val(&e, "style:row-height") {
                            st.height_tw = length_tw(&h);
                            st.exact = true;
                        } else if let Some(h) = attr_val(&e, "style:min-row-height") {
                            st.height_tw = length_tw(&h);
                        }
                    }
                }
                "style:table-cell-properties" => {
                    if let Some(n) = name.clone() {
                        let st = out.entry(n).or_insert_with(TableStyle::default);
                        st.fill = attr_val(&e, "fo:background-color").and_then(|c| {
                            let h = c.trim_start_matches('#');
                            let b = |i: usize| h.get(i..i + 2).and_then(|x| u8::from_str_radix(x, 16).ok());
                            Some([b(0)?, b(2)?, b(4)?]).filter(|c| *c != [255, 255, 255])
                        });
                        let sides = ["fo:border", "fo:border-top", "fo:border-bottom", "fo:border-left", "fo:border-right"];
                        st.no_border = !sides.iter().any(|k| attr_val(&e, k).is_some_and(|v| !v.trim().starts_with("none") && !v.trim().is_empty()));
                    }
                }
                _ => {}
            },
            Ok(Event::End(e)) if e.name().as_ref() == "style:style" => name = None,
            Ok(Event::Eof) | Err(_) => break,
            _ => {}
        }
    }
    out
}

pub(crate) fn odt_column(e: &quick_xml::events::BytesStart<'_>, styles: &std::collections::HashMap<String, TableStyle>, cols: &mut Vec<u32>) {
    let n = attr_val(e, "table:number-columns-repeated").and_then(|v| v.parse::<usize>().ok()).unwrap_or(1).min(512);
    let w = attr_val(e, "table:style-name").and_then(|s| styles.get(&s)).map_or(0, |s| s.width_tw);
    cols.extend(std::iter::repeat_n(w, n));
}

/// La mise en forme d'une case : étendue, largeur, hauteur de sa ligne,
/// fond, bordure.
pub(crate) fn odt_cell(
    e: &quick_xml::events::BytesStart<'_>,
    styles: &std::collections::HashMap<String, TableStyle>,
    cols: &[u32],
    (height_tw, height_exact): (u32, bool),
    (table, row, col, _, _): (u32, i64, i64, usize, bool),
    vspan: &mut std::collections::HashMap<(u32, u32), u32>,
) -> crate::model::TableCell {
    let (row, col) = (row.max(0) as u32, col.max(0) as u32);
    let mut c = crate::model::TableCell { table, row, col, height_tw, height_exact, ..Default::default() };
    let num = |k: &str| attr_val(e, k).and_then(|v| v.parse::<u32>().ok()).unwrap_or(1).max(1);
    if e.name().as_ref() == "table:covered-table-cell" {
        // Sous une case fusionnée vers le bas, ou à droite d'une case
        // fusionnée en largeur.
        if vspan.get(&(table, col)).is_some_and(|&last| row <= last) {
            c.vmerge = 2;
            // Width and fill follow the cell above.
            c.width_tw = cols.get(col as usize).copied().unwrap_or(0);
        } else {
            c.covered = true;
        }
        return c;
    }
    let span = num("table:number-columns-spanned");
    let rows = num("table:number-rows-spanned");
    c.span = span as u16;
    let range = (col as usize)..((col + span) as usize).min(cols.len());
    c.width_tw = cols.get(range).map_or(0, |w| if w.contains(&0) { 0 } else { w.iter().sum() });
    if rows > 1 {
        c.vmerge = 1;
        for k in col..col + span {
            vspan.insert((table, k), row + rows - 1);
        }
    }
    if let Some(st) = attr_val(e, "table:style-name").and_then(|s| styles.get(&s)) {
        c.fill = st.fill;
        c.no_border = st.no_border;
    }
    c
}
