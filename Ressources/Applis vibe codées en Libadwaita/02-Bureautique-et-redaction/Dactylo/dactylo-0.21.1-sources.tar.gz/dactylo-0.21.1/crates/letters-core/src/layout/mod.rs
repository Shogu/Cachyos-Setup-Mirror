// layout — the Letters page layout engine (ADR 0010).
// SPDX-License-Identifier: GPL-3.0-or-later
//
// Input: a `Document`. Output: a `RenderTree` — pages, and on each page
// positioned lines, list markers, table cell boxes, header and footer —
// in points from the page's top-left corner. Screen, print, PDF and
// thumbnails all draw this one tree, so they cannot disagree about where
// a line or a page break is.
//
// Text shaping (fonts, line breaking, glyph metrics) is behind the
// `Shaper` trait. The engine itself is pure arithmetic over line boxes:
// it decides where each paragraph goes, never how its glyphs look. The
// production shaper is Pango (`layout::pango`, feature `render`); tests use
// `MonoShaper`, whose metrics are exact and font-free.

use serde::{Deserialize, Serialize};

use crate::lists;
use crate::model::{Document, ListKind, PageGeometry, Paragraph, Run};

#[cfg(feature = "render")]
pub mod pango;
mod flottants;
mod mono;
mod tableaux;

pub use flottants::paragraph_from;
use flottants::{shape_beside, Float, FLOAT_GAP_PT};
pub use mono::MonoShaper;
use tableaux::layout_table;

/// Text defaults a document does not spell out itself.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct LayoutOptions {
    /// Page size and margins when the document has none.
    pub page: PageGeometry,
    /// Body font family when a run names none.
    pub font_family: String,
    /// Body font size in points when a run names none.
    pub font_size_pt: f64,
    /// Lines kept together at the foot (orphans) and head (widows) of a
    /// paragraph split across pages. 2 is Word's and LibreOffice's default.
    pub orphans: usize,
    pub widows: usize,
    /// Distance of the header's top from the page's top edge, and of the
    /// footer's bottom from the bottom edge (Word's default: 0.5in).
    pub header_distance_pt: f64,
    pub footer_distance_pt: f64,
    /// The document's heading looks (levels 1–6), if it has its own.
    #[serde(default)]
    pub heading_styles: Vec<crate::model::RunStyle>,
}

impl LayoutOptions {
    /// The document's own look for heading `level`, if it has one.
    pub fn heading_style(&self, level: u8) -> Option<&crate::model::RunStyle> {
        self.heading_styles.get(usize::from(level.clamp(1, 6)) - 1)
    }

    /// Size in points of heading `level`'s text.
    pub fn heading_size_pt(&self, level: u8) -> f64 {
        match self.heading_style(level).and_then(|h| h.font_size_hp) {
            Some(hp) => f64::from(hp) / 2.0,
            None if self.heading_style(level).is_some() => self.font_size_pt,
            None => self.font_size_pt * heading_scale(level),
        }
    }

    /// These options with the document's own body font where it names one.
    /// `layout` applies it; a renderer re-shaping paragraphs must use the
    /// same result.
    pub fn for_document(&self, doc: &Document) -> LayoutOptions {
        let mut o = self.clone();
        if let Some(family) = &doc.base_font.family {
            o.font_family = family.clone();
        }
        if let Some(hp) = doc.base_font.size_hp.filter(|hp| *hp > 0) {
            o.font_size_pt = f64::from(hp) / 2.0;
        }
        o.heading_styles.clone_from(&doc.heading_styles);
        o
    }
}

impl Default for LayoutOptions {
    fn default() -> Self {
        Self {
            page: PageGeometry::default(),
            font_family: "Liberation Serif".into(),
            font_size_pt: 12.0,
            orphans: 2,
            widows: 2,
            header_distance_pt: 36.0,
            footer_distance_pt: 36.0,
            heading_styles: Vec::new(),
        }
    }
}

/// What a shaper is asked to break into lines: one paragraph's runs at a
/// given width.
#[derive(Clone, Debug)]
pub struct ShapeRequest<'a> {
    pub runs: &'a [Run],
    /// Heading level 1–6, which scales and weights the text.
    pub heading: Option<u8>,
    /// Code block: monospace.
    pub code: bool,
    /// Title, Subtitle or block quote, which have looks of their own.
    pub look: Look,
    pub alignment: crate::model::Alignment,
    /// Width available to the lines, in points.
    pub width_pt: f64,
    /// Extra indent of the first line (negative = hanging), in points.
    pub first_line_indent_pt: f64,
    /// Tab stops in points from the text box's left edge.
    pub tab_stops_pt: Vec<f64>,
    /// A table of contents entry: its tab is one right-aligned stop at the
    /// box's right edge, so the page number sits at the margin (the
    /// painter draws the dot leader).
    pub right_tab: bool,
    pub defaults: &'a LayoutOptions,
}

/// One line of a shaped paragraph.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct LineBox {
    /// Char range of the paragraph's text on this line.
    pub start: usize,
    pub end: usize,
    /// Left edge of the ink box relative to the text box (alignment and
    /// first-line indent included).
    pub x_pt: f64,
    pub width_pt: f64,
    /// Natural (single-spaced) extents above and below the baseline.
    pub ascent_pt: f64,
    pub descent_pt: f64,
    /// Inline objects (images) on this line: their char index in the
    /// layout text and left edge relative to the text box.
    #[serde(default)]
    pub objects: Vec<(usize, f64)>,
}

impl LineBox {
    pub fn natural_height(&self) -> f64 {
        self.ascent_pt + self.descent_pt
    }
}

/// Breaks paragraphs into lines. Must return at least one line, also for an
/// empty paragraph (whose line has the height of its font).
pub trait Shaper {
    fn shape(&mut self, req: &ShapeRequest<'_>) -> Vec<LineBox>;
}

/// A key identifying everything a shaper's result depends on: the runs and
/// their styles, the paragraph's formatting and the width. Two requests
/// with one key shape identically.
pub fn request_key(req: &ShapeRequest<'_>) -> u64 {
    use std::hash::{Hash, Hasher};
    let mut h = std::collections::hash_map::DefaultHasher::new();
    format!("{:?}", req.runs).hash(&mut h);
    (req.heading, req.code, req.look, format!("{:?}", req.alignment)).hash(&mut h);
    (req.width_pt.to_bits(), req.first_line_indent_pt.to_bits()).hash(&mut h);
    req.tab_stops_pt.iter().map(|t| t.to_bits()).collect::<Vec<_>>().hash(&mut h);
    req.right_tab.hash(&mut h);
    (&req.defaults.font_family, req.defaults.font_size_pt.to_bits()).hash(&mut h);
    if let Some(level) = req.heading {
        format!("{:?}", req.defaults.heading_style(level)).hash(&mut h);
    }
    h.finish()
}

/// Shaped paragraphs kept between layouts: an edit re-shapes only the
/// paragraphs it changed, and the rest of the relayout is arithmetic.
/// Entries not used by the latest layout are dropped (`prune`), so the cache
/// holds one document's worth.
#[derive(Default)]
pub struct ShapeCache {
    entries: std::collections::HashMap<u64, Vec<LineBox>>,
    used: std::collections::HashSet<u64>,
    /// Requests shaped (not found in the cache) since the last `prune`.
    pub misses: usize,
}

impl ShapeCache {
    /// Forget entries the last layout did not use; reset the miss count.
    pub fn prune(&mut self) {
        let used = std::mem::take(&mut self.used);
        self.entries.retain(|k, _| used.contains(k));
        self.misses = 0;
    }

    /// Keys of the entries kept.
    pub fn keys(&self) -> impl Iterator<Item = &u64> {
        self.entries.keys()
    }
}

/// A shaper that answers from `cache` when it can.
pub struct Cached<'a> {
    pub shaper: &'a mut dyn Shaper,
    pub cache: &'a mut ShapeCache,
}

impl Shaper for Cached<'_> {
    fn shape(&mut self, req: &ShapeRequest<'_>) -> Vec<LineBox> {
        let key = request_key(req);
        self.cache.used.insert(key);
        if let Some(lines) = self.cache.entries.get(&key) {
            return lines.clone();
        }
        self.cache.misses += 1;
        let lines = self.shaper.shape(req);
        self.cache.entries.insert(key, lines.clone());
        lines
    }
}

/// `layout`, re-shaping only what `cache` does not already hold. After an
/// edit to one paragraph, that is the one paragraph (and its neighbour when
/// a heading looks ahead).
pub fn relayout(doc: &Document, opts: &LayoutOptions, shaper: &mut dyn Shaper, cache: &mut ShapeCache) -> RenderTree {
    layout(doc, opts, &mut Cached { shaper, cache })
}

/// Where a line's text comes from.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum Source {
    /// `Document::paragraphs[i]`, body text or a table cell.
    Paragraph(usize),
    Header,
    Footer,
    /// Footnote `Document::footnotes[i]`, at the foot of its page
    /// (`note_paragraph`).
    Footnote(usize),
}

/// A positioned element of a page. Coordinates are points from the page's
/// top-left corner.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum Item {
    /// Line `line` of the shaped `source`, drawn with its text box's left
    /// edge at `box_x_pt` (the line's own `x_pt` offset is inside it) and
    /// its baseline at `baseline_pt`. `box_width_pt` is the width it was
    /// shaped at, which a renderer needs to reproduce the same breaks.
    Line {
        source: Source,
        line: usize,
        start: usize,
        end: usize,
        text: String,
        box_x_pt: f64,
        box_width_pt: f64,
        x_pt: f64,
        top_pt: f64,
        baseline_pt: f64,
        height_pt: f64,
        /// Samizdat : le texte a été mis en lignes à partir de ce caractère
        /// du paragraphe (`paragraph_from`) : la suite d'un paragraphe qui
        /// longeait une image flottante, à pleine largeur. `line` compte
        /// depuis là. 0 = tout le paragraphe.
        #[serde(default)]
        from: usize,
    },
    /// A list item's marker ("•", "3."), in the item's first-line font.
    Marker { para: usize, text: String, x_pt: f64, baseline_pt: f64 },
    /// An inline image, `src` as the model names it, in its box.
    Image { para: usize, src: String, x_pt: f64, y_pt: f64, width_pt: f64, height_pt: f64 },
    /// A smart chip: its run's object char `ch` in paragraph `para`, drawn
    /// as a pill from `x_pt` on the line's baseline (the painter shapes its
    /// label, as the shaper measured it).
    Chip { para: usize, ch: usize, x_pt: f64, baseline_pt: f64 },
    /// A footnote reference: its run's object char `ch` in paragraph
    /// `para`, drawn as the note's superscript number from `x_pt`.
    NoteRef { para: usize, ch: usize, x_pt: f64, baseline_pt: f64 },
    /// The short rule above a page's footnotes.
    Rule { x_pt: f64, y_pt: f64, width_pt: f64 },
    /// Samizdat : le fond et la bordure d'un paragraphe encadré ou grisé
    /// (dessiné sous ses lignes). `top`/`bottom` : les traits du haut et du
    /// bas (absents entre deux paragraphes du même cadre).
    ParaBox {
        x_pt: f64,
        y_pt: f64,
        width_pt: f64,
        height_pt: f64,
        fill: Option<[u8; 3]>,
        border: Option<crate::model::ParaBorder>,
        top: bool,
        bottom: bool,
    },
    /// A table cell's border box.
    Cell {
        table: u32,
        row: u32,
        col: u32,
        x_pt: f64,
        y_pt: f64,
        width_pt: f64,
        height_pt: f64,
        /// Samizdat : fond de la case (RVB).
        #[serde(default)]
        fill: Option<[u8; 3]>,
        /// Samizdat : trait autour de la case.
        #[serde(default = "yes")]
        rule: bool,
    },
}

fn yes() -> bool {
    true
}

/// One page of the render tree.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct Page {
    pub index: usize,
    pub width_pt: f64,
    pub height_pt: f64,
    pub geometry: PageGeometry,
    pub items: Vec<Item>,
}

impl Page {
    /// The body lines on this page, in order: what a reader sees.
    pub fn lines(&self) -> impl Iterator<Item = &Item> {
        self.items.iter().filter(|i| matches!(i, Item::Line { source: Source::Paragraph(_), .. }))
    }
}

/// The laid-out document.
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
pub struct RenderTree {
    pub pages: Vec<Page>,
}

/// Where each page sits when the pages are stacked top to bottom with a
/// gap before each and after the last (the Print Layout view), at a scale
/// in pixels per point (#1282).
///
/// The tops are prefix sums, so finding the pages in a band, or the page
/// nearest a point, is a binary search: the view once re-summed every page
/// above each page it placed, which cost a 500-page document a quarter of a
/// million additions per frame and per pointer motion.
#[derive(Clone, Debug, Default)]
pub struct PageStack {
    /// `tops[i]`: the top of page `i`.
    tops: Vec<f64>,
    sizes: Vec<(f64, f64)>,
    gap: f64,
}

impl PageStack {
    pub fn new(sizes: Vec<(f64, f64)>, gap: f64) -> Self {
        let mut tops = Vec::with_capacity(sizes.len());
        let mut at = gap;
        for &(_, h) in &sizes {
            tops.push(at);
            at += h + gap;
        }
        PageStack { tops, sizes, gap }
    }

    pub fn len(&self) -> usize {
        self.sizes.len()
    }

    pub fn is_empty(&self) -> bool {
        self.sizes.is_empty()
    }

    /// Top of page `index` (the end of the stack past the last page).
    pub fn top(&self, index: usize) -> f64 {
        self.tops.get(index).copied().unwrap_or_else(|| self.height())
    }

    /// Width and height of page `index`, or zero past the last.
    pub fn size(&self, index: usize) -> (f64, f64) {
        self.sizes.get(index).copied().unwrap_or((0.0, 0.0))
    }

    /// The whole stack's height, gaps included.
    pub fn height(&self) -> f64 {
        self.tops.last().map_or(self.gap, |&t| t + self.sizes.last().map_or(0.0, |s| s.1) + self.gap)
    }

    /// The pages any part of which is in `top..=bottom`, as placed by a
    /// view that floors each page's top to a whole pixel.
    pub fn visible(&self, top: f64, bottom: f64) -> std::ops::Range<usize> {
        let first = self.first(|i| self.bottom(i) >= top);
        let end = self.first(|i| self.tops[i].floor() > bottom);
        first..end.max(first)
    }

    /// Bottom edge of page `i` as placed (its top floored).
    fn bottom(&self, i: usize) -> f64 {
        self.tops[i].floor() + self.sizes[i].1
    }

    /// The first page for which `past` holds, `past` being false for every
    /// page before some point and true from it on; `len()` if none.
    fn first(&self, past: impl Fn(usize) -> bool) -> usize {
        let (mut lo, mut hi) = (0, self.len());
        while lo < hi {
            let mid = lo + (hi - lo) / 2;
            if past(mid) { hi = mid } else { lo = mid + 1 }
        }
        lo
    }

    /// The page nearest widget `y` (a point between pages belongs to the
    /// nearer one, ties to the earlier), or `None` with no pages.
    pub fn nearest(&self, y: f64) -> Option<usize> {
        if self.is_empty() {
            return None;
        }
        let distance = |i: usize| {
            let (top, h) = (self.tops[i].floor(), self.sizes[i].1);
            if y < top { top - y } else if y > top + h { y - top - h } else { 0.0 }
        };
        // The first page whose bottom reaches y; y is in it, in the gap
        // above it, or past the last page.
        let i = self.first(|i| self.bottom(i) >= y).min(self.len() - 1);
        if i > 0 && distance(i - 1) <= distance(i) { Some(i - 1) } else { Some(i) }
    }
}

impl RenderTree {
    /// Where each page starts, as a character offset in `doc`'s text
    /// (paragraphs joined by one newline, `Document::paragraph_offset`):
    /// the first body line on the page (#1280). Print Layout, printing and
    /// PDF export all draw this tree, so these are their page breaks; a
    /// page with no body line of its own starts where the previous ended.
    pub fn page_breaks(&self, doc: &crate::model::Document) -> Vec<usize> {
        let mut out: Vec<usize> = Vec::with_capacity(self.pages.len());
        for page in &self.pages {
            let first = page.items.iter().find_map(|i| match i {
                Item::Line { source: Source::Paragraph(p), start, .. } => Some(doc.paragraph_offset(*p) + start),
                _ => None,
            });
            let previous = out.last().copied().unwrap_or(0);
            out.push(first.unwrap_or(previous).max(previous));
        }
        out
    }

    /// The pages stacked at `scale` px per point with `gap` px between.
    pub fn page_stack(&self, scale: f64, gap: f64) -> PageStack {
        PageStack::new(self.pages.iter().map(|p| (p.width_pt * scale, p.height_pt * scale)).collect(), gap)
    }

    /// The page holding the first line of paragraph `para`, if any.
    pub fn page_of_paragraph(&self, para: usize) -> Option<usize> {
        self.pages.iter().position(|p| {
            p.items.iter().any(|i| matches!(i, Item::Line { source: Source::Paragraph(q), .. } if *q == para))
        })
    }
}

/// The object replacement character: an inline image's one char in the
/// layout text.
pub const OBJECT: char = '\u{FFFC}';

/// Whether a run is an inline object (an image, a footnote reference or a
/// smart chip): one `OBJECT` char in the layout and edit sequence, whatever
/// its text.
pub fn is_object(run: &Run) -> bool {
    run.style.image.is_some() || run.style.footnote.is_some() || run.style.chip.is_some()
}

/// Space around a smart chip's label, in points: horizontal padding inside
/// the pill, and the gap kept outside it on each side.
pub const CHIP_PAD_PT: f64 = 4.0;
pub const CHIP_GAP_PT: f64 = 1.5;

/// A paragraph's text as the layout sees it: every inline object (image,
/// footnote reference) is one `OBJECT` char (the model keeps an image's alt
/// text as the run's text, and a footnote reference has none). Line char
/// ranges, `pango::TextPos` and `edit`'s sequence offsets index this text.
pub fn layout_text(runs: &[Run]) -> String {
    runs.iter().map(|r| if is_object(r) { OBJECT.to_string() } else { r.text.clone() }).collect()
}

/// EMU per point (914400 per inch).
const EMU_PER_PT: f64 = 12700.0;

/// Displayed size of an image run in points, shrunk to fit `max_width_pt`
/// with its aspect kept: the document's extent if it has one, else the
/// image's own pixels at 96 dpi (PNG), else one inch square.
pub fn image_size_pt(run: &Run, max_width_pt: f64) -> (f64, f64) {
    let (w, h) = match run.style.image_extent_emu {
        Some((w, h)) => (w as f64 / EMU_PER_PT, h as f64 / EMU_PER_PT),
        None => run.style.image.as_deref().and_then(png_size_px).map_or((72.0, 72.0), |(w, h)| {
            (f64::from(w) * 0.75, f64::from(h) * 0.75)
        }),
    };
    if w > max_width_pt && w > 0.0 {
        (max_width_pt, h * max_width_pt / w)
    } else {
        (w, h)
    }
}

/// Pixel size from a PNG file's IHDR chunk.
fn png_size_px(path: &str) -> Option<(u32, u32)> {
    use std::io::Read;
    let mut head = [0u8; 24];
    std::fs::File::open(path).ok()?.read_exact(&mut head).ok()?;
    if &head[..8] != b"\x89PNG\r\n\x1a\n" || &head[12..16] != b"IHDR" {
        return None;
    }
    let be = |b: &[u8]| u32::from_be_bytes([b[0], b[1], b[2], b[3]]);
    Some((be(&head[16..20]), be(&head[20..24])))
}

/// The run holding char `index` of a paragraph's layout text.
fn run_at(runs: &[Run], index: usize) -> Option<&Run> {
    let mut at = 0;
    for r in runs {
        let n = if is_object(r) { 1 } else { r.text.chars().count() };
        if index < at + n {
            return Some(r);
        }
        at += n;
    }
    None
}

/// Cell padding left and right, in points (Word's and LibreOffice's
/// default for a table: 0.08in).
pub const CELL_PADDING_PT: f64 = 5.4;

/// Width of the cell rules the painter draws, in points. A row is its
/// content plus one rule, as Word and LibreOffice measure it.
pub const CELL_RULE_PT: f64 = 0.5;

/// Marge haute et basse d'une zone de texte (tableau d'une seule case),
/// dessinée en cadre aux coins arrondis.
pub const BOX_PADDING_PT: f64 = 7.0;

/// Lay out `doc` into pages.
/// Footnote text size relative to body text: Word's and LibreOffice's
/// default, 10 pt notes under 12 pt text.
pub const NOTE_SCALE: f64 = 10.0 / 12.0;

/// A footnote reference's number: the superscript size and rise relative
/// to the text it is in (as `VertAlign::Superscript` draws).
pub const NOTE_REF_SCALE: f64 = 0.58;
pub const NOTE_REF_RISE: f64 = 0.33;

/// Room between a page's body text and its footnotes, holding the
/// separator rule `NOTE_RULE_GAP_PT` above the first note (LibreOffice's
/// footnote area: a thin line and a small gap).
pub const NOTE_SEPARATOR_PT: f64 = 6.0;
pub const NOTE_RULE_GAP_PT: f64 = 2.0;

/// Length of the separator rule, relative to the text width (LibreOffice's
/// default footnote line).
pub const NOTE_RULE_FRACTION: f64 = 0.25;

/// Footnote `i` as the paragraph drawn at the foot of its page, as
/// LibreOffice draws a Word footnote: its number at body size, a space, and
/// its text at `NOTE_SCALE` of it, spaced like the document's body
/// paragraphs (a note is a Normal paragraph in Word). The engine and the
/// painter both build it here.
pub fn note_paragraph(doc: &Document, i: usize, opts: &LayoutOptions) -> Paragraph {
    let hp = (opts.font_size_pt * NOTE_SCALE * 2.0).round() as u16;
    let size = crate::model::RunStyle { font_size_hp: Some(hp), ..Default::default() };
    let text = doc.footnotes.get(i).cloned().unwrap_or_default();
    let body = doc
        .paragraphs
        .iter()
        .find(|p| p.style.heading.is_none() && p.style.table_cell.is_none() && p.style.list == ListKind::None && p.style.named_style.is_none())
        .map(|p| &p.style);
    Paragraph {
        style: crate::model::ParaStyle {
            line_spacing: body.map_or(1.0, |s| s.line_spacing),
            space_after_pt: body.map_or(0.0, |s| s.space_after_pt),
            ..Default::default()
        },
        runs: vec![Run::plain((i + 1).to_string()), Run { text: format!(" {text}"), style: size }],
    }
}

/// Part of a footnote placed at the foot of a page: lines `from..to` of
/// note `note`. A note that does not fit on its reference's page continues
/// on the next, as LibreOffice and Word split one.
#[derive(Clone, Copy, Debug, PartialEq)]
struct NotePiece {
    note: usize,
    from: usize,
    to: usize,
}

/// The footnotes referenced on line `lb` of `para`.
fn line_notes(para: &Paragraph, lb: &LineBox) -> Vec<usize> {
    lb.objects.iter().filter_map(|&(ch, _)| run_at(&para.runs, ch)?.style.footnote).collect()
}

pub fn layout(doc: &Document, opts: &LayoutOptions, shaper: &mut dyn Shaper) -> RenderTree {
    let tree = layout_with(doc, opts, shaper, None);
    let geometry = doc.page.unwrap_or(opts.for_document(doc).page);
    if geometry.columns <= 1 || tree.pages.is_empty() {
        return tree;
    }
    // Columns on the last page are balanced, as in a LibreOffice section:
    // the lowest column foot at which the text still fits on that page,
    // found by halving. Earlier pages fill column after column.
    let last = tree.pages.len() - 1;
    let top = geometry.margin_top_pt;
    let (mut lo, mut hi) = (top + 1.0, (geometry.height_pt - geometry.margin_bottom_pt).max(top + 1.0));
    let mut best = None;
    while hi - lo > 1.0 {
        let mid = (lo + hi) / 2.0;
        let t = layout_with(doc, opts, shaper, Some((last, mid)));
        if t.pages.len() == tree.pages.len() {
            hi = mid;
            best = Some(t);
        } else {
            lo = mid;
        }
    }
    best.unwrap_or(tree)
}

/// `layout`, with the column foot of page `balance.0` held at `balance.1`.
fn layout_with(doc: &Document, opts: &LayoutOptions, shaper: &mut dyn Shaper, balance: Option<(usize, f64)>) -> RenderTree {
    let opts = &opts.for_document(doc);
    let geometry = doc.page.unwrap_or(opts.page);
    let mut flow = Flow::new(geometry, opts);
    flow.balance = balance;
    // Each footnote's height at the foot of a page, for the flow to keep
    // room for the notes of the lines it places.
    let text_w = flow.content_width();
    for i in 0..doc.footnotes.len() {
        let p = note_paragraph(doc, i, opts);
        let shaped = shape_paragraph(&p, text_w, opts, shaper);
        flow.note_lines.push(shaped.lines.iter().map(|l| l.natural_height() * spacing(&p)).collect());
        flow.note_after.push(p.style.space_after_pt.max(0.0));
    }
    let ordinals = lists::ordinals_of(doc.paragraphs.iter());
    let col_w = flow.column_width();

    let mut i = 0;
    while i < doc.paragraphs.len() {
        let para = &doc.paragraphs[i];
        if let Some(cell) = para.style.table_cell {
            let end = doc.paragraphs[i..]
                .iter()
                .position(|p| p.style.table_cell.is_none_or(|c| c.table != cell.table))
                .map_or(doc.paragraphs.len(), |n| i + n);
            // Samizdat : un tableau à côté d'une image flottante la longe,
            // rétréci, s'il reste assez de place ; sinon il passe dessous.
            if let Some(f) = flow.float.take().filter(|f| f.page == flow.pages.len() && f.column == flow.column && flow.y < f.bottom) {
                let col_w = flow.column_width();
                if col_w - f.width >= col_w * 0.4 {
                    flow.squeeze = Some((if f.left { f.width } else { 0.0 }, col_w - f.width));
                    flow.float = Some(f);
                } else {
                    flow.y = flow.y.max(f.bottom);
                }
            }
            layout_table(&mut flow, doc, i..end, shaper);
            i = end;
            continue;
        }
        // Samizdat : une image flottante se pose au bord de la colonne, en
        // haut de son paragraphe ; le texte la longe.
        let float_here = para.runs.iter().find(|r| r.style.image.is_some() && r.style.image_float.is_some());
        let gap = if flow.column_is_empty() && !(flow.pages.len() == 1 && flow.column == 0) {
            0.0
        } else {
            para.style.space_before_pt.max(0.0).max(flow.pending_after)
        };
        if let Some(run) = float_here {
            let (w, h) = image_size_pt(run, col_w * 0.62);
            let mut top = flow.y + gap;
            if top + h > flow.bottom() && !flow.column_is_empty() {
                flow.next_column();
                top = flow.y;
            }
            // Une image flottante déjà là, du même côté : en dessous.
            let left = run.style.image_float == Some(crate::model::ImageFloat::Left);
            if let Some(f) = flow.float.filter(|f| f.page == flow.pages.len() && f.column == flow.column && f.left == left) {
                top = top.max(f.bottom);
            }
            let x = flow.column_x() + if left { 0.0 } else { col_w - w };
            if let Some(src) = run.style.image.clone() {
                flow.push(Item::Image { para: i, src, x_pt: x, y_pt: top, width_pt: w, height_pt: h });
            }
            flow.float = Some(Float { page: flow.pages.len(), column: flow.column, bottom: top + h + FLOAT_GAP_PT / 2.0, width: w + FLOAT_GAP_PT, left });
        }
        let active = flow.float.filter(|f| f.page == flow.pages.len() && f.column == flow.column && flow.y + gap < f.bottom);
        let shaped = match active {
            Some(f) => shape_beside(para, col_w, f, flow.y + gap, opts, shaper),
            None => shape_paragraph(para, col_w, opts, shaper),
        };
        // Keep a heading, and any paragraph set to keep with the next (a
        // Title, a Word style's keepNext), with the first lines of what
        // follows it.
        let keep_next = if para.style.heading.is_some() || para.style.keep_with_next {
            doc.paragraphs.get(i + 1).filter(|n| n.style.table_cell.is_none()).map(|n| {
                let s = shape_paragraph(n, col_w, opts, shaper);
                let lines = s.lines.len().min(opts.orphans.max(1));
                n.style.space_before_pt
                    + s.lines[..lines].iter().map(|l| l.natural_height() * spacing(n)).sum::<f64>()
            })
        } else {
            None
        };
        // Samizdat : un cadre ou une trame continue avec le paragraphe voisin
        // qui a la même.
        let boxed = |q: &Paragraph| (q.style.border, q.style.shading, q.style.table_cell.is_none());
        let has_box = para.style.border.is_some() || para.style.shading.is_some();
        let join = (
            has_box && i > 0 && boxed(&doc.paragraphs[i - 1]) == boxed(para),
            has_box && doc.paragraphs.get(i + 1).is_some_and(|q| boxed(q) == boxed(para)),
        );
        place_paragraph(&mut flow, i, para, &shaped, ordinals[i], keep_next, join);
        i += 1;
    }
    flow.finish(doc, opts, shaper)
}

/// Line-height multiplier of a paragraph (1.0 when unset or nonsensical).
fn spacing(p: &Paragraph) -> f64 {
    let s = f64::from(p.style.line_spacing);
    if s.is_finite() && s > 0.0 { s } else { 1.0 }
}

/// A paragraph broken into lines, with the horizontal box it was shaped in.
struct Shaped {
    lines: Vec<LineBox>,
    /// Text box left edge, relative to the column's left edge.
    box_x: f64,
    box_w: f64,
    /// List marker x, relative to the column's left edge.
    marker_x: f64,
    /// Samizdat : à côté d'une image flottante, les lignes n'ont pas toutes
    /// la même boîte : pour chaque ligne (box_x, box_w, from, rang depuis
    /// from). Vide = toutes dans `box_x`/`box_w`, depuis 0.
    per_line: Vec<(f64, f64, usize, usize)>,
}

impl Shaped {
    /// (box_x, box_w, from, line) de la ligne `k`.
    fn geometry(&self, k: usize) -> (f64, f64, usize, usize) {
        self.per_line.get(k).copied().unwrap_or((self.box_x, self.box_w, 0, k))
    }
}

/// Left edge of a paragraph's text box, in points from its column's (or
/// table cell's) left edge: the left indent plus a list item's text indent.
pub fn paragraph_box_x(p: &Paragraph) -> f64 {
    let st = &p.style;
    let list_indent = if st.list == ListKind::None { 0.0 } else { lists::text_indent_pt(st.list_level) };
    let quote_indent = if st.block_quote { QUOTE_INDENT_PT } else { 0.0 };
    st.left_indent_pt.max(0.0) + list_indent + quote_indent
}

/// How far a block quote is indented from the left, in points (the Draft
/// editor's `blockquote` tag: 24 px).
pub const QUOTE_INDENT_PT: f64 = 18.0;

/// A paragraph's look beyond body text, headings and code: the named
/// Title and Subtitle styles, and block quotes.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Look {
    Body,
    /// Large and bold (Google Docs' and the old Letters stylesheet's 26 pt
    /// over 11 pt body text).
    Title,
    /// Larger than body text, grey (15 pt over 11 pt).
    Subtitle,
    /// Italic, indented by `QUOTE_INDENT_PT`.
    Quote,
}

impl Look {
    /// Text size relative to body text.
    pub fn scale(self) -> f64 {
        match self {
            Look::Title => 26.0 / 11.0,
            Look::Subtitle => 15.0 / 11.0,
            Look::Body | Look::Quote => 1.0,
        }
    }
}

/// The look of a paragraph styled `st`. A heading level wins over a named
/// style; a named style is matched as Word and LibreOffice spell it.
pub fn paragraph_look(st: &crate::model::ParaStyle) -> Look {
    if st.heading.is_some() {
        return Look::Body;
    }
    match st.named_style.as_deref().map(str::to_ascii_lowercase).as_deref() {
        Some("title") => Look::Title,
        Some("subtitle") => Look::Subtitle,
        _ if st.block_quote => Look::Quote,
        _ => Look::Body,
    }
}

/// The shaping request for paragraph `p` in a text box `box_w` wide. The
/// engine and every renderer build it here, so a renderer re-shaping a
/// paragraph to draw it gets exactly the lines the engine placed.
pub fn paragraph_request<'a>(p: &'a Paragraph, box_w: f64, opts: &'a LayoutOptions) -> ShapeRequest<'a> {
    let st = &p.style;
    let box_x = paragraph_box_x(p);
    ShapeRequest {
        runs: &p.runs,
        heading: st.heading,
        code: st.code_block.is_some(),
        look: paragraph_look(st),
        alignment: st.alignment,
        width_pt: box_w,
        // A list item's first line starts at its text indent; the marker
        // hangs in front of it.
        first_line_indent_pt: if st.list == ListKind::None { st.first_line_indent_pt } else { 0.0 },
        tab_stops_pt: if st.toc.is_some() { Vec::new() } else { st.tab_stops_pt.iter().map(|t| t - box_x).filter(|t| *t > 0.0).collect() },
        right_tab: st.toc.is_some(),
        defaults: opts,
    }
}

/// Size multiplier of heading level 1–6 relative to body text (the
/// editor's h1–h6 tags use the same scale).
pub fn heading_scale(level: u8) -> f64 {
    [1.6, 1.4, 1.2, 1.1, 1.0, 0.9][usize::from(level.clamp(1, 6) - 1)]
}

fn shape_paragraph(p: &Paragraph, avail_w: f64, opts: &LayoutOptions, shaper: &mut dyn Shaper) -> Shaped {
    let box_x = paragraph_box_x(p);
    let box_w = (avail_w - box_x - p.style.right_indent_pt.max(0.0)).max(1.0);
    let mut lines = shaper.shape(&paragraph_request(p, box_w, opts));
    if lines.is_empty() {
        let size = opts.font_size_pt;
        lines.push(LineBox { start: 0, end: 0, x_pt: 0.0, width_pt: 0.0, ascent_pt: size * 0.9, descent_pt: size * 0.25, objects: Vec::new() });
    }
    Shaped { lines, box_x, box_w, marker_x: box_x - lists::HANGING_PT.min(box_x), per_line: Vec::new() }
}

/// Place a shaped paragraph in the flow, splitting it across columns and
/// pages with orphan and widow control. `keep_next` is the height that must
/// fit below the paragraph on the same page (a heading's follower).
fn place_paragraph(flow: &mut Flow, idx: usize, para: &Paragraph, shaped: &Shaped, ordinal: u32, keep_next: Option<f64>, join: (bool, bool)) {
    let st = &para.style;
    if st.page_break_before && !flow.page_is_empty() {
        flow.new_page();
    }
    let ls = spacing(para);
    let heights: Vec<f64> = shaped.lines.iter().map(|l| l.natural_height() * ls).collect();
    let total: f64 = heights.iter().sum();

    // Between two paragraphs the larger of the space after the first and
    // the space before the second applies, not their sum: LibreOffice
    // draws Word documents that way (render-lab letters/paragraph-spacing:
    // 10pt after, then 24pt before, is a 24pt gap). Past the first
    // paragraph neither applies at the top of a page or column: Word and
    // LibreOffice start the text at the margin there, so a heading's
    // space before must not ride a page break onto the next page
    // (render-lab letters/toc). The document's own first paragraph keeps
    // its space before (render-lab letters/headings).
    let document_top = flow.pages.len() == 1 && flow.column == 0 && flow.column_is_empty();
    if !flow.column_is_empty() || document_top {
        flow.y += st.space_before_pt.max(0.0).max(std::mem::take(&mut flow.pending_after));
    }
    // Everything that must stay together with the first line: the whole
    // paragraph if short, the orphan lines otherwise, plus a heading's
    // follower.
    let n = heights.len();
    let head: f64 = if n < flow.opts.orphans + flow.opts.widows {
        total
    } else {
        heights[..flow.opts.orphans.min(n)].iter().sum()
    };
    let needed = head + keep_next.map(|k| st.space_after_pt.max(0.0) + k).unwrap_or(0.0);
    if flow.y + needed > flow.bottom() && !flow.column_is_empty() {
        flow.next_column();
        if !flow.column_is_empty() {
            flow.y += st.space_before_pt.max(0.0);
        }
    }

    let text: Vec<char> = layout_text(&para.runs).chars().collect();
    let mut line = 0;
    while line < n {
        // How many lines fit here, each with room for its footnotes? A line
        // whose note fits only in part ends the chunk: the note continues
        // on the next page (`split`: that line, and what carries over).
        let mut fit = 0;
        let mut y = flow.y;
        let mut notes: Vec<usize> = Vec::new();
        let mut split: Option<(usize, Vec<NotePiece>)> = None;
        while line + fit < n {
            let mut with = notes.clone();
            with.extend(line_notes(para, &shaped.lines[line + fit]));
            let Some(carry) = flow.plan(y + heights[line + fit], &with) else { break };
            y += heights[line + fit];
            fit += 1;
            if !carry.is_empty() {
                split = Some((line + fit - 1, carry));
                break;
            }
            notes = with;
        }
        if line + fit < n {
            // Widows: leave at least `widows` lines for the next column.
            let rest = n - line - fit;
            if rest < flow.opts.widows {
                fit = fit.saturating_sub(flow.opts.widows - rest);
            }
            // Orphans: don't strand fewer than `orphans` lines (only matters
            // for the paragraph's first chunk).
            if line == 0 && fit < flow.opts.orphans.min(n) {
                fit = 0;
            }
            // An empty column takes at least one line, or nothing would fit
            // anywhere.
            if fit == 0 && flow.column_is_empty() {
                fit = 1;
            }
        }
        if split.as_ref().is_some_and(|(k, _)| *k >= line + fit) {
            split = None;
        }
        // Samizdat : le cadre ou la trame de ce morceau du paragraphe.
        if (st.border.is_some() || st.shading.is_some()) && fit > 0 {
            const PAD: f64 = 3.0;
            let chunk: f64 = heights[line..line + fit].iter().sum();
            let here = (flow.pages.len(), flow.column);
            let first = line == 0;
            let last = line + fit == n;
            let joined_up = first && join.0 && flow.box_bottom.is_some_and(|(p, c, _)| (p, c) == here);
            let y0 = if joined_up { flow.box_bottom.map_or(flow.y - PAD, |b| b.2) } else { flow.y - PAD };
            let y1 = flow.y + chunk + if last && join.1 { 0.0 } else { PAD };
            let x = flow.column_x() + st.left_indent_pt.max(0.0) - PAD;
            let w = flow.column_width() - st.left_indent_pt.max(0.0) - st.right_indent_pt.max(0.0) + 2.0 * PAD;
            flow.push(Item::ParaBox {
                x_pt: x,
                y_pt: y0,
                width_pt: w,
                height_pt: y1 - y0,
                fill: st.shading,
                border: st.border,
                top: !joined_up,
                bottom: !(last && join.1),
            });
            flow.box_bottom = Some((here.0, here.1, y1));
        }
        for (k, (lb, &height)) in shaped.lines.iter().zip(&heights).enumerate().skip(line).take(fit) {
            let top = flow.y;
            let baseline = top + lb.ascent_pt;
            let x0 = flow.column_x();
            if k == 0 && st.list != ListKind::None {
                if let Some(text) = lists::marker_of(st, ordinal) {
                    flow.push(Item::Marker { para: idx, text, x_pt: x0 + shaped.marker_x, baseline_pt: baseline });
                }
            }
            let (bx, bw, from, kk) = shaped.geometry(k);
            emit_line_from(flow, idx, para, &text, (kk, from), lb, x0 + bx, bw, top, height);
            match split.take_if(|(at, _)| *at == k) {
                // What fits of the line's notes here, the rest next page.
                Some((_, carry)) => flow.add_notes_split(line_notes(para, lb), carry),
                None => flow.add_notes(line_notes(para, lb)),
            }
            flow.y += height;
        }
        line += fit;
        if line < n {
            flow.next_column();
        }
    }
    // Applied by whatever comes next, or dropped at the foot of a page.
    flow.pending_after = st.space_after_pt.max(0.0);
    if st.border.is_none() && st.shading.is_none() {
        flow.box_bottom = None;
    } else if !join.1 {
        // Un cadre qui se termine : l'air sous son trait.
        flow.pending_after = flow.pending_after.max(3.0);
    }
}

/// Emit line `k` of paragraph `idx` with its text box's left edge at
/// `box_x` and top at `top`, and the images on it.
#[allow(clippy::too_many_arguments)]
fn emit_line(flow: &mut Flow, idx: usize, para: &Paragraph, text: &[char], k: usize, lb: &LineBox, box_x: f64, box_w: f64, top: f64, height: f64) {
    emit_line_from(flow, idx, para, text, (k, 0), lb, box_x, box_w, top, height);
}

/// `emit_line`, pour la ligne `k.0` d'une mise en lignes commencée au
/// caractère `k.1` du paragraphe.
#[allow(clippy::too_many_arguments)]
fn emit_line_from(flow: &mut Flow, idx: usize, para: &Paragraph, text: &[char], (k, from): (usize, usize), lb: &LineBox, box_x: f64, box_w: f64, top: f64, height: f64) {
    let baseline = top + lb.ascent_pt;
    flow.push(Item::Line {
        source: Source::Paragraph(idx),
        line: k,
        from,
        start: lb.start,
        end: lb.end,
        text: text[lb.start.min(text.len())..lb.end.min(text.len())].iter().collect(),
        box_x_pt: box_x,
        box_width_pt: box_w,
        x_pt: box_x + lb.x_pt,
        top_pt: top,
        baseline_pt: baseline,
        height_pt: height,
    });
    let tallest = lb
        .objects
        .iter()
        .filter_map(|&(ch, _)| run_at(&para.runs, ch))
        .filter(|r| r.style.image.is_some() && r.style.image_float.is_none())
        .map(|r| image_size_pt(r, box_w).1)
        .fold(0.0, f64::max);
    for &(ch, x) in &lb.objects {
        let Some(run) = run_at(&para.runs, ch) else { continue };
        if run.style.chip.is_some() {
            flow.push(Item::Chip { para: idx, ch, x_pt: box_x + x, baseline_pt: baseline });
            continue;
        }
        if run.style.footnote.is_some() {
            flow.push(Item::NoteRef { para: idx, ch, x_pt: box_x + x, baseline_pt: baseline });
            continue;
        }
        let Some(src) = run.style.image.clone() else { continue };
        // Une image flottante est posée par place_paragraph, au bord.
        if run.style.image_float.is_some() {
            continue;
        }
        let (w, h) = image_size_pt(run, box_w);
        // Samizdat : aligné par le haut : toutes en haut de la ligne (la
        // plus haute des images de la ligne).
        let y = if para.style.align_top { baseline - tallest } else { baseline - h };
        flow.push(Item::Image { para: idx, src, x_pt: box_x + x, y_pt: y, width_pt: w, height_pt: h });
    }
}

/// The cursor that fills columns and pages.
struct Flow<'o> {
    geometry: PageGeometry,
    opts: &'o LayoutOptions,
    pages: Vec<Page>,
    column: usize,
    /// Current vertical position, points from the page top.
    y: f64,
    /// Items placed in the current column.
    column_items: usize,
    /// Space after the last paragraph, not yet added (see place_paragraph).
    pending_after: f64,
    /// Samizdat : le bas du dernier cadre de paragraphe (page, colonne, y),
    /// pour que le suivant, s'il est identique, le prolonge.
    box_bottom: Option<(usize, usize, f64)>,
    /// Each footnote's line heights at the foot of a page, and its space
    /// after.
    note_lines: Vec<Vec<f64>>,
    note_after: Vec<f64>,
    /// The footnote pieces at the foot of each page, in order.
    page_notes: Vec<Vec<NotePiece>>,
    /// What continues at the foot of the next page.
    carry: Vec<NotePiece>,
    /// Column balancing: on page `.0`, body text ends at `.1`.
    balance: Option<(usize, f64)>,
    /// Samizdat : l'image flottante que le texte longe encore.
    float: Option<Float>,
    /// Samizdat : le prochain tableau, à côté d'une image flottante :
    /// (décalage, largeur).
    squeeze: Option<(f64, f64)>,
}

impl<'o> Flow<'o> {
    fn new(geometry: PageGeometry, opts: &'o LayoutOptions) -> Self {
        let mut f = Flow {
            geometry,
            opts,
            pages: Vec::new(),
            column: 0,
            y: 0.0,
            column_items: 0,
            pending_after: 0.0,
            box_bottom: None,
            note_lines: Vec::new(),
            note_after: Vec::new(),
            page_notes: Vec::new(),
            carry: Vec::new(),
            float: None,
            squeeze: None,
            balance: None,
        };
        f.new_page();
        f
    }

    fn columns(&self) -> usize {
        usize::from(self.geometry.columns.max(1))
    }

    fn content_width(&self) -> f64 {
        (self.geometry.width_pt - self.geometry.margin_left_pt - self.geometry.margin_right_pt).max(1.0)
    }

    fn column_width(&self) -> f64 {
        let n = self.columns() as f64;
        ((self.content_width() - self.geometry.column_gap_pt * (n - 1.0)) / n).max(1.0)
    }

    fn column_x(&self) -> f64 {
        self.geometry.margin_left_pt + self.column as f64 * (self.column_width() + self.geometry.column_gap_pt)
    }

    fn top(&self) -> f64 {
        self.geometry.margin_top_pt
    }

    /// The foot of the text area, above the bottom margin.
    fn foot(&self) -> f64 {
        (self.geometry.height_pt - self.geometry.margin_bottom_pt).max(self.top() + 1.0)
    }

    fn note_len(&self, note: usize) -> usize {
        self.note_lines.get(note).map_or(0, Vec::len)
    }

    fn whole(&self, note: usize) -> NotePiece {
        NotePiece { note, from: 0, to: self.note_len(note) }
    }

    /// A piece's height: its lines, and the note's space after if it ends
    /// the note.
    fn piece_height(&self, p: &NotePiece) -> f64 {
        let lines = self.note_lines.get(p.note).map_or(0.0, |l| l[p.from.min(l.len())..p.to.min(l.len())].iter().sum());
        lines + if p.to >= self.note_len(p.note) { self.note_after.get(p.note).copied().unwrap_or(0.0) } else { 0.0 }
    }

    /// Room footnote pieces take at the foot of a page, with the separator.
    fn reserved(&self, pieces: &[NotePiece]) -> f64 {
        if pieces.is_empty() {
            return 0.0;
        }
        NOTE_SEPARATOR_PT + pieces.iter().map(|p| self.piece_height(p)).sum::<f64>()
    }

    fn current_notes(&self) -> &[NotePiece] {
        self.page_notes.last().map_or(&[], Vec::as_slice)
    }

    /// Where body text must end on this page, above its footnotes.
    fn bottom(&self) -> f64 {
        (self.foot() - self.reserved(self.current_notes())).max(self.top() + 1.0).min(self.limit())
    }

    /// The balanced column foot on this page, if any.
    fn limit(&self) -> f64 {
        match self.balance {
            Some((page, y)) if page + 1 == self.pages.len() => y.max(self.top() + 1.0),
            _ => f64::INFINITY,
        }
    }

    /// Whether body text can reach `y_end` on this page with the notes
    /// `notes` referenced by it: `None` if not, else the note lines that
    /// have to continue on the next page (empty when all fit). A note
    /// splits only when its first line fits with its reference.
    fn plan(&self, y_end: f64, notes: &[usize]) -> Option<Vec<NotePiece>> {
        let here = self.current_notes();
        let new: Vec<usize> = notes.iter().copied().filter(|n| !here.iter().any(|p| p.note == *n)).collect();
        let sep = if here.is_empty() && !new.is_empty() { NOTE_SEPARATOR_PT } else { 0.0 };
        let mut avail = self.foot() - self.reserved(here) - sep - y_end;
        if avail < -1e-6 || y_end > self.limit() + 1e-6 {
            return None;
        }
        let mut carry = Vec::new();
        let mut placed_any = false;
        for n in new {
            let whole = self.whole(n);
            if !carry.is_empty() {
                carry.push(whole);
                continue;
            }
            let full = self.piece_height(&whole);
            if full <= avail + 1e-6 {
                avail -= full;
                placed_any = true;
                continue;
            }
            let lines = &self.note_lines[n];
            let mut k = 0;
            let mut used = 0.0;
            while k < lines.len() && used + lines[k] <= avail + 1e-6 {
                used += lines[k];
                k += 1;
            }
            if k == 0 && !placed_any {
                return None;
            }
            carry.push(NotePiece { note: n, from: k, to: whole.to });
            avail -= used;
            placed_any |= k > 0;
        }
        Some(carry)
    }

    /// Put the notes referenced by a placed line at this page's foot.
    fn add_notes(&mut self, notes: Vec<usize>) {
        self.add_notes_split(notes, Vec::new());
    }

    /// As `add_notes`, with `carry` (from `plan`) continuing next page.
    fn add_notes_split(&mut self, notes: Vec<usize>, carry: Vec<NotePiece>) {
        let pieces: Vec<NotePiece> = notes
            .into_iter()
            .filter(|n| !self.current_notes().iter().any(|p| p.note == *n))
            .map(|n| {
                let whole = self.whole(n);
                match carry.iter().find(|c| c.note == n) {
                    Some(c) => NotePiece { to: c.from, ..whole },
                    None => whole,
                }
            })
            .filter(|p| p.to > p.from)
            .collect();
        if let Some(page) = self.page_notes.last_mut() {
            page.extend(pieces);
        }
        self.carry.extend(carry);
    }

    fn page_is_empty(&self) -> bool {
        self.pages.last().is_none_or(|p| p.items.is_empty())
    }

    fn column_is_empty(&self) -> bool {
        self.column_items == 0
    }

    fn new_page(&mut self) {
        let index = self.pages.len();
        self.pages.push(Page {
            index,
            width_pt: self.geometry.width_pt,
            height_pt: self.geometry.height_pt,
            geometry: self.geometry,
            items: Vec::new(),
        });
        // A footnote continued from the page before comes first.
        let carried = std::mem::take(&mut self.carry);
        self.page_notes.push(carried);
        self.column = 0;
        self.y = self.top();
        self.column_items = 0;
        self.pending_after = 0.0;
    }

    fn next_column(&mut self) {
        if self.column + 1 < self.columns() {
            self.column += 1;
            self.y = self.top();
            self.column_items = 0;
        self.pending_after = 0.0;
        } else {
            self.new_page();
        }
    }

    fn push(&mut self, item: Item) {
        self.column_items += 1;
        self.pages.last_mut().expect("a page").items.push(item);
    }

    /// Add headers and footers now that the page count is known.
    fn finish(mut self, doc: &Document, opts: &LayoutOptions, shaper: &mut dyn Shaper) -> RenderTree {
        let total = self.pages.len();
        let width = self.content_width();
        let (left, height) = (self.geometry.margin_left_pt, self.geometry.height_pt);
        // Each page's footnotes, ending at the foot of its text area under
        // a short rule.
        let foot = self.foot();
        let page_notes = std::mem::take(&mut self.page_notes);
        for (page, pieces) in self.pages.iter_mut().zip(&page_notes) {
            if pieces.is_empty() {
                continue;
            }
            // The last piece ends at the foot; a note's space after it is
            // not drawn.
            let after = pieces.last().filter(|p| p.to >= self.note_lines.get(p.note).map_or(0, Vec::len)).map_or(0.0, |p| self.note_after[p.note]);
            let total: f64 = pieces
                .iter()
                .map(|p| {
                    let lines = &self.note_lines[p.note];
                    lines[p.from.min(lines.len())..p.to.min(lines.len())].iter().sum::<f64>()
                        + if p.to >= lines.len() { self.note_after[p.note] } else { 0.0 }
                })
                .sum();
            let mut y = foot + after - total;
            page.items.push(Item::Rule { x_pt: left, y_pt: y - NOTE_RULE_GAP_PT, width_pt: width * NOTE_RULE_FRACTION });
            for piece in pieces {
                let i = piece.note;
                let p = note_paragraph(doc, i, opts);
                let shaped = shape_paragraph(&p, width, opts, shaper);
                let chars: Vec<char> = layout_text(&p.runs).chars().collect();
                let ls = spacing(&p);
                for (k, lb) in shaped.lines.iter().enumerate().take(piece.to).skip(piece.from) {
                    page.items.push(Item::Line {
                        source: Source::Footnote(i),
                        line: k,
                        start: lb.start,
                        end: lb.end,
                        text: chars[lb.start.min(chars.len())..lb.end.min(chars.len())].iter().collect(),
                        box_x_pt: left,
                        box_width_pt: width,
                        x_pt: left + lb.x_pt,
                        top_pt: y,
                        baseline_pt: y + lb.ascent_pt,
                        height_pt: lb.natural_height() * ls,
                        from: 0,
                    });
                    y += lb.natural_height() * ls;
                }
                if piece.to >= shaped.lines.len() {
                    y += p.style.space_after_pt.max(0.0);
                }
            }
        }
        for page in &mut self.pages {
            for (source, template) in [(Source::Header, &doc.header), (Source::Footer, &doc.footer)] {
                let Some(template) = template.as_deref().filter(|t| !t.is_empty()) else { continue };
                let text = page_field_text(template, page.index + 1, total);
                let runs = [Run::plain(text.clone())];
                let lines = shaper.shape(&ShapeRequest {
                    runs: &runs,
                    heading: None,
                    code: false,
                    look: Look::Body,
                    alignment: page_field_alignment(template),
                    width_pt: width,
                    first_line_indent_pt: 0.0,
                    tab_stops_pt: Vec::new(),
                    right_tab: false,
                    defaults: opts,
                });
                let block: f64 = lines.iter().map(LineBox::natural_height).sum();
                let mut y = match source {
                    Source::Header => opts.header_distance_pt,
                    _ => height - opts.footer_distance_pt - block,
                };
                let chars: Vec<char> = text.chars().collect();
                for (k, lb) in lines.iter().enumerate() {
                    page.items.push(Item::Line {
                        source: source.clone(),
                        line: k,
                        start: lb.start,
                        end: lb.end,
                        text: chars[lb.start.min(chars.len())..lb.end.min(chars.len())].iter().collect(),
                        box_x_pt: left,
                        box_width_pt: width,
                        x_pt: left + lb.x_pt,
                        top_pt: y,
                        baseline_pt: y + lb.ascent_pt,
                        height_pt: lb.natural_height(),
                        from: 0,
                    });
                    y += lb.natural_height();
                }
            }
        }
        RenderTree { pages: self.pages }
    }
}

/// Header/footer text for one page: "{page}" and "{total}" substituted.
/// A header or footer is left-aligned, as a Word or LibreOffice header
/// paragraph is by default; one that numbers the pages is centered (the
/// writers center it too).
pub fn page_field_alignment(template: &str) -> crate::model::Alignment {
    if template.contains("{page}") { crate::model::Alignment::Center } else { crate::model::Alignment::Left }
}

pub fn page_field_text(template: &str, page: usize, total: usize) -> String {
    template.replace("{page}", &page.to_string()).replace("{total}", &total.to_string())
}

#[cfg(test)]
mod tests;
