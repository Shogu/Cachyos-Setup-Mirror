// odt_shapes.rs — les formes dessinées d'un ODT (rectangles, ellipses),
// comme celles d'un croquis fait dans LibreOffice.
//
// Avant la lecture, les formes sont retirées du XML (leur texte éventuel
// devient un paragraphe juste après celui qui les porte) ; elles sont
// ensuite redessinées toutes ensemble en une image, placée après le
// paragraphe où la première est ancrée — comme pour Word (docx_shapes).
// SPDX-License-Identifier: GPL-3.0-or-later

use crate::docx_keep::element_end;

/// Une forme lue : (paragraphe hôte, x, y, largeur, hauteur en points,
/// z, nom de style, genre 0 rectangle / 1 ellipse / 2 arrondi).
#[derive(Debug, Clone)]
pub struct Found {
    pub host: usize,
    pub x: f64,
    pub y: f64,
    pub w: f64,
    pub h: f64,
    pub z: i64,
    pub style: String,
    pub kind: u8,
}

fn attr<'a>(tag: &'a str, name: &str) -> Option<&'a str> {
    let pat = format!(" {name}=\"");
    let i = tag.find(&pat)? + pat.len();
    tag[i..].split('"').next()
}

/// Une longueur ODF en points.
pub fn pt(v: &str) -> Option<f64> {
    let v = v.trim();
    let split = v.find(|c: char| c.is_ascii_alphabetic())?;
    let (n, unit) = v.split_at(split);
    let n: f64 = n.parse().ok()?;
    Some(match unit {
        "cm" => n * 72.0 / 2.54,
        "mm" => n * 72.0 / 25.4,
        "in" => n * 72.0,
        "pt" => n,
        "pc" => n * 12.0,
        "px" => n * 0.75,
        _ => return None,
    })
}

const SHAPES: [&str; 4] = ["draw:custom-shape", "draw:rect", "draw:ellipse", "draw:circle"];

/// Paragraphes ouverts dans `s` (le modèle compte aussi ceux des cases).
fn paragraphs_in(s: &str) -> usize {
    ["<text:p>", "<text:p ", "<text:p/", "<text:h>", "<text:h ", "<text:h/"].iter().map(|t| s.matches(t).count()).sum()
}

/// Retire les formes de `content` : le XML sans elles, et les formes.
pub fn take(content: &str) -> Option<(String, Vec<Found>)> {
    if !SHAPES.iter().any(|s| content.contains(&format!("<{s} "))) {
        return None;
    }
    let mut out = String::with_capacity(content.len());
    let mut found = Vec::new();
    let mut pending = String::new();
    let mut last = 0;
    loop {
        let next = SHAPES.iter().filter_map(|n| content[last..].find(&format!("<{n} ")).map(|k| (last + k, *n))).min();
        let Some((s, name)) = next else { break };
        let e = element_end(content, s, name).unwrap_or(content.len());
        flush(&mut out, &content[last..s], &mut pending);
        let host = paragraphs_in(&out).saturating_sub(1);
        let element = &content[s..e];
        let tag = &element[..element.find('>').unwrap_or(element.len())];
        let kind = match name {
            "draw:ellipse" | "draw:circle" => 1,
            "draw:rect" => if attr(tag, "draw:corner-radius").is_some() { 2 } else { 0 },
            _ => match element.find("<draw:enhanced-geometry").and_then(|g| attr(&element[g..], "draw:type")) {
                Some("ellipse") | Some("circle") => 1,
                Some("round-rectangle") => 2,
                Some("rectangle") | Some("rect") => 0,
                _ => 9, // géométrie inconnue : non dessinée
            },
        };
        let len = |k: &str| attr(tag, k).and_then(pt);
        if let (Some(w), Some(h), true) = (len("svg:width"), len("svg:height"), kind != 9) {
            found.push(Found {
                host,
                x: len("svg:x").unwrap_or(0.0),
                y: len("svg:y").unwrap_or(0.0),
                w,
                h,
                z: attr(tag, "draw:z-index").and_then(|z| z.parse().ok()).unwrap_or(0),
                style: attr(tag, "draw:style-name").unwrap_or("").to_string(),
                kind,
            });
        }
        // Son texte : des paragraphes après celui qui porte la forme.
        let mut i = 0;
        while let Some(k) = ["<text:p>", "<text:p ", "<text:h>", "<text:h "].iter().filter_map(|t| element[i..].find(t)).min() {
            let ps = i + k;
            let tname = if element[ps..].starts_with("<text:p") { "text:p" } else { "text:h" };
            let pe = element_end(element, ps, tname).unwrap_or(element.len());
            pending.push_str(&element[ps..pe]);
            i = pe;
        }
        last = e;
    }
    flush(&mut out, &content[last..], &mut pending);
    out.push_str(&pending);
    Some((out, found))
}

/// Copie `chunk` ; le texte des formes en attente vient après la première
/// fin de paragraphe.
fn flush(out: &mut String, chunk: &str, pending: &mut String) {
    if pending.is_empty() {
        out.push_str(chunk);
        return;
    }
    match ["</text:p>", "</text:h>"].iter().filter_map(|t| chunk.find(t).map(|k| k + t.len())).min() {
        Some(k) => {
            out.push_str(&chunk[..k]);
            out.push_str(&std::mem::take(pending));
            out.push_str(&chunk[k..]);
        }
        None => out.push_str(chunk),
    }
}

/// Fond et trait des styles graphiques : nom → (fond, trait, épaisseur).
#[cfg(feature = "render")]
fn graphic_styles(xml: &str) -> std::collections::HashMap<String, (Option<(f64, f64, f64)>, Option<(f64, f64, f64)>, f64)> {
    let mut out = std::collections::HashMap::new();
    let rgb = |v: &str| -> Option<(f64, f64, f64)> {
        let h = v.trim().trim_start_matches('#');
        let b = |i: usize| h.get(i..i + 2).and_then(|x| u8::from_str_radix(x, 16).ok()).map(|b| f64::from(b) / 255.0);
        Some((b(0)?, b(2)?, b(4)?))
    };
    let mut i = 0;
    while let Some(k) = xml[i..].find("<style:style ") {
        let s = i + k;
        let tag = &xml[s..s + xml[s..].find('>').unwrap_or(0)];
        i = s + 1;
        if attr(tag, "style:family") != Some("graphic") {
            continue;
        }
        let Some(name) = attr(tag, "style:name") else { continue };
        let end = xml[s..].find("</style:style>").map_or(xml.len(), |e| s + e);
        let body = &xml[s..end];
        let Some(g) = body.find("<style:graphic-properties") else { continue };
        let props = &body[g..g + body[g..].find('>').unwrap_or(0)];
        // Valeurs par défaut de LibreOffice : fond bleu, trait bleu foncé.
        let fill = match attr(props, "draw:fill") {
            Some("none") => None,
            _ => attr(props, "draw:fill-color").and_then(rgb).or(Some((0x72 as f64 / 255.0, 0x9f as f64 / 255.0, 0xcf as f64 / 255.0))),
        };
        let stroke = match attr(props, "draw:stroke") {
            Some("none") => None,
            _ => attr(props, "svg:stroke-color").and_then(rgb).or(Some((0x34 as f64 / 255.0, 0x65 as f64 / 255.0, 0xa4 as f64 / 255.0))),
        };
        let width = attr(props, "svg:stroke-width").and_then(pt).filter(|w| *w > 0.0).unwrap_or(0.75);
        out.insert(name.to_string(), (fill, stroke, width));
    }
    out
}

/// L'image des formes et le paragraphe après lequel la placer.
#[cfg(feature = "render")]
pub fn picture(content: &str, found: &[Found]) -> Option<(Vec<u8>, f64, f64, usize)> {
    let styles = graphic_styles(content);
    let base = found.iter().map(|f| f.host).min()?;
    // Une hauteur de paragraphe ordinaire, pour les formes ancrées à des
    // paragraphes différents.
    let para_h = 16.0;
    let list: Vec<crate::docx_shapes::Shape> = found
        .iter()
        .map(|f| {
            let (fill, stroke, stroke_w) = styles.get(&f.style).copied().unwrap_or((Some((0.447, 0.624, 0.812)), Some((0.204, 0.396, 0.643)), 0.75));
            crate::docx_shapes::Shape { kind: f.kind, x: f.x, y: f.y + (f.host - base) as f64 * para_h, w: f.w, h: f.h, z: f.z, fill, stroke, stroke_w }
        })
        .collect();
    let (png, w, h, _) = crate::docx_shapes::draw(list)?;
    Some((png, w, h, base + 1))
}

#[cfg(test)]
mod tests {
    #[test]
    fn shapes_leave_their_text_after_the_host_paragraph() {
        let xml = r#"<office:text><text:p>Titre<draw:custom-shape svg:x="0cm" svg:y="1cm" svg:width="2.54cm" svg:height="1in" draw:z-index="3"><text:p>dans</text:p><draw:enhanced-geometry draw:type="ellipse"/></draw:custom-shape></text:p><text:p>Suite</text:p></office:text>"#;
        let (out, found) = super::take(xml).unwrap();
        assert_eq!(out, "<office:text><text:p>Titre</text:p><text:p>dans</text:p><text:p>Suite</text:p></office:text>");
        assert_eq!(found.len(), 1);
        let f = &found[0];
        assert_eq!((f.host, f.kind, f.z), (0, 1, 3));
        assert!((f.w - 72.0).abs() < 0.01 && (f.h - 72.0).abs() < 0.01);
    }
}
