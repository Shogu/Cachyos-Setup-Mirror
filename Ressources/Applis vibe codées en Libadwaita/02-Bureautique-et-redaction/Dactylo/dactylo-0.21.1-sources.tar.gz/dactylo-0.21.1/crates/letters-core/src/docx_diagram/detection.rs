// Les schémas du document : blocs voisins, étiquette gardée, paragraphes
// recouverts.
// SPDX-License-Identifier: GPL-3.0-or-later

use super::*;

pub(super) fn touch(a: (i64, i64, i64, i64), b: (i64, i64, i64, i64), m: i64) -> bool {
    a.0 - m < b.2 && b.0 - m < a.2 && a.1 - m < b.3 && b.1 - m < a.3
}

/// Le paragraphe `p` sans les blocs `cut` (positions dans le document).
pub(super) fn without(xml: &str, s: usize, e: usize, cut: &[(usize, usize)]) -> String {
    let mut out = String::new();
    let mut at = s;
    let mut cuts: Vec<_> = cut.iter().filter(|c| c.0 >= s && c.1 <= e).collect();
    cuts.sort();
    for c in cuts {
        out.push_str(&xml[at..c.0]);
        at = c.1;
    }
    out.push_str(&xml[at..e]);
    out
}

pub(super) fn has_text(p: &str) -> bool {
    let mut at = 0;
    while let Some(s) = find_open(p, "w:t", at) {
        let Some(o) = p[s..].find('>').map(|i| s + i + 1) else { break };
        if p.as_bytes()[o - 2] == b'/' {
            at = o;
            continue;
        }
        let e = p[o..].find("</w:t>").map_or(p.len(), |i| o + i);
        if !p[o..e].trim().is_empty() {
            return true;
        }
        at = e;
    }
    false
}

/// Le bloc avec sa hauteur `positionV` décalée de `dy` (EMU).
pub(super) fn shifted(block: &str, dy: i64) -> String {
    let mut out = String::with_capacity(block.len());
    let mut rest = block;
    while let Some(i) = rest.find("<wp:positionV") {
        let Some(e) = rest[i..].find("</wp:positionV>").map(|e| i + e) else { break };
        let seg = &rest[i..e];
        out.push_str(&rest[..i]);
        match (seg.find("<wp:posOffset>"), seg.find("</wp:posOffset>")) {
            (Some(a), Some(b)) => {
                let v = num(Some(&seg[a + 14..b]));
                out.push_str(&format!("{}<wp:posOffset>{}</wp:posOffset>{}", &seg[..a], v + dy, &seg[b + 15..]));
            }
            _ => out.push_str(seg),
        }
        rest = &rest[e..];
    }
    out.push_str(rest);
    out
}

/// Les schémas du document et le document sans eux (une étiquette à la
/// place de chacun), ou `None` s'il n'y en a pas.
pub fn extract(xml: &str) -> Option<(String, Vec<Diagram>)> {
    if !(xml.contains("<wps:wsp") || xml.contains("<wpg:wgp")) {
        return None;
    }
    let (paras, _) = crate::docx_float::top_level(xml);
    let col = crate::docx_float::column_width(xml);
    let sect = xml.rfind("<w:sectPr").map_or("", |s| &xml[s..]);
    let tw = |name: &str, k: &str, d: f64| tag_at(sect, name).and_then(|t| attr(t, k)).and_then(|v| v.parse::<f64>().ok()).unwrap_or(d);
    let margin = ((tw("w:pgMar", "w:left", 1134.0) * 635.0) as i64, (tw("w:pgMar", "w:top", 1134.0) * 635.0) as i64);
    let text_h = ((tw("w:pgSz", "w:h", 16838.0) - tw("w:pgMar", "w:top", 1134.0) - tw("w:pgMar", "w:bottom", 1134.0)) * 635.0) as i64;
    // Le haut estimé de chaque paragraphe.
    let mut ys = Vec::with_capacity(paras.len());
    let mut y = 0i64;
    for p in &paras {
        ys.push(y);
        y += p.as_ref().map_or(2 * crate::docx_float::LINE_EMU, |p| p.height);
    }
    let mut blocks: Vec<Block> = Vec::new();
    for (i, p) in paras.iter().enumerate() {
        let Some(p) = p else { continue };
        let page_start = ys[i] / text_h.max(1) * text_h;
        blocks.extend(blocks_of(xml, p.start, p.end, i, ys[i], page_start, margin, col));
    }
    if blocks.iter().all(|b| !b.drawn) {
        return None;
    }
    // Les groupes de blocs qui se touchent (à 3 mm près), images à part.
    let n = blocks.len();
    let mut group: Vec<usize> = (0..n).collect();
    fn root(g: &mut Vec<usize>, i: usize) -> usize {
        let mut r = i;
        while g[r] != r {
            r = g[r];
        }
        g[i] = r;
        r
    }
    let boxes: Vec<_> = blocks.iter().map(|b| bbox(&b.elems)).collect();
    for a in 0..n {
        for b in a + 1..n {
            if blocks[a].pic || blocks[b].pic {
                continue;
            }
            // (deux formes dessinées se relient de plus loin : une flèche,
            // une boîte)
            let m = if blocks[a].drawn && blocks[b].drawn { 2 * CM } else { CM * 8 / 10 };
            if touch(boxes[a], boxes[b], m) {
                let (ra, rb) = (root(&mut group, a), root(&mut group, b));
                group[ra.max(rb)] = ra.min(rb);
            }
        }
    }
    let roots: Vec<usize> = (0..n).map(|i| root(&mut group, i)).collect();
    let mut clusters: Vec<Vec<usize>> = Vec::new();
    for i in 0..n {
        if blocks[i].pic {
            continue;
        }
        match clusters.iter_mut().find(|c| roots[c[0]] == roots[i]) {
            Some(c) => c.push(i),
            None => clusters.push(vec![i]),
        }
    }
    // Un schéma : au moins deux éléments, dont une forme visible.
    clusters.retain(|c| c.iter().map(|&i| blocks[i].elems.len()).sum::<usize>() >= 2 && c.iter().any(|&i| blocks[i].drawn));
    if clusters.is_empty() {
        return None;
    }
    // Les images posées dans un schéma en font partie.
    for c in &mut clusters {
        let all: Vec<Elem> = c.iter().flat_map(|&i| blocks[i].elems.clone()).collect();
        let bb = bbox(&all);
        for i in 0..n {
            if blocks[i].pic && touch(bbox(&blocks[i].elems), bb, -CM / 2) {
                c.push(i);
            }
        }
    }
    let mut diagrams = Vec::new();
    // Remplacements dans le document : (début, fin, texte).
    let mut edits: Vec<(usize, usize, String)> = Vec::new();
    let mut taken = vec![false; paras.len()];
    for (k, c) in clusters.iter().enumerate() {
        let label = format!("⟦schéma {}⟧", k + 1);
        let cuts: Vec<(usize, usize)> = c.iter().map(|&i| (blocks[i].start, blocks[i].end)).collect();
        let hosts: Vec<usize> = { let mut h: Vec<usize> = c.iter().map(|&i| blocks[i].host).collect(); h.sort(); h.dedup(); h };
        let first = hosts[0];
        let last_host = *hosts.last().unwrap();
        let elems: Vec<Elem> = c.iter().flat_map(|&i| blocks[i].elems.clone()).collect();
        let bottom = bbox(&elems).3;
        let Some(fp) = paras[first].as_ref() else { continue };
        if taken[first] {
            continue;
        }
        let first_stripped = without(xml, fp.start, fp.end, &cuts);
        let first_text = has_text(&first_stripped);
        // L'étiquette : après le premier hôte s'il a du texte, à sa place sinon.
        let y_label = ys[first] + if first_text { fp.height } else { 0 };
        let label_para = format!("<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\"/><w:jc w:val=\"center\"/></w:pPr><w:r><w:t>{label}</w:t></w:r></w:p>");
        // Les paragraphes que le schéma recouvrait : vides (une fois ses
        // blocs retirés), jusqu'au dernier hôte et sous le bas du schéma.
        // (le premier hôte vide n'est pas replié : le paragraphe de
        // l'étiquette prend sa place, et le schéma y revient à
        // l'enregistrement — le replier aussi ajoutait un paragraphe vide à
        // chaque enregistrement)
        let mut folded = String::new();
        let mut j = first + 1;
        while let Some(Some(p)) = paras.get(j) {
            let stripped = without(xml, p.start, p.end, &cuts);
            let empty = !has_text(&stripped) && !stripped.contains("<w:drawing") && !stripped.contains("<mc:AlternateContent") && !stripped.contains("<w:sectPr") && !stripped.contains("w:type=\"page\"");
            if j > last_host && (!empty || ys[j] >= bottom) {
                break;
            }
            if empty {
                folded.push_str(&stripped);
                edits.push((p.start, p.end, String::new()));
            } else {
                edits.push((p.start, p.end, stripped));
            }
            taken[j] = true;
            j += 1;
        }
        // Le run des formes, leurs hauteurs ramenées au paragraphe de
        // l'étiquette, pour le retour dans Word.
        let mut run = String::from("<w:r>");
        for &i in c {
            let b = &blocks[i];
            let piece = &xml[b.start..b.end];
            if b.para_rel {
                run.push_str(&shifted(piece, ys[b.host] - y_label));
            } else {
                run.push_str(piece);
            }
        }
        run.push_str("</w:r>");
        let keep_xml = format!("{run}</w:p>{folded}<w:p>");
        edits.push((fp.start, fp.end, if first_text { format!("{first_stripped}{label_para}") } else { label_para }));
        taken[first] = true;
        diagrams.push(Diagram { label, keep_xml, elems });
    }
    if diagrams.is_empty() {
        return None;
    }
    edits.sort_by_key(|e| e.0);
    let mut out = String::with_capacity(xml.len());
    let mut at = 0;
    for (s, e, t) in edits {
        if s < at {
            continue;
        }
        out.push_str(&xml[at..s]);
        out.push_str(&t);
        at = e;
    }
    out.push_str(&xml[at..]);
    Some((out, diagrams))
}

