// lists.rs — list markers and list geometry, shared by every renderer.
// SPDX-License-Identifier: GPL-3.0-or-later
//
// A list item's marker ("•", "3.") and its indent are presentation derived
// from the model (`ParaStyle::list`, `list_level`, `list_start`), never
// document text. The editor buffer, the page layout and exporters all ask
// here, so a numbered item cannot be "3." on screen and "1." in print.

use crate::model::{ListKind, ParaStyle};

/// Indent per nesting level, in points. Word's built-in "List Bullet N"
/// styles and LibreOffice's rendering of them step 0.25in per level.
pub const LEVEL_INDENT_PT: f64 = 18.0;

/// Hanging indent of a list item, in points: the marker sits this far left
/// of the item's text, and wrapped lines align with the text, not the marker.
pub const HANGING_PT: f64 = 18.0;

/// Deepest nesting level a renderer distinguishes (Word and ODF allow 9).
pub const MAX_LEVEL: u8 = 8;

/// Left edge of a list item's text, in points from the paragraph's own
/// left indent. The marker starts `HANGING_PT` before it.
pub fn text_indent_pt(level: u8) -> f64 {
    f64::from(level.min(MAX_LEVEL) + 1) * LEVEL_INDENT_PT
}

/// The ordinal each numbered paragraph displays; 0 for every other one.
///
/// Numbering runs per nesting level. A deeper item does not interrupt the
/// count of the level above it (1. / • / 2.), a shallower item restarts
/// every deeper level, and anything that is not a list item ends the list.
/// `list_start` restarts the count at that item.
pub fn ordinals<'a>(styles: impl IntoIterator<Item = &'a ParaStyle>) -> Vec<u32> {
    ordinals_with(styles.into_iter().map(|s| (s, false)))
}

/// Samizdat : `ordinals`, d'après les paragraphes : un paragraphe vide hors
/// liste n'interrompt pas la numérotation.
pub fn ordinals_of<'a>(paras: impl IntoIterator<Item = &'a crate::model::Paragraph>) -> Vec<u32> {
    ordinals_with(paras.into_iter().map(|p| (&p.style, p.runs.iter().all(|r| r.text.trim().is_empty() && r.style.image.is_none()))))
}

fn ordinals_with<'a>(styles: impl IntoIterator<Item = (&'a ParaStyle, bool)>) -> Vec<u32> {
    let mut counters = [0u32; MAX_LEVEL as usize + 1];
    styles
        .into_iter()
        .map(|(style, empty)| {
            if style.list == ListKind::None || style.table_cell.is_some() {
                // Samizdat : une ligne vide entre deux questions numérotées
                // ne recommence pas la liste (Word poursuit la numérotation).
                if !(empty && style.table_cell.is_none()) {
                    counters = [0; MAX_LEVEL as usize + 1];
                }
                return 0;
            }
            let level = usize::from(style.list_level.min(MAX_LEVEL));
            for deeper in &mut counters[level + 1..] {
                *deeper = 0;
            }
            if style.list != ListKind::Numbered {
                counters[level] = 0;
                return 0;
            }
            counters[level] = match style.list_start {
                Some(start) => start,
                None => counters[level] + 1,
            };
            counters[level]
        })
        .collect()
}

/// The marker drawn before a list item's text: a bullet glyph, or the
/// ordinal and a full stop. `None` for a paragraph that is not a list item.
///
/// Samizdat : la numérotation suit le niveau, comme la liste par défaut de
/// Word (et ce que Dactylo écrit dans le DOCX) : 1. puis a. puis i., et on
/// recommence au quatrième niveau.
/// La marque d'un paragraphe de liste, avec le symbole propre de sa puce.
pub fn marker_of(style: &crate::model::ParaStyle, ordinal: u32) -> Option<String> {
    match (&style.bullet_glyph, style.list) {
        (Some(g), ListKind::Bullet) => Some(g.clone()),
        _ => marker(style.list, style.list_level, ordinal),
    }
}

/// Le symbole qu'une puce Word dessine (`w:lvlText`), quand ce n'est pas le
/// rond ordinaire : « o » et « - » tels quels, et les caractères Symbol et
/// Wingdings (rangés par Word dans la zone privée d'Unicode) comme
/// LibreOffice les traduit. `None` pour le rond, ou un symbole inconnu.
pub fn bullet_glyph(text: &str) -> Option<String> {
    let mut chars = text.chars();
    let (c, rest) = (chars.next()?, chars.next());
    if rest.is_some() {
        return None;
    }
    let glyph = match c as u32 {
        0xF0B7 | 0xB7 => '\u{2022}',
        // « § » en Wingdings : le petit carré.
        0xA7 => '\u{25aa}',
        0xF0A7 => '\u{25aa}',
        0xF0D8 => '\u{27a2}',
        0xF0FC => '\u{2713}',
        0xF076 => '\u{2756}',
        0xF06E => '\u{25a0}',
        0xF071 => '\u{274f}',
        0xF0E0 => '\u{27a2}',
        0xF0A8 => '\u{25cf}',
        0xF000..=0xF0FF => return None,
        _ => c,
    };
    (glyph != BULLET && !glyph.is_whitespace()).then(|| glyph.to_string())
}

pub fn marker(kind: ListKind, level: u8, ordinal: u32) -> Option<String> {
    match kind {
        ListKind::None => None,
        ListKind::Bullet => Some(BULLET.to_string()),
        ListKind::Numbered => Some(format!("{}.", ordinal_text(level, ordinal))),
    }
}

/// Le numéro d'un élément de liste à ce niveau : 3, c ou iii.
pub fn ordinal_text(level: u8, n: u32) -> String {
    match level % 3 {
        0 => n.to_string(),
        1 => letters(n),
        _ => roman(n),
    }
}

fn letters(mut n: u32) -> String {
    // a … z, aa, ab … (comme Word)
    let mut s = Vec::new();
    while n > 0 {
        n -= 1;
        s.push(b'a' + (n % 26) as u8);
        n /= 26;
    }
    s.reverse();
    String::from_utf8(s).unwrap_or_default()
}

fn roman(mut n: u32) -> String {
    const T: [(u32, &str); 13] = [(1000, "m"), (900, "cm"), (500, "d"), (400, "cd"), (100, "c"), (90, "xc"), (50, "l"), (40, "xl"), (10, "x"), (9, "ix"), (5, "v"), (4, "iv"), (1, "i")];
    let mut s = String::new();
    for (v, r) in T {
        while n >= v {
            s.push_str(r);
            n -= v;
        }
    }
    s
}

/// The bullet glyph. U+2022, as Word's and LibreOffice's default bullets.
pub const BULLET: char = '\u{2022}';

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::Paragraph;

    fn ords(paras: &[Paragraph]) -> Vec<u32> {
        ordinals(paras.iter().map(|p| &p.style))
    }

    fn item(kind: ListKind, level: u8) -> Paragraph {
        Paragraph {
            style: ParaStyle { list: kind, list_level: level, ..Default::default() },
            runs: vec![crate::model::Run::plain("x")],
        }
    }

    #[test]
    fn numbering_counts_within_a_list() {
        let n = ListKind::Numbered;
        let paras = [item(n, 0), item(n, 0), item(n, 0)];
        assert_eq!(ords(&paras), vec![1, 2, 3]);
    }

    #[test]
    fn nested_items_do_not_interrupt_the_outer_count() {
        let (n, b) = (ListKind::Numbered, ListKind::Bullet);
        let paras = [item(n, 0), item(b, 1), item(n, 1), item(n, 1), item(n, 0), item(n, 1)];
        // The level-1 count restarts under each new level-0 item.
        assert_eq!(ords(&paras), vec![1, 0, 1, 2, 2, 1]);
    }

    #[test]
    fn a_plain_paragraph_ends_the_list() {
        let n = ListKind::Numbered;
        let paras = [item(n, 0), item(n, 0), item(ListKind::None, 0), item(n, 0)];
        assert_eq!(ords(&paras), vec![1, 2, 0, 1]);
    }

    #[test]
    fn list_start_restarts_at_that_item() {
        let n = ListKind::Numbered;
        let mut paras = vec![item(n, 0), item(n, 0), item(n, 0)];
        paras[1].style.list_start = Some(5);
        assert_eq!(ords(&paras), vec![1, 5, 6]);
    }

    #[test]
    fn markers_are_glyphs_not_markdown() {
        assert_eq!(marker(ListKind::Bullet, 0, 0).as_deref(), Some("\u{2022}"));
        assert_eq!(marker(ListKind::Numbered, 0, 12).as_deref(), Some("12."));
        assert_eq!(marker(ListKind::Numbered, 1, 2).as_deref(), Some("b."));
        assert_eq!(marker(ListKind::Numbered, 2, 4).as_deref(), Some("iv."));
        assert_eq!(marker(ListKind::Numbered, 1, 27).as_deref(), Some("aa."));
        assert_eq!(marker(ListKind::None, 0, 0), None);
    }

    #[test]
    fn each_level_indents_one_step_further() {
        assert_eq!(text_indent_pt(0), 18.0);
        assert_eq!(text_indent_pt(2), 54.0);
        assert_eq!(text_indent_pt(200), text_indent_pt(MAX_LEVEL));
    }
}
