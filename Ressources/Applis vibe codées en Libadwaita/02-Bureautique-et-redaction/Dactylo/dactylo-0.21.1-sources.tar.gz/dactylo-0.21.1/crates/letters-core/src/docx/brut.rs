// brut.rs — partie de docx.rs, découpé par thème.
// SPDX-License-Identifier: GPL-3.0-or-later

#![allow(unused_imports)]
use super::*;
use crate::model::{Alignment, Document, ListKind, PageGeometry, Paragraph, ParaStyle, Run, RunStyle};
use rdocx_oxml::shared::ST_Jc;

/// The body-paragraph properties rdocx does not hand back, in twips.
///
/// Two unrelated gaps share one scan of `word/document.xml`: the
/// strict-OOXML indents rdocx never parses, and the tab stops it parses
/// but exposes only as a count (`tab_stop_count`), with no positions.
#[derive(Clone, Default)]
pub(crate) struct RawPara {
    pub(crate) start_twips: Option<f64>,
    pub(crate) end_twips: Option<f64>,
    pub(crate) tab_twips: Vec<f64>,
    /// Direct `w:contextualSpacing` (rdocx does not model it).
    pub(crate) contextual: bool,
    /// Samizdat : `w:suppressLineNumbers`, hors de la numérotation des lignes.
    pub(crate) suppress_lines: bool,
    /// Samizdat : ce paragraphe termine une section (`w:sectPr` dans son
    /// `w:pPr`) qui n'est pas « continue » : la suivante commence sur une
    /// nouvelle page (orientation ou marges qui changent, en général).
    pub(crate) section_end: bool,
    /// Samizdat : trame (`w:shd` du paragraphe) et bordure (`w:pBdr`).
    pub(crate) shading: Option<[u8; 3]>,
    pub(crate) border: Option<crate::model::ParaBorder>,
    /// Samizdat : `w:textAlignment w:val="top"`.
    pub(crate) align_top: bool,
    /// Samizdat : un espace avant négatif (bandeau remonté dans la marge,
    /// docx_alt::lift), en vingtièmes de point.
    pub(crate) lift_twips: Option<f64>,
}

/// Per body paragraph: strict-spelled indents and tab-stop positions.
///
/// ISO/IEC 29500 strict names the horizontal indents `w:start`/`w:end`
/// rather than the transitional `w:left`/`w:right`, and LibreOffice's
/// "Office Open XML Text" export filter writes the strict spelling — as
/// does anything else targeting that conformance class. rdocx reads only
/// the transitional attributes, so those indents arrive as "absent" and
/// the paragraph reads as unindented. Everything else in `w:ind` is
/// already shared between the two spellings (`w:firstLine`, `w:hanging`),
/// as is `w:jc`'s `start`/`end`, which rdocx does map.
///
/// Both vectors are positional, in document order. `body` has one entry
/// per body-level `w:p`, so the caller can pair it with
/// `doc.paragraphs()`. `cells` has one per `w:p` directly inside a
/// top-level table's cells, in the order rdocx's tables → rows → cells →
/// paragraphs walk visits them (#1204). Paragraphs in a table nested inside
/// a cell belong to neither and are skipped.
///
/// Returns the values in twips. Any failure to open or scan the part
/// yields empty vectors, which the caller treats as "nothing to add".
#[derive(Default)]
pub(crate) struct RawParas {
    pub(crate) body: Vec<RawPara>,
    pub(crate) cells: Vec<RawPara>,
    /// Samizdat : pour chaque tableau de premier niveau, le nombre de
    /// paragraphes du corps qui le précèdent (sa place dans le document).
    pub(crate) table_at: Vec<usize>,
    /// Samizdat : une section numérote ses lignes (`w:lnNumType`).
    pub(crate) line_numbering: bool,
    /// Samizdat : chaque fin de section, dans l'ordre : (paragraphe du
    /// corps, section « continue »). Le type d'une section dit comment
    /// *elle* commence : le saut après la section k est celui de la k+1.
    pub(crate) sections: Vec<(usize, bool)>,
}

pub(crate) fn raw_paragraph_props(path: &str) -> RawParas {
    fn scan(path: &str) -> Result<RawParas, Box<dyn std::error::Error>> {
        let mut xml = PATCHED.with(|p| p.borrow().clone()).unwrap_or_default();
        if xml.is_empty() {
            let mut zip = zip::ZipArchive::new(std::fs::File::open(path)?)?;
            std::io::Read::read_to_string(&mut zip.by_name("word/document.xml")?, &mut xml)?;
        }

        let mut reader = quick_xml::Reader::from_str(&xml);
        reader.config_mut().trim_text(true);
        let mut out = RawParas::default();
        let mut table_depth = 0usize;
        // The paragraph list the current depth feeds, if any.
        fn at(out: &mut RawParas, depth: usize) -> Option<&mut Vec<RawPara>> {
            match depth {
                0 => Some(&mut out.body),
                1 => Some(&mut out.cells),
                _ => None,
            }
        }
        // `w:tab` means two different things: a stop inside `w:tabs`, and
        // a tab character inside a run. Only the former has a position,
        // so the flag is what keeps a tabbed line from inventing stops.
        let mut in_tabs = false;
        // Samizdat : dans les propriétés du paragraphe (pas celles de sa
        // marque de fin, ni d'une case) ; dans sa bordure.
        let (mut in_ppr, mut in_prpr, mut in_pbdr) = (false, false, false);
        loop {
            match reader.read_event()? {
                quick_xml::events::Event::Eof => break,
                quick_xml::events::Event::Start(e) => match e.name().as_ref() {
                    "w:tbl" => {
                        if table_depth == 0 {
                            out.table_at.push(out.body.len());
                        }
                        table_depth += 1;
                    }
                    "w:tabs" => in_tabs = true,
                    "w:pPr" => in_ppr = true,
                    "w:rPr" if in_ppr => in_prpr = true,
                    "w:pBdr" if in_ppr => in_pbdr = true,
                    "w:sectPr" if table_depth == 0 => {
                        if let Some(last) = out.body.last_mut() {
                            last.section_end = true;
                        }
                        out.sections.push((out.body.len().saturating_sub(1), false));
                    }
                    "w:p" => {
                        if let Some(list) = at(&mut out, table_depth) {
                            list.push(RawPara::default());
                        }
                    }
                    _ => {}
                },
                quick_xml::events::Event::End(e) => match e.name().as_ref() {
                    "w:tbl" => table_depth = table_depth.saturating_sub(1),
                    "w:tabs" => in_tabs = false,
                    "w:pPr" => in_ppr = false,
                    "w:rPr" => in_prpr = false,
                    "w:pBdr" => in_pbdr = false,
                    _ => {}
                },
                quick_xml::events::Event::Empty(e) => match e.name().as_ref() {
                    // A `w:p` with nothing in it is still a paragraph.
                    "w:p" => {
                        if let Some(list) = at(&mut out, table_depth) {
                            list.push(RawPara::default());
                        }
                    }
                    "w:tab" if in_tabs => {
                        let Some(last) = at(&mut out, table_depth).and_then(|l| l.last_mut()) else { continue };
                        let mut pos = None;
                        let mut val = None;
                        for a in e.attributes().with_checks(false).flatten() {
                            match a.key.as_ref() {
                                "w:pos" => pos = a.value.trim().parse::<f64>().ok(),
                                "w:val" => val = Some(a.value.trim().to_ascii_lowercase()),
                                _ => {}
                            }
                        }
                        // `w:val` decides whether this is a stop at all.
                        // `clear` *removes* an inherited stop at that
                        // position — LibreOffice writes one to drop the
                        // 2cm default — and `bar`/`num` are a rule and a
                        // list's numbering gap, not user tab stops. An
                        // allowlist keeps each of those from arriving as
                        // a phantom stop the document never had.
                        let keep = matches!(
                            val.as_deref().unwrap_or("left"),
                            "left" | "start" | "center" | "centre" | "right" | "end" | "decimal"
                        );
                        if let (Some(v), true) = (pos, keep) {
                            last.tab_twips.push(v);
                        }
                    }
                    "w:contextualSpacing" => {
                        if let Some(last) = at(&mut out, table_depth).and_then(|l| l.last_mut()) {
                            last.contextual = on_off(&e);
                        }
                    }
                    "w:suppressLineNumbers" => {
                        if let Some(last) = at(&mut out, table_depth).and_then(|l| l.last_mut()) {
                            last.suppress_lines = on_off(&e);
                        }
                    }
                    "w:lnNumType" => out.line_numbering = true,
                    // Une section vide (<w:sectPr/>) termine aussi la section.
                    "w:sectPr" if table_depth == 0 => {
                        if let Some(last) = out.body.last_mut() {
                            last.section_end = true;
                        }
                        out.sections.push((out.body.len().saturating_sub(1), false));
                    }
                    "w:type" if table_depth == 0 => {
                        // Le type de section : une section « continue » ne
                        // change pas de page (appliqué à la fin de la
                        // section d'avant, plus bas).
                        let continuous = e.attributes().flatten().any(|a| a.key.as_ref() == "w:val" && a.value.trim() == "continuous");
                        if let Some(last) = out.sections.last_mut() {
                            last.1 = continuous;
                        }
                    }
                    "w:spacing" if in_ppr && !in_prpr => {
                        let Some(last) = at(&mut out, table_depth).and_then(|l| l.last_mut()) else { continue };
                        let before = e.attributes().with_checks(false).flatten().find(|a| a.key.as_ref() == "w:before").and_then(|a| a.value.trim().parse::<f64>().ok());
                        if let Some(b) = before.filter(|b| *b < 0.0) {
                            last.lift_twips = Some(b);
                        }
                    }
                    "w:textAlignment" if in_ppr && !in_prpr => {
                        let Some(last) = at(&mut out, table_depth).and_then(|l| l.last_mut()) else { continue };
                        last.align_top = e.attributes().with_checks(false).flatten().any(|a| a.key.as_ref() == "w:val" && a.value.trim() == "top");
                    }
                    // Samizdat : trame et bordure du paragraphe.
                    "w:shd" if in_ppr && !in_prpr => {
                        let Some(last) = at(&mut out, table_depth).and_then(|l| l.last_mut()) else { continue };
                        let fill = e.attributes().with_checks(false).flatten().find(|a| a.key.as_ref() == "w:fill").map(|a| a.value.trim().to_string());
                        last.shading = fill.as_deref().and_then(hex_rgb);
                    }
                    "w:top" | "w:bottom" | "w:left" | "w:right" | "w:start" | "w:end" if in_pbdr => {
                        let Some(last) = at(&mut out, table_depth).and_then(|l| l.last_mut()) else { continue };
                        let (mut val, mut sz, mut color) = (String::new(), 4u16, [0u8; 3]);
                        for a in e.attributes().with_checks(false).flatten() {
                            match a.key.as_ref() {
                                "w:val" => val = a.value.trim().to_string(),
                                "w:sz" => sz = a.value.trim().parse().unwrap_or(4),
                                "w:color" => color = hex_rgb_any(a.value.trim()).unwrap_or([0, 0, 0]),
                                _ => {}
                            }
                        }
                        if !matches!(val.as_str(), "" | "none" | "nil") {
                            let side = match e.name().as_ref() {
                                "w:top" => crate::model::ParaBorder::TOP,
                                "w:bottom" => crate::model::ParaBorder::BOTTOM,
                                "w:left" | "w:start" => crate::model::ParaBorder::LEFT,
                                _ => crate::model::ParaBorder::RIGHT,
                            };
                            let b = last.border.get_or_insert(crate::model::ParaBorder { sides: 0, width: sz, color });
                            b.sides |= side;
                            b.width = b.width.max(sz);
                        }
                    }
                    "w:ind" => {
                        let Some(last) = at(&mut out, table_depth).and_then(|l| l.last_mut()) else { continue };
                        for a in e.attributes().with_checks(false).flatten() {
                            let v = || {
                                a.value.trim().parse::<f64>().ok()
                            };
                            match a.key.as_ref() {
                                "w:start" => last.start_twips = v(),
                                "w:end" => last.end_twips = v(),
                                _ => {}
                            }
                        }
                    }
                    _ => {}
                },
                _ => {}
            }
        }
        // Le saut après une section : selon le type de la section suivante.
        for k in 0..out.sections.len() {
            let (i, _) = out.sections[k];
            if let (Some(next), Some(p)) = (out.sections.get(k + 1), out.body.get_mut(i)) {
                p.section_end = !next.1;
            }
        }
        Ok(out)
    }
    scan(path).unwrap_or_default()
}

/// Lay the scanned properties over what rdocx read. Transitional wins
/// where both are present: it is what rdocx read, and a file carrying
/// both is already self-contradictory.
pub(crate) fn apply_strict_indents(style: &mut ParaStyle, raw: &RawPara) {
    if style.left_indent_pt == 0.0 {
        if let Some(tw) = raw.start_twips { style.left_indent_pt = tw / 20.0; }
    }
    if style.right_indent_pt == 0.0 {
        if let Some(tw) = raw.end_twips { style.right_indent_pt = tw / 20.0; }
    }
    style.tab_stops_pt = raw.tab_twips.iter().map(|tw| tw / 20.0).collect();
    // Samizdat : trame et bordure (rdocx ne les rend pas lisibles).
    style.shading = raw.shading;
    style.border = raw.border;
    style.align_top = raw.align_top;
    if let Some(tw) = raw.lift_twips {
        style.space_before_pt = tw / 20.0;
    }
}

/// An OOXML on/off element's value: present means on, unless `w:val`
/// says "0", "false" or "off".
pub(crate) fn on_off(e: &quick_xml::events::BytesStart<'_>) -> bool {
    !e.attributes().with_checks(false).flatten().any(|a| {
        a.key.as_ref() == "w:val" && matches!(a.value.trim(), "0" | "false" | "off")
    })
}

/// Paragraph styles whose paragraphs have `w:contextualSpacing` ("don't add
/// space between paragraphs of the same style"), through `w:basedOn`.
/// Word's list styles set it: without it every list item of a python-docx
/// or Word list would be 10pt apart.
pub(crate) fn contextual_styles(path: &str) -> std::collections::HashSet<String> {
    /// (style id, basedOn, contextualSpacing if the style itself says)
    type StyleSpacing = (String, Option<String>, Option<bool>);
    fn scan(path: &str) -> Result<Vec<StyleSpacing>, Box<dyn std::error::Error>> {
        let mut zip = zip::ZipArchive::new(std::fs::File::open(path)?)?;
        let mut xml = String::new();
        std::io::Read::read_to_string(&mut zip.by_name("word/styles.xml")?, &mut xml)?;
        let mut reader = quick_xml::Reader::from_str(&xml);
        reader.config_mut().trim_text(true);
        let mut out: Vec<StyleSpacing> = Vec::new();
        let attr = |e: &quick_xml::events::BytesStart<'_>, key: &str| {
            e.attributes().with_checks(false).flatten().find(|a| a.key.as_ref() == key).map(|a| a.value.to_string())
        };
        loop {
            match reader.read_event()? {
                quick_xml::events::Event::Eof => break,
                quick_xml::events::Event::Start(e) if e.name().as_ref() == "w:style" => {
                    out.push((attr(&e, "w:styleId").unwrap_or_default(), None, None));
                }
                quick_xml::events::Event::Empty(e) => match e.name().as_ref() {
                    "w:basedOn" => {
                        if let Some(last) = out.last_mut() {
                            last.1 = attr(&e, "w:val");
                        }
                    }
                    "w:contextualSpacing" => {
                        if let Some(last) = out.last_mut() {
                            last.2 = Some(on_off(&e));
                        }
                    }
                    _ => {}
                },
                _ => {}
            }
        }
        Ok(out)
    }
    let styles = scan(path).unwrap_or_default();
    let by_id: std::collections::HashMap<&str, &StyleSpacing> =
        styles.iter().map(|s| (s.0.as_str(), s)).collect();
    styles
        .iter()
        .filter(|s| {
            // Walk basedOn to the first style that decides; bounded, as a
            // hostile file may make the chain a cycle.
            let mut cur = Some(*s);
            for _ in 0..32 {
                let Some(style) = cur else { return false };
                if let Some(on) = style.2 {
                    return on;
                }
                cur = style.1.as_deref().and_then(|b| by_id.get(b).copied());
            }
            false
        })
        .map(|s| s.0.clone())
        .collect()
}
