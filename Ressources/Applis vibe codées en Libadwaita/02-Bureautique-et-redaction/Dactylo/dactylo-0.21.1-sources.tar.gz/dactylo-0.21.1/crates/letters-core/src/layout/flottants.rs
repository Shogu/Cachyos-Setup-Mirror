// SPDX-License-Identifier: GPL-3.0-or-later
// Samizdat : les images flottantes, le texte qui les longe.

use super::*;

/// Samizdat : le paragraphe `p` à partir du caractère `from` de son texte
/// de mise en page (un objet compte pour un) : la suite d'un paragraphe mise
/// en lignes à part. Sa première ligne n'est pas la première du paragraphe :
/// pas de retrait de première ligne.
pub fn paragraph_from(p: &Paragraph, from: usize) -> Paragraph {
    let mut out = p.clone();
    out.style.first_line_indent_pt = 0.0;
    out.runs.clear();
    let mut at = 0usize;
    for r in &p.runs {
        let n = if is_object(r) { 1 } else { r.text.chars().count() };
        if at + n <= from {
            at += n;
            continue;
        }
        if at >= from || is_object(r) {
            out.runs.push(r.clone());
        } else {
            let mut r2 = r.clone();
            r2.text = r.text.chars().skip(from - at).collect();
            out.runs.push(r2);
        }
        at += n;
    }
    out
}

/// Samizdat : une image flottante posée au bord de la colonne : le texte
/// longe `width` points de ce bord jusqu'à `bottom`.
#[derive(Clone, Copy, Debug)]
pub(super) struct Float {
    pub(super) page: usize,
    pub(super) column: usize,
    pub(super) bottom: f64,
    pub(super) width: f64,
    pub(super) left: bool,
}

/// Espace entre une image flottante et le texte qui la longe (Word : 0,32 cm).
pub(super) const FLOAT_GAP_PT: f64 = 9.0;

/// La mise en lignes d'un paragraphe qui commence à `top` dans la colonne,
/// le long de l'image flottante `f` : étroites tant qu'elles sont à côté de
/// l'image, à pleine largeur ensuite.
pub(super) fn shape_beside(p: &Paragraph, col_w: f64, f: Float, top: f64, opts: &LayoutOptions, shaper: &mut dyn Shaper) -> Shaped {
    let narrow_w = (col_w - f.width).max(col_w * 0.3);
    let dx = if f.left { col_w - narrow_w } else { 0.0 };
    let mut narrow = shape_paragraph(p, narrow_w, opts, shaper);
    narrow.box_x += dx;
    narrow.marker_x += dx;
    let ls = spacing(p);
    let mut y = top;
    let mut m = narrow.lines.len();
    for (k, l) in narrow.lines.iter().enumerate() {
        if y >= f.bottom {
            m = k;
            break;
        }
        y += l.natural_height() * ls;
    }
    if m == narrow.lines.len() || m == 0 {
        if m == 0 {
            return shape_paragraph(p, col_w, opts, shaper);
        }
        return narrow;
    }
    let from = narrow.lines[m].start;
    let rest_p = paragraph_from(p, from);
    let rest = shape_paragraph(&rest_p, col_w, opts, shaper);
    let mut lines: Vec<LineBox> = narrow.lines[..m].to_vec();
    let mut per_line: Vec<(f64, f64, usize, usize)> = (0..m).map(|k| (narrow.box_x, narrow.box_w, 0, k)).collect();
    for (k, l) in rest.lines.iter().enumerate() {
        let mut l = l.clone();
        l.start += from;
        l.end += from;
        for o in &mut l.objects {
            o.0 += from;
        }
        lines.push(l);
        per_line.push((rest.box_x, rest.box_w, from, k));
    }
    Shaped { lines, box_x: narrow.box_x, box_w: narrow.box_w, marker_x: narrow.marker_x, per_line }
}
