// Le schéma dessiné (cairo, pango) : formes, flèches, formes libres, texte,
// images.
// SPDX-License-Identifier: GPL-3.0-or-later

use super::*;

/// Le schéma dessiné : une image PNG, sa largeur et sa hauteur en points.
/// `image` donne les octets d'une image du paquet par son `r:embed`.
pub fn render(d: &Diagram, image: &dyn Fn(&str) -> Option<Vec<u8>>) -> Option<(Vec<u8>, f64, f64)> {
    use std::f64::consts::PI;
    let pt = |emu: i64| emu as f64 / 12_700.0;
    let (x0, y0, x1, y1) = bbox(&d.elems);
    let pad = 3.0;
    let (w, h) = (pt(x1 - x0) + 2.0 * pad, pt(y1 - y0) + 2.0 * pad);
    if !(w > 2.0 && h > 2.0 && w < 3000.0 && h < 3000.0) {
        return None;
    }
    let scale = 3.0;
    let surface = cairo::ImageSurface::create(cairo::Format::ARgb32, (w * scale) as i32, (h * scale) as i32).ok()?;
    {
        let cr = cairo::Context::new(&surface).ok()?;
        cr.scale(scale, scale);
        cr.translate(pad - pt(x0), pad - pt(y0));
        let mut list: Vec<&Elem> = d.elems.iter().collect();
        list.sort_by_key(|e| e.z);
        for e in list {
            let (x, y, ew, eh) = (pt(e.x), pt(e.y), pt(e.w), pt(e.h));
            cr.save().ok()?;
            if e.rot.abs() > 0.1 {
                cr.translate(x + ew / 2.0, y + eh / 2.0);
                cr.rotate(e.rot * PI / 180.0);
                cr.translate(-(x + ew / 2.0), -(y + eh / 2.0));
            }
            let set = |c: [u8; 3]| cr.set_source_rgb(f64::from(c[0]) / 255.0, f64::from(c[1]) / 255.0, f64::from(c[2]) / 255.0);
            let g = e.geom.as_str();
            let is_line = g == "line" || g.contains("Connector") || g.contains("connector");
            if g == "pic" {
                if let Some(bytes) = e.embed.as_deref().and_then(image) {
                    draw_picture(&cr, &bytes, x, y, ew, eh);
                }
            } else if is_line {
                let (mut ax, mut ay, mut bx, mut by) = (x, y, x + ew, y + eh);
                if e.flip_h {
                    std::mem::swap(&mut ax, &mut bx);
                }
                if e.flip_v {
                    std::mem::swap(&mut ay, &mut by);
                }
                if let Some((c, lw, dash)) = e.line {
                    set(c);
                    cr.set_line_width(lw);
                    if dash {
                        cr.set_dash(&[3.0 * lw, 2.0 * lw], 0.0);
                    }
                    cr.move_to(ax, ay);
                    if g.starts_with("bentConnector") {
                        let mx = (ax + bx) / 2.0;
                        cr.line_to(mx, ay);
                        cr.line_to(mx, by);
                    }
                    cr.line_to(bx, by);
                    cr.stroke().ok()?;
                    cr.set_dash(&[], 0.0);
                    let arrow = |tx: f64, ty: f64, fx: f64, fy: f64| {
                        let a = (ty - fy).atan2(tx - fx);
                        let s = (lw * 4.0).max(5.0);
                        cr.move_to(tx, ty);
                        cr.line_to(tx - s * (a - 0.4).cos(), ty - s * (a - 0.4).sin());
                        cr.line_to(tx - s * (a + 0.4).cos(), ty - s * (a + 0.4).sin());
                        cr.close_path();
                        let _ = cr.fill();
                    };
                    let (fx, fy) = if g.starts_with("bentConnector") { ((ax + bx) / 2.0, by) } else { (ax, ay) };
                    if e.tail {
                        arrow(bx, by, fx, fy);
                    }
                    if e.head {
                        let (gx, gy) = if g.starts_with("bentConnector") { ((ax + bx) / 2.0, ay) } else { (bx, by) };
                        arrow(ax, ay, gx, gy);
                    }
                }
            } else if g == "cust" {
                for p in &e.paths {
                    cr.save().ok()?;
                    cr.translate(x, y);
                    if e.flip_h {
                        cr.translate(ew, 0.0);
                        cr.scale(-1.0, 1.0);
                    }
                    if e.flip_v {
                        cr.translate(0.0, eh);
                        cr.scale(1.0, -1.0);
                    }
                    cr.scale(ew / p.w.max(1.0), eh / p.h.max(1.0));
                    cr.new_path();
                    let (mut cx, mut cy) = (0.0, 0.0);
                    for c in &p.cmds {
                        match *c {
                            Cmd::Move(a, b) => {
                                cr.move_to(a, b);
                                (cx, cy) = (a, b);
                            }
                            Cmd::Line(a, b) => {
                                cr.line_to(a, b);
                                (cx, cy) = (a, b);
                            }
                            Cmd::Cubic(a, b, c2, d, e2, f) => {
                                cr.curve_to(a, b, c2, d, e2, f);
                                (cx, cy) = (e2, f);
                            }
                            Cmd::Quad(a, b, c2, d) => {
                                // en cubique
                                cr.curve_to(cx + 2.0 / 3.0 * (a - cx), cy + 2.0 / 3.0 * (b - cy), c2 + 2.0 / 3.0 * (a - c2), d + 2.0 / 3.0 * (b - d), c2, d);
                                (cx, cy) = (c2, d);
                            }
                            Cmd::Arc(wr, hr, st, sw) => {
                                let (s0, s1) = (st.to_radians(), (st + sw).to_radians());
                                let (ox, oy) = (cx - wr * s0.cos(), cy - hr * s0.sin());
                                cr.save().ok()?;
                                cr.translate(ox, oy);
                                cr.scale(wr.max(1e-6), hr.max(1e-6));
                                if sw >= 0.0 {
                                    cr.arc(0.0, 0.0, 1.0, s0, s1);
                                } else {
                                    cr.arc_negative(0.0, 0.0, 1.0, s0, s1);
                                }
                                cr.restore().ok()?;
                                (cx, cy) = (ox + wr * s1.cos(), oy + hr * s1.sin());
                            }
                            Cmd::Close => cr.close_path(),
                        }
                    }
                    cr.restore().ok()?;
                    if let (true, Some(c)) = (p.fill, e.fill) {
                        set(c);
                        cr.fill_preserve().ok()?;
                    }
                    if let (true, Some((c, lw, _))) = (p.stroke, e.line) {
                        set(c);
                        cr.set_line_width(lw);
                        cr.stroke().ok()?;
                    }
                    cr.new_path();
                }
                if !e.text.is_empty() {
                    draw_text(&cr, e, x, y, ew, eh);
                }
            } else {
                shape_path(&cr, g, x, y, ew, eh, e.flip_h, e.flip_v);
                if let Some(c) = e.fill {
                    set(c);
                    cr.fill_preserve().ok()?;
                }
                if let Some((c, lw, dash)) = e.line {
                    set(c);
                    cr.set_line_width(lw);
                    if dash {
                        cr.set_dash(&[3.0 * lw, 2.0 * lw], 0.0);
                    }
                    cr.stroke().ok()?;
                    cr.set_dash(&[], 0.0);
                }
                cr.new_path();
                if !e.text.is_empty() {
                    draw_text(&cr, e, x, y, ew, eh);
                }
            }
            cr.restore().ok()?;
        }
    }
    let mut png = Vec::new();
    surface.write_to_png(&mut png).ok()?;
    Some((png, w, h))
}

#[allow(clippy::too_many_arguments)]
pub(super) fn shape_path(cr: &cairo::Context, g: &str, x: f64, y: f64, w: f64, h: f64, flip_h: bool, flip_v: bool) {
    use std::f64::consts::{FRAC_PI_2, PI, TAU};
    cr.new_path();
    // Une flèche pleine, la pointe vers la droite, retournée ensuite.
    let block_arrow = |cr: &cairo::Context, (x, y, w, h): (f64, f64, f64, f64), dir: u8| {
        // dir : 0 droite, 1 gauche, 2 haut, 3 bas
        let (l, t) = (w, h);
        let pts: [(f64, f64); 7] = [(0.0, 0.25), (0.6, 0.25), (0.6, 0.0), (1.0, 0.5), (0.6, 1.0), (0.6, 0.75), (0.0, 0.75)];
        for (i, &(u, v)) in pts.iter().enumerate() {
            let (px, py) = match dir {
                0 => (x + u * l, y + v * t),
                1 => (x + (1.0 - u) * l, y + v * t),
                2 => (x + v * l, y + (1.0 - u) * t),
                _ => (x + v * l, y + u * t),
            };
            if i == 0 {
                cr.move_to(px, py);
            } else {
                cr.line_to(px, py);
            }
        }
        cr.close_path();
    };
    match g {
        "ellipse" | "flowChartConnector" | "circle" => {
            cr.save().ok();
            cr.translate(x + w / 2.0, y + h / 2.0);
            cr.scale((w / 2.0).max(0.01), (h / 2.0).max(0.01));
            cr.arc(0.0, 0.0, 1.0, 0.0, TAU);
            cr.restore().ok();
        }
        "roundRect" | "flowChartAlternateProcess" => {
            let r = w.min(h) * 0.16;
            cr.new_sub_path();
            cr.arc(x + w - r, y + r, r, -FRAC_PI_2, 0.0);
            cr.arc(x + w - r, y + h - r, r, 0.0, FRAC_PI_2);
            cr.arc(x + r, y + h - r, r, FRAC_PI_2, PI);
            cr.arc(x + r, y + r, r, PI, 1.5 * PI);
            cr.close_path();
        }
        "triangle" => {
            cr.move_to(x + w / 2.0, if flip_v { y + h } else { y });
            cr.line_to(x + w, if flip_v { y } else { y + h });
            cr.line_to(x, if flip_v { y } else { y + h });
            cr.close_path();
        }
        "diamond" | "flowChartDecision" => {
            cr.move_to(x + w / 2.0, y);
            cr.line_to(x + w, y + h / 2.0);
            cr.line_to(x + w / 2.0, y + h);
            cr.line_to(x, y + h / 2.0);
            cr.close_path();
        }
        "rightArrow" => block_arrow(cr, (x, y, w, h), if flip_h { 1 } else { 0 }),
        "leftArrow" => block_arrow(cr, (x, y, w, h), if flip_h { 0 } else { 1 }),
        "upArrow" => block_arrow(cr, (x, y, w, h), if flip_v { 3 } else { 2 }),
        "downArrow" => block_arrow(cr, (x, y, w, h), if flip_v { 2 } else { 3 }),
        _ => cr.rectangle(x, y, w, h),
    }
}

pub(super) fn draw_text(cr: &cairo::Context, e: &Elem, x: f64, y: f64, w: f64, h: f64) {
    let pt = |emu: i64| emu as f64 / 12_700.0;
    let (l, t, r, b) = (pt(e.insets[0]), pt(e.insets[1]), pt(e.insets[2]), pt(e.insets[3]));
    let width = (w - l - r).max(4.0);
    let layout = pangocairo::functions::create_layout(cr);
    // (le dessin est en points : 72 points par pouce)
    pangocairo::functions::context_set_resolution(&layout.context(), 72.0);
    layout.context_changed();
    let mut text = String::new();
    let attrs = pango::AttrList::new();
    let mut last_align = 0;
    for (k, p) in e.text.iter().enumerate() {
        if k > 0 {
            text.push('\u{2029}');
        }
        last_align = p.align;
        for (s, size, bold, italic, color, under) in &p.runs {
            let start = text.len() as u32;
            text.push_str(s);
            let end = text.len() as u32;
            let add = |mut a: pango::Attribute| {
                a.set_start_index(start);
                a.set_end_index(end);
                attrs.insert(a);
            };
            add(pango::AttrSize::new((size * f64::from(pango::SCALE)) as i32).into());
            if *bold {
                add(pango::AttrInt::new_weight(pango::Weight::Bold).into());
            }
            if *italic {
                add(pango::AttrInt::new_style(pango::Style::Italic).into());
            }
            if *under {
                add(pango::AttrInt::new_underline(pango::Underline::Single).into());
            }
            if let Some(c) = color {
                add(pango::AttrColor::new_foreground(u16::from(c[0]) * 257, u16::from(c[1]) * 257, u16::from(c[2]) * 257).into());
            }
        }
    }
    let text = text.replace('\n', "\u{2028}");
    if text.trim().is_empty() {
        return;
    }
    let mut font = pango::FontDescription::from_string("Liberation Sans 11");
    font.set_size(11 * pango::SCALE);
    layout.set_font_description(Some(&font));
    layout.set_text(&text);
    layout.set_attributes(Some(&attrs));
    layout.set_width((width * f64::from(pango::SCALE)) as i32);
    layout.set_wrap(pango::WrapMode::WordChar);
    layout.set_alignment(match last_align {
        1 => pango::Alignment::Center,
        2 => pango::Alignment::Right,
        _ => pango::Alignment::Left,
    });
    // (l'alignement de chaque paragraphe : Pango n'en a qu'un ; le centre
    // l'emporte s'il y en a un)
    if e.text.iter().any(|p| p.align == 1) {
        layout.set_alignment(pango::Alignment::Center);
    }
    let (_, logical) = layout.pixel_extents();
    let th = f64::from(logical.height());
    let top = match e.v_anchor {
        1 => y + (h - th) / 2.0,
        2 => y + h - b - th,
        _ => y + t,
    };
    cr.set_source_rgb(0.0, 0.0, 0.0);
    cr.move_to(x + l, top);
    pangocairo::functions::show_layout(cr, &layout);
}

/// Une image (JPEG, PNG…) dessinée dans (x, y, w, h).
pub(super) fn draw_picture(cr: &cairo::Context, bytes: &[u8], x: f64, y: f64, w: f64, h: f64) {
    use gdk_pixbuf::prelude::*;
    let loader = gdk_pixbuf::PixbufLoader::new();
    if loader.write(bytes).is_err() || loader.close().is_err() {
        return;
    }
    let Some(pb) = loader.pixbuf() else { return };
    let pb = if pb.has_alpha() { pb } else { let Ok(p) = pb.add_alpha(false, 0, 0, 0) else { return }; p };
    let (pw, ph) = (pb.width(), pb.height());
    let Ok(mut surf) = cairo::ImageSurface::create(cairo::Format::ARgb32, pw, ph) else { return };
    {
        let stride = surf.stride() as usize;
        let src_stride = pb.rowstride() as usize;
        let src = unsafe { pb.pixels() };
        let Ok(mut dst) = surf.data() else { return };
        for row in 0..ph as usize {
            for col in 0..pw as usize {
                let s = row * src_stride + col * 4;
                let d = row * stride + col * 4;
                let a = u32::from(src[s + 3]);
                let pre = |c: u8| ((u32::from(c) * a + 127) / 255) as u8;
                // cairo ARGB32 (petit-boutiste) : B G R A
                dst[d] = pre(src[s + 2]);
                dst[d + 1] = pre(src[s + 1]);
                dst[d + 2] = pre(src[s]);
                dst[d + 3] = src[s + 3];
            }
        }
    }
    let _ = cr.save();
    cr.translate(x, y);
    cr.scale(w / f64::from(pw.max(1)), h / f64::from(ph.max(1)));
    let _ = cr.set_source_surface(&surf, 0.0, 0.0);
    let _ = cr.paint();
    let _ = cr.restore();
}

