// SPDX-License-Identifier: GPL-3.0-or-later
// Les styles de paragraphe en balises, les listes.

use super::*;

pub(super) const PARA_TAG_PREFIX: &str = "para:";

/// The paragraph properties the fixed tags do not carry, as one tag name:
/// spacing, indents, tab stops, a line spacing no `line-spacing-*` tag
/// names, block quote, code block, named style and a list restart. `None` when the
/// paragraph has none of them.
///
/// Without it all of these were dropped on the way into the editor, so a
/// save wrote the document back without its paragraph spacing and indents,
/// and Print Layout (which reads the document back from the editor) drew
/// every paragraph tight.
pub(super) fn para_tag_name(style: &letters_core::ParaStyle) -> Option<String> {
    let mut parts: Vec<String> = Vec::new();
    let mut num = |key: &str, v: f64| {
        if v != 0.0 {
            parts.push(format!("{key}={v}"));
        }
    };
    num("b", style.space_before_pt);
    num("a", style.space_after_pt);
    num("l", style.left_indent_pt);
    num("r", style.right_indent_pt);
    num("f", style.first_line_indent_pt);
    if !style.tab_stops_pt.is_empty() {
        let tabs: Vec<String> = style.tab_stops_pt.iter().map(f64::to_string).collect();
        parts.push(format!("t={}", tabs.join(",")));
    }
    if line_spacing_tag_name(style.line_spacing).is_none() && (style.line_spacing - 1.0).abs() > 0.001 {
        parts.push(format!("ls={}", style.line_spacing));
    }
    if style.block_quote {
        parts.push("q".into());
    }
    if let Some(start) = style.list_start {
        parts.push(format!("n={start}"));
    }
    if style.keep_with_next {
        parts.push("k".into());
    }
    if let Some(level) = style.toc {
        parts.push(format!("toc={level}"));
    }
    if style.line_numbers {
        parts.push("ln".into());
    }
    // Samizdat : trame et cadre du paragraphe.
    if let Some([r, g, b]) = style.shading {
        parts.push(format!("sh={r:02x}{g:02x}{b:02x}"));
    }
    if let Some(bd) = style.border {
        parts.push(format!("bd={},{},{:02x}{:02x}{:02x}", bd.sides, bd.width, bd.color[0], bd.color[1], bd.color[2]));
    }
    if let Some(lang) = &style.code_block {
        parts.push(format!("c={}", lang.replace(';', "")));
    }
    if let Some(name) = &style.named_style {
        // Last, and the only free text: everything after "s=" is the name.
        parts.push(format!("s={name}"));
    }
    (!parts.is_empty()).then(|| format!("{PARA_TAG_PREFIX}{}", parts.join(";")))
}

/// Read a `para:` tag back into `style`. Inverse of `para_tag_name`.
pub(super) fn apply_para_tag_name(name: &str, style: &mut letters_core::ParaStyle) {
    let Some(mut rest) = name.strip_prefix(PARA_TAG_PREFIX) else { return };
    while !rest.is_empty() {
        if let Some(named) = rest.strip_prefix("s=") {
            style.named_style = Some(named.to_string());
            return;
        }
        let (part, tail) = rest.split_once(';').unwrap_or((rest, ""));
        rest = tail;
        let (key, value) = part.split_once('=').unwrap_or((part, ""));
        let f = || value.parse::<f64>().ok();
        match key {
            "b" => style.space_before_pt = f().unwrap_or(0.0),
            "a" => style.space_after_pt = f().unwrap_or(0.0),
            "l" => style.left_indent_pt = f().unwrap_or(0.0),
            "r" => style.right_indent_pt = f().unwrap_or(0.0),
            "f" => style.first_line_indent_pt = f().unwrap_or(0.0),
            "t" => style.tab_stops_pt = value.split(',').filter_map(|t| t.parse().ok()).collect(),
            "ls" => style.line_spacing = value.parse().unwrap_or(1.0),
            "q" => style.block_quote = true,
            "k" => style.keep_with_next = true,
            "ln" => style.line_numbers = true,
            "toc" => style.toc = value.parse().ok(),
            "n" => style.list_start = value.parse().ok(),
            "c" => style.code_block = Some(value.to_string()),
            "sh" => style.shading = hex3(value),
            "bd" => {
                let mut it = value.split(',');
                if let (Some(sides), Some(width), Some(color)) = (it.next().and_then(|v| v.parse().ok()), it.next().and_then(|v| v.parse().ok()), it.next().and_then(hex3)) {
                    style.border = Some(letters_core::model::ParaBorder { sides, width, color });
                }
            }
            _ => {}
        }
    }
}

/// Create (on first use) the `para:` tag for `style` and return its name.
/// It also draws what it can in the Draft editor: spacing above and below,
/// and — outside lists, whose own tag owns the margin — the indents.
/// Position du numéro de page d'une entrée de table des matières : la
/// largeur du texte d'une page pleine (840 px moins les marges).
pub(super) const TOC_TAB_PX: i32 = 700;

pub(super) fn para_tag(buf: &gtk::TextBuffer, style: &letters_core::ParaStyle) -> Option<String> {
    let name = para_tag_name(style)?;
    if buf.tag_table().lookup(&name).is_none() {
        let px = |pt: f64| (pt * 96.0 / 72.0).round() as i32;
        let tag = gtk::TextTag::builder().name(&name).build();
        if style.space_before_pt > 0.0 {
            tag.set_pixels_above_lines(px(style.space_before_pt));
        }
        if style.space_after_pt > 0.0 {
            tag.set_pixels_below_lines(px(style.space_after_pt));
        }
        if style.list == letters_core::ListKind::None {
            if style.left_indent_pt != 0.0 {
                // (un retrait négatif — texte dans la marge — ne peut pas
                // passer avant le bord de la vue : GTK refuse et l'appli
                // s'arrêtait)
                tag.set_left_margin((EDITOR_LEFT_MARGIN_PX + px(style.left_indent_pt)).max(0));
            }
            if style.first_line_indent_pt != 0.0 {
                tag.set_indent(px(style.first_line_indent_pt));
            }
        }
        if style.right_indent_pt > 0.0 {
            tag.set_right_margin(EDITOR_LEFT_MARGIN_PX + px(style.right_indent_pt));
        }
        // Samizdat : lignes numérotées, un fond bleuté discret.
        if style.line_numbers {
            tag.set_paragraph_background(Some("#eef3fb"));
        }
        // Samizdat : la trame du paragraphe (son cadre est dessiné par
        // tablegrid, par-dessus la page).
        if let Some([r, g, b]) = style.shading {
            tag.set_paragraph_background(Some(&format!("#{r:02x}{g:02x}{b:02x}")));
        }
        // Entrée de table des matières : le numéro de page calé à droite.
        if style.toc.is_some() {
            let mut tabs = gtk4::pango::TabArray::new(1, true);
            tabs.set_tab(0, gtk4::pango::TabAlign::Right, TOC_TAB_PX - px(style.left_indent_pt));
            tag.set_tabs(Some(&tabs));
        }
        buf.tag_table().add(&tag);
    }
    Some(name)
}

/// GtkTextTag name for the list geometry of nesting level `level`.
pub(super) fn list_level_tag_name(level: u8) -> String {
    format!("list-level-{}", level.min(letters_core::lists::MAX_LEVEL))
}

/// Inverse of [`list_level_tag_name`].
pub(super) fn list_level_from_tag_name(name: &str) -> Option<u8> {
    name.strip_prefix("list-level-")?.parse().ok()
}

/// The editor's left margin in pixels (`TextView::set_left_margin`). A tag
/// with its own left margin *replaces* the view's, so list indents are
/// measured from this.
pub const EDITOR_LEFT_MARGIN_PX: i32 = 64;

/// Tag giving a list item at `level` its hanging indent: the marker sits at
/// the level's indent, a tab carries the text to the text indent, and
/// wrapped lines line up with the text rather than under the marker.
/// Created on first use, like the `link:` tags. Returns its name.
pub(crate) fn list_level_tag(buf: &gtk::TextBuffer, level: u8) -> String {
    use letters_core::lists;
    let name = list_level_tag_name(level);
    if buf.tag_table().lookup(&name).is_none() {
        // Points to the editor's pixels (GTK's 96 dpi), as fonts are drawn.
        let px = |pt: f64| (pt * 96.0 / 72.0).round() as i32;
        let hang = px(lists::HANGING_PT);
        let marker_x = px(lists::text_indent_pt(level) - lists::HANGING_PT);
        let mut tabs = gtk4::pango::TabArray::new(1, true);
        tabs.set_tab(0, gtk4::pango::TabAlign::Left, hang);
        let tag = gtk::TextTag::builder()
            .name(&name)
            .left_margin((EDITOR_LEFT_MARGIN_PX + marker_x).max(0))
            .indent(-hang)
            .tabs(&tabs)
            .build();
        buf.tag_table().add(&tag);
    }
    name
}

/// The editor shows a list item as its marker ("•", "3.") and a tab,
/// followed by the item's text; the model wants `ListKind` and the text
/// alone. Strip the marker and set the kind when capturing.
///
/// `tag_level` is the level carried by the paragraph's `list-level-N` tag.
/// A line without one (typed by hand, or pasted) still counts as a list
/// item when it starts with a marker; then four leading spaces make one
/// nesting level. Markdown's "- " and "N. " are accepted as typed markers.
/// A list marker at the start of an editor line: its kind, the number of
/// leading spaces, the marker's own length in chars (marker and separator),
/// and a numbered item's number.
pub(super) fn list_marker_prefix(text: &str) -> Option<(letters_core::ListKind, usize, usize, u32)> {
    let indent = text.len() - text.trim_start_matches(' ').len();
    let body = &text[indent..];
    // A marker is followed by a tab (as rendered) or a space (as typed).
    let separated = |rest: &str| rest.starts_with(['\t', ' ']);
    if let Some(rest) = body.strip_prefix(letters_core::lists::BULLET) {
        return separated(rest).then_some((letters_core::ListKind::Bullet, indent, 2, 0));
    }
    if body.starts_with("- ") {
        return Some((letters_core::ListKind::Bullet, indent, 2, 0));
    }
    let digits = body.chars().take_while(|c| c.is_ascii_digit()).count();
    if let Some(rest) = body[digits..].strip_prefix('.') {
        if digits > 0 && separated(rest) {
            return Some((letters_core::ListKind::Numbered, indent, digits + 2, body[..digits].parse().unwrap_or(0)));
        }
    }
    // Samizdat : « a. » ou « iv. » des niveaux 2 et 3, toujours suivis d'une
    // tabulation (le marqueur rendu ; un « a. » tapé n'est pas une liste).
    let letters = body.chars().take_while(|c| c.is_ascii_lowercase()).count();
    match body[letters..].strip_prefix('.') {
        Some(rest) if (1..=6).contains(&letters) && rest.starts_with('\t') => {
            Some((letters_core::ListKind::Numbered, indent, letters + 2, alpha_ordinal(&body[..letters])))
        }
        _ => None,
    }
}

/// Le rang d'un numéro en lettres : « c » → 3, « iv » → 4. Un mot fait
/// seulement des chiffres romains est lu en romain (sauf une lettre seule,
/// lue comme lettre : « c. » est le troisième, pas le centième).
pub(super) fn alpha_ordinal(token: &str) -> u32 {
    let roman = |c: char| match c {
        'i' => 1,
        'v' => 5,
        'x' => 10,
        'l' => 50,
        'c' => 100,
        'd' => 500,
        'm' => 1000,
        _ => 0,
    };
    if token.len() > 1 && token.chars().all(|c| roman(c) > 0) || token == "i" {
        let v: Vec<u32> = token.chars().map(roman).collect();
        return v.iter().enumerate().map(|(k, &x)| if v.get(k + 1).is_some_and(|&n| n > x) { -(x as i64) } else { x as i64 }).sum::<i64>().max(0) as u32;
    }
    token.bytes().fold(0u32, |acc, b| acc * 26 + u32::from(b - b'a' + 1))
}

/// Enter at the caret inside a list item: continue the list with the next
/// marker (at the same level), or, on an empty item, end the list by
/// removing that item's marker. `false` when the caret is not in a list
/// item, so Enter does what it always does. Shared by both views.
pub(crate) fn enter_in_list(buf: &gtk::TextBuffer) -> bool {
    let cursor = buf.iter_at_mark(&buf.get_insert());
    let mut line_start = cursor;
    line_start.set_line_offset(0);
    let mut line_end = cursor;
    if !line_end.ends_line() {
        line_end.forward_to_line_end();
    }
    let line = buf.text(&line_start, &line_end, false).to_string();
    let Some((kind, indent, marker, number)) = list_marker_prefix(&line) else { return false };
    // The caret inside the marker itself is not "in the item".
    if (cursor.line_offset() as usize) < indent + marker {
        return false;
    }
    let level_tag = line_start
        .tags()
        .into_iter()
        .find(|t| t.name().is_some_and(|n| list_level_from_tag_name(&n).is_some()));
    let body_empty = line.chars().skip(indent + marker).all(char::is_whitespace);
    buf.begin_user_action();
    if body_empty {
        let mut s = line_start;
        let mut e = line_start;
        e.forward_chars((indent + marker) as i32);
        buf.delete(&mut s, &mut e);
        if let Some(tag) = &level_tag {
            let mut end = buf.iter_at_mark(&buf.get_insert());
            if !end.ends_line() {
                end.forward_to_line_end();
            }
            let mut start = end;
            start.set_line_offset(0);
            buf.remove_tag(tag, &start, &end);
        }
    } else {
        buf.delete_selection(true, true);
        let next = match kind {
            letters_core::ListKind::Numbered => {
                let level = level_tag.as_ref().and_then(|t| t.name()).and_then(|n| list_level_from_tag_name(&n)).unwrap_or(0);
                format!("{}.\t", letters_core::lists::ordinal_text(level, number + 1))
            }
            _ => format!("{}\t", letters_core::lists::BULLET),
        };
        // An untagged (typed) item keeps its indent as spaces.
        let prefix = if level_tag.is_some() { next } else { format!("{}{next}", " ".repeat(indent)) };
        let mut at = buf.iter_at_mark(&buf.get_insert());
        buf.insert(&mut at, &format!("\n{prefix}"));
        if let Some(tag) = &level_tag {
            let mut start = buf.iter_at_mark(&buf.get_insert());
            start.set_line_offset(0);
            let mut end = start;
            if !end.ends_line() {
                end.forward_to_line_end();
            }
            buf.apply_tag(tag, &start, &end);
        }
    }
    buf.end_user_action();
    true
}

pub(super) fn capture_list_marker(para: &mut Paragraph, tag_level: Option<u8>) -> usize {
    let text = para.text();
    let Some((kind, indent, marker_chars, _)) = list_marker_prefix(&text) else { return 0 };
    para.style.list = kind;
    para.style.list_level = tag_level.unwrap_or((indent / 4) as u8);
    // Remove the indent and marker from the front of the run list. Counts
    // are in chars (the bullet is one char, three bytes), as runs slice.
    let stripped = indent + marker_chars;
    let mut remaining = stripped;
    while remaining > 0 {
        let Some(first) = para.runs.first_mut() else { break };
        let n = first.text.chars().count();
        if n <= remaining {
            remaining -= n;
            para.runs.remove(0);
        } else {
            let byte = first.text.char_indices().nth(remaining).map(|(b, _)| b).unwrap();
            first.text = first.text[byte..].to_string();
            remaining = 0;
        }
    }
    stripped
}
