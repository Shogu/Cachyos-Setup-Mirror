// SPDX-License-Identifier: GPL-3.0-or-later
// Fenêtre : choix de la police.

use super::*;

/// La phrase d'essai du choix de police : le début du Manifeste du parti
/// communiste (traduction de Laura Lafargue, 1885).
pub const FONT_SAMPLE: &str = "Un spectre hante l’Europe\u{a0}: le spectre du communisme. Toutes les puissances de la vieille Europe se sont unies en une Sainte-Alliance pour traquer ce spectre\u{a0}: le pape et le tsar, Metternich et Guizot, les radicaux de France et les policiers d’Allemagne.";

/// Choisir une famille de police, avec la phrase d'essai en français.
/// (GtkFontDialog ne permet pas de choisir la phrase d'essai : on garde
/// l'ancienne fenêtre de choix, qui le permet.)
#[allow(deprecated)]
pub fn choose_font_family(parent: &impl IsA<gtk::Widget>, title: &str, current: &str, done: impl Fn(String) + 'static) {
    let window = parent.as_ref().root().and_then(|r| r.downcast::<gtk::Window>().ok());
    let d = gtk::FontChooserDialog::new(Some(title), window.as_ref());
    d.set_modal(true);
    d.set_level(gtk::FontChooserLevel::FAMILY);
    d.set_preview_text(FONT_SAMPLE);
    if !current.is_empty() {
        d.set_font(&format!("{current} 12"));
    }
    d.connect_response(move |d, r| {
        if r == gtk::ResponseType::Ok {
            if let Some(f) = d.font_family() {
                done(f.name().to_string());
            }
        }
        d.destroy();
    });
    d.present();
}
