// SPDX-License-Identifier: GPL-3.0-or-later
// Fenêtre : Image : taille et recadrage.

use super::*;

/// `ocr(chemin, décalage)` : lire le texte de l'image (bouton « Extraire le
/// texte »), l'image étant au curseur, à ce décalage du tampon.
pub fn image(parent: &impl IsA<gtk::Widget>, buf: &gtk::TextBuffer, toast: impl Fn(&str) + 'static, ocr: impl Fn(String, i32) + 'static) {
    use crate::retouch::{self, Retouch};
    use std::cell::{Cell, RefCell};
    let Some((seq, run)) = commands::image_at_caret(buf) else {
        toast("Placez le curseur juste à côté d'une image");
        return;
    };
    // Samizdat : un schéma gardé : on modifie le texte de ses cases.
    let kept = commands::document(buf).kept;
    if kept.iter().any(|k| k.label == run.text && k.label.starts_with("⟦schéma")) {
        diagram(parent, buf, seq, run, toast);
        return;
    }
    let src = run.style.image.clone().unwrap_or_default();
    let Ok(original) = gtk::gdk_pixbuf::Pixbuf::from_file(&src) else {
        toast("Image illisible");
        return;
    };
    let (nw, nh) = (original.width(), original.height());
    let (ew, eh) = run.style.image_extent_emu.unwrap_or(((nw as f64 * commands::EMU_PER_PX) as u64, (nh as f64 * commands::EMU_PER_PX) as u64));
    // Aperçu rapide : l'image réduite, retouchée à chaque réglage.
    let small = {
        let k = (520.0 / nw.max(nh) as f64).min(1.0);
        original.scale_simple(((nw as f64 * k) as i32).max(1), ((nh as f64 * k) as i32).max(1), gtk::gdk_pixbuf::InterpType::Bilinear).unwrap_or_else(|| original.clone())
    };
    let doc = commands::document(buf);
    let image_para = letters_core::edit::locate(&doc, seq).map(|(p, _)| p);
    let caption = image_para.and_then(|p| retouch::caption_of(&doc, p));

    let (dialog, page, apply) = shell("Image", "Appliquer", 460);
    let state = Rc::new(RefCell::new(Retouch::default()));
    let ratio = Rc::new(Cell::new(eh as f64 / ew.max(1) as f64));

    let picture = gtk::Picture::new();
    picture.set_can_shrink(true);
    picture.set_content_fit(gtk::ContentFit::Contain);
    picture.set_size_request(-1, 200);
    picture.add_css_class("samizdat-checker");
    let preview = adw::PreferencesGroup::new();
    preview.add(&picture);
    page.add(&preview);

    // ---- Texte de l'image (OCR) ----
    let ocr_group = adw::PreferencesGroup::builder().title("Texte de l'image").build();
    let ocr_row = adw::ActionRow::builder().title("Extraire le texte").subtitle("Le texte reconnu est ajouté sous l'image").build();
    let ocr_btn = gtk::Button::builder().label("Extraire").valign(gtk::Align::Center).build();
    ocr_row.add_suffix(&ocr_btn);
    ocr_row.set_activatable_widget(Some(&ocr_btn));
    ocr_group.add(&ocr_row);
    page.add(&ocr_group);
    {
        let (d, src, caret) = (dialog.downgrade(), src.clone(), buf.iter_at_mark(&buf.get_insert()).offset());
        ocr_btn.connect_clicked(move |_| {
            if let Some(d) = d.upgrade() {
                d.close();
            }
            ocr(src.clone(), caret);
        });
    }

    // ---- Retouches ----
    let tools = adw::PreferencesGroup::builder().title("Retouches").build();
    let button = |icon: &str, tip: &str| {
        let b = gtk::Button::builder().icon_name(icon).tooltip_text(tip).build();
        b.add_css_class("flat");
        b
    };
    let rot_left = button("object-rotate-left-symbolic", "Pivoter à gauche");
    let rot_right = button("object-rotate-right-symbolic", "Pivoter à droite");
    let flip_h = button("object-flip-horizontal-symbolic", "Retourner horizontalement");
    let flip_v = button("object-flip-vertical-symbolic", "Retourner verticalement");
    let turn_row = adw::ActionRow::builder().title("Orientation").build();
    let turn_box = gtk::Box::new(gtk::Orientation::Horizontal, 2);
    turn_box.set_valign(gtk::Align::Center);
    for b in [&rot_left, &rot_right, &flip_h, &flip_v] {
        turn_box.append(b);
    }
    turn_row.add_suffix(&turn_box);
    tools.add(&turn_row);
    let slider = |title: &str, min: f64, max: f64| {
        let scale = gtk::Scale::with_range(gtk::Orientation::Horizontal, min, max, 1.0);
        scale.set_value(0.0);
        scale.set_draw_value(false);
        scale.set_hexpand(true);
        scale.set_size_request(200, -1);
        scale.add_mark(0.0, gtk::PositionType::Bottom, None);
        let row = adw::ActionRow::builder().title(title).build();
        row.add_suffix(&scale);
        (row, scale)
    };
    let (bright_row, bright) = slider("Luminosité", -100.0, 100.0);
    let (contrast_row, contrast) = slider("Contraste", -100.0, 100.0);
    let (radius_row, radius) = slider("Coins arrondis", 0.0, 25.0);
    radius.clear_marks();
    let frame = adw::SwitchRow::builder().title("Cadre fin").build();
    let reset_tools = gtk::Button::builder().label("Annuler les retouches").halign(gtk::Align::Start).margin_top(6).build();
    for r in [&bright_row, &contrast_row, &radius_row] {
        tools.add(r);
    }
    tools.add(&frame);
    tools.add(&reset_tools);
    page.add(&tools);

    // ---- Taille ----
    let size = adw::PreferencesGroup::builder().title("Taille").description(format!("Taille d'origine : {nw} × {nh} px")).build();
    let width = spin("Largeur (cm)", 0.5, 40.0, 0.1, 1, ew as f64 / commands::EMU_PER_CM, None);
    let height = spin("Hauteur (cm)", 0.5, 60.0, 0.1, 1, eh as f64 / commands::EMU_PER_CM, None);
    let keep = adw::SwitchRow::builder().title("Conserver les proportions").active(true).build();
    size.add(&width);
    size.add(&height);
    size.add(&keep);
    // Samizdat : dans la ligne, ou au bord avec le texte à côté.
    let place = adw::ComboRow::builder()
        .title("Position")
        .subtitle("Le texte peut couler à côté de l'image")
        .model(&gtk::StringList::new(&["Dans le texte", "À gauche, texte à droite", "À droite, texte à gauche"]))
        .build();
    place.set_selected(match run.style.image_float {
        None => 0,
        Some(letters_core::model::ImageFloat::Left) => 1,
        Some(letters_core::model::ImageFloat::Right) => 2,
    });
    size.add(&place);
    page.add(&size);

    // ---- Recadrer ----
    let crop = adw::PreferencesGroup::builder().title("Recadrer").description("Part de l'image à retirer de chaque côté, en %").build();
    let cl = spin("Gauche", 0.0, 90.0, 1.0, 0, 0.0, None);
    let cr = spin("Droite", 0.0, 90.0, 1.0, 0, 0.0, None);
    let ct = spin("Haut", 0.0, 90.0, 1.0, 0, 0.0, None);
    let cb = spin("Bas", 0.0, 90.0, 1.0, 0, 0.0, None);
    for r in [&cl, &cr, &ct, &cb] {
        crop.add(r);
    }
    page.add(&crop);

    // ---- Légende ----
    let cap_group = adw::PreferencesGroup::builder().title("Légende").description("Sous l'image, centrée. Laisser vide pour ne pas en mettre.").build();
    let cap_text = adw::EntryRow::builder().title("Texte de la légende").text(caption.as_ref().map(|c| c.0.clone()).unwrap_or_default()).build();
    let cap_num = adw::SwitchRow::builder().title("Numéroter").subtitle("Document 1, Document 2… dans l'ordre du document").active(caption.as_ref().map_or(crate::prefs::get().caption_numbered, |c| c.1)).build();
    cap_group.add(&cap_text);
    cap_group.add(&cap_num);
    page.add(&cap_group);


    // Les proportions suivent l'image retouchée.
    let guard = Rc::new(Cell::new(false));
    {
        let (h, k, g, ratio) = (height.clone(), keep.clone(), guard.clone(), ratio.clone());
        width.connect_value_notify(move |w| {
            if k.is_active() && !g.get() {
                g.set(true);
                h.set_value(w.value() * ratio.get());
                g.set(false);
            }
        });
    }
    {
        let (w, k, g, ratio) = (width.clone(), keep.clone(), guard.clone(), ratio.clone());
        height.connect_value_notify(move |h| {
            if k.is_active() && !g.get() {
                g.set(true);
                w.set_value(h.value() / ratio.get());
                g.set(false);
            }
        });
    }
    let refresh = {
        let (state, pic, small, ratio, width, height, keep, guard) = (state.clone(), picture.clone(), small.clone(), ratio.clone(), width.clone(), height.clone(), keep.clone(), guard.clone());
        let (cl, cr, ct, cb, bright, contrast, radius, frame) = (cl.clone(), cr.clone(), ct.clone(), cb.clone(), bright.clone(), contrast.clone(), radius.clone(), frame.clone());
        Rc::new(move || {
            {
                let mut st = state.borrow_mut();
                st.crop = (cl.value() / 100.0, ct.value() / 100.0, cr.value() / 100.0, cb.value() / 100.0);
                st.brightness = bright.value();
                st.contrast = contrast.value();
                st.radius = radius.value();
                st.frame = frame.is_active();
            }
            let out = retouch::process(&small, &state.borrow());
            pic.set_paintable(Some(&gtk::gdk::Texture::for_pixbuf(&out)));
            ratio.set(out.height() as f64 / out.width().max(1) as f64);
            if keep.is_active() && !guard.get() {
                guard.set(true);
                height.set_value(width.value() * ratio.get());
                guard.set(false);
            }
        })
    };
    refresh();
    for s in [&cl, &cr, &ct, &cb] {
        let r = refresh.clone();
        s.connect_value_notify(move |_| r());
    }
    for s in [&bright, &contrast, &radius] {
        let r = refresh.clone();
        s.connect_value_changed(move |_| r());
    }
    {
        let r = refresh.clone();
        frame.connect_active_notify(move |_| r());
    }
    // Pivoter : largeur et hauteur s'échangent.
    for (b, turn) in [(&rot_left, 3u32), (&rot_right, 1u32)] {
        let (state, r, width, height, guard) = (state.clone(), refresh.clone(), width.clone(), height.clone(), guard.clone());
        b.connect_clicked(move |_| {
            {
                let mut st = state.borrow_mut();
                st.quarter_turns = (st.quarter_turns + turn) % 4;
            }
            guard.set(true);
            let (w, h) = (width.value(), height.value());
            width.set_value(h);
            height.set_value(w);
            guard.set(false);
            r();
        });
    }
    for (b, horizontal) in [(&flip_h, true), (&flip_v, false)] {
        let (state, r) = (state.clone(), refresh.clone());
        b.connect_clicked(move |_| {
            {
                let mut st = state.borrow_mut();
                if horizontal {
                    st.flip_h = !st.flip_h;
                } else {
                    st.flip_v = !st.flip_v;
                }
            }
            r();
        });
    }
    {
        let (state, r, bright, contrast, radius, frame) = (state.clone(), refresh.clone(), bright.clone(), contrast.clone(), radius.clone(), frame.clone());
        reset_tools.connect_clicked(move |_| {
            *state.borrow_mut() = Retouch::default();
            bright.set_value(0.0);
            contrast.set_value(0.0);
            radius.set_value(0.0);
            frame.set_active(false);
            r();
        });
    }

    let (d, buf) = (dialog.downgrade(), buf.clone());
    let toast = Rc::new(toast);
    apply.connect_clicked(move |_| {
        let mut new_run = run.clone();
        let st = *state.borrow();
        if !st.is_identity() {
            match retouch::apply(&src, &st) {
                Ok((path, _, _)) => new_run.style.image = Some(path),
                Err(e) => {
                    toast(&format!("Retouche impossible : {e}"));
                    return;
                }
            }
        }
        new_run.style.image_extent_emu = Some(((width.value() * commands::EMU_PER_CM) as u64, (height.value() * commands::EMU_PER_CM) as u64));
        new_run.style.image_float = match place.selected() {
            1 => Some(letters_core::model::ImageFloat::Left),
            2 => Some(letters_core::model::ImageFloat::Right),
            _ => None,
        };
        commands::replace_image(&buf, seq, new_run);
        let (text, numbered) = (cap_text.text().to_string(), cap_num.is_active());
        let before = caption.clone().unwrap_or_default();
        if image_para.is_some() && (text.trim() != before.0.trim() || (numbered != before.1 && !text.trim().is_empty())) {
            retouch::set_caption(&buf, seq, &text, numbered);
        }
        if let Some(d) = d.upgrade() {
            d.close();
        }
    });
    dialog.present(Some(parent));
}
