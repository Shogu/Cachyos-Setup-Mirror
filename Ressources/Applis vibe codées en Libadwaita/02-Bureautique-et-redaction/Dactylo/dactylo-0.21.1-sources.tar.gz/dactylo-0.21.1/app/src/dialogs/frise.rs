// SPDX-License-Identifier: GPL-3.0-or-later
// Fenêtre : Frise chronologique.

use super::*;

/// La frise : un titre, des lignes date / événement, un aperçu. `apply`
/// reçoit la frise et le PNG dessiné.
pub fn frise(parent: &impl IsA<gtk::Widget>, initial: Option<crate::frise::Frise>, family: String, apply: impl Fn(crate::frise::Frise, std::path::PathBuf) + 'static) {
    use crate::frise::Frise;
    use std::cell::RefCell;
    let editing = initial.is_some();
    let f0 = initial.unwrap_or_else(|| Frise { title: String::new(), events: vec![Default::default(); 4] });
    let (dialog, page, ok) = shell("Frise chronologique", if editing { "Modifier" } else { "Insérer" }, 680);
    dialog.set_content_height(760);

    let preview = gtk::Picture::builder().content_fit(gtk::ContentFit::Contain).height_request(190).can_shrink(true).build();
    preview.add_css_class("card");
    let pg = adw::PreferencesGroup::new();
    pg.add(&preview);
    page.add(&pg);

    let g = adw::PreferencesGroup::new();
    let title = adw::EntryRow::builder().title("Titre de la frise").text(&f0.title).build();
    g.add(&title);
    page.add(&g);

    let add = gtk::Button::builder().icon_name("list-add-symbolic").tooltip_text("Ajouter une ligne").valign(gtk::Align::Center).build();
    add.add_css_class("flat");
    let rows_group = adw::PreferencesGroup::builder()
        .title("Dates et événements")
        .description("Une période : « 1914-1918 ». Avant notre ère : « 52 av. J.-C. ». Un jour : « 11 novembre 1918 ».")
        .header_suffix(&add)
        .build();
    let list = gtk::ListBox::builder().selection_mode(gtk::SelectionMode::None).build();
    list.add_css_class("boxed-list");
    rows_group.add(&list);
    page.add(&rows_group);

    type Row = (gtk::ListBoxRow, gtk::Entry, gtk::Entry);
    let rows: Rc<RefCell<Vec<Row>>> = Rc::default();
    let current = {
        let (rows, title) = (rows.clone(), title.clone());
        move || Frise { title: title.text().to_string(), events: rows.borrow().iter().map(|(_, d, e)| (d.text().to_string(), e.text().to_string())).collect() }
    };
    let current = Rc::new(current);
    // L'aperçu, redessiné peu après chaque frappe.
    let pending: Rc<std::cell::Cell<Option<glib::SourceId>>> = Rc::default();
    let last_png: Rc<RefCell<Option<std::path::PathBuf>>> = Rc::default();
    let refresh = {
        let (current, preview, family, last_png, pending) = (current.clone(), preview.clone(), family.clone(), last_png.clone(), pending.clone());
        Rc::new(move || {
            if let Some(id) = pending.take() {
                id.remove();
            }
            let (current, preview, family, last_png, pending2) = (current.clone(), preview.clone(), family.clone(), last_png.clone(), pending.clone());
            let id = glib::timeout_add_local_once(std::time::Duration::from_millis(250), move || {
                pending2.set(None);
                if let Ok(p) = crate::frise::render_png(&current(), &family) {
                    preview.set_filename(Some(&p));
                    if let Some(old) = last_png.replace(Some(p)) {
                        let _ = std::fs::remove_file(old);
                    }
                }
            });
            pending.set(Some(id));
        })
    };
    let add_row = {
        let (rows, list, refresh) = (rows.clone(), list.clone(), refresh.clone());
        Rc::new(move |date: &str, event: &str| {
            let d = gtk::Entry::builder().placeholder_text("Date").text(date).width_chars(14).max_width_chars(16).build();
            let e = gtk::Entry::builder().placeholder_text("Événement").text(event).hexpand(true).build();
            let del = gtk::Button::builder().icon_name("user-trash-symbolic").tooltip_text("Retirer cette ligne").valign(gtk::Align::Center).build();
            del.add_css_class("flat");
            let b = gtk::Box::new(gtk::Orientation::Horizontal, 8);
            b.set_margin_top(6);
            b.set_margin_bottom(6);
            b.set_margin_start(8);
            b.set_margin_end(4);
            b.append(&d);
            b.append(&e);
            b.append(&del);
            let row = gtk::ListBoxRow::builder().child(&b).activatable(false).build();
            list.append(&row);
            for entry in [&d, &e] {
                let r = refresh.clone();
                entry.connect_changed(move |_| r());
            }
            {
                let (rows, list, row, refresh) = (rows.clone(), list.clone(), row.clone(), refresh.clone());
                del.connect_clicked(move |_| {
                    list.remove(&row);
                    rows.borrow_mut().retain(|(r, _, _)| r != &row);
                    refresh();
                });
            }
            rows.borrow_mut().push((row, d, e));
        })
    };
    for (d, e) in &f0.events {
        add_row(d, e);
    }
    {
        let (add_row, refresh, rows) = (add_row.clone(), refresh.clone(), rows.clone());
        add.connect_clicked(move |_| {
            add_row("", "");
            if let Some((_, d, _)) = rows.borrow().last() {
                d.grab_focus();
            }
            refresh();
        });
    }
    {
        let r = refresh.clone();
        title.connect_changed(move |_| r());
    }
    refresh();

    let d = dialog.downgrade();
    ok.connect_clicked(move |_| {
        let f = current();
        if f.events.iter().all(|(d, e)| d.trim().is_empty() && e.trim().is_empty()) {
            return;
        }
        match crate::frise::render_png(&f, &family) {
            Ok(p) => apply(f, p),
            Err(e) => eprintln!("frise : {e}"),
        }
        if let Some(d) = d.upgrade() {
            d.close();
        }
    });
    {
        let last_png = last_png.clone();
        dialog.connect_closed(move |_| {
            if let Some(p) = last_png.take() {
                let _ = std::fs::remove_file(p);
            }
        });
    }
    dialog.present(Some(parent));
    title.grab_focus();
}
