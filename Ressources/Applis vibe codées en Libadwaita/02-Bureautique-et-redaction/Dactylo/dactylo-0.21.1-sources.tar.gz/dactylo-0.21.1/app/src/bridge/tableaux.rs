// SPDX-License-Identifier: GPL-3.0-or-later
// Les tableaux dans le texte de travail : lignes « | a | b | » ↔ cases, styles des cases.

use super::*;

/// Fold rendered pipe grids back into table-cell paragraphs.
///
/// A separate pass rather than part of the character walk above: a table
/// is only recognizable once a whole line is known (a row line means
/// nothing until the *next* line proves to be a delimiter), and the walk
/// deliberately knows nothing beyond the character in hand.
///
/// Without this, `render_to_buffer` → `capture_from_buffer` turned every
/// table into literal "| a | b |" prose — which is how a table inserted
/// into the editor used to reach DOCX as text and vanish as a table.
/// `first_id` is the id the first table found gets (tables are numbered in
/// document order; the live model folds a span that starts after others).
pub(crate) fn capture_tables(paragraphs: &mut Vec<Paragraph>, starts: &mut Vec<usize>, first_id: u32) {
    use letters_core::table_text;

    let mut out: Vec<Paragraph> = Vec::with_capacity(paragraphs.len());
    let mut out_starts: Vec<usize> = Vec::with_capacity(starts.len());
    let mut table_id = first_id.saturating_sub(1);
    let mut i = 0;
    while i < paragraphs.len() {
        let header_cells = table_text::parse_row(&paragraphs[i].text());
        let delimiter_ok = paragraphs
            .get(i + 1)
            .is_some_and(|p| table_text::is_delimiter_line(&p.text()));
        let Some(header_cells) = header_cells.filter(|_| delimiter_ok) else {
            out.push(std::mem::take(&mut paragraphs[i]));
            out_starts.push(starts[i]);
            i += 1;
            continue;
        };
        // A table's column count is its header's. A body row with a
        // different count is not part of this table — stopping there keeps
        // the grid rectangular, which every reader of (row, col) assumes.
        let cols = header_cells.len();
        table_id += 1;
        let mut row = 0u32;
        let push_row = |out: &mut Vec<Paragraph>, out_starts: &mut Vec<usize>, para: &Paragraph, start: usize, ranges: &[std::ops::Range<usize>], row: u32| {
            for (col, range) in ranges.iter().enumerate() {
                out_starts.push(start + range.start);
                out.push(Paragraph {
                    style: letters_core::ParaStyle {
                        table_cell: Some(letters_core::TableCell { table: table_id, row, col: col as u32, ..Default::default() }),
                        ..Default::default()
                    },
                    // Samizdat : « ↵ » dans une case est un saut de ligne.
                    runs: table_text::slice_runs(&para.runs, range)
                        .into_iter()
                        .map(|mut r| {
                            if r.text.contains(CELL_BREAK) {
                                r.text = r.text.replace(CELL_BREAK, "\u{2028}");
                            }
                            r
                        })
                        .collect(),
                });
            }
        };
        push_row(&mut out, &mut out_starts, &paragraphs[i], starts[i], &header_cells, row);
        i += 2; // header + delimiter
        while i < paragraphs.len() {
            let Some(ranges) = table_text::parse_row(&paragraphs[i].text()) else { break };
            if ranges.len() != cols || table_text::is_delimiter_line(&paragraphs[i].text()) {
                break;
            }
            // A row followed by a delimiter row is the next table's header:
            // two tables with nothing between them stay two (#1299). Read
            // as this table's body, the header joined it and its delimiter
            // came back as the user's own prose.
            if paragraphs.get(i + 1).is_some_and(|p| table_text::is_delimiter_line(&p.text())) {
                break;
            }
            row += 1;
            push_row(&mut out, &mut out_starts, &paragraphs[i], starts[i], &ranges, row);
            i += 1;
        }
    }
    *paragraphs = out;
    *starts = out_starts;
}

/// Flatten a document's paragraphs into the lines the editor shows.
///
/// Everything is one line per paragraph, except a table: its cells are
/// paragraphs in the model but a *grid* on screen, so each row's cells
/// collapse into one pipe line and a delimiter line follows the header.
/// `capture_tables` reverses exactly this.
pub(crate) fn render_lines(paragraphs: &[Paragraph]) -> Vec<std::borrow::Cow<'_, Paragraph>> {
    use letters_core::table_text;
    use std::borrow::Cow;

    let mut lines: Vec<Cow<Paragraph>> = Vec::with_capacity(paragraphs.len());
    let mut i = 0;
    while i < paragraphs.len() {
        let Some(cell) = paragraphs[i].style.table_cell else {
            lines.push(Cow::Borrowed(&paragraphs[i]));
            i += 1;
            continue;
        };
        let table = cell.table;
        let end = paragraphs[i..]
            .iter()
            .position(|p| p.style.table_cell.is_none_or(|c| c.table != table))
            .map_or(paragraphs.len(), |n| i + n);
        let cells = &paragraphs[i..end];
        let cols = cells.iter().filter_map(|p| p.style.table_cell).map(|c| c.col).max().unwrap_or(0) + 1;

        // Cells arrive in row-major order (the model keeps them that way);
        // chunking by the column count is what turns them back into rows.
        for (row, chunk) in cells.chunks(cols as usize).enumerate() {
            // Samizdat : un saut de ligne dans une case s'affiche « ↵ » :
            // la ligne du tableau reste une ligne (un cartouche, lui, passe
            // vraiment à la ligne).
            // (une zone de texte sans cadre ni fond est aussi un tableau
            // d'une seule case : même traitement)
            let boxed = cells.len() == 1 || chunk.iter().any(|p| p.style.cartouche.is_some());
            let row_cells: Vec<Vec<letters_core::Run>> = chunk
                .iter()
                .map(|p| {
                    p.runs
                        .iter()
                        .cloned()
                        .map(|mut r| {
                            if !boxed && r.text.contains('\u{2028}') {
                                r.text = r.text.replace('\u{2028}', CELL_BREAK);
                            }
                            r
                        })
                        .collect()
                })
                .collect();
            lines.push(Cow::Owned(Paragraph {
                style: letters_core::ParaStyle::default(),
                runs: table_text::layout_row_runs(&row_cells),
            }));
            if row == 0 {
                lines.push(Cow::Owned(Paragraph {
                    style: letters_core::ParaStyle::default(),
                    runs: vec![letters_core::Run::plain(table_text::delimiter_line(cols as usize))],
                }));
            }
        }
        i = end;
    }
    lines
}

/// Samizdat : le style d'une case de tableau, par (tableau dans l'ordre du
/// texte, ligne, colonne). La grille « | … | » de l'éditeur n'en dit rien :
/// sans lui, une relecture rendait chaque case à son style par défaut
/// (l'allure d'un cartouche, l'alignement…).
/// Samizdat : un saut de ligne dans une case de tableau, tel que le texte
/// de travail le montre (un caractère, comme U+2028 dans le document).
pub const CELL_BREAK: &str = "\u{21B5}";

pub(crate) type CellStyles = Vec<((usize, u32, u32), letters_core::ParaStyle)>;

pub(super) const CELL_STYLES_KEY: &str = "samizdat-cell-styles";

/// Les styles des cases de `paras` (la première de chaque case).
pub(crate) fn cell_styles_of(paras: &[Paragraph]) -> CellStyles {
    let mut out: CellStyles = Vec::new();
    let (mut ordinal, mut prev, mut first): (usize, Option<u32>, bool) = (0, None, true);
    for p in paras {
        let Some(c) = p.style.table_cell else {
            prev = None;
            continue;
        };
        if prev != Some(c.table) {
            if !first {
                ordinal += 1;
            }
            first = false;
        }
        prev = Some(c.table);
        let key = (ordinal, c.row, c.col);
        if out.iter().any(|(k, _)| *k == key) {
            continue;
        }
        let mut st = p.style.clone();
        // Samizdat : la mise en forme de la case (largeur, fusion, fond…),
        // que la grille de l'éditeur ignore aussi.
        let props = c.props();
        st.table_cell = (props != letters_core::TableCell::default()).then_some(props);
        if st != letters_core::ParaStyle::default() {
            out.push((key, st));
        }
    }
    out
}

/// Rendre aux cases de `paras` les styles `styles`.
pub(crate) fn apply_cell_styles(styles: &CellStyles, paras: &mut [Paragraph]) {
    if styles.is_empty() {
        return;
    }
    let (mut ordinal, mut prev): (usize, Option<u32>) = (0, None);
    let mut first = true;
    for p in paras.iter_mut() {
        let Some(c) = p.style.table_cell else {
            prev = None;
            continue;
        };
        if prev != Some(c.table) {
            if !first {
                ordinal += 1;
            }
            first = false;
        }
        prev = Some(c.table);
        if p.style != (letters_core::ParaStyle { table_cell: Some(c), ..Default::default() }) {
            continue;
        }
        if let Some((_, st)) = styles.iter().find(|(k, _)| *k == (ordinal, c.row, c.col)) {
            let cell = st.table_cell.map_or(c, |props| props.placed(c));
            p.style = letters_core::ParaStyle { table_cell: Some(cell), ..st.clone() };
        }
    }
}

pub(crate) fn set_cell_styles(buf: &gtk::TextBuffer, paras: &[Paragraph]) {
    // SAFETY: stored and read back as the same type, under this key only.
    unsafe { buf.set_data(CELL_STYLES_KEY, cell_styles_of(paras)) };
}

pub(crate) fn cell_styles(buf: &gtk::TextBuffer) -> CellStyles {
    // SAFETY: only ever set by set_cell_styles, with this type.
    unsafe { buf.data::<CellStyles>(CELL_STYLES_KEY).map(|p| p.as_ref().clone()).unwrap_or_default() }
}
