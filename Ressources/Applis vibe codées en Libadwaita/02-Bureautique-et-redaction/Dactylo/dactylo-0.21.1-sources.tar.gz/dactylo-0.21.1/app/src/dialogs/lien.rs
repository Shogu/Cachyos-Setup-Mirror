// SPDX-License-Identifier: GPL-3.0-or-later
// Fenêtre : Lien.

use super::*;

pub fn link(parent: &impl IsA<gtk::Widget>, buf: &gtk::TextBuffer) {
    let selected = buf.selection_bounds().map(|(a, b)| buf.text(&a, &b, false).to_string());
    let (dialog, page, apply) = shell("Insérer un lien", "Insérer", 420);
    let g = adw::PreferencesGroup::new();
    let text = adw::EntryRow::builder().title("Texte affiché").text(selected.clone().unwrap_or_default()).build();
    let url = adw::EntryRow::builder().title("Adresse").text("https://").build();
    if selected.is_some() {
        text.set_sensitive(false);
    }
    g.add(&text);
    g.add(&url);
    page.add(&g);
    let (d, buf) = (dialog.downgrade(), buf.clone());
    let go = Rc::new(move || {
        commands::insert_link(&buf, &text.text(), &url.text());
        if let Some(d) = d.upgrade() {
            d.close();
        }
    });
    let g2 = go.clone();
    apply.connect_clicked(move |_| g2());
    dialog.present(Some(parent));
}
