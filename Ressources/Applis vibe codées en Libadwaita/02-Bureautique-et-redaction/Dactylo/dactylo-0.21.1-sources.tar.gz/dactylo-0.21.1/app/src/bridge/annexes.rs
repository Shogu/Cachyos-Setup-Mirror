// SPDX-License-Identifier: GPL-3.0-or-later
// Les annexes du document gardées sur le tampon : en-tête, pied, page, notes, commentaires, objets gardés.

use super::*;

/// GtkTextTag marking a paragraph that starts on a new page. Registered
/// by `register_formatting_tags`, which also gives it the space and rule
/// that make the break visible in the editor.
pub const PAGE_BREAK_TAG: &str = "page-break";

/// Buffer data key holding the document's footnote texts.
pub const FOOTNOTES_KEY: &str = "letters-footnotes";
/// Buffer data key holding the document's header text, if it has one.
pub const HEADER_KEY: &str = "letters-header";
/// Buffer data key holding the document's footer text, if it has one.
pub const FOOTER_KEY: &str = "letters-footer";
/// Buffer data key holding the document's page geometry, if it has one.
pub const PAGE_KEY: &str = "letters-page";
/// Buffer data key holding the document's heading styles.
pub const HEADING_STYLES_KEY: &str = "letters-heading-styles";
/// Buffer data key holding the document's base (body) font.
pub const BASE_FONT_KEY: &str = "letters-base-font";
/// The document's comments (`letters_core::comments`).
pub const COMMENTS_KEY: &str = "letters-comments";
/// Samizdat : les objets gardés tels quels (équations, graphiques…).
pub const KEPT_KEY: &str = "dactylo-kept";

// GObject data is an untyped pointer: reading a key back at a type other than
// the one it was written with is undefined behaviour, not a panic, and no test
// will catch it. So each key gets one reader and the type appears exactly
// once per key — rather than a generic helper any future caller could
// instantiate at the wrong type.
//
// The outer `Option` distinguishes "key never set" (a buffer that was never
// rendered from a Document) from a document that genuinely has no header;
// both flatten to `None`, but only the former is worth keeping separate for
// anyone extending this.

/// Copy the document state that lives beside the buffer's text (footnotes,
/// header, footer, page geometry, base font) from `buf` into `doc`.
pub(crate) fn read_sidecars(buf: &gtk::TextBuffer, doc: &mut Document) {
    doc.footnotes = unsafe { buf.data::<Vec<String>>(FOOTNOTES_KEY).map(|p| p.as_ref().clone()).unwrap_or_default() };
    doc.header = header_sidecar(buf);
    doc.footer = footer_sidecar(buf);
    doc.page = page_sidecar(buf);
    doc.base_font = base_font_sidecar(buf);
    doc.heading_styles = heading_styles_sidecar(buf);
    doc.comments = comments_sidecar(buf);
    doc.kept = unsafe { buf.data::<Vec<letters_core::model::Keepsake>>(KEPT_KEY).map(|p| p.as_ref().clone()).unwrap_or_default() };
}

pub(super) fn comments_sidecar(buf: &gtk::TextBuffer) -> Vec<letters_core::Comment> {
    unsafe { buf.data::<Vec<letters_core::Comment>>(COMMENTS_KEY).map(|p| p.as_ref().clone()).unwrap_or_default() }
}

/// Keep `comments` beside `buf`'s text (the live model's comment ops change
/// them without a buffer edit), and tint only open threads' text.
pub fn set_comments(buf: &gtk::TextBuffer, comments: &[letters_core::Comment]) {
    unsafe { buf.set_data(COMMENTS_KEY, comments.to_vec()) };
    for c in comments.iter().filter(|c| c.parent.is_none()) {
        if let Some(tag) = buf.tag_table().lookup(&format!("{COMMENT_TAG_PREFIX}{}", c.id)) {
            tint_comment(&tag, !c.resolved);
        }
    }
}

pub(super) fn header_sidecar(buf: &gtk::TextBuffer) -> Option<String> {
    unsafe { buf.data::<Option<String>>(HEADER_KEY).and_then(|p| p.as_ref().clone()) }
}

pub(super) fn footer_sidecar(buf: &gtk::TextBuffer) -> Option<String> {
    unsafe { buf.data::<Option<String>>(FOOTER_KEY).and_then(|p| p.as_ref().clone()) }
}

pub(super) fn heading_styles_sidecar(buf: &gtk::TextBuffer) -> Vec<RunStyle> {
    unsafe { buf.data::<Vec<RunStyle>>(HEADING_STYLES_KEY).map(|p| p.as_ref().clone()).unwrap_or_default() }
}

/// Set the body font of the document in `buf`, beside its text.
pub fn set_base_font(buf: &gtk::TextBuffer, base: letters_core::model::BaseFont) {
    unsafe { buf.set_data(BASE_FONT_KEY, base) };
}

pub(super) fn base_font_sidecar(buf: &gtk::TextBuffer) -> letters_core::model::BaseFont {
    unsafe { buf.data::<letters_core::model::BaseFont>(BASE_FONT_KEY).map(|p| p.as_ref().clone()).unwrap_or_default() }
}

pub(crate) fn page_sidecar(buf: &gtk::TextBuffer) -> Option<PageGeometry> {
    unsafe { buf.data::<Option<PageGeometry>>(PAGE_KEY).and_then(|p| *p.as_ref()) }
}

/// Read the page geometry currently attached to `buf`, if it has one.
pub fn buffer_page_geometry(buf: &gtk::TextBuffer) -> Option<PageGeometry> {
    page_sidecar(buf)
}

/// Read the header/footer currently attached to `buf`.
pub fn buffer_header_footer(buf: &gtk::TextBuffer) -> (Option<String>, Option<String>) {
    (header_sidecar(buf), footer_sidecar(buf))
}

/// Update just the header/footer, leaving the rest of the buffer's document
/// state alone.
///
/// Empty text means "no header", not an empty one: the ODT and DOCX writers
/// both emit a header block for `Some("")`, so treating a cleared entry as
/// `Some("")` would put an empty header into every saved file.
pub fn set_buffer_header_footer(buf: &gtk::TextBuffer, header: &str, footer: &str) {
    let present = |text: &str| (!text.is_empty()).then(|| text.to_string());
    unsafe {
        buf.set_data(HEADER_KEY, present(header));
        buf.set_data(FOOTER_KEY, present(footer));
    }
}

/// Keep `doc`'s header, footer, footnotes and page setup beside `buf`'s
/// text (the live model's ops change them without a buffer edit).
pub fn set_page_furniture(buf: &gtk::TextBuffer, doc: &Document) {
    unsafe {
        buf.set_data(HEADER_KEY, doc.header.clone());
        buf.set_data(FOOTER_KEY, doc.footer.clone());
        buf.set_data(FOOTNOTES_KEY, doc.footnotes.clone());
        buf.set_data(PAGE_KEY, doc.page);
    }
}

/// Attach the document state that the text buffer cannot represent.
///
/// Called by `render_to_buffer`, and by anything else that replaces a
/// buffer's document wholesale, so a later `capture_from_buffer` can put the
/// Document back together.
pub fn set_buffer_sidecars(doc: &Document, buf: &gtk::TextBuffer) {
    unsafe {
        buf.set_data(FOOTNOTES_KEY, doc.footnotes.clone());
        buf.set_data(HEADER_KEY, doc.header.clone());
        buf.set_data(FOOTER_KEY, doc.footer.clone());
        buf.set_data(PAGE_KEY, doc.page);
        buf.set_data(BASE_FONT_KEY, doc.base_font.clone());
        buf.set_data(KEPT_KEY, doc.kept.clone());
        buf.set_data(HEADING_STYLES_KEY, doc.heading_styles.clone());
    }
    set_comments(buf, &doc.comments);
    apply_heading_looks(buf, doc);
}

/// Les titres de l'éditeur prennent l'apparence que le document leur donne
/// (couleur, taille, police), comme dans le PDF, Word et LibreOffice.
pub(super) fn apply_heading_looks(buf: &gtk::TextBuffer, doc: &Document) {
    let base_pt = doc.base_font.size_hp.map_or(12.0, |hp| f64::from(hp) / 2.0);
    let defaults = [1.6, 1.4, 1.2, 1.1, 1.0, 0.9];
    for (i, default_scale) in defaults.iter().enumerate() {
        let Some(tag) = buf.tag_table().lookup(&format!("h{}", i + 1)) else { continue };
        let look = doc.heading_styles.get(i);
        tag.set_scale(look.and_then(|h| h.font_size_hp).map_or(*default_scale, |hp| f64::from(hp) / 2.0 / base_pt));
        tag.set_foreground(look.and_then(|h| h.color.as_deref()).map(|c| format!("#{c}")).as_deref());
        tag.set_family(look.and_then(|h| h.font_family.as_deref()));
    }
}
