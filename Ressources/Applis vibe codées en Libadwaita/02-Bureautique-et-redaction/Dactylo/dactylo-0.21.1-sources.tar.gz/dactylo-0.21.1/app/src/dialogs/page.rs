// SPDX-License-Identifier: GPL-3.0-or-later
// Fenêtre : Mise en page.

use super::*;

pub(super) const PAPERS: [(&str, f64, f64); 5] = [
    ("A4 (21 × 29,7 cm)", 595.28, 841.89),
    ("A5 (14,8 × 21 cm)", 419.53, 595.28),
    ("A3 (29,7 × 42 cm)", 841.89, 1190.55),
    ("Lettre US (8,5 × 11 po)", 612.0, 792.0),
    ("Légal US (8,5 × 14 po)", 612.0, 1008.0),
];

/// Numérotation des pages : libellé, modèle du pied de page (« {page} » et
/// « {total} » deviennent des champs dans le DOCX et l'ODT).
pub(super) const PAGE_NUMBERS: [(&str, &str); 4] = [("Aucun", ""), ("1, 2, 3…", "{page}"), ("Page 1 sur 3", "Page {page} sur {total}"), ("1 sur 3", "{page} sur {total}")];
/// Où chercher un numéro de page : le plus long motif d'abord.
pub(super) const PAGE_NUMBER_ORDER: [usize; 3] = [2, 3, 1];
pub(super) const PAGE_NUMBER_SEP: &str = " — ";
pub(super) const ZONE_NAMES: [&str; 3] = ["à gauche", "au centre", "à droite"];

/// Un en-tête ou un pied de page en lignes de trois zones (gauche, centre,
/// droite) : « gauche\tcentre\tdroite », une ligne par « \n ». Une ligne
/// sans zones est à gauche, ou au centre si elle numérote les pages.
pub(super) fn split_zones(text: &str) -> Vec<[String; 3]> {
    text.split('\n')
        .map(|l| {
            if l.contains('\t') {
                let mut it = l.splitn(3, '\t');
                [it.next().unwrap_or("").to_string(), it.next().unwrap_or("").to_string(), it.next().unwrap_or("").to_string()]
            } else if l.contains("{page}") {
                [String::new(), l.to_string(), String::new()]
            } else {
                [l.to_string(), String::new(), String::new()]
            }
        })
        .collect()
}

/// L'inverse de `split_zones` ; None si tout est vide.
pub(super) fn join_zones(lines: &[[String; 3]]) -> Option<String> {
    let mut out: Vec<String> = lines
        .iter()
        .map(|[l, c, r]| {
            let (l, c, r) = (l.trim(), c.trim(), r.trim());
            if c.is_empty() && r.is_empty() {
                l.to_string()
            } else if l.is_empty() && r.is_empty() && c.contains("{page}") {
                c.to_string()
            } else if r.is_empty() {
                format!("{l}\t{c}")
            } else {
                format!("{l}\t{c}\t{r}")
            }
        })
        .collect();
    while out.last().is_some_and(|l| l.is_empty()) {
        out.pop();
    }
    (!out.is_empty()).then(|| out.join("\n"))
}

/// Retire le numéro de page des zones : (numérotation, zone où il était).
pub(super) fn take_page_number(lines: &mut [[String; 3]]) -> (usize, usize) {
    for &i in &PAGE_NUMBER_ORDER {
        let pattern = PAGE_NUMBERS[i].1;
        for line in lines.iter_mut() {
            for (z, zone) in line.iter_mut().enumerate() {
                if zone.contains(pattern) {
                    let rest = zone.replacen(pattern, "", 1);
                    *zone = rest.trim().trim_end_matches(PAGE_NUMBER_SEP.trim()).trim_start_matches(PAGE_NUMBER_SEP.trim()).trim().to_string();
                    return (i, z);
                }
            }
        }
    }
    (0, 1)
}

/// Les lignes de zones d'un en-tête ou d'un pied de page : deux lignes de
/// trois champs (la seconde repliée si elle est vide).
pub(super) fn zones_editor(title: &str, lines: &[[String; 3]]) -> (adw::PreferencesGroup, Vec<[gtk::Entry; 3]>) {
    let group = adw::PreferencesGroup::builder().title(title).build();
    let mut entries = Vec::new();
    for row in 0..2 {
        let b = gtk::Box::new(gtk::Orientation::Horizontal, 6);
        let es: [gtk::Entry; 3] = std::array::from_fn(|z| {
            let e = gtk::Entry::builder()
                .placeholder_text(format!("{}{}", if row == 0 { "" } else { "2ᵉ ligne " }, ZONE_NAMES[z]))
                .text(lines.get(row).map_or("", |l| l[z].as_str()))
                .hexpand(true)
                .build();
            EditableExt::set_alignment(&e, [0.0, 0.5, 1.0][z]);
            b.append(&e);
            e
        });
        if row == 0 {
            group.add(&b);
        } else {
            let exp = gtk::Expander::builder().label("Deuxième ligne").expanded(lines.get(1).is_some_and(|l| l.iter().any(|z| !z.is_empty()))).child(&b).build();
            exp.set_margin_top(6);
            group.add(&exp);
        }
        entries.push(es);
    }
    (group, entries)
}

/// Marges étroites de Word (0,5 po).
pub(super) const NARROW_CM: f64 = 1.27;
pub(super) const DEFAULT_MARGIN_CM: f64 = 2.0;

pub fn page_setup(parent: &impl IsA<gtk::Widget>, buf: &gtk::TextBuffer) {
    let doc = commands::document(buf);
    let g = doc.page.clone().unwrap_or(PageGeometry {
        width_pt: 595.28,
        height_pt: 841.89,
        margin_top_pt: DEFAULT_MARGIN_CM * PT_PER_CM,
        margin_bottom_pt: DEFAULT_MARGIN_CM * PT_PER_CM,
        margin_left_pt: DEFAULT_MARGIN_CM * PT_PER_CM,
        margin_right_pt: DEFAULT_MARGIN_CM * PT_PER_CM,
        ..Default::default()
    });
    let landscape = g.width_pt > g.height_pt;
    let (pw, ph) = if landscape { (g.height_pt, g.width_pt) } else { (g.width_pt, g.height_pt) };
    let paper_idx = PAPERS.iter().position(|(_, w, h)| (w - pw).abs() < 3.0 && (h - ph).abs() < 3.0).unwrap_or(0);

    let (dialog, page, apply) = shell("Mise en page", "Appliquer", 540);
    let paper_group = adw::PreferencesGroup::builder().title("Papier").build();
    let names: Vec<&str> = PAPERS.iter().map(|p| p.0).collect();
    let paper = adw::ComboRow::builder().title("Format").model(&gtk::StringList::new(&names)).selected(paper_idx as u32).build();
    let orient = adw::ComboRow::builder().title("Orientation").model(&gtk::StringList::new(&["Portrait", "Paysage"])).selected(landscape as u32).build();
    paper_group.add(&paper);
    paper_group.add(&orient);
    page.add(&paper_group);

    let m_group = adw::PreferencesGroup::builder().title("Marges").description("En centimètres").build();
    let top = spin("Haut", 0.0, 10.0, 0.05, 2, g.margin_top_pt / PT_PER_CM, None);
    let bottom = spin("Bas", 0.0, 10.0, 0.05, 2, g.margin_bottom_pt / PT_PER_CM, None);
    let left = spin("Gauche", 0.0, 10.0, 0.05, 2, g.margin_left_pt / PT_PER_CM, None);
    let right = spin("Droite", 0.0, 10.0, 0.05, 2, g.margin_right_pt / PT_PER_CM, None);
    // Marges étroites (1,27 cm, comme Word) : un interrupteur qui fige les
    // quatre marges ; le désactiver rend les valeurs d'avant.
    let narrow_now = [&top, &bottom, &left, &right].iter().all(|r| (r.value() - NARROW_CM).abs() < 0.05);
    let narrow = adw::SwitchRow::builder().title("Marges étroites").subtitle("1,27 cm de chaque côté").active(narrow_now).build();
    m_group.add(&narrow);
    for r in [&top, &bottom, &left, &right] {
        r.set_sensitive(!narrow_now);
        m_group.add(r);
    }
    {
        let rows = [top.clone(), bottom.clone(), left.clone(), right.clone()];
        let before = Rc::new(std::cell::RefCell::new(if narrow_now { [DEFAULT_MARGIN_CM; 4] } else { rows.each_ref().map(|r| r.value()) }));
        narrow.connect_active_notify(move |s| {
            let on = s.is_active();
            if on {
                *before.borrow_mut() = rows.each_ref().map(|r| r.value());
            }
            let values = if on { [NARROW_CM; 4] } else { *before.borrow() };
            for (r, v) in rows.iter().zip(values) {
                r.set_value(v);
                r.set_sensitive(!on);
            }
        });
    }
    page.add(&m_group);

    let (header_group, header_entries) = zones_editor("En-tête", &split_zones(doc.header.as_deref().unwrap_or_default()));
    header_group.set_description(Some("Trois zones : à gauche, au centre, à droite"));
    let mut footer_lines = split_zones(doc.footer.as_deref().unwrap_or_default());
    let (numbering, zone) = take_page_number(&mut footer_lines);
    let (footer_group, footer_entries) = zones_editor("Pied de page", &footer_lines);
    let numbers = adw::ComboRow::builder()
        .title("Numéros de page")
        .model(&gtk::StringList::new(&PAGE_NUMBERS.iter().map(|(l, _)| *l).collect::<Vec<_>>()))
        .selected(numbering as u32)
        .build();
    let place = adw::ComboRow::builder()
        .title("Place du numéro")
        .subtitle("Sur la première ligne du pied de page")
        .model(&gtk::StringList::new(&["À gauche", "Au centre", "À droite"]))
        .selected(zone as u32)
        .build();
    let num_group = adw::PreferencesGroup::new();
    num_group.add(&numbers);
    num_group.add(&place);
    page.add(&header_group);
    page.add(&footer_group);
    page.add(&num_group);

    let (d, buf) = (dialog.downgrade(), buf.clone());
    apply.connect_clicked(move |_| {
        let (_, w, h) = PAPERS[paper.selected().min(PAPERS.len() as u32 - 1) as usize];
        let (w, h) = if orient.selected() == 1 { (h, w) } else { (w, h) };
        let geometry = PageGeometry {
            width_pt: w,
            height_pt: h,
            margin_top_pt: top.value() * PT_PER_CM,
            margin_bottom_pt: bottom.value() * PT_PER_CM,
            margin_left_pt: left.value() * PT_PER_CM,
            margin_right_pt: right.value() * PT_PER_CM,
            ..g.clone()
        };
        let read = |entries: &Vec<[gtk::Entry; 3]>| -> Vec<[String; 3]> { entries.iter().map(|es| std::array::from_fn(|z| es[z].text().to_string())).collect() };
        let header = join_zones(&read(&header_entries));
        let mut footer = read(&footer_entries);
        let pattern = PAGE_NUMBERS.get(numbers.selected() as usize).map_or("", |p| p.1);
        if !pattern.is_empty() {
            let zone = &mut footer[0][(place.selected() as usize).min(2)];
            *zone = if zone.trim().is_empty() { pattern.to_string() } else { format!("{}{PAGE_NUMBER_SEP}{pattern}", zone.trim()) };
        }
        commands::set_page(&buf, geometry, header, join_zones(&footer));
        if let Some(d) = d.upgrade() {
            d.close();
        }
    });
    dialog.present(Some(parent));
}
