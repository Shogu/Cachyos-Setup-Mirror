// SPDX-License-Identifier: GPL-3.0-or-later
// Fenêtre : Éditeur de tableau.

use super::*;

/// Une vraie grille à remplir. Sans tableau sous le curseur : un nouveau
/// tableau (`rows` × `cols`). OK réécrit le tableau dans le document.
pub fn table_editor(parent: &impl IsA<gtk::Widget>, buf: &gtk::TextBuffer, textbox: bool) {
    let existing = if textbox { None } else { commands::table_at_caret(buf) };
    let initial: Vec<Vec<String>> = match &existing {
        // (un saut de ligne dans une case : une ligne de la zone de saisie)
        Some(t) => t.cells.iter().map(|row| row.iter().map(|c| c.as_ref().map(|p| p.text().replace('\u{2028}', "\n")).unwrap_or_default()).collect()).collect(),
        None if textbox => vec![vec![String::new()]],
        None => vec![vec![String::new(); 3]; 3],
    };
    // Hauteur de chaque ligne, en cm (0 = selon le texte).
    let initial_h: Vec<f64> = match &existing {
        Some(t) => t
            .cells
            .iter()
            .map(|row| row.iter().flatten().filter_map(|p| p.style.table_cell).map(|c| c.height_tw).max().unwrap_or(0))
            .map(|tw| (f64::from(tw) / 20.0 / 72.0 * 2.54 * 10.0).round() / 10.0)
            .collect(),
        None => Vec::new(),
    };
    let title = if textbox { "Zone de texte" } else if existing.is_some() { "Modifier le tableau" } else { "Insérer un tableau" };
    let (dialog, _page, apply) = shell(title, if existing.is_some() { "Appliquer" } else { "Insérer" }, 640);
    if !textbox {
        dialog.set_content_height(480);
    }
    // Le contenu du shell est remplacé : une grille dans une zone défilante.
    let grid = gtk::Grid::builder().row_spacing(4).column_spacing(4).margin_top(12).margin_bottom(12).margin_start(12).margin_end(12).build();
    let cells: Rc<std::cell::RefCell<Vec<Vec<gtk::TextView>>>> = Rc::default();
    let spins: Rc<std::cell::RefCell<Vec<gtk::SpinButton>>> = Rc::default();
    let textview = gtk::TextView::builder().wrap_mode(gtk::WrapMode::WordChar).top_margin(8).bottom_margin(8).left_margin(8).right_margin(8).build();

    let rebuild = {
        let (grid, cells, spins) = (grid.clone(), cells.clone(), spins.clone());
        move |texts: Vec<Vec<String>>, heights: Vec<f64>| {
            while let Some(c) = grid.first_child() {
                grid.remove(&c);
            }
            let cols = texts.iter().map(Vec::len).max().unwrap_or(1) as i32;
            let head = gtk::Label::builder().label("Hauteur (cm)").tooltip_text("Hauteur de la ligne : 0 = selon le texte. Pour laisser de la place pour écrire.").build();
            head.add_css_class("dim-label");
            head.add_css_class("caption");
            grid.attach(&head, cols, -1, 1, 1);
            let mut hs = Vec::new();
            let mut rows = Vec::new();
            for (r, row) in texts.iter().enumerate() {
                let sp = gtk::SpinButton::with_range(0.0, 20.0, 0.5);
                sp.set_digits(1);
                sp.set_value(heights.get(r).copied().unwrap_or(0.0));
                sp.set_tooltip_text(Some("Hauteur de la ligne (0 = selon le texte)"));
                sp.set_valign(gtk::Align::Center);
                grid.attach(&sp, cols, r as i32, 1, 1);
                hs.push(sp);
                let mut entries = Vec::new();
                for (c, text) in row.iter().enumerate() {
                    // Une case de plusieurs lignes : Entrée passe à la ligne
                    // dans la case, Tab va à la suivante.
                    let e = gtk::TextView::builder()
                        .wrap_mode(gtk::WrapMode::WordChar)
                        .accepts_tab(false)
                        .hexpand(true)
                        .top_margin(6)
                        .bottom_margin(6)
                        .left_margin(6)
                        .right_margin(6)
                        .build();
                    e.buffer().set_text(text);
                    e.set_size_request(80, -1);
                    if r == 0 {
                        e.add_css_class("heading");
                    }
                    let frame = gtk::Frame::new(None);
                    frame.set_child(Some(&e));
                    frame.set_valign(gtk::Align::Fill);
                    grid.attach(&frame, c as i32, r as i32, 1, 1);
                    entries.push(e);
                }
                rows.push(entries);
            }
            *cells.borrow_mut() = rows;
            *spins.borrow_mut() = hs;
        }
    };
    let rebuild = Rc::new(rebuild);
    let current = {
        let cells = cells.clone();
        move || -> Vec<Vec<String>> {
            cells
                .borrow()
                .iter()
                .map(|row| {
                    row.iter()
                        .map(|e| {
                            let b = e.buffer();
                            b.text(&b.start_iter(), &b.end_iter(), false).trim_end_matches('\n').to_string()
                        })
                        .collect()
                })
                .collect()
        }
    };
    let current = Rc::new(current);
    let current_h = {
        let spins = spins.clone();
        move || -> Vec<f64> { spins.borrow().iter().map(gtk::SpinButton::value).collect() }
    };
    let current_h = Rc::new(current_h);

    let content: gtk::Widget = if textbox {
        textview.buffer().set_text(&initial[0][0]);
        let frame = gtk::Frame::new(None);
        frame.set_child(Some(&textview));
        frame.set_margin_top(12);
        frame.set_margin_bottom(12);
        frame.set_margin_start(12);
        frame.set_margin_end(12);
        textview.set_size_request(-1, 160);
        let hint = gtk::Label::builder().label("Le texte est placé dans un encadré, à l'endroit du curseur.").wrap(true).xalign(0.0).margin_start(12).margin_end(12).build();
        hint.add_css_class("dim-label");
        let b = gtk::Box::new(gtk::Orientation::Vertical, 0);
        b.append(&frame);
        b.append(&hint);
        b.upcast()
    } else {
        rebuild(initial.clone(), initial_h.clone());
        let add_row = gtk::Button::builder().icon_name("list-add-symbolic").tooltip_text("Ajouter une ligne").build();
        let del_row = gtk::Button::builder().icon_name("list-remove-symbolic").tooltip_text("Retirer la dernière ligne").build();
        let add_col = gtk::Button::builder().icon_name("list-add-symbolic").tooltip_text("Ajouter une colonne").build();
        let del_col = gtk::Button::builder().icon_name("list-remove-symbolic").tooltip_text("Retirer la dernière colonne").build();
        let bar = gtk::Box::new(gtk::Orientation::Horizontal, 12);
        bar.set_halign(gtk::Align::Center);
        bar.set_margin_top(6);
        let group = |label: &str, a: &gtk::Button, b: &gtk::Button| {
            let g = gtk::Box::new(gtk::Orientation::Horizontal, 0);
            g.add_css_class("linked");
            g.append(b);
            g.append(a);
            let l = gtk::Label::new(Some(label));
            let h = gtk::Box::new(gtk::Orientation::Horizontal, 6);
            h.append(&l);
            h.append(&g);
            h
        };
        bar.append(&group("Lignes", &add_row, &del_row));
        bar.append(&group("Colonnes", &add_col, &del_col));
        let (rb, cur, curh, cells_for_focus) = (rebuild.clone(), current.clone(), current_h.clone(), cells.clone());
        add_row.connect_clicked(move |_| {
            let mut t = cur();
            let cols = t.first().map(Vec::len).unwrap_or(1);
            t.push(vec![String::new(); cols]);
            rb(t, curh());
            if let Some(e) = cells_for_focus.borrow().last().and_then(|r| r.first()) {
                e.grab_focus();
            }
        });
        let (rb, cur, curh) = (rebuild.clone(), current.clone(), current_h.clone());
        del_row.connect_clicked(move |_| {
            let mut t = cur();
            if t.len() > 1 {
                t.pop();
                rb(t, curh());
            }
        });
        let (rb, cur, curh) = (rebuild.clone(), current.clone(), current_h.clone());
        add_col.connect_clicked(move |_| {
            let mut t = cur();
            for row in &mut t {
                row.push(String::new());
            }
            rb(t, curh());
        });
        let (rb, cur, curh) = (rebuild.clone(), current.clone(), current_h.clone());
        del_col.connect_clicked(move |_| {
            let mut t = cur();
            if t.first().is_some_and(|r| r.len() > 1) {
                for row in &mut t {
                    row.pop();
                }
                rb(t, curh());
            }
        });
        let scroller = gtk::ScrolledWindow::builder().child(&grid).vexpand(true).min_content_height(320).hscrollbar_policy(gtk::PolicyType::Automatic).build();
        let b = gtk::Box::new(gtk::Orientation::Vertical, 0);
        b.append(&bar);
        b.append(&scroller);
        b.upcast()
    };
    if let Some(tv) = dialog.child().and_downcast::<adw::ToolbarView>() {
        tv.set_content(Some(&content));
    }

    let (d, buf) = (dialog.downgrade(), buf.clone());
    apply.connect_clicked(move |_| {
        let texts = if textbox {
            let tb = textview.buffer();
            let t = tb.text(&tb.start_iter(), &tb.end_iter(), false).replace('\n', " ");
            vec![vec![t.trim().to_string()]]
        } else {
            current()
        };
        // Une ligne de la zone de saisie : un saut de ligne dans la case.
        let texts: Vec<Vec<String>> = texts.into_iter().map(|row| row.into_iter().map(|t| t.replace('\n', "\u{2028}")).collect()).collect();
        let heights: Vec<u32> = current_h().iter().map(|cm| (cm / 2.54 * 72.0 * 20.0).round() as u32).collect();
        commands::write_table(&buf, &texts, existing.as_ref(), (!textbox).then_some(heights.as_slice()));
        if let Some(d) = d.upgrade() {
            d.close();
        }
    });
    dialog.present(Some(parent));
    let first = cells.borrow().first().and_then(|r| r.first()).cloned();
    if let Some(first) = first {
        first.grab_focus();
    }
}
