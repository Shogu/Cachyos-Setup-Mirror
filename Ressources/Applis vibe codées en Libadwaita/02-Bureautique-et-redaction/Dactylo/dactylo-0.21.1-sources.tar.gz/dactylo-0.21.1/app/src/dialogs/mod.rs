// dialogs.rs — dialogues Adwaita : mise en page, tableau, image, lien.
// SPDX-License-Identifier: GPL-3.0-or-later

use std::rc::Rc;

use gtk4::{self as gtk, glib, prelude::*};
use libadwaita::{self as adw, prelude::*};
use letters_core::PageGeometry;

use crate::commands;

const PT_PER_CM: f64 = 72.0 / 2.54;

/// Un dialogue « Annuler / Appliquer » avec une page de préférences.
fn shell(title: &str, apply_label: &str, width: i32) -> (adw::Dialog, adw::PreferencesPage, gtk::Button) {
    let page = adw::PreferencesPage::new();
    let header = adw::HeaderBar::builder().show_end_title_buttons(false).show_start_title_buttons(false).build();
    let cancel = gtk::Button::with_label("Annuler");
    let apply = gtk::Button::with_label(apply_label);
    apply.add_css_class("suggested-action");
    header.pack_start(&cancel);
    header.pack_end(&apply);
    let tv = adw::ToolbarView::new();
    tv.add_top_bar(&header);
    tv.set_content(Some(&page));
    let dialog = adw::Dialog::builder().title(title).content_width(width).child(&tv).build();
    if title == "Image" || title == "Mise en page" {
        dialog.set_content_height(720);
    }
    let d = dialog.downgrade();
    cancel.connect_clicked(move |_| {
        if let Some(d) = d.upgrade() {
            d.close();
        }
    });
    (dialog, page, apply)
}

fn spin(title: &str, min: f64, max: f64, step: f64, digits: u32, value: f64, suffix: Option<&str>) -> adw::SpinRow {
    let r = adw::SpinRow::with_range(min, max, step);
    r.set_title(title);
    r.set_digits(digits);
    r.set_value(value);
    if let Some(s) = suffix {
        r.set_subtitle(s);
    }
    r
}

// Une fenêtre par fichier ; ici, ce qu'elles partagent.
mod frise;
mod image;
mod lien;
mod page;
mod police;
mod schema;
mod tableau;

pub use frise::frise;
pub use image::image;
pub use lien::link;
pub use page::page_setup;
pub use police::choose_font_family;
pub use tableau::table_editor;
#[allow(unused_imports)]
use frise::*;
#[allow(unused_imports)]
use image::*;
#[allow(unused_imports)]
use lien::*;
#[allow(unused_imports)]
use page::*;
#[allow(unused_imports)]
use police::*;
#[allow(unused_imports)]
use schema::*;
#[allow(unused_imports)]
use tableau::*;
