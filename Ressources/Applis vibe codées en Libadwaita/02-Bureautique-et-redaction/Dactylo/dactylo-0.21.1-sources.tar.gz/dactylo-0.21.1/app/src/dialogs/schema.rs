// SPDX-License-Identifier: GPL-3.0-or-later
// Fenêtre : Schéma : le texte de ses cases.

use super::*;

/// Samizdat : modifier le texte des cases d'un schéma gardé (docx_diagram).
/// Le schéma d'origine est réécrit (il revient tel quel, avec ses nouveaux
/// textes, à l'enregistrement en .docx) et son image redessinée.
pub(super) fn diagram(parent: &impl IsA<gtk::Widget>, buf: &gtk::TextBuffer, seq: usize, run: letters_core::Run, toast: impl Fn(&str) + 'static) {
    let doc = commands::document(buf);
    let Some(index) = doc.kept.iter().position(|k| k.label == run.text) else { return };
    let texts = letters_core::docx_diagram::box_texts(&doc.kept[index].xml);
    if texts.is_empty() {
        toast("Ce schéma n'a pas de texte à modifier");
        return;
    }
    let (dialog, page, apply) = shell("Schéma", "Appliquer", 520);
    dialog.set_content_height(640);
    let group = adw::PreferencesGroup::builder()
        .title("Texte des cases")
        .description("Une ligne par paragraphe. Les formes, leur place et la mise en forme des cases sont gardées.")
        .build();
    let mut views = Vec::new();
    for (i, t) in texts.iter().enumerate() {
        let first: String = t.lines().find(|l| !l.trim().is_empty()).unwrap_or("").chars().take(40).collect();
        let title = gtk::Label::builder().label(format!("Case {} — {}", i + 1, if first.is_empty() { "(vide)".to_string() } else { first })).xalign(0.0).build();
        title.add_css_class("caption-heading");
        title.set_margin_top(6);
        let view = gtk::TextView::builder().wrap_mode(gtk::WrapMode::WordChar).top_margin(6).bottom_margin(6).left_margin(8).right_margin(8).accepts_tab(false).build();
        view.buffer().set_text(t);
        let frame = gtk::Frame::new(None);
        frame.set_child(Some(&view));
        let bx = gtk::Box::new(gtk::Orientation::Vertical, 4);
        bx.append(&title);
        bx.append(&frame);
        group.add(&bx);
        views.push(view);
    }
    page.add(&group);
    let (d, buf) = (dialog.downgrade(), buf.clone());
    apply.connect_clicked(move |_| {
        let new: Vec<String> = views
            .iter()
            .map(|v| {
                let b = v.buffer();
                b.text(&b.start_iter(), &b.end_iter(), false).trim_end_matches('\n').to_string()
            })
            .collect();
        let mut kept = commands::document(&buf).kept;
        let Some(k) = kept.get_mut(index) else { return };
        k.xml = letters_core::docx_diagram::set_box_texts(&k.xml, &new);
        if let Some((png, w, h)) = letters_core::docx_diagram::render_kept(k) {
            if let Ok(path) = suite_common_core::media_cache::persist(&png) {
                let mut new_run = run.clone();
                new_run.style.image = Some(path.to_string_lossy().into_owned());
                new_run.style.image_extent_emu = Some(((w * 12700.0) as u64, (h * 12700.0) as u64));
                // (le schéma modifié, gardé avant l'image : l'écriture le lit)
                unsafe { buf.set_data(crate::bridge::KEPT_KEY, kept) };
                commands::replace_image(&buf, seq, new_run);
            }
        }
        if let Some(d) = d.upgrade() {
            d.close();
        }
    });
    dialog.present(Some(parent));
}
