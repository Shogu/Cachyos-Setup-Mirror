#!/usr/bin/env python3
"""Contrôle de non-régression de Dactylo sur un corpus de documents.

Pour chaque .docx et .odt du corpus : mise en page (PDF), enregistrement
en .docx et en .odt puis relecture (bench). On compare au relevé de
référence (reference.tsv, à côté de ce script) :
  - le nombre de pages (et celui de LibreOffice, pour mémoire) ;
  - le texte mis en page, page par page (empreinte de pdftotext -layout) ;
  - l'aller-retour .docx / .odt.

Usage :
  controle.py CORPUS            compare, liste ce qui a changé
  controle.py CORPUS --maj      enregistre l'état actuel comme référence

CORPUS contient docs/ (les documents) et libreoffice/ (leurs PDF faits
par LibreOffice, facultatifs). Le banc d'essai est compilé au besoin.
"""
import hashlib
import os
import subprocess
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor

ICI = os.path.dirname(os.path.abspath(__file__))
RACINE = os.path.dirname(os.path.dirname(ICI))
REFERENCE = os.path.join(ICI, "reference.tsv")
BENCH = os.path.join(RACINE, "target", "release", "examples", "bench")


def pages(pdf):
    try:
        out = subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout
    except FileNotFoundError:
        return "?"
    for line in out.splitlines():
        if line.startswith("Pages:"):
            return line.split()[1]
    return "?"


def empreinte(pdf):
    out = subprocess.run(["pdftotext", "-layout", pdf, "-"], capture_output=True).stdout
    return hashlib.sha1(out).hexdigest()[:12]


def mesure(doc, corpus, sortie):
    nom = os.path.splitext(os.path.basename(doc))[0]
    r = subprocess.run([BENCH, doc, sortie], capture_output=True, text=True, timeout=300)
    log = r.stdout
    pdf = os.path.join(sortie, nom + ".pdf")
    if "LECTURE ÉCHOUÉE" in log or not os.path.exists(pdf):
        return [os.path.basename(doc), "-", "ÉCHEC", "-", "-", "-"]
    aller = lambda ext: "ok" if f"{ext} : aller-retour identique" in log else "diff"
    lo = pages(os.path.join(corpus, "libreoffice", nom + ".pdf"))
    return [os.path.basename(doc), lo, pages(pdf), empreinte(pdf), aller("docx"), aller("odt")]


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    corpus, maj = sys.argv[1], "--maj" in sys.argv
    subprocess.run(["cargo", "build", "-q", "--release", "-p", "letters-core", "--features", "render", "--example", "bench"],
                   cwd=RACINE, check=True)
    docs = sorted(os.path.join(corpus, "docs", f) for f in os.listdir(os.path.join(corpus, "docs")) if f.endswith((".docx", ".odt")))
    with tempfile.TemporaryDirectory() as sortie, ThreadPoolExecutor(max_workers=os.cpu_count()) as pool:
        lignes = list(pool.map(lambda d: mesure(d, corpus, sortie), docs))
    if maj:
        with open(REFERENCE, "w") as f:
            f.write("# document\tLibreOffice\tpages\ttexte\tdocx\todt\n")
            for l in lignes:
                f.write("\t".join(l) + "\n")
        print(f"Référence enregistrée : {len(lignes)} documents.")
        return
    ref = {}
    with open(REFERENCE) as f:
        for line in f:
            if not line.startswith("#"):
                l = line.rstrip("\n").split("\t")
                ref[l[0]] = l
    changes, mieux, pire = 0, 0, 0
    for l in lignes:
        r = ref.get(l[0])
        if r is None:
            print(f"NOUVEAU  {l[0]} : {l[2]} pages (LibreOffice {l[1]})")
            continue
        if r[1:] == l[1:]:
            continue
        changes += 1
        quoi = []
        if r[2] != l[2]:
            ecart = lambda p: abs(int(p) - int(l[1])) if p.isdigit() and l[1].isdigit() else 0
            sens = "mieux" if ecart(l[2]) < ecart(r[2]) else "PIRE" if ecart(l[2]) > ecart(r[2]) else "autant"
            mieux += sens == "mieux"
            pire += sens == "PIRE"
            quoi.append(f"pages {r[2]} → {l[2]} (LibreOffice {l[1]}, {sens})")
        elif r[3] != l[3]:
            quoi.append("mise en page changée, même nombre de pages")
        for i, ext in ((4, "docx"), (5, "odt")):
            if r[i] != l[i]:
                quoi.append(f"aller-retour {ext} : {r[i]} → {l[i]}")
        print(f"{l[0]} : " + " ; ".join(quoi))
    egaux = sum(1 for l in lignes if l[1] == l[2])
    print(f"\n{len(lignes)} documents, {changes} changés ({mieux} mieux, {pire} pire). "
          f"Même nombre de pages que LibreOffice : {egaux}.")
    sys.exit(1 if pire else 0)


if __name__ == "__main__":
    main()
