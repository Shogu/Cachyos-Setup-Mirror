#!/bin/sh
# Banc d'essai de Dactylo : ./tools/banc/lancer.sh <dossier de documents>
# Lit chaque document, l'enregistre en .docx et .odt, relit, compare ;
# contrôle les règles de Word ; écrit les Aperçus en PDF dans banc/out.
set -e
src="$1"; here=$(cd "$(dirname "$0")" && pwd); work="$here/work"
mkdir -p "$work/out"; rm -rf "$work/src"; cp -r "$src" "$work/src"
cargo build -q --release -p letters-core --features render --example bench
cd "$work/src"
for f in *; do echo "=== $f"; ../../../../target/release/examples/bench "$f" "$work/out" 2>&1 | grep -v "^libEGL\|Gtk-WARNING"; done > "$work/report.txt"
cd "$work"; python3 "$here/cover.py"; python3 "$here/wordcheck.py"; python3 "$here/pertes.py" | sed -n "/=== Caract/,$ p"
grep -B2 "DIFFÉRENCES\|ÉCHOU" report.txt || true
