import docx, io, copy
from docx.shared import Cm, Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_COLOR_INDEX
from docx.enum.table import WD_ROW_HEIGHT_RULE, WD_TABLE_ALIGNMENT
from docx.enum.section import WD_ORIENT, WD_SECTION
from docx.oxml import parse_xml, OxmlElement
from docx.oxml.ns import qn, nsdecls
from PIL import Image, ImageDraw

def img(name, w, h, color, text, fmt='PNG'):
    im = Image.new('RGB', (w, h), color); d = ImageDraw.Draw(im)
    d.rectangle([4, 4, w-5, h-5], outline='black', width=4); d.text((14, h//2-6), text, fill='black')
    im.save(name, fmt); return name
img('carte.png', 600, 400, '#9fd3a8', 'PNG 600x400')
img('photo.jpg', 500, 300, '#f2c38b', 'JPEG 500x300', 'JPEG')
img('mini1.png', 200, 150, '#a8c6f0', 'image 1/2')
img('mini2.png', 200, 150, '#f0a8c6', 'image 2/2')
img('logo.png', 160, 60, '#ffffff', 'LOGO lycée')
img('gros.png', 2400, 1600, '#d0d0ff', 'tres grande image')

d = docx.Document()
sec = d.sections[0]; sec.page_width, sec.page_height = Cm(21), Cm(29.7)
sec.left_margin = sec.right_margin = Cm(2); sec.top_margin = sec.bottom_margin = Cm(2)
# En-tête avec image + pied de page avec numéro de page
hp = sec.header.paragraphs[0]; hp.add_run().add_picture('logo.png', width=Cm(3)); hp.add_run('\tEn-tête : Lycée des Volcans\t2025-2026')
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER; fp.add_run('Page ')
r = fp.add_run()
for t, v in (('begin', None), (None, 'PAGE'), ('end', None)):
    if t: e = OxmlElement('w:fldChar'); e.set(qn('w:fldCharType'), t); r._r.append(e)
    else: e = OxmlElement('w:instrText'); e.set(qn('xml:space'), 'preserve'); e.text = v; r._r.append(e)

d.add_heading('Document de test « chelou » pour Dactylo', 0)
d.add_heading('1. Mise en forme des caractères', 1)
p = d.add_paragraph()
for txt, kw in [('gras ', {'bold': True}), ('italique ', {'italic': True}), ('souligné ', {'underline': True}), ('barré ', {'strike': True}),
                ('rouge ', {'color': RGBColor(0xC0, 0, 0)}), ('Courier 14 ', {'font': 'Courier New', 'size': 14}), ('petites majuscules ', {'small_caps': True})]:
    run = p.add_run(txt)
    for k, v in kw.items():
        if k == 'color': run.font.color.rgb = v
        elif k == 'font': run.font.name = v
        elif k == 'size': run.font.size = Pt(v)
        else: setattr(run.font, k, v)
r = p.add_run('surligné jaune '); r.font.highlight_color = WD_COLOR_INDEX.YELLOW
r = p.add_run('H'); r2 = p.add_run('2'); r2.font.subscript = True; p.add_run('O et x'); r3 = p.add_run('2'); r3.font.superscript = True
# pièges de surlignage : none et white
p2 = d.add_paragraph('Piège : ce texte a un surlignage « none », ')
p2._p.append(parse_xml(f'<w:r {nsdecls("w")}><w:rPr><w:highlight w:val="none"/></w:rPr><w:t xml:space="preserve">celui-ci « white », </w:t></w:r>'.replace('none', 'white')))
p2._p.append(parse_xml(f'<w:r {nsdecls("w")}><w:rPr><w:shd w:val="clear" w:color="auto" w:fill="C6EFCE"/></w:rPr><w:t>et celui-ci un fond vert par trame.</w:t></w:r>'))

d.add_heading('2. Paragraphes', 1)
for al, name in ((WD_ALIGN_PARAGRAPH.LEFT, 'à gauche'), (WD_ALIGN_PARAGRAPH.CENTER, 'centré'), (WD_ALIGN_PARAGRAPH.RIGHT, 'à droite'), (WD_ALIGN_PARAGRAPH.JUSTIFY, 'justifié')):
    q = d.add_paragraph(f'Paragraphe {name}. ' + 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. ' * 3); q.alignment = al
q = d.add_paragraph('Retrait de première ligne 1,5 cm, retrait gauche 2 cm, interligne double, 12 pt avant et après. ' * 2)
pf = q.paragraph_format; pf.first_line_indent = Cm(1.5); pf.left_indent = Cm(2); pf.line_spacing = 2; pf.space_before = Pt(12); pf.space_after = Pt(12)
q = d.add_paragraph('Paragraphe encadré avec une trame grise (bordure de paragraphe).')
q._p.get_or_add_pPr().append(parse_xml(f'<w:pBdr {nsdecls("w")}><w:top w:val="single" w:sz="8" w:space="4" w:color="000000"/><w:left w:val="single" w:sz="8" w:space="4" w:color="000000"/><w:bottom w:val="single" w:sz="8" w:space="4" w:color="000000"/><w:right w:val="single" w:sz="8" w:space="4" w:color="000000"/></w:pBdr>'))
q._p.get_or_add_pPr().append(parse_xml(f'<w:shd {nsdecls("w")} w:val="clear" w:color="auto" w:fill="E7E6E6"/>'))
q = d.add_paragraph('Nom :\tPrénom :\tClasse :')
q._p.get_or_add_pPr().append(parse_xml(f'<w:tabs {nsdecls("w")}><w:tab w:val="left" w:leader="dot" w:pos="4500"/><w:tab w:val="left" w:leader="dot" w:pos="9600"/></w:tabs>'))
q = d.add_paragraph('Ligne 1 du paragraphe'); q.add_run().add_break(); q.add_run('ligne 2 après un saut de ligne manuel')

d.add_heading('3. Listes', 1)
for t, lvl in (('Puce niveau 1', 0), ('Puce niveau 2', 1), ('Puce niveau 3', 2), ('Retour au niveau 1', 0)):
    d.add_paragraph(t, style='List Bullet' if lvl == 0 else f'List Bullet {lvl+1}')
for t in ('Premier', 'Deuxième', 'Troisième'):
    d.add_paragraph(t, style='List Number')
d.add_paragraph('Sous-point (liste numérotée niveau 2)', style='List Number 2')
d.add_paragraph('Paragraphe normal pour couper la liste.')
d.add_paragraph('Nouvelle liste numérotée : repart-elle à 1 ?', style='List Number')

d.add_heading('4. Images', 1)
d.add_paragraph('PNG en ligne, 10 cm :'); d.add_picture('carte.png', width=Cm(10))
d.add_paragraph('JPEG centré :'); d.add_picture('photo.jpg', width=Cm(8)); d.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
q = d.add_paragraph('Deux images dans le même paragraphe : ')
r = q.add_run(); r.add_picture('mini1.png', width=Cm(4)); r.add_picture('mini2.png', width=Cm(4))
d.add_paragraph('Image beaucoup trop grande (doit être réduite à la page) :'); d.add_picture('gros.png', width=Cm(25))
# image flottante ancrée (habillage carré) : on transforme un inline en anchor
d.add_paragraph('Image flottante ci-dessous, ancrée au paragraphe suivant, avec du texte autour.')
q = d.add_paragraph(); r = q.add_run(); r.add_picture('mini1.png', width=Cm(4))
inline = r._r.find('.//' + qn('wp:inline'))
anchor = parse_xml(f'''<wp:anchor {nsdecls("wp","a","pic","r")} distT="0" distB="0" distL="114300" distR="114300" simplePos="0" relativeHeight="5" behindDoc="0" locked="0" layoutInCell="1" allowOverlap="1">
<wp:simplePos x="0" y="0"/><wp:positionH relativeFrom="column"><wp:posOffset>3600000</wp:posOffset></wp:positionH><wp:positionV relativeFrom="paragraph"><wp:posOffset>0</wp:posOffset></wp:positionV>
<wp:extent cx="1440000" cy="1080000"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:wrapSquare wrapText="bothSides"/><wp:docPr id="77" name="flottante"/><wp:cNvGraphicFramePr/></wp:anchor>''')
anchor.append(copy.deepcopy(inline.find(qn('a:graphic')))); inline.getparent().replace(inline, anchor)
q.add_run('Ce texte devrait entourer l\'image flottante dans Word. ' * 6)
# image recadrée (srcRect)
d.add_paragraph('Image recadrée dans Word (moitié gauche seulement) :')
d.add_picture('carte.png', width=Cm(5))
blip = d.paragraphs[-1]._p.find('.//' + qn('pic:blipFill'))
blip.insert(1, parse_xml(f'<a:srcRect {nsdecls("a")} r="50000"/>'))

d.add_heading('5. Tableaux', 1)
d.add_paragraph('Tableau avec fusions, largeurs, fond, hauteur de ligne :')
t = d.add_table(rows=4, cols=3); t.style = 'Table Grid'
for i, w in enumerate((Cm(3), Cm(9), Cm(5))):
    for c in t.columns[i].cells: c.width = w
t.cell(0, 0).merge(t.cell(0, 1)).text = 'Fusion horizontale (2 colonnes)'
t.cell(0, 2).text = 'En-tête'
t.cell(1, 2).merge(t.cell(3, 2)).text = 'Fusion verticale sur 3 lignes'
for i, txt in enumerate(('A', 'B', 'C')):
    t.cell(i+1, 0).text = txt; t.cell(i+1, 1).text = f'Texte de la ligne {txt}'
t.cell(1, 1).text = 'Une phrase volontairement longue dans une case pour voir si elle passe bien à la ligne dans l\'éditeur, l\'aperçu et le PDF.'
sh = parse_xml(f'<w:shd {nsdecls("w")} w:val="clear" w:color="auto" w:fill="FFD966"/>'); t.cell(1, 0)._tc.get_or_add_tcPr().append(sh)
t.rows[3].height = Cm(2.5); t.rows[3].height_rule = WD_ROW_HEIGHT_RULE.AT_LEAST
d.add_paragraph('Tableau sans bordure, à remplir (cases vides avec lignes vides) :')
t2 = d.add_table(rows=2, cols=2)
t2.cell(0, 0).text = 'Nom'; t2.cell(0, 1).text = 'Prénom'
t2.cell(1, 0).paragraphs[0].text = ''; t2.cell(1, 0).add_paragraph(''); t2.cell(1, 0).add_paragraph('')
d.add_paragraph('Deux tableaux collés l\'un à l\'autre :')
for k in range(2):
    tt = d.add_table(rows=1, cols=2); tt.style = 'Table Grid'; tt.cell(0, 0).text = f'Tableau collé {k+1}'; tt.cell(0, 1).text = '…'
d.add_paragraph('Tableau imbriqué (un tableau dans une case) :')
t3 = d.add_table(rows=1, cols=2); t3.style = 'Table Grid'; t3.cell(0, 0).text = 'Case extérieure'
inner = t3.cell(0, 1).add_table(rows=2, cols=2)
for a in range(2):
    for b in range(2): inner.cell(a, b).text = f'int {a}{b}'
d.add_paragraph('Tableau très large (8 colonnes) :')
t4 = d.add_table(rows=3, cols=8); t4.style = 'Table Grid'
for a in range(3):
    for b in range(8): t4.cell(a, b).text = f'Colonne {b+1}' if a == 0 else f'valeur {a}.{b}'
d.add_paragraph('Une case avec du gras, une puce et une image :')
t5 = d.add_table(rows=1, cols=2); t5.style = 'Table Grid'
c = t5.cell(0, 0); c.paragraphs[0].add_run('Gras dans la case').bold = True; c.add_paragraph('• puce à la main')
t5.cell(0, 1).paragraphs[0].add_run().add_picture('mini2.png', width=Cm(3))

d.add_heading('6. Objets', 1)
q = d.add_paragraph('Une équation en ligne : ')
q._p.append(parse_xml(f'<m:oMath {nsdecls("m")} xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><m:f><m:num><m:r><m:t>a+b</m:t></m:r></m:num><m:den><m:r><m:t>2</m:t></m:r></m:den></m:f><m:r><m:t>=</m:t></m:r><m:sSup><m:e><m:r><m:t>x</m:t></m:r></m:e><m:sup><m:r><m:t>2</m:t></m:r></m:sup></m:sSup></m:oMath>'))
q.add_run(' (elle doit survivre à l\'enregistrement).')
d.add_paragraph('Lien hypertexte : ')
part = d.part; rid = part.relate_to('https://www.education.gouv.fr', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink', is_external=True)
d.paragraphs[-1]._p.append(parse_xml(f'<w:hyperlink {nsdecls("w","r")} r:id="{rid}"><w:r><w:rPr><w:color w:val="0563C1"/><w:u w:val="single"/></w:rPr><w:t>education.gouv.fr</w:t></w:r></w:hyperlink>'))
# zone de texte + formes (wps) avec repli VML
W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office"'
def shape(kind, x, y, w, h, fill, did, text=None):
    geom = 'ellipse' if kind == 3 else 'rect'
    tx = f'<wps:txbx><w:txbxContent><w:p><w:r><w:t>{text}</w:t></w:r></w:p></w:txbxContent></wps:txbx>' if text else ''
    vtx = f'<v:textbox><w:txbxContent><w:p><w:r><w:t>{text}</w:t></w:r></w:p></w:txbxContent></v:textbox>' if text else ''
    E = 12700
    return parse_xml(f'''<w:r {W}><mc:AlternateContent><mc:Choice Requires="wps"><w:drawing><wp:anchor distT="0" distB="0" distL="0" distR="0" simplePos="0" relativeHeight="{did}" behindDoc="0" locked="0" layoutInCell="1" allowOverlap="1"><wp:simplePos x="0" y="0"/><wp:positionH relativeFrom="column"><wp:posOffset>{int(x*E)}</wp:posOffset></wp:positionH><wp:positionV relativeFrom="paragraph"><wp:posOffset>{int(y*E)}</wp:posOffset></wp:positionV><wp:extent cx="{int(w*E)}" cy="{int(h*E)}"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:wrapNone/><wp:docPr id="{did}" name="forme{did}"/><wp:cNvGraphicFramePr/><a:graphic><a:graphicData uri="http://schemas.microsoft.com/office/word/2010/wordprocessingShape"><wps:wsp><wps:cNvSpPr/><wps:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{int(w*E)}" cy="{int(h*E)}"/></a:xfrm><a:prstGeom prst="{geom}"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="{fill}"/></a:solidFill><a:ln w="12700"><a:solidFill><a:srgbClr val="2D4D6A"/></a:solidFill></a:ln></wps:spPr>{tx}<wps:bodyPr/></wps:wsp></a:graphicData></a:graphic></wp:anchor></w:drawing></mc:Choice><mc:Fallback><w:pict><v:shape o:spt="{kind}" style="position:absolute;z-index:{did};margin-left:{x}pt;margin-top:{y}pt;width:{w}pt;height:{h}pt" fillcolor="#{fill}" strokecolor="#2D4D6A" strokeweight="1pt">{vtx}</v:shape></w:pict></mc:Fallback></mc:AlternateContent></w:r>''')
q = d.add_paragraph('Croquis : un rectangle vert et une ellipse crème (formes Word) :')
q._p.append(shape(1, 0, 20, 300, 120, 'C4DFB4', 101)); q._p.append(shape(3, 60, 35, 180, 90, 'FEF0CC', 102))
for _ in range(7): d.add_paragraph('')
q = d.add_paragraph('Une zone de texte avec une consigne :')
q._p.append(shape(1, 0, 18, 420, 40, 'FFFFFF', 103, 'Consigne dans une zone de texte : lisez le document 2.'))
for _ in range(3): d.add_paragraph('')
# note de bas de page (fabriquée à la main)
pass
d.add_paragraph('Fin de la section portrait, la suite est en paysage sur deux colonnes.')

# section paysage + 2 colonnes
s2 = d.add_section(WD_SECTION.NEW_PAGE); s2.orientation = WD_ORIENT.LANDSCAPE; s2.page_width, s2.page_height = Cm(29.7), Cm(21)
s2._sectPr.append(parse_xml(f'<w:cols {nsdecls("w")} w:num="2" w:space="708"/>'))
d.add_heading('7. Section paysage en deux colonnes', 1)
for i in range(6): d.add_paragraph(f'Paragraphe {i+1} en colonnes. ' + 'Texte de remplissage pour remplir la colonne. ' * 6)
d.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
d.add_paragraph('Après un saut de page manuel. Dernière ligne du document : ✔ émojis 🌋 et caractères spéciaux « » — … € œ Æ ß.')
d.save('Test_chelou_Dactylo.docx')
print('ok')
