import zipfile,re,sys,os,html
rep=open('report.txt').read()
stats={}
for blk in rep.split('=== ')[1:]:
    name=blk.split('\n')[0]
    m=re.search(r'(\d+) paragraphes, (\d+) mots, (\d+) tableaux, (\d+) images',blk)
    if m: stats[name]=tuple(map(int,m.groups()))
def words(s): return len(html.unescape(s).split())
for f in sorted(os.listdir('src')):
    z=zipfile.ZipFile('src/'+f)
    if f.endswith('.docx'):
        x=z.read('word/document.xml').decode()
        x=re.sub(r'<mc:Fallback>.*?</mc:Fallback>','',x,flags=re.S)
        paras=re.findall(r'<w:p[ >].*?</w:p>',x,re.S)
        text=' '.join(''.join(re.findall(r'<w:t(?: [^>]*)?>([^<]*)',p)) for p in paras)
        imgs=len(set(re.findall(r'r:embed="([^"]+)"',x))) and len(re.findall(r'<a:blip ',x))
        tb=len(re.findall(r'<w:tbl>',x))
    else:
        x=z.read('content.xml').decode()
        body=x[x.find('<office:body'):]
        body=re.sub(r'<text:s(?: text:c="(\d+)")?/>',' ',body)
        body=re.sub(r'<text:(tab|line-break)/>',' ',body)
        paras=re.findall(r'<text:(?:p|h)[ >].*?</text:(?:p|h)>',body,re.S)
        text=' '.join(re.sub(r'<[^>]+>','',p) for p in paras)
        imgs=len(re.findall(r'<draw:image [^>]*xlink:href="[^"]*\.(?:png|jpe?g|gif|bmp|tiff?|webp)"',body,re.I)); tb=len(re.findall(r'<table:table ',body))
    w=words(text); s=stats.get(f)
    if not s: print('?? ',f); continue
    flag=[]
    if s[1] < w*0.97: flag.append(f'MOTS {s[1]}/{w}')
    if s[3] < imgs: flag.append(f'IMAGES {s[3]}/{imgs}')
    if s[2] < tb: flag.append(f'TABLEAUX {s[2]}/{tb}')
    print(('⚠ ' if flag else 'ok ')+f, ' '.join(flag))
