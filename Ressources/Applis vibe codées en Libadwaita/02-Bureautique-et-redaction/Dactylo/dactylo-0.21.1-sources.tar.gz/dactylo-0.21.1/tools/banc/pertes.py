"""Banc d'essai, étape « mise en forme ».

Compare, caractère par caractère et paragraphe par paragraphe, la mise en
forme *effective* (styles résolus) d'un document source (work/src) et de sa
copie réenregistrée par Dactylo dans le même format (work/out).
Usage : python3 ../pertes.py   (depuis tools/banc/work)
"""
import zipfile, re, os, collections, difflib, html

def part(z, n):
    try: return z.read(n).decode('utf8', 'replace')
    except KeyError: return ''

def val(x, tag, attr='w:val'):
    m = re.search(rf'<w:{tag}\b[^>]*>', x)
    if not m: return None
    v = re.search(rf'{attr}="([^"]*)"', m.group(0))
    return v.group(1) if v else ''

def onoff(x, tag):
    v = val(x, tag)
    if v is None: return None
    return v not in ('0', 'false', 'off', 'none')

# ---------------------------------------------------------------- docx
THEME = {}
def docx_rpr(x):
    r = {}
    for k in ('b', 'i', 'strike'):
        v = onoff(x, k)
        if v is not None: r[k] = v
    u = val(x, 'u');
    if u is not None: r['u'] = u not in ('none', '0')
    s = val(x, 'sz')
    if s: r['sz'] = s
    c = val(x, 'color')
    if c is not None and c.lower() != 'auto': r['color'] = c.upper()
    h = val(x, 'highlight') or (val(x, 'shd', 'w:fill') if '<w:shd' in x else None)
    if h and h.lower() not in ('auto', 'none', 'ffffff'): r['fond'] = h.lower()
    f = re.search(r'<w:rFonts[^>]*w:ascii="([^"]*)"', x) or re.search(r'<w:rFonts[^>]*w:asciiTheme="([^"]*)"', x)
    if f: r['police'] = THEME.get(f.group(1), f.group(1))
    va = val(x, 'vertAlign')
    if va: r['exposant'] = va
    caps = onoff(x, 'caps')
    if caps is not None: r['majuscules'] = caps
    return r

def docx_ppr(x):
    p = {}
    jc = val(x, 'jc')
    if jc: p['alignement'] = {'both': 'justify', 'start': 'left', 'end': 'right'}.get(jc, jc)
    sp = re.search(r'<w:spacing[^>]*>', x)
    if sp:
        for a, k in (('w:before', 'avant'), ('w:after', 'après'), ('w:line', 'interligne')):
            m = re.search(rf'{a}="(-?\d+)"', sp.group(0))
            if m: p[k] = int(m.group(1)) // 20 * 20
    ind = re.search(r'<w:ind[^>]*>', x)
    if ind:
        for a, k in (('w:left', 'retrait'), ('w:start', 'retrait'), ('w:firstLine', '1re ligne'), ('w:hanging', 'suspendu'), ('w:right', 'retrait droit')):
            m = re.search(rf'{a}="(-?\d+)"', ind.group(0))
            if m: p[k] = int(m.group(1)) // 20 * 20
    if re.search(r'<w:pBdr>\s*<w:(top|bottom|left|right|between)\b(?![^>]*w:val="(none|nil)")', x): p['bordure'] = True
    if re.search(r'<w:shd[^>]*w:fill="(?!auto|FFFFFF)', x, re.I): p['trame'] = True
    tabs = re.findall(r'<w:tab [^>]*w:pos="(\d+)"', x)
    if tabs: p['tabulations'] = len(tabs)
    if re.search(r'<w:tab [^>]*w:leader="(dot|hyphen|underscore)', x): p['points de suite'] = True
    for k, n in (('keepNext', 'avec suivant'), ('pageBreakBefore', 'saut avant')):
        v = onoff(x, k)
        if v is not None: p[n] = v
    if '<w:numPr' in x and val(x, 'numId') not in (None, '0'): p['liste'] = True
    return p

class DocxStyles:
    def __init__(self, xml):
        self.s = {}
        for m in re.finditer(r'<w:style [^>]*w:styleId="([^"]+)"[^>]*>(.*?)</w:style>', xml, re.S):
            body = m.group(2)
            based = re.search(r'<w:basedOn w:val="([^"]+)"', body)
            ppr = re.search(r'<w:pPr>(.*?)</w:pPr>', body, re.S)
            rpr = re.search(r'<w:rPr>(.*?)</w:rPr>', body, re.S)
            self.s[m.group(1)] = (based.group(1) if based else None, docx_ppr(ppr.group(1)) if ppr else {}, docx_rpr(rpr.group(1)) if rpr else {})
        self.default = re.search(r'<w:style [^>]*w:type="paragraph"[^>]*w:default="1"[^>]*w:styleId="([^"]+)"', xml) or re.search(r'<w:style [^>]*w:default="1"[^>]*w:type="paragraph"[^>]*w:styleId="([^"]+)"', xml)
        self.default = self.default.group(1) if self.default else 'Normal'
        dd = re.search(r'<w:docDefaults>(.*?)</w:docDefaults>', xml, re.S)
        dd = dd.group(1) if dd else ''
        r = re.search(r'<w:rPrDefault>(.*?)</w:rPrDefault>', dd, re.S); p = re.search(r'<w:pPrDefault>(.*?)</w:pPrDefault>', dd, re.S)
        self.drpr = docx_rpr(r.group(1)) if r else {}; self.dppr = docx_ppr(p.group(1)) if p else {}
    def chain(self, sid, idx):
        out = {}; seen = set()
        while sid and sid in self.s and sid not in seen:
            seen.add(sid); based, pp, rp = self.s[sid]
            out = {**(pp if idx == 1 else rp), **out}; sid = based
        return out

def docx_read(path):
    z = zipfile.ZipFile(path)
    th = part(z, 'word/theme/theme1.xml')
    THEME.clear()
    for k, tag in (('minorHAnsi', 'minorFont'), ('majorHAnsi', 'majorFont')):
        m = re.search(rf'<a:{tag}>\s*<a:latin typeface="([^"]*)"', th)
        if m: THEME[k] = m.group(1)
    st = DocxStyles(part(z, 'word/styles.xml'))
    d = part(z, 'word/document.xml')
    d = re.sub(r'<mc:Fallback>.*?</mc:Fallback>', '', d, flags=re.S)
    d = re.sub(r'<w:txbxContent>.*?</w:txbxContent>', '', d, flags=re.S)
    paras = []
    for p in re.findall(r'<w:p[ >].*?</w:p>|<w:p/>', d, re.S):
        ppr = re.search(r'<w:pPr>(.*?)</w:pPr>', p, re.S); ppr = ppr.group(1) if ppr else ''
        ppr_wo = re.sub(r'<w:rPr>.*?</w:rPr>', '', ppr, flags=re.S)
        ps = re.search(r'<w:pStyle w:val="([^"]+)"', ppr_wo); ps = ps.group(1) if ps else st.default
        pp = {**st.dppr, **st.chain(ps, 1), **docx_ppr(ppr_wo)}
        base_r = {**st.drpr, **st.chain(ps, 2)}
        chars = []
        for r in re.findall(r'<w:r[ >].*?</w:r>', p, re.S):
            rpr = re.search(r'<w:rPr>(.*?)</w:rPr>', r, re.S); rpr = rpr.group(1) if rpr else ''
            rs = re.search(r'<w:rStyle w:val="([^"]+)"', rpr)
            eff = {**base_r, **(st.chain(rs.group(1), 2) if rs else {}), **docx_rpr(rpr)}
            for t in re.findall(r'<w:t(?:\s[^>]*)?>([^<]*)</w:t>|<w:(tab)/>', r):
                s = html.unescape(t[0]) if t[0] else ('\t' if t[1] else '')
                chars += [(ch, eff) for ch in s]
        paras.append((''.join(c for c, _ in chars), pp, chars))
    return paras

# ----------------------------------------------------------------- odt
FACES = {}
def odt_props(attrs):
    a = dict(re.findall(r'([a-z-]+:[a-z-]+)="([^"]*)"', attrs)); r = {}; p = {}
    if 'fo:font-weight' in a: r['b'] = a['fo:font-weight'] in ('bold', '600', '700', '800', '900')
    if 'fo:font-style' in a: r['i'] = a['fo:font-style'] == 'italic'
    if 'style:text-underline-style' in a: r['u'] = a['style:text-underline-style'] != 'none'
    if 'style:text-line-through-style' in a: r['strike'] = a['style:text-line-through-style'] != 'none'
    if 'fo:font-size' in a and a['fo:font-size'].endswith('pt'): r['sz'] = str(round(float(a['fo:font-size'][:-2]) * 2))
    if 'fo:color' in a: r['color'] = a['fo:color'].lstrip('#').upper()
    if 'fo:background-color' in a and a['fo:background-color'] not in ('transparent', '#ffffff'): r['fond'] = a['fo:background-color'].lower()
    if 'style:font-name' in a: r['police'] = FACES.get(a['style:font-name'], a['style:font-name'])
    elif 'fo:font-family' in a: r['police'] = a['fo:font-family']
    if 'style:text-position' in a: r['exposant'] = 'super' if a['style:text-position'].startswith(('super', '3', '4', '5')) else ('sub' if a['style:text-position'].startswith(('sub', '-')) else None)
    if 'fo:text-align' in a: p['alignement'] = {'start': 'left', 'end': 'right'}.get(a['fo:text-align'], a['fo:text-align'])
    def pt(v):
        m = re.match(r'(-?[\d.]+)(cm|mm|in|pt)', v or '')
        if not m: return None
        n = float(m.group(1)) * {'cm': 567, 'mm': 56.7, 'in': 1440, 'pt': 20}[m.group(2)]
        return int(n) // 20 * 20
    for k, n in (('fo:margin-top', 'avant'), ('fo:margin-bottom', 'après'), ('fo:margin-left', 'retrait'), ('fo:text-indent', '1re ligne'), ('fo:margin-right', 'retrait droit')):
        if k in a and pt(a[k]) is not None: p[n] = pt(a[k])
    if 'fo:line-height' in a: p['interligne'] = a['fo:line-height']
    if any(k.startswith('fo:border') and a[k] != 'none' for k in a): p['bordure'] = True
    if a.get('fo:background-color') not in (None, 'transparent', '#ffffff') and 'fo:text-align' in a or ('fo:background-color' in a and 'fo:margin-top' in a): pass
    if 'fo:break-before' in a: p['saut avant'] = a['fo:break-before'] == 'page'
    if 'fo:keep-with-next' in a: p['avec suivant'] = a['fo:keep-with-next'] == 'always'
    return r, p

def odt_read(path):
    z = zipfile.ZipFile(path); styles = {}
    FACES.clear()
    for n in ('styles.xml', 'content.xml'):
        for m in re.finditer(r'<style:font-face style:name="([^"]+)"[^>]*svg:font-family="([^"]+)"', part(z, n)):
            FACES[m.group(1)] = html.unescape(m.group(2)).strip("'")
    for n in ('styles.xml', 'content.xml'):
        x = part(z, n)
        for m in re.finditer(r'<style:style ([^>]*?)(/>|>(.*?)</style:style>)', x, re.S):  # (paresseux : un style vide « /> » ne déborde pas)
            head, body = m.group(1), m.group(3) or ''
            name = re.search(r'style:name="([^"]+)"', head)
            if not name: continue
            parent = re.search(r'style:parent-style-name="([^"]+)"', head)
            r = {}; p = {}
            for attrs in re.findall(r'<style:(?:text|paragraph)-properties([^>]*)', body):
                rr, pp = odt_props(attrs); r.update(rr); p.update(pp)
            tabs = len(re.findall(r'<style:tab-stop ', body))
            if tabs: p['tabulations'] = tabs
            if re.search(r'style:leader-text="[.\-_]"|style:leader-style="(dotted|solid)"', body): p['points de suite'] = True
            styles[name.group(1)] = (parent.group(1) if parent else None, r, p)
    dflt = re.search(r'<style:default-style style:family="paragraph">(.*?)</style:default-style>', part(z, 'styles.xml'), re.S)
    dr, dp = {}, {}
    if dflt:
        for attrs in re.findall(r'<style:(?:text|paragraph)-properties([^>]*)', dflt.group(1)):
            rr, pp = odt_props(attrs); dr.update(rr); dp.update(pp)
    def chain(name, i):
        out = {}; seen = set()
        while name and name in styles and name not in seen:
            seen.add(name); par, r, p = styles[name]; out = {**(r if i == 1 else p), **out}; name = par
        return out
    x = part(z, 'content.xml'); body = x[x.find('<office:text'):]
    body = re.sub(r'<draw:(custom-shape|rect|ellipse)\b.*?</draw:\1>', '', body, flags=re.S)
    paras = []
    for m in re.finditer(r'<text:(p|h)((?:\s[^>]*?)?)(?:/>|>(.*?)</text:\1>)', body, re.S):
        head, inner = m.group(2) or '', m.group(3) or ''
        sn = re.search(r'text:style-name="([^"]+)"', head); sn = sn.group(1) if sn else None
        pp = {**dp, **chain(sn, 2)}; base = {**dr, **chain(sn, 1)}
        chars = []
        def walk(s, eff):
            for t in re.split(r'(<text:span[^>]*>.*?</text:span>|<text:s(?: text:c="\d+")?/>|<text:tab/>|<text:line-break/>|<[^>]+>)', s, flags=re.S):
                if not t: continue
                if t.startswith('<text:span'):
                    n2 = re.search(r'text:style-name="([^"]+)"', t); inner2 = re.sub(r'^<text:span[^>]*>|</text:span>$', '', t, flags=re.S)
                    walk(inner2, {**eff, **(chain(n2.group(1), 1) if n2 else {})})
                elif t.startswith('<text:s'):
                    c = re.search(r'text:c="(\d+)"', t); chars.extend([(' ', eff)] * (int(c.group(1)) if c else 1))
                elif t == '<text:tab/>': chars.append(('\t', eff))
                elif t.startswith('<'): pass
                else: chars.extend((ch, eff) for ch in html.unescape(t))
        walk(inner, base)
        paras.append((''.join(c for c, _ in chars), pp, chars))
    return paras

# ------------------------------------------------------------- compare
CHAR_KEYS = ('b', 'i', 'u', 'strike', 'sz', 'color', 'fond', 'police', 'exposant', 'majuscules')
PARA_KEYS = ('alignement', 'avant', 'après', 'interligne', 'retrait', '1re ligne', 'suspendu', 'retrait droit', 'bordure', 'trame', 'tabulations', 'points de suite', 'avec suivant', 'saut avant', 'liste')
NAMES = {'b': 'gras', 'i': 'italique', 'u': 'souligné', 'strike': 'barré', 'sz': 'taille', 'color': 'couleur', 'fond': 'surlignage/fond', 'police': 'police', 'exposant': 'exposant/indice', 'majuscules': 'petites/majuscules'}
DEFAULTS = {'b': False, 'i': False, 'u': False, 'strike': False, 'majuscules': False, 'bordure': False, 'trame': False, 'points de suite': False, 'avec suivant': False, 'saut avant': False, 'liste': False, 'avant': 0, 'après': 0, 'retrait': 0, '1re ligne': 0, 'suspendu': 0, 'retrait droit': 0, 'tabulations': 0, 'alignement': 'left'}

def norm(d, k):
    v = d.get(k, DEFAULTS.get(k))
    if k == 'interligne' and v in (None, '100%', 240): return None
    if k == 'color' and v in ('000000', None): return None
    if k == 'police' and v: return v.split(',')[0].strip("'").lower()
    if k == 'fond' and v: return {'yellow': 'ffff00', 'green': '00ff00', 'cyan': '00ffff', 'magenta': 'ff00ff', 'red': 'ff0000', 'blue': '0000ff', 'lightgray': 'c0c0c0', 'darkgray': '808080', 'darkyellow': '808000', '#ffff00': 'ffff00'}.get(v.lower(), v.lower().lstrip('#'))
    return v

def compare(a, b, char_loss, para_loss, ex, fname=''):
    sm = difflib.SequenceMatcher(None, [t for t, _, _ in a], [t for t, _, _ in b], autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag != 'equal': continue
        for (ta, pa, ca), (tb, pb, cb) in zip(a[i1:i2], b[j1:j2]):
            if not ta.strip(): continue
            for k in PARA_KEYS:
                if k in ('retrait', 'suspendu', '1re ligne') and (pa.get('liste') or pb.get('liste')):
                    continue
                if norm(pa, k) != norm(pb, k):
                    para_loss[k] += 1
                    ex.setdefault(k, f'[{fname[:30]}] « {ta[:40]} » : {norm(pa, k)} → {norm(pb, k)}')
            for (ch, ea), (_, eb) in zip(ca, cb):
                if ch.isspace(): continue
                for k in CHAR_KEYS:
                    if norm(ea, k) != norm(eb, k):
                        char_loss[k] += 1
                        ex.setdefault(k, f'[{fname[:30]}] « {ta[:40]} » : {norm(ea, k)} → {norm(eb, k)}')

tot_c = collections.Counter(); tot_p = collections.Counter(); docs_c = collections.Counter(); docs_p = collections.Counter(); examples = {}
nchars = 0; npara = 0
for f in sorted(os.listdir('src')):
    ext = f.rsplit('.', 1)[-1].lower(); out = os.path.join('out', f)
    if ext not in ('docx', 'odt') or not os.path.exists(out): continue
    rd = docx_read if ext == 'docx' else odt_read
    a, b = rd(os.path.join('src', f)), rd(out)
    cl, pl = collections.Counter(), collections.Counter()
    compare(a, b, cl, pl, examples, f)
    nchars += sum(len(t.replace(' ', '')) for t, _, _ in a); npara += sum(1 for t, _, _ in a if t.strip())
    for k, v in cl.items(): tot_c[k] += v; docs_c[k] += 1
    for k, v in pl.items(): tot_p[k] += v; docs_p[k] += 1
    worst = sorted(list(cl.items()) + list(pl.items()), key=lambda kv: -kv[1])[:3]
    print(f'{f[:55]:55} ' + ', '.join(f'{NAMES.get(k, k)} {v}' for k, v in worst))
print(f'\n=== Caractères (sur {nchars}) : réglage, documents touchés, caractères changés')
for k, n in docs_c.most_common(): print(f'  {NAMES.get(k, k):20} {n:3} docs {tot_c[k]:7}   ex. {examples.get(k, "")}')
print(f'\n=== Paragraphes (sur {npara}) : réglage, documents touchés, paragraphes changés')
for k, n in docs_p.most_common(): print(f'  {k:20} {n:3} docs {tot_p[k]:7}   ex. {examples.get(k, "")}')
