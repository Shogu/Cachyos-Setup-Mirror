import zipfile,re,os,sys
from xml.dom import minidom
def check(path):
    z=zipfile.ZipFile(path); names=z.namelist(); errs=[]
    if names[0]!='[Content_Types].xml': errs.append('Content_Types pas en tête')
    if any(n.endswith('/') for n in names): errs.append('entrée de dossier')
    app=z.read('docProps/app.xml').decode()
    v=re.search(r'<AppVersion>([^<]*)',app)
    if v and not re.fullmatch(r'\d{1,2}\.\d{4}',v.group(1)): errs.append('AppVersion '+v.group(1))
    ct=z.read('[Content_Types].xml').decode()
    defaults=set(e.lower() for e in re.findall(r'Extension="([^"]+)"',ct)); overrides=set(re.findall(r'PartName="/([^"]+)"',ct))
    for n in names:
        if n.endswith('/') : continue
        if n not in overrides and n.rsplit('.',1)[-1].lower() not in defaults: errs.append('type inconnu '+n)
    for n in names:
        if n.endswith('.xml') or n.endswith('.rels'):
            try: minidom.parseString(z.read(n))
            except Exception as e: errs.append(f'XML invalide {n}: {e}')
    d=z.read('word/document.xml').decode()
    rels=z.read('word/_rels/document.xml.rels').decode()
    ids=set(re.findall(r'Id="([^"]+)"',rels))
    for rid in set(re.findall(r'r:(?:id|embed|link)="([^"]+)"',d)):
        if rid not in ids: errs.append('relation absente '+rid)
    for m in re.finditer(r'<Relationship [^>]*>',rels):
        t=m.group(0)
        if 'External' in t: continue
        tgt=re.search(r'Target="([^"]+)"',t).group(1)
        p=tgt[1:] if tgt.startswith('/') else os.path.normpath('word/'+tgt)
        if p not in names: errs.append('cible absente '+tgt)
    docpr=re.findall(r'<wp:docPr [^>]*id="(\d+)"',d)
    if len(docpr)!=len(set(docpr)): errs.append('docPr id en double')
    body=d[d.find('<w:body>'):]
    if re.search(r'</w:tbl>\s*(<w:sectPr|</w:body>|</w:tc>)',body): errs.append('tableau sans paragraphe après')
    for tc in re.findall(r'<w:tc>(.*?)</w:tc>',body,re.S):
        if '<w:p' not in tc: errs.append('case sans paragraphe'); break
    for tbl in re.findall(r'<w:tbl>.*?</w:tbl>',body,re.S):
        g=len(re.findall('<w:gridCol ',tbl))
        for tr in re.findall(r'<w:tr[ >].*?</w:tr>',tbl,re.S):
            n=sum(int(s) if s else 1 for s in [ (re.search(r'<w:gridSpan w:val="(\d+)"',tc) or [None,None])[1] for tc in re.findall(r'<w:tc>.*?</w:tc>',tr,re.S)])
            if n!=g: errs.append(f'ligne de {n} colonnes pour une grille de {g}'); break
    nums=set(re.findall(r'<w:num w:numId="(\d+)"',z.read('word/numbering.xml').decode())) if 'word/numbering.xml' in names else set()
    for nid in set(re.findall(r'<w:numId w:val="(\d+)"',d)):
        if nid!='0' and nid not in nums: errs.append('liste inconnue '+nid)
    bs=re.findall(r'<w:bookmarkStart [^>]*w:id="(\d+)"',d)
    if len(bs)!=len(set(bs)): errs.append('signet en double')
    if re.search(r'[\x00-\x08\x0b\x0c\x0e-\x1f]',d): errs.append('caractère de contrôle')
    return errs
bad=0
for f in sorted(os.listdir('out')):
    if f.endswith('.docx'):
        e=check('out/'+f)
        if e: bad+=1; print('⚠',f,'; '.join(sorted(set(e)))[:300])
print('docx contrôlés:',len([f for f in os.listdir('out') if f.endswith('.docx')]),'avec problème:',bad)
