// layout::pango — the production shaper, and the one Cairo painter for a
// `RenderTree` (ADR 0010). Screen, print and PDF all draw through
// `Painter::draw_page`, so they cannot disagree.
// SPDX-License-Identifier: GPL-3.0-or-later
//
// Pango and Cairo are not GTK: this runs headless, in tests, in a worker
// thread, or into a `cairo::PdfSurface`.
//
// Units: the Pango context is set to 72 dpi, so one Pango device unit is
// one point and the tree needs no conversion. Metrics hinting is off, so
// line breaks and line heights do not change with zoom — the page is laid
// out once, in points, and only scaled for display.

use std::cell::RefCell;
use std::collections::HashMap;

use pango::prelude::*;

use super::{paragraph_request, request_key, Item, LayoutOptions, LineBox, Look, RenderTree, ShapeCache, ShapeRequest, Shaper, Source};
use crate::model::{Alignment, Document, VertAlign};

/// Pango's fixed-point scale.
const SCALE: f64 = pango::SCALE as f64;

/// A smart chip's label size relative to the text around it.
const CHIP_TEXT_SCALE: f64 = 0.92;

fn to_pt(units: i32) -> f64 {
    f64::from(units) / SCALE
}

fn to_units(pt: f64) -> i32 {
    (pt * SCALE).round() as i32
}

/// A shaper backed by Pango through a Cairo font map, at 72 dpi. It keeps
/// the Pango layout of each paragraph it shapes (by `request_key`), so
/// drawing a page reuses the layout its lines came from.
pub struct PangoShaper {
    context: pango::Context,
    layouts: HashMap<u64, pango::Layout>,
}

impl Default for PangoShaper {
    fn default() -> Self {
        Self::new()
    }
}

impl PangoShaper {
    pub fn new() -> Self {
        let font_map = pangocairo::FontMap::new();
        let context = font_map.create_context();
        pangocairo::functions::context_set_resolution(&context, 72.0);
        let mut options = cairo::FontOptions::new().expect("cairo font options");
        options.set_hint_metrics(cairo::HintMetrics::Off);
        options.set_hint_style(cairo::HintStyle::None);
        // Greyscale, like print and like LibreOffice: subpixel colour
        // fringes belong to one screen, not to the page.
        options.set_antialias(cairo::Antialias::Gray);
        pangocairo::functions::context_set_font_options(&context, Some(&options));
        // Positions in fractional points, not rounded to whole units.
        context.set_round_glyph_positions(false);
        Self { context, layouts: HashMap::new() }
    }

    /// A small label (a smart chip's, a footnote reference's number) in
    /// the paragraph's font at `size_pt`: what the shaper measures and the
    /// painter draws.
    fn label(&self, label: &str, font: &pango::FontDescription, size_pt: f64) -> pango::Layout {
        let layout = pango::Layout::new(&self.context);
        let mut font = font.clone();
        font.set_size(to_units(size_pt));
        layout.set_font_description(Some(&font));
        layout.set_text(label);
        layout
    }

    /// The Pango layout of one paragraph, exactly as the engine shapes it.
    pub fn layout(&self, req: &ShapeRequest<'_>) -> pango::Layout {
        let layout = pango::Layout::new(&self.context);
        let mut base = pango::FontDescription::new();
        base.set_family(if req.code { "Liberation Mono" } else { &req.defaults.font_family });
        let mut size = req.defaults.font_size_pt;
        // A heading's look: the document's own heading style if it has
        // one (family, size, weight, slant, colour), else bold and scaled.
        let mut heading_color = None;
        if let Some(level) = req.heading {
            size = req.defaults.heading_size_pt(level);
            match req.defaults.heading_style(level) {
                Some(h) => {
                    if let Some(f) = &h.font_family {
                        base.set_family(f);
                    }
                    if h.bold {
                        base.set_weight(pango::Weight::Bold);
                    }
                    if h.italic {
                        base.set_style(pango::Style::Italic);
                    }
                    heading_color = h.color.as_deref().and_then(parse_hex);
                }
                None => base.set_weight(pango::Weight::Bold),
            }
        }
        // Title, Subtitle and block quotes (a heading level wins, above).
        if req.heading.is_none() {
            size *= req.look.scale();
            match req.look {
                Look::Title => base.set_weight(pango::Weight::Bold),
                Look::Subtitle => heading_color = Some((0x6666, 0x6666, 0x6666)),
                Look::Quote => base.set_style(pango::Style::Italic),
                Look::Body => {}
            }
        }
        base.set_size(to_units(size));
        layout.set_font_description(Some(&base));

        let mut text = String::new();
        let attrs = pango::AttrList::new();
        if let Some((r, g, b)) = heading_color {
            attrs.insert(pango::AttrColor::new_foreground(r, g, b));
        }
        for run in req.runs {
            let start = text.len() as u32;
            if super::is_object(run) {
                // An image is one object char holding its box open; the
                // painter draws the picture into it (layout_text). A
                // footnote reference is one too, with no size yet.
                text.push(super::OBJECT);
                let rect = if run.style.chip.is_some() {
                    // A chip holds its pill open: the label's width plus
                    // padding and gaps, the label's own ascent and descent.
                    let run_size = run.style.font_size_hp.map_or(size, |hp| f64::from(hp) / 2.0);
                    let label = self.label(&run.text, &base, run_size * CHIP_TEXT_SCALE);
                    let (_, logical) = label.extents();
                    let w = to_pt(logical.width()) + 2.0 * (super::CHIP_PAD_PT + super::CHIP_GAP_PT);
                    pango::Rectangle::new(0, -label.baseline(), to_units(w), logical.height())
                } else if let Some(n) = run.style.footnote {
                    // A footnote reference holds its superscript number's
                    // width; it is drawn raised, so it adds no height.
                    let run_size = run.style.font_size_hp.map_or(size, |hp| f64::from(hp) / 2.0);
                    let label = self.label(&(n + 1).to_string(), &base, run_size * super::NOTE_REF_SCALE);
                    let (_, logical) = label.extents();
                    pango::Rectangle::new(0, 0, logical.width(), 0)
                } else {
                    let (w, h) = if run.style.image.is_some() { super::image_size_pt(run, req.width_pt) } else { (0.0, 0.0) };
                    pango::Rectangle::new(0, -to_units(h), to_units(w), to_units(h))
                };
                let mut a: pango::Attribute = pango::AttrShape::new(&rect, &rect).into();
                a.set_start_index(start);
                a.set_end_index(text.len() as u32);
                attrs.insert(a);
                continue;
            }
            text.push_str(&run.text);
            let end = text.len() as u32;
            if start == end {
                continue;
            }
            let add = |mut a: pango::Attribute| {
                a.set_start_index(start);
                a.set_end_index(end);
                attrs.insert(a);
            };
            let st = &run.style;
            if st.bold {
                add(pango::AttrInt::new_weight(pango::Weight::Bold).into());
            }
            if st.italic {
                add(pango::AttrInt::new_style(pango::Style::Italic).into());
            }
            if st.underline || st.link.is_some() {
                add(pango::AttrInt::new_underline(pango::Underline::Single).into());
            }
            if st.strikethrough {
                add(pango::AttrInt::new_strikethrough(true).into());
            }
            if let Some(family) = &st.font_family {
                add(pango::AttrString::new_family(family).into());
            }
            if st.code {
                add(pango::AttrString::new_family("Liberation Mono").into());
            }
            let run_size = st.font_size_hp.map_or(size, |hp| f64::from(hp) / 2.0);
            if st.font_size_hp.is_some() {
                add(pango::AttrSize::new(to_units(run_size)).into());
            }
            if let Some((r, g, b)) = st.color.as_deref().and_then(parse_hex) {
                add(pango::AttrColor::new_foreground(r, g, b).into());
            } else if st.link.is_some() {
                add(pango::AttrColor::new_foreground(0x1a1a, 0x5f5f, 0xb4b4).into());
            }
            if st.highlight {
                // Samizdat : la couleur du surlignage (jaune par défaut).
                let (r, g, b) = st.highlight_color.as_deref().and_then(parse_hex).unwrap_or((0xffff, 0xffff, 0x0000));
                add(pango::AttrColor::new_background(r, g, b).into());
            }
            match st.vert_align {
                // 58% size, raised a third / lowered a sixth of the line,
                // as LibreOffice and Word draw them.
                Some(VertAlign::Superscript) => {
                    add(pango::AttrFloat::new_scale(0.58).into());
                    add(pango::AttrInt::new_rise(to_units(run_size * 0.33)).into());
                }
                Some(VertAlign::Subscript) => {
                    add(pango::AttrFloat::new_scale(0.58).into());
                    add(pango::AttrInt::new_rise(-to_units(run_size * 0.14)).into());
                }
                None => {}
            }
            // A tracked change, as Word and LibreOffice show one: in its
            // author's colour, an insertion underlined, a deletion struck
            // through. Last, so it wins over the run's own colour.
            if let Some(rev) = &st.revision {
                let (r, g, b) = crate::track::author_color(&rev.author);
                add(pango::AttrColor::new_foreground(r, g, b).into());
                match rev.kind {
                    crate::model::RevisionKind::Insert => add(pango::AttrInt::new_underline(pango::Underline::Single).into()),
                    crate::model::RevisionKind::Delete => add(pango::AttrInt::new_strikethrough(true).into()),
                }
            }
        }
        // Spaces ending a paragraph take no width. Pango lets spaces hang
        // past the margin where it breaks a line, but not at the end of the
        // text, so a last line that fits to the margin without its trailing
        // space was wrapped a word early (render-lab letters/indents: the
        // fixture's paragraphs end in a space, as typed text often does).
        // Word and LibreOffice let them hang. A zero-size shape keeps the
        // chars, so offsets are unchanged.
        let body = text.trim_end_matches([' ', '\t']);
        if !body.trim().is_empty() && body.len() < text.len() {
            let zero = pango::Rectangle::new(0, 0, 0, 0);
            let mut a: pango::Attribute = pango::AttrShape::new(&zero, &zero).into();
            a.set_start_index(body.len() as u32);
            a.set_end_index(text.len() as u32);
            attrs.insert(a);
        }
        layout.set_text(&text);
        layout.set_attributes(Some(&attrs));
        layout.set_width(to_units(req.width_pt.max(1.0)));
        layout.set_wrap(pango::WrapMode::WordChar);
        layout.set_indent(to_units(req.first_line_indent_pt));
        layout.set_alignment(match req.alignment {
            Alignment::Center => pango::Alignment::Center,
            Alignment::Right => pango::Alignment::Right,
            _ => pango::Alignment::Left,
        });
        layout.set_justify(req.alignment == Alignment::Justify);
        if req.right_tab {
            let mut tabs = pango::TabArray::new(1, false);
            tabs.set_tab(0, pango::TabAlign::Right, to_units(req.width_pt));
            layout.set_tabs(Some(&tabs));
        } else if !req.tab_stops_pt.is_empty() {
            let mut tabs = pango::TabArray::new(req.tab_stops_pt.len() as i32, false);
            for (i, t) in req.tab_stops_pt.iter().enumerate() {
                tabs.set_tab(i as i32, pango::TabAlign::Left, to_units(*t));
            }
            layout.set_tabs(Some(&tabs));
        }
        layout
    }
}

/// "RRGGBB" to 16-bit channels, via the canonical shared colour
/// (`suite_common_core::color::Color`). Behaviour on the inputs
/// Letters produces (6-digit RRGGBB, optional '#') is unchanged; the
/// shared parser additionally trims whitespace and accepts AARRGGBB,
/// which Letters' model never emits.
fn parse_hex(hex: &str) -> Option<(u16, u16, u16)> {
    suite_common_core::color::Color::from_hex(hex).map(|c| c.to_u16())
}

/// Lines of a layout as `LineBox`es, with char (not byte) offsets.
fn line_boxes(layout: &pango::Layout) -> Vec<LineBox> {
    let text = layout.text();
    let char_at = |byte: i32| text[..(byte.max(0) as usize).min(text.len())].chars().count();
    // Inline objects: (char index, byte index).
    let objects: Vec<(usize, i32)> = text
        .char_indices()
        .enumerate()
        .filter(|(_, (_, c))| *c == super::OBJECT)
        .map(|(ci, (bi, _))| (ci, bi as i32))
        .collect();
    let mut out = Vec::new();
    let mut iter = layout.iter();
    loop {
        let (_, logical) = iter.line_extents();
        let baseline = iter.baseline();
        if let Some(line) = iter.line_readonly() {
            let start = line.start_index();
            let (cs, ce) = (char_at(start), char_at(start + line.length()));
            out.push(LineBox {
                objects: objects
                    .iter()
                    .filter(|(ci, _)| (cs..ce).contains(ci))
                    .map(|&(ci, bi)| (ci, to_pt(layout.index_to_pos(bi).x())))
                    .collect(),
                start: cs,
                end: ce,
                x_pt: to_pt(logical.x()),
                width_pt: to_pt(logical.width()),
                ascent_pt: to_pt(baseline - logical.y()),
                descent_pt: to_pt(logical.y() + logical.height() - baseline),
            });
        }
        if !iter.next_line() {
            break;
        }
    }
    out
}

impl Shaper for PangoShaper {
    fn shape(&mut self, req: &ShapeRequest<'_>) -> Vec<LineBox> {
        let layout = self.layout(req);
        self.layouts.insert(request_key(req), layout.clone());
        let mut lines = line_boxes(&layout);
        // A line is as tall as the font's ascent, descent *and* line gap,
        // as LibreOffice and Word space lines (Liberation Serif 12pt:
        // 13.8pt); Pango's logical extents leave the gap out.
        if let Some(desc) = layout.font_description() {
            let m = self.context.metrics(Some(&desc), None);
            let gap = to_pt(m.height() - m.ascent() - m.descent()).max(0.0);
            for l in &mut lines {
                l.descent_pt += gap;
            }
        }
        lines
    }
}

/// A document laid out with Pango, ready to draw: the `RenderTree` plus
/// what drawing it needs. `draw_page` is the one routine that paints a
/// page, onto any Cairo context — a widget snapshot, a print context or a
/// PDF surface. The context's user space must be the page in points (scale
/// it for zoom before calling).
pub struct Typeset {
    doc: Document,
    opts: LayoutOptions,
    tree: RenderTree,
    shaper: PangoShaper,
    /// Shaped paragraphs kept for the next `update`.
    shapes: ShapeCache,
    /// Layouts made for drawing that the shaper did not keep (a paragraph's
    /// lines came from the shape cache), by request key.
    cache: RefCell<HashMap<u64, pango::Layout>>,
    images: RefCell<HashMap<String, Option<cairo::ImageSurface>>>,
    loader: Box<ImageLoader>,
    /// Les numéros de ligne en marge, calculés au premier dessin.
    numbers: RefCell<Option<Vec<LineNumber>>>,
    /// Samizdat (aménagement) : une ligne sur deux légèrement teintée.
    tint: bool,
}

/// Un numéro de ligne en marge : page, bord droit, ligne de base, numéro.
type LineNumber = (usize, f64, f64, u32);

/// L'écart entre un numéro de ligne et le texte, en points.
const LINE_NUMBER_GAP_PT: f64 = 9.0;

/// Decodes the image at a path for drawing.
type ImageLoader = dyn Fn(&str) -> Option<cairo::ImageSurface>;

/// A place in the document's text: paragraph index and char offset in its
/// layout text (`layout::layout_text`: an image is one char).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct TextPos {
    pub para: usize,
    pub offset: usize,
}

/// A piece of a selection: (page, x, top, width, height) in points.
pub type SelectionRect = (usize, f64, f64, f64, f64);

/// A comment's margin mark: width and height in points.
pub const COMMENT_MARK_PT: (f64, f64) = (12.0, 10.0);

/// An open comment thread on the pages, as a view shows it (print and PDF
/// do not, as LibreOffice's do not): the rectangles its text covers, and
/// a spot in the right margin beside its first line.
#[derive(Clone, Debug, PartialEq)]
pub struct CommentMark {
    pub id: u32,
    pub author: String,
    /// Comments in the thread, the first included.
    pub count: usize,
    /// Where its text starts.
    pub from: TextPos,
    pub rects: Vec<SelectionRect>,
    pub page: usize,
    /// The margin spot's left and top, in points on `page`.
    pub x_pt: f64,
    pub y_pt: f64,
}

/// A caret's box, in points on page `page`.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Caret {
    pub page: usize,
    pub x_pt: f64,
    pub top_pt: f64,
    pub height_pt: f64,
}

/// One body line on a page, as hit-testing needs it.
struct LineRef {
    para: usize,
    line: usize,
    box_x: f64,
    box_w: f64,
    x: f64,
    top: f64,
    height: f64,
    start: usize,
    end: usize,
}

/// The built-in image loader: PNG through Cairo.
fn load_png(path: &str) -> Option<cairo::ImageSurface> {
    let mut f = std::fs::File::open(path).ok()?;
    cairo::ImageSurface::create_from_png(&mut f).ok()
}

impl Typeset {
    /// Lay `doc` out into pages.
    pub fn new(doc: Document, opts: LayoutOptions) -> Self {
        let mut shaper = PangoShaper::new();
        let mut shapes = ShapeCache::default();
        let opts = opts.for_document(&doc);
        let tree = super::relayout(&doc, &opts, &mut shaper, &mut shapes);
        shapes.prune();
        Self {
            doc,
            opts,
            tree,
            shaper,
            shapes,
            cache: RefCell::new(HashMap::new()),
            images: RefCell::new(HashMap::new()),
            loader: Box::new(load_png),
            numbers: RefCell::new(None),
            tint: false,
        }
    }

    /// Une ligne de texte sur deux sur un fond légèrement teinté, pour
    /// suivre la ligne (PDF aménagé).
    pub fn set_alternate_tint(&mut self, on: bool) {
        self.tint = on;
    }

    pub fn tree(&self) -> &RenderTree {
        &self.tree
    }

    /// Where each page starts, as a character offset in the document's
    /// text (`RenderTree::page_breaks`).
    pub fn page_breaks(&self) -> Vec<usize> {
        self.tree.page_breaks(&self.doc)
    }

    /// Lay out `doc` in place of the current document, re-shaping only the
    /// paragraphs that changed (ADR 0010 stage 3c). Returns how many were
    /// shaped.
    pub fn update(&mut self, doc: Document, opts: LayoutOptions) -> usize {
        self.opts = opts.for_document(&doc);
        self.tree = super::relayout(&doc, &self.opts, &mut self.shaper, &mut self.shapes);
        self.doc = doc;
        let shaped = self.shapes.misses;
        self.shapes.prune();
        let keep: std::collections::HashSet<u64> = self.shapes.keys().copied().collect();
        self.shaper.layouts.retain(|k, _| keep.contains(k));
        self.cache.borrow_mut().clear();
        self.numbers.borrow_mut().take();
        shaped
    }

    pub fn document(&self) -> &Document {
        &self.doc
    }

    /// Decode images with `loader` (path to a Cairo surface) rather than
    /// the built-in PNG-only one. The app passes one backed by GdkTexture,
    /// which reads every format it can show.
    pub fn set_image_loader(&mut self, loader: impl Fn(&str) -> Option<cairo::ImageSurface> + 'static) {
        self.loader = Box::new(loader);
    }

    /// A smart chip: a rounded pill in the chip's colour with its label,
    /// shaped as `PangoShaper::layout` measured it.
    fn draw_chip(&self, cr: &cairo::Context, para: usize, ch: usize, x: f64, baseline: f64) {
        let Some(p) = self.doc.paragraphs.get(para) else { return };
        let Some(run) = super::run_at(&p.runs, ch) else { return };
        let Some(chip) = &run.style.chip else { return };
        // The paragraph's own font, as the shaper used it.
        let req = paragraph_request(p, 1000.0, &self.opts);
        let base = self.shaper.layout(&ShapeRequest { runs: &[], ..req });
        let font = base.font_description().unwrap_or_default();
        let size = run.style.font_size_hp.map_or(to_pt(font.size()), |hp| f64::from(hp) / 2.0);
        let label = self.shaper.label(&run.text, &font, size * CHIP_TEXT_SCALE);
        let (_, logical) = label.extents();
        let (w, h) = (to_pt(logical.width()) + 2.0 * super::CHIP_PAD_PT, to_pt(logical.height()));
        let (left, top) = (x + super::CHIP_GAP_PT, baseline - to_pt(label.baseline()));
        // Google's chip colours, light enough to print.
        let (fill, ink) = match chip.kind {
            crate::chips::ChipKind::Date => ((0.91, 0.94, 0.99), (0.10, 0.34, 0.71)),
            crate::chips::ChipKind::Person => ((0.93, 0.93, 0.93), (0.13, 0.13, 0.13)),
            crate::chips::ChipKind::Link => ((0.90, 0.96, 0.92), (0.09, 0.42, 0.22)),
        };
        let r = h / 2.0;
        let _ = cr.save();
        cr.new_sub_path();
        cr.arc(left + r, top + r, r, std::f64::consts::FRAC_PI_2, 3.0 * std::f64::consts::FRAC_PI_2);
        cr.arc(left + w - r, top + r, r, -std::f64::consts::FRAC_PI_2, std::f64::consts::FRAC_PI_2);
        cr.close_path();
        cr.set_source_rgb(fill.0, fill.1, fill.2);
        let _ = cr.fill();
        cr.set_source_rgb(ink.0, ink.1, ink.2);
        cr.move_to(left + super::CHIP_PAD_PT, top);
        pangocairo::functions::show_layout(cr, &label);
        let _ = cr.restore();
    }

    /// A footnote reference: the note's number, superscript, as the shaper
    /// measured it.
    fn draw_note_ref(&self, cr: &cairo::Context, para: usize, ch: usize, x: f64, baseline: f64) {
        let Some(p) = self.doc.paragraphs.get(para) else { return };
        let Some(run) = super::run_at(&p.runs, ch) else { return };
        let Some(n) = run.style.footnote else { return };
        let req = paragraph_request(p, 1000.0, &self.opts);
        let base = self.shaper.layout(&ShapeRequest { runs: &[], ..req });
        let font = base.font_description().unwrap_or_default();
        let size = run.style.font_size_hp.map_or(to_pt(font.size()), |hp| f64::from(hp) / 2.0);
        let label = self.shaper.label(&(n + 1).to_string(), &font, size * super::NOTE_REF_SCALE);
        let _ = cr.save();
        cr.move_to(x, baseline - size * super::NOTE_REF_RISE - to_pt(label.baseline()));
        pangocairo::functions::show_layout(cr, &label);
        let _ = cr.restore();
    }

    fn draw_image(&self, cr: &cairo::Context, src: &str, x: f64, y: f64, w: f64, h: f64) {
        let surface = self.images.borrow_mut().entry(src.to_string()).or_insert_with(|| (self.loader)(src)).clone();
        let _ = cr.save();
        match surface {
            Some(img) if img.width() > 0 && img.height() > 0 => {
                cr.rectangle(x, y, w, h);
                cr.clip();
                cr.translate(x, y);
                cr.scale(w / f64::from(img.width()), h / f64::from(img.height()));
                let _ = cr.set_source_surface(&img, 0.0, 0.0);
                let _ = cr.paint();
            }
            // Unreadable: a light frame where it would be, not nothing.
            _ => {
                cr.set_source_rgb(0.8, 0.8, 0.8);
                cr.set_line_width(0.5);
                cr.rectangle(x, y, w, h);
                let _ = cr.stroke();
            }
        }
        let _ = cr.restore();
    }

    fn paragraph_layout(&self, para: usize, box_w: f64) -> Option<pango::Layout> {
        let p = self.doc.paragraphs.get(para)?;
        let req = paragraph_request(p, box_w, &self.opts);
        let key = request_key(&req);
        if let Some(l) = self.shaper.layouts.get(&key) {
            return Some(l.clone());
        }
        let mut cache = self.cache.borrow_mut();
        Some(cache.entry(key).or_insert_with(|| self.shaper.layout(&req)).clone())
    }

    /// Write every page to a PDF at `path`, one PDF page per laid-out page
    /// at its own size, drawn by `draw_page` — the same routine the page
    /// view and printing use, so the PDF is the Print Layout.
    pub fn write_pdf(&self, path: impl AsRef<std::path::Path>) -> Result<(), String> {
        let first = self.tree.pages.first().ok_or("no pages to write")?;
        let surface = cairo::PdfSurface::new(first.width_pt, first.height_pt, path.as_ref())
            .map_err(|e| format!("cannot create {}: {e}", path.as_ref().display()))?;
        // PDF 1.4: readable everywhere, and no compressed object streams, so
        // the page tree is plain text a test can count.
        surface.restrict(cairo::PdfVersion::_1_4).map_err(|e| e.to_string())?;
        let cr = cairo::Context::new(&surface).map_err(|e| e.to_string())?;
        for (index, page) in self.tree.pages.iter().enumerate() {
            // A section of another size (landscape) gets its own page size.
            surface.set_size(page.width_pt, page.height_pt).map_err(|e| e.to_string())?;
            self.draw_page(&cr, index);
            cr.show_page().map_err(|e| e.to_string())?;
        }
        drop(cr);
        surface.finish();
        match surface.status() {
            Ok(()) => Ok(()),
            Err(e) => Err(format!("cannot write {}: {e}", path.as_ref().display())),
        }
    }

    /// The body line items of `page`: (paragraph, line, box width, line x,
    /// top, height, char range).
    fn body_lines(&self, page: usize) -> Vec<LineRef> {
        let Some(page) = self.tree.pages.get(page) else { return Vec::new() };
        page.items
            .iter()
            .filter_map(|i| match i {
                Item::Line { source: Source::Paragraph(p), line, box_x_pt, box_width_pt, x_pt, top_pt, height_pt, start, end, .. } => {
                    Some(LineRef {
                        para: *p,
                        line: *line,
                        box_x: *box_x_pt,
                        box_w: *box_width_pt,
                        x: *x_pt,
                        top: *top_pt,
                        height: *height_pt,
                        start: *start,
                        end: *end,
                    })
                }
                _ => None,
            })
            .collect()
    }

    /// The text position nearest to (`x_pt`, `y_pt`) on page `page`, in
    /// points from the page's corner: the line under the point (or the
    /// nearest one), then the character boundary nearest to it on that line.
    pub fn hit_test(&self, page: usize, x_pt: f64, y_pt: f64) -> Option<TextPos> {
        let lines = self.body_lines(page);
        // Distance from the point to a line's box, vertical first: a click
        // beside a table cell belongs to that cell's row, then its column.
        let distance = |l: &LineRef| {
            let dy = if y_pt < l.top { l.top - y_pt } else if y_pt > l.top + l.height { y_pt - l.top - l.height } else { 0.0 };
            let dx = if x_pt < l.box_x { l.box_x - x_pt } else if x_pt > l.box_x + l.box_w { x_pt - l.box_x - l.box_w } else { 0.0 };
            (dy, dx)
        };
        let best = lines.iter().min_by(|a, b| distance(a).partial_cmp(&distance(b)).unwrap_or(std::cmp::Ordering::Equal))?;
        let layout = self.paragraph_layout(best.para, best.box_w)?;
        let line = layout.line_readonly(best.line as i32)?;
        let hit = line.x_to_index(to_units(x_pt - best.x));
        let text = layout.text();
        let byte = (hit.index().max(0) as usize).min(text.len());
        let mut offset = text[..byte].chars().count() + hit.trailing().max(0) as usize;
        // The end of a wrapped line is the start of the next one; keep the
        // caret on the line that was clicked (before its trailing space).
        let para_len = text.chars().count();
        if offset >= best.end && best.end < para_len && best.end > best.start {
            offset = best.end - 1;
        }
        Some(TextPos { para: best.para, offset: offset.min(para_len) })
    }

    /// Where the caret for `pos` is drawn: page, x, line top and height in
    /// points. The caret at a wrap point is on the later line.
    pub fn caret(&self, pos: TextPos) -> Option<Caret> {
        for (index, _) in self.tree.pages.iter().enumerate() {
            let lines = self.body_lines(index);
            let para_lines: Vec<&LineRef> = lines.iter().filter(|l| l.para == pos.para).collect();
            let Some(line) = para_lines
                .iter()
                .find(|l| pos.offset >= l.start && (pos.offset < l.end || l.start == l.end))
                .or_else(|| para_lines.iter().rev().find(|l| pos.offset == l.end))
            else {
                continue;
            };
            let layout = self.paragraph_layout(line.para, line.box_w)?;
            let pl = layout.line_readonly(line.line as i32)?;
            let text = layout.text();
            let byte = text.char_indices().nth(pos.offset).map_or(text.len(), |(b, _)| b);
            let x = to_pt(pl.index_to_x(byte as i32, false));
            return Some(Caret { page: index, x_pt: line.x + x, top_pt: line.top, height_pt: line.height });
        }
        None
    }

    /// Rectangles covering the text from `from` to `to` (in document order),
    /// one per line piece: (page, x, top, width, height) in points.
    pub fn selection_rects(&self, from: TextPos, to: TextPos) -> Vec<SelectionRect> {
        let (a, b) = if (to.para, to.offset) < (from.para, from.offset) { (to, from) } else { (from, to) };
        let mut out = Vec::new();
        for index in 0..self.tree.pages.len() {
            for l in self.body_lines(index) {
                if l.para < a.para || l.para > b.para {
                    continue;
                }
                let s = if l.para == a.para { a.offset.max(l.start) } else { l.start };
                let e = if l.para == b.para { b.offset.min(l.end) } else { l.end };
                let whole_rest = l.para < b.para && l.end >= self.layout_len(l.para);
                if s > e || (s == e && !whole_rest) {
                    continue;
                }
                let Some(layout) = self.paragraph_layout(l.para, l.box_w) else { continue };
                let Some(pl) = layout.line_readonly(l.line as i32) else { continue };
                let text = layout.text();
                let byte = |c: usize| text.char_indices().nth(c).map_or(text.len(), |(b, _)| b) as i32;
                let x0 = to_pt(pl.index_to_x(byte(s), false));
                let mut x1 = to_pt(pl.index_to_x(byte(e), false));
                // A selection running past the paragraph end shows its
                // newline as a space's width.
                if whole_rest {
                    x1 += 4.0;
                }
                out.push((index, l.x + x0.min(x1), l.top, (x1 - x0).abs(), l.height));
            }
        }
        out
    }

    /// L'allure du cartouche `table` (celle de son premier paragraphe).
    fn cartouche(&self, table: u32) -> crate::model::Cartouche {
        self.doc
            .paragraphs
            .iter()
            .find(|p| p.style.table_cell.is_some_and(|c| c.table == table))
            .and_then(|p| p.style.cartouche)
            .unwrap_or_default()
    }

    /// Whether table `table` has a single cell (a text box).
    fn single_cell(&self, table: u32) -> bool {
        self.doc.paragraphs.iter().filter_map(|p| p.style.table_cell).filter(|c| c.table == table).all(|c| c.row == 0 && c.col == 0)
    }

    /// The page (from 0) each paragraph starts on: a table of contents'
    /// page numbers (`crate::toc::settle`). None for one with no line.
    pub fn paragraph_pages(&self) -> Vec<Option<usize>> {
        let mut out = vec![None; self.doc.paragraphs.len()];
        for (i, page) in self.tree.pages.iter().enumerate() {
            for item in &page.items {
                if let Item::Line { source: Source::Paragraph(p), .. } = item {
                    if let Some(slot) = out.get_mut(*p).filter(|s| s.is_none()) {
                        *slot = Some(i);
                    }
                }
            }
        }
        out
    }

    /// The open (unresolved) comment threads with text, in document order
    /// (`crate::comments`). Spots on one line sit side by side.
    pub fn comment_marks(&self) -> Vec<CommentMark> {
        let mut out: Vec<CommentMark> = Vec::new();
        let pos = |at: usize| crate::edit::locate(&self.doc, at).map(|(para, offset)| TextPos { para, offset });
        for t in crate::comments::threads(&self.doc) {
            let Some(a) = t.anchor.filter(|_| !t.comment.resolved) else { continue };
            let (Some(from), Some(to)) = (pos(a.start), pos(a.end)) else { continue };
            let rects = self.selection_rects(from, to);
            let Some(&(page, _, top, _, _)) = rects.first() else { continue };
            let Some(p) = self.tree.pages.get(page) else { continue };
            let mut x = (p.width_pt - p.geometry.margin_right_pt + 8.0).min(p.width_pt - 20.0);
            // Beside the spots already on this line.
            x += 16.0 * out.iter().filter(|m| m.page == page && (m.y_pt - top).abs() < 1.0).count() as f64;
            out.push(CommentMark { id: t.comment.id, author: t.comment.author, count: 1 + t.replies.len(), from, rects, page, x_pt: x, y_pt: top });
        }
        out
    }

    /// A table of contents entry's dot leader: dots across its tab's gap on
    /// `line`, from the page number back, a dot and a half apart.
    fn draw_leader(&self, cr: &cairo::Context, para: usize, layout: &pango::Layout, line: &pango::LayoutLine, x_pt: f64, baseline_pt: f64) {
        let text = layout.text();
        let Some(tab) = text.find('\t') else { return };
        let start = line.start_index().max(0) as usize;
        if tab < start || tab >= start + line.length().max(0) as usize {
            return;
        }
        let from = x_pt + to_pt(line.index_to_x(tab as i32, false));
        let to = x_pt + to_pt(line.index_to_x(tab as i32, true));
        let Some(p) = self.doc.paragraphs.get(para) else { return };
        let dot_runs = [crate::model::Run::plain(".")];
        let mut req = paragraph_request(p, 1000.0, &self.opts);
        req.runs = &dot_runs;
        req.right_tab = false;
        let dot = self.shaper.layout(&req);
        let Some(dot_line) = dot.line_readonly(0) else { return };
        let w = to_pt(dot_line.index_to_x(1, false)).max(1.0);
        let step = w * 1.5;
        let mut x = to - w - step * 0.5;
        while x >= from + w * 0.5 {
            cr.move_to(x, baseline_pt);
            pangocairo::functions::show_layout_line(cr, &dot_line);
            x -= step;
        }
    }

    /// Length of paragraph `para`'s layout text, in chars.
    pub fn layout_len(&self, para: usize) -> usize {
        self.doc.paragraphs.get(para).map_or(0, |p| super::layout_text(&p.runs).chars().count())
    }

    /// Les numéros de ligne de tout le document : une ligne sur cinq d'un
    /// texte (des paragraphes numérotés qui se suivent), les lignes vides
    /// non comptées, à partir de 1 pour chaque texte.
    fn line_numbers(&self) -> Vec<LineNumber> {
        if let Some(n) = self.numbers.borrow().as_ref() {
            return n.clone();
        }
        let paras = &self.doc.paragraphs;
        // Le premier paragraphe du texte de chaque paragraphe numéroté.
        let mut text_of = vec![None; paras.len()];
        for i in 0..paras.len() {
            if paras[i].style.line_numbers {
                text_of[i] = Some(if i > 0 && paras[i - 1].style.line_numbers { text_of[i - 1].unwrap_or(i) } else { i });
            }
        }
        let mut out = Vec::new();
        let mut current: Option<usize> = None;
        let mut count = 0u32;
        for (pi, page) in self.tree.pages.iter().enumerate() {
            let g = &page.geometry;
            let n = f64::from(g.columns.max(1));
            let col_w = ((page.width_pt - g.margin_left_pt - g.margin_right_pt - g.column_gap_pt * (n - 1.0)) / n).max(1.0);
            for item in &page.items {
                let Item::Line { source: Source::Paragraph(p), text, box_x_pt, baseline_pt, .. } = item else { continue };
                let Some(Some(t)) = text_of.get(*p) else { continue };
                if current != Some(*t) {
                    current = Some(*t);
                    count = 0;
                }
                if text.trim().is_empty() {
                    continue;
                }
                count += 1;
                if count % 5 != 0 {
                    continue;
                }
                // Dans la marge de la colonne de la ligne, hors du cadre
                // d'un cartouche.
                let col = ((box_x_pt - g.margin_left_pt) / (col_w + g.column_gap_pt)).floor().clamp(0.0, n - 1.0);
                let mut right = g.margin_left_pt + col * (col_w + g.column_gap_pt) - LINE_NUMBER_GAP_PT;
                if paras[*p].style.table_cell.is_some() {
                    right -= super::CELL_PADDING_PT;
                }
                out.push((pi, right, *baseline_pt, count));
            }
        }
        *self.numbers.borrow_mut() = Some(out.clone());
        out
    }

    fn draw_line_numbers(&self, cr: &cairo::Context, index: usize) {
        let marks: Vec<LineNumber> = self.line_numbers().into_iter().filter(|m| m.0 == index).collect();
        if marks.is_empty() {
            return;
        }
        let layout = pango::Layout::new(&self.shaper.context);
        let size = (self.opts.font_size_pt * 0.8).max(7.5);
        let desc = pango::FontDescription::from_string(&format!("{} {size}", self.opts.font_family));
        layout.set_font_description(Some(&desc));
        let _ = cr.save();
        cr.set_source_rgb(0.37, 0.36, 0.39);
        for (_, right, baseline, n) in marks {
            layout.set_text(&n.to_string());
            let w = to_pt(layout.size().0);
            cr.move_to(right - w, baseline - to_pt(layout.baseline()));
            pangocairo::functions::show_layout(cr, &layout);
        }
        let _ = cr.restore();
    }

    /// Draw page `index`'s content (not the paper itself). An index out of
    /// range draws nothing.
    pub fn draw_page(&self, cr: &cairo::Context, index: usize) {
        let Some(page) = self.tree.pages.get(index) else { return };
        if self.tint {
            let _ = cr.save();
            cr.set_source_rgb(0.925, 0.945, 0.98);
            let lines = page.items.iter().filter_map(|i| match i {
                Item::Line { source: Source::Paragraph(p), box_x_pt, box_width_pt, top_pt, height_pt, text, .. }
                    if self.doc.paragraphs.get(*p).is_some_and(|p| p.style.table_cell.is_none()) && !text.trim().is_empty() =>
                {
                    Some((*box_x_pt, *box_width_pt, *top_pt, *height_pt))
                }
                _ => None,
            });
            for (k, (x, w, top, h)) in lines.enumerate() {
                if k % 2 == 1 {
                    cr.rectangle(x - 4.0, top, w + 8.0, h);
                }
            }
            let _ = cr.fill();
            let _ = cr.restore();
        }
        cr.set_source_rgb(0.0, 0.0, 0.0);
        for item in &page.items {
            match item {
                Item::Line { source: Source::Paragraph(p), line, box_width_pt, x_pt, baseline_pt, .. } => {
                    let Some(layout) = self.paragraph_layout(*p, *box_width_pt) else { continue };
                    if let Some(l) = layout.line_readonly(*line as i32) {
                        cr.move_to(*x_pt, *baseline_pt);
                        pangocairo::functions::show_layout_line(cr, &l);
                        if self.doc.paragraphs.get(*p).is_some_and(|p| p.style.toc.is_some()) {
                            self.draw_leader(cr, *p, &layout, &l, *x_pt, *baseline_pt);
                        }
                    }
                }
                Item::Line { source: source @ (Source::Header | Source::Footer), text, box_x_pt, box_width_pt, top_pt, .. } => {
                    let template = if *source == Source::Header { self.doc.header.as_deref() } else { self.doc.footer.as_deref() };
                    // Samizdat : en trois zones (« gauche\tcentre\tdroite »),
                    // une ligne par « \n » ; sinon tout le texte aligné.
                    let zones: Vec<(String, Alignment)> = if text.contains('\t') {
                        let mut cols = [String::new(), String::new(), String::new()];
                        for (i, line) in text.split('\n').enumerate() {
                            let parts: Vec<&str> = if line.contains('\t') {
                                line.splitn(3, '\t').collect()
                            } else if template.is_some_and(|t| t.split('\n').nth(i).is_some_and(|l| l.contains("{page}"))) {
                                vec!["", line]
                            } else {
                                vec![line]
                            };
                            for (k, col) in cols.iter_mut().enumerate() {
                                if i > 0 {
                                    col.push('\n');
                                }
                                col.push_str(parts.get(k).copied().unwrap_or(""));
                            }
                        }
                        let [l, c, r] = cols;
                        vec![(l, Alignment::Left), (c, Alignment::Center), (r, Alignment::Right)]
                    } else {
                        vec![(text.clone(), super::page_field_alignment(template.unwrap_or_default()))]
                    };
                    for (zone, alignment) in zones {
                        if zone.trim().is_empty() {
                            continue;
                        }
                        let runs = [crate::model::Run::plain(zone)];
                        let req = ShapeRequest {
                            runs: &runs,
                            heading: None,
                            code: false,
                            look: Look::Body,
                            alignment,
                            width_pt: *box_width_pt,
                            first_line_indent_pt: 0.0,
                            tab_stops_pt: Vec::new(),
                            right_tab: false,
                            defaults: &self.opts,
                        };
                        let layout = self.shaper.layout(&req);
                        cr.move_to(*box_x_pt, *top_pt);
                        pangocairo::functions::show_layout(cr, &layout);
                    }
                }
                Item::Marker { para, text, x_pt, baseline_pt } => {
                    // The marker takes the item's first-run font and size.
                    let Some(p) = self.doc.paragraphs.get(*para) else { continue };
                    let first = p.runs.iter().find(|r| !r.text.is_empty());
                    let mut run = crate::model::Run::plain(text.clone());
                    if let Some(f) = first {
                        run.style.font_family = f.style.font_family.clone();
                        run.style.font_size_hp = f.style.font_size_hp;
                        run.style.color = f.style.color.clone();
                    }
                    let size = run.style.font_size_hp.map_or_else(
                        || p.style.heading.map_or(self.opts.font_size_pt, |l| self.opts.heading_size_pt(l)),
                        |hp| f64::from(hp) / 2.0,
                    );
                    if text.as_str() == crate::lists::BULLET.to_string() {
                        // Word's and LibreOffice's default bullet (Symbol /
                        // OpenSymbol) is a disc about 0.31 em across, its
                        // centre 0.28 em above the baseline; the "•" of a
                        // text face is smaller and varies by font. Drawn,
                        // it looks the same whatever fonts are installed.
                        let r = size * 0.155;
                        let (r_, g, b) = run.style.color.as_deref().and_then(parse_hex).unwrap_or((0, 0, 0));
                        let _ = cr.save();
                        cr.set_source_rgb(f64::from(r_) / 65535.0, f64::from(g) / 65535.0, f64::from(b) / 65535.0);
                        // Un chemin neuf : sinon l'arc partait du point courant
                        // (la fin de la ligne précédente) et traçait un trait.
                        cr.new_path();
                        cr.arc(*x_pt + r, *baseline_pt - size * 0.28, r, 0.0, std::f64::consts::TAU);
                        let _ = cr.fill();
                        let _ = cr.restore();
                        continue;
                    }
                    let runs = [run];
                    let mut req = paragraph_request(p, 1000.0, &self.opts);
                    req.runs = &runs;
                    req.first_line_indent_pt = 0.0;
                    req.alignment = Alignment::Left;
                    let layout = self.shaper.layout(&req);
                    cr.move_to(*x_pt, *baseline_pt - to_pt(layout.baseline()));
                    pangocairo::functions::show_layout(cr, &layout);
                }
                Item::Image { src, x_pt, y_pt, width_pt, height_pt, .. } => {
                    self.draw_image(cr, src, *x_pt, *y_pt, *width_pt, *height_pt);
                }
                Item::Chip { para, ch, x_pt, baseline_pt } => {
                    self.draw_chip(cr, *para, *ch, *x_pt, *baseline_pt);
                }
                Item::NoteRef { para, ch, x_pt, baseline_pt } => {
                    self.draw_note_ref(cr, *para, *ch, *x_pt, *baseline_pt);
                }
                Item::Line { source: Source::Footnote(n), line, box_width_pt, x_pt, baseline_pt, .. } => {
                    let p = super::note_paragraph(&self.doc, *n, &self.opts);
                    let layout = self.shaper.layout(&paragraph_request(&p, *box_width_pt, &self.opts));
                    if let Some(l) = layout.line_readonly(*line as i32) {
                        cr.move_to(*x_pt, *baseline_pt);
                        pangocairo::functions::show_layout_line(cr, &l);
                    }
                }
                Item::Rule { x_pt, y_pt, width_pt } => {
                    let _ = cr.save();
                    cr.set_line_width(0.5);
                    cr.move_to(*x_pt, *y_pt);
                    cr.line_to(*x_pt + *width_pt, *y_pt);
                    let _ = cr.stroke();
                    let _ = cr.restore();
                }
                Item::Cell { table, x_pt, y_pt, width_pt, height_pt, .. } if self.single_cell(*table) => {
                    // Un cartouche : coins arrondis ou carrés, trait fin,
                    // équilibré, épais ou aucun, fond gris clair ou blanc.
                    let look = self.cartouche(*table);
                    let (x, y, w, h) = (*x_pt, *y_pt, *width_pt, *height_pt);
                    let _ = cr.save();
                    if look.square {
                        cr.rectangle(x, y, w, h);
                    } else {
                        let r = 7.0f64.min(w / 2.0).min(h / 2.0);
                        let pi = std::f64::consts::PI;
                        cr.new_sub_path();
                        cr.arc(x + w - r, y + r, r, -pi / 2.0, 0.0);
                        cr.arc(x + w - r, y + h - r, r, 0.0, pi / 2.0);
                        cr.arc(x + r, y + h - r, r, pi / 2.0, pi);
                        cr.arc(x + r, y + r, r, pi, 3.0 * pi / 2.0);
                        cr.close_path();
                    }
                    let (fr, fg, fb) = look.fill_rgb();
                    cr.set_source_rgb(fr, fg, fb);
                    let lw = look.line_pt();
                    if lw > 0.0 {
                        let _ = cr.fill_preserve();
                        cr.set_source_rgb(0.37, 0.36, 0.39);
                        cr.set_line_width(lw);
                        let _ = cr.stroke();
                    } else {
                        let _ = cr.fill();
                    }
                    let _ = cr.restore();
                }
                Item::Cell { x_pt, y_pt, width_pt, height_pt, .. } => {
                    // A 0.5 pt rule, at least one device pixel, on whole
                    // pixels: on screen a hairline between two pixel rows
                    // was drawn as two grey rows, which blurred into the
                    // cell text. (On paper and PDF a device unit is tiny,
                    // so this changes nothing there.)
                    let (px, _) = cr.device_to_user_distance(1.0, 0.0).unwrap_or((0.5, 0.0));
                    let lw = 0.5f64.max(px.abs());
                    let snap = |x: f64, y: f64| {
                        let (dx, dy) = cr.user_to_device(x, y);
                        let (dw, _) = cr.user_to_device_distance(lw, 0.0).unwrap_or((lw, 0.0));
                        let half = (dw.round().max(1.0) % 2.0) / 2.0;
                        cr.device_to_user(dx.round() + half, dy.round() + half).unwrap_or((x, y))
                    };
                    let (x0, y0) = snap(*x_pt, *y_pt);
                    let (x1, y1) = snap(*x_pt + *width_pt, *y_pt + *height_pt);
                    let _ = cr.save();
                    cr.set_source_rgb(0.0, 0.0, 0.0);
                    cr.set_line_width(lw);
                    cr.rectangle(x0, y0, x1 - x0, y1 - y0);
                    let _ = cr.stroke();
                    let _ = cr.restore();
                }
            }
        }
        self.draw_line_numbers(cr, index);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::layout::layout;
    use crate::model::{Paragraph, Run};

    fn doc(n: usize, text: &str) -> Document {
        let mut d = Document::new();
        d.paragraphs = (0..n).map(|_| Paragraph { style: Default::default(), runs: vec![Run::plain(text)] }).collect();
        d
    }

    /// Un saut de ligne (U+2028) passe à la ligne dans le même paragraphe.
    #[test]
    fn a_line_separator_breaks_the_line() {
        let d = doc(1, "Première\u{2028}Seconde");
        let t = Typeset::new(d, LayoutOptions::default());
        assert_eq!(t.tree().pages[0].lines().count(), 2);
    }

    /// Un texte aux lignes numérotées : un numéro toutes les cinq lignes,
    /// dans la marge, et de nouveau à partir de 1 pour un second texte.
    #[test]
    fn numbered_lines_every_five_restarting_per_text() {
        let mut d = doc(14, "Une ligne courte.");
        for (i, p) in d.paragraphs.iter_mut().enumerate() {
            p.style.line_numbers = i != 7;
        }
        let t = Typeset::new(d, LayoutOptions::default());
        let n: Vec<u32> = t.line_numbers().iter().map(|m| m.3).collect();
        assert_eq!(n, vec![5, 5]);
        let left = t.tree().pages[0].geometry.margin_left_pt;
        assert!(t.line_numbers().iter().all(|m| m.1 < left));
    }

    /// A table of contents laid out: each page number ends at the right
    /// margin, a dot leader fills the gap, and the numbers are the pages
    /// the headings are really on.
    #[test]
    fn a_table_of_contents_has_page_numbers_at_the_margin() {
        let mut d = crate::toc::sample_document();
        let t = Typeset::new(d.clone(), LayoutOptions::default());
        let ops = crate::toc::update(&d, &t.paragraph_pages());
        crate::edit::apply_all(&mut d, &ops).unwrap();
        assert!(ops.is_empty(), "the sample's pages are the layout's: {:?}", d.paragraphs.iter().map(|p| p.text()).collect::<Vec<_>>());
        let t = Typeset::new(d.clone(), LayoutOptions::default());
        let page = &t.tree().pages[0];
        let right = page.width_pt - page.geometry.margin_right_pt;
        for p in 0..4 {
            let end = t.caret(TextPos { para: p, offset: t.layout_len(p) }).unwrap();
            assert!((end.x_pt - right).abs() < 1.0, "entry {p} ends at {} not {right}", end.x_pt);
        }
        // Dots drawn between title and number.
        let surface = cairo::ImageSurface::create(cairo::Format::Rgb24, page.width_pt as i32, page.height_pt as i32).unwrap();
        {
            let cr = cairo::Context::new(&surface).unwrap();
            cr.set_source_rgb(1.0, 1.0, 1.0);
            cr.paint().unwrap();
            t.draw_page(&cr, 0);
        }
        let start = t.caret(TextPos { para: 0, offset: "Introduction".len() }).unwrap();
        let data = surface.take_data().unwrap();
        let stride = page.width_pt as usize * 4;
        let dark = (start.x_pt as usize + 20..right as usize - 20)
            .filter(|&x| (start.top_pt as usize..(start.top_pt + start.height_pt) as usize).any(|y| data[y * stride + x * 4] < 128))
            .count();
        assert!(dark > 20, "a leader across the gap: {dark} dark columns");
    }

    /// Space before does not ride a page break onto the next page: past
    /// the first paragraph, Word and LibreOffice start each page at the
    /// margin (render-lab letters/toc drew a heading with 24pt before
    /// 24pt too low on page 2). The document's own first paragraph keeps
    /// its space (render-lab letters/headings), and mid-page it applies.
    #[test]
    fn space_before_is_dropped_at_the_top_of_a_page() {
        use crate::layout::Source;
        let top = LayoutOptions::default().page.margin_top_pt;
        let first_top = |t: &Typeset, page: usize, para: usize| {
            t.tree().pages[page]
                .lines()
                .filter_map(|l| match l {
                    Item::Line { source: Source::Paragraph(p), top_pt, .. } if *p == para => Some(*top_pt),
                    _ => None,
                })
                .next()
                .unwrap()
        };
        let mut d = doc(3, "body");
        for p in d.paragraphs.iter_mut() {
            p.style.space_before_pt = 24.0;
        }
        d.paragraphs[2].style.page_break_before = true;
        let t = Typeset::new(d, LayoutOptions::default());
        assert_eq!(t.tree().pages.len(), 2);
        assert!((first_top(&t, 0, 0) - (top + 24.0)).abs() < 0.01, "the document's first paragraph keeps its space");
        assert!(first_top(&t, 0, 1) - top - 24.0 > 20.0, "mid-page the space applies after two lines: {}", first_top(&t, 0, 1));
        assert!((first_top(&t, 1, 2) - top).abs() < 0.01, "after the break it starts at the margin");
    }

    /// Open threads with text are marked where their text is, with a spot
    /// in the right margin; a resolved one is not.
    #[test]
    fn comment_marks_cover_open_threads_beside_their_text() {
        let d = crate::comments::sample_document();
        let t = Typeset::new(d, LayoutOptions::default());
        let marks = t.comment_marks();
        assert_eq!(marks.iter().map(|m| (m.id, m.count)).collect::<Vec<_>>(), [(1, 2), (2, 1)], "comment 4 is resolved");
        let page = &t.tree().pages[0];
        let body_right = page.width_pt - page.geometry.margin_right_pt;
        for m in &marks {
            assert!(m.x_pt >= body_right && m.x_pt + 12.0 <= page.width_pt, "in the margin: {m:?}");
            assert!(m.rects.iter().all(|r| r.0 == 0 && r.1 + r.3 <= body_right + 0.5));
        }
        assert_eq!(marks[0].y_pt, marks[1].y_pt, "both on the first line");
        assert!(marks[1].x_pt > marks[0].x_pt, "side by side");
    }

    #[test]
    fn pango_lines_have_real_metrics_and_partition_the_text() {
        let opts = LayoutOptions::default();
        let text = "The quick brown fox jumps over the lazy dog. ".repeat(12);
        let d = doc(1, text.trim_end());
        let t = layout(&d, &opts, &mut PangoShaper::new());
        let lines: Vec<&Item> = t.pages[0].lines().collect();
        assert!(lines.len() >= 4, "a long paragraph wraps: {}", lines.len());
        let mut joined = String::new();
        for l in &lines {
            let Item::Line { text, height_pt, .. } = l else { unreachable!() };
            // Liberation Serif 12pt: about 13.8pt per line.
            assert!((12.0..16.0).contains(height_pt), "line height {height_pt}");
            joined.push_str(text);
        }
        assert_eq!(joined, text.trim_end());
    }

    #[test]
    fn the_painter_draws_ink_where_the_tree_puts_lines() {
        let opts = LayoutOptions::default();
        let typeset = Typeset::new(doc(3, "Hello, page."), opts);
        let page = &typeset.tree().pages[0];
        let (w, h) = (page.width_pt.ceil() as i32, page.height_pt.ceil() as i32);
        let surface = cairo::ImageSurface::create(cairo::Format::Rgb24, w, h).unwrap();
        {
            let cr = cairo::Context::new(&surface).unwrap();
            cr.set_source_rgb(1.0, 1.0, 1.0);
            cr.paint().unwrap();
            typeset.draw_page(&cr, 0);
        }
        surface.flush();
        let stride = surface.stride() as usize;
        let data = surface.take_data().unwrap();
        let dark = |x0: usize, y0: usize, x1: usize, y1: usize| {
            (y0..y1).any(|y| (x0..x1).any(|x| data[y * stride + x * 4] < 128))
        };
        // Ink inside the first line's box, none above the top margin.
        assert!(dark(72, 72, 160, 86), "no text drawn in the first line box");
        assert!(!dark(0, 0, w as usize, 70), "ink above the top margin");
    }

    /// Clicking a laid-out character finds it, and its caret is drawn where
    /// the click was: hit-testing and caret placement are inverse.
    #[test]
    fn hit_test_and_caret_are_inverse() {
        let text = "The quick brown fox jumps over the lazy dog. ".repeat(6);
        let mut d = doc(3, text.trim_end());
        d.paragraphs[1].style.alignment = crate::model::Alignment::Center;
        let t = Typeset::new(d, LayoutOptions::default());
        for (para, offset) in [(0, 0), (0, 10), (0, 100), (1, 57), (2, 200)] {
            let c = t.caret(TextPos { para, offset }).expect("a caret");
            let hit = t.hit_test(c.page, c.x_pt + 0.1, c.top_pt + c.height_pt / 2.0).expect("a hit");
            assert_eq!(hit, TextPos { para, offset }, "caret {c:?}");
        }
        // A click in the left margin lands at the start of that line; one
        // far below the text, on the last line.
        let first = t.caret(TextPos { para: 0, offset: 0 }).unwrap();
        assert_eq!(t.hit_test(0, 10.0, first.top_pt + 2.0), Some(TextPos { para: 0, offset: 0 }));
        let below = t.hit_test(0, 1000.0, 800.0).unwrap();
        assert_eq!(below.para, 2);
        // The caret at the end of a paragraph is after its last char.
        let len = t.layout_len(2);
        let end = t.caret(TextPos { para: 2, offset: len }).unwrap();
        let before = t.caret(TextPos { para: 2, offset: len - 1 }).unwrap();
        assert!(end.x_pt > before.x_pt);
    }

    #[test]
    fn a_selection_covers_whole_lines_between_its_ends() {
        let text = "The quick brown fox jumps over the lazy dog. ".repeat(6);
        let t = Typeset::new(doc(2, text.trim_end()), LayoutOptions::default());
        let rects = t.selection_rects(TextPos { para: 0, offset: 4 }, TextPos { para: 1, offset: 9 });
        let lines0 = t.tree().pages[0].lines().filter(|i| matches!(i, Item::Line { source: Source::Paragraph(0), .. })).count();
        assert_eq!(rects.len(), lines0 + 1, "every line of the first paragraph, and one of the second");
        assert!(rects[0].1 > 72.0, "starts after 'The '");
        assert!(rects.iter().all(|r| r.3 > 0.0));
        // Reversed ends select the same text.
        assert_eq!(rects, t.selection_rects(TextPos { para: 1, offset: 9 }, TextPos { para: 0, offset: 4 }));
    }

    /// A paragraph's trailing space hangs past the margin: a last line
    /// that fits without it is not wrapped a word early (render-lab
    /// letters/indents).
    #[test]
    fn a_trailing_space_does_not_wrap_the_last_line() {
        let opts = LayoutOptions::default();
        let line = "lazy dog. Pack my box with five dozen liquor jugs. How vexingly quick daft zebras jump.";
        let mut shaper = PangoShaper::new();
        let runs = [crate::model::Run::plain(line)];
        fn req<'a>(runs: &'a [crate::model::Run], w: f64, opts: &'a LayoutOptions) -> ShapeRequest<'a> {
            ShapeRequest {
                runs,
                heading: None,
                code: false,
                look: Look::Body,
                alignment: Alignment::Left,
                width_pt: w,
                first_line_indent_pt: 0.0,
                tab_stops_pt: Vec::new(),
                right_tab: false,
                defaults: opts,
            }
        }
        let width = shaper.shape(&req(&runs, 1000.0, &opts))[0].width_pt;
        let spaced = [crate::model::Run::plain(format!("{line} "))];
        let lines = shaper.shape(&req(&spaced, width + 0.05, &opts));
        assert_eq!(lines.len(), 1, "the trailing space wrapped the line");
        assert!(lines[0].natural_height() > 10.0);
        // A paragraph of spaces only keeps its line height.
        let blank = [crate::model::Run::plain("   ")];
        assert!(shaper.shape(&req(&blank, 100.0, &opts))[0].natural_height() > 10.0);
    }

    /// Updating after an edit re-shapes the edited paragraph only, and
    /// draws and hit-tests the same as a fresh layout.
    #[test]
    fn update_reshapes_only_what_changed() {
        let text = "The quick brown fox jumps over the lazy dog. ".repeat(4);
        let mut d = doc(50, text.trim_end());
        let mut t = Typeset::new(d.clone(), LayoutOptions::default());
        let op = crate::edit::typing(&d, crate::edit::paragraph_start(&d, 20) + 3, "abc").unwrap();
        crate::edit::apply(&mut d, &op).unwrap();
        assert_eq!(t.update(d.clone(), LayoutOptions::default()), 1);
        let fresh = Typeset::new(d, LayoutOptions::default());
        assert_eq!(t.tree(), fresh.tree());
        let pos = TextPos { para: 20, offset: 5 };
        assert_eq!(t.caret(pos), fresh.caret(pos));
    }

    /// The PDF is the laid-out pages: as many PDF pages as the tree has,
    /// each at the page's size in points. (The render lab rasterises this
    /// same PDF and compares it with the on-screen page view pixel by
    /// pixel: `print_agreement`.)
    #[test]
    fn the_pdf_has_the_trees_pages_at_their_size() {
        let geometry = crate::model::PageGeometry { width_pt: 612.0, height_pt: 792.0, ..Default::default() };
        let mut d = doc(120, "One line of body text.");
        d.page = Some(geometry);
        let typeset = Typeset::new(d, LayoutOptions::default());
        let pages = typeset.tree().pages.len();
        assert!(pages >= 3, "120 lines take several pages: {pages}");
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("out.pdf");
        typeset.write_pdf(&path).expect("write pdf");
        let bytes = std::fs::read(&path).unwrap();
        let text = String::from_utf8_lossy(&bytes);
        let page_objects = text.matches("/Type /Page").count() - text.matches("/Type /Pages").count();
        assert_eq!(page_objects, pages, "one PDF page per laid-out page");
        assert!(text.contains("/MediaBox [ 0 0 612 792 ]"), "pages keep their size in points");
    }
}
