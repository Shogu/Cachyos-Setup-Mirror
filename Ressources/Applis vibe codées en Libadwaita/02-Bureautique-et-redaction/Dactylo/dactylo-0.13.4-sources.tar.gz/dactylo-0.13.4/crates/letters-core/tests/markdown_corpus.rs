// CommonMark corpus harness — round-trip idempotence ratchet.
//
// For every example in the vendored CommonMark spec (652 inputs), we check
// parse(md) == parse(serialize(parse(md))). This is not HTML conformance
// (we are a document model, not an HTML renderer); it measures that our
// Markdown reader/writer pair is *stable* on the full grammar the spec
// exercises. The pass count may never drop below the recorded baseline —
// raising it is progress you can see in CI output.

use letters_core::markdown;

#[derive(serde::Deserialize)]
struct Example {
    markdown: String,
    section: String,
    example: u32,
}

fn corpus() -> Vec<Example> {
    let raw = include_str!("corpus/commonmark-spec.json");
    serde_json::from_str(raw).expect("corpus JSON")
}

fn baseline() -> usize {
    include_str!("corpus/roundtrip-baseline.txt").trim().parse().expect("baseline int")
}

#[test]
fn commonmark_roundtrip_ratchet() {
    let examples = corpus();
    let total = examples.len();
    let mut passed = 0usize;
    let mut per_section: std::collections::BTreeMap<String, (usize, usize)> = Default::default();
    let mut failures: Vec<u32> = Vec::new();

    for ex in &examples {
        let doc1 = markdown::parse(&ex.markdown);
        let md2 = markdown::serialize(&doc1);
        let doc2 = markdown::parse(&md2);
        let ok = doc1 == doc2;
        let entry = per_section.entry(ex.section.clone()).or_default();
        entry.1 += 1;
        if ok {
            entry.0 += 1;
            passed += 1;
        } else {
            failures.push(ex.example);
        }
    }

    println!("\nCommonMark round-trip idempotence: {passed}/{total}");
    for (section, (ok, n)) in &per_section {
        println!("  {section:<28} {ok:>3}/{n:<3}");
    }

    let base = baseline();
    assert!(
        passed >= base,
        "REGRESSION: round-trip passes dropped to {passed}, baseline is {base}. \
         First failing examples: {:?}",
        &failures[..failures.len().min(10)]
    );
    if passed > base {
        println!(
            "IMPROVEMENT: {passed} > baseline {base} — bump tests/corpus/roundtrip-baseline.txt"
        );
    }
}

/// The two whole documents in `tests/fixtures/` (a letter and a rich
/// technical document; see `tests/fixtures/fixtures.json`) round-trip
/// idempotently, as each CommonMark example must. Unlike the spec's
/// examples, these mix every block kind in one file, so a construct that
/// survives alone but disturbs its neighbours shows up here.
#[test]
fn whole_markdown_fixtures_round_trip() {
    let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../tests/fixtures");
    for name in ["example_letter.md", "rich_document.md"] {
        let path = dir.join(name);
        let md = std::fs::read_to_string(&path).unwrap_or_else(|e| panic!("{}: {e}", path.display()));
        let doc1 = markdown::parse(&md);
        assert!(doc1.paragraphs.len() > 5, "{name} parsed to almost nothing");
        let doc2 = markdown::parse(&markdown::serialize(&doc1));
        assert_eq!(doc1, doc2, "{name} does not round-trip idempotently");
    }
}

/// The corpus size the docs quote next to the baseline (README.md,
/// ROADMAP.md), recorded so `tests/test_roadmap_figures.py` can check those
/// figures without running this corpus. Adding or removing a case means
/// updating `tests/corpus/roundtrip-total.txt` as well as the baseline.
#[test]
fn the_recorded_total_is_the_corpus_size() {
    let recorded: usize = include_str!("corpus/roundtrip-total.txt").trim().parse().expect("total int");
    assert_eq!(corpus().len(), recorded, "the CommonMark spec examples changed size: update tests/corpus/roundtrip-total.txt");
}
