// docx_alt.rs — ce que Word range « à côté » du texte : variantes
// mc:AlternateContent et zones de texte.
//
// 1. Word (et d'autres) enveloppent souvent une image dans
//    <mc:AlternateContent> : une variante moderne (<mc:Choice>, un
//    <w:drawing>) et une variante ancienne (<mc:Fallback>, du VML). Le lecteur
//    DOCX ne lit pas cette enveloppe : l'image disparaissait. On la remplace
//    par sa variante moderne quand celle-ci porte un <w:drawing>.
// 2. Le texte d'une zone de texte (<w:txbxContent>) est rangé dans une forme
//    dessinée, hors du fil du document : il était invisible, puis perdu à
//    l'enregistrement. Chaque zone de texte devient un cartouche de Dactylo
//    (un tableau d'une case), placé juste après le paragraphe qui l'ancre,
//    avec son texte et la mise en forme de ses caractères. La position
//    flottante sur la page est perdue ; ses paragraphes sont réunis en un
//    seul, séparés par des retours à la ligne (un cartouche tient en un
//    paragraphe).
// SPDX-License-Identifier: GPL-3.0-or-later

/// Début de la prochaine balise ouvrante `<name` (suivie de `>`, `/` ou
/// d'une espace) à partir de `from`.
fn find_open(xml: &str, name: &str, from: usize) -> Option<usize> {
    let pat = format!("<{name}");
    let mut at = from;
    while let Some(i) = xml.get(at..)?.find(&pat) {
        let i = at + i;
        match xml.as_bytes().get(i + pat.len()) {
            Some(b'>' | b' ' | b'/' | b'\n' | b'\t' | b'\r') => return Some(i),
            _ => at = i + pat.len(),
        }
    }
    None
}

/// La fin (après `</name>`) de l'élément qui commence en `start`, en tenant
/// compte des éléments de même nom imbriqués.
fn matching_close(xml: &str, name: &str, start: usize) -> Option<usize> {
    let open_end = start + xml[start..].find('>')? + 1;
    if xml.as_bytes()[open_end - 2] == b'/' {
        return Some(open_end);
    }
    let close = format!("</{name}>");
    let mut depth = 1usize;
    let mut at = open_end;
    loop {
        let next_close = at + xml[at..].find(&close)?;
        match find_open(xml, name, at).filter(|&o| o < next_close) {
            Some(o) => {
                let oe = o + xml[o..].find('>')? + 1;
                if xml.as_bytes()[oe - 2] != b'/' {
                    depth += 1;
                }
                at = oe;
            }
            None => {
                depth -= 1;
                at = next_close + close.len();
                if depth == 0 {
                    return Some(at);
                }
            }
        }
    }
}

/// Le contenu (entre les balises) de l'élément `[start, end)`.
fn inner<'a>(xml: &'a str, name: &str, start: usize, end: usize) -> &'a str {
    let open_end = start + xml[start..end].find('>').map_or(0, |i| i + 1);
    let close = format!("</{name}>");
    if xml[start..end].ends_with(&close) && open_end <= end - close.len() {
        &xml[open_end..end - close.len()]
    } else {
        ""
    }
}

/// Le premier élément `name` dans `xml` : (début, fin).
fn first(xml: &str, name: &str) -> Option<(usize, usize)> {
    let s = find_open(xml, name, 0)?;
    Some((s, matching_close(xml, name, s)?))
}

/// Les paragraphes d'une zone de texte réunis en un seul (sauts de ligne),
/// avec la mise en forme de paragraphe du premier. `None` sans texte.
fn box_paragraph(content: &str) -> Option<String> {
    if !content.contains("<w:t") {
        return None;
    }
    let mut ppr = String::new();
    let mut runs: Vec<String> = Vec::new();
    let mut at = 0usize;
    while let Some(s) = find_open(content, "w:p", at) {
        let Some(e) = matching_close(content, "w:p", s) else { break };
        let mut body = inner(content, "w:p", s, e).to_string();
        if let Some((ps, pe)) = first(&body, "w:pPr") {
            if runs.is_empty() {
                ppr = body[ps..pe].to_string();
            }
            body.replace_range(ps..pe, "");
        }
        runs.push(body);
        at = e;
    }
    if runs.is_empty() {
        return None;
    }
    Some(format!("<w:p>{ppr}{}</w:p>", runs.join("<w:r><w:br/></w:r>")))
}

/// Un cartouche de Dactylo (tableau d'une case) qui porte `paragraph`.
fn cartouche(paragraph: &str) -> String {
    format!(
        "<w:tbl><w:tblPr><w:tblStyle w:val=\"Cartouche_carre_fin_blanc\"/><w:tblW w:w=\"9360\" w:type=\"dxa\"/>\
         <w:tblBorders><w:top w:val=\"single\" w:sz=\"6\" w:space=\"0\" w:color=\"5E5C64\"/><w:left w:val=\"single\" w:sz=\"6\" w:space=\"0\" w:color=\"5E5C64\"/>\
         <w:bottom w:val=\"single\" w:sz=\"6\" w:space=\"0\" w:color=\"5E5C64\"/><w:right w:val=\"single\" w:sz=\"6\" w:space=\"0\" w:color=\"5E5C64\"/>\
         <w:insideH w:val=\"single\" w:sz=\"6\" w:space=\"0\" w:color=\"5E5C64\"/><w:insideV w:val=\"single\" w:sz=\"6\" w:space=\"0\" w:color=\"5E5C64\"/></w:tblBorders>\
         <w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"FFFFFF\"/><w:tblCellMar><w:top w:w=\"140\" w:type=\"dxa\"/><w:left w:w=\"108\" w:type=\"dxa\"/>\
         <w:bottom w:w=\"140\" w:type=\"dxa\"/><w:right w:w=\"108\" w:type=\"dxa\"/></w:tblCellMar></w:tblPr>\
         <w:tblGrid><w:gridCol w:w=\"9360\"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"FFFFFF\"/></w:tcPr>{paragraph}</w:tc></w:tr></w:tbl>"
    )
}

/// Le document sans enveloppes ni zones de texte, ou `None` s'il n'y avait
/// rien à changer.
pub fn unwrap(xml: &str) -> Option<String> {
    if !xml.contains("<mc:AlternateContent") && !xml.contains("<w:txbxContent") {
        return None;
    }
    let mut out = xml.to_string();
    // Les zones de texte trouvées, et l'endroit (dans `out`) après lequel les
    // placer : on les insère à la fin, de la dernière à la première.
    let mut boxes: Vec<(usize, String)> = Vec::new();
    let mut at = 0usize;
    loop {
        // Le prochain élément à traiter : une enveloppe, ou une image/forme
        // nue qui porte une zone de texte.
        let candidates = [
            ("mc:AlternateContent", find_open(&out, "mc:AlternateContent", at)),
            ("w:drawing", find_open(&out, "w:drawing", at)),
            ("w:pict", find_open(&out, "w:pict", at)),
        ];
        let Some((name, start)) = candidates.iter().filter_map(|(n, s)| s.map(|s| (*n, s))).min_by_key(|(_, s)| *s) else {
            break;
        };
        let Some(end) = matching_close(&out, name, start) else { break };
        let block = out[start..end].to_string();
        // Le contenu à garder à cet endroit, et la zone de texte éventuelle.
        let keep: Option<String> = if name == "mc:AlternateContent" {
            let choice = first(&block, "mc:Choice").map(|(s, e)| inner(&block, "mc:Choice", s, e).to_string()).unwrap_or_default();
            if let Some((s, e)) = first(&choice, "w:txbxContent") {
                // La variante moderne porte la zone de texte : l'enveloppe
                // entière s'en va, le texte devient un cartouche.
                if let Some(p) = box_paragraph(inner(&choice, "w:txbxContent", s, e)) {
                    boxes.push((start, cartouche(&p)));
                }
                Some(String::new())
            } else if choice.contains("<w:drawing") {
                Some(choice)
            } else {
                None
            }
        } else if let Some((s, e)) = first(&block, "w:txbxContent") {
            if let Some(p) = box_paragraph(inner(&block, "w:txbxContent", s, e)) {
                boxes.push((start, cartouche(&p)));
            }
            Some(String::new())
        } else {
            None
        };
        match keep {
            Some(k) => {
                out.replace_range(start..end, &k);
                // Les zones déjà relevées plus loin n'existent pas encore :
                // seules les positions avant `start` comptent.
                at = start;
                if name == "mc:AlternateContent" && !k.is_empty() {
                    // Le <w:drawing> remis à plat ne porte pas de zone de
                    // texte : on peut le sauter.
                    at = start + k.len();
                }
            }
            None => at = end,
        }
    }
    // Chaque cartouche va après la fin du paragraphe qui ancrait sa zone.
    for (pos, table) in boxes.into_iter().rev() {
        let Some(rel) = out[pos..].find("</w:p>") else { continue };
        let close = pos + rel + "</w:p>".len();
        // Dans une case de tableau, une case doit finir par un paragraphe.
        let table = if out[close..].trim_start().starts_with("</w:tc>") { format!("{table}<w:p/>") } else { table };
        out.insert_str(close, &table);
    }
    (out != xml).then_some(out)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn picture_in_alternate_content_is_unwrapped() {
        let xml = r#"<w:body><w:p><w:r><mc:AlternateContent><mc:Choice Requires="wpg"><w:drawing><wp:inline><a:blip r:embed="rId8"/></wp:inline></w:drawing></mc:Choice><mc:Fallback><w:pict><v:shape><v:imagedata r:id="rId8"/></v:shape></w:pict></mc:Fallback></mc:AlternateContent></w:r></w:p></w:body>"#;
        let out = unwrap(xml).unwrap();
        assert_eq!(out, r#"<w:body><w:p><w:r><w:drawing><wp:inline><a:blip r:embed="rId8"/></wp:inline></w:drawing></w:r></w:p></w:body>"#);
    }

    #[test]
    fn text_box_becomes_a_cartouche_after_its_paragraph() {
        let xml = r#"<w:body><w:p><w:r><w:t>Avant</w:t></w:r><w:r><mc:AlternateContent><mc:Choice Requires="wps"><w:drawing><wp:anchor><wps:txbx><w:txbxContent><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>Titre</w:t></w:r></w:p><w:p><w:r><w:t>Seconde ligne</w:t></w:r></w:p></w:txbxContent></wps:txbx></wp:anchor></w:drawing></mc:Choice><mc:Fallback><w:pict><v:textbox><w:txbxContent><w:p><w:r><w:t>Titre</w:t></w:r></w:p></w:txbxContent></v:textbox></w:pict></mc:Fallback></mc:AlternateContent></w:r></w:p><w:p><w:r><w:t>Après</w:t></w:r></w:p></w:body>"#;
        let out = unwrap(xml).unwrap();
        assert!(!out.contains("AlternateContent") && !out.contains("txbxContent"), "{out}");
        let table = out.find("<w:tbl>").unwrap();
        assert!(out.find("Avant").unwrap() < table && table < out.find("Après").unwrap());
        assert!(out.contains("<w:jc w:val=\"center\"/></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>Titre</w:t></w:r><w:r><w:br/></w:r><w:r><w:t>Seconde ligne"), "{out}");
        assert_eq!(out.matches("Titre").count(), 1);
    }

    #[test]
    fn plain_documents_are_left_alone() {
        assert!(unwrap("<w:body><w:p><w:r><w:t>Rien</w:t></w:r></w:p></w:body>").is_none());
    }
}
