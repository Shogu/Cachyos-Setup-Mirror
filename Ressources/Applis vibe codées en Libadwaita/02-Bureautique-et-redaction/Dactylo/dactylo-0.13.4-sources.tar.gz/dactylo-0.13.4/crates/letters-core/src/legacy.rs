// legacy.rs — les anciens formats de traitement de texte : .rtf et .doc.
//
// Si AbiWord est installé, il convertit le fichier en ODT (mise en forme bien
// plus complète). Sinon, ils sont lus par Dactylo lui-même :
// - RTF : un format texte. On en garde les paragraphes, le gras, l'italique,
//   le souligné, le barré, la taille, la couleur, l'alignement et les puces.
//   Les tableaux deviennent des lignes (cases séparées par des tabulations) ;
//   les images, en-têtes et pieds de page sont laissés de côté.
// - DOC (Word 97-2003) : un format binaire très complexe. On n'en récupère
//   que le texte, paragraphe par paragraphe, sans mise en forme.
//
// Le texte lu est écrit dans un petit DOCX temporaire, que le lecteur DOCX
// ordinaire ouvre ensuite. Le fichier d'origine n'est jamais modifié.
// SPDX-License-Identifier: GPL-3.0-or-later

use std::io::{Read, Write};
use std::path::Path;

/// Extensions lues par ce module.
pub const CONVERTED: [&str; 3] = ["doc", "dot", "rtf"];

/// L'extension est-elle un ancien format lu ici ?
pub fn needs_conversion(path: &Path) -> bool {
    ext(path).is_some_and(|e| CONVERTED.contains(&e.as_str()))
}

fn ext(path: &Path) -> Option<String> {
    path.extension().map(|e| e.to_string_lossy().to_ascii_lowercase())
}

fn temp_name(prefix: &str) -> std::path::PathBuf {
    static N: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
    let n = N.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
    std::env::temp_dir().join(format!("{prefix}-{}-{n}", std::process::id()))
}

/// Lit un .rtf ou un .doc : par AbiWord s'il est installé, sinon par les
/// lecteurs intégrés ci-dessous.
pub fn read(path: &Path) -> Result<crate::Document, String> {
    if let Some(doc) = via_abiword(path) {
        return Ok(doc);
    }
    let bytes = std::fs::read(path).map_err(|e| format!("Lecture impossible : {e}"))?;
    // Un « .doc » est parfois un RTF renommé (vieux réflexe de Word).
    let paragraphs = if bytes.starts_with(b"{\\rtf") {
        rtf::parse(&bytes)
    } else if ext(path).as_deref() == Some("rtf") {
        return Err("Ce fichier .rtf n'est pas un RTF valide.".into());
    } else {
        doc::text(&bytes)?
    };
    read_paragraphs(&paragraphs)
}

/// AbiWord, s'il est dans le PATH.
fn abiword() -> Option<std::path::PathBuf> {
    std::env::split_paths(&std::env::var_os("PATH")?).map(|d| d.join("abiword")).find(|p| p.is_file())
}

/// Conversion en ODT par AbiWord, sans fenêtre, dans un dossier temporaire.
/// `None` si AbiWord est absent ou si la conversion échoue : on retombe
/// alors sur les lecteurs intégrés.
fn via_abiword(path: &Path) -> Option<crate::Document> {
    let abiword = abiword()?;
    let dir = temp_name("dactylo-abiword");
    std::fs::create_dir_all(&dir).ok()?;
    let out = dir.join("converti.odt");
    let ok = std::process::Command::new(abiword)
        .arg("--to=odt")
        .arg(format!("--to-name={}", out.display()))
        .arg(path)
        .stdout(std::process::Stdio::null())
        .stderr(std::process::Stdio::null())
        .status()
        .is_ok_and(|s| s.success());
    let doc = (ok && out.is_file()).then(|| crate::odt::read(&out.to_string_lossy()).ok()).flatten();
    let _ = std::fs::remove_dir_all(&dir);
    doc
}

/// Un morceau de texte et sa mise en forme.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct Run {
    pub text: String,
    pub bold: bool,
    pub italic: bool,
    pub underline: bool,
    pub strike: bool,
    /// Taille en demi-points (24 = 12 pt).
    pub half_points: Option<u32>,
    /// Couleur RRGGBB.
    pub color: Option<String>,
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Para {
    /// "center", "right", "both" ; `None` : à gauche.
    pub align: Option<&'static str>,
    pub runs: Vec<Run>,
}

fn esc(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;")
}

fn document_xml(paras: &[Para]) -> String {
    let mut body = String::new();
    for p in paras {
        body.push_str("<w:p>");
        if let Some(a) = p.align {
            body.push_str(&format!("<w:pPr><w:jc w:val=\"{a}\"/></w:pPr>"));
        }
        for r in &p.runs {
            let mut rpr = String::new();
            if r.bold {
                rpr.push_str("<w:b/>");
            }
            if r.italic {
                rpr.push_str("<w:i/>");
            }
            if r.strike {
                rpr.push_str("<w:strike/>");
            }
            if let Some(c) = &r.color {
                rpr.push_str(&format!("<w:color w:val=\"{c}\"/>"));
            }
            if let Some(s) = r.half_points {
                rpr.push_str(&format!("<w:sz w:val=\"{s}\"/>"));
            }
            if r.underline {
                rpr.push_str("<w:u w:val=\"single\"/>");
            }
            // Tabulations et sauts de ligne : des éléments à part.
            for (n, line) in r.text.split('\n').enumerate() {
                if n > 0 {
                    body.push_str(&format!("<w:r><w:rPr>{rpr}</w:rPr><w:br/></w:r>"));
                }
                for (i, piece) in line.split('\t').enumerate() {
                    if i > 0 {
                        body.push_str(&format!("<w:r><w:rPr>{rpr}</w:rPr><w:tab/></w:r>"));
                    }
                    if !piece.is_empty() {
                        body.push_str(&format!("<w:r><w:rPr>{rpr}</w:rPr><w:t xml:space=\"preserve\">{}</w:t></w:r>", esc(piece)));
                    }
                }
            }
        }
        body.push_str("</w:p>");
    }
    format!(
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\
         <w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>{body}\
         <w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1417\" w:right=\"1417\" w:bottom=\"1417\" w:left=\"1417\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/></w:sectPr>\
         </w:body></w:document>"
    )
}

/// Écrit les paragraphes dans un DOCX temporaire et le lit.
fn read_paragraphs(paras: &[Para]) -> Result<crate::Document, String> {
    let mut buf = std::io::Cursor::new(Vec::new());
    {
        let mut z = zip::ZipWriter::new(&mut buf);
        let o: zip::write::SimpleFileOptions = Default::default();
        let parts = [
            ("[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>".to_string()),
            ("_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>".to_string()),
            ("word/document.xml", document_xml(paras)),
        ];
        for (name, data) in parts {
            z.start_file(name, o).map_err(|e| e.to_string())?;
            z.write_all(data.as_bytes()).map_err(|e| e.to_string())?;
        }
        z.finish().map_err(|e| e.to_string())?;
    }
    let tmp = temp_name("dactylo-ancien").with_extension("docx");
    std::fs::write(&tmp, buf.into_inner()).map_err(|e| e.to_string())?;
    let read = crate::docx::read(&tmp.to_string_lossy());
    let _ = std::fs::remove_file(&tmp);
    read
}

// ── RTF ──────────────────────────────────────────────────────────────────

mod rtf {
    use super::{Para, Run};

    #[derive(Clone, Default)]
    struct State {
        bold: bool,
        italic: bool,
        underline: bool,
        strike: bool,
        half_points: Option<u32>,
        color: Option<usize>,
        /// Groupe à ignorer (table des polices, images, en-têtes…).
        skip: bool,
        /// Nombre de caractères de repli à sauter après un \uN.
        uc: usize,
    }

    /// Destinations dont le contenu n'est pas du texte du document.
    const SKIPPED: [&str; 24] = [
        "fonttbl", "stylesheet", "info", "pict", "object", "header", "headerl", "headerr", "headerf", "footer",
        "footerl", "footerr", "footerf", "fldinst", "listtable", "listoverridetable", "rsidtbl", "generator",
        "themedata", "colorschememapping", "datastore", "latentstyles", "xmlnstbl", "footnote",
    ];

    /// Ajoute du texte au paragraphe courant, avec la mise en forme courante.
    fn push(cur: &mut Para, st: &State, colors: &[Option<String>], text: &str) {
        if text.is_empty() {
            return;
        }
        let run = Run {
            text: String::new(),
            bold: st.bold,
            italic: st.italic,
            underline: st.underline,
            strike: st.strike,
            half_points: st.half_points,
            color: st.color.and_then(|c| colors.get(c).cloned().flatten()),
        };
        match cur.runs.last_mut() {
            Some(last) if Run { text: String::new(), ..last.clone() } == run => last.text.push_str(text),
            _ => cur.runs.push(Run { text: text.to_string(), ..run }),
        }
    }

    pub fn parse(bytes: &[u8]) -> Vec<Para> {
        let enc = encoding_rs::WINDOWS_1252;
        let mut paras: Vec<Para> = Vec::new();
        let mut cur = Para::default();
        let mut align: Option<&'static str> = None;
        let mut colors: Vec<Option<String>> = Vec::new();
        let mut in_colortbl = false;
        let mut color_acc = (0u8, 0u8, 0u8, false);
        let mut stack: Vec<State> = Vec::new();
        let mut st = State { uc: 1, ..Default::default() };
        let mut pending_skip = 0usize;
        let mut hex: Vec<u8> = Vec::new();
        let mut first_in_group = false;
        let mut i = 0usize;

        while i < bytes.len() {
            let c = bytes[i];
            // Les octets \'hh se décodent ensemble (texte multioctet).
            if !(c == b'\\' && bytes.get(i + 1) == Some(&b'\'')) && !hex.is_empty() {
                let (s, _, _) = enc.decode(&hex);
                if !st.skip {
                    push(&mut cur, &st, &colors, &s);
                }
                hex.clear();
            }
            match c {
                b'{' => {
                    stack.push(st.clone());
                    first_in_group = true;
                    i += 1;
                }
                b'}' => {
                    in_colortbl = false;
                    if let Some(prev) = stack.pop() {
                        st = prev;
                    }
                    i += 1;
                }
                b'\\' => {
                    let next = *bytes.get(i + 1).unwrap_or(&b' ');
                    if next == b'\'' {
                        let h = std::str::from_utf8(bytes.get(i + 2..i + 4).unwrap_or(b"3f")).unwrap_or("3f");
                        let v = u8::from_str_radix(h, 16).unwrap_or(b'?');
                        i += 4;
                        if pending_skip > 0 {
                            pending_skip -= 1;
                        } else if !st.skip {
                            hex.push(v);
                        }
                        first_in_group = false;
                        continue;
                    }
                    if !next.is_ascii_alphabetic() {
                        // Symbole de contrôle.
                        i += 2;
                        let sym = match next {
                            b'\\' => "\\",
                            b'{' => "{",
                            b'}' => "}",
                            b'~' => "\u{a0}",
                            b'_' => "\u{2011}",
                            b'*' => {
                                st.skip = true;
                                ""
                            }
                            _ => "",
                        };
                        if !st.skip {
                            push(&mut cur, &st, &colors, sym);
                        }
                        first_in_group = false;
                        continue;
                    }
                    // Mot de contrôle et paramètre éventuel.
                    let mut j = i + 1;
                    while j < bytes.len() && bytes[j].is_ascii_alphabetic() {
                        j += 1;
                    }
                    let word = std::str::from_utf8(&bytes[i + 1..j]).unwrap_or("");
                    let mut k = j;
                    if k < bytes.len() && (bytes[k] == b'-' || bytes[k].is_ascii_digit()) {
                        k += 1;
                        while k < bytes.len() && bytes[k].is_ascii_digit() {
                            k += 1;
                        }
                    }
                    let param: Option<i32> = std::str::from_utf8(&bytes[j..k]).ok().and_then(|s| s.parse().ok());
                    if k < bytes.len() && bytes[k] == b' ' {
                        k += 1;
                    }
                    i = k;
                    let was_first = first_in_group;
                    first_in_group = false;
                    // Le numéro ou la puce d'une liste, écrit dans une police
                    // de symboles : on le remplace par une vraie puce.
                    if was_first && (word == "listtext" || word == "pntext") {
                        if !st.skip {
                            push(&mut cur, &st, &colors, "•\u{a0}");
                        }
                        st.skip = true;
                        continue;
                    }
                    if was_first && SKIPPED.contains(&word) {
                        st.skip = true;
                        continue;
                    }
                    if word == "colortbl" {
                        in_colortbl = true;
                        colors.clear();
                        color_acc = (0, 0, 0, false);
                        continue;
                    }
                    if in_colortbl {
                        let v = param.unwrap_or(0).clamp(0, 255) as u8;
                        match word {
                            "red" => color_acc = (v, color_acc.1, color_acc.2, true),
                            "green" => color_acc = (color_acc.0, v, color_acc.2, true),
                            "blue" => color_acc = (color_acc.0, color_acc.1, v, true),
                            _ => {}
                        }
                        continue;
                    }
                    if st.skip {
                        continue;
                    }
                    let on = param != Some(0);
                    match word {
                        "par" | "sect" | "row" | "page" => {
                            cur.align = align;
                            paras.push(std::mem::take(&mut cur));
                        }
                        "pard" | "ql" => align = None,
                        "qc" => align = Some("center"),
                        "qr" => align = Some("right"),
                        "qj" => align = Some("both"),
                        "line" => push(&mut cur, &st, &colors, "\n"),
                        "tab" | "cell" => push(&mut cur, &st, &colors, "\t"),
                        "plain" => {
                            st.bold = false;
                            st.italic = false;
                            st.underline = false;
                            st.strike = false;
                            st.half_points = None;
                            st.color = None;
                        }
                        "b" => st.bold = on,
                        "i" => st.italic = on,
                        "ul" => st.underline = on,
                        "uld" | "uldb" | "ulw" => st.underline = true,
                        "ulnone" => st.underline = false,
                        "strike" => st.strike = on,
                        "fs" => st.half_points = param.filter(|p| *p > 0).map(|p| p as u32),
                        "cf" => st.color = param.map(|p| p as usize).filter(|p| *p > 0),
                        "uc" => st.uc = param.unwrap_or(1).max(0) as usize,
                        "u" => {
                            let mut n = param.unwrap_or(0);
                            if n < 0 {
                                n += 65536;
                            }
                            if let Some(ch) = char::from_u32(n as u32) {
                                push(&mut cur, &st, &colors, &ch.to_string());
                            }
                            pending_skip = st.uc;
                        }
                        "emdash" => push(&mut cur, &st, &colors, "—"),
                        "endash" => push(&mut cur, &st, &colors, "–"),
                        "bullet" => push(&mut cur, &st, &colors, "•"),
                        "lquote" => push(&mut cur, &st, &colors, "‘"),
                        "rquote" => push(&mut cur, &st, &colors, "’"),
                        "ldblquote" => push(&mut cur, &st, &colors, "“"),
                        "rdblquote" => push(&mut cur, &st, &colors, "”"),
                        _ => {}
                    }
                }
                b'\r' | b'\n' => i += 1,
                b';' if in_colortbl => {
                    colors.push(color_acc.3.then(|| format!("{:02X}{:02X}{:02X}", color_acc.0, color_acc.1, color_acc.2)));
                    color_acc = (0, 0, 0, false);
                    i += 1;
                }
                _ => {
                    // Texte ordinaire, jusqu'au prochain caractère spécial.
                    let mut j = i;
                    while j < bytes.len() && !matches!(bytes[j], b'{' | b'}' | b'\\' | b'\r' | b'\n') {
                        j += 1;
                    }
                    let mut chunk = &bytes[i..j];
                    while pending_skip > 0 && !chunk.is_empty() {
                        chunk = &chunk[1..];
                        pending_skip -= 1;
                    }
                    if !st.skip && !in_colortbl {
                        let (s, _, _) = enc.decode(chunk);
                        push(&mut cur, &st, &colors, &s);
                    }
                    first_in_group = false;
                    i = j;
                }
            }
        }
        if !hex.is_empty() {
            let (s, _, _) = enc.decode(&hex);
            push(&mut cur, &st, &colors, &s);
        }
        if !cur.runs.is_empty() {
            cur.align = align;
            paras.push(cur);
        }
        paras
    }
}

// ── DOC (Word 97-2003) : le texte seul ───────────────────────────────────

mod doc {
    use super::{Para, Read, Run};

    fn u16_at(b: &[u8], o: usize) -> Option<u16> {
        Some(u16::from_le_bytes(b.get(o..o + 2)?.try_into().ok()?))
    }
    fn u32_at(b: &[u8], o: usize) -> Option<u32> {
        Some(u32::from_le_bytes(b.get(o..o + 4)?.try_into().ok()?))
    }

    fn stream(file: &mut cfb::CompoundFile<std::io::Cursor<&[u8]>>, name: &str) -> Option<Vec<u8>> {
        let mut s = file.open_stream(name).ok()?;
        let mut v = Vec::new();
        s.read_to_end(&mut v).ok()?;
        Some(v)
    }

    pub fn text(bytes: &[u8]) -> Result<Vec<Para>, String> {
        let bad = || "Ce fichier .doc est illisible (format Word 97-2003 attendu).".to_string();
        let mut file = cfb::CompoundFile::open(std::io::Cursor::new(bytes)).map_err(|_| bad())?;
        let word = stream(&mut file, "WordDocument").ok_or_else(bad)?;
        if u16_at(&word, 0) != Some(0xA5EC) {
            return Err(bad());
        }
        let flags = u16_at(&word, 0x0A).ok_or_else(bad)?;
        if flags & 0x0100 != 0 {
            return Err("Ce fichier .doc est protégé par un mot de passe.".into());
        }
        let table_name = if flags & 0x0200 != 0 { "1Table" } else { "0Table" };
        let table = stream(&mut file, table_name).ok_or_else(bad)?;
        // Nombre de caractères du corps du texte (hors notes, en-têtes…).
        let ccp_text = u32_at(&word, 0x4C).ok_or_else(bad)? as usize;
        let fc_clx = u32_at(&word, 0x1A2).ok_or_else(bad)? as usize;
        let lcb_clx = u32_at(&word, 0x1A6).ok_or_else(bad)? as usize;
        let clx = table.get(fc_clx..fc_clx + lcb_clx).ok_or_else(bad)?;
        // Clx : des Prc (0x01) à sauter, puis la table des morceaux (0x02).
        let mut at = 0usize;
        while clx.get(at) == Some(&0x01) {
            at += 3 + u16_at(clx, at + 1).ok_or_else(bad)? as usize;
        }
        if clx.get(at) != Some(&0x02) {
            return Err(bad());
        }
        let lcb = u32_at(clx, at + 1).ok_or_else(bad)? as usize;
        let plc = clx.get(at + 5..at + 5 + lcb).ok_or_else(bad)?;
        let n = lcb.saturating_sub(4) / 12;
        let mut out = String::new();
        for k in 0..n {
            let cp0 = u32_at(plc, k * 4).ok_or_else(bad)? as usize;
            let cp1 = u32_at(plc, (k + 1) * 4).ok_or_else(bad)? as usize;
            if cp0 >= ccp_text {
                break;
            }
            let len = cp1.min(ccp_text).saturating_sub(cp0);
            let fc = u32_at(plc, (n + 1) * 4 + k * 8 + 2).ok_or_else(bad)?;
            if fc & 0x4000_0000 != 0 {
                let off = ((fc & !0x4000_0000) / 2) as usize;
                let raw = word.get(off..off + len).ok_or_else(bad)?;
                let (s, _, _) = encoding_rs::WINDOWS_1252.decode(raw);
                out.push_str(&s);
            } else {
                let off = fc as usize;
                let raw = word.get(off..off + len * 2).ok_or_else(bad)?;
                let units: Vec<u16> = raw.chunks_exact(2).map(|c| u16::from_le_bytes([c[0], c[1]])).collect();
                out.push_str(&String::from_utf16_lossy(&units));
            }
        }
        Ok(split(&out))
    }

    /// Découpe le texte brut de Word en paragraphes, en retirant les codes
    /// de champ et les caractères spéciaux.
    fn split(raw: &str) -> Vec<Para> {
        let mut paras = Vec::new();
        let mut cur = String::new();
        // Champs : 0x13 instruction 0x14 résultat 0x15 ; on garde le résultat.
        let mut fields: Vec<bool> = Vec::new(); // true : dans l'instruction
        let mut cells = 0;
        for ch in raw.chars() {
            if ch != '\u{07}' && !matches!(ch, '\u{13}' | '\u{14}' | '\u{15}') {
                cells = 0;
            }
            match ch {
                '\u{13}' => fields.push(true),
                '\u{14}' => {
                    if let Some(f) = fields.last_mut() {
                        *f = false;
                    }
                }
                '\u{15}' => {
                    fields.pop();
                }
                _ if fields.last() == Some(&true) => {}
                '\r' | '\u{0C}' => paras.push(std::mem::take(&mut cur)),
                '\u{07}' => {
                    // Fin de case ; deux de suite : fin de ligne de tableau.
                    cells += 1;
                    if cells >= 2 {
                        let line = std::mem::take(&mut cur);
                        paras.push(line.trim_end_matches('\t').to_string());
                        cells = 0;
                    } else {
                        cur.push('\t');
                    }
                }
                '\u{0B}' => cur.push('\n'),
                '\t' => cur.push('\t'),
                '\u{1E}' => cur.push('-'),
                c if (c as u32) < 0x20 => {}
                c => cur.push(c),
            }
        }
        if !cur.is_empty() {
            paras.push(cur);
        }
        paras
            .into_iter()
            .map(|t| Para { align: None, runs: if t.is_empty() { vec![] } else { vec![Run { text: t, ..Default::default() }] } })
            .collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rtf_keeps_text_and_basic_formatting() {
        let src = b"{\\rtf1\\ansi\\ansicpg1252{\\fonttbl{\\f0 Arial;}}{\\colortbl;\\red255\\green0\\blue0;}\n\\pard\\qc{\\b Titre}\\par\n\\pard Un {\\i mot} en \\cf1 rouge\\cf0 , caf\\'e9 \\u8364?.\\par}";
        let p = rtf::parse(src);
        assert_eq!(p.len(), 2, "{p:?}");
        assert_eq!(p[0].align, Some("center"));
        assert!(p[0].runs[0].bold && p[0].runs[0].text == "Titre");
        let all: String = p[1].runs.iter().map(|r| r.text.as_str()).collect();
        assert_eq!(all, "Un mot en rouge, caf\u{e9} \u{20ac}.");
        assert!(p[1].runs.iter().any(|r| r.italic && r.text == "mot"));
        assert!(p[1].runs.iter().any(|r| r.color.as_deref() == Some("FF0000") && r.text == "rouge"));
    }

    #[test]
    fn rtf_reads_into_a_document() {
        let dir = temp_name("dactylo-rtf-test");
        std::fs::create_dir_all(&dir).unwrap();
        let f = dir.join("essai.rtf");
        std::fs::write(&f, b"{\\rtf1\\ansi {\\b Bonjour} le monde\\par Seconde ligne\\par}").unwrap();
        let doc = read(&f).unwrap();
        let text: Vec<String> = doc.paragraphs.iter().map(|p| p.text()).collect();
        assert!(text.iter().any(|t| t == "Bonjour le monde"), "{text:?}");
        assert!(text.iter().any(|t| t == "Seconde ligne"), "{text:?}");
        let _ = std::fs::remove_dir_all(&dir);
    }
}
