// editor.rs — le tampon de texte d'un document et sa saisie.
// SPDX-License-Identifier: GPL-3.0-or-later
//
// Le modèle `letters_core::Document` (via live.rs) est la source de vérité ;
// le GtkTextBuffer n'en est que la vue. La frappe est interceptée avant que
// GTK n'insère quoi que ce soit, puis rejouée comme une opération du
// modèle : le texte tapé hérite ainsi du style voulu (gras en cours, etc.)
// et chaque mot tapé reste une seule étape d'annulation.

use gtk4::{self as gtk, glib, prelude::*};
use letters_core::edit::{self, Op};

/// Fait défiler la feuille pour que `it` soit à `yalign` de la hauteur
/// visible (0 en haut, 0,5 au milieu). La vue n'a pas son propre
/// défilement : c'est la fenêtre défilante qui la contient qui bouge.
/// Le cadre de défilement de `view`, et la hauteur (dans ce qui défile) du
/// point `y` de la vue : mesurée dans la page (stable, quel que soit le
/// défilement en cours), plus la marge au-dessus de la page (grande en
/// mode concentration).
fn content_y(view: &gtk::TextView, y: i32) -> Option<(gtk::ScrolledWindow, f64)> {
    let scroller = view.ancestor(gtk::ScrolledWindow::static_type()).and_then(|w| w.downcast::<gtk::ScrolledWindow>().ok())?;
    let content = scroll_content(&scroller)?;
    let p = view.compute_point(&content, &gtk::graphene::Point::new(0.0, y as f32))?;
    Some((scroller, p.y() as f64 + content.margin_top() as f64))
}

/// Ce qui défile dans `scroller` : l'enfant du Viewport s'il y en a un.
pub fn scroll_content(scroller: &gtk::ScrolledWindow) -> Option<gtk::Widget> {
    let child = scroller.child()?;
    match child.downcast::<gtk::Viewport>() {
        Ok(vp) => vp.child(),
        Err(child) => Some(child),
    }
}

pub fn scroll_to_iter(view: &gtk::TextView, it: &gtk::TextIter, yalign: f64) {
    let loc = view.iter_location(it);
    let (_, y) = view.buffer_to_window_coords(gtk::TextWindowType::Widget, loc.x(), loc.y() + loc.height() / 2);
    let Some((scroller, cy)) = content_y(view, y) else { return };
    let adj = scroller.vadjustment();
    let target = cy - adj.page_size() * yalign;
    adj.set_value(target.clamp(adj.lower(), (adj.upper() - adj.page_size()).max(adj.lower())));
}

/// Fait défiler juste assez pour que la ligne de `it` soit visible, avec une
/// petite marge ; ne bouge pas si elle l'est déjà.
pub fn ensure_visible(view: &gtk::TextView, it: &gtk::TextIter) {
    let loc = view.iter_location(it);
    let (_, y) = view.buffer_to_window_coords(gtk::TextWindowType::Widget, loc.x(), loc.y());
    let Some((scroller, top)) = content_y(view, y) else { return };
    let adj = scroller.vadjustment();
    let margin = 24.0_f64.min(adj.page_size() / 4.0);
    let bottom = top + loc.height() as f64;
    let target = if it.is_start() {
        adj.lower()
    } else if top - margin < adj.value() {
        top - margin
    } else if bottom + margin > adj.value() + adj.page_size() {
        bottom + margin - adj.page_size()
    } else {
        return;
    };
    adj.set_value(target.clamp(adj.lower(), (adj.upper() - adj.page_size()).max(adj.lower())));
}

/// Un tampon prêt à l'emploi : balises de formatage, modèle vivant, frappe
/// passant par le modèle.
pub fn new_buffer() -> gtk::TextBuffer {
    let buf = gtk::TextBuffer::new(None);
    crate::formatting::register_formatting_tags(&buf);
    crate::live::LiveModel::attach(&buf);
    buf.connect_insert_text(|b, _iter, text| {
        // Le modèle écrit lui-même dans le tampon (chargement, annulation,
        // reformatage) : on le laisse faire.
        if crate::live::is_busy(b) || text.is_empty() {
            return;
        }
        b.stop_signal_emission_by_name("insert-text");
        let (b, text) = (b.clone(), text.to_string());
        // Hors de l'émission : on ne modifie pas un tampon en cours
        // d'insertion. Priorité haute, donc avant le prochain dessin, et
        // dans l'ordre des frappes.
        glib::idle_add_local_full(glib::Priority::HIGH, move || {
            insert_text(&b, &text);
            glib::ControlFlow::Break
        });
    });
    buf
}

/// Taper `text` au curseur, comme une opération du modèle.
fn insert_text(buf: &gtk::TextBuffer, text: &str) {
    let Some(m) = crate::live::of(buf) else {
        return;
    };
    let mut m = m.borrow_mut();
    let (s, e) = selection_offsets(buf);
    let caret = s as i32;
    let (s, e) = (m.sequence_offset(buf, s), m.sequence_offset(buf, e));
    let doc = m.document(buf).clone();
    let mut ops = Vec::new();
    let mut scratch = doc.clone();
    if e > s {
        let del = Op::Delete { at: s, len: e - s };
        if edit::apply(&mut scratch, &del).is_err() {
            return;
        }
        ops.push(del);
    }
    // Typographie française : l'espace avant « ; ! ? : » devient insécable,
    // " devient « ou », ' devient ’.
    let (mut at, mut text) = (s, text.to_string());
    if e == s {
        if let Some((back, replacement)) = french_typography(&scratch, s, &text) {
            if back > 0 {
                let del = Op::Delete { at: s - back, len: back };
                if edit::apply(&mut scratch, &del).is_err() {
                    return;
                }
                ops.push(del);
                at = s - back;
            }
            if replacement.is_empty() && ops.is_empty() {
                // Espace tapée après « et son espace insécable : rien à faire.
                return;
            }
            text = replacement;
        }
    }
    let text = text.as_str();
    let Some(mut typed) = typed_ops(&scratch, at, text) else {
        return;
    };
    // Formatage choisi sans sélection (Ctrl+B puis frappe) : appliqué au
    // texte tapé, dans la même opération.
    if let Some(pending) = crate::formatting::take_pending(buf).filter(|p| e == s && p.at == caret) {
        for op in &mut typed {
            if let Op::Insert { content, .. } = op {
                for run in content.iter_mut().flat_map(|p| p.runs.iter_mut()) {
                    for (name, on) in &pending.marks {
                        if let Some(flag) = crate::formatting::style_flag(&mut run.style, name) {
                            *flag = *on;
                        }
                    }
                    for (key, value) in &pending.values {
                        key.copy(value, &mut run.style);
                    }
                }
            }
        }
    }
    let inserts = typed.iter().any(|op| matches!(op, Op::Insert { .. }));
    ops.extend(typed);
    let word = text.chars().count() == 1 && !text.chars().any(char::is_whitespace) && e == s;
    let applied = m.apply_user_ops(buf, &ops, word);
    // La projection place le curseur « après le changement dans le premier
    // paragraphe modifié », qu'elle déduit en comparant l'avant et l'après :
    // faux pour un saut de paragraphe au milieu d'un paragraphe, et quand la
    // lettre tapée est la même que la suivante (taper « l » devant « le » :
    // la comparaison ne sait pas lequel des deux est nouveau, et le curseur
    // sautait la lettre). On le place nous-mêmes après le texte inséré.
    if applied && inserts {
        let target = at + text.chars().count();
        if let Some(off) = m.buffer_offset(buf, target) {
            buf.place_cursor(&buf.iter_at_offset(off as i32));
        }
    }
    drop(m);
    crate::live::sync_actions(buf);
}

const NBSP: char = '\u{a0}';
/// Espace fine insécable, avant ; ! ?
const NNBSP: char = '\u{202f}';

/// La correction typographique d'un caractère tapé à `at` : combien de
/// caractères effacer avant lui, et quoi taper à la place.
fn french_typography(doc: &letters_core::Document, at: usize, typed: &str) -> Option<(usize, String)> {
    let mut it = typed.chars();
    let c = it.next()?;
    if it.next().is_some() {
        return None;
    }
    let (pi, po) = edit::locate(doc, at)?;
    let para: Vec<char> = doc.paragraphs[pi].runs.iter().flat_map(|r| r.text.chars()).collect();
    let before = |n: usize| po.checked_sub(n).and_then(|i| para.get(i)).copied();
    let prev = before(1);
    match c {
        ';' | '!' | '?' => match prev {
            Some(' ') => Some((1, format!("{NNBSP}{c}"))),
            Some(p) if p.is_alphabetic() || p == '»' || p == ')' => Some((0, format!("{NNBSP}{c}"))),
            _ => None,
        },
        // Pas d'espace ajoutée devant « : » collé (heures, adresses web).
        ':' if prev == Some(' ') => Some((1, format!("{NBSP}:"))),
        '"' => {
            let upto = &para[..po.min(para.len())];
            let open = upto.iter().filter(|c| **c == '«').count() > upto.iter().filter(|c| **c == '»').count();
            if open {
                Some((usize::from(prev == Some(' ')), format!("{NBSP}»")))
            } else {
                Some((0, format!("«{NBSP}")))
            }
        }
        '\'' => Some((0, "’".to_string())),
        ' ' if prev == Some(NBSP) && before(2) == Some('«') => Some((0, String::new())),
        _ => None,
    }
}

/// Entrée dans un élément de liste vide termine la liste au lieu d'en
/// ajouter un autre.
fn typed_ops(doc: &letters_core::Document, at: usize, text: &str) -> Option<Vec<Op>> {
    if text == "\n" {
        let (pi, _) = edit::locate(doc, at)?;
        let p = &doc.paragraphs[pi];
        if p.style.list != letters_core::ListKind::None && p.runs.is_empty() {
            let style = letters_core::ParaStyle { list: letters_core::ListKind::None, list_level: 0, ..p.style.clone() };
            return Some(vec![Op::SetParaStyle { at, style }]);
        }
        // Entrée à la fin d'un titre : le paragraphe suivant est du corps
        // de texte, pas un autre titre.
        let (_, po) = edit::locate(doc, at)?;
        let len: usize = p.runs.iter().map(|r| r.text.chars().count()).sum();
        if (p.style.heading.is_some() || p.style.block_quote) && po >= len {
            let body = letters_core::ParaStyle { heading: None, block_quote: false, ..p.style.clone() };
            return Some(vec![edit::typing(doc, at, text)?, Op::SetParaStyle { at: at + 1, style: body }]);
        }
    }
    Some(vec![edit::typing(doc, at, text)?])
}

fn selection_offsets(buf: &gtk::TextBuffer) -> (usize, usize) {
    let a = buf.iter_at_mark(&buf.get_insert()).offset().max(0) as usize;
    let b = buf.iter_at_mark(&buf.selection_bound()).offset().max(0) as usize;
    (a.min(b), a.max(b))
}

/// Habillage des tableaux (affichés en grille « | a | b | ») : police à
/// chasse fixe, fond gris, ligne de séparation atténuée. Balises de
/// présentation : le modèle les ignore.
pub fn decorate_tables(buf: &gtk::TextBuffer) {
    let modified = buf.is_modified();
    let (s, e) = buf.bounds();
    for tag in ["table-line", "table-delim", "textbox-line", "textbox-white", "textbox-hide", "textbox-h1", "textbox-h2", "textbox-h3", "textbox-h4", "textbox-h5", "textbox-h6"] {
        // Les balises « textbox-hN » ne sont créées qu'au premier titre en
        // cartouche : ne retirer que celles qui existent (sinon GTK avertit).
        if let Some(t) = buf.tag_table().lookup(tag) {
            buf.remove_tag(&t, &s, &e);
        }
    }
    let text = buf.slice(&s, &e, true);
    if !text.contains("| ") {
        buf.set_modified(modified);
        return;
    }
    let lines: Vec<&str> = text.split('\n').collect();
    let is_row = |l: &str| {
        let t = l.trim();
        t.starts_with('|') && t.ends_with('|') && t.len() >= 2
    };
    // Une seule case : « | texte | ».
    let single = |l: &str| {
        let t = l.trim();
        t.len() >= 2 && !t[1..t.len() - 1].contains('|')
    };
    let mut starts = Vec::with_capacity(lines.len());
    let mut off = 0i32;
    for l in &lines {
        starts.push(off);
        off += l.chars().count() as i32 + 1;
    }
    let len = |i: usize| lines[i].chars().count() as i32;
    // L'allure de chaque cartouche, par tableau (dans l'ordre du texte).
    let looks = crate::bridge::cell_styles(buf);
    let mut ordinal: Option<usize> = None;
    let mut i = 0;
    while i < lines.len() {
        let line = lines[i];
        if is_row(line) && lines.get(i + 1).is_some_and(|d| letters_core::table_text::is_delimiter_line(d)) {
            ordinal = Some(ordinal.map_or(0, |n| n + 1));
        }
        // Zone de texte (tableau d'une case) : un encadré gris clair, sans
        // les barres ni la ligne « | --- | ».
        let textbox = is_row(line)
            && single(line)
            && (i == 0 || !is_row(lines[i - 1]))
            && lines.get(i + 1).is_some_and(|d| letters_core::table_text::is_delimiter_line(d) && single(d))
            && lines.get(i + 2).is_none_or(|n| !is_row(n));
        if textbox {
            let (a, b) = (buf.iter_at_offset(starts[i]), buf.iter_at_offset(starts[i] + len(i)));
            let style = looks.iter().find(|(k, _)| Some(*k) == ordinal.map(|n| (n, 0, 0))).map(|(_, st)| st);
            let white = style.and_then(|st| st.cartouche).is_some_and(|c| c.white);
            buf.apply_tag_by_name(if white { "textbox-white" } else { "textbox-line" }, &a, &b);
            // Un titre dans un cartouche : l'allure du titre.
            if let Some(level) = style.and_then(|st| st.heading).filter(|l| (1..=6).contains(l)) {
                let name = format!("textbox-h{level}");
                if let Some(h) = buf.tag_table().lookup(&format!("h{level}")) {
                    let t = buf.tag_table().lookup(&name).unwrap_or_else(|| {
                        let t = gtk::TextTag::new(Some(&name));
                        buf.tag_table().add(&t);
                        t
                    });
                    t.set_scale(h.scale());
                    t.set_weight(h.weight());
                    t.set_foreground_rgba(h.foreground_rgba().as_ref());
                    t.set_family(h.family().as_deref());
                    buf.apply_tag(&t, &a, &b);
                }
            }
            let lead = line.chars().take_while(|c| c.is_whitespace()).count() as i32;
            let tail = line.chars().rev().take_while(|c| c.is_whitespace()).count() as i32;
            let open = if line.trim_start().starts_with("| ") { 2 } else { 1 };
            let close = if line.trim_end().ends_with(" |") { 2 } else { 1 };
            let hide = |from: i32, to: i32| buf.apply_tag_by_name("textbox-hide", &buf.iter_at_offset(from), &buf.iter_at_offset(to));
            hide(starts[i], starts[i] + lead + open);
            hide(starts[i] + len(i) - tail - close, starts[i + 1] + len(i + 1));
            i += 2;
            continue;
        }
        if is_row(line) {
            let (a, b) = (buf.iter_at_offset(starts[i]), buf.iter_at_offset(starts[i] + len(i)));
            buf.apply_tag_by_name("table-line", &a, &b);
            if letters_core::table_text::is_delimiter_line(line) {
                buf.apply_tag_by_name("table-delim", &a, &b);
            }
        }
        i += 1;
    }
    buf.set_modified(modified);
}

/// Style de paragraphe proposé dans la liste déroulante.
#[derive(Clone, Copy, PartialEq, Eq)]
pub enum BlockStyle {
    Body,
    Heading(u8),
}

pub const BLOCK_STYLES: [(BlockStyle, &str); 5] = [
    (BlockStyle::Body, "Corps de texte"),
    (BlockStyle::Heading(1), "Titre 1"),
    (BlockStyle::Heading(2), "Titre 2"),
    (BlockStyle::Heading(3), "Titre 3"),
    (BlockStyle::Heading(4), "Titre 4"),
];

pub fn set_block_style(buf: &gtk::TextBuffer, block: BlockStyle) {
    crate::formatting::restyle_here(buf, |style| {
        let mut s = style.clone();
        match block {
            BlockStyle::Body => {
                s.heading = None;
                s.block_quote = false;
            }
            BlockStyle::Heading(n) => {
                s.heading = Some(n);
                s.block_quote = false;
            }
        }
        s
    });
}

/// Ce que le curseur « porte » : pour mettre à jour la barre d'outils.
#[derive(Default, Clone)]
pub struct CaretState {
    pub bold: bool,
    pub italic: bool,
    pub underline: bool,
    pub strikethrough: bool,
    pub highlight: bool,
    pub font_family: Option<String>,
    pub font_size_hp: Option<u16>,
    pub color: Option<String>,
    pub base_family: Option<String>,
    pub base_size_hp: Option<u16>,
    pub para: Option<letters_core::ParaStyle>,
    pub block: Option<usize>,
    pub alignment: Option<letters_core::Alignment>,
    pub list: Option<letters_core::ListKind>,
}

pub fn caret_state(buf: &gtk::TextBuffer) -> CaretState {
    let mut st = CaretState::default();
    let Some(m) = crate::live::of(buf) else { return st };
    let Ok(mut m) = m.try_borrow_mut() else { return st };
    let (s, _) = selection_offsets(buf);
    let seq = m.sequence_offset(buf, s);
    let mut run = edit::typing_style(m.document(buf), seq);
    // Une sélection : le style de son premier caractère.
    if buf.has_selection() {
        let (s, e) = selection_offsets(buf);
        let (a, b) = (m.sequence_offset(buf, s), m.sequence_offset(buf, e));
        if let Some(r) = edit::slice(m.document(buf), a, b)
            .and_then(|ps| ps.into_iter().flat_map(|p| p.runs).find(|r| !r.text.is_empty()))
        {
            run = r.style;
        }
    }
    st.bold = run.bold;
    st.italic = run.italic;
    st.underline = run.underline;
    st.strikethrough = run.strikethrough;
    st.highlight = run.highlight;
    st.font_family = run.font_family.clone();
    st.font_size_hp = run.font_size_hp;
    st.color = run.color.clone();
    {
        let base = &m.document(buf).base_font;
        st.base_family = base.family.clone();
        st.base_size_hp = base.size_hp;
    }
    if let Some(p) = m.paragraph_style_at(buf, s) {
        st.para = Some(p.clone());
        st.block = BLOCK_STYLES.iter().position(|(b, _)| match *b {
            BlockStyle::Body => p.heading.is_none() && !p.block_quote,
            BlockStyle::Heading(n) => p.heading == Some(n),
        });
        st.alignment = Some(p.alignment);
        st.list = Some(p.list);
    }
    // Formatage en attente au curseur (Ctrl+B sans sélection).
    if let Some(p) = crate::formatting::take_pending(buf) {
        let at = buf.iter_at_mark(&buf.get_insert()).offset();
        if p.at == at {
            for (name, on) in &p.marks {
                match name.as_str() {
                    "bold" => st.bold = *on,
                    "italic" => st.italic = *on,
                    "underline" => st.underline = *on,
                    "strikethrough" => st.strikethrough = *on,
                    "highlight" => st.highlight = *on,
                    _ => {}
                }
            }
            for (key, value) in &p.values {
                let mut r = letters_core::RunStyle { font_family: st.font_family.clone(), font_size_hp: st.font_size_hp, color: st.color.clone(), ..Default::default() };
                key.copy(value, &mut r);
                st.font_family = r.font_family;
                st.font_size_hp = r.font_size_hp;
                st.color = r.color;
            }
            crate::formatting::put_pending(buf, p);
        }
    }
    st
}

pub fn toggle_list(buf: &gtk::TextBuffer, kind: letters_core::ListKind) {
    crate::bridge::apply_structured_edit(buf, |editor| {
        editor.toggle_list_at_cursor(kind);
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    fn pump() {
        let ctx = glib::MainContext::default();
        while ctx.iteration(false) {}
    }

    fn model_text(buf: &gtk::TextBuffer) -> String {
        crate::bridge::document_of(buf).paragraphs.iter().map(|p| p.text()).collect::<Vec<_>>().join("¶")
    }

    fn buf_text(buf: &gtk::TextBuffer) -> String {
        buf.text(&buf.start_iter(), &buf.end_iter(), true).replace('\n', "¶")
    }

    fn type_(buf: &gtk::TextBuffer, t: &str) {
        for c in t.chars() {
            buf.insert_interactive_at_cursor(&c.to_string(), true);
            pump();
        }
    }

    /// GTK ne vit que sur un thread : un seul #[test] qui enchaîne les cas.
    #[test]
    fn editing() {
        gtk::init().unwrap();
        typing_and_return();
        bold_heading_list_undo();
        formats();
        commands_work();
        new_features();
        typography_spacing_spell();
        caret_after_same_letter();
    }

    /// Taper une lettre devant la même lettre : le curseur reste juste
    /// après elle (il sautait la suivante, et la frappe s'entremêlait).
    fn caret_after_same_letter() {
        let buf = new_buffer();
        type_(&buf, "villages");
        buf.place_cursor(&buf.iter_at_offset(6));
        type_(&buf, "Encore");
        assert_eq!(model_text(&buf), "villagEncorees");
        buf.place_cursor(&buf.iter_at_offset(1));
        type_(&buf, "ill");
        assert_eq!(model_text(&buf), "villillagEncorees");
    }

    /// Typographie française à la frappe, interligne, vérification
    /// orthographique des seuls paragraphes modifiés.
    fn typography_spacing_spell() {
        let buf = new_buffer();
        type_(&buf, "Il dit \"bonjour\" ; l'ami répond! À 10:30 voici :");
        assert_eq!(model_text(&buf), "Il dit «\u{a0}bonjour\u{a0}»\u{202f}; l’ami répond\u{202f}! À 10:30 voici\u{a0}:");
        assert_eq!(buf_text(&buf), model_text(&buf));
        // Le curseur suit le texte corrigé.
        type_(&buf, "x");
        assert!(model_text(&buf).ends_with("voici\u{a0}:x"), "{}", model_text(&buf));
        // Une espace tapée après « n'en ajoute pas une seconde.
        type_(&buf, " \" ");
        assert!(model_text(&buf).ends_with(":x «\u{a0}"), "{:?}", model_text(&buf));

        let (s, e) = buf.bounds();
        buf.select_range(&s, &e);
        crate::commands::restyle(&buf, |st| letters_core::ParaStyle { line_spacing: 1.5, ..st.clone() });
        pump();
        assert_eq!(crate::bridge::document_of(&buf).paragraphs[0].style.line_spacing, 1.5);
        let dir = std::env::temp_dir().join(format!("samizdat-ls-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("ls.docx");
        letters_core::save::write(&crate::bridge::document_of(&buf), &path).unwrap();
        assert_eq!(letters_core::save::read(&path).unwrap().paragraphs[0].style.line_spacing, 1.5);

        // Orthographe : seul le paragraphe modifié est revérifié.
        let checker = crate::spell::Checker::new();
        if !checker.available() {
            return;
        }
        let buf = new_buffer();
        checker.track(&buf);
        type_(&buf, "Le chat dort.\nLe chien aboit fort.");
        checker.check_buffer(&buf);
        let errors = |buf: &gtk::TextBuffer| {
            let tag = buf.tag_table().lookup("spelling-error").unwrap();
            let mut it = buf.start_iter();
            let mut n = 0;
            loop {
                if it.starts_tag(Some(&tag)) {
                    n += 1;
                }
                if !it.forward_to_tag_toggle(Some(&tag)) {
                    break;
                }
            }
            n
        };
        assert_eq!(errors(&buf), 1, "« aboit »");
        buf.place_cursor(&buf.iter_at_offset(7));
        type_(&buf, "zz");
        checker.schedule(&buf);
        let t0 = std::time::Instant::now();
        while t0.elapsed() < std::time::Duration::from_millis(600) {
            pump();
            std::thread::sleep(std::time::Duration::from_millis(20));
        }
        assert_eq!(errors(&buf), 2, "« chatzz » souligné, « aboit » toujours");
    }

    /// Surlignage en couleur, lien, colonnes, éditeur de tableau, zone de
    /// texte, forme : sur le modèle puis après un aller-retour DOCX/ODT.
    fn new_features() {
        use crate::commands;
        let buf = new_buffer();
        let doc = letters_core::markdown::parse("Un mot vert et un lien.\n\nFin.\n");
        crate::bridge::load_document(&doc, &buf);
        pump();
        select(&buf, 3, 6); // « mot »
        commands::set_highlight(&buf, Some("00FF00"));
        select(&buf, 0, 2); // « Un »
        commands::set_highlight(&buf, Some("FFA500"));
        pump();
        let d = crate::bridge::document_of(&buf);
        let mot = d.paragraphs[0].runs.iter().find(|r| r.text == "mot").expect("run mot");
        assert!(mot.style.highlight && mot.style.highlight_color.as_deref() == Some("00FF00"), "{:?}", mot.style);
        // Lien sur « lien ».
        select(&buf, 18, 22);
        commands::insert_link(&buf, "", "https://example.org");
        pump();
        // Colonnes.
        commands::set_columns(&buf, 2);
        assert_eq!(commands::columns(&buf), 2);
        // Tableau via l'éditeur : en-tête en gras conservé quand on modifie.
        let mut end = buf.end_iter();
        end.backward_char();
        buf.place_cursor(&end);
        let texts = vec![vec!["Nom".to_string(), "Prix".to_string()], vec!["Pain".to_string(), "1".to_string()]];
        commands::write_table(&buf, &texts, None);
        pump();
        // Mettre « Nom » en gras dans le modèle, puis modifier la case.
        let d = crate::bridge::document_of(&buf);
        let first = d.paragraphs.iter().position(|p| p.style.table_cell.is_some()).expect("tableau inséré");
        let mut bolded = d.paragraphs[first].clone();
        bolded.runs[0].style.bold = true;
        crate::live::of(&buf).unwrap().borrow_mut().edit_with(&buf, |_| vec![letters_core::edit::Op::SetParagraphs { para: first, remove: 1, insert: vec![bolded] }]);
        pump();
        let off = {
            let m = crate::live::of(&buf).unwrap();
            let mut m = m.borrow_mut();
            let seq = letters_core::edit::paragraph_start(m.document(&buf), first);
            m.buffer_offset(&buf, seq).unwrap()
        };
        buf.place_cursor(&buf.iter_at_offset(off as i32));
        let t = commands::table_at_caret(&buf).expect("tableau au curseur");
        assert_eq!((t.rows, t.cols), (2, 2));
        let edited = vec![vec!["Article".to_string(), "Prix".to_string()], vec!["Pain".to_string(), "1".to_string()], vec!["Lait".to_string(), "2".to_string()]];
        commands::write_table(&buf, &edited, Some(&t));
        pump();
        let d = crate::bridge::document_of(&buf);
        let cells: Vec<_> = d.paragraphs.iter().filter(|p| p.style.table_cell.is_some()).collect();
        eprintln!("tableau édité : {:?}", cells.iter().map(|p| (p.text(), p.runs.first().map(|r| r.style.bold))).collect::<Vec<_>>());
        assert_eq!(cells.len(), 6);
        assert_eq!(cells[0].text(), "Article");
        assert_eq!(cells[0].runs[0].style.bold, true, "le gras de la case est conservé");
        // Zone de texte : un tableau d'une case, à la fin.
        buf.place_cursor(&buf.end_iter());
        commands::write_table(&buf, &[vec!["Encadré important".to_string()]], None);
        pump();
        // Forme.
        let png = crate::shapes::render_png(crate::shapes::Shape::Star, "F6D32D").unwrap();
        buf.place_cursor(&buf.start_iter());
        commands::insert_image_sized(&buf, &png, Some(3.0)).unwrap();
        pump();
        // Aller-retour.
        let d = crate::bridge::document_of(&buf);
        let dir = std::env::temp_dir().join(format!("samizdat-nf-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        for ext in ["docx", "odt"] {
            let path = dir.join(format!("n.{ext}"));
            letters_core::save::write(&d, &path).unwrap();
            let back = letters_core::save::read(&path).unwrap();
            let runs: Vec<_> = back.paragraphs.iter().flat_map(|p| p.runs.iter()).collect();
            let mot = runs.iter().find(|r| r.text.contains("mot")).unwrap();
            assert_eq!(mot.style.highlight_color.as_deref(), Some("00FF00"), "{ext} vert");
            let un = runs.iter().find(|r| r.text.starts_with("Un")).unwrap();
            assert_eq!(un.style.highlight_color.as_deref(), Some("FFA500"), "{ext} orange");
            assert!(runs.iter().any(|r| r.style.link.as_deref() == Some("https://example.org")), "{ext} lien");
            assert_eq!(back.page.as_ref().map(|p| p.columns), Some(2), "{ext} colonnes");
            let tables: std::collections::BTreeSet<u32> = back.paragraphs.iter().filter_map(|p| p.style.table_cell.map(|c| c.table)).collect();
            assert_eq!(tables.len(), 2, "{ext} : tableau + zone de texte");
            assert!(back.paragraphs.iter().any(|p| p.text() == "Encadré important"), "{ext}");
            assert!(runs.iter().any(|r| r.style.image.is_some()), "{ext} forme");
            eprintln!("{ext} : nouveautés OK");
        }
        // Bordures des tableaux dans le DOCX.
        let x = {
            use std::io::Read;
            let mut z = zip::ZipArchive::new(std::fs::File::open(dir.join("n.docx")).unwrap()).unwrap();
            let mut s = String::new();
            z.by_name("word/document.xml").unwrap().read_to_string(&mut s).unwrap();
            s
        };
        assert!(x.contains("w:tblBorders"), "bordures de tableau");
        assert!(x.contains("w:highlight w:val=\"green\""), "surlignage Word vert");
        // Orthographe.
        let sp = crate::spell::Checker::new();
        if sp.available() {
            assert!(sp.correct("maison") && sp.correct("aujourd'hui") && sp.correct("l'homme") && sp.correct("peut-être"));
            assert!(!sp.correct("maisonn"));
            assert!(sp.suggestions("maisonn").iter().any(|s| s == "maison"), "{:?}", sp.suggestions("maisonn"));
            // Une image avant le mot ne doit pas décaler le soulignement.
            let b2 = new_buffer();
            crate::bridge::load_document(&letters_core::markdown::parse("Une maisonn ici.\n"), &b2);
            pump();
            b2.place_cursor(&b2.start_iter());
            commands::insert_image_sized(&b2, &png, Some(1.0)).unwrap();
            pump();
            sp.check_buffer(&b2);
            let tag = b2.tag_table().lookup("spelling-error").unwrap();
            let mut it = b2.start_iter();
            assert!(it.forward_to_tag_toggle(Some(&tag)), "mot souligné");
            let (a, b, word) = sp.misspelled_at(&b2, &it).unwrap();
            eprintln!("souligné : {word:?} ({a}..{b})");
            assert_eq!(word, "maisonn");
            // La recherche aussi tient compte de l'image.
            let found = commands::find_all(&b2, "ici", true);
            assert_eq!(b2.text(&b2.iter_at_offset(found[0].0), &b2.iter_at_offset(found[0].1), false), "ici");
            eprintln!("orthographe : OK");
        }
    }

    fn select(buf: &gtk::TextBuffer, a: i32, b: i32) {
        buf.select_range(&buf.iter_at_offset(a), &buf.iter_at_offset(b));
    }

    /// Police, taille, couleur, retraits, remplacement, tableaux, mise en
    /// page, images : sur le modèle, puis relus après un aller-retour DOCX.
    fn commands_work() {
        use crate::commands;
        let buf = new_buffer();
        let doc = letters_core::markdown::parse("Bonjour le monde.\n\nSecond paragraphe avec monde.\n");
        crate::bridge::load_document(&doc, &buf);
        pump();
        // Sélection « Bonjour » : police, taille, couleur.
        select(&buf, 0, 7);
        commands::set_font_family(&buf, Some("Liberation Serif".into()));
        commands::set_font_size(&buf, 18.0);
        commands::set_color(&buf, Some("C01C28".into()));
        crate::formatting::toggle_tag_in(&buf, "highlight");
        pump();
        let d = crate::bridge::document_of(&buf);
        let r0 = &d.paragraphs[0].runs[0];
        eprintln!("style: {:?} {:?} {:?} hl={}", r0.style.font_family, r0.style.font_size_hp, r0.style.color, r0.style.highlight);
        assert_eq!(r0.text, "Bonjour");
        assert_eq!(r0.style.font_family.as_deref(), Some("Liberation Serif"));
        assert_eq!(r0.style.font_size_hp, Some(36));
        assert_eq!(r0.style.color.as_deref(), Some("C01C28"));
        assert!(r0.style.highlight);
        // Sans sélection : la taille s'applique au texte tapé ensuite.
        let mut end = buf.start_iter();
        end.forward_to_line_end();
        buf.place_cursor(&end);
        commands::set_font_size(&buf, 8.0);
        type_(&buf, " petit");
        let d = crate::bridge::document_of(&buf);
        let last = d.paragraphs[0].runs.last().unwrap();
        eprintln!("frappe: {:?} {:?}", last.text, last.style.font_size_hp);
        assert!(last.text.contains("petit") && last.style.font_size_hp == Some(16));
        // Retrait.
        commands::indent(&buf, true);
        commands::indent(&buf, true);
        pump();
        let d = crate::bridge::document_of(&buf);
        assert!((d.paragraphs[0].style.left_indent_pt - 2.0 * commands::INDENT_STEP_PT).abs() < 0.1);
        // Remplacer tout : deux « monde ».
        let found = commands::find_all(&buf, "MONDE", false);
        assert_eq!(found.len(), 2);
        assert_eq!(commands::replace_ranges(&buf, &found, "pays"), 2);
        pump();
        let txt = model_text(&buf);
        eprintln!("remplacé: {txt}");
        assert!(txt.contains("le pays.") && txt.contains("avec pays.") && !txt.contains("monde"));
        // Le style du mot remplacé est conservé (Bonjour reste rouge).
        assert_eq!(crate::bridge::document_of(&buf).paragraphs[0].runs[0].style.color.as_deref(), Some("C01C28"));
        // Un seul pas d'annulation pour tout le remplacement.
        crate::live::undo(&buf, false);
        pump();
        assert!(model_text(&buf).contains("monde"), "{}", model_text(&buf));
        crate::live::undo(&buf, true);
        pump();
        // Tableau 2×3 après le second paragraphe, puis une ligne de plus.
        buf.place_cursor(&buf.end_iter());
        commands::table(&buf, commands::TableEdit::Insert(2, 3));
        pump();
        assert!(commands::in_table(&buf), "le curseur est dans le tableau");
        type_(&buf, "Cellule");
        let d = crate::bridge::document_of(&buf);
        let first = d.paragraphs.iter().find(|p| p.style.table_cell.is_some()).unwrap();
        eprintln!("cellule: {:?} {:?}", first.style.table_cell, first.text());
        assert_eq!(first.text(), "Cellule");
        commands::table(&buf, commands::TableEdit::RowBelow);
        pump();
        let d = crate::bridge::document_of(&buf);
        let cells: Vec<_> = d.paragraphs.iter().filter_map(|p| p.style.table_cell).collect();
        eprintln!("tableau: {} cellules ; tampon : {}", cells.len(), buf_text(&buf));
        assert_eq!(cells.len(), 9);
        // Mise en page : A5 paysage, en-tête.
        let page = letters_core::PageGeometry { width_pt: 595.28, height_pt: 419.53, margin_top_pt: 30.0, margin_bottom_pt: 30.0, margin_left_pt: 40.0, margin_right_pt: 40.0, ..Default::default() };
        commands::set_page(&buf, page, Some("Mon en-tête".into()), None);
        let d = crate::bridge::document_of(&buf);
        assert_eq!(d.page.as_ref().map(|p| p.width_pt as i32), Some(595));
        assert_eq!(d.header.as_deref(), Some("Mon en-tête"));
        // Image : insertion au début, puis taille et recadrage.
        let dir = std::env::temp_dir().join(format!("samizdat-img-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let png = dir.join("carre.png");
        let pb = gtk::gdk_pixbuf::Pixbuf::new(gtk::gdk_pixbuf::Colorspace::Rgb, false, 8, 400, 200).unwrap();
        pb.fill(0x3584e4ff);
        pb.savev(&png, "png", &[]).unwrap();
        buf.place_cursor(&buf.start_iter());
        commands::insert_image(&buf, &png).unwrap();
        pump();
        buf.place_cursor(&buf.start_iter());
        let (seq, run) = commands::image_at_caret(&buf).expect("image au curseur");
        assert_eq!(run.style.image_extent_emu, Some((400 * 9525, 200 * 9525)));
        let (cropped, cw, ch) = commands::crop_image(run.style.image.as_deref().unwrap(), 0.25, 0.0, 0.25, 0.0).unwrap();
        assert_eq!((cw, ch), (200, 200));
        let mut r2 = run.clone();
        r2.style.image = Some(cropped);
        r2.style.image_extent_emu = Some((3 * 360000, 3 * 360000));
        commands::replace_image(&buf, seq, r2);
        pump();
        buf.place_cursor(&buf.start_iter());
        let (_, run) = commands::image_at_caret(&buf).expect("image remplacée");
        assert_eq!(run.style.image_extent_emu, Some((1080000, 1080000)));
        // Aller-retour DOCX et ODT de tout ça.
        let d = crate::bridge::document_of(&buf);
        for ext in ["docx", "odt"] {
            let path = dir.join(format!("t.{ext}"));
            letters_core::save::write(&d, &path).unwrap();
            let back = letters_core::save::read(&path).unwrap();
            let runs: Vec<_> = back.paragraphs.iter().flat_map(|p| p.runs.iter()).collect();
            let img = runs.iter().find(|r| r.style.image.is_some()).unwrap_or_else(|| panic!("{ext} : image perdue"));
            let ext_emu = img.style.image_extent_emu.unwrap();
            assert!((ext_emu.0 as i64 - 1080000).abs() < 20000, "{ext} : taille {ext_emu:?}");
            let bonjour = runs.iter().find(|r| r.text.starts_with("Bonjour")).unwrap();
            assert_eq!(bonjour.style.font_size_hp, Some(36), "{ext}");
            assert_eq!(bonjour.style.font_family.as_deref(), Some("Liberation Serif"), "{ext}");
            assert_eq!(bonjour.style.color.as_deref().map(str::to_uppercase).as_deref(), Some("C01C28"), "{ext}");
            assert!(bonjour.style.highlight, "{ext}");
            assert_eq!(back.paragraphs.iter().filter(|p| p.style.table_cell.is_some()).count(), 9, "{ext}");
            assert!(back.paragraphs.iter().any(|p| p.style.left_indent_pt > 60.0), "{ext} : retrait");
            assert_eq!(back.page.as_ref().map(|p| p.width_pt.round() as i32), Some(595), "{ext}");
            assert_eq!(back.header.as_deref(), Some("Mon en-tête"), "{ext}");
            eprintln!("{ext} : OK");
        }
    }

    /// Enregistrement ODT/DOCX/MD relu à l'identique, et export PDF.
    fn formats() {
        let doc = letters_core::markdown::parse("# Titre\n\nDu **gras** et de l'*italique*.\n\n- un\n- deux\n");
        let dir = std::env::temp_dir().join("samizdat-test-formats");
        std::fs::create_dir_all(&dir).unwrap();
        for ext in ["odt", "docx", "md"] {
            let path = dir.join(format!("t.{ext}"));
            letters_core::save::write(&doc, &path).unwrap();
            let back = letters_core::save::read(&path).unwrap();
            let texts = |d: &letters_core::Document| d.paragraphs.iter().map(|p| p.text()).collect::<Vec<_>>();
            assert_eq!(texts(&back), texts(&doc), "{ext}");
            assert_eq!(back.paragraphs[0].style.heading, Some(1), "{ext}");
        }
        let pdf = dir.join("t.pdf");
        letters_core::layout::pango::Typeset::new(doc, letters_core::layout::LayoutOptions::default()).write_pdf(&pdf).unwrap();
        let bytes = std::fs::read(&pdf).unwrap();
        assert!(bytes.starts_with(b"%PDF"));
        eprintln!("pdf  : {} octets", bytes.len());
    }

    fn typing_and_return() {
        let buf = new_buffer();
        let doc = letters_core::markdown::parse("# Titre\n\nUn paragraphe.\n");
        crate::bridge::load_document(&doc, &buf);
        pump();
        eprintln!("load : buf={} | model={}", buf_text(&buf), model_text(&buf));
        buf.place_cursor(&buf.start_iter());
        type_(&buf, "ab");
        eprintln!("ab   : buf={} | model={}", buf_text(&buf), model_text(&buf));
        type_(&buf, "\n");
        eprintln!("ret  : buf={} | model={}", buf_text(&buf), model_text(&buf));
        type_(&buf, "cd");
        eprintln!("cd   : buf={} | model={}", buf_text(&buf), model_text(&buf));
        let mut end = buf.end_iter();
        buf.place_cursor(&end);
        type_(&buf, "\nfin");
        end = buf.end_iter();
        let _ = end;
        eprintln!("fin  : buf={} | model={}", buf_text(&buf), model_text(&buf));
        assert_eq!(buf_text(&buf).replace("¶", "\n"), model_text(&buf).replace("¶", "\n"));
    }

    fn bold_heading_list_undo() {
        let buf = new_buffer();
        let doc = letters_core::markdown::parse("Premier paragraphe.\n\nSecond.\n");
        crate::bridge::load_document(&doc, &buf);
        pump();
        // Fin du premier paragraphe, Ctrl+B, frappe.
        let mut it = buf.start_iter();
        it.forward_to_line_end();
        buf.place_cursor(&it);
        crate::formatting::toggle_tag_in(&buf, "bold");
        type_(&buf, " gras");
        crate::formatting::toggle_tag_in(&buf, "bold");
        type_(&buf, " normal");
        let d = crate::bridge::document_of(&buf);
        let runs: Vec<(String, bool)> = d.paragraphs[0].runs.iter().map(|r| (r.text.clone(), r.style.bold)).collect();
        eprintln!("runs : {runs:?}");
        assert!(runs.iter().any(|(t, b)| t.contains("gras") && *b));
        assert!(runs.iter().any(|(t, b)| t.contains("normal") && !*b));
        // Titre 2 sur le premier paragraphe, sans bouger le texte.
        set_block_style(&buf, BlockStyle::Heading(2));
        pump();
        type_(&buf, "!");
        eprintln!("titre: buf={} | model={}", buf_text(&buf), model_text(&buf));
        let d = crate::bridge::document_of(&buf);
        assert_eq!(d.paragraphs[0].style.heading, Some(2));
        assert_eq!(d.paragraphs.len(), 2);
        // Entrée au bout du titre : corps de texte.
        let mut it = buf.start_iter();
        it.forward_to_line_end();
        buf.place_cursor(&it);
        type_(&buf, "\nCorps");
        let d = crate::bridge::document_of(&buf);
        eprintln!("corps: {:?} / {:?}", d.paragraphs[0].style.heading, d.paragraphs[1].style.heading);
        assert_eq!((d.paragraphs[0].style.heading, d.paragraphs[1].style.heading), (Some(2), None));
        assert_eq!(d.paragraphs[1].text(), "Corps");
        crate::live::undo(&buf, false);
        crate::live::undo(&buf, false);
        pump();
        assert_eq!(crate::bridge::document_of(&buf).paragraphs.len(), 2, "{}", model_text(&buf));
        // Liste sur le second paragraphe.
        let mut it = buf.end_iter();
        it.backward_char();
        buf.place_cursor(&it);
        toggle_list(&buf, letters_core::ListKind::Bullet);
        pump();
        let d = crate::bridge::document_of(&buf);
        eprintln!("liste: buf={} | list={:?}", buf_text(&buf), d.paragraphs[1].style.list);
        assert_eq!(d.paragraphs[1].style.list, letters_core::ListKind::Bullet);
        // Entrée en fin d'élément de liste : nouvel élément.
        buf.place_cursor(&buf.end_iter());
        type_(&buf, "\nitem 2");
        let d = crate::bridge::document_of(&buf);
        eprintln!("item : buf={} | model={}", buf_text(&buf), model_text(&buf));
        assert_eq!(d.paragraphs.len(), 3);
        assert_eq!(d.paragraphs[2].style.list, letters_core::ListKind::Bullet);
        assert_eq!(buf_text(&buf).replace("¶", "\n").lines().count(), 3);
        // Annuler défait « item 2 ».
        // Annuler défait la frappe mot par mot.
        crate::live::undo(&buf, false);
        crate::live::undo(&buf, false);
        crate::live::undo(&buf, false);
        pump();
        eprintln!("undo : buf={} | model={}", buf_text(&buf), model_text(&buf));
        assert!(!model_text(&buf).contains("item"));
    }
}
