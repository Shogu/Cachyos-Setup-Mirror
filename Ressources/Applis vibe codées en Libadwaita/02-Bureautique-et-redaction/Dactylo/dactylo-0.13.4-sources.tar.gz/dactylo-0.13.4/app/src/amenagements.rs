// amenagements.rs — le PDF aménagé : police adaptée (Luciole,
// OpenDyslexic), grands caractères, interligne aéré, grand contraste, texte
// aligné à gauche. Le document lui-même ne change pas.
// SPDX-License-Identifier: GPL-3.0-or-later

use letters_core::{Alignment, Document};

/// La police du PDF aménagé.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum Font {
    #[default]
    Document,
    Luciole,
    OpenDyslexic,
}

impl Font {
    pub const ALL: [(Font, &'static str); 3] = [(Font::Document, "Celle du document"), (Font::Luciole, "Luciole (basse vision)"), (Font::OpenDyslexic, "OpenDyslexic (dyslexie)")];

    pub fn family(self) -> Option<&'static str> {
        match self {
            Font::Document => None,
            Font::Luciole => Some("Luciole"),
            Font::OpenDyslexic => Some("OpenDyslexic"),
        }
    }
}

/// Les tailles proposées (None : celle du document).
pub const SIZES: [(Option<f64>, &str); 3] = [(None, "Celle du document"), (Some(16.0), "16 points"), (Some(20.0), "20 points")];

/// Les interlignes proposés (None : celui du document).
pub const SPACINGS: [(Option<f32>, &str); 4] = [(None, "Celui du document"), (Some(1.15), "1,15"), (Some(1.5), "1,5"), (Some(2.0), "Double")];

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Options {
    pub font: Font,
    pub size: usize,
    pub spacing: usize,
    pub contrast: bool,
    pub left: bool,
    /// Une ligne sur deux teintée.
    pub tint: bool,
}

impl Options {
    /// Les derniers choix (préférences), sinon : Luciole 16 pt, interligne
    /// 1,5, aligné à gauche.
    pub fn load() -> Self {
        let s = crate::prefs::get().amenagements;
        let v: Vec<&str> = s.split(';').collect();
        if v.len() < 5 {
            return Self { font: Font::Luciole, size: 1, spacing: 2, contrast: false, left: true, tint: false };
        }
        let n = |i: usize, max: usize| v[i].parse::<usize>().unwrap_or(0).min(max - 1);
        Self {
            font: Font::ALL[n(0, Font::ALL.len())].0,
            size: n(1, SIZES.len()),
            spacing: n(2, SPACINGS.len()),
            contrast: v[3] == "1",
            left: v[4] == "1",
            tint: v.get(5) == Some(&"1"),
        }
    }

    pub fn save(&self) {
        let font = Font::ALL.iter().position(|(f, _)| *f == self.font).unwrap_or(0);
        let s = format!("{font};{};{};{};{};{}", self.size, self.spacing, u8::from(self.contrast), u8::from(self.left), u8::from(self.tint));
        crate::prefs::update(|p| p.amenagements = s);
    }
}

/// Aménage `doc` (une copie prête à mettre en page) selon `o`.
pub fn adapt(doc: &mut Document, o: &Options) {
    let base_hp = doc.base_font.size_hp.unwrap_or(24).max(1);
    if let Some(family) = o.font.family() {
        doc.base_font.family = Some(family.to_string());
        for st in &mut doc.heading_styles {
            st.font_family = None;
        }
    }
    let factor = SIZES[o.size].0.map(|pt| (pt * 2.0) / f64::from(base_hp));
    if let Some(f) = factor {
        // Le texte courant grandit à la taille choisie, et tout le reste
        // (titres, tailles explicites) dans la même proportion.
        doc.base_font.size_hp = Some((f64::from(base_hp) * f).round() as u16);
        for st in &mut doc.heading_styles {
            if let Some(hp) = st.font_size_hp.as_mut() {
                *hp = (f64::from(*hp) * f).round() as u16;
            }
        }
    }
    let spacing = SPACINGS[o.spacing].0;
    for p in &mut doc.paragraphs {
        if o.left && p.style.alignment == Alignment::Justify {
            p.style.alignment = Alignment::Left;
        }
        if let Some(ls) = spacing {
            if p.style.toc.is_none() {
                p.style.line_spacing = ls;
            }
        }
        if let Some(f) = factor {
            p.style.space_before_pt *= f;
            p.style.space_after_pt *= f;
        }
        if o.contrast && p.style.table_cell.is_some() {
            let mut look = p.style.cartouche.unwrap_or_default();
            look.white = true;
            if look.line == letters_core::CartoucheLine::Thin {
                look.line = letters_core::CartoucheLine::Medium;
            }
            p.style.cartouche = Some(look);
        }
        for r in &mut p.runs {
            if o.font.family().is_some() && r.style.image.is_none() && !r.style.code {
                r.style.font_family = None;
            }
            if let (Some(f), Some(hp)) = (factor, r.style.font_size_hp.as_mut()) {
                *hp = (f64::from(*hp) * f).round().clamp(2.0, 3276.0) as u16;
            }
            if o.contrast {
                // Du noir sur du blanc : ni couleurs ni gris.
                r.style.color = None;
            }
        }
    }
    if o.contrast {
        for st in &mut doc.heading_styles {
            st.color = None;
        }
    }
}

/// Le nom du PDF aménagé : « Nom (aménagé).pdf ».
pub fn file_name(stem: &str) -> String {
    format!("{stem} (aménagé).pdf")
}

/// Si la police `family` est installée.
pub fn installed(family: &str) -> bool {
    use pangocairo::pango::prelude::*;
    let map = pangocairo::FontMap::new();
    map.list_families().iter().any(|f| f.name().eq_ignore_ascii_case(family))
}

#[cfg(test)]
mod tests {
    use super::*;
    use letters_core::{Paragraph, Run};

    #[test]
    fn adapting_scales_sizes_and_unjustifies() {
        let mut d = Document::new();
        d.base_font.size_hp = Some(24);
        let mut p = Paragraph { style: Default::default(), runs: vec![Run::plain("a")] };
        p.style.alignment = Alignment::Justify;
        p.runs[0].style.font_size_hp = Some(48);
        p.runs[0].style.color = Some("1A5FB4".into());
        d.paragraphs = vec![p];
        let o = Options { font: Font::OpenDyslexic, size: 2, spacing: 3, contrast: true, left: true, tint: true };
        adapt(&mut d, &o);
        assert_eq!(d.base_font.family.as_deref(), Some("OpenDyslexic"));
        assert_eq!(d.base_font.size_hp, Some(40));
        let p = &d.paragraphs[0];
        assert_eq!(p.style.alignment, Alignment::Left);
        assert_eq!(p.style.line_spacing, 2.0);
        assert_eq!(p.runs[0].style.font_size_hp, Some(80));
        assert_eq!(p.runs[0].style.color, None);
        assert_eq!(file_name("Cours"), "Cours (aménagé).pdf");
    }
}
