// window/ocrui.rs — l'OCR dans la fenêtre : le texte d'une capture du
// presse-papier, d'une image ou d'un PDF scanné importé, d'une image du
// document, ou d'une page d'un onglet PDF.
//
// Où va le texte : au curseur dans un document ; sous l'image pour une image
// du document ; dans le presse-papier depuis un onglet PDF (qu'on ne modifie
// pas).
// SPDX-License-Identifier: GPL-3.0-or-later

use super::*;
use crate::ocr::Source;

/// Où mettre le texte reconnu.
pub(super) enum Target {
    Cursor,
    /// Dans un nouveau paragraphe sous l'image à ce décalage du tampon.
    AfterImage(i32),
    Clipboard,
}

impl Window {
    pub(super) fn connect_ocr(self: &Rc<Self>) {
        let add = |name: &str, f: Box<dyn Fn(&Rc<Window>)>| {
            let a = gio::SimpleAction::new(name, None);
            let w = Rc::downgrade(self);
            a.connect_activate(move |_, _| {
                if let Some(w) = w.upgrade() {
                    f(&w);
                }
            });
            self.win.add_action(&a);
        };
        add("ocr-import", Box::new(|w| w.ocr_import()));
        add("ocr-pdf-page", Box::new(|w| w.ocr_pdf(false)));
        add("ocr-pdf-all", Box::new(|w| w.ocr_pdf(true)));
        add("spell-fix-all", Box::new(|w| w.spell_fix_all()));
    }

    /// Après un Ctrl+V d'image : proposer d'en coller plutôt le texte. Le
    /// bouton retire l'image collée (une annulation) et insère son texte, si
    /// rien n'a changé depuis ; sinon l'image reste et le texte s'ajoute.
    pub(super) fn offer_paste_text(self: &Rc<Self>, source: Source) {
        let buf = self.buf();
        let changed = Rc::new(Cell::new(false));
        let handler: Rc<RefCell<Option<glib::SignalHandlerId>>> = Rc::default();
        // Une fois le collage fini (il se termine un peu plus tard).
        {
            let (b, c, h) = (buf.clone(), changed.clone(), handler.clone());
            glib::idle_add_local_once(move || {
                let id = b.connect_changed(move |_| c.set(true));
                *h.borrow_mut() = Some(id);
            });
        }
        let toast = adw::Toast::builder().title("Image collée").button_label("Coller le texte à la place").timeout(8).priority(adw::ToastPriority::High).build();
        {
            let (b, h) = (buf.clone(), handler.clone());
            toast.connect_dismissed(move |_| {
                if let Some(id) = h.borrow_mut().take() {
                    b.disconnect(id);
                }
            });
        }
        let w = Rc::downgrade(self);
        let source = RefCell::new(Some(source));
        toast.connect_button_clicked(move |_| {
            let (Some(w), Some(source)) = (w.upgrade(), source.borrow_mut().take()) else { return };
            if !changed.get() && w.buf() == buf {
                let _ = WidgetExt::activate_action(&w.win, "win.undo", None);
            }
            w.ocr(source, Target::Cursor);
        });
        self.toasts.add_toast(toast);
    }

    /// Une image ou un PDF scanné, choisi sur le disque.
    fn ocr_import(self: &Rc<Self>) {
        let filter = gtk::FileFilter::new();
        filter.set_name(Some("Images et PDF"));
        filter.add_mime_type("image/*");
        filter.add_mime_type("application/pdf");
        let filters = gio::ListStore::new::<gtk::FileFilter>();
        filters.append(&filter);
        let dialog = gtk::FileDialog::builder().title("Texte d'une image ou d'un PDF").accept_label("Lire le texte").filters(&filters).modal(true).build();
        if let Some(dir) = self.initial_folder() {
            dialog.set_initial_folder(Some(&dir));
        }
        let w = Rc::downgrade(self);
        dialog.open(Some(&self.win), gio::Cancellable::NONE, move |r| {
            let (Some(w), Some(path)) = (w.upgrade(), r.ok().and_then(|f| f.path())) else { return };
            w.ocr(Source::File(path), Target::Cursor);
        });
    }

    /// Le texte d'une image du document, ajouté sous elle.
    pub(super) fn ocr_image(self: &Rc<Self>, path: String, offset: i32) {
        self.ocr(Source::File(path.into()), Target::AfterImage(offset));
    }

    /// Onglet PDF : la page affichée, ou tout le document.
    fn ocr_pdf(self: &Rc<Self>, all: bool) {
        let doc = self.doc();
        let (Some(view), Some(path)) = (doc.pdf.clone(), doc.path.borrow().clone()) else { return };
        let source = if all { Source::File(path) } else { Source::PdfPage(path, view.current_page()) };
        self.ocr(source, Target::Clipboard);
    }

    fn ocr(self: &Rc<Self>, source: Source, target: Target) {
        if self.ocr_busy.replace(true) {
            self.toast("Une lecture est déjà en cours");
            return;
        }
        let progress = adw::Toast::builder().title("Lecture du texte…").timeout(0).build();
        self.toasts.add_toast(progress.clone());
        let p2 = progress.clone();
        let w = Rc::downgrade(self);
        crate::ocr::recognize(
            source,
            move |i, n| {
                if n > 1 {
                    p2.set_title(&format!("Lecture du texte : page {i} sur {n}…"));
                }
            },
            move |r| {
                progress.dismiss();
                let Some(w) = w.upgrade() else { return };
                w.ocr_busy.set(false);
                match r {
                    Ok(text) if text.trim().is_empty() => w.toast("Aucun texte reconnu dans cette image"),
                    Ok(text) => w.ocr_deliver(&text, target),
                    Err(e) => w.error("Lecture du texte impossible", &e),
                }
            },
        );
    }

    fn ocr_deliver(&self, text: &str, target: Target) {
        let words = crate::ocr::word_count(text);
        let to_clipboard = matches!(target, Target::Clipboard) || self.doc().is_pdf();
        if to_clipboard {
            self.win.clipboard().set_text(text);
            self.toast(&format!("Texte copié ({words} mots) : Ctrl+V pour le coller"));
            return;
        }
        let buf = self.buf();
        let after_image = match target {
            Target::AfterImage(off) => {
                let mut it = buf.iter_at_offset(off);
                if !it.ends_line() {
                    it.forward_to_line_end();
                }
                buf.place_cursor(&it);
                Some(it.offset())
            }
            _ => None,
        };
        let inserted = if after_image.is_some() { format!("\n{text}") } else { text.to_string() };
        // Comme un collage : le texte passe par le modèle (une étape
        // d'annulation).
        buf.insert_at_cursor(&inserted);
        // Sous une image (centrée, seule sur sa ligne), le texte reprend un
        // alignement à gauche. Après l'insertion, faite elle-même plus tard.
        if let Some(start) = after_image {
            let len = text.chars().count() as i32;
            let b = buf.clone();
            glib::idle_add_local_once(move || {
                let (from, to) = (b.iter_at_offset(start + 1), b.iter_at_offset(start + 1 + len));
                b.select_range(&from, &to);
                crate::formatting::align_in(&b, "align-left");
                b.place_cursor(&b.iter_at_offset(start + 1 + len));
            });
        }
        self.view().grab_focus();
        self.toast(&format!("Texte reconnu : {words} mots (Ctrl+Z pour l'enlever)"));
    }

    /// Remplace chaque mot souligné par la première suggestion, après
    /// confirmation, en une seule étape d'annulation.
    fn spell_fix_all(self: &Rc<Self>) {
        let doc = self.doc();
        if doc.is_pdf() || !doc.spell.available() {
            return;
        }
        let (fixes, left) = doc.spell.corrections(&doc.buf);
        if fixes.is_empty() {
            self.toast(if left > 0 { "Aucune correction proposée par le dictionnaire" } else { "Aucune faute trouvée" });
            return;
        }
        let n = fixes.len();
        let mut body = String::from("Chaque mot souligné est remplacé par la première suggestion du dictionnaire. Les noms propres (majuscule en milieu de phrase) ne sont pas touchés. Ctrl+Z annule tout d'un coup.");
        if left > 0 {
            body.push_str(&format!("\n\n{left} mot{} sans suggestion reste{} souligné{}.", if left > 1 { "s" } else { "" }, if left > 1 { "nt" } else { "" }, if left > 1 { "s" } else { "" }));
        }
        let d = adw::AlertDialog::new(Some(&format!("Corriger {n} mot{} ?", if n > 1 { "s" } else { "" })), Some(&body));
        d.add_response("cancel", "Annuler");
        d.add_response("fix", "Corriger");
        d.set_response_appearance("fix", adw::ResponseAppearance::Suggested);
        d.set_default_response(Some("fix"));
        let w = Rc::downgrade(self);
        d.connect_response(None, move |_, r| {
            if r != "fix" {
                return;
            }
            let Some(w) = w.upgrade() else { return };
            let done = crate::commands::replace_each(&w.buf(), &fixes);
            w.doc().spell.check_buffer(&w.buf());
            w.after_format();
            w.toast(&format!("{done} mot{} corrigé{} (Ctrl+Z pour annuler)", if done > 1 { "s" } else { "" }, if done > 1 { "s" } else { "" }));
        });
        d.present(Some(&self.win));
    }
}
