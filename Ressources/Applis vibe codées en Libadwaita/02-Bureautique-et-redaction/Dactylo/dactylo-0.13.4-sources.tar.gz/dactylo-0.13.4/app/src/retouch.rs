// retouch.rs — retouches d'image et légendes.
//
// Retouches : recadrer, pivoter, retourner, luminosité, contraste, coins
// arrondis, cadre fin. Elles produisent une nouvelle image (PNG) ; l'image
// d'origine n'est jamais modifiée.
//
// Légende : un paragraphe « Caption » sous l'image, centré, sans italique,
// dans la police de l'interface. Numérotée, elle commence par
// « Document 1 — », et les numéros suivent l'ordre du document.
// SPDX-License-Identifier: GPL-3.0-or-later

use gtk4::{self as gtk, gdk_pixbuf::Pixbuf};
use letters_core::edit::{self, Op};
use letters_core::{Alignment, Document, Paragraph, ParaStyle, Run, RunStyle};

/// Les réglages d'une retouche. Recadrage en fraction de chaque côté.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Retouch {
    pub crop: (f64, f64, f64, f64),
    /// Quarts de tour, dans le sens des aiguilles d'une montre.
    pub quarter_turns: u32,
    pub flip_h: bool,
    pub flip_v: bool,
    /// −100 à 100.
    pub brightness: f64,
    pub contrast: f64,
    /// Rayon des coins, en % du petit côté (0 à 25).
    pub radius: f64,
    pub frame: bool,
}

impl Retouch {
    pub fn is_identity(&self) -> bool {
        *self == Self::default()
    }
}

/// Applique `r` à `pb`.
pub fn process(pb: &Pixbuf, r: &Retouch) -> Pixbuf {
    let (l, t, rr, b) = r.crop;
    let mut pb = pb.clone();
    if l + t + rr + b > 0.0 && l + rr < 0.95 && t + b < 0.95 {
        let (w, h) = (pb.width() as f64, pb.height() as f64);
        let x = (w * l).round() as i32;
        let y = (h * t).round() as i32;
        let cw = ((w * (1.0 - l - rr)).round() as i32).clamp(1, pb.width() - x);
        let ch = ((h * (1.0 - t - b)).round() as i32).clamp(1, pb.height() - y);
        pb = pb.new_subpixbuf(x, y, cw, ch).copy().unwrap_or(pb);
    }
    let rotation = match r.quarter_turns % 4 {
        1 => Some(gtk::gdk_pixbuf::PixbufRotation::Clockwise),
        2 => Some(gtk::gdk_pixbuf::PixbufRotation::Upsidedown),
        3 => Some(gtk::gdk_pixbuf::PixbufRotation::Counterclockwise),
        _ => None,
    };
    if let Some(rot) = rotation {
        pb = pb.rotate_simple(rot).unwrap_or(pb);
    }
    if r.flip_h {
        pb = pb.flip(true).unwrap_or(pb);
    }
    if r.flip_v {
        pb = pb.flip(false).unwrap_or(pb);
    }
    if r.brightness != 0.0 || r.contrast != 0.0 {
        pb = tone(&pb, r.brightness, r.contrast);
    }
    if r.radius > 0.0 || r.frame {
        if let Some(out) = round_and_frame(&pb, r.radius, r.frame) {
            pb = out;
        }
    }
    pb
}

/// Luminosité et contraste, pixel par pixel.
fn tone(pb: &Pixbuf, brightness: f64, contrast: f64) -> Pixbuf {
    let pb = pb.add_alpha(false, 0, 0, 0).unwrap_or_else(|_| pb.clone());
    let out = pb.copy().unwrap_or_else(|| pb.clone());
    let c = contrast.clamp(-100.0, 100.0) * 2.55;
    let factor = (259.0 * (c + 255.0)) / (255.0 * (259.0 - c));
    let shift = brightness.clamp(-100.0, 100.0) * 1.28;
    let (w, h, stride, n) = (out.width() as usize, out.height() as usize, out.rowstride() as usize, out.n_channels() as usize);
    let lut: Vec<u8> = (0..256).map(|v| (factor * (v as f64 - 128.0) + 128.0 + shift).round().clamp(0.0, 255.0) as u8).collect();
    unsafe {
        let data = out.pixels();
        for y in 0..h {
            for x in 0..w {
                let i = y * stride + x * n;
                for k in 0..3 {
                    data[i + k] = lut[data[i + k] as usize];
                }
            }
        }
    }
    out
}

/// Coins arrondis (transparents) et cadre fin gris foncé.
fn round_and_frame(pb: &Pixbuf, radius_pct: f64, frame: bool) -> Option<Pixbuf> {
    use gtk::gdk::prelude::GdkCairoContextExt;
    let (w, h) = (pb.width(), pb.height());
    let surface = gtk::cairo::ImageSurface::create(gtk::cairo::Format::ARgb32, w, h).ok()?;
    {
        let cr = gtk::cairo::Context::new(&surface).ok()?;
        let r = (radius_pct / 100.0 * w.min(h) as f64 / 2.0 * 2.0).min(w.min(h) as f64 / 2.0);
        let line = if frame { (w.min(h) as f64 / 180.0).max(2.0) } else { 0.0 };
        let inset = line / 2.0;
        rounded(&cr, inset, inset, w as f64 - line, h as f64 - line, (r - inset).max(0.0));
        cr.save().ok()?;
        cr.clip_preserve();
        cr.set_source_pixbuf(pb, 0.0, 0.0);
        cr.paint().ok()?;
        cr.restore().ok()?;
        if frame {
            cr.set_source_rgba(0.24, 0.22, 0.27, 0.9);
            cr.set_line_width(line);
            cr.stroke().ok()?;
        }
    }
    surface.flush();
    #[allow(deprecated)]
    gtk::gdk::pixbuf_get_from_surface(&surface, 0, 0, w, h)
}

pub fn rounded(cr: &gtk::cairo::Context, x: f64, y: f64, w: f64, h: f64, r: f64) {
    let r = r.min(w / 2.0).min(h / 2.0).max(0.0);
    let pi = std::f64::consts::PI;
    cr.new_sub_path();
    cr.arc(x + w - r, y + r, r, -pi / 2.0, 0.0);
    cr.arc(x + w - r, y + h - r, r, 0.0, pi / 2.0);
    cr.arc(x + r, y + h - r, r, pi / 2.0, pi);
    cr.arc(x + r, y + r, r, pi, 3.0 * pi / 2.0);
    cr.close_path();
}

/// L'image `src` retouchée, enregistrée en PNG dans le cache des images.
pub fn apply(src: &str, r: &Retouch) -> Result<(String, i32, i32), String> {
    let pb = Pixbuf::from_file(src).map_err(|e| e.to_string())?;
    let out = process(&pb, r);
    let path = crate::commands::unique_name("png");
    out.savev(&path, "png", &[]).map_err(|e| e.to_string())?;
    Ok((path.to_string_lossy().to_string(), out.width(), out.height()))
}

// ---- Légendes --------------------------------------------------------------

pub const CAPTION_STYLE: &str = "Caption";
const NUMBER_PREFIX: &str = "Document ";
const NUMBER_SEP: &str = " — ";

pub fn is_caption(p: &Paragraph) -> bool {
    p.style.named_style.as_deref() == Some(CAPTION_STYLE)
}

/// « Document 3 — Texte » → (Some(3), "Texte").
fn split_number(text: &str) -> (Option<u32>, String) {
    if let Some(rest) = text.strip_prefix(NUMBER_PREFIX) {
        if let Some((n, tail)) = rest.split_once(NUMBER_SEP) {
            if let Ok(n) = n.trim().parse() {
                return (Some(n), tail.to_string());
            }
        }
    }
    (None, text.to_string())
}

/// La légende sous le paragraphe `pi` : son texte (sans numéro) et si elle
/// est numérotée.
pub fn caption_of(doc: &Document, pi: usize) -> Option<(String, bool)> {
    let p = doc.paragraphs.get(pi + 1).filter(|p| is_caption(p))?;
    let (n, text) = split_number(&p.text());
    Some((text, n.is_some()))
}

/// La police des légendes : celle de l'interface de GNOME (sans empattement).
fn caption_family() -> Option<String> {
    if !gtk::is_initialized_main_thread() {
        return None;
    }
    let name = gtk::Settings::default()?.gtk_font_name()?;
    gtk::pango::FontDescription::from_string(&name).family().map(|f| f.to_string())
}

pub(crate) fn caption_paragraph(text: &str, number: Option<u32>) -> Paragraph {
    let base = RunStyle { font_size_hp: Some(22), color: Some("3D3846".into()), font_family: caption_family(), ..Default::default() };
    let mut runs = Vec::new();
    if let Some(n) = number {
        runs.push(Run { text: format!("{NUMBER_PREFIX}{n}{NUMBER_SEP}"), style: RunStyle { bold: true, ..base.clone() } });
    }
    runs.push(Run { text: text.trim().to_string(), style: base });
    Paragraph {
        style: ParaStyle { alignment: Alignment::Center, named_style: Some(CAPTION_STYLE.into()), space_after_pt: 12.0, ..Default::default() },
        runs,
    }
}

/// Les opérations qui renumérotent les légendes numérotées dans l'ordre.
fn renumber(doc: &Document) -> Vec<Op> {
    let mut n = 0;
    let mut ops = Vec::new();
    for (i, p) in doc.paragraphs.iter().enumerate() {
        if !is_caption(p) {
            continue;
        }
        let (num, text) = split_number(&p.text());
        if num.is_none() {
            continue;
        }
        n += 1;
        if num != Some(n) {
            ops.push(Op::SetParagraphs { para: i, remove: 1, insert: vec![caption_paragraph(&text, Some(n))] });
        }
    }
    ops
}

/// Pose, change ou retire (texte vide) la légende de l'image au point
/// `seq` du modèle. Une seule étape d'annulation.
pub fn set_caption(buf: &gtk::TextBuffer, seq: usize, text: &str, numbered: bool) {
    let Some(live) = crate::live::of(buf) else { return };
    live.borrow_mut().edit_with(buf, |doc| {
        let Some((pi, _)) = edit::locate(doc, seq) else { return Vec::new() };
        let has = doc.paragraphs.get(pi + 1).is_some_and(is_caption);
        let mut ops = Vec::new();
        if text.trim().is_empty() {
            if has {
                ops.push(Op::SetParagraphs { para: pi + 1, remove: 1, insert: Vec::new() });
            }
        } else {
            // Numéro provisoire : la renumérotation le corrige.
            let para = caption_paragraph(text, numbered.then_some(0));
            ops.push(Op::SetParagraphs { para: pi + 1, remove: usize::from(has), insert: vec![para] });
        }
        let mut scratch = doc.clone();
        if edit::apply_all(&mut scratch, &ops).is_err() {
            return Vec::new();
        }
        ops.extend(renumber(&scratch));
        ops
    });
    crate::live::sync_actions(buf);
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn numbers_and_tone() {
        assert_eq!(split_number("Document 12 — Carte de l'Europe"), (Some(12), "Carte de l'Europe".to_string()));
        assert_eq!(split_number("Une photo"), (None, "Une photo".to_string()));
        let mut doc = Document::from_plain_text("a\nb\nc");
        doc.paragraphs.insert(1, caption_paragraph("Premier", Some(5)));
        doc.paragraphs.push(caption_paragraph("Second", Some(9)));
        let ops = renumber(&doc);
        edit::apply_all(&mut doc, &ops).unwrap();
        assert_eq!(doc.paragraphs[1].text(), "Document 1 — Premier");
        assert_eq!(doc.paragraphs[4].text(), "Document 2 — Second");
        assert_eq!(caption_of(&doc, 0), Some(("Premier".to_string(), true)));
    }
}
