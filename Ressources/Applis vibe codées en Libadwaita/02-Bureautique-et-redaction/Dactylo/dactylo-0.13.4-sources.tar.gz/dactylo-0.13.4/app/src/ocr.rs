// ocr.rs — reconnaissance de texte (Tesseract) : une image, une capture du
// presse-papier ou les pages d'un PDF scanné deviennent du texte propre.
//
// Tesseract tourne dans un processus à part (l'appli ne se fige pas). Les
// petites images sont agrandies et posées sur fond blanc avant la lecture ;
// le texte lu est ensuite recollé en paragraphes (Tesseract coupe chaque
// ligne comme sur l'image), sans les césures de fin de ligne, et mis à la
// typographie française.
// SPDX-License-Identifier: GPL-3.0-or-later

use std::cell::OnceCell;
use std::path::{Path, PathBuf};
use std::rc::Rc;

use gtk4::{self as gtk, gdk, gdk_pixbuf, gio, glib, prelude::*};

/// Ce qu'on donne à lire.
#[derive(Clone)]
pub enum Source {
    /// Une image (PNG, JPEG…) ou un PDF.
    File(PathBuf),
    /// Une image en mémoire (le presse-papier).
    Texture(gdk::Texture),
    /// Une seule page d'un PDF.
    PdfPage(PathBuf, usize),
}

/// Une image plus étroite est agrandie avant la lecture : Tesseract lit mal
/// les petits caractères d'une capture d'écran.
const MIN_WIDTH: i32 = 2000;
/// Résolution de lecture d'une page de PDF.
const PDF_DPI: f64 = 300.0;

thread_local! {
    static LANG: OnceCell<&'static str> = const { OnceCell::new() };
}

/// La langue de lecture : le français s'il est installé (paquet
/// tesseract-data-fra), sinon l'anglais.
fn language() -> &'static str {
    LANG.with(|l| {
        *l.get_or_init(|| {
            let out = std::process::Command::new("tesseract").arg("--list-langs").output();
            match out {
                Ok(o) if String::from_utf8_lossy(&o.stdout).lines().any(|l| l.trim() == "fra") => "fra",
                _ => "eng",
            }
        })
    })
}

/// Tesseract est-il là ?
pub fn available() -> bool {
    glib::find_program_in_path("tesseract").is_some()
}

fn work_dir() -> PathBuf {
    let d = glib::user_cache_dir().join(crate::DIR).join("ocr");
    let _ = std::fs::create_dir_all(&d);
    d
}

fn temp_png(tag: &str) -> PathBuf {
    let n = glib::random_int();
    work_dir().join(format!("{tag}-{}-{n:08x}.png", std::process::id()))
}

/// Une image prête à lire : sur fond blanc (les captures ont souvent de la
/// transparence, que Tesseract voit noire) et assez grande.
fn prepare(pixbuf: &gdk_pixbuf::Pixbuf) -> Result<PathBuf, String> {
    let (w, h) = (pixbuf.width(), pixbuf.height());
    let k = if w < MIN_WIDTH { (MIN_WIDTH as f64 / w.max(1) as f64).min(3.0) } else { 1.0 };
    let (nw, nh) = (((w as f64) * k).round() as i32, ((h as f64) * k).round() as i32);
    let flat = pixbuf
        .composite_color_simple(nw.max(1), nh.max(1), gdk_pixbuf::InterpType::Hyper, 255, 64, 0xffffff, 0xffffff)
        .ok_or("image trop grande")?;
    let out = temp_png("image");
    flat.savev(&out, "png", &[]).map_err(|e| e.to_string())?;
    Ok(out)
}

/// Les pages à lire, une à une : chaque appel prépare l'image de la page `i`.
type PageMaker = Rc<dyn Fn(usize) -> Result<PathBuf, String>>;

/// Les pages d'une source, et combien il y en a.
fn pages(source: Source) -> Result<(PageMaker, usize), String> {
    match source {
        Source::Texture(t) => {
            let path = temp_png("capture");
            t.save_to_png(&path).map_err(|e| e.to_string())?;
            let pb = gdk_pixbuf::Pixbuf::from_file(&path).map_err(|e| e.to_string());
            let _ = std::fs::remove_file(&path);
            let ready = prepare(&pb?)?;
            let cell = std::cell::RefCell::new(Some(ready));
            Ok((Rc::new(move |_| cell.borrow_mut().take().ok_or_else(|| "déjà lue".to_string())), 1))
        }
        Source::PdfPage(path, i) => {
            let doc = crate::pdfview::Document::open(&path)?;
            let ready = render_pdf_page(&doc, i)?;
            let cell = std::cell::RefCell::new(Some(ready));
            Ok((Rc::new(move |_| cell.borrow_mut().take().ok_or_else(|| "déjà lue".to_string())), 1))
        }
        Source::File(path) if is_pdf(&path) => {
            let doc = Rc::new(crate::pdfview::Document::open(&path)?);
            let n = doc.page_count();
            Ok((Rc::new(move |i| render_pdf_page(&doc, i)), n))
        }
        Source::File(path) => {
            let pb = gdk_pixbuf::Pixbuf::from_file(&path).map_err(|_| "Ce fichier n'est pas une image lisible".to_string())?;
            let ready = prepare(&pb)?;
            let cell = std::cell::RefCell::new(Some(ready));
            Ok((Rc::new(move |_| cell.borrow_mut().take().ok_or_else(|| "déjà lue".to_string())), 1))
        }
    }
}

pub fn is_pdf(path: &Path) -> bool {
    path.extension().is_some_and(|e| e.eq_ignore_ascii_case("pdf"))
}

/// La page `i` d'un PDF en image, à 300 points par pouce, sur fond blanc.
pub fn render_pdf_page(doc: &crate::pdfview::Document, i: usize) -> Result<PathBuf, String> {
    let (w, h) = doc.size(i);
    let k = PDF_DPI / 72.0;
    let surface = gtk::cairo::ImageSurface::create(gtk::cairo::Format::Rgb24, (w * k).ceil() as i32, (h * k).ceil() as i32).map_err(|e| e.to_string())?;
    {
        let cr = gtk::cairo::Context::new(&surface).map_err(|e| e.to_string())?;
        cr.set_source_rgb(1.0, 1.0, 1.0);
        cr.paint().map_err(|e| e.to_string())?;
        cr.scale(k, k);
        doc.render(i, &cr);
    }
    let out = temp_png("page");
    let mut f = std::fs::File::create(&out).map_err(|e| e.to_string())?;
    surface.write_to_png(&mut f).map_err(|e| e.to_string())?;
    Ok(out)
}

/// Lit `source` (toutes ses pages) ; `progress(page, total)` avant chaque
/// page, `done` à la fin avec le texte propre.
pub fn recognize(source: Source, progress: impl Fn(usize, usize) + 'static, done: impl FnOnce(Result<String, String>) + 'static) {
    if !available() {
        done(Err("Tesseract n'est pas installé : sudo pacman -S tesseract tesseract-data-fra".into()));
        return;
    }
    let (make, n) = match pages(source) {
        Ok(p) => p,
        Err(e) => return done(Err(e)),
    };
    next_page(make, 0, n, Vec::new(), Rc::new(progress), Box::new(done));
}

fn next_page(make: PageMaker, i: usize, n: usize, mut acc: Vec<String>, progress: Rc<dyn Fn(usize, usize)>, done: Box<dyn FnOnce(Result<String, String>)>) {
    if i >= n {
        let text = acc.iter().map(|t| clean(t)).filter(|t| !t.is_empty()).collect::<Vec<_>>().join("\n");
        done(Ok(text));
        return;
    }
    progress(i + 1, n);
    // Laisser l'interface afficher la progression avant de préparer l'image.
    glib::idle_add_local_once(move || {
        let image = match make(i) {
            Ok(p) => p,
            Err(e) => return done(Err(e)),
        };
        let path = image.clone();
        run_tesseract(&path, move |r| {
            let _ = std::fs::remove_file(&image);
            match r {
                Ok(t) => {
                    acc.push(t);
                    next_page(make, i + 1, n, acc, progress, done);
                }
                Err(e) => done(Err(e)),
            }
        });
    });
}

/// `tesseract image stdout`, sans bloquer l'interface.
fn run_tesseract(image: &Path, done: impl FnOnce(Result<String, String>) + 'static) {
    let args = [image.as_os_str(), "stdout".as_ref(), "-l".as_ref(), language().as_ref(), "--psm".as_ref(), "3".as_ref()];
    let mut argv: Vec<&std::ffi::OsStr> = vec!["tesseract".as_ref()];
    argv.extend(args);
    let proc = match gio::Subprocess::newv(&argv, gio::SubprocessFlags::STDOUT_PIPE | gio::SubprocessFlags::STDERR_PIPE) {
        Ok(p) => p,
        Err(e) => return done(Err(e.to_string())),
    };
    let p2 = proc.clone();
    proc.communicate_utf8_async(None, gio::Cancellable::NONE, move |r| match r {
        Ok((out, err)) => {
            if p2.is_successful() {
                done(Ok(out.map(|s| s.to_string()).unwrap_or_default()))
            } else {
                let msg = err.map(|s| s.to_string()).unwrap_or_default();
                done(Err(msg.lines().rev().find(|l| !l.trim().is_empty()).unwrap_or("échec de Tesseract").to_string()))
            }
        }
        Err(e) => done(Err(e.to_string())),
    });
}

// ---- Nettoyage du texte lu ------------------------------------------------

/// Une ligne qui commence un élément : puce, tiret de dialogue, numéro.
fn starts_item(line: &str) -> bool {
    let mut c = line.chars();
    match c.next() {
        Some('•' | '·' | '▪' | '■' | '●' | '-' | '–' | '—' | '*' | '>') => true,
        Some(d) if d.is_ascii_digit() => {
            let rest: String = line.chars().skip_while(|c| c.is_ascii_digit()).take(2).collect();
            line.chars().take_while(|c| c.is_ascii_digit()).count() <= 2 && (rest.starts_with(". ") || rest.starts_with(") ") || rest.starts_with("° "))
        }
        Some(l) if l.is_ascii_lowercase() => {
            let rest: String = c.take(2).collect();
            rest.starts_with(") ")
        }
        _ => false,
    }
}

/// Fin de phrase.
fn ends_sentence(line: &str) -> bool {
    line.trim_end().ends_with(['.', '!', '?', ':', '»', '"', '”', '…'])
}

/// Recolle les lignes coupées par l'image en paragraphes, retire les
/// césures, garde puces et dialogues à la ligne, et met la typographie
/// française. Les paragraphes sont séparés par un retour à la ligne.
pub fn clean(raw: &str) -> String {
    let raw = raw
        .replace('\u{c}', "\n\n")
        .replace('ﬁ', "fi")
        .replace('ﬂ', "fl")
        .replace('ﬀ', "ff")
        .replace('ﬃ', "ffi")
        .replace('ﬄ', "ffl")
        .replace('\r', "");
    let mut paragraphs: Vec<String> = Vec::new();
    let mut block: Vec<&str> = Vec::new();
    let flush = |block: &mut Vec<&str>, paragraphs: &mut Vec<String>| {
        if block.is_empty() {
            return;
        }
        let widest = block.iter().map(|l| l.chars().count()).max().unwrap_or(0);
        let mut cur = String::new();
        for (k, line) in block.iter().enumerate() {
            if cur.is_empty() {
                cur.push_str(line);
            } else if starts_item(line) {
                paragraphs.push(std::mem::take(&mut cur));
                cur.push_str(line);
            } else {
                let hyphen = cur.ends_with('-') && cur.chars().rev().nth(1).is_some_and(char::is_alphabetic) && line.chars().next().is_some_and(char::is_lowercase);
                if hyphen {
                    cur.pop();
                } else {
                    cur.push(' ');
                }
                cur.push_str(line);
            }
            // Une ligne courte qui finit une phrase finit le paragraphe.
            let short = (line.chars().count() as f64) < widest as f64 * 0.7;
            if k + 1 < block.len() && short && ends_sentence(line) {
                paragraphs.push(std::mem::take(&mut cur));
            }
        }
        if !cur.is_empty() {
            paragraphs.push(cur);
        }
        block.clear();
    };
    for line in raw.lines() {
        let line = line.trim();
        if line.is_empty() {
            flush(&mut block, &mut paragraphs);
        } else {
            block.push(line);
        }
    }
    flush(&mut block, &mut paragraphs);
    paragraphs
        .iter()
        .map(|p| typography(&collapse_spaces(p)))
        .filter(|p| p.chars().any(char::is_alphanumeric))
        .collect::<Vec<_>>()
        .join("\n")
}

fn collapse_spaces(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut space = false;
    for c in s.chars() {
        if c == ' ' || c == '\t' {
            if !space {
                out.push(' ');
            }
            space = true;
        } else {
            out.push(c);
            space = false;
        }
    }
    out.trim().to_string()
}

const NBSP: char = '\u{a0}';
const NNBSP: char = '\u{202f}';

/// Typographie française d'un paragraphe : espaces insécables avant « ; ! ?
/// : », guillemets français, apostrophe typographique, points de suspension.
pub fn typography(s: &str) -> String {
    let chars: Vec<char> = s.replace("...", "…").replace(['“', '”'], "\"").chars().collect();
    let mut out: Vec<char> = Vec::with_capacity(chars.len() + 8);
    let mut open = false;
    for (i, &c) in chars.iter().enumerate() {
        let prev = out.last().copied();
        let next = chars.get(i + 1).copied();
        match c {
            '\'' | '`' => out.push('’'),
            ';' | '!' | '?' => {
                match prev {
                    Some(' ') | Some(NBSP) => {
                        out.pop();
                        out.push(NNBSP);
                    }
                    Some(p) if p.is_alphanumeric() || p == '»' || p == ')' => out.push(NNBSP),
                    _ => {}
                }
                out.push(c);
            }
            // « : » n'a d'espace que si le texte en avait une (heures, liens).
            ':' if matches!(prev, Some(' ')) => {
                out.pop();
                out.push(NBSP);
                out.push(':');
            }
            '"' => {
                if open {
                    if matches!(prev, Some(' ')) {
                        out.pop();
                    }
                    out.push(NBSP);
                    out.push('»');
                } else {
                    out.push('«');
                    out.push(NBSP);
                }
                open = !open;
            }
            '«' => {
                out.push('«');
                if next != Some(NBSP) {
                    out.push(NBSP);
                }
                open = true;
            }
            '»' => {
                match prev {
                    Some(' ') => {
                        out.pop();
                        out.push(NBSP);
                    }
                    Some(NBSP) => {}
                    _ => out.push(NBSP),
                }
                out.push('»');
                open = false;
            }
            ' ' if prev == Some(NBSP) || prev == Some(NNBSP) => {}
            _ => out.push(c),
        }
    }
    out.into_iter().collect()
}

/// Nombre de mots, pour le message de fin.
pub fn word_count(s: &str) -> usize {
    s.split_whitespace().filter(|w| w.chars().any(char::is_alphanumeric)).count()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn lines_become_paragraphs_without_hyphens() {
        let raw = "Le jeu des puissances dans les relations inter-\nnationales depuis 1945 est marqué par la\nguerre froide.\nUne autre idée commence ici et continue\nsur la ligne suivante.\n\n- un élément\n- un autre";
        let out = clean(raw);
        let paras: Vec<&str> = out.lines().collect();
        assert_eq!(paras[0], "Le jeu des puissances dans les relations internationales depuis 1945 est marqué par la guerre froide.");
        assert_eq!(paras[1], "Une autre idée commence ici et continue sur la ligne suivante.");
        assert_eq!(paras[2], "- un élément");
        assert_eq!(paras[3], "- un autre");
    }

    #[test]
    fn french_typography() {
        assert_eq!(typography("Pourquoi ? C'est \"vrai\" : oui!"), "Pourquoi\u{202f}? C’est «\u{a0}vrai\u{a0}»\u{a0}: oui\u{202f}!");
        assert_eq!(typography("à 10:30 sur http://x.fr"), "à 10:30 sur http://x.fr");
        assert_eq!(typography("« Liberté »"), "«\u{a0}Liberté\u{a0}»");
    }
}
