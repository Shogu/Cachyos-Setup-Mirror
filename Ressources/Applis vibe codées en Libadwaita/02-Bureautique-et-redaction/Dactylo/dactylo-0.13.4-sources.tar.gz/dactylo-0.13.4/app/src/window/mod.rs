// window/mod.rs — fenêtre principale.
//
// Barre de titre : fichier (plan, ouvrir + récents, nouveau), rechercher,
// enregistrer (bouton scindé), menu. Barre du haut : tout ce qui modifie le
// texte. Barre du bas : orthographe, mise en page, colonnes, aperçu, zoom.
// Quand la fenêtre rétrécit, des groupes se replient en un bouton à menu.
// SPDX-License-Identifier: GPL-3.0-or-later

use std::cell::{Cell, RefCell};
use std::path::{Path, PathBuf};
use std::rc::Rc;

use gtk4::{self as gtk, gio, glib, prelude::*};
use libadwaita::{self as adw, prelude::*};
use letters_core::{Alignment, ListKind};

use crate::editor::{self, BlockStyle, BLOCK_STYLES};

mod access;
mod actions;
mod doc;
mod files;
mod popovers;
mod livepane;
mod ocrui;
mod tabs;

pub use actions::set_accels;
pub use doc::Doc;
use files::*;
pub use tabs::{active, all_windows, create};

/// Couleurs du texte (palette GNOME), « RRGGBB ».
const PALETTE: [(&str, &str); 10] = [
    ("000000", "Noir"),
    ("5E5C64", "Gris"),
    ("C01C28", "Rouge"),
    ("E66100", "Orange"),
    ("E5A50A", "Jaune foncé"),
    ("26A269", "Vert"),
    ("1C71D8", "Bleu"),
    ("613583", "Violet"),
    ("865E3C", "Marron"),
    ("FFFFFF", "Blanc"),
];

/// Couleurs de surlignage : vives, et reconnues comme surlignage par Word
/// pour les quatre premières.
const HIGHLIGHTS: [(&str, &str); 6] = [
    ("FFFF00", "Jaune"),
    ("00FF00", "Vert"),
    ("00FFFF", "Turquoise"),
    ("FF00FF", "Rose"),
    ("FFA500", "Orange"),
    ("C8A2FF", "Lilas"),
];

/// Couleurs proposées pour les formes.
const SHAPE_COLORS: [&str; 7] = ["3584E4", "2EC27E", "F6D32D", "E66100", "E01B24", "9141AC", crate::shapes::TRANSPARENT];

const ZOOM_STEPS: [f64; 9] = [0.5, 0.67, 0.8, 0.9, 1.0, 1.1, 1.25, 1.5, 2.0];
const PAGE_WIDTH: f64 = 840.0;
/// Interlignes proposés (libellé, valeur de l'action win.line-spacing).
const LINE_SPACINGS: [(&str, &str); 4] = [("Simple", "1"), ("1,15", "1.15"), ("1,5", "1.5"), ("Double", "2")];
/// L'espace que l'éditeur laisse sous un paragraphe (6 px), en points.
const EDITOR_SPACE_AFTER_PT: f64 = 4.5;
/// Taille du texte sans réglage (12 pt, en demi-points), comme la feuille.
const DEFAULT_SIZE_HP: u16 = 24;

fn hex_rgb(hex: &str) -> (f64, f64, f64) {
    let v = u32::from_str_radix(hex.trim_start_matches('#'), 16).unwrap_or(0);
    (((v >> 16) & 255) as f64 / 255.0, ((v >> 8) & 255) as f64 / 255.0, (v & 255) as f64 / 255.0)
}

fn paint_swatch(cr: &gtk::cairo::Context, hex: Option<&str>, w: i32, h: i32) {
    if hex == Some(crate::shapes::TRANSPARENT) {
        // Transparent : blanc barré de rouge.
        cr.rectangle(0.0, 0.0, w as f64, h as f64);
        cr.set_source_rgb(1.0, 1.0, 1.0);
        let _ = cr.fill_preserve();
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.25);
        cr.set_line_width(1.0);
        let _ = cr.stroke();
        cr.move_to(w as f64, 0.0);
        cr.line_to(0.0, h as f64);
        cr.set_source_rgb(0.88, 0.11, 0.14);
        cr.set_line_width(1.5);
        let _ = cr.stroke();
        return;
    }
    let (r, g, b) = hex.map(hex_rgb).unwrap_or((0.12, 0.12, 0.12));
    cr.rectangle(0.0, 0.0, w as f64, h as f64);
    cr.set_source_rgb(r, g, b);
    let _ = cr.fill_preserve();
    cr.set_source_rgba(0.0, 0.0, 0.0, 0.25);
    cr.set_line_width(1.0);
    let _ = cr.stroke();
}

fn swatch(hex: Option<&str>, w: i32, h: i32) -> gtk::DrawingArea {
    let area = gtk::DrawingArea::builder().content_width(w).content_height(h).build();
    let hex = hex.map(str::to_string);
    area.set_draw_func(move |_, cr, w, h| paint_swatch(cr, hex.as_deref(), w, h));
    area
}

fn icon_toggle(icon: &str, tooltip: &str) -> gtk::ToggleButton {
    let b = gtk::ToggleButton::builder().icon_name(icon).tooltip_text(tooltip).build();
    b.add_css_class("flat");
    b
}

fn icon_button(icon: &str, action: &str, tooltip: &str) -> gtk::Button {
    let b = gtk::Button::builder().icon_name(icon).action_name(action).tooltip_text(tooltip).build();
    b.add_css_class("flat");
    b
}

fn hbox(children: &[&gtk::Widget], linked: bool) -> gtk::Box {
    let b = gtk::Box::new(gtk::Orientation::Horizontal, if linked { 0 } else { 2 });
    if linked {
        b.add_css_class("linked");
    }
    for w in children {
        b.append(*w);
    }
    b
}

fn sep() -> gtk::Separator {
    let s = gtk::Separator::new(gtk::Orientation::Vertical);
    s.set_margin_top(6);
    s.set_margin_bottom(6);
    s
}

pub struct Window {
    pub win: adw::ApplicationWindow,
    /// Les onglets ; chaque contenu porte son document (`Doc::of`).
    tab_view: adw::TabView,
    /// Le document de l'onglet affiché.
    current: RefCell<Rc<Doc>>,
    toc_btn: gtk::Button,
    title: adw::WindowTitle,
    toasts: adw::ToastOverlay,
    /// Pendant la mise à jour de la barre d'outils depuis le curseur : les
    /// boutons ne doivent pas reformater le texte.
    syncing: Cell<bool>,
    force_close: Cell<bool>,
    styles: gtk::MenuButton,
    indent_btn: gtk::ToggleButton,
    toggles: Vec<(&'static str, gtk::ToggleButton)>,
    lists: Vec<(ListKind, gtk::ToggleButton)>,
    align_btn: adw::SplitButton,
    font_label: gtk::Label,
    size_spin: gtk::SpinButton,
    color: Rc<RefCell<Option<String>>>,
    color_bar: gtk::DrawingArea,
    highlight: Rc<RefCell<String>>,
    hl_css: gtk::CssProvider,
    search: Rc<crate::search::SearchBar>,
    split: adw::OverlaySplitView,
    outline: gtk::ListBox,
    outline_pending: Cell<bool>,
    open_btn: adw::SplitButton,
    new_btn: adw::SplitButton,
    templates_monitor: RefCell<Option<gio::FileMonitor>>,
    spell_btn: gtk::ToggleButton,
    zoom_label: gtk::Label,
    columns_btns: Vec<gtk::ToggleButton>,
    base_menu: gio::Menu,
    /// Ce qui ne sert qu'aux documents texte (caché sur un PDF).
    text_only: Vec<gtk::Widget>,
    /// Les boutons qu'on peut masquer (préférences), par clé.
    tools: Vec<(&'static str, gtk::Widget)>,
    /// Mode concentration : plein écran, barres cachées, ligne au milieu.
    focus: Cell<bool>,
    main_tv: adw::ToolbarView,
    content_tv: adw::ToolbarView,
    focus_exit: gtk::Button,
    /// Aperçu en direct, à droite du texte.
    live: Rc<crate::livepreview::LivePreview>,
    live_paned: gtk::Paned,
    stage: gtk::Overlay,
    preview_btn: adw::SplitButton,
    live_on: Cell<bool>,
    /// Fenêtre étroite : l'aperçu passe par-dessus le texte.
    narrow: Cell<bool>,
    /// Chaque modification du texte : l'aperçu attend la fin de la frappe.
    live_gen: Cell<u64>,
    live_stale: Cell<bool>,
    /// Le texte lu du tampon et où commence chaque paragraphe : pour passer
    /// d'un point de l'aperçu au tampon, et retour.
    live_map: RefCell<Option<(letters_core::Document, Vec<usize>)>>,
    /// La séparation est placée : un déplacement vient de l'utilisateur.
    live_ready: Rc<Cell<bool>>,
    narrow_points: Vec<adw::Breakpoint>,
    /// Une lecture OCR en cours.
    ocr_busy: Cell<bool>,
    /// Onglet PDF : lire le texte d'une page scannée.
    ocr_pdf_btn: gtk::MenuButton,
    /// La règle graduée (au-dessus de la page).
    ruler: Rc<crate::ruler::Ruler>,
}

impl Window {
    fn new(app: &adw::Application) -> Rc<Self> {
        // Les onglets, dans les notifications.
        let tab_view = adw::TabView::new();
        // Ctrl+Début / Ctrl+Fin restent au texte (début et fin du document).
        tab_view.remove_shortcuts(adw::TabViewShortcuts::CONTROL_HOME | adw::TabViewShortcuts::CONTROL_END | adw::TabViewShortcuts::CONTROL_SHIFT_HOME | adw::TabViewShortcuts::CONTROL_SHIFT_END);
        let toasts = adw::ToastOverlay::new();
        let live = crate::livepreview::LivePreview::new();
        let live_paned = gtk::Paned::builder()
            .orientation(gtk::Orientation::Horizontal)
            .start_child(&tab_view)
            .resize_start_child(true)
            .shrink_start_child(false)
            .resize_end_child(false)
            .shrink_end_child(false)
            .build();
        toasts.set_child(Some(&live_paned));
        let tab_bar = adw::TabBar::builder().view(&tab_view).autohide(true).build();

        // ---- Barre de titre ----
        let title = adw::WindowTitle::new("Nouveau document", "");
        let header = adw::HeaderBar::new();
        header.set_title_widget(Some(&title));
        let outline_btn = gtk::ToggleButton::builder().icon_name("sidebar-show-symbolic").tooltip_text("Plan du document (F9)").build();
        let open_btn = adw::SplitButton::builder().icon_name("document-open-symbolic").action_name("win.open").tooltip_text("Ouvrir un document (Ctrl+O)").dropdown_tooltip("Documents récents").build();
        let new_btn = adw::SplitButton::builder().icon_name("tab-new-symbolic").action_name("app.new").tooltip_text("Nouvel onglet (Ctrl+T)").dropdown_tooltip("Modèles").build();
        header.pack_start(&outline_btn);
        header.pack_start(&open_btn);
        header.pack_start(&new_btn);

        let menu = gio::Menu::new();
        menu.append(Some("Préférences"), Some("app.preferences"));
        menu.append(Some("À propos de Dactylo"), Some("app.about"));
        let menu_btn = gtk::MenuButton::builder().icon_name("open-menu-symbolic").menu_model(&menu).tooltip_text("Menu principal").primary(true).build();
        header.pack_end(&menu_btn);
        let save_menu = gio::Menu::new();
        save_menu.append(Some("Enregistrer sous…"), Some("win.save-as"));
        save_menu.append(Some("Enregistrer comme modèle…"), Some("win.save-template"));
        let save_btn = adw::SplitButton::builder().icon_name("document-save-symbolic").action_name("win.save").menu_model(&save_menu).tooltip_text("Enregistrer (Ctrl+S)").dropdown_tooltip("Enregistrer sous, comme modèle").build();
        // Exporter : le PDF d'un clic, les autres exports dans la flèche.
        let export_menu = gio::Menu::new();
        let both = gio::Menu::new();
        both.append(Some("Enregistrer en DOCX et PDF…"), Some("win.save-both"));
        export_menu.append_section(None, &both);
        let more = gio::Menu::new();
        more.append(Some("Créer un livret de séquence…"), Some("win.livret"));
        more.append(Some("Copier sur une clé USB…"), Some("win.export-usb"));
        export_menu.append_section(None, &more);
        let export_btn = adw::SplitButton::builder().icon_name("samizdat-export-symbolic").action_name("win.export-pdf").menu_model(&export_menu).tooltip_text("Exporter en PDF (Ctrl+E)").dropdown_tooltip("Autres exports : DOCX et PDF, livret, clé USB").build();
        header.pack_end(&export_btn);
        header.pack_end(&save_btn);
        let find_btn = gtk::Button::builder().icon_name("edit-find-symbolic").action_name("win.find").tooltip_text("Rechercher (Ctrl+F)").build();
        header.pack_end(&find_btn);
        // Vue d'ensemble des onglets (miniatures), quand il y en a plusieurs.
        let tab_btn = adw::TabButton::builder().view(&tab_view).action_name("overview.open").tooltip_text("Tous les onglets").visible(false).build();
        header.pack_end(&tab_btn);
        tab_view.connect_n_pages_notify({
            let b = tab_btn.clone();
            move |v| b.set_visible(v.n_pages() > 1)
        });

        // ---- Barre du haut : le texte ----
        let undo = icon_button("edit-undo-symbolic", "win.undo", "Annuler (Ctrl+Z)");
        let redo = icon_button("edit-redo-symbolic", "win.redo", "Rétablir (Ctrl+Maj+Z)");
        // Annuler et Rétablir au bord gauche de la barre d'outils ; la mise
        // en forme reste centrée (barre en trois parties ci-dessous).
        let undo_box = hbox(&[undo.upcast_ref(), redo.upcast_ref()], false);
        undo_box.set_margin_start(6);
        undo_box.set_margin_end(12);
        // Le style du paragraphe : une icône (¶) et son menu ; l'infobulle
        // dit le style du curseur, le menu le coche.
        let styles_menu = gio::Menu::new();
        for (i, (_, label)) in BLOCK_STYLES.iter().enumerate() {
            let shortcut = if (1..=3).contains(&i) { format!("    Ctrl+{i}") } else { String::new() };
            let item = gio::MenuItem::new(Some(&format!("{label}{shortcut}")), None);
            item.set_action_and_target_value(Some("win.paragraph-style"), Some(&i.to_string().to_variant()));
            styles_menu.append_item(&item);
        }
        let styles = gtk::MenuButton::builder().icon_name("samizdat-style-symbolic").menu_model(&styles_menu).tooltip_text("Style du paragraphe : Corps de texte").build();
        styles.add_css_class("flat");
        let font_label = gtk::Label::builder().label("Sans").ellipsize(gtk::pango::EllipsizeMode::End).width_chars(12).max_width_chars(12).xalign(0.0).build();
        let font_box = gtk::Box::new(gtk::Orientation::Horizontal, 6);
        font_box.append(&font_label);
        font_box.append(&gtk::Image::from_icon_name("pan-down-symbolic"));
        let font_btn = gtk::Button::builder().child(&font_box).tooltip_text("Police").build();
        let size_spin = gtk::SpinButton::with_range(4.0, 144.0, 1.0);
        size_spin.set_digits(0);
        size_spin.set_value(DEFAULT_SIZE_HP as f64 / 2.0);
        size_spin.set_tooltip_text(Some("Taille (pt)"));
        size_spin.set_valign(gtk::Align::Center);

        let bold = icon_toggle("format-text-bold-symbolic", "Gras (Ctrl+B)");
        let italic = icon_toggle("format-text-italic-symbolic", "Italique (Ctrl+I)");
        let underline = icon_toggle("format-text-underline-symbolic", "Souligné (Ctrl+U)");
        let strike = icon_toggle("format-text-strikethrough-symbolic", "Barré");
        let biu = hbox(&[bold.upcast_ref(), italic.upcast_ref(), underline.upcast_ref(), strike.upcast_ref()], true);

        // Couleur du texte : bouton scindé, « A » souligné de la couleur.
        let color: Rc<RefCell<Option<String>>> = Rc::new(RefCell::new(Some("C01C28".into())));
        let color_bar = gtk::DrawingArea::builder().content_width(16).content_height(4).build();
        {
            let c = color.clone();
            color_bar.set_draw_func(move |_, cr, w, h| paint_swatch(cr, c.borrow().as_deref(), w, h));
        }
        let a_label = gtk::Label::new(Some("A"));
        a_label.add_css_class("heading");
        let a_box = gtk::Box::new(gtk::Orientation::Vertical, 1);
        a_box.append(&a_label);
        a_box.append(&color_bar);
        a_box.set_valign(gtk::Align::Center);
        let color_pop = gtk::Popover::new();
        let color_btn = adw::SplitButton::builder().child(&a_box).popover(&color_pop).tooltip_text("Couleur du texte").dropdown_tooltip("Choisir la couleur").build();

        // Surlignage : bouton scindé, « ab » sur la couleur courante.
        let highlight: Rc<RefCell<String>> = Rc::new(RefCell::new("FFFF00".into()));
        let hl_label = gtk::Label::new(Some("ab"));
        hl_label.add_css_class("samizdat-highlight-label");
        let hl_css = gtk::CssProvider::new();
        #[allow(deprecated)]
        hl_label.style_context().add_provider(&hl_css, gtk::STYLE_PROVIDER_PRIORITY_APPLICATION + 3);
        let hl_pop = gtk::Popover::new();
        let hl_btn = adw::SplitButton::builder().child(&hl_label).popover(&hl_pop).tooltip_text("Surligner").dropdown_tooltip("Choisir la couleur de surlignage").build();
        for b in [&color_btn, &hl_btn] {
            b.add_css_class("flat");
        }

        // Paragraphe : alignement (un bouton à menu), listes, retraits.
        let align_menu = gio::Menu::new();
        let align_section = gio::Menu::new();
        for (label, target) in [("À droite", "right"), ("À gauche", "left"), ("Centré", "center")] {
            let item = gio::MenuItem::new(Some(label), None);
            item.set_action_and_target_value(Some("win.align"), Some(&target.to_variant()));
            align_section.append_item(&item);
        }
        align_menu.append_section(None, &align_section);
        let spacing_section = gio::Menu::new();
        for (label, target) in LINE_SPACINGS {
            let item = gio::MenuItem::new(Some(label), None);
            item.set_action_and_target_value(Some("win.line-spacing"), Some(&target.to_variant()));
            spacing_section.append_item(&item);
        }
        align_menu.append_section(Some("Interligne"), &spacing_section);
        let study_section = gio::Menu::new();
        study_section.append(Some("Numéroter les lignes (5, 10, 15…)"), Some("win.toggle-line-numbers"));
        align_menu.append_section(None, &study_section);
        // Un bouton scindé : « Justifier » d'un clic ; sa flèche propose à
        // droite, à gauche, centré, puis l'interligne et les lignes numérotées.
        let align_btn = adw::SplitButton::builder()
            .icon_name("format-justify-fill-symbolic")
            .menu_model(&align_menu)
            .tooltip_text("Justifier")
            .dropdown_tooltip("Alignement et interligne")
            .build();
        align_btn.set_action_name(Some("win.align"));
        align_btn.set_action_target_value(Some(&"justify".to_variant()));
        align_btn.add_css_class("flat");
        let align_group = hbox(&[align_btn.upcast_ref()], false);
        let bullets = icon_toggle("view-list-bullet-symbolic", "Liste à puces");
        let numbers = icon_toggle("view-list-ordered-symbolic", "Liste numérotée");
        // Un seul bouton de retrait : il met ou enlève le retrait (enfoncé
        // quand le paragraphe en a un).
        let indent_btn = gtk::ToggleButton::builder().icon_name("format-indent-more-symbolic").tooltip_text("Retrait : le mettre ou l'enlever (Tab et Maj+Tab dans une liste)").build();
        indent_btn.add_css_class("flat");
        let para_group = hbox(&[bullets.upcast_ref(), numbers.upcast_ref(), indent_btn.upcast_ref()], false);

        // Insertion.
        let ins_image = icon_button("samizdat-image-symbolic", "win.insert-image", "Insérer une image");
        let ins_table = icon_button("samizdat-table-symbolic", "win.insert-table", "Insérer un tableau");
        let cartouche_pop = gtk::Popover::new();
        let ins_text = gtk::MenuButton::builder().icon_name("samizdat-textbox-symbolic").popover(&cartouche_pop).tooltip_text("Insérer un cartouche (encadrer la sélection)").build();
        ins_text.add_css_class("flat");
        let shapes_pop = gtk::Popover::new();
        let ins_shape = gtk::MenuButton::builder().icon_name("samizdat-shapes-symbolic").popover(&shapes_pop).tooltip_text("Insérer une forme").build();
        ins_shape.add_css_class("flat");
        let ins_frise = icon_button("samizdat-timeline-symbolic", "win.insert-frise", "Insérer une frise chronologique");
        // OCR : le texte d'une image ou d'un PDF scanné, inséré au curseur
        // (le texte d'une capture se propose au Ctrl+V).
        let ins_ocr = icon_button("samizdat-ocr-symbolic", "win.ocr-import", "Insérer le texte d'une image ou d'un PDF scanné (OCR)");
        let ins_link = icon_button("samizdat-link-symbolic", "win.insert-link", "Insérer un lien");
        let insert_group = hbox(&[ins_image.upcast_ref(), ins_ocr.upcast_ref(), ins_table.upcast_ref(), ins_text.upcast_ref(), ins_link.upcast_ref()], false);

        // Groupes repliés (fenêtre étroite).
        let text_menu = gio::Menu::new();
        for (label, action) in [("Gras", "win.toggle-bold"), ("Italique", "win.toggle-italic"), ("Souligné", "win.toggle-underline"), ("Barré", "win.toggle-strikethrough")] {
            text_menu.append(Some(label), Some(action));
        }
        let text_collapsed = gtk::MenuButton::builder().icon_name("format-text-bold-symbolic").menu_model(&text_menu).tooltip_text("Mise en forme").visible(false).build();
        let para_menu = gio::Menu::new();
        for (label, action) in [("Liste à puces", "win.toggle-bullets"), ("Liste numérotée", "win.toggle-numbers"), ("Retrait (mettre ou enlever)", "win.indent-toggle")] {
            para_menu.append(Some(label), Some(action));
        }
        let para_collapsed = gtk::MenuButton::builder().icon_name("view-list-bullet-symbolic").menu_model(&para_menu).tooltip_text("Listes et retraits").visible(false).build();
        let insert_menu = gio::Menu::new();
        for (label, action) in [("Insérer une image…", "win.insert-image"), ("Insérer le texte d'une image (OCR)…", "win.ocr-import"), ("Insérer un tableau…", "win.insert-table"), ("Insérer un cartouche", "win.cartouche-default"), ("Insérer une frise…", "win.insert-frise"), ("Insérer un lien…", "win.insert-link")] {
            insert_menu.append(Some(label), Some(action));
        }
        let insert_collapsed = gtk::MenuButton::builder().icon_name("list-add-symbolic").menu_model(&insert_menu).tooltip_text("Insérer").visible(false).build();
        for b in [&text_collapsed, &para_collapsed, &insert_collapsed] {
            b.add_css_class("flat");
        }

        let bar = gtk::Box::new(gtk::Orientation::Horizontal, 4);
        bar.add_css_class("toolbar");
        bar.set_halign(gtk::Align::Center);
        bar.append(&styles);
        bar.append(&font_btn);
        bar.append(&size_spin);
        bar.append(&sep());
        bar.append(&biu);
        bar.append(&text_collapsed);
        bar.append(&color_btn);
        bar.append(&hl_btn);
        bar.append(&sep());
        bar.append(&align_group);
        bar.append(&para_group);
        bar.append(&para_collapsed);
        bar.append(&sep());
        bar.append(&insert_group);
        bar.append(&insert_collapsed);
        bar.append(&ins_shape);
        bar.append(&ins_frise);
        let bar_row = gtk::CenterBox::new();
        bar_row.set_start_widget(Some(&undo_box));
        bar_row.set_center_widget(Some(&bar));
        let bar_scroll = gtk::ScrolledWindow::builder().vscrollbar_policy(gtk::PolicyType::Never).hscrollbar_policy(gtk::PolicyType::Automatic).propagate_natural_height(true).child(&bar_row).build();

        // ---- Barre du bas : la page et l'affichage ----
        // Barre du bas en icônes seules : le libellé passe dans l'infobulle.
        let spell_btn = gtk::ToggleButton::builder().active(true).icon_name("samizdat-spell-symbolic").tooltip_text("Orthographe : vérification pendant la frappe").build();
        spell_btn.add_css_class("flat");
        // La flèche : corriger d'un coup tout le document.
        let spell_menu = gio::Menu::new();
        spell_menu.append(Some("Corriger tout le document"), Some("win.spell-fix-all"));
        let spell_more = gtk::MenuButton::builder().menu_model(&spell_menu).direction(gtk::ArrowType::Up).tooltip_text("Plus d'options d'orthographe").build();
        spell_more.add_css_class("flat");
        let spell_box = gtk::Box::new(gtk::Orientation::Horizontal, 0);
        spell_box.append(&spell_btn);
        spell_box.append(&spell_more);
        let page_btn = gtk::Button::builder().action_name("win.page-setup").icon_name("document-page-setup-symbolic").tooltip_text("Mise en page : format du papier, marges, en-tête et pied de page").build();
        page_btn.add_css_class("flat");
        let columns_pop = gtk::Popover::builder().position(gtk::PositionType::Top).build();
        let columns_btn = gtk::MenuButton::builder().popover(&columns_pop).icon_name("samizdat-columns-symbolic").tooltip_text("Colonnes du document").build();
        columns_btn.add_css_class("flat");
        columns_btn.set_direction(gtk::ArrowType::Up);
        let preview_menu = gio::Menu::new();
        preview_menu.append(Some("Aperçu en grand"), Some("win.preview"));
        let preview_btn = adw::SplitButton::builder()
            .action_name("win.live-preview")
            .menu_model(&preview_menu)
            .icon_name("samizdat-preview-symbolic")
            .tooltip_text("Aperçu en direct, à droite du texte (F12)")
            .dropdown_tooltip("Autres aperçus")
            .direction(gtk::ArrowType::Up)
            .build();
        preview_btn.add_css_class("flat");
        let zoom_pop = gtk::Popover::builder().position(gtk::PositionType::Top).build();
        let zoom_btn = gtk::MenuButton::builder().icon_name("samizdat-zoom-symbolic").popover(&zoom_pop).tooltip_text("Zoom").build();
        zoom_btn.add_css_class("flat");
        zoom_btn.set_direction(gtk::ArrowType::Up);
        let zoom_label = gtk::Label::builder().label("100 %").width_chars(6).build();
        zoom_label.add_css_class("numeric");

        let ocr_pdf_menu = gio::Menu::new();
        ocr_pdf_menu.append(Some("Texte de cette page"), Some("win.ocr-pdf-page"));
        ocr_pdf_menu.append(Some("Texte de tout le document"), Some("win.ocr-pdf-all"));
        let ocr_pdf_btn = gtk::MenuButton::builder().menu_model(&ocr_pdf_menu).tooltip_text("PDF scanné : reconnaître le texte (OCR) et le copier dans le presse-papier").direction(gtk::ArrowType::Up).visible(false).build();
        ocr_pdf_btn.set_child(Some(&adw::ButtonContent::builder().icon_name("samizdat-ocr-symbolic").label("Texte (OCR)").build()));
        ocr_pdf_btn.add_css_class("flat");
        let bottom = gtk::CenterBox::new();
        bottom.add_css_class("toolbar");
        bottom.set_start_widget(Some(&spell_box));
        let access_btn = gtk::Button::builder().icon_name("samizdat-accessibility-symbolic").action_name("win.amenagements").tooltip_text("Aménagements : un PDF adapté (police, taille, interligne, contraste)").build();
        access_btn.add_css_class("flat");
        let focus_btn = gtk::Button::builder().icon_name("samizdat-focus-symbolic").action_name("win.focus-mode").tooltip_text("Mode concentration (F11)").build();
        focus_btn.add_css_class("flat");
        let bottom_sep = sep();
        let ruler_btn = gtk::ToggleButton::builder().icon_name("samizdat-ruler-symbolic").action_name("win.ruler").tooltip_text("Règle graduée (Ctrl+R)").build();
        ruler_btn.add_css_class("flat");
        let right = hbox(&[ocr_pdf_btn.upcast_ref(), ruler_btn.upcast_ref(), page_btn.upcast_ref(), columns_btn.upcast_ref(), bottom_sep.upcast_ref(), preview_btn.upcast_ref(), access_btn.upcast_ref(), focus_btn.upcast_ref(), zoom_btn.upcast_ref()], false);
        bottom.set_end_widget(Some(&right));

        let toast_target = toasts.downgrade();
        let first = Doc::text();
        let search = crate::search::SearchBar::new(&first.buf, &first.view, move |t| {
            if let Some(o) = toast_target.upgrade() {
                o.add_toast(adw::Toast::new(t));
            }
        });

        // ---- Plan ----
        let outline = gtk::ListBox::builder().selection_mode(gtk::SelectionMode::None).build();
        outline.add_css_class("navigation-sidebar");
        let outline_empty = adw::StatusPage::builder().icon_name("view-list-symbolic").title("Aucun titre").description("Les titres du document apparaîtront ici.").build();
        outline_empty.add_css_class("compact");
        outline.set_placeholder(Some(&outline_empty));
        let outline_scroll = gtk::ScrolledWindow::builder().hscrollbar_policy(gtk::PolicyType::Never).child(&outline).vexpand(true).build();
        let side_header = adw::HeaderBar::builder().show_end_title_buttons(false).show_start_title_buttons(false).title_widget(&adw::WindowTitle::new("Plan", "")).build();
        let side = adw::ToolbarView::new();
        side.add_top_bar(&side_header);
        side.set_content(Some(&outline_scroll));
        let toc_btn = gtk::Button::builder().label("Insérer une table des matières").action_name("win.insert-toc").tooltip_text("Liste des titres avec leur numéro de page, insérée au curseur").margin_start(6).margin_end(6).margin_top(6).margin_bottom(6).build();
        side.add_bottom_bar(&toc_btn);

        let content = adw::ToolbarView::new();
        content.add_top_bar(&bar_scroll);
        content.add_top_bar(&search.widget);
        let ruler = crate::ruler::Ruler::new();
        ruler.widget.set_visible(crate::prefs::get().show_ruler);
        content.add_top_bar(&ruler.widget);
        content.add_bottom_bar(&bottom);
        content.set_top_bar_style(adw::ToolbarStyle::RaisedBorder);
        content.set_bottom_bar_style(adw::ToolbarStyle::RaisedBorder);
        // Mode concentration : un bouton discret pour en sortir.
        let focus_exit = gtk::Button::builder().icon_name("view-restore-symbolic").tooltip_text("Quitter le mode concentration (Échap)").halign(gtk::Align::End).valign(gtk::Align::Start).margin_top(12).margin_end(18).visible(false).build();
        focus_exit.add_css_class("osd");
        focus_exit.add_css_class("circular");
        focus_exit.add_css_class("samizdat-focus-exit");
        focus_exit.set_action_name(Some("win.focus-mode"));
        let stage = gtk::Overlay::new();
        stage.set_child(Some(&toasts));
        stage.add_overlay(&focus_exit);
        content.set_content(Some(&stage));

        let main = adw::ToolbarView::new();
        main.add_top_bar(&header);
        main.add_top_bar(&tab_bar);
        main.set_content(Some(&content));

        let split = adw::OverlaySplitView::builder().sidebar(&side).content(&main).show_sidebar(false).min_sidebar_width(200.0).max_sidebar_width(300.0).build();
        split.bind_property("show-sidebar", &outline_btn, "active").bidirectional().sync_create().build();

        // SAMIZDAT_TEST_WIDTH : largeur imposée (tests de la barre adaptative).
        let width = std::env::var("SAMIZDAT_TEST_WIDTH").ok().and_then(|v| v.parse().ok()).unwrap_or(1280);
        let overview = adw::TabOverview::builder().view(&tab_view).child(&split).enable_new_tab(true).build();
        let win = adw::ApplicationWindow::builder().application(app).default_width(width).default_height(880).width_request(360).height_request(400).content(&overview).title("Dactylo").build();
        {
            let a = gio::SimpleAction::new("open", None);
            let o = overview.downgrade();
            a.connect_activate(move |_, _| {
                if let Some(o) = o.upgrade() {
                    o.set_open(true);
                }
            });
            let group = gio::SimpleActionGroup::new();
            group.add_action(&a);
            win.insert_action_group("overview", Some(&group));
        }

        // Barre adaptative : les groupes se replient l'un après l'autre.
        let bp = |max: f64| adw::Breakpoint::new(adw::BreakpointCondition::new_length(adw::BreakpointConditionLengthType::MaxWidth, max, adw::LengthUnit::Sp));
        let collapse_insert = |b: &adw::Breakpoint| {
            b.add_setter(&insert_group, "visible", Some(&false.to_value()));
            b.add_setter(&insert_collapsed, "visible", Some(&true.to_value()));
        };
        let collapse_para = |b: &adw::Breakpoint| {
            b.add_setter(&para_group, "visible", Some(&false.to_value()));
            b.add_setter(&para_collapsed, "visible", Some(&true.to_value()));
        };
        let collapse_text = |b: &adw::Breakpoint| {
            b.add_setter(&biu, "visible", Some(&false.to_value()));
            b.add_setter(&text_collapsed, "visible", Some(&true.to_value()));
            b.add_setter(&font_label, "width-chars", Some(&7.to_value()));
            b.add_setter(&font_label, "max-width-chars", Some(&7.to_value()));
        };
        let b1 = bp(1180.0);
        collapse_insert(&b1);
        let b2 = bp(1030.0);
        collapse_insert(&b2);
        collapse_para(&b2);
        let b3 = bp(940.0);
        collapse_insert(&b3);
        collapse_para(&b3);
        collapse_text(&b3);
        for b in [&b1, &b2, &b3] {
            win.add_breakpoint(b.clone());
        }

        let columns_btns = Self::build_columns_popover(&columns_pop);
        let tools: Vec<(&'static str, gtk::Widget)> = vec![
            ("cartouche", ins_text.clone().upcast()),
            ("formes", ins_shape.clone().upcast()),
            ("frise", ins_frise.clone().upcast()),
            ("ocr", ins_ocr.clone().upcast()),
            ("tableau", ins_table.clone().upcast()),
            ("lien", ins_link.clone().upcast()),
            ("colonnes", columns_btn.clone().upcast()),
            ("amenagements", access_btn.clone().upcast()),
            ("concentration", focus_btn.clone().upcast()),
        ];
        let text_only: Vec<gtk::Widget> = vec![
            undo_box.clone().upcast(),
            bar_scroll.clone().upcast(),
            spell_box.clone().upcast(),
            page_btn.clone().upcast(),
            ruler_btn.clone().upcast(),
            columns_btn.clone().upcast(),
            preview_btn.clone().upcast(),
            access_btn.upcast(),
            bottom_sep.upcast(),
            focus_btn.upcast(),
            save_btn.clone().upcast(),
            export_btn.clone().upcast(),
        ];
        let this = Rc::new(Self {
            win,
            tab_view,
            current: RefCell::new(first),
            toc_btn,
            title,
            toasts,
            syncing: Cell::new(false),
            force_close: Cell::new(false),
            styles,
            indent_btn: indent_btn.clone(),
            toggles: vec![("bold", bold), ("italic", italic), ("underline", underline), ("strikethrough", strike)],
            lists: vec![(ListKind::Bullet, bullets), (ListKind::Numbered, numbers)],
            align_btn,
            font_label,
            size_spin,
            color,
            color_bar,
            highlight,
            hl_css,
            search,
            split,
            outline,
            outline_pending: Cell::new(false),
            open_btn,
            new_btn,
            templates_monitor: RefCell::new(None),
            spell_btn,
            zoom_label,
            columns_btns,
            base_menu: gio::Menu::new(),
            text_only,
            tools,
            focus: Cell::new(false),
            main_tv: main.clone(),
            content_tv: content.clone(),
            focus_exit,
            live,
            live_paned,
            stage: stage.clone(),
            preview_btn: preview_btn.clone(),
            live_on: Cell::new(false),
            narrow: Cell::new(false),
            live_gen: Cell::new(0),
            live_stale: Cell::new(true),
            live_map: RefCell::new(None),
            live_ready: Rc::new(Cell::new(false)),
            narrow_points: vec![b2.clone(), b3.clone()],
            ocr_busy: Cell::new(false),
            ocr_pdf_btn,
            ruler,
        });
        this.build_color_popover(&color_pop);
        this.build_highlight_popover(&hl_pop);
        this.build_shapes_popover(&shapes_pop);
        this.build_cartouche_popover(&cartouche_pop);
        this.build_zoom_popover(&zoom_pop);
        this.build_context_menu();
        this.connect_widgets(&color_btn, &hl_btn, &font_btn);
        this.connect_columns();
        this.connect_tabs(&overview);
        this.add_actions();
        this.apply_tool_prefs();
        if crate::prefs::get().outline_on_start {
            this.split.set_show_sidebar(true);
        }
        this.connect_live();
        this.connect_ruler();
        this.connect_ocr();
        if crate::prefs::get().live_on_start {
            // Une fois la fenêtre à sa taille, pour placer la séparation.
            let w = Rc::downgrade(&this);
            this.win.connect_map(move |_| {
                if let Some(w) = w.upgrade() {
                    if !w.live_on.get() {
                        w.set_live(true);
                    }
                }
            });
        }
        this.refresh_recents();
        this.watch_templates();
        this.set_highlight_swatch();
        if !this.doc().spell.available() {
            this.spell_btn.set_active(false);
            this.spell_btn.set_sensitive(false);
            this.spell_btn.set_tooltip_text(Some("Dictionnaire français introuvable (paquet hunspell-fr)"));
        }
        this
    }

    /// Le document de l'onglet affiché.
    fn doc(&self) -> Rc<Doc> {
        self.current.borrow().clone()
    }

    fn buf(&self) -> gtk::TextBuffer {
        self.current.borrow().buf.clone()
    }

    fn view(&self) -> gtk::TextView {
        self.current.borrow().view.clone()
    }

    fn is_current(&self, doc: &Rc<Doc>) -> bool {
        Rc::ptr_eq(&self.current.borrow(), doc)
    }

    // ---- Signaux ----------------------------------------------------------

    fn connect_widgets(self: &Rc<Self>, color_btn: &adw::SplitButton, hl_btn: &adw::SplitButton, font_btn: &gtk::Button) {
        for (name, btn) in &self.toggles {
            let (w, name) = (Rc::downgrade(self), *name);
            btn.connect_toggled(move |_| {
                let Some(w) = w.upgrade() else { return };
                if w.syncing.get() {
                    return;
                }
                crate::formatting::toggle_tag_in(&w.buf(), name);
                w.after_format();
            });
        }
        for (kind, btn) in &self.lists {
            let (w, kind) = (Rc::downgrade(self), *kind);
            btn.connect_toggled(move |_| {
                let Some(w) = w.upgrade() else { return };
                if w.syncing.get() {
                    return;
                }
                editor::toggle_list(&w.buf(), kind);
                w.after_format();
            });
        }
        {
            // Le menu des styles : une action à état (le style du curseur).
            let a = gio::SimpleAction::new_stateful("paragraph-style", Some(glib::VariantTy::STRING), &"0".to_variant());
            let w = Rc::downgrade(self);
            a.connect_activate(move |a, p| {
                let Some(i) = p.and_then(|v| v.get::<String>()).and_then(|s| s.parse::<usize>().ok()) else { return };
                a.set_state(&i.to_string().to_variant());
                let w = w.clone();
                // Après la fermeture du menu.
                glib::idle_add_local_once(move || {
                    let Some(w) = w.upgrade() else { return };
                    if let Some((block, _)) = BLOCK_STYLES.get(i) {
                        editor::set_block_style(&w.buf(), *block);
                        w.after_format();
                    }
                });
            });
            self.win.add_action(&a);
            // Le bouton de retrait : un clic met ou enlève le retrait.
            let w = Rc::downgrade(self);
            self.indent_btn.connect_clicked(move |_| {
                let Some(w) = w.upgrade() else { return };
                if w.syncing.get() {
                    return;
                }
                let _ = WidgetExt::activate_action(&w.win, "win.indent-toggle", None);
            });
        }
        {
            let w = Rc::downgrade(self);
            color_btn.connect_clicked(move |_| {
                if let Some(w) = w.upgrade() {
                    let c = w.color.borrow().clone();
                    w.doc().restore_selection();
                    crate::commands::set_color(&w.buf(), c);
                    w.after_format();
                }
            });
            let w = Rc::downgrade(self);
            hl_btn.connect_clicked(move |_| {
                if let Some(w) = w.upgrade() {
                    let c = w.highlight.borrow().clone();
                    w.doc().restore_selection();
                    crate::commands::set_highlight(&w.buf(), Some(&c));
                    w.after_format();
                }
            });
        }
        {
            let w = Rc::downgrade(self);
            font_btn.connect_clicked(move |_| {
                let Some(w) = w.upgrade() else { return };
                let current = w.font_label.text().to_string();
                let w2 = w.clone();
                crate::dialogs::choose_font_family(&w.win, "Police", &current, move |family| {
                    w2.doc().restore_selection();
                    crate::commands::set_font_family(&w2.buf(), Some(family.clone()));
                    w2.font_label.set_text(&family);
                    w2.after_format();
                });
            });
        }
        {
            let w = Rc::downgrade(self);
            self.size_spin.connect_value_changed(move |sp| {
                let Some(w) = w.upgrade() else { return };
                if w.syncing.get() {
                    return;
                }
                // La valeur d'abord : rétablir la sélection remet la barre à
                // jour, donc ce champ à la taille du texte sélectionné.
                let size = sp.value();
                w.syncing.set(true);
                w.doc().restore_selection();
                w.syncing.set(false);
                crate::commands::set_font_size(&w.buf(), size);
                crate::live::sync_actions(&w.buf());
            });
            let w = Rc::downgrade(self);
            self.size_spin.connect_activate(move |_| {
                if let Some(w) = w.upgrade() {
                    w.view().grab_focus();
                }
            });
        }
        // Plan.
        {
            let w = Rc::downgrade(self);
            self.outline.connect_row_activated(move |_, row| {
                let Some(w) = w.upgrade() else { return };
                let off: i32 = row.widget_name().parse().unwrap_or(0);
                let it = w.buf().iter_at_offset(off);
                w.buf().place_cursor(&it);
                editor::scroll_to_iter(&w.view(), &it, 0.1);
                w.view().grab_focus();
                if w.split.is_collapsed() {
                    w.split.set_show_sidebar(false);
                }
            });
            let w = Rc::downgrade(self);
            self.split.connect_show_sidebar_notify(move |sp| {
                if let (true, Some(w)) = (sp.shows_sidebar(), w.upgrade()) {
                    w.refresh_outline();
                }
            });
        }
        // Orthographe.
        {
            let w = Rc::downgrade(self);
            self.spell_btn.connect_toggled(move |b| {
                if let Some(w) = w.upgrade() {
                    w.doc().spell.enabled.set(b.is_active());
                    w.doc().spell.check_buffer(&w.buf());
                }
            });
        }
        // Glisser-déposer d'un fichier sur la fenêtre.
        {
            let drop = gtk::DropTarget::new(gio::File::static_type(), gtk::gdk::DragAction::COPY);
            let app = self.win.application();
            drop.connect_drop(move |_, value, _, _| {
                if let (Ok(file), Some(app)) = (value.get::<gio::File>(), app.as_ref()) {
                    app.open(&[file], "");
                    return true;
                }
                false
            });
            self.win.add_controller(drop);
        }
    }

    fn after_format(&self) {
        crate::live::sync_actions(&self.buf());
        self.view().grab_focus();
        self.sync_toolbar();
    }

    fn schedule_sync(self: &Rc<Self>) {
        let w = Rc::downgrade(self);
        glib::idle_add_local_once(move || {
            if let Some(w) = w.upgrade() {
                w.sync_toolbar();
                w.center_caret();
                w.live_caret();
                // Un changement fait pendant la fermeture d'un menu (styles,
                // listes déroulantes) laissait l'onglet sans allocation : la
                // page ne se redessinait plus. On la fait réallouer.
                w.tab_view.queue_allocate();
            }
        });
    }

    // ---- Zoom ---------------------------------------------------------------

    fn set_zoom(&self, z: f64) {
        let doc = self.doc();
        doc.zoom.set(z);
        self.zoom_label.set_text(&format!("{} %", (z * 100.0).round()));
        if let Some(pdf) = &doc.pdf {
            pdf.set_scale(z);
            return;
        }
        let width = (PAGE_WIDTH * z).round() as i32;
        self.doc().clamp.set_maximum_size(width);
        self.doc().clamp.set_tightening_threshold((600.0 * z).round() as i32);
        // Agrandie, la feuille ne se resserre plus : on défile de côté.
        self.doc().zoom_bin.set_size_request(if z > 1.0 { width } else { -1 }, -1);
        self.doc().zoom_bin.set_zoom(z);
    }

    fn zoom_step(&self, up: bool) {
        let z = self.doc().zoom.get();
        let next = if up {
            ZOOM_STEPS.iter().copied().find(|s| *s > z + 0.001).unwrap_or(z)
        } else {
            ZOOM_STEPS.iter().rev().copied().find(|s| *s < z - 0.001).unwrap_or(z)
        };
        self.set_zoom(next);
    }

    // ---- Mode concentration -------------------------------------------------

    fn set_focus_mode(&self, on: bool) {
        if self.doc().is_pdf() && on {
            return;
        }
        self.focus.set(on);
        self.main_tv.set_reveal_top_bars(!on);
        self.content_tv.set_reveal_top_bars(!on);
        self.content_tv.set_reveal_bottom_bars(!on);
        self.focus_exit.set_visible(on);
        self.place_live();
        if on {
            self.win.add_css_class("samizdat-zen");
            self.split.set_show_sidebar(false);
            self.win.fullscreen();
        } else {
            self.win.remove_css_class("samizdat-zen");
            self.win.unfullscreen();
        }
        self.zen_padding();
        if let Some(a) = self.win.lookup_action("focus-exit").and_then(|a| a.downcast::<gio::SimpleAction>().ok()) {
            a.set_enabled(on);
        }
        self.view().grab_focus();
    }

    /// Mode concentration : une demi-hauteur d'écran blanche au-dessus et
    /// au-dessous du texte, pour que la ligne en cours soit au milieu de
    /// l'écran dès la première ligne (sinon le début du document reste
    /// collé en haut). Hors du mode, les marges ordinaires.
    pub(super) fn zen_padding(&self) {
        let on = self.focus.get() && crate::prefs::get().focus_center;
        for d in Doc::all().iter().filter(|d| !d.is_pdf()) {
            d.centered.set(false);
            if !on {
                d.clamp.set_margin_top(24);
                d.clamp.set_margin_bottom(24);
            }
        }
        if !on {
            return;
        }
        let doc = self.doc();
        if doc.is_pdf() {
            return;
        }
        doc.centered.set(true);
        let (clamp, view) = (doc.clamp.clone(), doc.view.clone());
        // Après le passage en plein écran : attendre que la hauteur soit
        // stable.
        // Puis, deux images plus tard (les marges posées), centrer.
        let (last, frames, placed) = (Cell::new(-1), Cell::new(0), Cell::new(0));
        self.win.add_tick_callback(move |win, _| {
            if placed.get() > 0 {
                placed.set(placed.get() + 1);
                if placed.get() < 3 {
                    return glib::ControlFlow::Continue;
                }
                let buf = view.buffer();
                editor::scroll_to_iter(&view, &buf.iter_at_mark(&buf.get_insert()), 0.5);
                return glib::ControlFlow::Break;
            }
            let h = win.height();
            frames.set(frames.get() + 1);
            if (h <= 0 || h != last.replace(h)) && frames.get() < 60 {
                return glib::ControlFlow::Continue;
            }
            let pad = (h / 2).max(24);
            clamp.set_margin_top(pad);
            clamp.set_margin_bottom(pad);
            placed.set(1);
            glib::ControlFlow::Continue
        });
    }

    /// Machine à écrire : la ligne du curseur reste au milieu de l'écran.
    fn center_caret(&self) {
        if !self.focus.get() || !crate::prefs::get().focus_center {
            return;
        }
        let doc = self.doc();
        if doc.is_pdf() {
            return;
        }
        let it = doc.buf.iter_at_mark(&doc.buf.get_insert());
        editor::scroll_to_iter(&doc.view, &it, 0.5);
    }

    // ---- Barre d'outils depuis le curseur ---------------------------------------

    fn sync_toolbar(&self) {
        if self.doc().is_pdf() || crate::live::is_busy(&self.buf()) {
            return;
        }
        let st = editor::caret_state(&self.buf());
        self.syncing.set(true);
        for (name, btn) in &self.toggles {
            btn.set_active(match *name {
                "bold" => st.bold,
                "italic" => st.italic,
                "underline" => st.underline,
                _ => st.strikethrough,
            });
        }
        for (kind, btn) in &self.lists {
            btn.set_active(st.list == Some(*kind));
        }
        let al = st.alignment.unwrap_or(Alignment::Left);
        // « Justifier » paraît enfoncé quand le paragraphe est justifié (un
        // bouton scindé n'a pas d'état coché à lui).
        if al == Alignment::Justify {
            self.align_btn.add_css_class("samizdat-on");
        } else {
            self.align_btn.remove_css_class("samizdat-on");
        }
        if let Some(a) = self.win.lookup_action("line-spacing").and_then(|a| a.downcast::<gio::SimpleAction>().ok()) {
            let ls = st.para.as_ref().map_or(1.0, |p| p.line_spacing);
            let target = LINE_SPACINGS.iter().map(|(_, t)| *t).min_by(|a, b| {
                let d = |t: &str| (t.parse::<f32>().unwrap_or(1.0) - ls).abs();
                d(a).total_cmp(&d(b))
            });
            a.set_state(&target.unwrap_or("1").to_variant());
        }
        if let Some(a) = self.win.lookup_action("align").and_then(|a| a.downcast::<gio::SimpleAction>().ok()) {
            a.set_state(&match al {
                Alignment::Center => "center",
                Alignment::Right => "right",
                Alignment::Justify => "justify",
                _ => "left",
            }.to_variant());
        }
        if let Some(i) = st.block {
            if let Some(a) = self.win.lookup_action("paragraph-style").and_then(|a| a.downcast::<gio::SimpleAction>().ok()) {
                a.set_state(&i.to_string().to_variant());
            }
            if let Some((_, label)) = BLOCK_STYLES.get(i) {
                self.styles.set_tooltip_text(Some(&format!("Style du paragraphe : {label}")));
            }
        }
        self.ruler.set_indent(match &st.para {
            Some(p) if p.list != ListKind::None => None,
            Some(p) => Some(p.left_indent_pt),
            None => Some(0.0),
        });
        let indented = st.para.as_ref().is_some_and(crate::commands::is_indented);
        if self.indent_btn.is_active() != indented {
            self.indent_btn.set_active(indented);
        }
        let family = st.font_family.clone().or(st.base_family.clone()).unwrap_or_else(|| self.doc().editor_family());
        if self.font_label.text() != family {
            self.font_label.set_text(&family);
            let attrs = gtk::pango::AttrList::new();
            attrs.insert(gtk::pango::AttrString::new_family(&family));
            self.font_label.set_attributes(Some(&attrs));
        }
        let size = st.font_size_hp.or(st.base_size_hp).unwrap_or(DEFAULT_SIZE_HP) as f64 / 2.0;
        if (self.size_spin.value() - size).abs() > 0.01 {
            self.size_spin.set_value(size);
        }
        let cols = crate::commands::columns(&self.buf()) as usize;
        if let Some(b) = self.columns_btns.get(cols.saturating_sub(1)) {
            b.set_active(true);
        }
        self.syncing.set(false);
        self.update_undo_actions();
    }

    fn update_undo_actions(&self) {
        let (u, r) = match crate::live::of(&self.buf()) {
            Some(m) => match m.try_borrow() {
                Ok(m) => (m.can_undo(), m.can_redo()),
                Err(_) => return,
            },
            None => (false, false),
        };
        for (name, on) in [("undo", u), ("redo", r)] {
            if let Some(a) = self.win.lookup_action(name).and_then(|a| a.downcast::<gio::SimpleAction>().ok()) {
                a.set_enabled(on);
            }
        }
    }

    fn update_title(&self) {
        let name = self.display_name();
        let modified = self.doc().is_modified();
        let shown = if modified { format!("• {name}") } else { name.clone() };
        self.title.set_title(&shown);
        let doc = self.doc();
        let dir = doc.path.borrow().as_ref().and_then(|p| p.parent().map(tilde)).unwrap_or_default();
        let subtitle = match &doc.pdf {
            Some(pdf) => {
                let n = pdf.page_count();
                format!("PDF en lecture seule · {n} page{} · {dir}", if n > 1 { "s" } else { "" })
            }
            None => dir,
        };
        self.title.set_subtitle(&subtitle);
        self.win.set_title(Some(&format!("{name} — Dactylo")));
    }

    fn display_name(&self) -> String {
        self.doc().display_name()
    }

    pub fn present(&self) {
        self.win.present();
        if !self.doc().is_pdf() {
            self.view().grab_focus();
        }
    }

    fn toast(&self, text: &str) {
        self.toasts.add_toast(adw::Toast::new(text));
    }

    fn error(&self, heading: &str, body: &str) {
        let d = adw::AlertDialog::new(Some(heading), Some(body));
        d.add_response("close", "Fermer");
        d.present(Some(&self.win));
    }

    /// Police de base du document affiché (chargé), ou celle des
    /// préférences ; la barre d'outils suit.
    fn adopt_base_font(&self, base: &letters_core::model::BaseFont) {
        self.doc().adopt_base_font(base);
        self.sync_toolbar();
    }

    /// Les préférences ont changé : les documents qui suivent la police par
    /// défaut la reprennent.
    pub fn preferences_changed(&self) {
        for d in self.docs() {
            d.preferences_changed();
        }
        self.apply_tool_prefs();
        self.sync_toolbar();
    }

    /// Les boutons masqués dans les préférences ; sur un PDF, ceux du
    /// texte aussi.
    pub(super) fn apply_tool_prefs(&self) {
        let p = crate::prefs::get();
        let pdf = self.doc().is_pdf();
        for (key, w) in &self.tools {
            let text_only = self.text_only.contains(w);
            w.set_visible(p.shows(key) && !(pdf && text_only));
        }
    }

    /// Insère une table des matières au curseur, ou met à jour celle qui
    /// existe.
    fn insert_toc(&self) {
        let Some(live) = crate::live::of(&self.buf()) else { return };
        let doc = crate::bridge::document_of(&self.buf());
        if letters_core::toc::headings(&doc).is_empty() {
            self.toast("Aucun titre à lister : appliquez un style Titre à vos intertitres");
            return;
        }
        if !letters_core::toc::blocks(&doc).is_empty() {
            if !self.refresh_toc() {
                self.toast("La table des matières est à jour");
            }
            return;
        }
        let caret = self.buf().iter_at_mark(&self.buf().get_insert()).offset().max(0) as usize;
        let seq = live.borrow_mut().sequence_offset(&self.buf(), caret);
        let para = letters_core::edit::locate(&doc, seq).map_or(0, |(p, _)| p);
        let mut prepared = doc.clone();
        self.prepare_for_layout(&mut prepared);
        let ops = letters_core::toc::settle(&prepared, letters_core::toc::insert(&prepared, para), |d| files::paginate(d));
        // Les entrées viennent du document préparé : on les remet telles
        // quelles (elles n'ont pas d'espace ajouté).
        live.borrow_mut().edit_with(&self.buf(), |_| ops);
        self.refresh_outline();
    }

    fn refresh_outline(&self) {
        while let Some(row) = self.outline.first_child() {
            self.outline.remove(&row);
        }
        if self.doc().is_pdf() {
            return;
        }
        let found = crate::live::of(&self.buf()).and_then(|m| {
            m.try_borrow_mut().ok().map(|mut m| {
                let items = m.outline(&self.buf());
                (items, !letters_core::toc::blocks(m.document(&self.buf())).is_empty())
            })
        });
        let Some((items, has_toc)) = found else { return };
        self.toc_btn.set_label(if has_toc { "Mettre à jour la table des matières" } else { "Insérer une table des matières" });
        for (level, title, off) in items {
            let label = gtk::Label::builder().label(if title.trim().is_empty() { "(titre vide)".to_string() } else { title }).xalign(0.0).ellipsize(gtk::pango::EllipsizeMode::End).build();
            label.set_margin_start(((level.max(1) - 1) as i32) * 14);
            if level <= 1 {
                label.add_css_class("heading");
            }
            let row = gtk::ListBoxRow::builder().child(&label).build();
            row.set_widget_name(&off.to_string());
            self.outline.append(&row);
        }
    }

    fn insert_image_dialog(self: &Rc<Self>) {
        let filter = gtk::FileFilter::new();
        filter.set_name(Some("Images"));
        filter.add_pixbuf_formats();
        let filters = gio::ListStore::new::<gtk::FileFilter>();
        filters.append(&filter);
        let dialog = gtk::FileDialog::builder().title("Insérer une image").modal(true).filters(&filters).build();
        let w = self.clone();
        dialog.open(Some(&self.win), gio::Cancellable::NONE, move |res| {
            let Ok(file) = res else { return };
            let Some(path) = file.path() else { return };
            match crate::commands::insert_image(&w.buf(), &path) {
                Ok(()) => w.after_format(),
                Err(e) => w.error("Impossible d'insérer l'image", &e),
            }
        });
    }

}
