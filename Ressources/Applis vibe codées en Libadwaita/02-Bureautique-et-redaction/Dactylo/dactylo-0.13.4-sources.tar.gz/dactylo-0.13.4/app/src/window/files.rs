// window/files.rs — fichiers : ouvrir, enregistrer, exporter, récents,
// modèles, copies de secours.
// SPDX-License-Identifier: GPL-3.0-or-later

use super::*;

impl Window {
    // ---- Récents et secours -----------------------------------------------------

    pub(super) fn refresh_recents(&self) {
        let menu = gio::Menu::new();
        let list = crate::store::recents();
        let section = gio::Menu::new();
        if list.is_empty() {
            section.append(Some("Aucun document récent"), Some("win.none"));
        }
        for p in &list {
            let name = p.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
            let dir = p.parent().map(tilde).unwrap_or_default();
            let item = gio::MenuItem::new(Some(&format!("{name}   —   {dir}")), None);
            item.set_action_and_target_value(Some("win.open-recent"), Some(&p.to_string_lossy().to_variant()));
            section.append_item(&item);
        }
        menu.append_section(Some("Documents récents"), &section);
        if !list.is_empty() {
            let clear = gio::Menu::new();
            clear.append(Some("Effacer la liste"), Some("win.clear-recents"));
            menu.append_section(None, &clear);
        }
        self.open_btn.set_menu_model(Some(&menu));
    }

    /// Le menu du bouton Nouveau : les modèles, puis leur gestion.
    pub(super) fn refresh_templates(&self) {
        let menu = gio::Menu::new();
        let section = gio::Menu::new();
        let list = crate::store::templates();
        if list.is_empty() {
            section.append(Some("Aucun modèle"), Some("win.none"));
        }
        for p in &list {
            let name = p.file_stem().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
            let item = gio::MenuItem::new(Some(&name), None);
            item.set_action_and_target_value(Some("app.new-from-template"), Some(&p.to_string_lossy().to_variant()));
            section.append_item(&item);
        }
        menu.append_section(Some("Nouveau à partir d'un modèle"), &section);
        let manage = gio::Menu::new();
        manage.append(Some("Enregistrer comme modèle…"), Some("win.save-template"));
        manage.append(Some("Importer des modèles…"), Some("win.import-templates"));
        manage.append(Some("Ouvrir le dossier des modèles"), Some("win.open-templates"));
        menu.append_section(None, &manage);
        self.new_btn.set_menu_model(Some(&menu));
    }

    /// Le menu suit le dossier des modèles (ajouts depuis Fichiers…).
    pub(super) fn watch_templates(self: &Rc<Self>) {
        self.refresh_templates();
        let dir = gio::File::for_path(crate::store::templates_dir());
        if let Ok(monitor) = dir.monitor_directory(gio::FileMonitorFlags::NONE, gio::Cancellable::NONE) {
            let w = Rc::downgrade(self);
            monitor.connect_changed(move |_, _, _, _| {
                if let Some(w) = w.upgrade() {
                    w.refresh_templates();
                }
            });
            *self.templates_monitor.borrow_mut() = Some(monitor);
        }
    }

    /// Ouvre un modèle comme nouveau document sans nom, dans un onglet.
    pub fn load_template(self: &Rc<Self>, path: &Path) {
        self.target_tab();
        match letters_core::save::read(path) {
            Ok(doc) => {
                crate::bridge::load_document(&doc, &self.buf());
                self.adopt_base_font(&doc.base_font);
                self.buf().set_modified(false);
                self.buf().place_cursor(&self.buf().start_iter());
                *self.doc().path.borrow_mut() = None;
                self.refresh_tab(&self.doc());
                self.sync_toolbar();
            }
            Err(e) => self.error("Impossible d'ouvrir le modèle", &e),
        }
    }

    pub(super) fn save_template(self: &Rc<Self>) {
        let dir = crate::store::templates_dir();
        let entry = gtk::Entry::builder().text(self.stem()).activates_default(true).build();
        let d = adw::AlertDialog::new(Some("Enregistrer comme modèle"), Some("Le document sera proposé dans le menu du bouton Nouveau."));
        d.set_extra_child(Some(&entry));
        d.add_responses(&[("cancel", "Annuler"), ("save", "Enregistrer")]);
        d.set_response_appearance("save", adw::ResponseAppearance::Suggested);
        d.set_default_response(Some("save"));
        d.set_close_response("cancel");
        let name_ok = {
            let dir = dir.clone();
            move |name: &str| {
                let n = name.trim();
                !n.is_empty() && !n.contains('/') && !dir.join(format!("{n}.docx")).exists()
            }
        };
        {
            let (d2, name_ok) = (d.downgrade(), name_ok.clone());
            entry.connect_changed(move |e| {
                if let Some(d) = d2.upgrade() {
                    let ok = name_ok(&e.text());
                    d.set_response_enabled("save", ok);
                    d.set_body(if ok || e.text().trim().is_empty() { "Le document sera proposé dans le menu du bouton Nouveau." } else { "Un modèle porte déjà ce nom." });
                }
            });
        }
        d.set_response_enabled("save", name_ok(&entry.text()));
        let (w, e2) = (self.clone(), entry.clone());
        d.choose(Some(&self.win), gio::Cancellable::NONE, move |resp| {
            if resp != "save" {
                return;
            }
            let path = dir.join(format!("{}.docx", e2.text().trim()));
            let doc = crate::bridge::document_of(&w.buf());
            let _ = std::fs::create_dir_all(&dir);
            match letters_core::save::write(&doc, &path) {
                Ok(_) => {
                    w.refresh_templates();
                    w.toast("Modèle enregistré");
                }
                Err(e) => w.error("Impossible d'enregistrer le modèle", &e),
            }
        });
        entry.grab_focus();
    }

    pub(super) fn import_templates(self: &Rc<Self>) {
        let filter = gtk::FileFilter::new();
        filter.set_name(Some("Documents (DOCX, ODT, Markdown)"));
        for ext in crate::store::TEMPLATE_EXTENSIONS {
            filter.add_suffix(ext);
        }
        let filters = gio::ListStore::new::<gtk::FileFilter>();
        filters.append(&filter);
        let dialog = gtk::FileDialog::builder().title("Importer des modèles").modal(true).filters(&filters).build();
        let w = self.clone();
        dialog.open_multiple(Some(&self.win), gio::Cancellable::NONE, move |res| {
            let Ok(files) = res else { return };
            let mut n = 0;
            for i in 0..files.n_items() {
                let Some(path) = files.item(i).and_then(|o| o.downcast::<gio::File>().ok()).and_then(|f| f.path()) else { continue };
                match crate::store::import_template(&path) {
                    Ok(_) => n += 1,
                    Err(e) => w.error("Impossible d'importer le modèle", &e),
                }
            }
            w.refresh_templates();
            if n > 0 {
                w.toast(&if n == 1 { "Modèle importé".to_string() } else { format!("{n} modèles importés") });
            }
        });
    }

    pub(super) fn open_templates_folder(&self) {
        let dir = crate::store::templates_dir();
        let _ = std::fs::create_dir_all(&dir);
        gtk::FileLauncher::new(Some(&gio::File::for_path(&dir))).launch(Some(&self.win), gio::Cancellable::NONE, |_| {});
    }

    /// Ouvre une copie de secours dans un onglet (document non enregistré).
    pub fn restore(self: &Rc<Self>, r: &crate::store::Recovery) {
        self.target_tab();
        match letters_core::save::read(&r.doc) {
            Ok(doc) => {
                crate::bridge::load_document(&doc, &self.buf());
                self.adopt_base_font(&doc.base_font);
                *self.doc().path.borrow_mut() = r.original.clone();
                self.buf().set_modified(true);
                self.refresh_tab(&self.doc());
                self.sync_toolbar();
                crate::store::forget_recovery(r);
                self.toast("Document récupéré : pensez à l'enregistrer");
            }
            Err(e) => self.error("Impossible de récupérer le document", &e),
        }
    }

    // ---- Fichiers -------------------------------------------------------

    /// Charge un fichier dans l'onglet affiché (voir `open_file`).
    pub(super) fn load(self: &Rc<Self>, file: &gio::File) {
        let Some(path) = file.path() else {
            self.toast("Seuls les fichiers locaux sont pris en charge");
            return;
        };
        match letters_core::save::read(&path) {
            Ok(doc) => {
                crate::bridge::load_document(&doc, &self.buf());
                self.adopt_base_font(&doc.base_font);
                self.buf().place_cursor(&self.buf().start_iter());
                crate::store::add_recent(&path);
                // Un format que Dactylo lit mais n'écrit pas (.doc, .rtf,
                // modèles…) : l'original n'est jamais écrasé, le document
                // sera enregistré à côté, en DOCX (ODT pour un modèle ODT).
                let ext = path.extension().map(|e| e.to_string_lossy().to_ascii_lowercase()).unwrap_or_default();
                let writable = letters_core::save::SaveFormat::from_extension(&ext).is_some();
                let target = if writable { path.clone() } else { converted_name(&path, if ext == "ott" { "odt" } else { "docx" }) };
                self.buf().set_modified(!writable);
                if !writable {
                    self.toast(&format!(
                        "Ouvert depuis le format .{ext} : il sera enregistré en « {} »",
                        target.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default()
                    ));
                }
                *self.doc().path.borrow_mut() = Some(target);
                self.refresh_recents();
                self.refresh_tab(&self.doc());
                self.sync_toolbar();
            }
            Err(e) => self.error("Impossible d'ouvrir le document", &e),
        }
    }

    /// Enregistre ; `then` est appelé avec `true` si l'enregistrement a eu lieu.
    pub(super) fn save(self: &Rc<Self>, then: impl FnOnce(bool) + 'static) {
        let path = self.doc().path.borrow().clone();
        match path {
            Some(p) => then(self.write_to(&p, true)),
            None => self.save_as(then),
        }
    }

    pub(super) fn write_to(&self, path: &Path, notify: bool) -> bool {
        self.refresh_toc();
        let mut doc = crate::bridge::document_of(&self.buf());
        // Sans police de base, le fichier prend celle qu'on voit à l'écran
        // (sinon Word et LibreOffice afficheraient une police à empattements).
        if doc.base_font.family.is_none() {
            doc.base_font.family = Some(self.doc().editor_family());
        }
        match letters_core::save::write(&doc, path) {
            Ok(report) => {
                self.buf().set_modified(false);
                *self.doc().path.borrow_mut() = Some(path.to_path_buf());
                // Préférence : le PDF à côté, sous le même nom.
                let ext = path.extension().map(|e| e.to_string_lossy().to_lowercase()).unwrap_or_default();
                if crate::prefs::get().pdf_with_save && matches!(ext.as_str(), "docx" | "odt") {
                    if let Err(e) = self.write_pdf(&path.with_extension("pdf")) {
                        self.toast(&format!("PDF non enregistré : {e}"));
                    }
                }
                crate::store::drop_recovery(self.doc().id);
                crate::store::add_recent(path);
                self.refresh_recents();
                self.refresh_tab(&self.doc());
                if !report.features.is_empty() {
                    let names: Vec<String> = report.features.iter().map(|f| format!("{f:?}")).collect();
                    log_report(&names);
                    self.toast(&format!("Enregistré — {} élément(s) non pris en charge par le format {}", report.features.len(), report.format));
                } else if notify {
                    self.toast("Document enregistré");
                }
                true
            }
            Err(e) => {
                self.error("Impossible d'enregistrer", &e);
                false
            }
        }
    }

    /// Le document tel que l'aperçu et le PDF le dessinent : sans police de
    /// base, il prend celle de l'éditeur, pour que le PDF ressemble à l'écran.
    pub(super) fn typeset_document(&self) -> letters_core::Document {
        self.typeset_with(|_| {})
    }

    /// `typeset_document`, la copie modifiée par `f` avant que ses tables
    /// des matières prennent leurs numéros de page (le PDF aménagé).
    pub(super) fn typeset_with(&self, f: impl FnOnce(&mut letters_core::Document)) -> letters_core::Document {
        let mut doc = crate::bridge::document_of(&self.buf());
        self.prepare_for_layout(&mut doc);
        f(&mut doc);
        // Tables des matières à jour (numéros de page) dans la copie.
        if !letters_core::toc::blocks(&doc).is_empty() {
            let ops = letters_core::toc::settle(&doc, Vec::new(), |d| paginate(d));
            let _ = letters_core::edit::apply_all(&mut doc, &ops);
        }
        doc
    }

    /// Ce que l'éditeur montre sans que le document le dise : sa police
    /// (celle de GNOME) et l'espace sous chaque paragraphe (6 px = 4,5 pt).
    /// L'aperçu et le PDF le reprennent pour ressembler à l'écran.
    pub(super) fn prepare_for_layout(&self, doc: &mut letters_core::Document) {
        if doc.base_font.family.is_none() {
            doc.base_font.family = Some(self.doc().editor_family());
        }
        if doc.base_font.size_hp.is_none() {
            doc.base_font.size_hp = Some(DEFAULT_SIZE_HP);
        }
        for p in &mut doc.paragraphs {
            if p.style.space_after_pt == 0.0 && p.style.table_cell.is_none() && p.style.toc.is_none() {
                // Les interlignes 1,15 / 1,5 / 2 ont leur propre espace dessous.
                let ls = p.style.line_spacing;
                p.style.space_after_pt = if (ls - 1.15).abs() < 0.01 {
                    2.25
                } else if (ls - 1.5).abs() < 0.01 {
                    6.0
                } else if (ls - 2.0).abs() < 0.01 {
                    12.0
                } else {
                    EDITOR_SPACE_AFTER_PT
                };
            }
        }
    }

    /// Met à jour les numéros de page des tables des matières du document
    /// (une étape d'annulation). Rend `true` s'il y en avait à changer.
    pub(super) fn refresh_toc(&self) -> bool {
        let Some(live) = crate::live::of(&self.buf()) else { return false };
        let mut doc = crate::bridge::document_of(&self.buf());
        if letters_core::toc::blocks(&doc).is_empty() {
            return false;
        }
        self.prepare_for_layout(&mut doc);
        let pages = paginate(&doc);
        let ops = letters_core::toc::update(&doc, &pages);
        !ops.is_empty() && live.borrow_mut().edit_with(&self.buf(), |_| ops)
    }

    pub(super) fn write_pdf(&self, path: &Path) -> Result<(), String> {
        let doc = self.typeset_document();
        letters_core::layout::pango::Typeset::new(doc, letters_core::layout::LayoutOptions::default()).write_pdf(path)
    }

    /// Le nom proposé : celui du fichier, sinon le grand titre (Titre 1)
    /// d'un document neuf, sinon « Document ».
    pub(super) fn stem(&self) -> String {
        if let Some(stem) = self.doc().path.borrow().as_ref().and_then(|p| p.file_stem().map(|n| n.to_string_lossy().to_string())) {
            return stem;
        }
        if !crate::prefs::get().title_as_name {
            return "Document".into();
        }
        let doc = crate::bridge::document_of(&self.buf());
        doc.paragraphs
            .iter()
            .find(|p| p.style.heading == Some(1) && p.style.table_cell.is_none())
            .map(|p| clean_file_name(&p.text()))
            .filter(|t| !t.is_empty())
            .unwrap_or_else(|| "Document".into())
    }

    /// Le dossier où ouvrir et enregistrer : celui du document, sinon le
    /// dossier des documents des préférences.
    pub(super) fn initial_folder(&self) -> Option<gio::File> {
        if let Some(dir) = self.doc().path.borrow().as_ref().and_then(|p| p.parent()) {
            return Some(gio::File::for_path(dir));
        }
        crate::prefs::get().docs_dir.filter(|d| std::path::Path::new(d).is_dir()).map(gio::File::for_path)
    }

    pub(super) fn save_dialog(&self, title: &str, initial: String, filters: Option<gio::ListStore>) -> gtk::FileDialog {
        let mut b = gtk::FileDialog::builder().title(title).modal(true).initial_name(initial);
        if let Some(f) = filters {
            b = b.filters(&f);
        }
        let dialog = b.build();
        if let Some(dir) = self.initial_folder() {
            dialog.set_initial_folder(Some(&dir));
        }
        dialog
    }

    pub(super) fn save_as(self: &Rc<Self>, then: impl FnOnce(bool) + 'static) {
        let initial = self.doc().path.borrow().as_ref().and_then(|p| p.file_name().map(|n| n.to_string_lossy().to_string())).unwrap_or_else(|| format!("{}.docx", self.stem()));
        let dialog = self.save_dialog("Enregistrer le document", initial, Some(save_filters()));
        let w = self.clone();
        dialog.save(Some(&self.win), gio::Cancellable::NONE, move |res| match res {
            Ok(file) => {
                let Some(mut path) = file.path() else { return then(false) };
                if path.extension().is_none() {
                    path.set_extension("docx");
                }
                then(w.write_to(&path, true));
            }
            Err(_) => then(false),
        });
    }

    pub(super) fn open_dialog(self: &Rc<Self>) {
        let dialog = gtk::FileDialog::builder().title("Ouvrir un document").modal(true).filters(&open_filters()).build();
        if let Some(dir) = self.initial_folder() {
            dialog.set_initial_folder(Some(&dir));
        }
        let app = self.win.application();
        dialog.open_multiple(Some(&self.win), gio::Cancellable::NONE, move |res| {
            if let (Ok(files), Some(app)) = (res, app) {
                let files: Vec<gio::File> = (0..files.n_items()).filter_map(|i| files.item(i).and_then(|o| o.downcast::<gio::File>().ok())).collect();
                app.open(&files, "");
            }
        });
    }

    pub(super) fn export_pdf(self: &Rc<Self>) {
        let filter = gtk::FileFilter::new();
        filter.set_name(Some("PDF"));
        filter.add_mime_type("application/pdf");
        let filters = gio::ListStore::new::<gtk::FileFilter>();
        filters.append(&filter);
        let dialog = self.save_dialog("Exporter en PDF", format!("{}.pdf", self.stem()), Some(filters));
        let w = self.clone();
        dialog.save(Some(&self.win), gio::Cancellable::NONE, move |res| {
            let Ok(file) = res else { return };
            let Some(mut path) = file.path() else { return };
            if path.extension().is_none() {
                path.set_extension("pdf");
            }
            match w.write_pdf(&path) {
                Ok(()) => w.toast("PDF exporté"),
                Err(e) => w.error("Impossible d'exporter en PDF", &e),
            }
        });
    }

    /// Enregistre en DOCX et exporte le PDF à côté, sous le même nom. Si un
    /// des deux fichiers existe déjà : remplacer, garder les deux, annuler.
    pub(super) fn save_both(self: &Rc<Self>) {
        let dialog = self.save_dialog("Enregistrer en DOCX et PDF", self.stem(), None);
        let w = self.clone();
        dialog.save(Some(&self.win), gio::Cancellable::NONE, move |res| {
            let Ok(file) = res else { return };
            let Some(chosen) = file.path() else { return };
            // Le nom sans extension : on ajoute .docx et .pdf.
            let base = match chosen.extension().and_then(|e| e.to_str()) {
                Some(e) if ["docx", "pdf", "odt"].contains(&e.to_ascii_lowercase().as_str()) => chosen.with_extension(""),
                _ => chosen.clone(),
            };
            let pair = |b: &Path| (with_ext(b, "docx"), with_ext(b, "pdf"));
            let (docx, pdf) = pair(&base);
            let existing: Vec<String> = [&docx, &pdf].iter().filter(|p| p.exists()).filter_map(|p| p.file_name().map(|n| n.to_string_lossy().to_string())).collect();
            let write = {
                let w = w.clone();
                move |docx: PathBuf, pdf: PathBuf| {
                    if !w.write_to(&docx, false) {
                        return;
                    }
                    match w.write_pdf(&pdf) {
                        Ok(()) => w.toast(&format!(
                            "Enregistré : {} et {}",
                            docx.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default(),
                            pdf.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default()
                        )),
                        Err(e) => w.error("Le DOCX est enregistré, mais pas le PDF", &e),
                    }
                }
            };
            if existing.is_empty() {
                write(docx, pdf);
                return;
            }
            let body = if existing.len() == 2 {
                format!("« {} » et « {} » existent déjà dans ce dossier.", existing[0], existing[1])
            } else {
                format!("« {} » existe déjà dans ce dossier.", existing[0])
            };
            let heading = if existing.len() == 2 { "Ces fichiers existent déjà" } else { "Ce fichier existe déjà" };
            let d = adw::AlertDialog::new(Some(heading), Some(&body));
            d.add_responses(&[("cancel", "Annuler"), ("keep", "Garder les deux"), ("replace", "Remplacer")]);
            d.set_response_appearance("replace", adw::ResponseAppearance::Destructive);
            d.set_default_response(Some("keep"));
            d.set_close_response("cancel");
            d.choose(Some(&w.win), gio::Cancellable::NONE, move |resp| match resp.as_str() {
                "replace" => write(docx, pdf),
                "keep" => {
                    let parent = base.parent().map(Path::to_path_buf).unwrap_or_default();
                    let stem = base.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
                    let mut n = 2;
                    loop {
                        let b = parent.join(format!("{stem} ({n})"));
                        let (d2, p2) = pair(&b);
                        if !d2.exists() && !p2.exists() {
                            write(d2, p2);
                            break;
                        }
                        n += 1;
                    }
                }
                _ => {}
            });
        });
    }
}

pub(super) fn with_ext(base: &Path, ext: &str) -> PathBuf {
    let mut s = base.as_os_str().to_owned();
    s.push(format!(".{ext}"));
    PathBuf::from(s)
}


/// Le nom sous lequel enregistrer un document ouvert depuis un format que
/// Dactylo n'écrit pas : même dossier, même nom, nouvelle extension, sans
/// écraser un fichier existant.
fn converted_name(path: &Path, ext: &str) -> PathBuf {
    let first = path.with_extension(ext);
    if !first.exists() {
        return first;
    }
    let stem = path.file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
    (2..)
        .map(|n| path.with_file_name(format!("{stem} ({n}).{ext}")))
        .find(|p| !p.exists())
        .unwrap_or(first)
}

pub(super) fn open_filters() -> gio::ListStore {
    let store = gio::ListStore::new::<gtk::FileFilter>();
    let all = gtk::FileFilter::new();
    all.set_name(Some("Documents (et PDF en lecture)"));
    for m in crate::MIME_TYPES {
        all.add_mime_type(m);
    }
    all.add_mime_type("text/html");
    for s in ["*.docx", "*.docm", "*.dotx", "*.dotm", "*.odt", "*.ott", "*.doc", "*.dot", "*.rtf", "*.md", "*.markdown", "*.txt", "*.html", "*.htm", "*.pdf"] {
        all.add_pattern(s);
    }
    store.append(&all);
    store
}

pub(super) fn save_filters() -> gio::ListStore {
    let store = gio::ListStore::new::<gtk::FileFilter>();
    for (name, pat) in [("Word (.docx)", "*.docx"), ("OpenDocument (.odt)", "*.odt"), ("Markdown (.md)", "*.md"), ("HTML (.html)", "*.html"), ("Texte brut (.txt)", "*.txt")] {
        let f = gtk::FileFilter::new();
        f.set_name(Some(name));
        f.add_pattern(pat);
        store.append(&f);
    }
    store
}

pub(super) fn tilde(dir: &Path) -> String {
    let home = glib::home_dir();
    match dir.strip_prefix(&home) {
        Ok(rest) if rest.as_os_str().is_empty() => "~".into(),
        Ok(rest) => format!("~/{}", rest.display()),
        Err(_) => dir.display().to_string(),
    }
}

pub(super) fn log_report(names: &[String]) {
    for n in names {
        glib::g_message!("samizdat", "Non pris en charge par le format : {n}");
    }
}

/// La page (à partir de 0) où commence chaque paragraphe.
pub(super) fn paginate(doc: &letters_core::Document) -> Vec<Option<usize>> {
    letters_core::layout::pango::Typeset::new(doc.clone(), letters_core::layout::LayoutOptions::default()).paragraph_pages()
}

/// Un titre en nom de fichier : sans les caractères interdits, pas trop long.
pub(super) fn clean_file_name(title: &str) -> String {
    let cleaned: String = title.chars().map(|c| if "/\\:*?\"<>|".contains(c) || c.is_control() { ' ' } else { c }).collect();
    let words: Vec<&str> = cleaned.split_whitespace().collect();
    let mut out = words.join(" ");
    if out.chars().count() > 80 {
        out = out.chars().take(80).collect::<String>().trim_end().to_string();
    }
    out.trim_matches('.').to_string()
}

// ---- Clé USB --------------------------------------------------------------------

/// Les clés et disques amovibles montés : (nom, montage), la première
/// d'abord.
fn removable_mounts() -> Vec<(String, gio::Mount)> {
    gio::VolumeMonitor::get()
        .mounts()
        .into_iter()
        .filter(|m| {
            let removable = m.drive().is_some_and(|d| d.is_removable() || d.is_media_removable());
            (removable || m.can_eject()) && m.root().path().is_some()
        })
        .map(|m| (m.name().to_string(), m))
        .collect()
}

impl Window {
    /// Une copie DOCX du document (le document garde son propre fichier).
    fn write_copy(&self, path: &Path) -> Result<(), String> {
        self.refresh_toc();
        let mut doc = crate::bridge::document_of(&self.buf());
        if doc.base_font.family.is_none() {
            doc.base_font.family = Some(self.doc().editor_family());
        }
        letters_core::save::write(&doc, path).map(|_| ())
    }

    /// Copie le document (DOCX et PDF) dans un dossier d'une clé USB choisi
    /// en naviguant dans la clé.
    pub(super) fn export_usb(self: &Rc<Self>) {
        let mounts = removable_mounts();
        let Some((_, mount)) = mounts.first().cloned() else {
            self.toast("Aucune clé USB branchée");
            return;
        };
        let dialog = gtk::FileDialog::builder().title("Dossier de la clé USB").accept_label("Copier ici").modal(true).build();
        dialog.set_initial_folder(Some(&mount.root()));
        let w = self.clone();
        dialog.select_folder(Some(&self.win), gio::Cancellable::NONE, move |res| {
            let Some(dir) = res.ok().and_then(|f| f.path()) else { return };
            let stem = w.stem();
            let (docx, pdf) = (dir.join(format!("{stem}.docx")), dir.join(format!("{stem}.pdf")));
            if let Err(e) = w.write_copy(&docx).and_then(|_| w.write_pdf(&pdf)) {
                w.error("Impossible de copier sur la clé", &e);
                return;
            }
            w.toast(&format!("« {stem} » copié sur la clé (DOCX et PDF)"));
        });
    }
}
