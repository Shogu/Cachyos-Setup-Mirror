// window/tabs.rs — les fenêtres et leurs onglets.
//
// Une fenêtre a un seul jeu de barres d'outils ; elles suivent le document
// de l'onglet affiché. Ouvrir un fichier l'ajoute en onglet (un onglet neuf
// et vide est réutilisé) ; un PDF s'ouvre en lecture seule. Un onglet glissé
// hors de la fenêtre en ouvre une nouvelle.
// SPDX-License-Identifier: GPL-3.0-or-later

use super::*;

thread_local! {
    static WINDOWS: RefCell<Vec<Rc<Window>>> = const { RefCell::new(Vec::new()) };
}

/// Une nouvelle fenêtre, avec un document vide si `with_doc`.
pub fn create(app: &adw::Application, with_doc: bool) -> Rc<Window> {
    let w = Window::new(app);
    let first = w.doc();
    if with_doc {
        w.add_tab(&first, true);
        justify_blank(&first);
    } else {
        // Fenêtre qui reçoit un onglet glissé : le document provisoire s'en va.
        first.forget();
    }
    WINDOWS.with(|ws| ws.borrow_mut().push(w.clone()));
    let id = w.win.clone();
    w.win.connect_destroy(move |_| WINDOWS.with(|ws| ws.borrow_mut().retain(|x| x.win != id)));
    w
}

/// Toutes les fenêtres.
pub fn all_windows() -> Vec<Rc<Window>> {
    WINDOWS.with(|ws| ws.borrow().clone())
}

/// La fenêtre active (ou la dernière ouverte).
pub fn active(app: &adw::Application) -> Option<Rc<Window>> {
    let windows = all_windows();
    let active = app.active_window();
    windows.iter().find(|w| active.as_ref().is_some_and(|a| a == w.win.upcast_ref::<gtk::Window>())).cloned().or_else(|| windows.last().cloned())
}

/// Les signaux propres à un document : ils retrouvent sa fenêtre du moment.
pub(super) fn wire_doc(doc: &Rc<Doc>) {
    if doc.is_pdf() {
        return;
    }
    // Clic droit : suggestions d'orthographe et menu du document.
    {
        let click = gtk::GestureClick::new();
        click.set_button(3);
        click.set_propagation_phase(gtk::PropagationPhase::Capture);
        let d = Rc::downgrade(doc);
        click.connect_pressed(move |_, _, x, y| {
            let Some(d) = d.upgrade() else { return };
            let Some(w) = d.owner() else { return };
            let (bx, by) = d.view.window_to_buffer_coords(gtk::TextWindowType::Widget, x as i32, y as i32);
            let menu = gio::Menu::new();
            if let Some(it) = d.view.iter_at_location(bx, by) {
                if let Some((a, b, word)) = d.spell.misspelled_at(&d.buf, &it) {
                    let sugg = gio::Menu::new();
                    let list = d.spell.suggestions(&word);
                    if list.is_empty() {
                        sugg.append(Some("(aucune suggestion)"), Some("win.none"));
                    }
                    for s in list {
                        let item = gio::MenuItem::new(Some(&s), None);
                        item.set_action_and_target_value(Some("win.spell-replace"), Some(&format!("{a}|{b}|{s}").to_variant()));
                        sugg.append_item(&item);
                    }
                    let add = gio::MenuItem::new(Some(&format!("Ajouter « {word} » au dictionnaire")), None);
                    add.set_action_and_target_value(Some("win.spell-add"), Some(&word.to_variant()));
                    sugg.append_item(&add);
                    menu.append_section(None, &sugg);
                }
            }
            for i in 0..w.base_menu.n_items() {
                if let Some(section) = w.base_menu.item_link(i, "section") {
                    menu.append_section(None, &section);
                }
            }
            d.view.set_extra_menu(Some(&menu));
        });
        doc.view.add_controller(click);
    }
    // Glisser-déposer sur la page : une image (fichier, image d'une page web,
    // vignette) s'insère là où elle est lâchée ; un document s'ouvre.
    {
        let drop = gtk::DropTarget::new(glib::Type::INVALID, gtk::gdk::DragAction::COPY);
        drop.set_types(&[gtk::gdk::FileList::static_type(), gtk::gdk::Texture::static_type()]);
        let d = Rc::downgrade(doc);
        drop.connect_drop(move |_, value, x, y| {
            let Some(d) = d.upgrade() else { return false };
            let (bx, by) = d.view.window_to_buffer_coords(gtk::TextWindowType::Widget, x as i32, y as i32);
            if let Some(it) = d.view.iter_at_location(bx, by) {
                d.buf.place_cursor(&it);
            }
            let done = {
                let d = Rc::downgrade(&d);
                move || {
                    if let Some(w) = d.upgrade().and_then(|d| d.owner()) {
                        w.after_format();
                    }
                }
            };
            if let Ok(t) = value.get::<gtk::gdk::Texture>() {
                let _ = crate::commands::insert_image_texture(&d.buf, &t);
                done();
                return true;
            }
            let Ok(list) = value.get::<gtk::gdk::FileList>() else { return false };
            for f in list.files() {
                match f.path() {
                    Some(p) if crate::commands::image_size(&p.to_string_lossy()).is_some() => {
                        let _ = crate::commands::insert_image(&d.buf, &p);
                        done();
                    }
                    Some(_) => {
                        if let Some(app) = d.view.root().and_then(|r| r.downcast::<gtk::Window>().ok()).and_then(|w| w.application()) {
                            app.open(&[f.clone()], "");
                        }
                    }
                    None => {
                        let (d2, done) = (Rc::downgrade(&d), done.clone());
                        crate::web::fetch_image(&f.uri(), move |r| {
                            let Some(d) = d2.upgrade() else { return };
                            let w = d.owner();
                            match r {
                                Ok(p) if crate::commands::image_size(&p.to_string_lossy()).is_some() => {
                                    let _ = crate::commands::insert_image(&d.buf, &p);
                                    let _ = std::fs::remove_file(&p);
                                    done();
                                }
                                Ok(p) => {
                                    let _ = std::fs::remove_file(&p);
                                    if let Some(w) = w {
                                        w.toast("Ce lien ne mène pas à une image : ouvrez l'image, puis glissez-la ou copiez-la");
                                    }
                                }
                                Err(e) => {
                                    if let Some(w) = w {
                                        w.toast(&format!("Image non récupérée : {e}"));
                                    }
                                }
                            }
                        });
                    }
                }
            }
            true
        });
        doc.view.add_controller(drop);
    }
    // Double-clic : image (taille, recadrage) ou tableau (éditeur).
    {
        let click = gtk::GestureClick::new();
        click.set_button(1);
        let d = Rc::downgrade(doc);
        click.connect_pressed(move |g, n, x, y| {
            let Some(d) = d.upgrade() else { return };
            if n != 2 {
                return;
            }
            let (bx, by) = d.view.window_to_buffer_coords(gtk::TextWindowType::Widget, x as i32, y as i32);
            let Some(it) = d.view.iter_at_location(bx, by) else { return };
            if let Some(p) = it.paintable() {
                g.set_state(gtk::EventSequenceState::Claimed);
                d.buf.place_cursor(&it);
                // Une frise chronologique se modifie dans son propre dialogue.
                // SAFETY: posé par bridge, du type String, sous cette clé.
                let frise = unsafe { p.data::<String>("letters-image-alt").map(|a| a.as_ref().starts_with(crate::frise::PREFIX)) }.unwrap_or(false);
                let _ = WidgetExt::activate_action(&d.view, if frise { "win.edit-frise" } else { "win.image-properties" }, None);
                return;
            }
            let tag = d.buf.tag_table().lookup("table-line");
            if tag.is_some_and(|t| it.has_tag(&t)) {
                g.set_state(gtk::EventSequenceState::Claimed);
                d.buf.place_cursor(&it);
                let _ = WidgetExt::activate_action(&d.view, "win.edit-table", None);
            }
        });
        doc.view.add_controller(click);
    }
    // Tab / Maj+Tab dans une liste : changer de niveau.
    {
        let keys = gtk::EventControllerKey::new();
        keys.set_propagation_phase(gtk::PropagationPhase::Capture);
        let d = Rc::downgrade(doc);
        keys.connect_key_pressed(move |_, key, _, mods| {
            let Some(d) = d.upgrade() else { return glib::Propagation::Proceed };
            // Entrée dans un cartouche : une nouvelle ligne dans le cartouche ;
            // sur une ligne vide, on en sort. Maj+Entrée : toujours une ligne.
            if matches!(key, gtk::gdk::Key::Return | gtk::gdk::Key::KP_Enter) && !mods.contains(gtk::gdk::ModifierType::CONTROL_MASK) {
                if let Some(done) = crate::commands::cartouche_enter(&d.buf, mods.contains(gtk::gdk::ModifierType::SHIFT_MASK)) {
                    if done == crate::commands::EnterDone::NewLine && !crate::prefs::get().cartouche_hint_shown {
                        crate::prefs::update(|p| p.cartouche_hint_shown = true);
                        if let Some(w) = d.owner() {
                            w.toast("Entrée : nouvelle ligne dans le cartouche. Entrée sur une ligne vide : en sortir");
                        }
                    }
                    return glib::Propagation::Stop;
                }
                return glib::Propagation::Proceed;
            }
            if !matches!(key, gtk::gdk::Key::Tab | gtk::gdk::Key::ISO_Left_Tab) || mods.contains(gtk::gdk::ModifierType::CONTROL_MASK) {
                return glib::Propagation::Proceed;
            }
            let in_list = editor::caret_state(&d.buf).list.is_some_and(|l| l != ListKind::None);
            if !in_list {
                return glib::Propagation::Proceed;
            }
            let more = key == gtk::gdk::Key::Tab && !mods.contains(gtk::gdk::ModifierType::SHIFT_MASK);
            crate::commands::indent(&d.buf, more);
            if let Some(w) = d.owner() {
                w.after_format();
            }
            glib::Propagation::Stop
        });
        doc.view.add_controller(keys);
    }
    // Ctrl+V d'une image (capture d'écran, « Copier l'image » du
    // navigateur, fichier image copié dans Fichiers).
    {
        let d = Rc::downgrade(doc);
        doc.view.connect_paste_clipboard(move |view| {
            let Some(d) = d.upgrade() else { return };
            let clip = view.clipboard();
            let formats = clip.formats();
            let has_text = formats.contains_type(glib::GString::static_type()) || formats.contain_mime_type("text/plain;charset=utf-8");
            let paste_texture = |d2: Rc<Doc>, clip: gtk::gdk::Clipboard| {
                clip.read_texture_async(gio::Cancellable::NONE, move |res| {
                    if let Ok(Some(t)) = res {
                        let ok = crate::commands::insert_image_texture(&d2.buf, &t).is_ok();
                        if let Some(w) = d2.owner() {
                            w.after_format();
                            if ok {
                                w.offer_paste_text(crate::ocr::Source::Texture(t));
                            }
                        }
                    }
                });
            };
            if formats.contains_type(gtk::gdk::Texture::static_type()) && !has_text {
                view.stop_signal_emission_by_name("paste-clipboard");
                paste_texture(d.clone(), clip);
            } else if formats.contains_type(gtk::gdk::Texture::static_type()) && crate::prefs::get().paste_web_images {
                // Une image copiée dans un navigateur vient avec son adresse :
                // l'image passe avant. Un vrai texte (traitement de texte,
                // tableur) reste du texte.
                view.stop_signal_emission_by_name("paste-clipboard");
                let d2 = d.clone();
                let c2 = clip.clone();
                clip.read_text_async(gio::Cancellable::NONE, move |res| {
                    let text = res.ok().flatten().map(|t| t.to_string()).unwrap_or_default();
                    if crate::web::is_bare_address(&text) {
                        paste_texture(d2, c2);
                    } else {
                        d2.buf.delete_selection(true, true);
                        d2.buf.insert_interactive_at_cursor(&text, true);
                    }
                });
            } else if formats.contains_type(gtk::gdk::FileList::static_type()) {
                view.stop_signal_emission_by_name("paste-clipboard");
                let d2 = d.clone();
                clip.read_value_async(gtk::gdk::FileList::static_type(), glib::Priority::DEFAULT, gio::Cancellable::NONE, move |res| {
                    let Some(list) = res.ok().and_then(|v| v.get::<gtk::gdk::FileList>().ok()) else { return };
                    let mut pasted = Vec::new();
                    for f in list.files() {
                        if let Some(p) = f.path() {
                            if crate::commands::image_size(&p.to_string_lossy()).is_some() && crate::commands::insert_image(&d2.buf, &p).is_ok() {
                                pasted.push(p);
                            }
                        }
                    }
                    if let Some(w) = d2.owner() {
                        w.after_format();
                        // Une seule image collée : son texte peut la remplacer.
                        if let [p] = pasted.as_slice() {
                            w.offer_paste_text(crate::ocr::Source::File(p.clone()));
                        }
                    }
                });
            }
        });
    }
    {
        let d = Rc::downgrade(doc);
        doc.buf.connect_mark_set(move |_, _, mark| {
            if mark.name().as_deref() != Some("insert") {
                return;
            }
            let Some(d) = d.upgrade() else { return };
            if let Some(w) = d.owner().filter(|w| w.is_current(&d)) {
                w.schedule_sync();
            }
        });
    }
    {
        let d = Rc::downgrade(doc);
        doc.buf.connect_changed(move |_| {
            let Some(d) = d.upgrade() else { return };
            d.schedule_decorate();
            d.spell.schedule(&d.buf);
            let Some(w) = d.owner().filter(|w| w.is_current(&d)) else { return };
            w.schedule_sync();
            w.search.text_changed();
            w.schedule_outline();
            w.schedule_live();
        });
    }
    {
        let d = Rc::downgrade(doc);
        doc.buf.connect_modified_changed(move |_| {
            let Some(d) = d.upgrade() else { return };
            if let Some(w) = d.owner() {
                w.refresh_tab(&d);
            }
        });
    }
}

impl Window {
    pub(super) fn connect_tabs(self: &Rc<Self>, overview: &adw::TabOverview) {
        // Un onglet arrive (ajouté, ou glissé depuis une autre fenêtre).
        {
            let w = Rc::downgrade(self);
            self.tab_view.connect_page_attached(move |_, page, _| {
                let (Some(w), Some(d)) = (w.upgrade(), Doc::of(&page.child())) else { return };
                *d.owner.borrow_mut() = Rc::downgrade(&w);
                w.refresh_tab(&d);
            });
        }
        {
            let w = Rc::downgrade(self);
            self.tab_view.connect_selected_page_notify(move |_| {
                if let Some(w) = w.upgrade() {
                    w.switched();
                }
            });
        }
        // Fermer un onglet : proposer d'enregistrer.
        {
            let w = Rc::downgrade(self);
            self.tab_view.connect_close_page(move |view, page| {
                let Some(w) = w.upgrade() else { return glib::Propagation::Proceed };
                let Some(d) = Doc::of(&page.child()) else {
                    view.close_page_finish(page, true);
                    return glib::Propagation::Stop;
                };
                if !d.is_modified() || w.force_close.get() {
                    view.close_page_finish(page, true);
                    d.forget();
                    return glib::Propagation::Stop;
                }
                w.confirm_close_tab(page, &d);
                glib::Propagation::Stop
            });
        }
        // Plus d'onglet : la fenêtre se ferme.
        {
            let w = Rc::downgrade(self);
            self.tab_view.connect_page_detached(move |view, _, _| {
                let Some(w) = w.upgrade() else { return };
                if view.n_pages() == 0 {
                    w.force_close.set(true);
                    w.win.close();
                }
            });
        }
        // Onglet glissé hors de la fenêtre : une nouvelle fenêtre l'accueille.
        {
            let w = Rc::downgrade(self);
            self.tab_view.connect_create_window(move |_| {
                let w = w.upgrade()?;
                let app = w.win.application()?.downcast::<adw::Application>().ok()?;
                let target = create(&app, false);
                target.win.present();
                Some(target.tab_view.clone())
            });
        }
        // « + » de la vue d'ensemble : un document vide.
        {
            let w = Rc::downgrade(self);
            overview.connect_create_tab(move |_| {
                let w = w.upgrade().expect("fenêtre");
                w.add_blank_tab()
            });
        }
        {
            let w = Rc::downgrade(self);
            self.win.connect_close_request(move |_| {
                let Some(w) = w.upgrade() else { return glib::Propagation::Proceed };
                if w.force_close.get() {
                    w.forget_docs();
                    return glib::Propagation::Proceed;
                }
                let modified: Vec<Rc<Doc>> = w.docs().into_iter().filter(|d| d.is_modified()).collect();
                if modified.is_empty() {
                    w.forget_docs();
                    return glib::Propagation::Proceed;
                }
                w.confirm_close(modified);
                glib::Propagation::Stop
            });
        }
    }

    /// Les documents des onglets de cette fenêtre.
    pub(super) fn docs(&self) -> Vec<Rc<Doc>> {
        (0..self.tab_view.n_pages()).filter_map(|i| Doc::of(&self.tab_view.nth_page(i).child())).collect()
    }

    fn forget_docs(&self) {
        for d in self.docs() {
            d.forget();
        }
    }

    fn page_of(&self, doc: &Rc<Doc>) -> Option<adw::TabPage> {
        let page = self.tab_view.page(&doc.root);
        (page.child() == doc.root).then_some(page)
    }

    /// Ajoute l'onglet d'un document.
    pub(super) fn add_tab(self: &Rc<Self>, doc: &Rc<Doc>, select: bool) -> adw::TabPage {
        let page = self.tab_view.append(&doc.root);
        *doc.owner.borrow_mut() = Rc::downgrade(self);
        self.refresh_tab(doc);
        if select {
            self.tab_view.set_selected_page(&page);
            self.switched();
        }
        page
    }

    /// Un nouvel onglet vide (Ctrl+T, bouton Nouveau).
    pub fn add_blank_tab(self: &Rc<Self>) -> adw::TabPage {
        let doc = Doc::text();
        let page = self.add_tab(&doc, true);
        justify_blank(&doc);
        doc.view.grab_focus();
        page
    }

    /// L'onglet affiché s'il est neuf et vide, sinon un nouvel onglet : là
    /// où ouvrir un fichier.
    pub fn target_tab(self: &Rc<Self>) -> Rc<Doc> {
        let current = self.doc();
        if current.is_pristine() && self.page_of(&current).is_some() {
            return current;
        }
        self.add_blank_tab();
        self.doc()
    }

    /// Ouvre un fichier dans un onglet (ou montre l'onglet qui l'a déjà).
    pub fn open_file(self: &Rc<Self>, file: &gio::File) {
        let Some(path) = file.path() else {
            self.toast("Seuls les fichiers locaux sont pris en charge");
            return;
        };
        let canon = path.canonicalize().unwrap_or_else(|_| path.clone());
        if let Some(d) = Doc::all().into_iter().find(|d| d.path.borrow().as_ref().is_some_and(|p| p.canonicalize().unwrap_or_else(|_| p.clone()) == canon)) {
            if let Some(w) = d.owner() {
                if let Some(page) = w.page_of(&d) {
                    w.tab_view.set_selected_page(&page);
                    w.win.present();
                    return;
                }
            }
        }
        if path.extension().is_some_and(|e| e.eq_ignore_ascii_case("pdf")) {
            match Doc::pdf(&path) {
                Ok(doc) => {
                    let pristine = Some(self.doc()).filter(|c| c.is_pristine() && self.page_of(c).is_some());
                    self.add_tab(&doc, true);
                    if let Some(old) = pristine.and_then(|c| self.page_of(&c).map(|p| (c, p))) {
                        self.tab_view.close_page(&old.1);
                    }
                    crate::store::add_recent(&path);
                    self.refresh_recents();
                }
                Err(e) => self.error("Impossible d'ouvrir le PDF", &e),
            }
            return;
        }
        let doc = self.target_tab();
        if let Some(page) = self.page_of(&doc) {
            self.tab_view.set_selected_page(&page);
        }
        self.load(file);
    }

    /// Le titre de l'onglet (et de la fenêtre si c'est l'onglet affiché).
    pub(super) fn refresh_tab(&self, doc: &Rc<Doc>) {
        if let Some(page) = self.page_of(doc) {
            let name = doc.display_name();
            page.set_title(&if doc.is_modified() { format!("• {name}") } else { name });
            page.set_tooltip(&doc.path.borrow().as_ref().map(|p| glib::markup_escape_text(&p.to_string_lossy()).to_string()).unwrap_or_default());
            if doc.is_pdf() {
                page.set_icon(Some(&gio::ThemedIcon::new("x-office-document-symbolic")));
            }
        }
        if self.is_current(doc) {
            self.update_title();
        }
    }

    /// Un autre onglet est affiché : les barres suivent son document.
    pub(super) fn switched(self: &Rc<Self>) {
        let Some(page) = self.tab_view.selected_page() else { return };
        let Some(doc) = Doc::of(&page.child()) else { return };
        *self.current.borrow_mut() = doc.clone();
        let pdf = doc.is_pdf();
        for w in &self.text_only {
            w.set_visible(!pdf);
        }
        self.toc_btn.set_visible(!pdf);
        self.ocr_pdf_btn.set_visible(pdf);
        self.apply_tool_prefs();
        let blocks = (0..BLOCK_STYLES.len()).map(|i| format!("block-{i}"));
        for name in EDIT_ACTIONS.iter().map(|s| s.to_string()).chain(blocks) {
            if let Some(a) = self.win.lookup_action(&name).and_then(|a| a.downcast::<gio::SimpleAction>().ok()) {
                a.set_enabled(!pdf);
            }
        }
        if !pdf {
            self.search.attach(&doc.buf, &doc.view);
            self.syncing.set(true);
            self.spell_btn.set_active(doc.spell.enabled.get() && doc.spell.available());
            self.syncing.set(false);
            self.sync_toolbar();
        } else {
            self.search.widget.set_reveal_child(false);
        }
        self.zoom_label.set_text(&format!("{} %", (doc.zoom.get() * 100.0).round()));
        self.update_title();
        if self.split.shows_sidebar() {
            self.refresh_outline();
        }
        self.live_switched();
        self.place_ruler();
        if self.focus.get() {
            self.zen_padding();
        }
        if !pdf {
            doc.view.grab_focus();
        }
    }

    pub(super) fn schedule_outline(self: &Rc<Self>) {
        if !self.split.shows_sidebar() || self.outline_pending.replace(true) {
            return;
        }
        let w = Rc::downgrade(self);
        glib::timeout_add_local_once(std::time::Duration::from_millis(400), move || {
            if let Some(w) = w.upgrade() {
                w.outline_pending.set(false);
                w.refresh_outline();
            }
        });
    }

    /// Ferme l'onglet affiché (Ctrl+W).
    pub(super) fn close_current_tab(&self) {
        if let Some(page) = self.tab_view.selected_page() {
            self.tab_view.close_page(&page);
        }
    }

    fn confirm_close_tab(self: &Rc<Self>, page: &adw::TabPage, doc: &Rc<Doc>) {
        let d = adw::AlertDialog::new(Some("Enregistrer les modifications ?"), Some(&format!("« {} » a des modifications non enregistrées.", doc.display_name())));
        d.add_responses(&[("cancel", "Annuler"), ("discard", "Ne pas enregistrer"), ("save", "Enregistrer")]);
        d.set_response_appearance("discard", adw::ResponseAppearance::Destructive);
        d.set_response_appearance("save", adw::ResponseAppearance::Suggested);
        d.set_default_response(Some("save"));
        d.set_close_response("cancel");
        let (w, page, doc) = (self.clone(), page.clone(), doc.clone());
        d.choose(Some(&self.win), gio::Cancellable::NONE, move |resp| match resp.as_str() {
            "discard" => {
                w.tab_view.close_page_finish(&page, true);
                doc.forget();
            }
            "save" => {
                w.tab_view.set_selected_page(&page);
                let (w2, page2, doc2) = (w.clone(), page.clone(), doc.clone());
                w.save(move |ok| {
                    w2.tab_view.close_page_finish(&page2, ok);
                    if ok {
                        doc2.forget();
                    }
                });
            }
            _ => w.tab_view.close_page_finish(&page, false),
        });
    }

    /// Fermer la fenêtre avec des documents non enregistrés : une seule
    /// question, une case par document.
    fn confirm_close(self: &Rc<Self>, modified: Vec<Rc<Doc>>) {
        let one = modified.len() == 1;
        let d = adw::AlertDialog::new(
            Some("Enregistrer les modifications ?"),
            Some(if one { "Ce document a des modifications non enregistrées." } else { "Ces documents ont des modifications non enregistrées. Cochez ceux à enregistrer." }),
        );
        let list = gtk::ListBox::builder().selection_mode(gtk::SelectionMode::None).build();
        list.add_css_class("boxed-list");
        let mut checks = Vec::new();
        for doc in &modified {
            let check = gtk::CheckButton::builder().active(true).valign(gtk::Align::Center).build();
            let row = adw::ActionRow::builder().title(glib::markup_escape_text(&doc.display_name()).as_str()).activatable_widget(&check).build();
            if let Some(dir) = doc.path.borrow().as_ref().and_then(|p| p.parent()) {
                row.set_subtitle(&glib::markup_escape_text(&tilde(dir)));
            }
            row.add_prefix(&check);
            list.append(&row);
            checks.push(check);
        }
        if !one {
            d.set_extra_child(Some(&list));
        }
        d.add_responses(&[("cancel", "Annuler"), ("discard", "Fermer sans enregistrer"), ("save", "Enregistrer")]);
        d.set_response_appearance("discard", adw::ResponseAppearance::Destructive);
        d.set_response_appearance("save", adw::ResponseAppearance::Suggested);
        d.set_default_response(Some("save"));
        d.set_close_response("cancel");
        let w = self.clone();
        d.choose(Some(&self.win), gio::Cancellable::NONE, move |resp| match resp.as_str() {
            "discard" => {
                w.force_close.set(true);
                w.win.close();
            }
            "save" => {
                let chosen: Vec<Rc<Doc>> = modified.iter().zip(&checks).filter(|(_, c)| c.is_active()).map(|(d, _)| d.clone()).collect();
                w.save_all(chosen);
            }
            _ => {}
        });
    }

    /// Enregistre les documents l'un après l'autre, puis ferme la fenêtre.
    /// Un enregistrement annulé laisse la fenêtre ouverte.
    fn save_all(self: &Rc<Self>, mut docs: Vec<Rc<Doc>>) {
        if docs.is_empty() {
            self.force_close.set(true);
            self.win.close();
            return;
        }
        let doc = docs.remove(0);
        if let Some(page) = self.page_of(&doc) {
            self.tab_view.set_selected_page(&page);
        }
        let w = self.clone();
        self.save(move |ok| {
            if ok {
                w.save_all(docs);
            }
        });
    }
}

/// Les actions sans objet sur un PDF.
const EDIT_ACTIONS: &[&str] = &[
    "ocr-import",
    "export-usb",
    "insert-frise",
    "edit-frise",
    "amenagements",
    "cartouche-default",
    "remove-cartouche",
    "toggle-line-numbers",
    "save",
    "save-as",
    "export-pdf",
    "save-both",
    "save-template",
    "undo",
    "redo",
    "replace",
    "page-setup",
    "preview",
    "indent-more",
    "indent-toggle",
    "paragraph-style",
    "indent-less",
    "toggle-bullets",
    "toggle-numbers",
    "align",
    "line-spacing",
    "insert-toc",
    "insert-image",
    "insert-link",
    "insert-textbox",
    "insert-table",
    "edit-table",
    "image-properties",
    "toggle-bold",
    "toggle-italic",
    "toggle-underline",
    "toggle-strikethrough",
    "table-row-above",
    "table-row-below",
    "table-col-left",
    "table-col-right",
    "table-delete-row",
    "table-delete-col",
];

/// Un document neuf commence justifié. Un fichier ouvert ou un modèle garde
/// ses propres alignements : ils remplacent ce paragraphe vide.
fn justify_blank(doc: &Doc) {
    let buf = doc.buf.clone();
    if buf.char_count() != 0 {
        return;
    }
    buf.place_cursor(&buf.start_iter());
    crate::formatting::align_in(&buf, "align-justify");
    buf.set_modified(false);
}
