// shapes.rs — formes simples (flèches, carré, rectangle, rond, étoile),
// dessinées en PNG haute résolution puis insérées comme des images : elles
// se redimensionnent et s'enregistrent comme toute image.
// SPDX-License-Identifier: GPL-3.0-or-later

use gtk4::{self as gtk, cairo};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Shape {
    ArrowRight,
    ArrowLeft,
    Square,
    Rectangle,
    Circle,
    Star,
}

pub const SHAPES: [(Shape, &str); 6] = [
    (Shape::ArrowRight, "Flèche vers la droite"),
    (Shape::ArrowLeft, "Flèche vers la gauche"),
    (Shape::Square, "Carré"),
    (Shape::Rectangle, "Rectangle"),
    (Shape::Circle, "Rond"),
    (Shape::Star, "Étoile"),
];

impl Shape {
    /// Proportions (largeur, hauteur) de la forme.
    pub fn aspect(self) -> (f64, f64) {
        match self {
            Shape::ArrowRight | Shape::ArrowLeft => (2.0, 1.0),
            Shape::Rectangle => (2.0, 1.2),
            _ => (1.0, 1.0),
        }
    }

    /// Trace le contour de la forme dans le rectangle (0, 0, w, h).
    pub fn path(self, cr: &cairo::Context, w: f64, h: f64) {
        match self {
            Shape::Square | Shape::Rectangle => rounded(cr, 0.0, 0.0, w, h, w.min(h) * 0.06),
            Shape::Circle => {
                cr.save().ok();
                cr.translate(w / 2.0, h / 2.0);
                cr.scale(w / 2.0, h / 2.0);
                cr.arc(0.0, 0.0, 1.0, 0.0, std::f64::consts::TAU);
                cr.restore().ok();
            }
            Shape::Star => {
                let (cx, cy) = (w / 2.0, h * 0.53);
                let (r1, r2) = (w.min(h) * 0.5, w.min(h) * 0.2);
                for i in 0..10 {
                    let a = -std::f64::consts::FRAC_PI_2 + i as f64 * std::f64::consts::PI / 5.0;
                    let r = if i % 2 == 0 { r1 } else { r2 };
                    let (x, y) = (cx + r * a.cos(), cy + r * a.sin());
                    if i == 0 {
                        cr.move_to(x, y);
                    } else {
                        cr.line_to(x, y);
                    }
                }
                cr.close_path();
            }
            Shape::ArrowRight | Shape::ArrowLeft => {
                // Flèche vers la droite ; miroir pour la gauche.
                let pts = [(0.0, 0.3), (0.6, 0.3), (0.6, 0.0), (1.0, 0.5), (0.6, 1.0), (0.6, 0.7), (0.0, 0.7)];
                for (i, (x, y)) in pts.iter().enumerate() {
                    let x = if self == Shape::ArrowLeft { 1.0 - x } else { *x };
                    if i == 0 {
                        cr.move_to(x * w, y * h);
                    } else {
                        cr.line_to(x * w, y * h);
                    }
                }
                cr.close_path();
            }
        }
    }
}

fn rounded(cr: &cairo::Context, x: f64, y: f64, w: f64, h: f64, r: f64) {
    use std::f64::consts::PI;
    cr.new_sub_path();
    cr.arc(x + w - r, y + r, r, -PI / 2.0, 0.0);
    cr.arc(x + w - r, y + h - r, r, 0.0, PI / 2.0);
    cr.arc(x + r, y + h - r, r, PI / 2.0, PI);
    cr.arc(x + r, y + r, r, PI, 1.5 * PI);
    cr.close_path();
}

fn rgb(hex: &str) -> (f64, f64, f64) {
    let v = u32::from_str_radix(hex.trim_start_matches('#'), 16).unwrap_or(0x3584e4);
    (((v >> 16) & 255) as f64 / 255.0, ((v >> 8) & 255) as f64 / 255.0, (v & 255) as f64 / 255.0)
}

/// La « couleur » des formes sans remplissage.
pub const TRANSPARENT: &str = "transparent";

/// Dessine la forme pleine, de couleur `hex`, avec un liseré plus foncé ;
/// transparente : le contour seul, gris foncé.
pub fn paint(cr: &cairo::Context, shape: Shape, hex: &str, w: f64, h: f64) {
    if hex == TRANSPARENT {
        let lw = (w.min(h) * 0.045).max(1.5);
        cr.save().ok();
        cr.translate(lw, lw);
        shape.path(cr, w - 2.0 * lw, h - 2.0 * lw);
        cr.set_source_rgb(0.24, 0.22, 0.27);
        cr.set_line_width(lw);
        cr.set_line_join(cairo::LineJoin::Round);
        let _ = cr.stroke();
        cr.restore().ok();
        return;
    }
    let lw = (w.min(h) * 0.03).max(1.0);
    cr.save().ok();
    cr.translate(lw, lw);
    shape.path(cr, w - 2.0 * lw, h - 2.0 * lw);
    let (r, g, b) = rgb(hex);
    cr.set_source_rgb(r, g, b);
    let _ = cr.fill_preserve();
    cr.set_source_rgb(r * 0.7, g * 0.7, b * 0.7);
    cr.set_line_width(lw);
    cr.set_line_join(cairo::LineJoin::Round);
    let _ = cr.stroke();
    cr.restore().ok();
}

/// La forme en PNG (fond transparent), dans le cache des images ; renvoie
/// son chemin.
pub fn render_png(shape: Shape, hex: &str) -> Result<std::path::PathBuf, String> {
    let (aw, ah) = shape.aspect();
    let (w, h) = ((aw * 600.0) as i32, (ah * 600.0) as i32);
    let surface = cairo::ImageSurface::create(cairo::Format::ARgb32, w, h).map_err(|e| e.to_string())?;
    {
        let cr = cairo::Context::new(&surface).map_err(|e| e.to_string())?;
        paint(&cr, shape, hex, w as f64, h as f64);
    }
    let dir = gtk::glib::user_cache_dir().join(crate::DIR).join("images");
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let t = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0);
    let path = dir.join(format!("forme-{t:x}.png"));
    let mut f = std::fs::File::create(&path).map_err(|e| e.to_string())?;
    surface.write_to_png(&mut f).map_err(|e| e.to_string())?;
    Ok(path)
}
