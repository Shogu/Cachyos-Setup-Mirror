// ruler.rs — la règle graduée au-dessus de la page.
//
// Elle mesure en centimètres depuis le début du texte, à l'échelle exacte
// des retraits (1 cm à l'écran = 1 cm imprimé). Le triangle bleu est le
// retrait du paragraphe du curseur : on le tire pour le changer, par pas de
// 0,25 cm. Un clic sur une graduation pose une ligne repère verticale sur
// toute la page (pour vérifier qu'une image, un cartouche et le texte
// tombent au même endroit). Chaque ligne a sa pastille en haut de la règle :
// un clic dessus l'enlève, on la tire pour la déplacer, ou hors de la règle
// pour la jeter ; clic droit : tout enlever.
// SPDX-License-Identifier: GPL-3.0-or-later

use std::cell::{Cell, RefCell};
use std::rc::Rc;

use gtk4::{self as gtk, prelude::*};

/// Pixels par centimètre dans l'éditeur à 100 % (96 points par pouce).
pub const PX_PER_CM: f64 = 96.0 / 2.54;
/// Points par centimètre (les retraits sont en points).
pub const PT_PER_CM: f64 = 72.0 / 2.54;
const HEIGHT: i32 = 24;
const STEP_CM: f64 = 0.25;

thread_local! {
    /// Les lignes repères, en cm depuis le début du texte (toutes les pages).
    static GUIDES: RefCell<Vec<f64>> = const { RefCell::new(Vec::new()) };
}

pub fn guides() -> Vec<f64> {
    GUIDES.with(|g| g.borrow().clone())
}

/// Pose une ligne repère à `cm`, ou l'enlève s'il y en a une tout près.
fn toggle_guide(cm: f64) {
    GUIDES.with(|g| {
        let mut g = g.borrow_mut();
        if let Some(i) = g.iter().position(|x| (x - cm).abs() < STEP_CM / 2.0) {
            g.remove(i);
        } else {
            g.push(cm);
        }
    });
}

/// Dessine les lignes repères sur une page (coordonnées de la vue du texte,
/// dont le texte commence à `text_x`).
pub fn draw_guides(cr: &gtk::cairo::Context, text_x: f64, height: f64) {
    let gs = guides();
    if gs.is_empty() {
        return;
    }
    cr.set_source_rgba(0.21, 0.52, 0.89, 0.75);
    cr.set_line_width(1.0);
    cr.set_dash(&[5.0, 4.0], 0.0);
    for g in gs {
        let x = (text_x + g * PX_PER_CM).round() + 0.5;
        cr.move_to(x, 0.0);
        cr.line_to(x, height);
    }
    let _ = cr.stroke();
}

fn set_guide(i: usize, cm: f64) {
    GUIDES.with(|g| {
        if let Some(x) = g.borrow_mut().get_mut(i) {
            *x = cm;
        }
    });
}

fn remove_guide(i: usize) {
    GUIDES.with(|g| {
        let mut g = g.borrow_mut();
        if i < g.len() {
            g.remove(i);
        }
    });
}

fn clear_guides() {
    GUIDES.with(|g| g.borrow_mut().clear());
}

/// Tolérance (en pixels) pour attraper une ligne repère dans la règle.
const GRAB_PX: f64 = 8.0;
/// Tirée à plus de tant de pixels au-dessus ou au-dessous, elle est jetée.
const DROP_PX: f64 = 22.0;

fn snap(cm: f64) -> f64 {
    (cm / STEP_CM).round() * STEP_CM
}

pub struct Ruler {
    pub widget: gtk::DrawingArea,
    view: RefCell<Option<gtk::TextView>>,
    /// Retrait du paragraphe du curseur, en cm ; `None` dans une liste.
    indent: Cell<Option<f64>>,
    /// Pendant qu'on tire le triangle : la position proposée.
    dragging: Cell<Option<f64>>,
    start_x: Cell<f64>,
    /// La ligne repère qu'on tire : (indice, position, va être jetée).
    moving: Cell<Option<(usize, f64, bool)>>,
    /// La ligne repère sous le pointeur.
    hover: Cell<Option<usize>>,
    /// Où était le texte au dernier dessin (pour redessiner s'il bouge).
    last_x0: Cell<f64>,
    on_indent: RefCell<Option<Box<dyn Fn(f64)>>>,
    on_guides: RefCell<Option<Box<dyn Fn()>>>,
}

impl Ruler {
    pub fn new() -> Rc<Self> {
        let widget = gtk::DrawingArea::builder().content_height(HEIGHT).hexpand(true).build();
        widget.set_tooltip_text(Some("Clic sur une graduation : poser une ligne repère\nClic sur sa pastille : l'enlever · la tirer : la déplacer\nClic droit : enlever toutes les lignes repères\nTirer le triangle bleu : retrait du paragraphe"));
        widget.add_css_class("samizdat-ruler");
        let this = Rc::new(Self {
            widget,
            view: RefCell::new(None),
            indent: Cell::new(Some(0.0)),
            dragging: Cell::new(None),
            start_x: Cell::new(0.0),
            moving: Cell::new(None),
            hover: Cell::new(None),
            last_x0: Cell::new(f64::NAN),
            on_indent: RefCell::new(None),
            on_guides: RefCell::new(None),
        });
        this.connect();
        this
    }

    pub fn set_view(&self, view: Option<&gtk::TextView>) {
        *self.view.borrow_mut() = view.cloned();
        self.widget.queue_draw();
    }

    /// Le retrait du paragraphe du curseur (en points), `None` dans une liste.
    pub fn set_indent(&self, pt: Option<f64>) {
        let cm = pt.map(|p| p / PT_PER_CM);
        if cm != self.indent.get() {
            self.indent.set(cm);
            self.widget.queue_draw();
        }
    }

    pub fn connect_indent(&self, f: impl Fn(f64) + 'static) {
        *self.on_indent.borrow_mut() = Some(Box::new(f));
    }

    pub fn connect_guides(&self, f: impl Fn() + 'static) {
        *self.on_guides.borrow_mut() = Some(Box::new(f));
    }

    /// Début et fin du texte dans la règle, et pixels par cm (zoom compris).
    fn geometry(&self) -> Option<(f64, f64, f64)> {
        let view = self.view.borrow().clone()?;
        let left = crate::bridge::EDITOR_LEFT_MARGIN_PX as f32;
        let p0 = view.compute_point(&self.widget, &gtk::graphene::Point::new(left, 0.0))?;
        let p1 = view.compute_point(&self.widget, &gtk::graphene::Point::new(left + PX_PER_CM as f32, 0.0))?;
        let pe = view.compute_point(&self.widget, &gtk::graphene::Point::new(view.width() as f32 - left, 0.0))?;
        let scale = (p1.x() - p0.x()) as f64;
        (scale > 1.0).then_some((p0.x() as f64, pe.x() as f64, scale))
    }

    /// La ligne repère à portée du pointeur, s'il y en a une.
    fn guide_at(&self, x: f64) -> Option<usize> {
        let (x0, _, s) = self.geometry()?;
        guides()
            .iter()
            .enumerate()
            .map(|(i, g)| (i, (x - (x0 + g * s)).abs()))
            .filter(|(_, d)| *d <= GRAB_PX)
            .min_by(|a, b| a.1.total_cmp(&b.1))
            .map(|(i, _)| i)
    }

    fn near_indent(&self, x: f64, y: f64) -> bool {
        let h = self.widget.height() as f64;
        match (self.geometry(), self.indent.get()) {
            (Some((x0, _, s)), Some(ind)) => y >= h - 14.0 && (x - (x0 + ind * s)).abs() <= 7.0,
            _ => false,
        }
    }

    fn guides_changed(&self) {
        self.widget.queue_draw();
        if let Some(f) = self.on_guides.borrow().as_ref() {
            f();
        }
    }

    fn connect(self: &Rc<Self>) {
        // Survol : la pastille sous le pointeur s'allume, le pointeur devient une main.
        {
            let motion = gtk::EventControllerMotion::new();
            let w = Rc::downgrade(self);
            motion.connect_motion(move |_, x, y| {
                let Some(w) = w.upgrade() else { return };
                let hov = if w.near_indent(x, y) { None } else { w.guide_at(x) };
                let cursor = if w.near_indent(x, y) {
                    Some("ew-resize")
                } else if hov.is_some() {
                    Some("pointer")
                } else {
                    None
                };
                w.widget.set_cursor_from_name(cursor);
                if hov != w.hover.get() {
                    w.hover.set(hov);
                    w.widget.queue_draw();
                }
            });
            let w = Rc::downgrade(self);
            motion.connect_leave(move |_| {
                let Some(w) = w.upgrade() else { return };
                if w.hover.take().is_some() {
                    w.widget.queue_draw();
                }
            });
            self.widget.add_controller(motion);
        }
        // Clic droit : enlever toutes les lignes repères.
        {
            let click = gtk::GestureClick::builder().button(3).build();
            let w = Rc::downgrade(self);
            click.connect_pressed(move |g, _, x, y| {
                g.set_state(gtk::EventSequenceState::Claimed);
                let Some(w) = w.upgrade() else { return };
                let pop = gtk::Popover::new();
                pop.set_parent(&w.widget);
                pop.set_pointing_to(Some(&gtk::gdk::Rectangle::new(x as i32, y as i32, 1, 1)));
                pop.set_has_arrow(false);
                let btn = gtk::Button::with_label("Enlever toutes les lignes repères");
                btn.add_css_class("flat");
                btn.set_sensitive(!guides().is_empty());
                let ww = Rc::downgrade(&w);
                let p = pop.clone();
                btn.connect_clicked(move |_| {
                    p.popdown();
                    if let Some(w) = ww.upgrade() {
                        clear_guides();
                        w.hover.set(None);
                        w.guides_changed();
                    }
                });
                pop.set_child(Some(&btn));
                w.widget.set_has_tooltip(false);
                let ww = Rc::downgrade(&w);
                pop.connect_closed(move |p| {
                    if let Some(w) = ww.upgrade() {
                        w.widget.set_has_tooltip(true);
                    }
                    let p = p.clone();
                    gtk::glib::idle_add_local_once(move || p.unparent());
                });
                pop.popup();
            });
            self.widget.add_controller(click);
        }
        {
            let w = Rc::downgrade(self);
            self.widget.set_draw_func(move |_, cr, width, height| {
                if let Some(w) = w.upgrade() {
                    w.draw(cr, width as f64, height as f64);
                }
            });
        }
        // La page bouge (fenêtre, aperçu à droite, zoom) : la règle suit.
        {
            let w = Rc::downgrade(self);
            self.widget.add_tick_callback(move |_, _| {
                let Some(w) = w.upgrade() else { return gtk::glib::ControlFlow::Break };
                if w.widget.is_drawable() {
                    let x0 = w.geometry().map_or(-1.0, |g| g.0);
                    if (x0 - w.last_x0.get()).abs() > 0.5 {
                        w.widget.queue_draw();
                    }
                }
                gtk::glib::ControlFlow::Continue
            });
        }
        let drag = gtk::GestureDrag::new();
        {
            let w = Rc::downgrade(self);
            drag.connect_drag_begin(move |g, x, y| {
                // La règle garde le geste : sinon, dans la zone des barres,
                // tirer déplacerait toute la fenêtre.
                g.set_state(gtk::EventSequenceState::Claimed);
                let Some(w) = w.upgrade() else { return };
                w.start_x.set(x);
                if w.near_indent(x, y) {
                    w.dragging.set(w.indent.get());
                } else if let Some(i) = w.guide_at(x) {
                    w.moving.set(Some((i, guides()[i], false)));
                } else if let (Some((x0, _, s)), Some(ind)) = (w.geometry(), w.indent.get()) {
                    if (x - (x0 + ind * s)).abs() <= 7.0 {
                        w.dragging.set(Some(ind));
                    }
                }
            });
        }
        {
            let w = Rc::downgrade(self);
            drag.connect_drag_update(move |_, dx, dy| {
                let Some(w) = w.upgrade() else { return };
                if let Some((i, _, _)) = w.moving.get() {
                    if dx.abs() < 3.0 && dy.abs() < 3.0 {
                        return;
                    }
                    let Some((x0, x1, s)) = w.geometry() else { return };
                    let cm = snap(((w.start_x.get() + dx) - x0) / s).clamp(0.0, (x1 - x0) / s);
                    let out = dy.abs() > DROP_PX;
                    w.moving.set(Some((i, cm, out)));
                    set_guide(i, cm);
                    w.widget.set_cursor_from_name(Some(if out { "not-allowed" } else { "grabbing" }));
                    w.guides_changed();
                    return;
                }
                if w.dragging.get().is_none() {
                    return;
                }
                let Some((x0, x1, s)) = w.geometry() else { return };
                let max = ((x1 - x0) / s - 2.0).max(0.0);
                let cm = snap(((w.start_x.get() + dx) - x0) / s).clamp(0.0, max);
                w.dragging.set(Some(cm));
                w.widget.queue_draw();
            });
        }
        {
            let w = Rc::downgrade(self);
            drag.connect_drag_end(move |_, dx, dy| {
                let Some(w) = w.upgrade() else { return };
                if let Some((i, _, out)) = w.moving.take() {
                    // Un simple clic sur la pastille, ou tirée hors de la règle : on l'enlève.
                    if out || (dx.abs() < 3.0 && dy.abs() < 3.0) {
                        remove_guide(i);
                    }
                    w.hover.set(None);
                    w.widget.set_cursor_from_name(None);
                    w.guides_changed();
                    return;
                }
                if let Some(cm) = w.dragging.take() {
                    if w.indent.get().is_none_or(|i| (i - cm).abs() > 0.01) {
                        w.indent.set(Some(cm));
                        if let Some(f) = w.on_indent.borrow().as_ref() {
                            f(cm);
                        }
                    }
                    w.widget.queue_draw();
                    return;
                }
                // Un clic (pas un glissé) : une ligne repère.
                if dx.abs() < 3.0 {
                    let Some((x0, x1, s)) = w.geometry() else { return };
                    let x = w.start_x.get();
                    if x < x0 - 4.0 || x > x1 + 4.0 {
                        return;
                    }
                    toggle_guide(snap((x - x0) / s).max(0.0));
                    w.guides_changed();
                }
            });
        }
        self.widget.add_controller(drag);
    }

    fn draw(&self, cr: &gtk::cairo::Context, width: f64, height: f64) {
        let Some((x0, x1, s)) = self.geometry() else { return };
        self.last_x0.set(x0);
        let dark = adw_dark();
        let (fg, faint) = if dark { ((0.9, 0.9, 0.9), 0.55) } else { ((0.2, 0.2, 0.2), 0.6) };
        // La bande du texte, claire ; les marges de part et d'autre, grisées.
        cr.set_source_rgba(fg.0, fg.1, fg.2, 0.06);
        cr.rectangle(0.0, 2.0, width, height - 4.0);
        let _ = cr.fill();
        cr.set_source_rgba(1.0, 1.0, 1.0, if dark { 0.10 } else { 0.85 });
        cr.rectangle(x0, 2.0, x1 - x0, height - 4.0);
        let _ = cr.fill();
        // Graduations : tous les 0,25 cm, chiffrées tous les centimètres.
        let layout = pangocairo::functions::create_layout(cr);
        layout.set_font_description(Some(&gtk::pango::FontDescription::from_string("Sans 7")));
        let n = ((x1 - x0) / s / STEP_CM).floor() as i32;
        for k in 0..=n {
            let cm = k as f64 * STEP_CM;
            let x = (x0 + cm * s).round() + 0.5;
            let whole = k % 4 == 0;
            let half = k % 2 == 0;
            let len = if whole { 7.0 } else if half { 5.0 } else { 3.0 };
            cr.set_source_rgba(fg.0, fg.1, fg.2, faint);
            cr.set_line_width(1.0);
            cr.move_to(x, height - 3.0);
            cr.line_to(x, height - 3.0 - len);
            let _ = cr.stroke();
            if whole && k > 0 {
                layout.set_text(&format!("{}", k / 4));
                let (tw, _) = layout.pixel_size();
                cr.move_to(x - tw as f64 / 2.0, 3.0);
                pangocairo::functions::show_layout(cr, &layout);
            }
        }
        // Lignes repères posées.
        // Chacune a sa pastille en haut, grosse cible pour la reprendre.
        let moving = self.moving.get();
        for (i, g) in guides().into_iter().enumerate() {
            let x = (x0 + g * s).round() + 0.5;
            let hot = self.hover.get() == Some(i) || moving.is_some_and(|m| m.0 == i);
            let gone = moving.is_some_and(|m| m.0 == i && m.2);
            let a = if gone { 0.35 } else { 1.0 };
            cr.set_source_rgba(0.21, 0.52, 0.89, a);
            cr.set_line_width(if hot { 2.0 } else { 1.5 });
            cr.move_to(x, 2.0);
            cr.line_to(x, height - 2.0);
            let _ = cr.stroke();
            // Pastille : un écusson qui pointe vers le bas.
            let r = if hot { 6.0 } else { 4.5 };
            cr.move_to(x - r, 1.0);
            cr.line_to(x + r, 1.0);
            cr.line_to(x + r, 1.0 + r * 1.2);
            cr.line_to(x, 1.0 + r * 2.0);
            cr.line_to(x - r, 1.0 + r * 1.2);
            cr.close_path();
            if hot {
                cr.set_source_rgba(0.88, 0.11, 0.14, a);
            }
            let _ = cr.fill();
            if hot && !gone && moving.is_none() {
                // Une petite croix blanche : cliquer l'enlève.
                cr.set_source_rgb(1.0, 1.0, 1.0);
                cr.set_line_width(1.4);
                let (cx, cy, d) = (x, 1.0 + r * 0.9, 2.0);
                cr.move_to(cx - d, cy - d);
                cr.line_to(cx + d, cy + d);
                cr.move_to(cx + d, cy - d);
                cr.line_to(cx - d, cy + d);
                let _ = cr.stroke();
            }
        }
        // Le retrait du paragraphe (ou celui qu'on tire).
        if let Some(ind) = self.dragging.get().or(self.indent.get()) {
            let x = x0 + ind * s;
            cr.set_source_rgb(0.21, 0.52, 0.89);
            cr.move_to(x - 6.0, height - 12.0);
            cr.line_to(x + 6.0, height - 12.0);
            cr.line_to(x, height - 3.0);
            cr.close_path();
            let _ = cr.fill();
            if self.dragging.get().is_some() {
                layout.set_text(&format!("{:.2} cm", ind).replace('.', ","));
                let (tw, _) = layout.pixel_size();
                cr.move_to((x + 8.0).min(width - tw as f64 - 2.0), 3.0);
                pangocairo::functions::show_layout(cr, &layout);
            }
        }
    }
}

fn adw_dark() -> bool {
    libadwaita::StyleManager::default().is_dark()
}
