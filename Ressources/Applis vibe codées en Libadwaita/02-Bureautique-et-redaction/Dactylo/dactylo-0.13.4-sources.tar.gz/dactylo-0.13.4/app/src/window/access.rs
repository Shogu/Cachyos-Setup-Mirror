// window/access.rs — le bouton Aménagements : un PDF adapté (police,
// taille, interligne, contraste, alignement), le document restant tel quel.
// SPDX-License-Identifier: GPL-3.0-or-later

use super::*;
use crate::amenagements::{self, Font, Options, SIZES, SPACINGS};

fn combo(title: &str, items: &[&str], selected: usize) -> adw::ComboRow {
    let model = gtk::StringList::new(items);
    adw::ComboRow::builder().title(title).model(&model).selected(selected as u32).build()
}

impl Window {
    pub(super) fn amenagements_dialog(self: &Rc<Self>) {
        let o = Options::load();
        let page = adw::PreferencesPage::new();
        let reading = adw::PreferencesGroup::builder()
            .title("Lecture")
            .description("Un PDF à part, « Nom (aménagé).pdf » : le document lui-même ne change pas.")
            .build();
        let fonts: Vec<&str> = Font::ALL.iter().map(|(_, l)| *l).collect();
        let font = combo("Police", &fonts, Font::ALL.iter().position(|(f, _)| *f == o.font).unwrap_or(0));
        let note = |f: Font| match f {
            Font::Luciole if !amenagements::installed("Luciole") => "Non installée : réinstallez Dactylo",
            Font::Luciole => "Dessinée pour les élèves malvoyants",
            Font::OpenDyslexic if !amenagements::installed("OpenDyslexic") => "Non installée : réinstallez Dactylo",
            Font::OpenDyslexic => "Lettres lestées vers le bas, pour les élèves dyslexiques",
            Font::Document => "",
        };
        font.set_subtitle(note(o.font));
        font.connect_selected_notify(move |r| {
            let f = Font::ALL.get(r.selected() as usize).map_or(Font::Document, |(f, _)| *f);
            r.set_subtitle(note(f));
        });
        let sizes: Vec<&str> = SIZES.iter().map(|(_, l)| *l).collect();
        let size = combo("Taille du texte", &sizes, o.size);
        size.set_subtitle("Les titres grandissent dans la même proportion");
        let spacings: Vec<&str> = SPACINGS.iter().map(|(_, l)| *l).collect();
        let spacing = combo("Interligne", &spacings, o.spacing);
        reading.add(&font);
        reading.add(&size);
        reading.add(&spacing);
        page.add(&reading);

        let layout = adw::PreferencesGroup::builder().title("Mise en page").build();
        let left = adw::SwitchRow::builder()
            .title("Aligné à gauche")
            .subtitle("Pas de texte justifié : des espaces réguliers entre les mots")
            .active(o.left)
            .build();
        let contrast = adw::SwitchRow::builder()
            .title("Grand contraste")
            .subtitle("Texte noir sur blanc, sans couleur ; cartouches blancs au trait marqué")
            .active(o.contrast)
            .build();
        let tint = adw::SwitchRow::builder()
            .title("Une ligne sur deux teintée")
            .subtitle("Un fond bleuté très léger, pour ne pas perdre la ligne")
            .active(o.tint)
            .build();
        layout.add(&left);
        layout.add(&tint);
        layout.add(&contrast);
        page.add(&layout);

        let header = adw::HeaderBar::builder().show_end_title_buttons(false).show_start_title_buttons(false).build();
        let cancel = gtk::Button::with_label("Annuler");
        let export = gtk::Button::with_label("Exporter le PDF");
        export.add_css_class("suggested-action");
        header.pack_start(&cancel);
        header.pack_end(&export);
        let tv = adw::ToolbarView::new();
        tv.add_top_bar(&header);
        tv.set_content(Some(&page));
        let dialog = adw::Dialog::builder().title("Aménagements").content_width(480).child(&tv).build();
        let d = dialog.downgrade();
        cancel.connect_clicked(move |_| {
            if let Some(d) = d.upgrade() {
                d.close();
            }
        });
        let (w, d) = (Rc::downgrade(self), dialog.downgrade());
        export.connect_clicked(move |_| {
            let o = Options {
                font: Font::ALL.get(font.selected() as usize).map_or(Font::Document, |(f, _)| *f),
                size: size.selected() as usize,
                spacing: spacing.selected() as usize,
                contrast: contrast.is_active(),
                left: left.is_active(),
                tint: tint.is_active(),
            };
            o.save();
            if let Some(d) = d.upgrade() {
                d.close();
            }
            let Some(w) = w.upgrade() else { return };
            w.export_amenage(o);
        });
        dialog.present(Some(&self.win));
    }

    fn export_amenage(self: &Rc<Self>, o: Options) {
        let filter = gtk::FileFilter::new();
        filter.set_name(Some("PDF"));
        filter.add_mime_type("application/pdf");
        let filters = gio::ListStore::new::<gtk::FileFilter>();
        filters.append(&filter);
        let dialog = self.save_dialog("Exporter le PDF aménagé", amenagements::file_name(&self.stem()), Some(filters));
        let w = self.clone();
        dialog.save(Some(&self.win), gio::Cancellable::NONE, move |res| {
            let Ok(file) = res else { return };
            let Some(mut path) = file.path() else { return };
            if path.extension().is_none() {
                path.set_extension("pdf");
            }
            let doc = w.typeset_with(|d| amenagements::adapt(d, &o));
            let mut t = letters_core::layout::pango::Typeset::new(doc, letters_core::layout::LayoutOptions::default());
            t.set_alternate_tint(o.tint);
            match t.write_pdf(&path) {
                Ok(()) => w.toast("PDF aménagé exporté"),
                Err(e) => w.error("Impossible d'exporter le PDF aménagé", &e),
            }
        });
    }
}

impl Window {
    /// Insère une frise chronologique, ou (`edit`) modifie celle du curseur.
    pub(super) fn frise_dialog(self: &Rc<Self>, edit: bool) {
        let existing = if edit {
            crate::commands::image_at_caret(&self.buf()).and_then(|(seq, run)| crate::frise::Frise::from_alt(&run.text).map(|f| (seq, run, f)))
        } else {
            None
        };
        let family = self.doc().editor_family();
        let w = Rc::downgrade(self);
        let old = existing.as_ref().map(|(seq, run, _)| (*seq, run.style.image_extent_emu));
        crate::dialogs::frise(&self.win, existing.map(|(_, _, f)| f), family, move |f, png| {
            let Some(w) = w.upgrade() else { return };
            let alt = Some(f.to_alt());
            let res = match old {
                // Même largeur qu'avant, la hauteur suit le nouveau dessin.
                Some((seq, extent)) => {
                    let cm = extent.map(|(ew, _)| ew as f64 / crate::commands::EMU_PER_CM);
                    crate::commands::image_run(&png, cm.or(Some(16.0)), alt).map(|run| crate::commands::replace_image(&w.buf(), seq, run))
                }
                None => crate::commands::image_run(&png, Some(16.0), alt).map(|run| crate::commands::insert_block_image(&w.buf(), run)),
            };
            let _ = std::fs::remove_file(&png);
            match res {
                Ok(()) => w.after_format(),
                Err(e) => w.error("Impossible d'insérer la frise", &e),
            }
        });
    }
}

impl Window {
    /// Le livret de séquence : les documents d'un dossier (ou choisis), dans
    /// l'ordre voulu, en un seul PDF.
    pub(super) fn livret_dialog(self: &Rc<Self>) {
        use std::path::PathBuf;
        let folder: Option<PathBuf> = self.doc().path.borrow().as_ref().and_then(|p| p.parent().map(Path::to_path_buf));
        let files: Rc<RefCell<Vec<PathBuf>>> = Rc::new(RefCell::new(folder.as_deref().map(crate::livret::folder_documents).unwrap_or_default()));

        let page = adw::PreferencesPage::new();
        let add = gtk::Button::builder().icon_name("list-add-symbolic").tooltip_text("Ajouter des documents").valign(gtk::Align::Center).build();
        add.add_css_class("flat");
        let docs = adw::PreferencesGroup::builder()
            .title("Documents")
            .description("Dans l'ordre du livret ; les flèches les déplacent. Un PDF enregistré à côté de son DOCX n'est compté qu'une fois.")
            .header_suffix(&add)
            .build();
        let list = gtk::ListBox::builder().selection_mode(gtk::SelectionMode::None).build();
        list.add_css_class("boxed-list");
        docs.add(&list);
        page.add(&docs);

        let opts = adw::PreferencesGroup::builder().title("Livret").build();
        let default_title = folder.as_ref().and_then(|f| f.file_name()).map(|n| n.to_string_lossy().to_string()).unwrap_or_else(|| "Livret".into());
        let title = adw::EntryRow::builder().title("Titre").text(&default_title).build();
        let cover = adw::SwitchRow::builder().title("Page de garde").subtitle("Le titre du livret, en grand").active(true).build();
        let contents = adw::SwitchRow::builder().title("Sommaire").subtitle("Chaque document et sa page dans le livret").active(true).build();
        let numbers = adw::SwitchRow::builder().title("Numéroter les pages du livret").subtitle("Dans le coin en bas à droite").active(true).build();
        let access = adw::SwitchRow::builder().title("Avec les aménagements").subtitle("Les derniers réglages du bouton Aménagements").active(false).build();
        opts.add(&title);
        opts.add(&cover);
        opts.add(&contents);
        opts.add(&numbers);
        opts.add(&access);
        page.add(&opts);

        // La liste, refaite à chaque changement.
        type Refresh = Rc<RefCell<Option<Rc<dyn Fn()>>>>;
        let refresh: Refresh = Rc::default();
        let rebuild = {
            let (files, list, refresh) = (files.clone(), list.clone(), refresh.clone());
            Rc::new(move || {
                while let Some(c) = list.first_child() {
                    list.remove(&c);
                }
                let n = files.borrow().len();
                if n == 0 {
                    let empty = adw::ActionRow::builder().title("Aucun document").subtitle("Ajoutez-en avec le bouton +").build();
                    list.append(&empty);
                }
                for (i, f) in files.borrow().iter().enumerate() {
                    let row = adw::ActionRow::builder()
                        .title(glib::markup_escape_text(&f.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default()))
                        .subtitle(glib::markup_escape_text(&f.parent().map(|p| p.to_string_lossy().to_string()).unwrap_or_default()))
                        .build();
                    let mk = |icon: &str, tip: &str, sensitive: bool| {
                        let b = gtk::Button::builder().icon_name(icon).tooltip_text(tip).valign(gtk::Align::Center).sensitive(sensitive).build();
                        b.add_css_class("flat");
                        b
                    };
                    let up = mk("go-up-symbolic", "Monter", i > 0);
                    let down = mk("go-down-symbolic", "Descendre", i + 1 < n);
                    let del = mk("user-trash-symbolic", "Retirer du livret", true);
                    for (b, delta) in [(&up, -1i32), (&down, 1), (&del, 0)] {
                        let (files, refresh) = (files.clone(), refresh.clone());
                        b.connect_clicked(move |_| {
                            {
                                let mut f = files.borrow_mut();
                                if delta == 0 {
                                    f.remove(i);
                                } else {
                                    let j = (i as i32 + delta) as usize;
                                    f.swap(i, j);
                                }
                            }
                            if let Some(r) = refresh.borrow().clone() {
                                r();
                            }
                        });
                    }
                    row.add_suffix(&up);
                    row.add_suffix(&down);
                    row.add_suffix(&del);
                    list.append(&row);
                }
            })
        };
        *refresh.borrow_mut() = Some(rebuild.clone());
        rebuild();

        let header = adw::HeaderBar::builder().show_end_title_buttons(false).show_start_title_buttons(false).build();
        let cancel = gtk::Button::with_label("Annuler");
        let create = gtk::Button::with_label("Créer le livret");
        create.add_css_class("suggested-action");
        header.pack_start(&cancel);
        header.pack_end(&create);
        let tv = adw::ToolbarView::new();
        tv.add_top_bar(&header);
        tv.set_content(Some(&page));
        let dialog = adw::Dialog::builder().title("Livret de séquence").content_width(560).content_height(680).child(&tv).build();
        {
            let d = dialog.downgrade();
            cancel.connect_clicked(move |_| {
                if let Some(d) = d.upgrade() {
                    d.close();
                }
            });
        }
        {
            let (files, rebuild, win, folder) = (files.clone(), rebuild.clone(), self.win.clone(), folder.clone());
            add.connect_clicked(move |_| {
                let filter = gtk::FileFilter::new();
                filter.set_name(Some("Documents (DOCX, ODT, PDF, Markdown, texte)"));
                for pat in ["*.docx", "*.odt", "*.pdf", "*.md", "*.txt", "*.DOCX", "*.ODT", "*.PDF"] {
                    filter.add_pattern(pat);
                }
                let filters = gio::ListStore::new::<gtk::FileFilter>();
                filters.append(&filter);
                let fd = gtk::FileDialog::builder().title("Ajouter au livret").modal(true).filters(&filters).build();
                let start = folder.clone().or_else(|| crate::prefs::get().docs_dir.map(PathBuf::from));
                if let Some(dir) = start {
                    fd.set_initial_folder(Some(&gio::File::for_path(dir)));
                }
                let (files, rebuild) = (files.clone(), rebuild.clone());
                fd.open_multiple(Some(&win), gio::Cancellable::NONE, move |res| {
                    let Ok(model) = res else { return };
                    for i in 0..model.n_items() {
                        if let Some(p) = model.item(i).and_downcast::<gio::File>().and_then(|f| f.path()) {
                            if crate::livret::accepts(&p) && !files.borrow().contains(&p) {
                                files.borrow_mut().push(p);
                            }
                        }
                    }
                    rebuild();
                });
            });
        }
        let (w, d) = (Rc::downgrade(self), dialog.downgrade());
        create.connect_clicked(move |_| {
            let Some(w) = w.upgrade() else { return };
            let list = files.borrow().clone();
            if list.is_empty() {
                w.toast("Ajoutez au moins un document");
                return;
            }
            let o = crate::livret::Options { title: title.text().to_string(), cover: cover.is_active(), contents: contents.is_active(), numbers: numbers.is_active() };
            let with_access = access.is_active();
            if let Some(d) = d.upgrade() {
                d.close();
            }
            let filter = gtk::FileFilter::new();
            filter.set_name(Some("PDF"));
            filter.add_mime_type("application/pdf");
            let filters = gio::ListStore::new::<gtk::FileFilter>();
            filters.append(&filter);
            let name = format!("{}.pdf", super::files::clean_file_name(&o.title));
            let fd = w.save_dialog("Enregistrer le livret", name, Some(filters));
            if let Some(dir) = list[0].parent() {
                fd.set_initial_folder(Some(&gio::File::for_path(dir)));
            }
            let w2 = w.clone();
            fd.save(Some(&w.win), gio::Cancellable::NONE, move |res| {
                let Some(mut out) = res.ok().and_then(|f| f.path()) else { return };
                if out.extension().is_none() {
                    out.set_extension("pdf");
                }
                let access = with_access.then(Options::load);
                let family = w2.doc().editor_family();
                let prepare = |d: &mut letters_core::Document| {
                    w2.prepare_for_layout(d);
                    if let Some(a) = &access {
                        amenagements::adapt(d, a);
                    }
                };
                let tint = access.as_ref().is_some_and(|a| a.tint);
                match crate::livret::build(&list, &o, &family, &prepare, tint, &out) {
                    Ok(n) => {
                        let toast = adw::Toast::builder().title(format!("Livret créé : {n} pages")).button_label("Ouvrir").timeout(8).build();
                        let (app, out) = (w2.win.application(), out.clone());
                        toast.connect_button_clicked(move |_| {
                            if let Some(app) = &app {
                                app.open(&[gio::File::for_path(&out)], "");
                            }
                        });
                        w2.toasts.add_toast(toast);
                    }
                    Err(e) => w2.error("Impossible de créer le livret", &e),
                }
            });
        });
        dialog.present(Some(&self.win));
    }
}
