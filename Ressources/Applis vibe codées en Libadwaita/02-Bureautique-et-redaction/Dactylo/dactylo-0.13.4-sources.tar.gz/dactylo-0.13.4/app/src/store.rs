// store.rs — fichiers récents (liste propre à Samizdat) et copies de secours.
// SPDX-License-Identifier: GPL-3.0-or-later

use std::path::{Path, PathBuf};

use gtk4::glib;

const MAX_RECENTS: usize = 10;

fn data_dir() -> PathBuf {
    let d = glib::user_data_dir().join(crate::DIR);
    let _ = std::fs::create_dir_all(&d);
    d
}

fn recents_file() -> PathBuf {
    data_dir().join("recents.txt")
}

/// Les documents récents qui existent encore, du plus récent au plus ancien.
pub fn recents() -> Vec<PathBuf> {
    std::fs::read_to_string(recents_file())
        .unwrap_or_default()
        .lines()
        .map(PathBuf::from)
        .filter(|p| p.is_file())
        .take(MAX_RECENTS)
        .collect()
}

pub fn add_recent(path: &Path) {
    let path = path.canonicalize().unwrap_or_else(|_| path.to_path_buf());
    let mut list = recents();
    list.retain(|p| p != &path);
    list.insert(0, path);
    list.truncate(MAX_RECENTS);
    let text: Vec<String> = list.iter().map(|p| p.to_string_lossy().to_string()).collect();
    let _ = std::fs::write(recents_file(), text.join("\n") + "\n");
}

pub fn clear_recents() {
    let _ = std::fs::remove_file(recents_file());
}

// ---- Copies de secours ------------------------------------------------------

fn recovery_dir() -> PathBuf {
    let d = data_dir().join("secours");
    let _ = std::fs::create_dir_all(&d);
    d
}

/// Une copie de secours : le document (ODT, fidèle au modèle) et le chemin
/// du fichier d'origine s'il en avait un.
pub struct Recovery {
    pub doc: PathBuf,
    pub original: Option<PathBuf>,
}

/// Écrit la copie de secours de la fenêtre `id`.
pub fn save_recovery(id: u64, doc: &letters_core::Document, original: Option<&Path>) {
    let dir = recovery_dir();
    let file = dir.join(format!("{id}.odt"));
    if letters_core::save::write(doc, &file).is_ok() {
        let meta = original.map(|p| p.to_string_lossy().to_string()).unwrap_or_default();
        let _ = std::fs::write(dir.join(format!("{id}.txt")), meta);
    }
}

pub fn drop_recovery(id: u64) {
    let dir = recovery_dir();
    let _ = std::fs::remove_file(dir.join(format!("{id}.odt")));
    let _ = std::fs::remove_file(dir.join(format!("{id}.txt")));
}

/// Copies laissées par une session qui s'est mal terminée.
pub fn pending_recoveries() -> Vec<Recovery> {
    let Ok(entries) = std::fs::read_dir(recovery_dir()) else { return Vec::new() };
    let mut out = Vec::new();
    for e in entries.flatten() {
        let p = e.path();
        if p.extension().is_some_and(|x| x == "odt") {
            let meta = p.with_extension("txt");
            let original = std::fs::read_to_string(&meta).ok().map(|s| s.trim().to_string()).filter(|s| !s.is_empty()).map(PathBuf::from);
            out.push(Recovery { doc: p, original });
        }
    }
    out
}

pub fn forget_recovery(r: &Recovery) {
    let _ = std::fs::remove_file(&r.doc);
    let _ = std::fs::remove_file(r.doc.with_extension("txt"));
}

// ---- Modèles ------------------------------------------------------------------

/// Extensions reconnues comme modèles.
pub const TEMPLATE_EXTENSIONS: [&str; 3] = ["docx", "odt", "md"];

/// Le dossier des modèles, propre à Samizdat :
/// ~/.local/share/samizdat/modeles.
pub fn templates_dir() -> PathBuf {
    let d = data_dir().join("modeles");
    let _ = std::fs::create_dir_all(&d);
    d
}

fn is_template(p: &Path) -> bool {
    p.is_file() && p.extension().and_then(|e| e.to_str()).is_some_and(|e| TEMPLATE_EXTENSIONS.contains(&e.to_lowercase().as_str()))
}

/// Les modèles disponibles, par ordre alphabétique.
pub fn templates() -> Vec<PathBuf> {
    let Ok(entries) = std::fs::read_dir(templates_dir()) else { return Vec::new() };
    let mut list: Vec<PathBuf> = entries.flatten().map(|e| e.path()).filter(|p| is_template(p)).collect();
    list.sort_by_key(|p| p.file_name().map(|n| n.to_string_lossy().to_lowercase()));
    list
}

/// `dir/stem.ext`, ou `dir/stem (2).ext`… s'il existe déjà.
pub fn free_name(dir: &Path, stem: &str, ext: &str) -> PathBuf {
    let first = dir.join(format!("{stem}.{ext}"));
    if !first.exists() {
        return first;
    }
    (2..).map(|n| dir.join(format!("{stem} ({n}).{ext}"))).find(|p| !p.exists()).expect("un nom libre")
}

/// Copie `src` dans le dossier des modèles ; rend le chemin de la copie.
pub fn import_template(src: &Path) -> Result<PathBuf, String> {
    let dir = templates_dir();
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let stem = src.file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_else(|| "Modèle".into());
    let ext = src.extension().map(|s| s.to_string_lossy().to_lowercase()).unwrap_or_else(|| "docx".into());
    let dest = free_name(&dir, &stem, &ext);
    std::fs::copy(src, &dest).map_err(|e| e.to_string())?;
    Ok(dest)
}
