// pdfview.rs — un PDF en lecture seule, dans un onglet.
//
// Le rendu passe par poppler-glib (la bibliothèque des visionneuses de
// GNOME), chargée au premier PDF ouvert : sans elle, Samizdat fonctionne,
// seuls les PDF ne s'ouvrent pas. Chaque page est dessinée quand elle
// devient visible, puis gardée jusqu'au prochain changement de zoom.
// SPDX-License-Identifier: GPL-3.0-or-later

use std::cell::{Cell, RefCell};
use std::ffi::{c_char, c_double, c_int, c_void, CStr, CString};
use std::rc::Rc;

use gtk4::{self as gtk, glib, prelude::*};

extern "C" {
    fn dlopen(filename: *const c_char, flag: c_int) -> *mut c_void;
    fn dlsym(handle: *mut c_void, symbol: *const c_char) -> *mut c_void;
    fn g_object_unref(object: *mut c_void);
    fn g_error_free(error: *mut GError);
    fn g_free(p: *mut c_void);
    fn g_list_free(list: *mut GList);
}

#[repr(C)]
struct GList {
    data: *mut c_void,
    next: *mut GList,
    prev: *mut GList,
}

#[repr(C)]
#[derive(Clone, Copy, Debug, Default, PartialEq)]
struct PopplerRectangle {
    x1: c_double,
    y1: c_double,
    x2: c_double,
    y2: c_double,
}

#[repr(C)]
struct PopplerColor {
    red: u16,
    green: u16,
    blue: u16,
}

/// POPPLER_SELECTION_GLYPH : lettre par lettre.
const SELECTION_GLYPH: c_int = 0;

const RTLD_NOW: c_int = 2;

#[repr(C)]
struct GError {
    domain: u32,
    code: c_int,
    message: *const c_char,
}

type NewFromFile = unsafe extern "C" fn(*const c_char, *const c_char, *mut *mut GError) -> *mut c_void;
type NPages = unsafe extern "C" fn(*mut c_void) -> c_int;
type GetPage = unsafe extern "C" fn(*mut c_void, c_int) -> *mut c_void;
type PageSize = unsafe extern "C" fn(*mut c_void, *mut c_double, *mut c_double);
type Render = unsafe extern "C" fn(*mut c_void, *mut c_void);
type SelectedText = unsafe extern "C" fn(*mut c_void, c_int, *mut PopplerRectangle) -> *mut c_char;
type RenderSelection = unsafe extern "C" fn(*mut c_void, *mut c_void, *mut PopplerRectangle, *mut PopplerRectangle, c_int, *mut PopplerColor, *mut PopplerColor);
type FindText = unsafe extern "C" fn(*mut c_void, *const c_char) -> *mut GList;
type RectFree = unsafe extern "C" fn(*mut PopplerRectangle);

struct Poppler {
    new_from_file: NewFromFile,
    n_pages: NPages,
    get_page: GetPage,
    page_size: PageSize,
    render: Render,
    selected_text: SelectedText,
    render_selection: RenderSelection,
    find_text: FindText,
    rect_free: RectFree,
}

fn poppler() -> Option<&'static Poppler> {
    thread_local! {
        static LIB: Option<&'static Poppler> = load();
    }
    LIB.with(|l| *l)
}

fn load() -> Option<&'static Poppler> {
    let handle = ["libpoppler-glib.so.8", "libpoppler-glib.so"].iter().find_map(|name| {
        let c = CString::new(*name).ok()?;
        let h = unsafe { dlopen(c.as_ptr(), RTLD_NOW) };
        (!h.is_null()).then_some(h)
    })?;
    let sym = |name: &str| -> Option<*mut c_void> {
        let c = CString::new(name).ok()?;
        let p = unsafe { dlsym(handle, c.as_ptr()) };
        (!p.is_null()).then_some(p)
    };
    unsafe {
        let p = Poppler {
            new_from_file: std::mem::transmute::<*mut c_void, NewFromFile>(sym("poppler_document_new_from_file")?),
            n_pages: std::mem::transmute::<*mut c_void, NPages>(sym("poppler_document_get_n_pages")?),
            get_page: std::mem::transmute::<*mut c_void, GetPage>(sym("poppler_document_get_page")?),
            page_size: std::mem::transmute::<*mut c_void, PageSize>(sym("poppler_page_get_size")?),
            render: std::mem::transmute::<*mut c_void, Render>(sym("poppler_page_render")?),
            selected_text: std::mem::transmute::<*mut c_void, SelectedText>(sym("poppler_page_get_selected_text")?),
            render_selection: std::mem::transmute::<*mut c_void, RenderSelection>(sym("poppler_page_render_selection")?),
            find_text: std::mem::transmute::<*mut c_void, FindText>(sym("poppler_page_find_text")?),
            rect_free: std::mem::transmute::<*mut c_void, RectFree>(sym("poppler_rectangle_free")?),
        };
        Some(Box::leak(Box::new(p)))
    }
}

/// Un document PDF ouvert.
pub(crate) struct Document {
    lib: &'static Poppler,
    doc: *mut c_void,
    pages: Vec<*mut c_void>,
}

impl Drop for Document {
    fn drop(&mut self) {
        unsafe {
            for p in &self.pages {
                g_object_unref(*p);
            }
            g_object_unref(self.doc);
        }
    }
}

impl Document {
    pub(crate) fn open(path: &std::path::Path) -> Result<Self, String> {
        let lib = poppler().ok_or("La bibliothèque poppler-glib est introuvable (paquet poppler-glib).")?;
        let uri = glib::filename_to_uri(path, None).map_err(|e| e.to_string())?;
        let uri = CString::new(uri.as_str()).map_err(|e| e.to_string())?;
        let mut err: *mut GError = std::ptr::null_mut();
        let doc = unsafe { (lib.new_from_file)(uri.as_ptr(), std::ptr::null(), &mut err) };
        if doc.is_null() {
            let msg = if err.is_null() {
                "PDF illisible".to_string()
            } else {
                let m = unsafe { CStr::from_ptr((*err).message) }.to_string_lossy().to_string();
                unsafe { g_error_free(err) };
                m
            };
            return Err(msg);
        }
        let n = unsafe { (lib.n_pages)(doc) }.max(0);
        let pages = (0..n).map(|i| unsafe { (lib.get_page)(doc, i) }).filter(|p| !p.is_null()).collect();
        Ok(Self { lib, doc, pages })
    }

    pub(crate) fn page_count(&self) -> usize {
        self.pages.len()
    }

    /// Taille de la page `i`, en points.
    pub(crate) fn size(&self, i: usize) -> (f64, f64) {
        let (mut w, mut h) = (0.0, 0.0);
        unsafe { (self.lib.page_size)(self.pages[i], &mut w, &mut h) };
        (w, h)
    }

    pub(crate) fn render(&self, i: usize, cr: &gtk::cairo::Context) {
        unsafe { (self.lib.render)(self.pages[i], cr.to_raw_none() as *mut c_void) };
    }

    /// Le texte sous le rectangle `r` (points, origine en haut à gauche).
    fn text_in(&self, i: usize, r: Rect) -> String {
        let mut rect = r.poppler();
        let p = unsafe { (self.lib.selected_text)(self.pages[i], SELECTION_GLYPH, &mut rect) };
        if p.is_null() {
            return String::new();
        }
        let text = unsafe { CStr::from_ptr(p) }.to_string_lossy().to_string();
        unsafe { g_free(p as *mut c_void) };
        text
    }

    /// Surligne les lettres sous `r`, comme une sélection de texte.
    fn render_selection(&self, i: usize, cr: &gtk::cairo::Context, r: Rect) {
        let mut rect = r.poppler();
        let mut old = rect;
        let mut glyph = PopplerColor { red: 0xffff, green: 0xffff, blue: 0xffff };
        let mut back = PopplerColor { red: 0x3535, green: 0x8484, blue: 0xe4e4 };
        unsafe { (self.lib.render_selection)(self.pages[i], cr.to_raw_none() as *mut c_void, &mut rect, &mut old, SELECTION_GLYPH, &mut glyph, &mut back) };
    }

    /// Les occurrences de `needle` sur la page `i` (sans tenir compte de la
    /// casse), en points depuis le haut à gauche.
    fn find(&self, i: usize, needle: &str) -> Vec<Rect> {
        let Ok(c) = CString::new(needle) else { return Vec::new() };
        let (_, h) = self.size(i);
        let list = unsafe { (self.lib.find_text)(self.pages[i], c.as_ptr()) };
        let mut out = Vec::new();
        let mut node = list;
        while !node.is_null() {
            let r = unsafe { (*node).data as *mut PopplerRectangle };
            if !r.is_null() {
                let p = unsafe { *r };
                // poppler compte les y depuis le bas de la page.
                out.push(Rect { x: p.x1.min(p.x2), y: h - p.y1.max(p.y2), w: (p.x2 - p.x1).abs(), h: (p.y2 - p.y1).abs() });
                unsafe { (self.lib.rect_free)(r) };
            }
            node = unsafe { (*node).next };
        }
        if !list.is_null() {
            unsafe { g_list_free(list) };
        }
        out
    }
}

/// Un rectangle en points, origine en haut à gauche de la page.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
struct Rect {
    x: f64,
    y: f64,
    w: f64,
    h: f64,
}

impl Rect {
    fn from_points(a: (f64, f64), b: (f64, f64)) -> Self {
        Self { x: a.0.min(b.0), y: a.1.min(b.1), w: (a.0 - b.0).abs(), h: (a.1 - b.1).abs() }
    }

    fn poppler(&self) -> PopplerRectangle {
        PopplerRectangle { x1: self.x, y1: self.y, x2: self.x + self.w, y2: self.y + self.h }
    }
}

/// L'onglet d'un PDF : les pages l'une sous l'autre, sur fond gris, une
/// barre de recherche au-dessus. Glisser sur le texte le sélectionne et le
/// copie.
pub struct PdfView {
    pub widget: gtk::Box,
    scroller: gtk::ScrolledWindow,
    doc: Rc<Document>,
    areas: Vec<gtk::DrawingArea>,
    /// Pages déjà dessinées au zoom courant.
    drawn: Rc<RefCell<Vec<bool>>>,
    scale: Rc<Cell<f64>>,
    /// Sélection en cours : page et rectangle.
    selection: Rc<RefCell<Option<(usize, Rect)>>>,
    /// Résultats de recherche (page, rectangle) et le courant.
    found: Rc<RefCell<Vec<(usize, Rect)>>>,
    current: Rc<Cell<usize>>,
    search_bar: gtk::Revealer,
    entry: gtk::SearchEntry,
    count: gtk::Label,
}

/// Points → pixels à 100 %.
const PX_PER_PT: f64 = 96.0 / 72.0;

impl PdfView {
    pub fn open(path: &std::path::Path) -> Result<Rc<Self>, String> {
        let doc = Rc::new(Document::open(path)?);
        let n = doc.pages.len();
        let scale = Rc::new(Cell::new(1.0));
        let drawn = Rc::new(RefCell::new(vec![false; n]));
        let selection: Rc<RefCell<Option<(usize, Rect)>>> = Rc::default();
        let found: Rc<RefCell<Vec<(usize, Rect)>>> = Rc::default();
        let current = Rc::new(Cell::new(0));
        let column = gtk::Box::new(gtk::Orientation::Vertical, 18);
        column.set_margin_top(24);
        column.set_margin_bottom(24);
        column.set_halign(gtk::Align::Center);
        let scroller = gtk::ScrolledWindow::builder().child(&column).vexpand(true).hexpand(true).build();
        scroller.add_css_class("samizdat-desk");
        let mut areas = Vec::new();
        for i in 0..n {
            let area = gtk::DrawingArea::new();
            area.add_css_class("samizdat-pdf-page");
            area.set_cursor_from_name(Some("text"));
            let (d, sc, dr, sw, sel, fd, cur) = (doc.clone(), scale.clone(), drawn.clone(), scroller.downgrade(), selection.clone(), found.clone(), current.clone());
            area.set_draw_func(move |a, cr, aw, ah| {
                cr.set_source_rgb(1.0, 1.0, 1.0);
                cr.rectangle(0.0, 0.0, aw as f64, ah as f64);
                let _ = cr.fill();
                // Hors de la vue : page blanche, dessinée en y arrivant.
                if !sw.upgrade().is_some_and(|sw| visible(&sw, a)) {
                    return;
                }
                let s = sc.get() * PX_PER_PT;
                cr.scale(s, s);
                d.render(i, cr);
                // Résultats de recherche : jaune ; le courant, orange.
                for (k, (p, r)) in fd.borrow().iter().enumerate() {
                    if *p != i {
                        continue;
                    }
                    if k == cur.get() {
                        cr.set_source_rgba(1.0, 0.47, 0.0, 0.45);
                    } else {
                        cr.set_source_rgba(0.96, 0.83, 0.18, 0.45);
                    }
                    cr.rectangle(r.x - 1.0, r.y - 1.0, r.w + 2.0, r.h + 2.0);
                    let _ = cr.fill();
                }
                if let Some((p, r)) = *sel.borrow() {
                    if p == i {
                        d.render_selection(i, cr, r);
                    }
                }
                if let Some(slot) = dr.borrow_mut().get_mut(i) {
                    *slot = true;
                }
            });
            // Glisser : sélectionner ; relâcher : copier.
            let drag = gtk::GestureDrag::new();
            let (sel, sc, d2, a2) = (selection.clone(), scale.clone(), doc.clone(), area.downgrade());
            drag.connect_drag_update(move |g, dx, dy| {
                let Some((x0, y0)) = g.start_point() else { return };
                let s = sc.get() * PX_PER_PT;
                let r = Rect::from_points((x0 / s, y0 / s), ((x0 + dx) / s, (y0 + dy) / s));
                *sel.borrow_mut() = Some((i, r));
                if let Some(a) = a2.upgrade() {
                    a.queue_draw();
                }
            });
            let (sel, a2) = (selection.clone(), area.downgrade());
            drag.connect_drag_end(move |_, dx, dy| {
                let Some(a) = a2.upgrade() else { return };
                if dx.abs() < 3.0 && dy.abs() < 3.0 {
                    // Simple clic : plus de sélection.
                    *sel.borrow_mut() = None;
                    a.queue_draw();
                    return;
                }
                let Some((p, r)) = *sel.borrow() else { return };
                let text = d2.text_in(p, r);
                if text.trim().is_empty() {
                    return;
                }
                a.clipboard().set_text(&text);
                toast(&a, "Texte copié : collez-le avec Ctrl+V");
            });
            area.add_controller(drag);
            let label = gtk::Label::new(Some(&format!("Page {} sur {n}", i + 1)));
            label.add_css_class("dim-label");
            label.add_css_class("caption");
            let b = gtk::Box::new(gtk::Orientation::Vertical, 6);
            b.append(&area);
            b.append(&label);
            column.append(&b);
            areas.push(area);
        }

        // Barre de recherche.
        let entry = gtk::SearchEntry::builder().placeholder_text("Rechercher dans le PDF").hexpand(true).build();
        let count = gtk::Label::builder().width_chars(8).build();
        count.add_css_class("dim-label");
        count.add_css_class("numeric");
        let prev = gtk::Button::builder().icon_name("go-up-symbolic").tooltip_text("Précédent (Maj+Entrée)").build();
        let next = gtk::Button::builder().icon_name("go-down-symbolic").tooltip_text("Suivant (Entrée)").build();
        let close = gtk::Button::builder().icon_name("window-close-symbolic").tooltip_text("Fermer (Échap)").build();
        for b in [&prev, &next, &close] {
            b.add_css_class("flat");
        }
        let row = gtk::Box::new(gtk::Orientation::Horizontal, 6);
        row.append(&entry);
        row.append(&count);
        row.append(&prev);
        row.append(&next);
        row.append(&close);
        let clamp = libadwaita::Clamp::builder().maximum_size(720).child(&row).build();
        clamp.set_margin_top(6);
        clamp.set_margin_bottom(6);
        clamp.set_margin_start(12);
        clamp.set_margin_end(12);
        let search_bar = gtk::Revealer::builder().child(&clamp).transition_type(gtk::RevealerTransitionType::SlideDown).build();
        search_bar.add_css_class("toolbar");
        let widget = gtk::Box::new(gtk::Orientation::Vertical, 0);
        widget.append(&search_bar);
        widget.append(&scroller);

        let this = Rc::new(Self { widget, scroller, doc, areas, drawn, scale, selection, found, current, search_bar, entry: entry.clone(), count });
        this.resize();
        // En défilant : dessiner les pages qui apparaissent.
        let w = Rc::downgrade(&this);
        this.scroller.vadjustment().connect_value_changed(move |_| {
            if let Some(w) = w.upgrade() {
                w.draw_visible();
            }
        });
        let w = Rc::downgrade(&this);
        this.scroller.vadjustment().connect_page_size_notify(move |_| {
            if let Some(w) = w.upgrade() {
                w.draw_visible();
            }
        });
        let w = Rc::downgrade(&this);
        entry.connect_search_changed(move |_| {
            if let Some(w) = w.upgrade() {
                w.search();
            }
        });
        for (button, forward) in [(&next, true), (&prev, false)] {
            let w = Rc::downgrade(&this);
            button.connect_clicked(move |_| {
                if let Some(w) = w.upgrade() {
                    w.step(forward);
                }
            });
        }
        let w = Rc::downgrade(&this);
        entry.connect_activate(move |_| {
            if let Some(w) = w.upgrade() {
                w.step(true);
            }
        });
        let w = Rc::downgrade(&this);
        entry.connect_next_match(move |_| {
            if let Some(w) = w.upgrade() {
                w.step(true);
            }
        });
        let w = Rc::downgrade(&this);
        entry.connect_previous_match(move |_| {
            if let Some(w) = w.upgrade() {
                w.step(false);
            }
        });
        let w = Rc::downgrade(&this);
        entry.connect_stop_search(move |_| {
            if let Some(w) = w.upgrade() {
                w.hide_search();
            }
        });
        let w = Rc::downgrade(&this);
        close.connect_clicked(move |_| {
            if let Some(w) = w.upgrade() {
                w.hide_search();
            }
        });
        Ok(this)
    }

    pub fn page_count(&self) -> usize {
        self.areas.len()
    }

    /// La page au milieu de la vue.
    pub fn current_page(&self) -> usize {
        let middle = self.scroller.height() as f32 / 2.0;
        self.areas
            .iter()
            .position(|a| {
                a.compute_point(&self.scroller, &gtk::graphene::Point::new(0.0, a.height() as f32))
                    .is_some_and(|p| p.y() >= middle)
            })
            .unwrap_or(self.areas.len().saturating_sub(1))
    }

    fn resize(&self) {
        *self.selection.borrow_mut() = None;
        let s = self.scale.get() * PX_PER_PT;
        for (i, a) in self.areas.iter().enumerate() {
            let (w, h) = self.doc.size(i);
            a.set_content_width((w * s).round() as i32);
            a.set_content_height((h * s).round() as i32);
            a.queue_draw();
        }
        self.drawn.borrow_mut().iter_mut().for_each(|d| *d = false);
    }

    fn draw_visible(&self) {
        let drawn = self.drawn.borrow().clone();
        for (i, a) in self.areas.iter().enumerate() {
            if !drawn[i] && visible(&self.scroller, a) {
                a.queue_draw();
            }
        }
    }

    fn redraw_all(&self) {
        for a in &self.areas {
            a.queue_draw();
        }
    }

    /// Zoom : 1.0 = 100 %.
    pub fn set_scale(&self, s: f64) {
        self.scale.set(s);
        self.resize();
    }

    /// Ctrl+F.
    pub fn show_search(&self) {
        self.search_bar.set_reveal_child(true);
        self.entry.grab_focus();
        self.entry.select_region(0, -1);
    }

    fn hide_search(&self) {
        self.search_bar.set_reveal_child(false);
        self.found.borrow_mut().clear();
        self.count.set_text("");
        self.redraw_all();
    }

    fn search(&self) {
        let needle = self.entry.text().to_string();
        let mut all = Vec::new();
        if !needle.trim().is_empty() {
            for i in 0..self.areas.len() {
                all.extend(self.doc.find(i, &needle).into_iter().map(|r| (i, r)));
            }
        }
        let n = all.len();
        *self.found.borrow_mut() = all;
        self.current.set(0);
        if needle.is_empty() {
            self.count.set_text("");
            self.entry.remove_css_class("error");
        } else if n == 0 {
            self.count.set_text("Aucun");
            self.entry.add_css_class("error");
        } else {
            self.entry.remove_css_class("error");
        }
        self.redraw_all();
        self.show_current();
    }

    fn step(&self, forward: bool) {
        let n = self.found.borrow().len();
        if n == 0 {
            return;
        }
        let c = self.current.get();
        self.current.set(if forward { (c + 1) % n } else { (c + n - 1) % n });
        self.redraw_all();
        self.show_current();
    }

    /// Fait défiler jusqu'au résultat courant.
    fn show_current(&self) {
        let found = self.found.borrow();
        let Some((p, r)) = found.get(self.current.get()).copied() else { return };
        self.count.set_text(&format!("{} / {}", self.current.get() + 1, found.len()));
        let area = &self.areas[p];
        let Some(child) = self.scroller.child() else { return };
        let Some(bounds) = area.compute_bounds(&child) else { return };
        let s = self.scale.get() * PX_PER_PT;
        let adj = self.scroller.vadjustment();
        let y = bounds.y() as f64 + r.y * s - adj.page_size() / 3.0;
        adj.set_value(y.clamp(adj.lower(), (adj.upper() - adj.page_size()).max(adj.lower())));
    }
}

/// Une notification dans la fenêtre qui contient `w`.
fn toast(w: &impl IsA<gtk::Widget>, text: &str) {
    if let Some(o) = w.ancestor(libadwaita::ToastOverlay::static_type()).and_then(|o| o.downcast::<libadwaita::ToastOverlay>().ok()) {
        o.add_toast(libadwaita::Toast::new(text));
    }
}

/// La page `area` est-elle (au moins en partie) dans la vue ?
fn visible(sw: &gtk::ScrolledWindow, area: &gtk::DrawingArea) -> bool {
    let Some(bounds) = area.compute_bounds(sw) else { return true };
    let h = sw.height() as f32;
    // Une demi-hauteur de marge : la page suivante est prête avant d'arriver.
    bounds.y() + bounds.height() >= -h * 0.5 && bounds.y() <= h * 1.5
}
