// web.rs — une image venue du navigateur : glissée depuis une page (son
// adresse) ou une vignette (« data: »), téléchargée puis insérée.
// SPDX-License-Identifier: GPL-3.0-or-later

use gtk4::{gio, glib};

/// Le fichier d'une image à l'adresse `uri` : décodée si elle est dans
/// l'adresse (« data:image/…;base64,… »), sinon téléchargée avec curl.
pub fn fetch_image(uri: &str, done: impl FnOnce(Result<std::path::PathBuf, String>) + 'static) {
    let dir = glib::user_cache_dir().join(crate::DIR).join("images");
    if let Err(e) = std::fs::create_dir_all(&dir) {
        return done(Err(e.to_string()));
    }
    let t = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0);
    let path = dir.join(format!("web-{t:x}"));
    if let Some(data) = uri.strip_prefix("data:") {
        let Some((head, body)) = data.split_once(',') else { return done(Err("adresse « data: » illisible".into())) };
        let bytes = if head.ends_with(";base64") {
            glib::base64_decode(body.trim()).to_vec()
        } else {
            glib::Uri::unescape_string(body, None::<&str>).map(|s| s.as_bytes().to_vec()).unwrap_or_default()
        };
        return done(std::fs::write(&path, bytes).map(|_| path).map_err(|e| e.to_string()));
    }
    if !(uri.starts_with("http://") || uri.starts_with("https://")) {
        return done(Err(format!("adresse non prise en charge : {uri}")));
    }
    let args: Vec<&std::ffi::OsStr> = vec![
        "curl".as_ref(),
        "-fsSL".as_ref(),
        "--max-time".as_ref(),
        "30".as_ref(),
        "-A".as_ref(),
        "Mozilla/5.0 (X11; Linux x86_64) Dactylo".as_ref(),
        "-o".as_ref(),
        path.as_os_str(),
        uri.as_ref(),
    ];
    let proc = match gio::Subprocess::newv(&args, gio::SubprocessFlags::STDERR_PIPE) {
        Ok(p) => p,
        Err(e) => return done(Err(format!("curl introuvable : {e}"))),
    };
    let p2 = proc.clone();
    proc.communicate_utf8_async(None, gio::Cancellable::NONE, move |res| {
        let err = res.ok().and_then(|(_, e)| e).map(|e| e.to_string()).unwrap_or_default();
        if p2.is_successful() {
            done(Ok(path))
        } else {
            let _ = std::fs::remove_file(&path);
            done(Err(format!("téléchargement impossible : {}", err.trim())))
        }
    });
}

/// Si `text` n'est qu'une adresse (ce qu'un navigateur met à côté d'une
/// image copiée) : alors l'image passe avant.
pub fn is_bare_address(text: &str) -> bool {
    let t = text.trim();
    t.is_empty() || (!t.contains(char::is_whitespace) && (t.starts_with("http://") || t.starts_with("https://") || t.starts_with("data:") || t.starts_with("file:")))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_data_uri_is_decoded() {
        let png = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==";
        let got: std::rc::Rc<std::cell::RefCell<Option<std::path::PathBuf>>> = Default::default();
        let g = got.clone();
        fetch_image(&format!("data:image/png;base64,{png}"), move |r| *g.borrow_mut() = r.ok());
        let p = got.borrow().clone().expect("decoded");
        assert!(crate::commands::image_size(&p.to_string_lossy()).is_some());
        let _ = std::fs::remove_file(p);
        assert!(is_bare_address("https://example.org/a.jpg"));
        assert!(!is_bare_address("Un vrai texte copié"));
    }
}
