// prefs.rs — préférences de Samizdat : nouveaux documents, saisie,
// enregistrement, boutons de la barre d'outils, affichage, images.
//
// Enregistrées dans ~/.config/samizdat/preferences.ini.
// SPDX-License-Identifier: GPL-3.0-or-later

use std::cell::RefCell;

use gtk4::{self as gtk, glib, prelude::*};
use libadwaita::{self as adw, prelude::*};

/// Les boutons de la barre d'outils qu'on peut masquer : clé, libellé.
pub const TOOLS: [(&str, &str); 9] = [
    ("cartouche", "Cartouche"),
    ("formes", "Formes"),
    ("frise", "Frise chronologique"),
    ("ocr", "Texte d'une image (OCR)"),
    ("tableau", "Tableau"),
    ("lien", "Lien"),
    ("colonnes", "Colonnes"),
    ("amenagements", "Aménagements"),
    ("concentration", "Mode concentration"),
];

/// Les zooms proposés au démarrage.
pub const ZOOMS: [(f64, &str); 5] = [(0.8, "80 %"), (0.9, "90 %"), (1.0, "100 %"), (1.1, "110 %"), (1.25, "125 %")];

#[derive(Clone, Debug, PartialEq)]
pub struct Prefs {
    /// Police des documents qui n'en précisent pas ; `None` : celle de GNOME.
    pub font_family: Option<String>,
    /// Taille en demi-points (24 = 12 pt).
    pub font_size_hp: u16,
    /// Dossier proposé pour ouvrir et enregistrer un document neuf.
    pub docs_dir: Option<String>,
    /// Les derniers aménagements choisis (`amenagements::Options`).
    pub amenagements: String,
    /// Proposer le premier titre d'un document neuf comme nom de fichier.
    pub title_as_name: bool,
    /// Le modèle d'un nouveau document (chemin) ; `None` : une page vide.
    pub start_template: Option<String>,
    /// Vérifier l'orthographe dès l'ouverture d'un document.
    pub spell_on_open: bool,
    /// Coller l'image (et non son adresse) copiée dans un navigateur.
    pub paste_web_images: bool,
    /// Les boutons masqués de la barre d'outils (clés de `TOOLS`).
    pub hidden_tools: Vec<String>,
    /// Ouvrir le panneau Plan au démarrage.
    pub outline_on_start: bool,
    /// Ouvrir l'aperçu en direct (à droite) au démarrage.
    pub live_on_start: bool,
    /// La règle graduée au-dessus de la page.
    pub show_ruler: bool,
    /// Largeur du panneau d'aperçu en direct, en pixels.
    pub live_width: i32,
    /// Le zoom d'un document ouvert.
    pub default_zoom: f64,
    /// Mode concentration : la ligne en cours reste au milieu de l'écran.
    pub focus_center: bool,
    /// À chaque enregistrement en DOCX, le PDF à côté, sous le même nom.
    pub pdf_with_save: bool,
    /// Une image insérée est seule sur sa ligne, centrée.
    pub image_own_line: bool,
    /// Une nouvelle légende est numérotée (« Document 1 »…).
    pub caption_numbered: bool,
    /// L'astuce sur Entrée dans un cartouche a été montrée.
    pub cartouche_hint_shown: bool,
}

/// Le dossier des cours, s'il existe : proposé par défaut.
fn default_docs_dir() -> Option<String> {
    let d = glib::home_dir().join("Dropbox").join("LYCEE").join("CLASSES");
    d.is_dir().then(|| d.to_string_lossy().to_string())
}

impl Default for Prefs {
    fn default() -> Self {
        Self {
            font_family: None,
            font_size_hp: 24,
            docs_dir: default_docs_dir(),
            amenagements: String::new(),
            title_as_name: true,
            start_template: None,
            spell_on_open: true,
            paste_web_images: true,
            hidden_tools: Vec::new(),
            outline_on_start: false,
            live_on_start: false,
            show_ruler: false,
            live_width: 380,
            default_zoom: 1.0,
            focus_center: true,
            pdf_with_save: false,
            image_own_line: true,
            caption_numbered: false,
            cartouche_hint_shown: false,
        }
    }
}

impl Prefs {
    /// Si le bouton `tool` (clé de `TOOLS`) est affiché.
    pub fn shows(&self, tool: &str) -> bool {
        !self.hidden_tools.iter().any(|t| t == tool)
    }
}

thread_local! {
    static PREFS: RefCell<Prefs> = RefCell::new(load());
}

fn path() -> std::path::PathBuf {
    glib::user_config_dir().join(crate::DIR).join("preferences.ini")
}

fn load() -> Prefs {
    let mut p = Prefs::default();
    let kf = glib::KeyFile::new();
    if kf.load_from_file(path(), glib::KeyFileFlags::NONE).is_err() {
        return p;
    }
    let text = |g: &str, k: &str| kf.string(g, k).ok().map(|s| s.trim().to_string()).filter(|s| !s.is_empty());
    let flag = |g: &str, k: &str, default: bool| kf.boolean(g, k).unwrap_or(default);
    p.font_family = text("Documents", "police");
    if let Ok(size) = kf.double("Documents", "taille") {
        p.font_size_hp = ((size * 2.0).round() as u16).clamp(8, 288);
    }
    if kf.has_key("Documents", "dossier").unwrap_or(false) {
        p.docs_dir = text("Documents", "dossier");
    }
    p.amenagements = text("Amenagements", "choix").unwrap_or_default();
    p.title_as_name = flag("Documents", "titre_comme_nom", true);
    p.start_template = text("Documents", "modele");
    p.spell_on_open = flag("Saisie", "orthographe", true);
    p.paste_web_images = flag("Saisie", "images_web", true);
    p.hidden_tools = text("Barre", "masques").map(|s| s.split(';').map(str::to_string).collect()).unwrap_or_default();
    p.outline_on_start = flag("Affichage", "plan", false);
    p.live_on_start = flag("Affichage", "apercu", false);
    p.show_ruler = flag("Affichage", "regle", false);
    p.live_width = kf.integer("Affichage", "apercu_largeur").unwrap_or(380).clamp(220, 1200);
    p.default_zoom = kf.double("Affichage", "zoom").unwrap_or(1.0).clamp(0.5, 2.0);
    p.focus_center = flag("Affichage", "concentration_centre", true);
    p.pdf_with_save = flag("Enregistrement", "pdf", false);
    p.image_own_line = flag("Images", "seule", true);
    p.caption_numbered = flag("Images", "legende_numerotee", false);
    p.cartouche_hint_shown = flag("Astuces", "cartouche", false);
    p
}

fn save(p: &Prefs) {
    let kf = glib::KeyFile::new();
    kf.set_string("Documents", "police", p.font_family.as_deref().unwrap_or(""));
    kf.set_double("Documents", "taille", p.font_size_hp as f64 / 2.0);
    kf.set_string("Documents", "dossier", p.docs_dir.as_deref().unwrap_or(""));
    kf.set_boolean("Documents", "titre_comme_nom", p.title_as_name);
    kf.set_string("Documents", "modele", p.start_template.as_deref().unwrap_or(""));
    kf.set_string("Amenagements", "choix", &p.amenagements);
    kf.set_boolean("Saisie", "orthographe", p.spell_on_open);
    kf.set_boolean("Saisie", "images_web", p.paste_web_images);
    kf.set_string("Barre", "masques", &p.hidden_tools.join(";"));
    kf.set_boolean("Affichage", "plan", p.outline_on_start);
    kf.set_boolean("Affichage", "apercu", p.live_on_start);
    kf.set_boolean("Affichage", "regle", p.show_ruler);
    kf.set_integer("Affichage", "apercu_largeur", p.live_width);
    kf.set_double("Affichage", "zoom", p.default_zoom);
    kf.set_boolean("Affichage", "concentration_centre", p.focus_center);
    kf.set_boolean("Enregistrement", "pdf", p.pdf_with_save);
    kf.set_boolean("Images", "seule", p.image_own_line);
    kf.set_boolean("Images", "legende_numerotee", p.caption_numbered);
    kf.set_boolean("Astuces", "cartouche", p.cartouche_hint_shown);
    let path = path();
    if let Some(dir) = path.parent() {
        let _ = std::fs::create_dir_all(dir);
    }
    let _ = kf.save_to_file(path);
}

pub fn get() -> Prefs {
    PREFS.with(|p| p.borrow().clone())
}

pub fn update(f: impl FnOnce(&mut Prefs)) {
    PREFS.with(|p| {
        let mut p = p.borrow_mut();
        f(&mut p);
        save(&p);
    });
}

/// Un interrupteur relié à une préférence.
fn switch(title: &str, subtitle: &str, active: bool, set: impl Fn(&mut Prefs, bool) + 'static, changed: std::rc::Rc<dyn Fn()>) -> adw::SwitchRow {
    let row = adw::SwitchRow::builder().title(title).active(active).build();
    if !subtitle.is_empty() {
        row.set_subtitle(subtitle);
    }
    row.connect_active_notify(move |s| {
        let on = s.is_active();
        update(|p| set(p, on));
        changed();
    });
    row
}

/// La fenêtre des préférences. `changed` est appelé après chaque réglage.
pub fn dialog(parent: &impl IsA<gtk::Widget>, changed: impl Fn() + 'static) {
    let changed: std::rc::Rc<dyn Fn()> = std::rc::Rc::new(changed);
    let p = get();

    // ---- Page Documents ----
    let page = adw::PreferencesPage::builder().title("Documents").icon_name("document-edit-symbolic").build();

    let docs = adw::PreferencesGroup::builder()
        .title("Nouveaux documents")
        .description("Police et taille du texte des documents qui n'en précisent pas. Elles sont enregistrées dans le document.")
        .build();
    let gnome_font = || parent.as_ref().pango_context().font_description().and_then(|d| d.family()).map(|f| f.to_string()).unwrap_or_else(|| "Sans".into());
    let font_btn = gtk::Button::builder().label(p.font_family.clone().unwrap_or_else(gnome_font)).valign(gtk::Align::Center).build();
    let reset = gtk::Button::builder().icon_name("edit-undo-symbolic").tooltip_text("Revenir à la police de GNOME").valign(gtk::Align::Center).visible(p.font_family.is_some()).build();
    reset.add_css_class("flat");
    let font_row = adw::ActionRow::builder().title("Police").build();
    font_row.add_suffix(&reset);
    font_row.add_suffix(&font_btn);
    font_row.set_activatable_widget(Some(&font_btn));
    let size = adw::SpinRow::with_range(6.0, 72.0, 0.5);
    size.set_title("Taille (pt)");
    size.set_digits(1);
    size.set_value(p.font_size_hp as f64 / 2.0);
    docs.add(&font_row);
    docs.add(&size);
    // Le modèle d'un nouveau document.
    let templates = crate::store::templates();
    let mut names: Vec<String> = vec!["Une page vide".into()];
    names.extend(templates.iter().map(|t| t.file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_default()));
    let names_ref: Vec<&str> = names.iter().map(String::as_str).collect();
    let start = adw::ComboRow::builder()
        .title("Un nouveau document commence par")
        .subtitle("Les modèles du dossier des modèles")
        .model(&gtk::StringList::new(&names_ref))
        .build();
    let current = p.start_template.as_ref().and_then(|s| templates.iter().position(|t| t.to_string_lossy() == s.as_str())).map_or(0, |i| i + 1);
    start.set_selected(current as u32);
    {
        let templates = templates.clone();
        start.connect_selected_notify(move |r| {
            let t = (r.selected() as usize).checked_sub(1).and_then(|i| templates.get(i)).map(|t| t.to_string_lossy().to_string());
            update(|p| p.start_template = t);
        });
    }
    docs.add(&start);
    docs.add(&switch(
        "Premier titre comme nom de fichier",
        "Un document neuf propose son premier Titre 1 à l'enregistrement",
        p.title_as_name,
        |p, on| p.title_as_name = on,
        changed.clone(),
    ));
    page.add(&docs);

    let typing = adw::PreferencesGroup::builder().title("Saisie").build();
    typing.add(&switch("Vérifier l'orthographe à l'ouverture", "Le bouton Orthographe reste disponible", p.spell_on_open, |p, on| p.spell_on_open = on, changed.clone()));
    typing.add(&switch(
        "Coller les images copiées dans un navigateur",
        "« Copier l'image » puis Ctrl+V colle l'image, pas son adresse",
        p.paste_web_images,
        |p, on| p.paste_web_images = on,
        changed.clone(),
    ));
    page.add(&typing);

    let images = adw::PreferencesGroup::builder().title("Images").build();
    images.add(&switch(
        "Une image seule sur sa ligne",
        "Centrée ; du texte à côté prendrait toute sa hauteur",
        p.image_own_line,
        |p, on| p.image_own_line = on,
        changed.clone(),
    ));
    images.add(&switch("Légendes numérotées", "Une nouvelle légende commence par « Document 1 », « Document 2 »…", p.caption_numbered, |p, on| p.caption_numbered = on, changed.clone()));
    page.add(&images);

    // Dossier des documents : Ouvrir et Enregistrer y commencent.
    let files = adw::PreferencesGroup::builder().title("Fichiers").build();
    let dir_row = adw::ActionRow::builder()
        .title("Dossier des documents")
        .subtitle(p.docs_dir.clone().unwrap_or_else(|| "Aucun".into()))
        .build();
    let choose = gtk::Button::builder().label("Choisir…").valign(gtk::Align::Center).build();
    dir_row.add_suffix(&choose);
    files.add(&dir_row);
    files.add(&switch(
        "Enregistrer aussi le PDF",
        "À chaque enregistrement en DOCX ou ODT, le PDF à côté, sous le même nom",
        p.pdf_with_save,
        |p, on| p.pdf_with_save = on,
        changed.clone(),
    ));
    page.add(&files);
    {
        let (row, parent) = (dir_row.clone(), parent.as_ref().clone());
        choose.connect_clicked(move |_| {
            let dialog = gtk::FileDialog::builder().title("Dossier des documents").modal(true).build();
            if let Some(d) = get().docs_dir {
                dialog.set_initial_folder(Some(&gtk::gio::File::for_path(d)));
            }
            let row = row.clone();
            let win = parent.root().and_then(|r| r.downcast::<gtk::Window>().ok());
            dialog.select_folder(win.as_ref(), gtk::gio::Cancellable::NONE, move |res| {
                if let Some(path) = res.ok().and_then(|f| f.path()) {
                    let s = path.to_string_lossy().to_string();
                    row.set_subtitle(&s);
                    update(|p| p.docs_dir = Some(s));
                }
            });
        });
    }

    // ---- Page Interface ----
    let ui = adw::PreferencesPage::builder().title("Interface").icon_name("preferences-desktop-appearance-symbolic").build();
    let tools = adw::PreferencesGroup::builder()
        .title("Barre d'outils")
        .description("Les boutons à afficher. Un bouton masqué retire sa fonction de l'interface.")
        .build();
    for (key, label) in TOOLS {
        tools.add(&switch(
            label,
            "",
            p.shows(key),
            move |p, on| {
                p.hidden_tools.retain(|t| t != key);
                if !on {
                    p.hidden_tools.push(key.to_string());
                }
            },
            changed.clone(),
        ));
    }
    ui.add(&tools);

    let view = adw::PreferencesGroup::builder().title("Affichage").build();
    view.add(&switch("Plan ouvert au démarrage", "Le panneau des titres du document", p.outline_on_start, |p, on| p.outline_on_start = on, changed.clone()));
    view.add(&switch("Aperçu à droite au démarrage", "Les pages telles qu'elles seront imprimées, à côté du texte (F12)", p.live_on_start, |p, on| p.live_on_start = on, changed.clone()));
    let zoom_names: Vec<&str> = ZOOMS.iter().map(|(_, l)| *l).collect();
    let zoom = adw::ComboRow::builder().title("Zoom des documents ouverts").model(&gtk::StringList::new(&zoom_names)).build();
    zoom.set_selected(ZOOMS.iter().position(|(z, _)| (z - p.default_zoom).abs() < 0.01).unwrap_or(2) as u32);
    {
        let changed = changed.clone();
        zoom.connect_selected_notify(move |r| {
            let z = ZOOMS.get(r.selected() as usize).map_or(1.0, |(z, _)| *z);
            update(|p| p.default_zoom = z);
            changed();
        });
    }
    view.add(&zoom);
    view.add(&switch(
        "Mode concentration : ligne au milieu",
        "La ligne en cours reste au milieu de l'écran",
        p.focus_center,
        |p, on| p.focus_center = on,
        changed.clone(),
    ));
    ui.add(&view);

    {
        let (changed, reset2) = (changed.clone(), reset.clone());
        font_btn.connect_clicked(move |b| {
            let (changed, reset2, b2) = (changed.clone(), reset2.clone(), b.clone());
            let current = b.label().map(|l| l.to_string()).unwrap_or_default();
            crate::dialogs::choose_font_family(b, "Police par défaut", &current, move |family| {
                b2.set_label(&family);
                if get().font_family.as_deref() == Some(family.as_str()) {
                    return;
                }
                update(|p| p.font_family = Some(family));
                reset2.set_visible(true);
                changed();
            });
        });
    }
    {
        let (changed, font_btn) = (changed.clone(), font_btn.clone());
        let parent = parent.as_ref().clone();
        reset.connect_clicked(move |r| {
            update(|p| p.font_family = None);
            r.set_visible(false);
            let family = parent.pango_context().font_description().and_then(|d| d.family()).map(|f| f.to_string()).unwrap_or_else(|| "Sans".into());
            font_btn.set_label(&family);
            changed();
        });
    }
    {
        let changed = changed.clone();
        size.connect_value_notify(move |s| {
            update(|p| p.font_size_hp = (s.value() * 2.0).round() as u16);
            changed();
        });
    }

    let dialog = adw::PreferencesDialog::builder().title("Préférences").search_enabled(true).build();
    dialog.add(&page);
    dialog.add(&ui);
    dialog.present(Some(parent));
}
