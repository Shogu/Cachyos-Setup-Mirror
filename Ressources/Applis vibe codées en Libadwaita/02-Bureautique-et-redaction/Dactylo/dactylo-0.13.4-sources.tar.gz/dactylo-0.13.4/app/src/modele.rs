// modele.rs — fabrique les modèles livrés avec Samizdat : Cours, Page de
// garde de séquence, Bac blanc Français, Bac blanc Histoire-Géographie.
//
// Lancer : SAMIZDAT_MODELES=/chemin cargo test -p dactylo modele -- --ignored
// SPDX-License-Identifier: GPL-3.0-or-later

#[cfg(test)]
mod tests {
    use letters_core::model::BaseFont;
    use letters_core::{Alignment, Document, ListKind, PageGeometry, Paragraph, ParaStyle, Run, RunStyle, TableCell};

    const INK: &str = "241F31";
    const BLUE: &str = "1A5FB4";
    const GREY: &str = "5E5C64";

    fn run(text: &str, style: RunStyle) -> Run {
        Run { text: text.into(), style }
    }

    fn plain(text: &str) -> Run {
        run(text, RunStyle { color: Some(INK.into()), ..Default::default() })
    }

    fn bold(text: &str, color: &str) -> Run {
        run(text, RunStyle { bold: true, color: Some(color.into()), ..Default::default() })
    }

    fn para(style: ParaStyle, runs: Vec<Run>) -> Paragraph {
        Paragraph { style, runs }
    }

    fn body() -> ParaStyle {
        ParaStyle { line_spacing: 1.15, space_after_pt: 6.0, ..Default::default() }
    }

    fn heading(level: u8, text: &str) -> Paragraph {
        para(ParaStyle { heading: Some(level), space_before_pt: if level == 1 { 6.0 } else { 14.0 }, space_after_pt: 6.0, keep_with_next: true, ..Default::default() }, vec![Run::plain(text)])
    }

    /// Une zone de texte (tableau d'une case), aux coins arrondis dans le PDF.
    fn boxed(id: u32, runs: Vec<Run>) -> Paragraph {
        para(ParaStyle { table_cell: Some(TableCell { table: id, row: 0, col: 0 }), line_spacing: 1.15, ..Default::default() }, runs)
    }

    fn bullet(runs: Vec<Run>) -> Paragraph {
        para(ParaStyle { list: ListKind::Bullet, space_after_pt: 3.0, line_spacing: 1.15, ..Default::default() }, runs)
    }

    fn numbered(runs: Vec<Run>) -> Paragraph {
        para(ParaStyle { list: ListKind::Numbered, space_after_pt: 6.0, line_spacing: 1.15, ..Default::default() }, runs)
    }

    fn empty() -> Paragraph {
        para(body(), vec![])
    }

    /// L'emplacement d'une image : un cadre gris clair aux coins arrondis.
    fn placeholder(path: &std::path::Path) {
        let (w, h) = (1200, 640);
        let surface = gtk4::cairo::ImageSurface::create(gtk4::cairo::Format::ARgb32, w, h).unwrap();
        let cr = gtk4::cairo::Context::new(&surface).unwrap();
        crate::retouch::rounded(&cr, 6.0, 6.0, w as f64 - 12.0, h as f64 - 12.0, 40.0);
        cr.set_source_rgb(0.965, 0.961, 0.957);
        cr.fill_preserve().unwrap();
        cr.set_source_rgb(0.6, 0.59, 0.62);
        cr.set_line_width(6.0);
        cr.set_dash(&[24.0, 16.0], 0.0);
        cr.stroke().unwrap();
        cr.set_dash(&[], 0.0);
        cr.select_font_face("Sans", gtk4::cairo::FontSlant::Normal, gtk4::cairo::FontWeight::Bold);
        cr.set_font_size(54.0);
        cr.set_source_rgb(0.37, 0.36, 0.39);
        for (i, line) in ["Image du document", "double-clic : retouches et légende"].iter().enumerate() {
            if i == 1 {
                cr.select_font_face("Sans", gtk4::cairo::FontSlant::Normal, gtk4::cairo::FontWeight::Normal);
                cr.set_font_size(40.0);
            }
            let ext = cr.text_extents(line).unwrap();
            cr.move_to((w as f64 - ext.width()) / 2.0, h as f64 / 2.0 - 10.0 + i as f64 * 70.0);
            cr.show_text(line).unwrap();
        }
        drop(cr);
        let mut f = std::fs::File::create(path).unwrap();
        surface.write_to_png(&mut f).unwrap();
    }

    fn sup(text: &str) -> Run {
        run(text, RunStyle { color: Some(INK.into()), vert_align: Some(letters_core::model::VertAlign::Superscript), ..Default::default() })
    }

    fn small(text: &str) -> Run {
        run(text, RunStyle { color: Some(GREY.into()), font_size_hp: Some(21), ..Default::default() })
    }

    fn centered(runs: Vec<Run>, after: f64) -> Paragraph {
        para(ParaStyle { alignment: Alignment::Center, space_after_pt: after, ..Default::default() }, runs)
    }

    fn big(text: &str, hp: u16, color: &str) -> Run {
        run(text, RunStyle { bold: true, color: Some(color.into()), font_size_hp: Some(hp), ..Default::default() })
    }

    /// Un cartouche d'une allure donnée.
    fn cartouche(id: u32, look: letters_core::Cartouche, align: Alignment, runs: Vec<Run>) -> Paragraph {
        let mut p = boxed(id, runs);
        p.style.cartouche = Some(look);
        p.style.alignment = align;
        p
    }

    fn page_break(mut p: Paragraph) -> Paragraph {
        p.style.page_break_before = true;
        p
    }

    /// Une ligne d'un texte d'étude : numérotée de 5 en 5, justifiée.
    fn text_line(runs: Vec<Run>) -> Paragraph {
        para(ParaStyle { line_numbers: true, alignment: Alignment::Justify, line_spacing: 1.15, space_after_pt: 4.0, first_line_indent_pt: 18.0, ..Default::default() }, runs)
    }

    fn image(img: &std::path::Path, cm: f64) -> Paragraph {
        let w = (cm * 360_000.0) as u64;
        para(ParaStyle { alignment: Alignment::Center, space_after_pt: 4.0, ..Default::default() }, vec![run("\u{FFFC}", RunStyle { image: Some(img.to_string_lossy().to_string()), image_extent_emu: Some((w, w * 640 / 1200)), ..Default::default() })])
    }

    /// A4, marges 2 cm, Adwaita Sans 13 pt, titres bleus.
    fn document(footer: &str) -> Document {
        let mut d = Document::new();
        let cm = 72.0 / 2.54;
        d.page = Some(PageGeometry { width_pt: 595.28, height_pt: 841.89, margin_top_pt: 2.0 * cm, margin_bottom_pt: 2.0 * cm, margin_left_pt: 2.0 * cm, margin_right_pt: 2.0 * cm, columns: 1, ..Default::default() });
        d.base_font = BaseFont { family: Some("Adwaita Sans".into()), size_hp: Some(26) };
        d.footer = (!footer.is_empty()).then(|| footer.into());
        let h = |size: u16, color: &str| RunStyle { bold: true, color: Some(color.into()), font_size_hp: Some(size), ..Default::default() };
        d.heading_styles = vec![h(44, BLUE), h(34, BLUE), h(29, INK), h(26, INK), h(26, INK), h(26, INK)];
        d
    }

    fn finish(mut d: Document, mut p: Vec<Paragraph>, out: &std::path::Path) {
        for q in &mut p {
            if q.style.table_cell.is_none() && q.style.heading.is_none() && q.style.list == ListKind::None && q.style.line_spacing == 1.0 {
                q.style.line_spacing = 1.15;
            }
        }
        d.paragraphs = p;
        letters_core::save::write(&d, out).expect("modèle écrit");
        let back = letters_core::save::read(out).expect("modèle relu");
        assert_eq!(back.footer, d.footer);
        // Un aperçu en PDF, à côté (pour vérifier la mise en page).
        if std::env::var_os("SAMIZDAT_MODELES_PDF").is_some() {
            letters_core::layout::pango::Typeset::new(back, letters_core::layout::LayoutOptions::default()).write_pdf(&out.with_extension("pdf")).unwrap();
        }
    }

    fn top_line(classe: &str) -> Paragraph {
        para(ParaStyle { space_after_pt: 2.0, ..Default::default() }, vec![run(classe, RunStyle { bold: true, color: Some(GREY.into()), font_size_hp: Some(22), ..Default::default() })])
    }

    /// Cours : la séquence en petit en haut, la séance en Titre 1.
    fn cours(img: &std::path::Path, out: &std::path::Path) {
        let d = document("Page {page} sur {total}");
        let p = vec![
            top_line("TERMINALE BAC PRO  ·  HISTOIRE-GÉOGRAPHIE"),
            para(ParaStyle { space_after_pt: 4.0, ..Default::default() }, vec![run("Séquence 1 — Titre de la séquence", RunStyle { color: Some(BLUE.into()), font_size_hp: Some(24), ..Default::default() })]),
            heading(1, "Séance 1 — Titre de la séance"),
            boxed(1, vec![bold("Problématique : ", BLUE), plain("comment … ?")]),
            empty(),
            heading(2, "Documents de la séance"),
            bullet(vec![bold("Document 1 — ", INK), plain("Texte : Auteur, « Titre de l'œuvre », date")]),
            bullet(vec![bold("Document 2 — ", INK), plain("Carte ou image : titre, source, date")]),
            bullet(vec![bold("Document 3 — ", INK), plain("…")]),
            heading(3, "Document 1 — Auteur, « Titre de l'œuvre », date"),
            boxed(2, vec![plain("Collez ici le texte de l'auteur. Le cadre aux coins arrondis le sépare du reste de la page, sans l'alourdir.")]),
            para(ParaStyle { alignment: Alignment::Right, space_before_pt: 4.0, space_after_pt: 10.0, ..Default::default() }, vec![run("Source : auteur, ouvrage, éditeur, année.", RunStyle { color: Some(GREY.into()), font_size_hp: Some(22), ..Default::default() })]),
            heading(3, "Document 2 — Titre de la carte ou de l'image"),
            image(img, 14.0),
            crate::retouch::caption_paragraph("Légende : ce que montre l'image, sa source et sa date.", None),
        ];
        finish(d, p, out);
    }

    /// Page de garde d'une séquence.
    fn garde(img: &std::path::Path, out: &std::path::Path) {
        let d = document("");
        let p = vec![
            top_line("CLASSE : TERMINALE BAC PRO …"),
            para(ParaStyle { space_after_pt: 0.0, ..Default::default() }, vec![run("Séquence 1", RunStyle { color: Some(BLUE.into()), font_size_hp: Some(28), ..Default::default() })]),
            heading(1, "Titre de la séquence"),
            cartouche(1, crate::commands::CARTOUCHES[1].2, Alignment::Left, vec![bold("Problématique générale : ", BLUE), plain("en quoi … ?")]),
            empty(),
            cartouche(2, crate::commands::CARTOUCHES[4].2, Alignment::Justify, vec![bold("Introduction. ", BLUE), plain("Quelques lignes pour entrer dans la séquence : une situation, une question, un lien avec ce que les élèves connaissent.")]),
            empty(),
            image(img, 16.0),
            crate::retouch::caption_paragraph("Légende de l'image : ce qu'elle montre, sa source et sa date.", None),
            heading(2, "Plan de la séquence"),
            numbered(vec![bold("Séance 1 — ", INK), plain("Titre de la séance")]),
            numbered(vec![bold("Séance 2 — ", INK), plain("Titre de la séance")]),
            numbered(vec![bold("Séance 3 — ", INK), plain("Titre de la séance")]),
            numbered(vec![bold("Évaluation — ", INK), plain("ce qui sera évalué")]),
        ];
        finish(d, p, out);
    }

    /// La couverture d'un sujet de baccalauréat professionnel blanc.
    fn bac_cover(epreuve: &[&str], pages: &str, duree: &str, interdit: &str) -> Vec<Paragraph> {
        let mut p = vec![
            centered(vec![], 40.0),
            centered(vec![big("BACCALAURÉAT PROFESSIONNEL BLANC", 34, INK)], 30.0),
        ];
        let sujet = crate::commands::CARTOUCHES[5].2;
        let mut runs = Vec::new();
        for (i, line) in epreuve.iter().enumerate() {
            if i > 0 {
                runs.push(big(crate::commands::LINE_BREAK, 34, BLUE));
            }
            runs.push(big(line, 34, BLUE));
        }
        p.push(cartouche(1, sujet, Alignment::Center, runs));
        p.extend([
            centered(vec![], 30.0),
            centered(vec![big(duree, 28, INK)], 24.0),
            centered(vec![plain(pages)], 8.0),
            centered(vec![plain(interdit)], 24.0),
        ]);
        p
    }

    fn question(n: u32, points: &str, text: &str) -> Vec<Paragraph> {
        vec![
            para(ParaStyle { space_before_pt: 8.0, space_after_pt: 2.0, keep_with_next: true, ..Default::default() }, vec![bold(&format!("Question {n} : "), BLUE), bold(&format!("({points})"), INK)]),
            para(body(), vec![plain(text)]),
        ]
    }

    /// Un tableau : ses lignes de cases, la première en gras si `header`.
    fn table(id: u32, rows: &[&[&str]], header: bool) -> Vec<Paragraph> {
        let mut out = Vec::new();
        for (r, row) in rows.iter().enumerate() {
            for (c, text) in row.iter().enumerate() {
                let runs = if text.is_empty() {
                    vec![]
                } else if header && r == 0 {
                    vec![bold(text, INK)]
                } else {
                    vec![plain(text)]
                };
                out.push(para(ParaStyle { table_cell: Some(TableCell { table: id, row: r as u32, col: c as u32 }), line_spacing: 1.15, ..Default::default() }, runs));
            }
        }
        out
    }

    fn underlined(text: &str) -> Run {
        run(text, RunStyle { bold: true, underline: true, color: Some(INK.into()), ..Default::default() })
    }

    /// « Thème 1 : … », le libellé souligné.
    fn labelled(label: &str, text: &str) -> Paragraph {
        para(ParaStyle { space_after_pt: 8.0, line_spacing: 1.15, ..Default::default() }, vec![underlined(label), run(&format!(" {text}"), RunStyle { bold: true, color: Some(INK.into()), ..Default::default() })])
    }

    /// Le titre d'une partie, encadré, et dans le Plan.
    fn partie(id: u32, text: &str) -> Paragraph {
        let mut p = cartouche(id, crate::commands::CARTOUCHES[4].2, Alignment::Center, vec![Run::plain(text)]);
        p.style.heading = Some(1);
        p
    }

    /// Une nouvelle page (un paragraphe vide qui la commence : un tableau ou
    /// un cartouche ne peut pas commencer une page dans Word).
    fn new_page() -> Paragraph {
        para(ParaStyle { page_break_before: true, ..Default::default() }, vec![])
    }

    fn centered_title(text: &str, underline: bool, hp: u16) -> Paragraph {
        para(
            ParaStyle { alignment: Alignment::Center, space_before_pt: 10.0, space_after_pt: 8.0, keep_with_next: true, ..Default::default() },
            vec![run(text, RunStyle { bold: true, underline, color: Some(INK.into()), font_size_hp: Some(hp), ..Default::default() })],
        )
    }

    /// « QUESTION 1 : … », comme dans les sujets officiels.
    fn q(n: u32, text: &str) -> Paragraph {
        para(ParaStyle { space_before_pt: 6.0, space_after_pt: 10.0, line_spacing: 1.15, ..Default::default() }, vec![bold(&format!("QUESTION {n} : "), INK), plain(text)])
    }

    fn bullet_plain(text: &str) -> Paragraph {
        bullet(vec![plain(text)])
    }

    /// Un document du dossier : son titre, son texte (et ses notes) dans un
    /// cartouche Document, sa source.
    fn dossier_document(id: u32, n: u32, title: &str, lines: &[&str], source: &str) -> Vec<Paragraph> {
        let mut runs = Vec::new();
        for (i, l) in lines.iter().enumerate() {
            if i > 0 {
                runs.push(plain(crate::commands::LINE_BREAK));
            }
            if l.starts_with("Notes") || l.starts_with("1.") || l.starts_with("2.") {
                runs.push(run(l, RunStyle { color: Some(GREY.into()), font_size_hp: Some(21), ..Default::default() }));
            } else {
                runs.push(plain(l));
            }
        }
        let mut doc = cartouche(id, crate::commands::CARTOUCHES[4].2, Alignment::Left, runs);
        doc.style.line_spacing = 1.15;
        vec![
            para(ParaStyle { space_before_pt: 6.0, space_after_pt: 6.0, keep_with_next: true, ..Default::default() }, vec![bold(&format!("DOCUMENT {n} : "), INK), plain(title)]),
            doc,
            para(ParaStyle { alignment: Alignment::Right, space_before_pt: 4.0, space_after_pt: 12.0, ..Default::default() }, vec![small(source)]),
        ]
    }

    fn annexe(n: u32, title: &str) -> Vec<Paragraph> {
        vec![
            page_break(para(ParaStyle { space_after_pt: 18.0, ..Default::default() }, vec![bold("NOM, Prénom : ", INK), plain("……………………………………………………………")])),
            centered_title(&format!("ANNEXE {n} À COMPLÉTER ET À RENDRE AVEC LA COPIE"), true, 26),
            centered_title(title, false, 26),
        ]
    }

    /// Bac blanc de français, sur le modèle d'un sujet de l'académie.
    fn bac_francais(img: &std::path::Path, out: &std::path::Path) {
        let d = document("BAC Blanc – Français\t{page} sur {total}\tLycée …");
        let mut p = bac_cover(
            &["ÉPREUVE DE FRANÇAIS"],
            "Ce sujet comporte 5 pages numérotées de 1/5 à 5/5. Assurez-vous que cet exemplaire est complet. S'il est incomplet, demandez un autre exemplaire au chef de salle.",
            "Durée totale de l'épreuve : 3 heures — Coefficient : 2,5",
            "L'usage du dictionnaire et de la calculatrice est interdit.",
        );
        let lorem = "Collez ici le texte. Chaque paragraphe garde ses lignes numérotées de 5 en 5 dans la marge, comme dans les sujets officiels ; les numéros repartent de 1 pour le texte suivant. ";
        p.extend([
            page_break(para(ParaStyle { space_after_pt: 12.0, ..Default::default() }, vec![bold("Programme limitatif : ", INK), bold("« Thème de l'objet d'étude »", BLUE)])),
            heading(2, "Texte 1"),
            text_line(vec![plain(&lorem.repeat(3)), sup("1")]),
            text_line(vec![plain(&lorem.repeat(3))]),
            text_line(vec![plain(&lorem.repeat(2)), sup("2")]),
            para(ParaStyle { alignment: Alignment::Right, space_before_pt: 6.0, space_after_pt: 12.0, ..Default::default() }, vec![bold("Auteur, ", INK), plain("Titre de l'œuvre, éditeur, année.")]),
            para(ParaStyle { space_after_pt: 2.0, ..Default::default() }, vec![small("1. Note : explication d'un mot difficile.")]),
            para(ParaStyle { space_after_pt: 2.0, ..Default::default() }, vec![small("2. Note : …")]),
            page_break(heading(2, "Document 2 — Bande dessinée")),
            image(img, 16.0),
            crate::retouch::caption_paragraph("Auteur, titre de l'album, éditeur, année, planche ou page.", None),
            page_break(heading(2, "Texte 2")),
            text_line(vec![plain(&lorem.repeat(3))]),
            text_line(vec![plain(&lorem.repeat(3)), sup("1")]),
            para(ParaStyle { alignment: Alignment::Right, space_before_pt: 6.0, space_after_pt: 12.0, ..Default::default() }, vec![bold("Auteur, ", INK), plain("Titre de l'œuvre, éditeur, année.")]),
            para(ParaStyle { space_after_pt: 2.0, ..Default::default() }, vec![small("1. Note : …")]),
            page_break(heading(2, "Évaluation des compétences de lecture (10 points)")),
            heading(3, "Texte 1"),
        ]);
        p.extend(question(1, "2 points", "a) Question sur le texte 1. b) Seconde partie de la question."));
        p.extend(question(2, "2 points", "Question sur le texte 1."));
        p.push(heading(3, "Document 2 et texte 2"));
        p.extend(question(3, "3 points", "Question sur la bande dessinée."));
        p.extend(question(4, "3 points", "Question qui rapproche les documents : en vous appuyant sur …, montrez que …"));
        p.push(heading(2, "Évaluation des compétences d'écriture (10 points)"));
        let look = letters_core::Cartouche { square: false, line: letters_core::CartoucheLine::Medium, white: false };
        p.push(cartouche(2, look, Alignment::Justify, vec![bold("Sujet : ", BLUE), plain("énoncé du sujet d'écriture. Vous rédigerez un texte argumenté d'une quarantaine de lignes, en vous appuyant sur les documents du corpus, sur vos lectures et sur votre culture personnelle.")]));
        finish(d, p, out);
    }

    /// Bac blanc d'histoire-géographie et EMC, sur le modèle des sujets
    /// de l'académie : trois parties, le dossier documentaire, les
    /// questions, les annexes à rendre avec la copie.
    fn bac_hg(img: &std::path::Path, out: &std::path::Path) {
        let d = document("BAC Blanc – HG/EMC\t{page} sur {total}\tLycée …");
        let mut p = bac_cover(
            &["HISTOIRE-GÉOGRAPHIE", "ENSEIGNEMENT MORAL ET CIVIQUE"],
            "Le candidat traite obligatoirement les trois parties : histoire, géographie, enseignement moral et civique.",
            "Durée : 2 h 30 – Coefficient : 2,5",
            "L'usage de la calculatrice et du dictionnaire est interdit.",
        );
        let br = crate::commands::LINE_BREAK;
        p.extend(table(
            2,
            &[
                &[&format!("Première partie{br}HISTOIRE{br}(6 points)"), "Page 2"],
                &[&format!("Deuxième partie{br}GÉOGRAPHIE{br}(8 points){br}ANNEXE 1 À RENDRE AVEC LA COPIE"), "Pages 3 à 8"],
                &[&format!("Troisième partie{br}ENSEIGNEMENT MORAL ET CIVIQUE{br}(6 points)"), "Pages 9 à 12"],
            ],
            false,
        ));
        for q in p.iter_mut().filter(|q| q.style.table_cell.is_some_and(|c| c.table == 2)) {
            q.style.alignment = Alignment::Center;
        }
        p.push(centered(vec![], 6.0));

        // Première partie : histoire.
        p.push(new_page());
        p.push(partie(3, "PREMIÈRE PARTIE : HISTOIRE (6 points)"));
        p.push(labelled("Thème 1 :", "Le jeu des puissances dans les relations internationales depuis 1945."));
        p.push(labelled("Compétence évaluée :", "Maîtriser et utiliser des repères chronologiques (3 points)"));
        p.push(q(1, "Placez les repères suivants sur la frise chronologique (annexe 1 à rendre avec la copie) :"));
        for e in ["Guerre de Corée.", "Proclamation de la République populaire de Chine.", "Chute du mur de Berlin.", "Crise des missiles de Cuba."] {
            p.push(bullet_plain(e));
        }
        p.push(q(2, "Citez deux éléments qui font des États-Unis et de l'URSS des superpuissances."));
        p.push(labelled("Compétence évaluée :", "S'approprier les démarches historiques (3 points)"));
        p.push(q(3, "En quelques lignes, expliquez la notion de « non-alignement » des pays nouvellement décolonisés durant la guerre froide."));

        // Deuxième partie : géographie.
        p.push(new_page());
        p.push(partie(4, "DEUXIÈME PARTIE : GÉOGRAPHIE (8 points)"));
        p.push(labelled("Thème 1 :", "L'accès aux ressources pour produire, consommer, se loger et se déplacer."));
        p.push(para(ParaStyle { space_after_pt: 4.0, ..Default::default() }, vec![underlined("Capacités évaluées :")]));
        for c in [
            "Décrire une situation géographique ;",
            "Questionner un ou des documents pour conduire une analyse géographique autour d'un projet d'aménagement lié au développement durable ;",
            "Réaliser un croquis simple de géographie.",
        ] {
            p.push(bullet_plain(c));
        }
        p.push(centered_title("SUJET", true, 28));
        p.push(centered_title("Titre du sujet : le projet étudié", true, 26));
        p.push(para(ParaStyle { space_before_pt: 8.0, space_after_pt: 6.0, ..Default::default() }, vec![plain("Le dossier comporte 3 documents :")]));
        p.extend(table(5, &[&["Document", "Source des documents"], &["Document 1", "AUTEUR. « Titre de l'article » [en ligne]. Journal, date. Disponible sur : … [consulté le …]."], &["Document 2", "…"], &["Document 3", "…"]], true));
        p.push(empty());
        let mut doc1 = dossier_document(
            6,
            1,
            "titre du document.",
            &["« Collez ici le texte du document. Entrée passe à la ligne dans le cadre, et les notes restent dedans. »", "Notes :", "1. Explication d'un mot difficile.", "2. …"],
            "Source : auteur, titre, date.",
        );
        doc1[0].style.page_break_before = true;
        p.extend(doc1);
        p.push(para(ParaStyle { space_before_pt: 6.0, space_after_pt: 6.0, keep_with_next: true, page_break_before: true, ..Default::default() }, vec![bold("DOCUMENT 3 : ", INK), plain("titre de la photographie ou de la carte.")]));
        p.push(image(img, 16.0));
        p.push(crate::retouch::caption_paragraph("Légende et source de l'image.", None));
        p.push(page_break(centered_title("QUESTIONS", true, 28)));
        p.push(q(1, "Expliquez les enjeux du projet aux échelles locale et nationale."));
        p.push(q(2, "Relevez … (Document 1)."));
        p.push(q(3, "Recopiez le tableau suivant sur votre copie et complétez-le afin d'identifier les acteurs et leurs arguments (Documents 1, 2 et 3)."));
        p.extend(table(7, &[&["", "Acteurs", "Arguments"], &["Favorables au projet", "", ""], &["Opposants au projet", "", ""]], true));
        p.push(empty());
        p.push(q(4, "Réalisez un croquis (Annexe 1) à partir de la légende proposée et des documents 1, 2 et 3."));
        p.push(q(5, "Justifiez l'affirmation suivante dans un texte d'une dizaine de lignes : « … ». Vous vous appuierez sur l'exemple étudié ou sur tout autre exemple de votre choix."));
        p.extend(annexe(1, "Titre du croquis"));
        p.push(image(img, 16.0));
        p.push(para(ParaStyle { space_before_pt: 8.0, space_after_pt: 4.0, ..Default::default() }, vec![underlined("Légende :")]));
        p.extend(table(8, &[&["", "Zone d'extraction", "", "Station de stockage"], &["", "Usine de transformation", "", "Flux par canalisations"]], false));
        p.push(empty());
        // La frise à placer (annexe de la première partie), modifiable d'un double-clic.
        let frise = crate::frise::Frise {
            title: "Annexe : frise à compléter".into(),
            events: vec![("1945".into(), "…".into()), ("1947-1991".into(), "Guerre froide".into()), ("1962".into(), "…".into()), ("1989".into(), "…".into())],
        };
        let png = crate::frise::render_png(&frise, "Adwaita Sans").unwrap();
        let (w, h) = crate::commands::image_size(&png.to_string_lossy()).unwrap();
        let emu = (16.0 * 360_000.0) as u64;
        p.extend(annexe(2, "Frise chronologique (première partie)"));
        p.push(para(
            ParaStyle { alignment: Alignment::Center, space_after_pt: 4.0, ..Default::default() },
            vec![run(&frise.to_alt(), RunStyle { image: Some(png.to_string_lossy().to_string()), image_extent_emu: Some((emu, emu * h as u64 / w as u64)), ..Default::default() })],
        ));

        // Troisième partie : EMC.
        p.push(new_page());
        p.push(partie(9, "TROISIÈME PARTIE : ENSEIGNEMENT MORAL ET CIVIQUE (6 points)"));
        p.push(labelled("Thème :", "S'engager et débattre en démocratie autour des défis de société."));
        p.push(para(ParaStyle { space_after_pt: 4.0, ..Default::default() }, vec![underlined("Compétences évaluées :")]));
        for c in [
            "Construire et exprimer une argumentation cohérente et étayée en s'appuyant sur les repères et les notions du programme ;",
            "Mettre à distance ses opinions personnelles pour construire son jugement ;",
            "Respecter autrui et la pluralité des points de vue.",
        ] {
            p.push(bullet_plain(c));
        }
        p.push(para(ParaStyle { space_before_pt: 8.0, space_after_pt: 8.0, line_spacing: 1.15, ..Default::default() }, vec![underlined("Termes et notions qui peuvent être mobilisés (liste non exhaustive) :"), plain(" association, liberté d'expression, pluralisme, responsabilité, démocratie participative, démocratie représentative.")]));
        p.push(centered_title("SUJET", true, 28));
        p.push(centered_title("Titre du sujet", true, 26));
        p.push(cartouche(10, crate::commands::CARTOUCHES[4].2, Alignment::Justify, vec![plain("La situation : quelques lignes qui présentent le débat.")]));
        p.push(para(ParaStyle { space_before_pt: 10.0, space_after_pt: 6.0, ..Default::default() }, vec![plain("Le dossier comporte 2 documents :")]));
        p.extend(table(11, &[&["Document", "Source des documents"], &["Document 1", "…"], &["Document 2", "…"]], true));
        p.push(empty());
        let mut doc1 = dossier_document(12, 1, "titre du document.", &["« Texte du document. »"], "Source : …");
        doc1[0].style.page_break_before = true;
        p.extend(doc1);
        p.push(page_break(centered_title("QUESTIONS", true, 28)));
        p.push(q(1, "Expliquez la phrase soulignée dans le document 1."));
        p.push(q(2, "Identifiez … (Document 1)."));
        p.push(q(3, "Expliquez comment … (Documents 1 et 2)."));
        p.push(q(4, "Vous participez à une réunion publique dont l'objet est d'échanger sur la question suivante : « … ». Exposez votre point de vue dans un texte argumenté d'une dizaine de lignes."));
        p.push(empty());
        p.push(cartouche(13, crate::commands::CARTOUCHES[5].2, Alignment::Left, vec![bold("Afin de respecter l'anonymat de votre copie, vous ne devez pas signer votre composition, citer votre nom, celui d'un camarade ou celui de votre établissement.", INK)]));
        finish(d, p, out);
    }

    /// Les modèles livrés, dans le dossier `SAMIZDAT_MODELES` : lancer
    /// SAMIZDAT_MODELES=/chemin cargo test -p dactylo modele -- --ignored
    #[test]
    #[ignore]
    fn modele() {
        let Ok(dir) = std::env::var("SAMIZDAT_MODELES") else { return };
        let dir = std::path::PathBuf::from(dir);
        std::fs::create_dir_all(&dir).unwrap();
        let img = dir.join("Image.png");
        placeholder(&img);
        cours(&img, &dir.join("Cours.docx"));
        garde(&img, &dir.join("Page de garde de séquence.docx"));
        bac_francais(&img, &dir.join("Bac blanc Français.docx"));
        bac_hg(&img, &dir.join("Bac blanc Histoire-Géographie.docx"));
        let _ = std::fs::remove_file(img);
    }
}
