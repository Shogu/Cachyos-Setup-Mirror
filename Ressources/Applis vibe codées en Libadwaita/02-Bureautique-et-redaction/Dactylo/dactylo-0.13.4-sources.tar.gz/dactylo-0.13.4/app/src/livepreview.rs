// livepreview.rs — l'aperçu en direct, à droite du texte : les pages telles
// que le PDF les montrera, redessinées pendant la frappe.
//
// Une seule zone de dessin de la taille du panneau, qui ne dessine que les
// pages visibles (un long document ne coûte pas plus qu'une page), et une
// barre de défilement à côté. Un clic sur une page y place le curseur.
// SPDX-License-Identifier: GPL-3.0-or-later

use std::cell::{Cell, RefCell};
use std::rc::Rc;

use gtk4::{self as gtk, prelude::*};
use letters_core::layout::pango::{Caret, TextPos, Typeset};
use letters_core::layout::{LayoutOptions, PageStack};

/// Écart entre deux pages et marge autour, en pixels.
const GAP: f64 = 16.0;
const SIDE: f64 = 14.0;
/// 1 point = 96/72 pixels à 100 %.
const PX_PER_PT: f64 = 96.0 / 72.0;

struct State {
    typeset: Option<Typeset>,
    stack: PageStack,
    /// Pixels par point.
    scale: f64,
    caret: Option<Caret>,
}

pub struct LivePreview {
    pub widget: gtk::Box,
    pub area: gtk::DrawingArea,
    adj: gtk::Adjustment,
    count: gtk::Label,
    state: RefCell<State>,
    /// Un clic sur une page : le point du texte, le nombre de clics, et
    /// où (pour y ouvrir un menu).
    on_click: RefCell<Option<Box<dyn Fn(TextPos, i32, f64, f64)>>>,
    /// Le panneau vient d'être rempli : aller au curseur sans attendre
    /// qu'il sorte de l'écran.
    jump: Cell<bool>,
}

impl LivePreview {
    pub fn new() -> Rc<Self> {
        let area = gtk::DrawingArea::builder().hexpand(true).vexpand(true).build();
        area.set_cursor_from_name(Some("pointer"));
        let adj = gtk::Adjustment::new(0.0, 0.0, 0.0, 40.0, 400.0, 0.0);
        let scrollbar = gtk::Scrollbar::new(gtk::Orientation::Vertical, Some(&adj));
        let pages = gtk::Box::new(gtk::Orientation::Horizontal, 0);
        pages.append(&area);
        pages.append(&scrollbar);

        let title = gtk::Label::new(Some("Aperçu"));
        title.add_css_class("heading");
        let count = gtk::Label::new(None);
        count.add_css_class("dim-label");
        count.add_css_class("caption");
        let titles = gtk::Box::new(gtk::Orientation::Vertical, 0);
        titles.set_tooltip_text(Some("Clic sur une page : le curseur va à cet endroit du texte\nDouble-clic : modifier l'image, la frise, le tableau ou le cartouche"));
        titles.append(&title);
        titles.append(&count);
        let close = gtk::Button::builder().icon_name("window-close-symbolic").action_name("win.live-preview").tooltip_text("Fermer l'aperçu (F12)").valign(gtk::Align::Center).build();
        close.add_css_class("flat");
        close.add_css_class("circular");
        let head = gtk::CenterBox::new();
        head.set_center_widget(Some(&titles));
        head.set_end_widget(Some(&close));
        head.set_margin_top(6);
        head.set_margin_bottom(6);
        head.set_margin_end(6);

        let widget = gtk::Box::new(gtk::Orientation::Vertical, 0);
        widget.add_css_class("samizdat-desk");
        widget.add_css_class("samizdat-live");
        widget.append(&head);
        widget.append(&gtk::Separator::new(gtk::Orientation::Horizontal));
        widget.append(&pages);
        widget.set_size_request(220, -1);

        let this = Rc::new(Self {
            widget,
            area,
            adj,
            count,
            state: RefCell::new(State { typeset: None, stack: PageStack::default(), scale: 0.5, caret: None }),
            on_click: RefCell::new(None),
            jump: Cell::new(true),
        });
        this.connect();
        this
    }

    fn connect(self: &Rc<Self>) {
        {
            let w = Rc::downgrade(self);
            self.area.set_draw_func(move |_, cr, width, height| {
                if let Some(w) = w.upgrade() {
                    w.draw(cr, width as f64, height as f64);
                }
            });
        }
        {
            let w = Rc::downgrade(self);
            self.area.connect_resize(move |_, _, _| {
                if let Some(w) = w.upgrade() {
                    w.relayout();
                }
            });
        }
        {
            let area = self.area.downgrade();
            self.adj.connect_value_changed(move |_| {
                if let Some(a) = area.upgrade() {
                    a.queue_draw();
                }
            });
        }
        {
            let scroll = gtk::EventControllerScroll::new(gtk::EventControllerScrollFlags::VERTICAL | gtk::EventControllerScrollFlags::KINETIC);
            let adj = self.adj.clone();
            scroll.connect_scroll(move |c, _, dy| {
                let step = if c.unit() == gtk::gdk::ScrollUnit::Wheel { dy * 60.0 } else { dy };
                adj.set_value((adj.value() + step).clamp(adj.lower(), (adj.upper() - adj.page_size()).max(adj.lower())));
                gtk::glib::Propagation::Stop
            });
            self.area.add_controller(scroll);
        }
        {
            let click = gtk::GestureClick::new();
            let w = Rc::downgrade(self);
            click.connect_released(move |g, n, x, y| {
                let Some(w) = w.upgrade() else { return };
                g.set_state(gtk::EventSequenceState::Claimed);
                if let Some(pos) = w.hit(x, y) {
                    if let Some(f) = w.on_click.borrow().as_ref() {
                        f(pos, n, x, y);
                    }
                }
            });
            self.area.add_controller(click);
        }
    }

    /// Ce que fait un clic sur une page.
    pub fn connect_clicked(&self, f: impl Fn(TextPos, i32, f64, f64) + 'static) {
        *self.on_click.borrow_mut() = Some(Box::new(f));
    }

    /// Le prochain `show_caret` ira au curseur même s'il est déjà visible
    /// (panneau rouvert, autre onglet).
    pub fn jump_to_caret(&self) {
        self.jump.set(true);
    }

    /// Met les pages à jour avec `doc` (seuls les paragraphes changés sont
    /// recomposés).
    pub fn set_document(&self, doc: letters_core::Document) {
        {
            let mut st = self.state.borrow_mut();
            match st.typeset.as_mut() {
                Some(t) => {
                    t.update(doc, LayoutOptions::default());
                }
                None => st.typeset = Some(Typeset::new(doc, LayoutOptions::default())),
            }
        }
        self.relayout();
    }

    /// Oublie les pages (onglet PDF, panneau fermé longtemps).
    pub fn clear(&self) {
        let mut st = self.state.borrow_mut();
        st.typeset = None;
        st.caret = None;
        st.stack = PageStack::default();
        drop(st);
        self.count.set_text("");
        self.area.queue_draw();
    }

    /// Montre où est le curseur du texte, et y amène l'aperçu s'il est hors
    /// de vue.
    pub fn show_caret(&self, pos: Option<TextPos>) {
        let (caret, target) = {
            let mut st = self.state.borrow_mut();
            let caret = pos.and_then(|p| st.typeset.as_ref().and_then(|t| t.caret(p)));
            st.caret = caret;
            let target = caret.map(|c| (st.stack.top(c.page).floor() + c.top_pt * st.scale, c.height_pt * st.scale));
            (caret, target)
        };
        if let (Some(c), Some((y, h))) = (caret, target) {
            self.update_count(Some(c.page));
            let (top, page) = (self.adj.value(), self.adj.page_size());
            let jump = self.jump.replace(false);
            if page > 0.0 && (jump || y < top + 12.0 || y + h > top + page - 12.0) {
                let v = y - page / 3.0;
                self.adj.set_value(v.clamp(self.adj.lower(), (self.adj.upper() - page).max(self.adj.lower())));
            }
        }
        self.area.queue_draw();
    }

    fn update_count(&self, page: Option<usize>) {
        let n = self.state.borrow().stack.len();
        let text = match (page, n) {
            (_, 0) => String::new(),
            (Some(p), n) => format!("Page {} sur {n}", p + 1),
            (None, 1) => "1 page".into(),
            (None, n) => format!("{n} pages"),
        };
        self.count.set_text(&text);
    }

    /// Recalcule l'échelle (les pages remplissent la largeur du panneau) et
    /// la hauteur à faire défiler.
    fn relayout(&self) {
        let (w, h) = (self.area.width() as f64, self.area.height() as f64);
        let page = {
            let mut st = self.state.borrow_mut();
            let Some(t) = st.typeset.as_ref() else {
                drop(st);
                self.area.queue_draw();
                return;
            };
            let widest = t.tree().pages.iter().map(|p| p.width_pt).fold(0.0_f64, f64::max).max(1.0);
            let scale = if w > 0.0 { ((w - 2.0 * SIDE).max(60.0) / widest).min(PX_PER_PT) } else { 0.5 };
            let stack = t.tree().page_stack(scale, GAP);
            // Panneau élargi ou rétréci : on reste au même endroit des pages.
            let want = if st.scale > 0.0 { self.adj.value() * scale / st.scale } else { self.adj.value() };
            st.scale = scale;
            st.stack = stack;
            (st.caret.map(|c| c.page), want)
        };
        let (page, want) = page;
        let total = self.state.borrow().stack.height();
        let value = want.min((total - h).max(0.0));
        self.adj.configure(value, 0.0, total, 40.0, (h * 0.9).max(1.0), h.max(0.0));
        self.update_count(page);
        self.area.queue_draw();
    }

    fn page_x(&self, width: f64, page_w: f64) -> f64 {
        ((width - page_w) / 2.0).max(SIDE.min(width / 10.0)).floor()
    }

    fn draw(&self, cr: &gtk::cairo::Context, width: f64, height: f64) {
        let st = self.state.borrow();
        let Some(t) = st.typeset.as_ref() else { return };
        let top = self.adj.value();
        for i in st.stack.visible(top, top + height) {
            let (pw, ph) = st.stack.size(i);
            let x = self.page_x(width, pw);
            let y = st.stack.top(i).floor() - top;
            // Une ombre légère, puis la feuille.
            cr.set_source_rgba(0.0, 0.0, 0.0, 0.10);
            cr.rectangle(x - 1.0, y - 1.0, pw + 2.0, ph + 3.0);
            let _ = cr.fill();
            cr.set_source_rgb(1.0, 1.0, 1.0);
            cr.rectangle(x, y, pw, ph);
            let _ = cr.fill();
            let _ = cr.save();
            cr.translate(x, y);
            cr.rectangle(0.0, 0.0, pw, ph);
            cr.clip();
            cr.scale(st.scale, st.scale);
            t.draw_page(cr, i);
            let _ = cr.restore();
            // Le curseur du texte, en bleu, pour se repérer.
            if let Some(c) = st.caret.filter(|c| c.page == i) {
                let cy = y + c.top_pt * st.scale;
                let ch = (c.height_pt * st.scale).max(3.0);
                cr.set_source_rgba(0.21, 0.52, 0.89, 0.18);
                cr.rectangle(x, cy, pw, ch);
                let _ = cr.fill();
                cr.set_source_rgb(0.21, 0.52, 0.89);
                cr.rectangle(x + c.x_pt * st.scale - 1.0, cy, 2.0, ch);
                let _ = cr.fill();
            }
        }
    }

    /// Le point du texte sous (`x`, `y`) dans la zone de dessin.
    fn hit(&self, x: f64, y: f64) -> Option<TextPos> {
        let st = self.state.borrow();
        let t = st.typeset.as_ref()?;
        let yy = y + self.adj.value();
        let page = st.stack.nearest(yy)?;
        let (pw, _) = st.stack.size(page);
        let px = self.page_x(self.area.width() as f64, pw);
        let x_pt = (x - px) / st.scale;
        let y_pt = (yy - st.stack.top(page).floor()) / st.scale;
        t.hit_test(page, x_pt, y_pt)
    }
}
