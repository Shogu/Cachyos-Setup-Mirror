// zoom.rs — un conteneur qui agrandit ou réduit tout ce qu'il contient.
//
// La feuille (texte, images, poignées, curseur) est dessinée à l'échelle
// par une transformation d'allocation : GTK convertit aussi les clics et
// les glissés, l'édition se comporte comme à 100 %.
// SPDX-License-Identifier: GPL-3.0-or-later

use gtk4::{self as gtk, glib, gsk, prelude::*, subclass::prelude::*};

mod imp {
    use super::*;
    use std::cell::{Cell, RefCell};

    pub struct ZoomBin {
        pub child: RefCell<Option<gtk::Widget>>,
        pub zoom: Cell<f64>,
    }

    impl Default for ZoomBin {
        fn default() -> Self {
            Self { child: RefCell::new(None), zoom: Cell::new(1.0) }
        }
    }

    #[glib::object_subclass]
    impl ObjectSubclass for ZoomBin {
        const NAME: &'static str = "SamizdatZoomBin";
        type Type = super::ZoomBin;
        type ParentType = gtk::Widget;
    }

    impl ObjectImpl for ZoomBin {
        fn dispose(&self) {
            if let Some(c) = self.child.take() {
                c.unparent();
            }
        }
    }

    impl WidgetImpl for ZoomBin {
        fn request_mode(&self) -> gtk::SizeRequestMode {
            gtk::SizeRequestMode::HeightForWidth
        }

        fn measure(&self, orientation: gtk::Orientation, for_size: i32) -> (i32, i32, i32, i32) {
            let Some(child) = self.child.borrow().clone() else { return (0, 0, -1, -1) };
            let z = self.zoom.get();
            let for_child = if for_size >= 0 { (for_size as f64 / z).floor() as i32 } else { -1 };
            let (min, nat, _, _) = child.measure(orientation, for_child);
            ((min as f64 * z).ceil() as i32, (nat as f64 * z).ceil() as i32, -1, -1)
        }

        fn size_allocate(&self, width: i32, height: i32, _baseline: i32) {
            let Some(child) = self.child.borrow().clone() else { return };
            let z = self.zoom.get();
            let (w, h) = ((width as f64 / z).floor() as i32, (height as f64 / z).floor() as i32);
            let t = gsk::Transform::new().scale(z as f32, z as f32);
            child.allocate(w, h, -1, Some(t));
        }
    }
}

glib::wrapper! {
    pub struct ZoomBin(ObjectSubclass<imp::ZoomBin>) @extends gtk::Widget, @implements gtk::Accessible, gtk::Buildable, gtk::ConstraintTarget;
}

impl ZoomBin {
    pub fn new(child: &impl IsA<gtk::Widget>) -> Self {
        let bin: Self = glib::Object::new();
        child.set_parent(&bin);
        *bin.imp().child.borrow_mut() = Some(child.clone().upcast());
        bin
    }

    pub fn set_zoom(&self, z: f64) {
        self.imp().zoom.set(z.clamp(0.25, 4.0));
        self.queue_resize();
    }
}
