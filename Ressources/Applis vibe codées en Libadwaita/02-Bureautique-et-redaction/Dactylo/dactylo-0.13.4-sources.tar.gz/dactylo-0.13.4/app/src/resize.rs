// resize.rs — redimensionner une image à la souris.
//
// Au survol d'une image, un cadre et une poignée apparaissent dans son coin
// inférieur droit ; tirer la poignée change la taille (proportions
// conservées), avec un aperçu en pointillés et la taille en cm. Au lâcher,
// la nouvelle taille est enregistrée dans le modèle (une étape d'annulation).
// SPDX-License-Identifier: GPL-3.0-or-later

use std::cell::RefCell;
use std::rc::Rc;

use gtk4::{self as gtk, prelude::*};

const HANDLE: f64 = 12.0;
/// Zone sensible autour de la poignée, en pixels.
const GRAB: f64 = 16.0;

#[derive(Clone, Copy, Debug)]
struct ImageBox {
    /// Décalage de l'image dans le tampon.
    offset: i32,
    /// Position et taille à l'écran (coordonnées du widget).
    x: f64,
    y: f64,
    w: f64,
    h: f64,
}

#[derive(Default)]
struct State {
    hover: Option<ImageBox>,
    /// Glisser en cours : l'image de départ et la largeur courante.
    drag: Option<(ImageBox, f64)>,
}

/// Enveloppe la vue dans un Overlay qui dessine cadre, poignée et aperçu.
pub fn attach(view: &gtk::TextView, buf: &gtk::TextBuffer, on_done: impl Fn() + 'static) -> gtk::Overlay {
    let overlay = gtk::Overlay::new();
    overlay.set_child(Some(view));
    let area = gtk::DrawingArea::new();
    area.set_can_target(false);
    area.set_hexpand(true);
    area.set_vexpand(true);
    overlay.add_overlay(&area);

    let state: Rc<RefCell<State>> = Rc::default();
    {
        let st = state.clone();
        area.set_draw_func(move |_, cr, _, _| draw(cr, &st.borrow()));
    }

    // Survol : repérer l'image sous le pointeur.
    let motion = gtk::EventControllerMotion::new();
    {
        let (st, v, a) = (state.clone(), view.clone(), area.clone());
        motion.connect_motion(move |_, x, y| {
            if st.borrow().drag.is_some() {
                return;
            }
            let hit = image_at(&v, x, y);
            let near = hit.is_some_and(|b| near_handle(&b, x, y));
            v.set_cursor_from_name(Some(if near { "se-resize" } else { "text" }));
            let changed = st.borrow().hover.map(|b| b.offset) != hit.map(|b| b.offset);
            st.borrow_mut().hover = hit;
            if changed || hit.is_some() {
                a.queue_draw();
            }
        });
        let (st, v, a) = (state.clone(), view.clone(), area.clone());
        motion.connect_leave(move |_| {
            if st.borrow().drag.is_none() {
                st.borrow_mut().hover = None;
                v.set_cursor_from_name(Some("text"));
                a.queue_draw();
            }
        });
    }
    view.add_controller(motion);

    // Glisser depuis la poignée.
    let drag = gtk::GestureDrag::new();
    drag.set_propagation_phase(gtk::PropagationPhase::Capture);
    {
        let (st, a) = (state.clone(), area.clone());
        drag.connect_drag_begin(move |g, x, y| {
            let hover = st.borrow().hover;
            match hover {
                Some(b) if near_handle(&b, x, y) => {
                    g.set_state(gtk::EventSequenceState::Claimed);
                    st.borrow_mut().drag = Some((b, b.w));
                    a.queue_draw();
                }
                _ => {
                    g.set_state(gtk::EventSequenceState::Denied);
                }
            }
        });
        let (st, a) = (state.clone(), area.clone());
        drag.connect_drag_update(move |_, dx, dy| {
            let mut s = st.borrow_mut();
            if let Some((b, w)) = s.drag.as_mut() {
                let ratio = b.h / b.w.max(1.0);
                // La direction qui s'éloigne le plus l'emporte.
                let by_x = b.w + dx;
                let by_y = (b.h + dy) / ratio.max(0.01);
                *w = (if (by_x - b.w).abs() >= (by_y - b.w).abs() { by_x } else { by_y }).clamp(16.0, 680.0);
                drop(s);
                a.queue_draw();
            }
        });
        let (st, a, v, buf) = (state.clone(), area.clone(), view.clone(), buf.clone());
        let on_done = Rc::new(on_done);
        drag.connect_drag_end(move |_, _, _| {
            let Some((b, w)) = st.borrow_mut().drag.take() else { return };
            st.borrow_mut().hover = None;
            a.queue_draw();
            v.set_cursor_from_name(Some("text"));
            if (w - b.w).abs() < 2.0 {
                return;
            }
            let h = w * b.h / b.w.max(1.0);
            buf.place_cursor(&buf.iter_at_offset(b.offset));
            if let Some((seq, mut run)) = crate::commands::image_at_caret(&buf) {
                run.style.image_extent_emu = Some(((w * crate::commands::EMU_PER_PX) as u64, (h * crate::commands::EMU_PER_PX) as u64));
                crate::commands::replace_image(&buf, seq, run);
                on_done();
            }
        });
    }
    view.add_controller(drag);
    overlay
}

fn near_handle(b: &ImageBox, x: f64, y: f64) -> bool {
    (x - (b.x + b.w)).abs() <= GRAB && (y - (b.y + b.h)).abs() <= GRAB
}

/// L'image sous le point (x, y) du widget, avec son rectangle à l'écran :
/// on parcourt les images de la ligne sous le pointeur (et de celle juste
/// au-dessus, pour la zone de la poignée qui déborde sous l'image).
fn image_at(view: &gtk::TextView, x: f64, y: f64) -> Option<ImageBox> {
    let (_, by) = view.window_to_buffer_coords(gtk::TextWindowType::Widget, x as i32, y as i32);
    let mut seen = std::collections::HashSet::new();
    for dy in [0, -(GRAB as i32)] {
        let (line, _) = view.line_at_y(by + dy);
        if !seen.insert(line.line()) {
            continue;
        }
        let mut it = line;
        loop {
            if let Some(p) = it.paintable() {
                let (w, h) = (p.intrinsic_width() as f64, p.intrinsic_height() as f64);
                let loc = view.iter_location(&it);
                let (wx, wy) = view.buffer_to_window_coords(gtk::TextWindowType::Widget, loc.x(), loc.y() + loc.height());
                let b = ImageBox { offset: it.offset(), x: wx as f64, y: wy as f64 - h, w, h };
                if x >= b.x - 2.0 && x <= b.x + b.w + GRAB && y >= b.y - 2.0 && y <= b.y + b.h + GRAB {
                    return Some(b);
                }
            }
            if it.ends_line() || !it.forward_char() {
                break;
            }
        }
    }
    None
}

fn draw(cr: &gtk::cairo::Context, s: &State) {
    let accent = (0.21, 0.52, 0.89);
    if let Some((b, w)) = s.drag {
        let h = w * b.h / b.w.max(1.0);
        cr.set_source_rgba(accent.0, accent.1, accent.2, 0.12);
        cr.rectangle(b.x, b.y, w, h);
        let _ = cr.fill();
        // Trait blanc dessous : le pointillé reste visible sur toute image.
        cr.set_source_rgb(1.0, 1.0, 1.0);
        cr.set_line_width(4.0);
        cr.rectangle(b.x + 1.0, b.y + 1.0, w - 2.0, h - 2.0);
        let _ = cr.stroke();
        cr.set_source_rgb(accent.0, accent.1, accent.2);
        cr.set_line_width(2.0);
        cr.set_dash(&[6.0, 4.0], 0.0);
        cr.rectangle(b.x + 1.0, b.y + 1.0, w - 2.0, h - 2.0);
        let _ = cr.stroke();
        cr.set_dash(&[], 0.0);
        // Taille en centimètres.
        let cm = |px: f64| px * crate::commands::EMU_PER_PX / crate::commands::EMU_PER_CM;
        let label = format!("{:.1} × {:.1} cm", cm(w), cm(h)).replace('.', ",");
        cr.select_font_face("Sans", gtk::cairo::FontSlant::Normal, gtk::cairo::FontWeight::Bold);
        cr.set_font_size(12.0);
        if let Ok(ext) = cr.text_extents(&label) {
            let (tx, ty) = (b.x + w - ext.width() - 14.0, b.y + h - 10.0);
            cr.set_source_rgba(0.0, 0.0, 0.0, 0.7);
            rounded(cr, tx - 6.0, ty - ext.height() - 6.0, ext.width() + 12.0, ext.height() + 12.0, 4.0);
            let _ = cr.fill();
            cr.set_source_rgb(1.0, 1.0, 1.0);
            cr.move_to(tx, ty);
            let _ = cr.show_text(&label);
        }
        handle(cr, b.x + w, b.y + h, accent);
        return;
    }
    if let Some(b) = s.hover {
        cr.set_source_rgb(1.0, 1.0, 1.0);
        cr.set_line_width(3.0);
        cr.rectangle(b.x + 1.0, b.y + 1.0, b.w - 2.0, b.h - 2.0);
        let _ = cr.stroke();
        cr.set_source_rgb(accent.0, accent.1, accent.2);
        cr.set_line_width(1.5);
        cr.rectangle(b.x + 1.0, b.y + 1.0, b.w - 2.0, b.h - 2.0);
        let _ = cr.stroke();
        handle(cr, b.x + b.w, b.y + b.h, accent);
    }
}

fn handle(cr: &gtk::cairo::Context, x: f64, y: f64, accent: (f64, f64, f64)) {
    let (hx, hy) = (x - HANDLE / 2.0, y - HANDLE / 2.0);
    rounded(cr, hx, hy, HANDLE, HANDLE, 3.0);
    cr.set_source_rgb(1.0, 1.0, 1.0);
    let _ = cr.fill_preserve();
    cr.set_source_rgb(accent.0, accent.1, accent.2);
    cr.set_line_width(2.0);
    let _ = cr.stroke();
}

fn rounded(cr: &gtk::cairo::Context, x: f64, y: f64, w: f64, h: f64, r: f64) {
    use std::f64::consts::PI;
    cr.new_sub_path();
    cr.arc(x + w - r, y + r, r, -PI / 2.0, 0.0);
    cr.arc(x + w - r, y + h - r, r, 0.0, PI / 2.0);
    cr.arc(x + r, y + h - r, r, PI / 2.0, PI);
    cr.arc(x + r, y + r, r, PI, 1.5 * PI);
    cr.close_path();
}
