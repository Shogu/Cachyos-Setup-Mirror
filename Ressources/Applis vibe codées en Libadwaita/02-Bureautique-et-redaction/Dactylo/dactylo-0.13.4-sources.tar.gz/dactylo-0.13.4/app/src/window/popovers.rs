// window/popovers.rs — les popovers de la barre d'outils et le menu contextuel.
// SPDX-License-Identifier: GPL-3.0-or-later

use super::*;

impl Window {
    // ---- Construction des popovers -------------------------------------------

    pub(super) fn build_color_popover(self: &Rc<Self>, pop: &gtk::Popover) {
        let col = gtk::Box::new(gtk::Orientation::Vertical, 6);
        let auto = gtk::Button::with_label("Automatique");
        auto.add_css_class("flat");
        col.append(&auto);
        let grid = gtk::Grid::builder().row_spacing(4).column_spacing(4).build();
        for (i, (hex, name)) in PALETTE.iter().enumerate() {
            let b = gtk::Button::builder().child(&swatch(Some(hex), 22, 22)).tooltip_text(*name).build();
            b.add_css_class("flat");
            b.add_css_class("samizdat-swatch");
            let (w, hex, pop2) = (Rc::downgrade(self), hex.to_string(), pop.downgrade());
            b.connect_clicked(move |_| {
                if let Some(p) = pop2.upgrade() {
                    p.popdown();
                }
                if let Some(w) = w.upgrade() {
                    *w.color.borrow_mut() = Some(hex.clone());
                    w.color_bar.queue_draw();
                    w.doc().restore_selection();
                    crate::commands::set_color(&w.buf(), Some(hex.clone()));
                    w.after_format();
                }
            });
            grid.attach(&b, (i % 5) as i32, (i / 5) as i32, 1, 1);
        }
        col.append(&grid);
        let custom = gtk::Button::with_label("Personnalisée…");
        custom.add_css_class("flat");
        col.append(&custom);
        pop.set_child(Some(&col));
        let (w, p) = (Rc::downgrade(self), pop.downgrade());
        auto.connect_clicked(move |_| {
            if let Some(p) = p.upgrade() {
                p.popdown();
            }
            if let Some(w) = w.upgrade() {
                w.doc().restore_selection();
                crate::commands::set_color(&w.buf(), None);
                w.after_format();
            }
        });
        let (w, p) = (Rc::downgrade(self), pop.downgrade());
        custom.connect_clicked(move |_| {
            if let Some(p) = p.upgrade() {
                p.popdown();
            }
            let Some(w) = w.upgrade() else { return };
            let dialog = gtk::ColorDialog::builder().title("Couleur du texte").with_alpha(false).build();
            let initial = w.color.borrow().as_deref().map(hex_rgb).map(|(r, g, b)| gtk::gdk::RGBA::new(r as f32, g as f32, b as f32, 1.0));
            let w2 = w.clone();
            dialog.choose_rgba(Some(&w.win), initial.as_ref(), gio::Cancellable::NONE, move |res| {
                if let Ok(c) = res {
                    let hex = format!("{:02X}{:02X}{:02X}", (c.red() * 255.0).round() as u8, (c.green() * 255.0).round() as u8, (c.blue() * 255.0).round() as u8);
                    *w2.color.borrow_mut() = Some(hex.clone());
                    w2.color_bar.queue_draw();
                    w2.doc().restore_selection();
                    crate::commands::set_color(&w2.buf(), Some(hex));
                    w2.after_format();
                }
            });
        });
    }

    pub(super) fn build_highlight_popover(self: &Rc<Self>, pop: &gtk::Popover) {
        let col = gtk::Box::new(gtk::Orientation::Vertical, 6);
        let grid = gtk::Grid::builder().row_spacing(4).column_spacing(4).build();
        for (i, (hex, name)) in HIGHLIGHTS.iter().enumerate() {
            let b = gtk::Button::builder().child(&swatch(Some(hex), 24, 24)).tooltip_text(*name).build();
            b.add_css_class("flat");
            b.add_css_class("samizdat-swatch");
            let (w, hex, pop2) = (Rc::downgrade(self), hex.to_string(), pop.downgrade());
            b.connect_clicked(move |_| {
                if let Some(p) = pop2.upgrade() {
                    p.popdown();
                }
                if let Some(w) = w.upgrade() {
                    *w.highlight.borrow_mut() = hex.clone();
                    w.set_highlight_swatch();
                    w.doc().restore_selection();
                    crate::commands::set_highlight(&w.buf(), Some(&hex));
                    w.after_format();
                }
            });
            grid.attach(&b, (i % 3) as i32, (i / 3) as i32, 1, 1);
        }
        col.append(&grid);
        let none = gtk::Button::with_label("Aucun surlignage");
        none.add_css_class("flat");
        col.append(&none);
        pop.set_child(Some(&col));
        let (w, p) = (Rc::downgrade(self), pop.downgrade());
        none.connect_clicked(move |_| {
            if let Some(p) = p.upgrade() {
                p.popdown();
            }
            if let Some(w) = w.upgrade() {
                w.doc().restore_selection();
                crate::commands::set_highlight(&w.buf(), None);
                w.after_format();
            }
        });
    }

    pub(super) fn set_highlight_swatch(&self) {
        let hex = self.highlight.borrow().clone();
        self.hl_css.load_from_string(&format!("label.samizdat-highlight-label {{ background-color: #{hex}; }}"));
    }

    pub(super) fn build_shapes_popover(self: &Rc<Self>, pop: &gtk::Popover) {
        let chosen: Rc<RefCell<String>> = Rc::new(RefCell::new(SHAPE_COLORS[0].to_string()));
        let col = gtk::Box::new(gtk::Orientation::Vertical, 8);
        let grid = gtk::Grid::builder().row_spacing(4).column_spacing(4).build();
        let previews: Rc<RefCell<Vec<gtk::DrawingArea>>> = Rc::default();
        for (i, (shape, name)) in crate::shapes::SHAPES.iter().enumerate() {
            let area = gtk::DrawingArea::builder().content_width(40).content_height(28).build();
            let (shape, c) = (*shape, chosen.clone());
            area.set_draw_func(move |_, cr, w, h| {
                let (aw, ah) = shape.aspect();
                let s = ((w as f64 - 4.0) / aw).min((h as f64 - 4.0) / ah);
                cr.translate((w as f64 - aw * s) / 2.0, (h as f64 - ah * s) / 2.0);
                crate::shapes::paint(cr, shape, &c.borrow(), aw * s, ah * s);
            });
            previews.borrow_mut().push(area.clone());
            let b = gtk::Button::builder().child(&area).tooltip_text(*name).build();
            b.add_css_class("flat");
            let (w, c, pop2) = (Rc::downgrade(self), chosen.clone(), pop.downgrade());
            b.connect_clicked(move |_| {
                if let Some(p) = pop2.upgrade() {
                    p.popdown();
                }
                let (w, c) = (w.clone(), c.clone());
                glib::idle_add_local_once(move || {
                let Some(w) = w.upgrade() else { return };
                let width = match shape {
                    crate::shapes::Shape::ArrowLeft | crate::shapes::Shape::ArrowRight | crate::shapes::Shape::Rectangle => 5.0,
                    _ => 3.0,
                };
                match crate::shapes::render_png(shape, &c.borrow()).and_then(|p| crate::commands::insert_image_sized(&w.buf(), &p, Some(width))) {
                    Ok(()) => w.after_format(),
                    Err(e) => w.error("Impossible d'insérer la forme", &e),
                }
                });
            });
            grid.attach(&b, (i % 3) as i32, (i / 3) as i32, 1, 1);
        }
        let colors = gtk::Box::new(gtk::Orientation::Horizontal, 2);
        for hex in SHAPE_COLORS {
            let tip = if hex == crate::shapes::TRANSPARENT { "Transparent : le contour seul" } else { "Couleur de la forme" };
            let b = gtk::Button::builder().child(&swatch(Some(hex), 18, 18)).tooltip_text(tip).build();
            b.add_css_class("flat");
            b.add_css_class("samizdat-swatch");
            let (c, previews) = (chosen.clone(), previews.clone());
            b.connect_clicked(move |_| {
                *c.borrow_mut() = hex.to_string();
                for p in previews.borrow().iter() {
                    p.queue_draw();
                }
            });
            colors.append(&b);
        }
        let label = gtk::Label::new(Some("Couleur"));
        label.add_css_class("dim-label");
        label.set_xalign(0.0);
        col.append(&grid);
        col.append(&label);
        col.append(&colors);
        pop.set_child(Some(&col));
    }

    /// Le bouton Cartouche : six cartouches nommés à un clic, les autres
    /// allures dans « Personnaliser… », et de quoi retirer le cartouche du
    /// curseur.
    pub(super) fn build_cartouche_popover(self: &Rc<Self>, pop: &gtk::Popover) {
        use letters_core::{Cartouche, CartoucheLine};
        let col = gtk::Box::new(gtk::Orientation::Vertical, 8);
        let title = gtk::Label::builder().label("Cartouche").xalign(0.0).build();
        title.add_css_class("heading");
        let hint = gtk::Label::builder()
            .label("Encadre la sélection, ou change le cartouche\noù est le curseur. Entrée : nouvelle ligne ;\nEntrée sur une ligne vide : en sortir.")
            .xalign(0.0)
            .build();
        hint.add_css_class("dim-label");
        hint.add_css_class("caption");
        col.append(&title);
        col.append(&hint);
        let grid = gtk::Grid::builder().row_spacing(4).column_spacing(6).build();
        let buttons: Rc<RefCell<Vec<(Cartouche, gtk::Button)>>> = Rc::default();
        let apply = {
            let (w, pop2) = (Rc::downgrade(self), pop.downgrade());
            Rc::new(move |look: Cartouche| {
                if let Some(p) = pop2.upgrade() {
                    p.popdown();
                }
                // Après la fermeture du menu : modifier le texte pendant
                // qu'il se ferme laissait la page sans dessin.
                let w = w.clone();
                glib::idle_add_local_once(move || {
                    if let Some(w) = w.upgrade() {
                        w.apply_cartouche(look);
                    }
                });
            })
        };
        for (i, (name, tip, look)) in crate::commands::CARTOUCHES.iter().enumerate() {
            let look = *look;
            let area = gtk::DrawingArea::builder().content_width(76).content_height(46).build();
            area.set_draw_func(move |_, cr, w, h| paint_cartouche(cr, look, w as f64, h as f64));
            let label = gtk::Label::new(Some(name));
            label.add_css_class("caption");
            let b = gtk::Box::new(gtk::Orientation::Vertical, 2);
            b.append(&area);
            b.append(&label);
            let btn = gtk::Button::builder().child(&b).tooltip_text(*tip).build();
            btn.add_css_class("flat");
            btn.add_css_class("samizdat-cartouche");
            let apply = apply.clone();
            btn.connect_clicked(move |_| apply(look));
            buttons.borrow_mut().push((look, btn.clone()));
            grid.attach(&btn, (i % 3) as i32, (i / 3) as i32, 1, 1);
        }
        col.append(&grid);

        // Personnaliser : coins, trait, fond.
        let custom = Rc::new(std::cell::Cell::new(Cartouche::default()));
        let expander = gtk::Expander::new(Some("Personnaliser…"));
        let ebox = gtk::Box::new(gtk::Orientation::Vertical, 6);
        ebox.set_margin_top(6);
        let preview = gtk::DrawingArea::builder().content_width(120).content_height(56).halign(gtk::Align::Center).build();
        {
            let c = custom.clone();
            preview.set_draw_func(move |_, cr, w, h| paint_cartouche(cr, c.get(), w as f64, h as f64));
        }
        let choice_row = |label: &str, items: &[&str]| -> (gtk::Box, Vec<gtk::ToggleButton>) {
            let row = gtk::Box::new(gtk::Orientation::Horizontal, 8);
            let l = gtk::Label::builder().label(label).xalign(0.0).width_chars(6).build();
            l.add_css_class("dim-label");
            let linked = gtk::Box::new(gtk::Orientation::Horizontal, 0);
            linked.add_css_class("linked");
            let mut toggles: Vec<gtk::ToggleButton> = Vec::new();
            for it in items {
                let t = gtk::ToggleButton::with_label(it);
                if let Some(first) = toggles.first() {
                    t.set_group(Some(first));
                }
                linked.append(&t);
                toggles.push(t);
            }
            row.append(&l);
            row.append(&linked);
            (row, toggles)
        };
        let (r1, corners) = choice_row("Coins", &["Arrondis", "Carrés"]);
        let (r2, lines) = choice_row("Trait", &["Aucun", "Fin", "Moyen", "Épais"]);
        let (r3, fills) = choice_row("Fond", &["Gris clair", "Blanc"]);
        let line_of = |i: usize| [CartoucheLine::None, CartoucheLine::Thin, CartoucheLine::Medium, CartoucheLine::Thick][i];
        let sync = {
            let (corners, lines, fills, custom, preview) = (corners.clone(), lines.clone(), fills.clone(), custom.clone(), preview.clone());
            Rc::new(move || {
                let li = lines.iter().position(|t| t.is_active()).unwrap_or(1);
                custom.set(Cartouche { square: corners[1].is_active(), line: line_of(li), white: fills[1].is_active() });
                preview.queue_draw();
            })
        };
        for t in corners.iter().chain(lines.iter()).chain(fills.iter()) {
            let sync = sync.clone();
            t.connect_toggled(move |t| {
                if t.is_active() {
                    sync();
                }
            });
        }
        let set_custom = {
            let (corners, lines, fills) = (corners.clone(), lines.clone(), fills.clone());
            move |look: Cartouche| {
                corners[usize::from(look.square)].set_active(true);
                let li = [CartoucheLine::None, CartoucheLine::Thin, CartoucheLine::Medium, CartoucheLine::Thick].iter().position(|l| *l == look.line).unwrap_or(1);
                lines[li].set_active(true);
                fills[usize::from(look.white)].set_active(true);
            }
        };
        set_custom(Cartouche::default());
        let apply_custom = gtk::Button::with_label("Appliquer");
        apply_custom.add_css_class("suggested-action");
        apply_custom.set_halign(gtk::Align::End);
        {
            let (apply, custom) = (apply.clone(), custom.clone());
            apply_custom.connect_clicked(move |_| apply(custom.get()));
        }
        ebox.append(&preview);
        ebox.append(&r1);
        ebox.append(&r2);
        ebox.append(&r3);
        ebox.append(&apply_custom);
        expander.set_child(Some(&ebox));
        col.append(&expander);

        let remove = gtk::Button::with_label("Retirer le cartouche");
        remove.add_css_class("flat");
        let (w, pop2) = (Rc::downgrade(self), pop.downgrade());
        remove.connect_clicked(move |_| {
            if let Some(p) = pop2.upgrade() {
                p.popdown();
            }
            let w = w.clone();
            glib::idle_add_local_once(move || {
                if let Some(w) = w.upgrade() {
                    if crate::commands::remove_cartouche(&w.buf()) {
                        w.after_format();
                    }
                }
            });
        });
        col.append(&remove);
        let (w, r) = (Rc::downgrade(self), remove.clone());
        pop.connect_show(move |_| {
            let Some(w) = w.upgrade() else { return };
            let here = crate::commands::cartouche_at_caret(&w.buf());
            r.set_visible(here.is_some());
            for (look, b) in buttons.borrow().iter() {
                if Some(*look) == here {
                    b.add_css_class("samizdat-current");
                } else {
                    b.remove_css_class("samizdat-current");
                }
            }
            if let Some(look) = here {
                set_custom(look);
                expander.set_expanded(!crate::commands::CARTOUCHES.iter().any(|(_, _, l)| *l == look));
            }
        });
        pop.set_child(Some(&col));
    }

    /// Met en cartouche (ou change l'allure du cartouche du curseur).
    pub(super) fn apply_cartouche(&self, look: letters_core::Cartouche) {
        match crate::commands::cartouche(&self.buf(), look) {
            crate::commands::CartoucheDone::InTable => self.toast("Le curseur est dans un tableau : placez-le dans le texte"),
            _ => self.after_format(),
        }
    }

    pub(super) fn build_columns_popover(pop: &gtk::Popover) -> Vec<gtk::ToggleButton> {
        let b = gtk::Box::new(gtk::Orientation::Horizontal, 0);
        b.add_css_class("linked");
        let mut out = Vec::new();
        for n in 1..=3 {
            let t = gtk::ToggleButton::builder().label(match n {
                1 => "1 colonne",
                2 => "2 colonnes",
                _ => "3 colonnes",
            }).build();
            if let Some(first) = out.first() {
                t.set_group(Some(first));
            }
            b.append(&t);
            out.push(t);
        }
        let hint = gtk::Label::builder().label("S'applique à tout le document.\nVisible dans l'aperçu et le PDF.").wrap(true).xalign(0.0).build();
        hint.add_css_class("dim-label");
        hint.add_css_class("caption");
        let col = gtk::Box::new(gtk::Orientation::Vertical, 8);
        col.append(&b);
        col.append(&hint);
        pop.set_child(Some(&col));
        out
    }

    pub(super) fn connect_columns(self: &Rc<Self>) {
        for (i, t) in self.columns_btns.iter().enumerate() {
            let w = Rc::downgrade(self);
            t.connect_toggled(move |t| {
                let Some(w) = w.upgrade() else { return };
                if t.is_active() && !w.syncing.get() && crate::commands::columns(&w.buf()) != (i + 1) as u8 {
                    crate::commands::set_columns(&w.buf(), (i + 1) as u8);
                    w.toast(&match i {
                        0 => "Document sur une colonne".to_string(),
                        n => format!("Document sur {} colonnes (visible dans l'aperçu)", n + 1),
                    });
                }
            });
        }
    }

    pub(super) fn build_zoom_popover(self: &Rc<Self>, pop: &gtk::Popover) {
        let minus = gtk::Button::from_icon_name("list-remove-symbolic");
        let plus = gtk::Button::from_icon_name("list-add-symbolic");
        minus.set_tooltip_text(Some("Réduire"));
        plus.set_tooltip_text(Some("Agrandir"));
        for b in [&minus, &plus] {
            b.add_css_class("flat");
            b.add_css_class("circular");
        }
        let row = gtk::Box::new(gtk::Orientation::Horizontal, 6);
        row.append(&minus);
        row.append(&self.zoom_label);
        row.append(&plus);
        let reset = gtk::Button::with_label("Taille réelle");
        reset.add_css_class("flat");
        let col = gtk::Box::new(gtk::Orientation::Vertical, 6);
        col.append(&row);
        col.append(&reset);
        pop.set_child(Some(&col));
        let w = Rc::downgrade(self);
        minus.connect_clicked(move |_| {
            if let Some(w) = w.upgrade() {
                w.zoom_step(false);
            }
        });
        let w = Rc::downgrade(self);
        plus.connect_clicked(move |_| {
            if let Some(w) = w.upgrade() {
                w.zoom_step(true);
            }
        });
        let w = Rc::downgrade(self);
        reset.connect_clicked(move |_| {
            if let Some(w) = w.upgrade() {
                w.set_zoom(1.0);
            }
        });
    }

    /// Menu contextuel du texte : image, tableau (et orthographe, ajoutée
    /// au clic droit sur un mot souligné).
    pub(super) fn build_context_menu(&self) {
        let img = gio::Menu::new();
        img.append(Some("Taille et recadrage de l'image…"), Some("win.image-properties"));
        self.base_menu.append_section(None, &img);
        let t = gio::Menu::new();
        t.append(Some("Modifier le tableau…"), Some("win.edit-table"));
        t.append(Some("Ligne au-dessus"), Some("win.table-row-above"));
        t.append(Some("Ligne en dessous"), Some("win.table-row-below"));
        t.append(Some("Colonne à gauche"), Some("win.table-col-left"));
        t.append(Some("Colonne à droite"), Some("win.table-col-right"));
        t.append(Some("Supprimer la ligne"), Some("win.table-delete-row"));
        t.append(Some("Supprimer la colonne"), Some("win.table-delete-col"));
        let sub = gio::Menu::new();
        sub.append_submenu(Some("Tableau"), &t);
        self.base_menu.append_section(None, &sub);
        self.view().set_extra_menu(Some(&self.base_menu));
    }
}

/// L'aperçu d'un cartouche : une page blanche, le cadre et trois lignes.
fn paint_cartouche(cr: &gtk::cairo::Context, look: letters_core::Cartouche, w: f64, h: f64) {
    cr.set_source_rgb(1.0, 1.0, 1.0);
    cr.rectangle(0.0, 0.0, w, h);
    let _ = cr.fill();
    let (x, y, bw, bh) = (5.0, 5.0, w - 10.0, h - 10.0);
    if look.square {
        cr.rectangle(x, y, bw, bh);
    } else {
        let r = 6.0;
        let pi = std::f64::consts::PI;
        cr.new_sub_path();
        cr.arc(x + bw - r, y + r, r, -pi / 2.0, 0.0);
        cr.arc(x + bw - r, y + bh - r, r, 0.0, pi / 2.0);
        cr.arc(x + r, y + bh - r, r, pi / 2.0, pi);
        cr.arc(x + r, y + r, r, pi, 3.0 * pi / 2.0);
        cr.close_path();
    }
    let (fr, fg, fb) = if look.white { (1.0, 1.0, 1.0) } else { (0.93, 0.925, 0.92) };
    cr.set_source_rgb(fr, fg, fb);
    let lw = look.line_pt();
    if lw > 0.0 {
        let _ = cr.fill_preserve();
        cr.set_source_rgb(0.37, 0.36, 0.39);
        cr.set_line_width(lw * 1.1);
        let _ = cr.stroke();
    } else if look.white {
        // Ni trait ni fond : un pointillé léger, pour voir la place.
        let _ = cr.fill_preserve();
        cr.set_source_rgba(0.37, 0.36, 0.39, 0.45);
        cr.set_line_width(0.8);
        cr.set_dash(&[2.0, 2.0], 0.0);
        let _ = cr.stroke();
        cr.set_dash(&[], 0.0);
    } else {
        let _ = cr.fill();
    }
    cr.set_source_rgb(0.6, 0.59, 0.62);
    for (i, frac) in [0.8, 0.9, 0.55].iter().enumerate() {
        let ly = y + 6.0 + i as f64 * 6.0;
        cr.rectangle(x + 7.0, ly, (bw - 14.0) * frac, 2.0);
    }
    let _ = cr.fill();
}
