// search.rs — barre Rechercher / Remplacer (Ctrl+F, Ctrl+H).
// SPDX-License-Identifier: GPL-3.0-or-later

use std::cell::{Cell, RefCell};
use std::rc::Rc;

use gtk4::{self as gtk, glib, prelude::*};

use crate::commands;

pub struct SearchBar {
    pub widget: gtk::Revealer,
    entry: gtk::SearchEntry,
    replace_entry: gtk::Entry,
    replace_row: gtk::Box,
    count: gtk::Label,
    case: gtk::ToggleButton,
    /// Le document de l'onglet affiché (`attach`).
    target: RefCell<(gtk::TextBuffer, gtk::TextView)>,
    matches: RefCell<Vec<(i32, i32)>>,
    current: Cell<usize>,
    pending: Cell<bool>,
}

impl SearchBar {
    pub fn new(buf: &gtk::TextBuffer, view: &gtk::TextView, toast: impl Fn(&str) + 'static) -> Rc<Self> {
        // (`buf` et `view` : le premier document ; `attach` en change.)
        let entry = gtk::SearchEntry::builder().placeholder_text("Rechercher").hexpand(true).build();
        let prev = gtk::Button::builder().icon_name("go-up-symbolic").tooltip_text("Précédent (Maj+Entrée)").build();
        let next = gtk::Button::builder().icon_name("go-down-symbolic").tooltip_text("Suivant (Entrée)").build();
        let count = gtk::Label::builder().width_chars(8).build();
        count.add_css_class("dim-label");
        count.add_css_class("numeric");
        let case = gtk::ToggleButton::builder().label("Aa").tooltip_text("Respecter la casse").build();
        let toggle_replace = gtk::ToggleButton::builder().icon_name("edit-find-replace-symbolic").tooltip_text("Remplacer (Ctrl+H)").build();
        let close = gtk::Button::builder().icon_name("window-close-symbolic").tooltip_text("Fermer (Échap)").build();
        for b in [&prev, &next, &close] {
            b.add_css_class("flat");
        }
        case.add_css_class("flat");
        toggle_replace.add_css_class("flat");
        let nav = gtk::Box::new(gtk::Orientation::Horizontal, 0);
        nav.add_css_class("linked");
        nav.append(&prev);
        nav.append(&next);

        let row1 = gtk::Box::new(gtk::Orientation::Horizontal, 6);
        row1.append(&entry);
        row1.append(&count);
        row1.append(&nav);
        row1.append(&case);
        row1.append(&toggle_replace);
        row1.append(&close);

        let replace_entry = gtk::Entry::builder().placeholder_text("Remplacer par").hexpand(true).build();
        let one = gtk::Button::with_label("Remplacer");
        let all = gtk::Button::with_label("Tout remplacer");
        let replace_row = gtk::Box::new(gtk::Orientation::Horizontal, 6);
        replace_row.append(&replace_entry);
        replace_row.append(&one);
        replace_row.append(&all);
        replace_row.set_visible(false);

        let col = gtk::Box::new(gtk::Orientation::Vertical, 6);
        col.append(&row1);
        col.append(&replace_row);
        let clamp = libadwaita::Clamp::builder().maximum_size(720).child(&col).build();
        clamp.set_margin_top(6);
        clamp.set_margin_bottom(6);
        clamp.set_margin_start(12);
        clamp.set_margin_end(12);
        let widget = gtk::Revealer::builder().child(&clamp).transition_type(gtk::RevealerTransitionType::SlideDown).build();

        let this = Rc::new(Self {
            widget,
            entry: entry.clone(),
            replace_entry: replace_entry.clone(),
            replace_row: replace_row.clone(),
            count,
            case: case.clone(),
            target: RefCell::new((buf.clone(), view.clone())),
            matches: RefCell::new(Vec::new()),
            current: Cell::new(0),
            pending: Cell::new(false),
        });

        let w = Rc::downgrade(&this);
        entry.connect_search_changed(move |_| {
            if let Some(w) = w.upgrade() {
                w.refresh(true);
            }
        });
        let w = Rc::downgrade(&this);
        case.connect_toggled(move |_| {
            if let Some(w) = w.upgrade() {
                w.refresh(true);
            }
        });
        let w = Rc::downgrade(&this);
        entry.connect_activate(move |_| {
            if let Some(w) = w.upgrade() {
                w.step(true);
            }
        });
        let w = Rc::downgrade(&this);
        entry.connect_next_match(move |_| {
            if let Some(w) = w.upgrade() {
                w.step(true);
            }
        });
        let w = Rc::downgrade(&this);
        entry.connect_previous_match(move |_| {
            if let Some(w) = w.upgrade() {
                w.step(false);
            }
        });
        let w = Rc::downgrade(&this);
        entry.connect_stop_search(move |_| {
            if let Some(w) = w.upgrade() {
                w.hide();
            }
        });
        let w = Rc::downgrade(&this);
        next.connect_clicked(move |_| {
            if let Some(w) = w.upgrade() {
                w.step(true);
            }
        });
        let w = Rc::downgrade(&this);
        prev.connect_clicked(move |_| {
            if let Some(w) = w.upgrade() {
                w.step(false);
            }
        });
        let w = Rc::downgrade(&this);
        close.connect_clicked(move |_| {
            if let Some(w) = w.upgrade() {
                w.hide();
            }
        });
        let r = replace_row.clone();
        toggle_replace.connect_toggled(move |t| r.set_visible(t.is_active()));
        {
            let rr = replace_row.clone();
            let tr = toggle_replace.clone();
            rr.connect_visible_notify(move |r| tr.set_active(r.is_visible()));
        }
        let toast = Rc::new(toast);
        let w = Rc::downgrade(&this);
        one.connect_clicked(move |_| {
            if let Some(w) = w.upgrade() {
                w.replace_current();
            }
        });
        let w = Rc::downgrade(&this);
        replace_entry.connect_activate(move |_| {
            if let Some(w) = w.upgrade() {
                w.replace_current();
            }
        });
        let (w, t) = (Rc::downgrade(&this), toast.clone());
        all.connect_clicked(move |_| {
            if let Some(w) = w.upgrade() {
                let n = w.replace_all();
                t(&match n {
                    0 => "Aucune occurrence".to_string(),
                    1 => "1 occurrence remplacée".to_string(),
                    n => format!("{n} occurrences remplacées"),
                });
            }
        });
        this
    }

    fn buf(&self) -> gtk::TextBuffer {
        self.target.borrow().0.clone()
    }

    fn view(&self) -> gtk::TextView {
        self.target.borrow().1.clone()
    }

    /// Recherche dans un autre document (changement d'onglet).
    pub fn attach(&self, buf: &gtk::TextBuffer, view: &gtk::TextView) {
        if &self.buf() == buf {
            return;
        }
        self.clear_tags();
        *self.target.borrow_mut() = (buf.clone(), view.clone());
        if self.widget.reveals_child() {
            self.refresh(false);
        }
    }

    /// Le texte du document a changé : on recherche à nouveau (au prochain
    /// temps mort).
    pub fn text_changed(self: &Rc<Self>) {
        if !self.widget.reveals_child() || self.pending.replace(true) {
            return;
        }
        let w = Rc::downgrade(self);
        glib::timeout_add_local_once(std::time::Duration::from_millis(150), move || {
            if let Some(w) = w.upgrade() {
                w.pending.set(false);
                w.refresh(false);
            }
        });
    }

    pub fn show(&self, replace: bool) {
        // Le texte sélectionné devient la recherche.
        if let Some((a, b)) = self.buf().selection_bounds() {
            let t = self.buf().text(&a, &b, false);
            if !t.contains('\n') && !t.is_empty() {
                self.entry.set_text(&t);
            }
        }
        self.widget.set_reveal_child(true);
        if replace {
            self.replace_row.set_visible(true);
        }
        self.entry.grab_focus();
        self.entry.select_region(0, -1);
        self.refresh(true);
    }

    pub fn hide(&self) {
        self.widget.set_reveal_child(false);
        self.clear_tags();
        self.view().grab_focus();
    }

    fn clear_tags(&self) {
        let modified = self.buf().is_modified();
        let (s, e) = self.buf().bounds();
        self.buf().remove_tag_by_name("search-match", &s, &e);
        self.buf().remove_tag_by_name("search-current", &s, &e);
        self.buf().set_modified(modified);
    }

    /// Recherche à nouveau et surligne. `jump` : sélectionne l'occurrence
    /// la plus proche du curseur.
    fn refresh(&self, jump: bool) {
        self.clear_tags();
        let found = commands::find_all(&self.buf(), &self.entry.text(), self.case.is_active());
        let modified = self.buf().is_modified();
        for (a, b) in &found {
            self.buf().apply_tag_by_name("search-match", &self.buf().iter_at_offset(*a), &self.buf().iter_at_offset(*b));
        }
        self.buf().set_modified(modified);
        let caret = self.buf().iter_at_mark(&self.buf().get_insert()).offset();
        let near = found.iter().position(|(a, _)| *a >= caret).unwrap_or(0);
        *self.matches.borrow_mut() = found;
        if jump {
            self.current.set(near);
            self.select_current(false);
        } else {
            self.current.set(self.current.get().min(self.matches.borrow().len().saturating_sub(1)));
            self.mark_current();
        }
        self.update_count();
    }

    fn update_count(&self) {
        let n = self.matches.borrow().len();
        if self.entry.text().is_empty() {
            self.count.set_text("");
            self.entry.remove_css_class("error");
        } else if n == 0 {
            self.count.set_text("Aucun");
            self.entry.add_css_class("error");
        } else {
            self.count.set_text(&format!("{} / {n}", self.current.get() + 1));
            self.entry.remove_css_class("error");
        }
    }

    fn mark_current(&self) {
        let modified = self.buf().is_modified();
        let (s, e) = self.buf().bounds();
        self.buf().remove_tag_by_name("search-current", &s, &e);
        if let Some((a, b)) = self.matches.borrow().get(self.current.get()) {
            self.buf().apply_tag_by_name("search-current", &self.buf().iter_at_offset(*a), &self.buf().iter_at_offset(*b));
        }
        self.buf().set_modified(modified);
    }

    fn select_current(&self, focus_view: bool) {
        self.mark_current();
        let m = self.matches.borrow();
        if let Some((a, b)) = m.get(self.current.get()) {
            let (s, e) = (self.buf().iter_at_offset(*a), self.buf().iter_at_offset(*b));
            self.buf().select_range(&s, &e);
            crate::editor::scroll_to_iter(&self.view(), &s, 0.3);
        }
        if focus_view {
            self.view().grab_focus();
        }
    }

    fn step(&self, forward: bool) {
        let n = self.matches.borrow().len();
        if n == 0 {
            return;
        }
        let c = self.current.get();
        self.current.set(if forward { (c + 1) % n } else { (c + n - 1) % n });
        self.select_current(false);
        self.update_count();
    }

    fn replace_current(&self) {
        let cur = self.matches.borrow().get(self.current.get()).copied();
        if let Some(r) = cur {
            commands::replace_ranges(&self.buf(), &[r], &self.replace_entry.text());
            self.refresh(false);
            // Passer à l'occurrence suivante (même index, la liste a raccourci).
            self.select_current(false);
            self.update_count();
        }
    }

    fn replace_all(&self) -> usize {
        let all = self.matches.borrow().clone();
        let n = commands::replace_ranges(&self.buf(), &all, &self.replace_entry.text());
        self.refresh(false);
        n
    }
}
