// window/doc.rs — un document ouvert dans un onglet.
//
// Chaque onglet a son tampon, sa vue, son zoom, son chemin, son correcteur
// et sa copie de secours. Un onglet peut passer d'une fenêtre à l'autre
// (glisser-déposer) : le document retrouve sa fenêtre par `owner`, mis à
// jour quand l'onglet arrive dans une fenêtre.
// SPDX-License-Identifier: GPL-3.0-or-later

use std::rc::Weak;

use super::*;

pub struct Doc {
    pub buf: gtk::TextBuffer,
    pub view: gtk::TextView,
    /// Le contenu de l'onglet.
    pub root: gtk::Widget,
    pub clamp: adw::Clamp,
    pub zoom_bin: crate::zoom::ZoomBin,
    pub zoom: Cell<f64>,
    pub path: RefCell<Option<PathBuf>>,
    /// Identifiant de la copie de secours.
    pub id: u64,
    pub spell: Rc<crate::spell::Checker>,
    pub base_css: gtk::CssProvider,
    /// La police de base vient des préférences (le document n'en a pas).
    pub base_from_prefs: Cell<bool>,
    /// Un PDF en lecture seule.
    pub pdf: Option<Rc<crate::pdfview::PdfView>>,
    pub owner: RefCell<Weak<Window>>,
    decorate_pending: Cell<bool>,
    /// La dernière sélection faite dans la page. Quand la taille ou la police
    /// prend le focus, GTK efface la sélection du texte (la « sélection
    /// primaire » passe au champ) : on la retrouve ici pour l'appliquer.
    pub kept_selection: Rc<Cell<Option<(i32, i32)>>>,
    /// Mode concentration, ligne au milieu : le défilement est au centrage,
    /// la page ne doit pas être retenue en place.
    pub centered: Rc<Cell<bool>>,
    /// Les lignes repères de la règle, par-dessus la page.
    pub guides_area: gtk::DrawingArea,
}

thread_local! {
    /// Tous les documents ouverts, toutes fenêtres confondues.
    static DOCS: RefCell<Vec<Rc<Doc>>> = const { RefCell::new(Vec::new()) };
}

const DOC_KEY: &str = "samizdat-doc";

impl Doc {
    /// Un document texte vide.
    pub fn text() -> Rc<Self> {
        let buf = editor::new_buffer();
        let view = gtk::TextView::builder()
            .buffer(&buf)
            .wrap_mode(gtk::WrapMode::WordChar)
            .top_margin(56)
            .bottom_margin(56)
            .left_margin(crate::bridge::EDITOR_LEFT_MARGIN_PX)
            .right_margin(crate::bridge::EDITOR_LEFT_MARGIN_PX)
            .pixels_below_lines(6)
            .vexpand(true)
            .build();
        view.add_css_class("samizdat-page");
        view.update_property(&[gtk::accessible::Property::Label("Document")]);
        // La page : une feuille centrée sur un fond gris.
        let page = {
            let v = view.clone();
            crate::resize::attach(&view, &buf, move || {
                v.grab_focus();
            })
        };
        // Les lignes repères de la règle, sur toute la hauteur de la page.
        let guides_area = gtk::DrawingArea::builder().can_target(false).hexpand(true).vexpand(true).build();
        guides_area.set_draw_func(|_, cr, _, h| crate::ruler::draw_guides(cr, crate::bridge::EDITOR_LEFT_MARGIN_PX as f64, h as f64));
        page.add_overlay(&guides_area);
        // Le zoom agrandit toute la feuille ; au-delà de 100 %, elle garde sa
        // largeur et l'onglet défile de côté.
        let zoom_bin = crate::zoom::ZoomBin::new(&page);
        let prefs = crate::prefs::get();
        zoom_bin.set_zoom(prefs.default_zoom);
        let clamp = adw::Clamp::builder().maximum_size(PAGE_WIDTH as i32).tightening_threshold(600).child(&zoom_bin).build();
        clamp.set_margin_top(24);
        clamp.set_margin_bottom(24);
        clamp.set_margin_start(12);
        clamp.set_margin_end(12);
        // Le cadre de défilement ne doit pas « montrer » la page quand elle
        // reprend le focus (après la barre d'outils) : il remontait tout en
        // haut de la feuille, et le clic en cours devenait une sélection
        // glissée sur plusieurs lignes. Le curseur est suivi à part.
        let viewport = gtk::Viewport::builder().scroll_to_focus(false).child(&clamp).build();
        let scroller = gtk::ScrolledWindow::builder().hscrollbar_policy(gtk::PolicyType::Automatic).child(&viewport).build();
        scroller.add_css_class("samizdat-desk");
        let base_css = gtk::CssProvider::new();
        #[allow(deprecated)]
        view.style_context().add_provider(&base_css, gtk::STYLE_PROVIDER_PRIORITY_APPLICATION + 2);
        let doc = Self::register(Self {
            buf,
            view,
            root: scroller.clone().upcast(),
            clamp,
            zoom_bin,
            zoom: Cell::new(prefs.default_zoom),
            path: RefCell::new(None),
            id: next_doc_id(),
            spell: crate::spell::Checker::new(),
            base_css,
            base_from_prefs: Cell::new(false),
            pdf: None,
            owner: RefCell::new(Weak::new()),
            decorate_pending: Cell::new(false),
            kept_selection: Rc::new(Cell::new(None)),
            centered: Rc::new(Cell::new(false)),
            guides_area: guides_area.clone(),
        });
        doc.spell.enabled.set(prefs.spell_on_open);
        doc.spell.track(&doc.buf);
        doc.keep_selection();
        doc.follow_caret();
        doc.keep_scroll(&scroller);
        super::tabs::wire_doc(&doc);
        doc.adopt_base_font(&Default::default());
        doc.start_autosave();
        doc
    }

    /// Quand le modèle réécrit des lignes (image, tableau, légende…), la
    /// vue ne doit pas sauter en haut du document : pendant un court instant
    /// après chaque modification, la position est rétablie si elle a fui.
    fn keep_scroll(&self, scroller: &gtk::ScrolledWindow) {
        let adj = scroller.vadjustment();
        let pin: Rc<Cell<Option<(f64, std::time::Instant)>>> = Rc::default();
        {
            let (pin, adj) = (pin.clone(), adj.clone());
            self.buf.connect_changed(move |_| {
                let now = std::time::Instant::now();
                if pin.get().is_none_or(|(_, until)| now > until) {
                    pin.set(Some((adj.value(), now + std::time::Duration::from_millis(450))));
                }
            });
        }
        let restore = {
            let (pin, centered) = (pin.clone(), self.centered.clone());
            move |a: &gtk::Adjustment| {
                if centered.get() {
                    return;
                }
                let Some((v, until)) = pin.get() else { return };
                if std::time::Instant::now() > until {
                    return;
                }
                if a.value() < v - 1.0 && a.upper() - a.page_size() >= v {
                    a.set_value(v);
                }
            }
        };
        let r = restore.clone();
        adj.connect_value_changed(move |a| r(a));
        adj.connect_upper_notify(move |a| restore(a));
    }

    /// Un PDF, en lecture seule.
    pub fn pdf(path: &Path) -> Result<Rc<Self>, String> {
        let view = crate::pdfview::PdfView::open(path)?;
        let empty = Self::text_parts();
        Ok(Self::register(Self {
            buf: empty.0,
            view: empty.1,
            root: view.widget.clone().upcast(),
            clamp: empty.2,
            zoom_bin: empty.3,
            zoom: Cell::new(1.0),
            path: RefCell::new(Some(path.to_path_buf())),
            id: next_doc_id(),
            spell: crate::spell::Checker::new(),
            base_css: gtk::CssProvider::new(),
            base_from_prefs: Cell::new(false),
            pdf: Some(view),
            owner: RefCell::new(Weak::new()),
            decorate_pending: Cell::new(false),
            kept_selection: Rc::new(Cell::new(None)),
            centered: Rc::new(Cell::new(false)),
            guides_area: gtk::DrawingArea::new(),
        }))
    }

    /// Les pièces d'un document texte qu'un PDF a aussi, sans s'en servir.
    fn text_parts() -> (gtk::TextBuffer, gtk::TextView, adw::Clamp, crate::zoom::ZoomBin) {
        let buf = editor::new_buffer();
        let view = gtk::TextView::with_buffer(&buf);
        view.set_editable(false);
        let zoom_bin = crate::zoom::ZoomBin::new(&gtk::Box::new(gtk::Orientation::Vertical, 0));
        (buf, view, adw::Clamp::new(), zoom_bin)
    }

    /// Retient la sélection tant que la page n'a pas le focus.
    fn keep_selection(&self) {
        let kept = self.kept_selection.clone();
        let view = self.view.downgrade();
        self.buf.connect_mark_set(move |buf, _, mark| {
            if mark != &buf.get_insert() && mark.name().as_deref() != Some("selection_bound") {
                return;
            }
            match buf.selection_bounds() {
                Some((a, b)) => kept.set(Some((a.offset(), b.offset()))),
                // Le curseur bouge dans la page : l'ancienne sélection est
                // abandonnée. Hors de la page, c'est GTK qui l'a effacée.
                None => {
                    if view.upgrade().is_some_and(|v| v.is_focus()) {
                        kept.set(None);
                    }
                }
            }
        });
        // Le texte change (annuler, remplacer…) : les positions retenues ne
        // valent plus rien. Une mise en forme resélectionne d'elle-même.
        let kept = self.kept_selection.clone();
        self.buf.connect_changed(move |buf| {
            kept.set(buf.selection_bounds().map(|(a, b)| (a.offset(), b.offset())));
        });
        // De retour dans la page : la sélection est celle qu'on y voit.
        let kept = self.kept_selection.clone();
        let focus = gtk::EventControllerFocus::new();
        let buf = self.buf.downgrade();
        focus.connect_enter(move |_| {
            if let Some(buf) = buf.upgrade() {
                kept.set(buf.selection_bounds().map(|(a, b)| (a.offset(), b.offset())));
            }
        });
        self.view.add_controller(focus);
    }

    /// Garde le curseur à l'écran pendant la frappe et les déplacements au
    /// clavier (le cadre de défilement ne le fait plus de lui-même).
    fn follow_caret(&self) {
        let pending = Rc::new(Cell::new(false));
        let view = self.view.downgrade();
        self.buf.connect_mark_set(move |buf, _, mark| {
            if mark != &buf.get_insert() || pending.get() {
                return;
            }
            let Some(v) = view.upgrade() else { return };
            if !v.is_focus() {
                return;
            }
            pending.set(true);
            let (pending, view) = (pending.clone(), view.clone());
            // Après la mise en page, pour connaître la place de la ligne.
            glib::idle_add_local_once(move || {
                pending.set(false);
                if let Some(v) = view.upgrade() {
                    let it = v.buffer().iter_at_mark(&v.buffer().get_insert());
                    editor::ensure_visible(&v, &it);
                }
            });
        });
    }

    /// Rétablit la sélection effacée quand le focus a quitté la page.
    pub fn restore_selection(&self) {
        if self.buf.has_selection() || self.view.is_focus() {
            return;
        }
        if let Some((a, b)) = self.kept_selection.get() {
            let n = self.buf.char_count();
            let (a, b) = (a.min(n), b.min(n));
            if a != b {
                self.buf.select_range(&self.buf.iter_at_offset(a), &self.buf.iter_at_offset(b));
            }
        }
    }

    fn register(doc: Self) -> Rc<Self> {
        let doc = Rc::new(doc);
        unsafe { doc.root.set_data(DOC_KEY, Rc::downgrade(&doc)) };
        DOCS.with(|d| d.borrow_mut().push(doc.clone()));
        doc
    }

    /// Le document d'un contenu d'onglet.
    pub fn of(child: &gtk::Widget) -> Option<Rc<Self>> {
        unsafe { child.data::<Weak<Self>>(DOC_KEY).and_then(|p| p.as_ref().upgrade()) }
    }

    /// Tous les documents ouverts.
    pub fn all() -> Vec<Rc<Self>> {
        DOCS.with(|d| d.borrow().clone())
    }

    /// L'onglet est fermé : le document s'en va (et sa copie de secours).
    pub fn forget(self: &Rc<Self>) {
        crate::store::drop_recovery(self.id);
        DOCS.with(|d| d.borrow_mut().retain(|x| !Rc::ptr_eq(x, self)));
    }

    pub fn owner(&self) -> Option<Rc<Window>> {
        self.owner.borrow().upgrade()
    }

    pub fn is_pdf(&self) -> bool {
        self.pdf.is_some()
    }

    pub fn is_modified(&self) -> bool {
        !self.is_pdf() && self.buf.is_modified()
    }

    pub fn display_name(&self) -> String {
        self.path
            .borrow()
            .as_ref()
            .and_then(|p| p.file_name().map(|n| n.to_string_lossy().to_string()))
            .unwrap_or_else(|| "Nouveau document".into())
    }

    /// Un document neuf, vide et jamais modifié : un fichier ouvert le
    /// remplace.
    pub fn is_pristine(&self) -> bool {
        !self.is_pdf() && self.path.borrow().is_none() && !self.buf.is_modified() && self.buf.char_count() == 0
    }

    /// La police de base du document (DOCX : celle du style Normal) devient
    /// celle de la page.
    pub fn apply_base_font(&self, base: &letters_core::model::BaseFont) {
        let mut css = String::from("textview.samizdat-page {");
        if let Some(f) = &base.family {
            css.push_str(&format!(" font-family: \"{}\";", f.replace('"', "")));
        }
        if let Some(hp) = base.size_hp {
            css.push_str(&format!(" font-size: {}pt;", hp as f64 / 2.0));
        }
        css.push('}');
        self.base_css.load_from_string(&css);
    }

    /// Police de base du document chargé ; s'il n'en a pas, celle des
    /// préférences, enregistrée avec lui.
    pub fn adopt_base_font(&self, base: &letters_core::model::BaseFont) {
        if base.family.is_some() || base.size_hp.is_some() {
            self.base_from_prefs.set(false);
            self.apply_base_font(base);
            return;
        }
        let p = crate::prefs::get();
        let base = letters_core::model::BaseFont { family: p.font_family.clone(), size_hp: Some(p.font_size_hp) };
        crate::bridge::set_base_font(&self.buf, base.clone());
        self.apply_base_font(&base);
        self.base_from_prefs.set(true);
    }

    /// Les préférences ont changé : un document qui suit la police par
    /// défaut la reprend.
    pub fn preferences_changed(&self) {
        if !self.is_pdf() && self.base_from_prefs.get() {
            self.adopt_base_font(&Default::default());
        }
    }

    /// Copie de secours toutes les 2 minutes tant que le document a des
    /// modifications non enregistrées.
    fn start_autosave(self: &Rc<Self>) {
        let d = Rc::downgrade(self);
        glib::timeout_add_seconds_local(120, move || {
            let Some(d) = d.upgrade() else { return glib::ControlFlow::Break };
            if !DOCS.with(|all| all.borrow().iter().any(|x| Rc::ptr_eq(x, &d))) {
                return glib::ControlFlow::Break;
            }
            if d.buf.is_modified() && !crate::live::is_busy(&d.buf) {
                let doc = crate::bridge::document_of(&d.buf);
                crate::store::save_recovery(d.id, &doc, d.path.borrow().as_deref());
            }
            glib::ControlFlow::Continue
        });
    }

    /// Habillage différé : tableaux en grille grise.
    pub fn schedule_decorate(self: &Rc<Self>) {
        if self.decorate_pending.replace(true) {
            return;
        }
        let d = Rc::downgrade(self);
        glib::idle_add_local_once(move || {
            if let Some(d) = d.upgrade() {
                d.decorate_pending.set(false);
                if !crate::live::is_busy(&d.buf) {
                    editor::decorate_tables(&d.buf);
                }
            }
        });
    }

    /// La police par défaut de l'éditeur (celle de GNOME ou du document).
    pub fn editor_family(&self) -> String {
        self.view.pango_context().font_description().and_then(|d| d.family()).map(|f| f.to_string()).unwrap_or_else(|| "Sans".into())
    }
}

fn next_doc_id() -> u64 {
    static COUNTER: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
    let t = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_millis() as u64).unwrap_or(0);
    t * 100 + COUNTER.fetch_add(1, std::sync::atomic::Ordering::Relaxed) % 100
}
