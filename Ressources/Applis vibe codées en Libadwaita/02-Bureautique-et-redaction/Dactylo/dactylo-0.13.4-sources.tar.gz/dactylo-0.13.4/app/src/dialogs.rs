// dialogs.rs — dialogues Adwaita : mise en page, tableau, image, lien.
// SPDX-License-Identifier: GPL-3.0-or-later

use std::rc::Rc;

use gtk4::{self as gtk, glib, prelude::*};
use libadwaita::{self as adw, prelude::*};
use letters_core::PageGeometry;

use crate::commands;

const PT_PER_CM: f64 = 72.0 / 2.54;

/// Un dialogue « Annuler / Appliquer » avec une page de préférences.
fn shell(title: &str, apply_label: &str, width: i32) -> (adw::Dialog, adw::PreferencesPage, gtk::Button) {
    let page = adw::PreferencesPage::new();
    let header = adw::HeaderBar::builder().show_end_title_buttons(false).show_start_title_buttons(false).build();
    let cancel = gtk::Button::with_label("Annuler");
    let apply = gtk::Button::with_label(apply_label);
    apply.add_css_class("suggested-action");
    header.pack_start(&cancel);
    header.pack_end(&apply);
    let tv = adw::ToolbarView::new();
    tv.add_top_bar(&header);
    tv.set_content(Some(&page));
    let dialog = adw::Dialog::builder().title(title).content_width(width).child(&tv).build();
    if title == "Image" || title == "Mise en page" {
        dialog.set_content_height(720);
    }
    let d = dialog.downgrade();
    cancel.connect_clicked(move |_| {
        if let Some(d) = d.upgrade() {
            d.close();
        }
    });
    (dialog, page, apply)
}

fn spin(title: &str, min: f64, max: f64, step: f64, digits: u32, value: f64, suffix: Option<&str>) -> adw::SpinRow {
    let r = adw::SpinRow::with_range(min, max, step);
    r.set_title(title);
    r.set_digits(digits);
    r.set_value(value);
    if let Some(s) = suffix {
        r.set_subtitle(s);
    }
    r
}

// ---- Mise en page ---------------------------------------------------------

const PAPERS: [(&str, f64, f64); 5] = [
    ("A4 (21 × 29,7 cm)", 595.28, 841.89),
    ("A5 (14,8 × 21 cm)", 419.53, 595.28),
    ("A3 (29,7 × 42 cm)", 841.89, 1190.55),
    ("Lettre US (8,5 × 11 po)", 612.0, 792.0),
    ("Légal US (8,5 × 14 po)", 612.0, 1008.0),
];

/// Numérotation des pages : libellé, modèle du pied de page (« {page} » et
/// « {total} » deviennent des champs dans le DOCX et l'ODT).
const PAGE_NUMBERS: [(&str, &str); 4] = [("Aucun", ""), ("1, 2, 3…", "{page}"), ("Page 1 sur 3", "Page {page} sur {total}"), ("1 sur 3", "{page} sur {total}")];
/// Où chercher un numéro de page : le plus long motif d'abord.
const PAGE_NUMBER_ORDER: [usize; 3] = [2, 3, 1];
const PAGE_NUMBER_SEP: &str = " — ";
const ZONE_NAMES: [&str; 3] = ["à gauche", "au centre", "à droite"];

/// Un en-tête ou un pied de page en lignes de trois zones (gauche, centre,
/// droite) : « gauche\tcentre\tdroite », une ligne par « \n ». Une ligne
/// sans zones est à gauche, ou au centre si elle numérote les pages.
fn split_zones(text: &str) -> Vec<[String; 3]> {
    text.split('\n')
        .map(|l| {
            if l.contains('\t') {
                let mut it = l.splitn(3, '\t');
                [it.next().unwrap_or("").to_string(), it.next().unwrap_or("").to_string(), it.next().unwrap_or("").to_string()]
            } else if l.contains("{page}") {
                [String::new(), l.to_string(), String::new()]
            } else {
                [l.to_string(), String::new(), String::new()]
            }
        })
        .collect()
}

/// L'inverse de `split_zones` ; None si tout est vide.
fn join_zones(lines: &[[String; 3]]) -> Option<String> {
    let mut out: Vec<String> = lines
        .iter()
        .map(|[l, c, r]| {
            let (l, c, r) = (l.trim(), c.trim(), r.trim());
            if c.is_empty() && r.is_empty() {
                l.to_string()
            } else if l.is_empty() && r.is_empty() && c.contains("{page}") {
                c.to_string()
            } else if r.is_empty() {
                format!("{l}\t{c}")
            } else {
                format!("{l}\t{c}\t{r}")
            }
        })
        .collect();
    while out.last().is_some_and(|l| l.is_empty()) {
        out.pop();
    }
    (!out.is_empty()).then(|| out.join("\n"))
}

/// Retire le numéro de page des zones : (numérotation, zone où il était).
fn take_page_number(lines: &mut [[String; 3]]) -> (usize, usize) {
    for &i in &PAGE_NUMBER_ORDER {
        let pattern = PAGE_NUMBERS[i].1;
        for line in lines.iter_mut() {
            for (z, zone) in line.iter_mut().enumerate() {
                if zone.contains(pattern) {
                    let rest = zone.replacen(pattern, "", 1);
                    *zone = rest.trim().trim_end_matches(PAGE_NUMBER_SEP.trim()).trim_start_matches(PAGE_NUMBER_SEP.trim()).trim().to_string();
                    return (i, z);
                }
            }
        }
    }
    (0, 1)
}

/// Les lignes de zones d'un en-tête ou d'un pied de page : deux lignes de
/// trois champs (la seconde repliée si elle est vide).
fn zones_editor(title: &str, lines: &[[String; 3]]) -> (adw::PreferencesGroup, Vec<[gtk::Entry; 3]>) {
    let group = adw::PreferencesGroup::builder().title(title).build();
    let mut entries = Vec::new();
    for row in 0..2 {
        let b = gtk::Box::new(gtk::Orientation::Horizontal, 6);
        let es: [gtk::Entry; 3] = std::array::from_fn(|z| {
            let e = gtk::Entry::builder()
                .placeholder_text(format!("{}{}", if row == 0 { "" } else { "2ᵉ ligne " }, ZONE_NAMES[z]))
                .text(lines.get(row).map_or("", |l| l[z].as_str()))
                .hexpand(true)
                .build();
            EditableExt::set_alignment(&e, [0.0, 0.5, 1.0][z]);
            b.append(&e);
            e
        });
        if row == 0 {
            group.add(&b);
        } else {
            let exp = gtk::Expander::builder().label("Deuxième ligne").expanded(lines.get(1).is_some_and(|l| l.iter().any(|z| !z.is_empty()))).child(&b).build();
            exp.set_margin_top(6);
            group.add(&exp);
        }
        entries.push(es);
    }
    (group, entries)
}

/// Marges étroites de Word (0,5 po).
const NARROW_CM: f64 = 1.27;
const DEFAULT_MARGIN_CM: f64 = 2.0;

pub fn page_setup(parent: &impl IsA<gtk::Widget>, buf: &gtk::TextBuffer) {
    let doc = commands::document(buf);
    let g = doc.page.clone().unwrap_or(PageGeometry {
        width_pt: 595.28,
        height_pt: 841.89,
        margin_top_pt: DEFAULT_MARGIN_CM * PT_PER_CM,
        margin_bottom_pt: DEFAULT_MARGIN_CM * PT_PER_CM,
        margin_left_pt: DEFAULT_MARGIN_CM * PT_PER_CM,
        margin_right_pt: DEFAULT_MARGIN_CM * PT_PER_CM,
        ..Default::default()
    });
    let landscape = g.width_pt > g.height_pt;
    let (pw, ph) = if landscape { (g.height_pt, g.width_pt) } else { (g.width_pt, g.height_pt) };
    let paper_idx = PAPERS.iter().position(|(_, w, h)| (w - pw).abs() < 3.0 && (h - ph).abs() < 3.0).unwrap_or(0);

    let (dialog, page, apply) = shell("Mise en page", "Appliquer", 540);
    let paper_group = adw::PreferencesGroup::builder().title("Papier").build();
    let names: Vec<&str> = PAPERS.iter().map(|p| p.0).collect();
    let paper = adw::ComboRow::builder().title("Format").model(&gtk::StringList::new(&names)).selected(paper_idx as u32).build();
    let orient = adw::ComboRow::builder().title("Orientation").model(&gtk::StringList::new(&["Portrait", "Paysage"])).selected(landscape as u32).build();
    paper_group.add(&paper);
    paper_group.add(&orient);
    page.add(&paper_group);

    let m_group = adw::PreferencesGroup::builder().title("Marges").description("En centimètres").build();
    let top = spin("Haut", 0.0, 10.0, 0.05, 2, g.margin_top_pt / PT_PER_CM, None);
    let bottom = spin("Bas", 0.0, 10.0, 0.05, 2, g.margin_bottom_pt / PT_PER_CM, None);
    let left = spin("Gauche", 0.0, 10.0, 0.05, 2, g.margin_left_pt / PT_PER_CM, None);
    let right = spin("Droite", 0.0, 10.0, 0.05, 2, g.margin_right_pt / PT_PER_CM, None);
    // Marges étroites (1,27 cm, comme Word) : un interrupteur qui fige les
    // quatre marges ; le désactiver rend les valeurs d'avant.
    let narrow_now = [&top, &bottom, &left, &right].iter().all(|r| (r.value() - NARROW_CM).abs() < 0.05);
    let narrow = adw::SwitchRow::builder().title("Marges étroites").subtitle("1,27 cm de chaque côté").active(narrow_now).build();
    m_group.add(&narrow);
    for r in [&top, &bottom, &left, &right] {
        r.set_sensitive(!narrow_now);
        m_group.add(r);
    }
    {
        let rows = [top.clone(), bottom.clone(), left.clone(), right.clone()];
        let before = Rc::new(std::cell::RefCell::new(if narrow_now { [DEFAULT_MARGIN_CM; 4] } else { rows.each_ref().map(|r| r.value()) }));
        narrow.connect_active_notify(move |s| {
            let on = s.is_active();
            if on {
                *before.borrow_mut() = rows.each_ref().map(|r| r.value());
            }
            let values = if on { [NARROW_CM; 4] } else { *before.borrow() };
            for (r, v) in rows.iter().zip(values) {
                r.set_value(v);
                r.set_sensitive(!on);
            }
        });
    }
    page.add(&m_group);

    let (header_group, header_entries) = zones_editor("En-tête", &split_zones(doc.header.as_deref().unwrap_or_default()));
    header_group.set_description(Some("Trois zones : à gauche, au centre, à droite"));
    let mut footer_lines = split_zones(doc.footer.as_deref().unwrap_or_default());
    let (numbering, zone) = take_page_number(&mut footer_lines);
    let (footer_group, footer_entries) = zones_editor("Pied de page", &footer_lines);
    let numbers = adw::ComboRow::builder()
        .title("Numéros de page")
        .model(&gtk::StringList::new(&PAGE_NUMBERS.iter().map(|(l, _)| *l).collect::<Vec<_>>()))
        .selected(numbering as u32)
        .build();
    let place = adw::ComboRow::builder()
        .title("Place du numéro")
        .subtitle("Sur la première ligne du pied de page")
        .model(&gtk::StringList::new(&["À gauche", "Au centre", "À droite"]))
        .selected(zone as u32)
        .build();
    let num_group = adw::PreferencesGroup::new();
    num_group.add(&numbers);
    num_group.add(&place);
    page.add(&header_group);
    page.add(&footer_group);
    page.add(&num_group);

    let (d, buf) = (dialog.downgrade(), buf.clone());
    apply.connect_clicked(move |_| {
        let (_, w, h) = PAPERS[paper.selected().min(PAPERS.len() as u32 - 1) as usize];
        let (w, h) = if orient.selected() == 1 { (h, w) } else { (w, h) };
        let geometry = PageGeometry {
            width_pt: w,
            height_pt: h,
            margin_top_pt: top.value() * PT_PER_CM,
            margin_bottom_pt: bottom.value() * PT_PER_CM,
            margin_left_pt: left.value() * PT_PER_CM,
            margin_right_pt: right.value() * PT_PER_CM,
            ..g.clone()
        };
        let read = |entries: &Vec<[gtk::Entry; 3]>| -> Vec<[String; 3]> { entries.iter().map(|es| std::array::from_fn(|z| es[z].text().to_string())).collect() };
        let header = join_zones(&read(&header_entries));
        let mut footer = read(&footer_entries);
        let pattern = PAGE_NUMBERS.get(numbers.selected() as usize).map_or("", |p| p.1);
        if !pattern.is_empty() {
            let zone = &mut footer[0][(place.selected() as usize).min(2)];
            *zone = if zone.trim().is_empty() { pattern.to_string() } else { format!("{}{PAGE_NUMBER_SEP}{pattern}", zone.trim()) };
        }
        commands::set_page(&buf, geometry, header, join_zones(&footer));
        if let Some(d) = d.upgrade() {
            d.close();
        }
    });
    dialog.present(Some(parent));
}

// ---- Image : taille et recadrage ------------------------------------------

/// `ocr(chemin, décalage)` : lire le texte de l'image (bouton « Extraire le
/// texte »), l'image étant au curseur, à ce décalage du tampon.
pub fn image(parent: &impl IsA<gtk::Widget>, buf: &gtk::TextBuffer, toast: impl Fn(&str) + 'static, ocr: impl Fn(String, i32) + 'static) {
    use crate::retouch::{self, Retouch};
    use std::cell::{Cell, RefCell};
    let Some((seq, run)) = commands::image_at_caret(buf) else {
        toast("Placez le curseur juste à côté d'une image");
        return;
    };
    let src = run.style.image.clone().unwrap_or_default();
    let Ok(original) = gtk::gdk_pixbuf::Pixbuf::from_file(&src) else {
        toast("Image illisible");
        return;
    };
    let (nw, nh) = (original.width(), original.height());
    let (ew, eh) = run.style.image_extent_emu.unwrap_or(((nw as f64 * commands::EMU_PER_PX) as u64, (nh as f64 * commands::EMU_PER_PX) as u64));
    // Aperçu rapide : l'image réduite, retouchée à chaque réglage.
    let small = {
        let k = (520.0 / nw.max(nh) as f64).min(1.0);
        original.scale_simple(((nw as f64 * k) as i32).max(1), ((nh as f64 * k) as i32).max(1), gtk::gdk_pixbuf::InterpType::Bilinear).unwrap_or_else(|| original.clone())
    };
    let doc = commands::document(buf);
    let image_para = letters_core::edit::locate(&doc, seq).map(|(p, _)| p);
    let caption = image_para.and_then(|p| retouch::caption_of(&doc, p));

    let (dialog, page, apply) = shell("Image", "Appliquer", 460);
    let state = Rc::new(RefCell::new(Retouch::default()));
    let ratio = Rc::new(Cell::new(eh as f64 / ew.max(1) as f64));

    let picture = gtk::Picture::new();
    picture.set_can_shrink(true);
    picture.set_content_fit(gtk::ContentFit::Contain);
    picture.set_size_request(-1, 200);
    picture.add_css_class("samizdat-checker");
    let preview = adw::PreferencesGroup::new();
    preview.add(&picture);
    page.add(&preview);

    // ---- Texte de l'image (OCR) ----
    let ocr_group = adw::PreferencesGroup::builder().title("Texte de l'image").build();
    let ocr_row = adw::ActionRow::builder().title("Extraire le texte").subtitle("Le texte reconnu est ajouté sous l'image").build();
    let ocr_btn = gtk::Button::builder().label("Extraire").valign(gtk::Align::Center).build();
    ocr_row.add_suffix(&ocr_btn);
    ocr_row.set_activatable_widget(Some(&ocr_btn));
    ocr_group.add(&ocr_row);
    page.add(&ocr_group);
    {
        let (d, src, caret) = (dialog.downgrade(), src.clone(), buf.iter_at_mark(&buf.get_insert()).offset());
        ocr_btn.connect_clicked(move |_| {
            if let Some(d) = d.upgrade() {
                d.close();
            }
            ocr(src.clone(), caret);
        });
    }

    // ---- Retouches ----
    let tools = adw::PreferencesGroup::builder().title("Retouches").build();
    let button = |icon: &str, tip: &str| {
        let b = gtk::Button::builder().icon_name(icon).tooltip_text(tip).build();
        b.add_css_class("flat");
        b
    };
    let rot_left = button("object-rotate-left-symbolic", "Pivoter à gauche");
    let rot_right = button("object-rotate-right-symbolic", "Pivoter à droite");
    let flip_h = button("object-flip-horizontal-symbolic", "Retourner horizontalement");
    let flip_v = button("object-flip-vertical-symbolic", "Retourner verticalement");
    let turn_row = adw::ActionRow::builder().title("Orientation").build();
    let turn_box = gtk::Box::new(gtk::Orientation::Horizontal, 2);
    turn_box.set_valign(gtk::Align::Center);
    for b in [&rot_left, &rot_right, &flip_h, &flip_v] {
        turn_box.append(b);
    }
    turn_row.add_suffix(&turn_box);
    tools.add(&turn_row);
    let slider = |title: &str, min: f64, max: f64| {
        let scale = gtk::Scale::with_range(gtk::Orientation::Horizontal, min, max, 1.0);
        scale.set_value(0.0);
        scale.set_draw_value(false);
        scale.set_hexpand(true);
        scale.set_size_request(200, -1);
        scale.add_mark(0.0, gtk::PositionType::Bottom, None);
        let row = adw::ActionRow::builder().title(title).build();
        row.add_suffix(&scale);
        (row, scale)
    };
    let (bright_row, bright) = slider("Luminosité", -100.0, 100.0);
    let (contrast_row, contrast) = slider("Contraste", -100.0, 100.0);
    let (radius_row, radius) = slider("Coins arrondis", 0.0, 25.0);
    radius.clear_marks();
    let frame = adw::SwitchRow::builder().title("Cadre fin").build();
    let reset_tools = gtk::Button::builder().label("Annuler les retouches").halign(gtk::Align::Start).margin_top(6).build();
    for r in [&bright_row, &contrast_row, &radius_row] {
        tools.add(r);
    }
    tools.add(&frame);
    tools.add(&reset_tools);
    page.add(&tools);

    // ---- Taille ----
    let size = adw::PreferencesGroup::builder().title("Taille").description(format!("Taille d'origine : {nw} × {nh} px")).build();
    let width = spin("Largeur (cm)", 0.5, 40.0, 0.1, 1, ew as f64 / commands::EMU_PER_CM, None);
    let height = spin("Hauteur (cm)", 0.5, 60.0, 0.1, 1, eh as f64 / commands::EMU_PER_CM, None);
    let keep = adw::SwitchRow::builder().title("Conserver les proportions").active(true).build();
    size.add(&width);
    size.add(&height);
    size.add(&keep);
    page.add(&size);

    // ---- Recadrer ----
    let crop = adw::PreferencesGroup::builder().title("Recadrer").description("Part de l'image à retirer de chaque côté, en %").build();
    let cl = spin("Gauche", 0.0, 90.0, 1.0, 0, 0.0, None);
    let cr = spin("Droite", 0.0, 90.0, 1.0, 0, 0.0, None);
    let ct = spin("Haut", 0.0, 90.0, 1.0, 0, 0.0, None);
    let cb = spin("Bas", 0.0, 90.0, 1.0, 0, 0.0, None);
    for r in [&cl, &cr, &ct, &cb] {
        crop.add(r);
    }
    page.add(&crop);

    // ---- Légende ----
    let cap_group = adw::PreferencesGroup::builder().title("Légende").description("Sous l'image, centrée. Laisser vide pour ne pas en mettre.").build();
    let cap_text = adw::EntryRow::builder().title("Texte de la légende").text(caption.as_ref().map(|c| c.0.clone()).unwrap_or_default()).build();
    let cap_num = adw::SwitchRow::builder().title("Numéroter").subtitle("Document 1, Document 2… dans l'ordre du document").active(caption.as_ref().map_or(crate::prefs::get().caption_numbered, |c| c.1)).build();
    cap_group.add(&cap_text);
    cap_group.add(&cap_num);
    page.add(&cap_group);


    // Les proportions suivent l'image retouchée.
    let guard = Rc::new(Cell::new(false));
    {
        let (h, k, g, ratio) = (height.clone(), keep.clone(), guard.clone(), ratio.clone());
        width.connect_value_notify(move |w| {
            if k.is_active() && !g.get() {
                g.set(true);
                h.set_value(w.value() * ratio.get());
                g.set(false);
            }
        });
    }
    {
        let (w, k, g, ratio) = (width.clone(), keep.clone(), guard.clone(), ratio.clone());
        height.connect_value_notify(move |h| {
            if k.is_active() && !g.get() {
                g.set(true);
                w.set_value(h.value() / ratio.get());
                g.set(false);
            }
        });
    }
    let refresh = {
        let (state, pic, small, ratio, width, height, keep, guard) = (state.clone(), picture.clone(), small.clone(), ratio.clone(), width.clone(), height.clone(), keep.clone(), guard.clone());
        let (cl, cr, ct, cb, bright, contrast, radius, frame) = (cl.clone(), cr.clone(), ct.clone(), cb.clone(), bright.clone(), contrast.clone(), radius.clone(), frame.clone());
        Rc::new(move || {
            {
                let mut st = state.borrow_mut();
                st.crop = (cl.value() / 100.0, ct.value() / 100.0, cr.value() / 100.0, cb.value() / 100.0);
                st.brightness = bright.value();
                st.contrast = contrast.value();
                st.radius = radius.value();
                st.frame = frame.is_active();
            }
            let out = retouch::process(&small, &state.borrow());
            pic.set_paintable(Some(&gtk::gdk::Texture::for_pixbuf(&out)));
            ratio.set(out.height() as f64 / out.width().max(1) as f64);
            if keep.is_active() && !guard.get() {
                guard.set(true);
                height.set_value(width.value() * ratio.get());
                guard.set(false);
            }
        })
    };
    refresh();
    for s in [&cl, &cr, &ct, &cb] {
        let r = refresh.clone();
        s.connect_value_notify(move |_| r());
    }
    for s in [&bright, &contrast, &radius] {
        let r = refresh.clone();
        s.connect_value_changed(move |_| r());
    }
    {
        let r = refresh.clone();
        frame.connect_active_notify(move |_| r());
    }
    // Pivoter : largeur et hauteur s'échangent.
    for (b, turn) in [(&rot_left, 3u32), (&rot_right, 1u32)] {
        let (state, r, width, height, guard) = (state.clone(), refresh.clone(), width.clone(), height.clone(), guard.clone());
        b.connect_clicked(move |_| {
            {
                let mut st = state.borrow_mut();
                st.quarter_turns = (st.quarter_turns + turn) % 4;
            }
            guard.set(true);
            let (w, h) = (width.value(), height.value());
            width.set_value(h);
            height.set_value(w);
            guard.set(false);
            r();
        });
    }
    for (b, horizontal) in [(&flip_h, true), (&flip_v, false)] {
        let (state, r) = (state.clone(), refresh.clone());
        b.connect_clicked(move |_| {
            {
                let mut st = state.borrow_mut();
                if horizontal {
                    st.flip_h = !st.flip_h;
                } else {
                    st.flip_v = !st.flip_v;
                }
            }
            r();
        });
    }
    {
        let (state, r, bright, contrast, radius, frame) = (state.clone(), refresh.clone(), bright.clone(), contrast.clone(), radius.clone(), frame.clone());
        reset_tools.connect_clicked(move |_| {
            *state.borrow_mut() = Retouch::default();
            bright.set_value(0.0);
            contrast.set_value(0.0);
            radius.set_value(0.0);
            frame.set_active(false);
            r();
        });
    }

    let (d, buf) = (dialog.downgrade(), buf.clone());
    let toast = Rc::new(toast);
    apply.connect_clicked(move |_| {
        let mut new_run = run.clone();
        let st = *state.borrow();
        if !st.is_identity() {
            match retouch::apply(&src, &st) {
                Ok((path, _, _)) => new_run.style.image = Some(path),
                Err(e) => {
                    toast(&format!("Retouche impossible : {e}"));
                    return;
                }
            }
        }
        new_run.style.image_extent_emu = Some(((width.value() * commands::EMU_PER_CM) as u64, (height.value() * commands::EMU_PER_CM) as u64));
        commands::replace_image(&buf, seq, new_run);
        let (text, numbered) = (cap_text.text().to_string(), cap_num.is_active());
        let before = caption.clone().unwrap_or_default();
        if image_para.is_some() && (text.trim() != before.0.trim() || (numbered != before.1 && !text.trim().is_empty())) {
            retouch::set_caption(&buf, seq, &text, numbered);
        }
        if let Some(d) = d.upgrade() {
            d.close();
        }
    });
    dialog.present(Some(parent));
}

// ---- Éditeur de tableau -----------------------------------------------------

/// Une vraie grille à remplir. Sans tableau sous le curseur : un nouveau
/// tableau (`rows` × `cols`). OK réécrit le tableau dans le document.
pub fn table_editor(parent: &impl IsA<gtk::Widget>, buf: &gtk::TextBuffer, textbox: bool) {
    let existing = if textbox { None } else { commands::table_at_caret(buf) };
    let initial: Vec<Vec<String>> = match &existing {
        Some(t) => t.cells.iter().map(|row| row.iter().map(|c| c.as_ref().map(|p| p.text()).unwrap_or_default()).collect()).collect(),
        None if textbox => vec![vec![String::new()]],
        None => vec![vec![String::new(); 3]; 3],
    };
    let title = if textbox { "Zone de texte" } else if existing.is_some() { "Modifier le tableau" } else { "Insérer un tableau" };
    let (dialog, _page, apply) = shell(title, if existing.is_some() { "Appliquer" } else { "Insérer" }, 640);
    if !textbox {
        dialog.set_content_height(480);
    }
    // Le contenu du shell est remplacé : une grille dans une zone défilante.
    let grid = gtk::Grid::builder().row_spacing(4).column_spacing(4).margin_top(12).margin_bottom(12).margin_start(12).margin_end(12).build();
    let cells: Rc<std::cell::RefCell<Vec<Vec<gtk::Entry>>>> = Rc::default();
    let textview = gtk::TextView::builder().wrap_mode(gtk::WrapMode::WordChar).top_margin(8).bottom_margin(8).left_margin(8).right_margin(8).build();

    let rebuild = {
        let (grid, cells) = (grid.clone(), cells.clone());
        move |texts: Vec<Vec<String>>| {
            while let Some(c) = grid.first_child() {
                grid.remove(&c);
            }
            let mut rows = Vec::new();
            for (r, row) in texts.iter().enumerate() {
                let mut entries = Vec::new();
                for (c, text) in row.iter().enumerate() {
                    let e = gtk::Entry::builder().text(text.as_str()).hexpand(true).width_chars(8).build();
                    if r == 0 {
                        e.add_css_class("heading");
                    }
                    grid.attach(&e, c as i32, r as i32, 1, 1);
                    entries.push(e);
                }
                rows.push(entries);
            }
            *cells.borrow_mut() = rows;
        }
    };
    let rebuild = Rc::new(rebuild);
    let current = {
        let cells = cells.clone();
        move || -> Vec<Vec<String>> { cells.borrow().iter().map(|row| row.iter().map(|e| e.text().to_string()).collect()).collect() }
    };
    let current = Rc::new(current);

    let content: gtk::Widget = if textbox {
        textview.buffer().set_text(&initial[0][0]);
        let frame = gtk::Frame::new(None);
        frame.set_child(Some(&textview));
        frame.set_margin_top(12);
        frame.set_margin_bottom(12);
        frame.set_margin_start(12);
        frame.set_margin_end(12);
        textview.set_size_request(-1, 160);
        let hint = gtk::Label::builder().label("Le texte est placé dans un encadré, à l'endroit du curseur.").wrap(true).xalign(0.0).margin_start(12).margin_end(12).build();
        hint.add_css_class("dim-label");
        let b = gtk::Box::new(gtk::Orientation::Vertical, 0);
        b.append(&frame);
        b.append(&hint);
        b.upcast()
    } else {
        rebuild(initial.clone());
        let add_row = gtk::Button::builder().icon_name("list-add-symbolic").tooltip_text("Ajouter une ligne").build();
        let del_row = gtk::Button::builder().icon_name("list-remove-symbolic").tooltip_text("Retirer la dernière ligne").build();
        let add_col = gtk::Button::builder().icon_name("list-add-symbolic").tooltip_text("Ajouter une colonne").build();
        let del_col = gtk::Button::builder().icon_name("list-remove-symbolic").tooltip_text("Retirer la dernière colonne").build();
        let bar = gtk::Box::new(gtk::Orientation::Horizontal, 12);
        bar.set_halign(gtk::Align::Center);
        bar.set_margin_top(6);
        let group = |label: &str, a: &gtk::Button, b: &gtk::Button| {
            let g = gtk::Box::new(gtk::Orientation::Horizontal, 0);
            g.add_css_class("linked");
            g.append(b);
            g.append(a);
            let l = gtk::Label::new(Some(label));
            let h = gtk::Box::new(gtk::Orientation::Horizontal, 6);
            h.append(&l);
            h.append(&g);
            h
        };
        bar.append(&group("Lignes", &add_row, &del_row));
        bar.append(&group("Colonnes", &add_col, &del_col));
        let (rb, cur, cells_for_focus) = (rebuild.clone(), current.clone(), cells.clone());
        add_row.connect_clicked(move |_| {
            let mut t = cur();
            let cols = t.first().map(Vec::len).unwrap_or(1);
            t.push(vec![String::new(); cols]);
            rb(t);
            if let Some(e) = cells_for_focus.borrow().last().and_then(|r| r.first()) {
                e.grab_focus();
            }
        });
        let (rb, cur) = (rebuild.clone(), current.clone());
        del_row.connect_clicked(move |_| {
            let mut t = cur();
            if t.len() > 1 {
                t.pop();
                rb(t);
            }
        });
        let (rb, cur) = (rebuild.clone(), current.clone());
        add_col.connect_clicked(move |_| {
            let mut t = cur();
            for row in &mut t {
                row.push(String::new());
            }
            rb(t);
        });
        let (rb, cur) = (rebuild.clone(), current.clone());
        del_col.connect_clicked(move |_| {
            let mut t = cur();
            if t.first().is_some_and(|r| r.len() > 1) {
                for row in &mut t {
                    row.pop();
                }
                rb(t);
            }
        });
        let scroller = gtk::ScrolledWindow::builder().child(&grid).vexpand(true).min_content_height(320).hscrollbar_policy(gtk::PolicyType::Automatic).build();
        let b = gtk::Box::new(gtk::Orientation::Vertical, 0);
        b.append(&bar);
        b.append(&scroller);
        b.upcast()
    };
    if let Some(tv) = dialog.child().and_downcast::<adw::ToolbarView>() {
        tv.set_content(Some(&content));
    }

    let (d, buf) = (dialog.downgrade(), buf.clone());
    apply.connect_clicked(move |_| {
        let texts = if textbox {
            let tb = textview.buffer();
            let t = tb.text(&tb.start_iter(), &tb.end_iter(), false).replace('\n', " ");
            vec![vec![t.trim().to_string()]]
        } else {
            current()
        };
        commands::write_table(&buf, &texts, existing.as_ref());
        if let Some(d) = d.upgrade() {
            d.close();
        }
    });
    dialog.present(Some(parent));
    let first = cells.borrow().first().and_then(|r| r.first()).cloned();
    if let Some(first) = first {
        first.grab_focus();
    }
}

// ---- Lien -------------------------------------------------------------------

pub fn link(parent: &impl IsA<gtk::Widget>, buf: &gtk::TextBuffer) {
    let selected = buf.selection_bounds().map(|(a, b)| buf.text(&a, &b, false).to_string());
    let (dialog, page, apply) = shell("Insérer un lien", "Insérer", 420);
    let g = adw::PreferencesGroup::new();
    let text = adw::EntryRow::builder().title("Texte affiché").text(selected.clone().unwrap_or_default()).build();
    let url = adw::EntryRow::builder().title("Adresse").text("https://").build();
    if selected.is_some() {
        text.set_sensitive(false);
    }
    g.add(&text);
    g.add(&url);
    page.add(&g);
    let (d, buf) = (dialog.downgrade(), buf.clone());
    let go = Rc::new(move || {
        commands::insert_link(&buf, &text.text(), &url.text());
        if let Some(d) = d.upgrade() {
            d.close();
        }
    });
    let g2 = go.clone();
    apply.connect_clicked(move |_| g2());
    dialog.present(Some(parent));
}

// ---- Frise chronologique ------------------------------------------------------

/// La frise : un titre, des lignes date / événement, un aperçu. `apply`
/// reçoit la frise et le PNG dessiné.
pub fn frise(parent: &impl IsA<gtk::Widget>, initial: Option<crate::frise::Frise>, family: String, apply: impl Fn(crate::frise::Frise, std::path::PathBuf) + 'static) {
    use crate::frise::Frise;
    use std::cell::RefCell;
    let editing = initial.is_some();
    let f0 = initial.unwrap_or_else(|| Frise { title: String::new(), events: vec![Default::default(); 4] });
    let (dialog, page, ok) = shell("Frise chronologique", if editing { "Modifier" } else { "Insérer" }, 680);
    dialog.set_content_height(760);

    let preview = gtk::Picture::builder().content_fit(gtk::ContentFit::Contain).height_request(190).can_shrink(true).build();
    preview.add_css_class("card");
    let pg = adw::PreferencesGroup::new();
    pg.add(&preview);
    page.add(&pg);

    let g = adw::PreferencesGroup::new();
    let title = adw::EntryRow::builder().title("Titre de la frise").text(&f0.title).build();
    g.add(&title);
    page.add(&g);

    let add = gtk::Button::builder().icon_name("list-add-symbolic").tooltip_text("Ajouter une ligne").valign(gtk::Align::Center).build();
    add.add_css_class("flat");
    let rows_group = adw::PreferencesGroup::builder()
        .title("Dates et événements")
        .description("Une période : « 1914-1918 ». Avant notre ère : « 52 av. J.-C. ». Un jour : « 11 novembre 1918 ».")
        .header_suffix(&add)
        .build();
    let list = gtk::ListBox::builder().selection_mode(gtk::SelectionMode::None).build();
    list.add_css_class("boxed-list");
    rows_group.add(&list);
    page.add(&rows_group);

    type Row = (gtk::ListBoxRow, gtk::Entry, gtk::Entry);
    let rows: Rc<RefCell<Vec<Row>>> = Rc::default();
    let current = {
        let (rows, title) = (rows.clone(), title.clone());
        move || Frise { title: title.text().to_string(), events: rows.borrow().iter().map(|(_, d, e)| (d.text().to_string(), e.text().to_string())).collect() }
    };
    let current = Rc::new(current);
    // L'aperçu, redessiné peu après chaque frappe.
    let pending: Rc<std::cell::Cell<Option<glib::SourceId>>> = Rc::default();
    let last_png: Rc<RefCell<Option<std::path::PathBuf>>> = Rc::default();
    let refresh = {
        let (current, preview, family, last_png, pending) = (current.clone(), preview.clone(), family.clone(), last_png.clone(), pending.clone());
        Rc::new(move || {
            if let Some(id) = pending.take() {
                id.remove();
            }
            let (current, preview, family, last_png, pending2) = (current.clone(), preview.clone(), family.clone(), last_png.clone(), pending.clone());
            let id = glib::timeout_add_local_once(std::time::Duration::from_millis(250), move || {
                pending2.set(None);
                if let Ok(p) = crate::frise::render_png(&current(), &family) {
                    preview.set_filename(Some(&p));
                    if let Some(old) = last_png.replace(Some(p)) {
                        let _ = std::fs::remove_file(old);
                    }
                }
            });
            pending.set(Some(id));
        })
    };
    let add_row = {
        let (rows, list, refresh) = (rows.clone(), list.clone(), refresh.clone());
        Rc::new(move |date: &str, event: &str| {
            let d = gtk::Entry::builder().placeholder_text("Date").text(date).width_chars(14).max_width_chars(16).build();
            let e = gtk::Entry::builder().placeholder_text("Événement").text(event).hexpand(true).build();
            let del = gtk::Button::builder().icon_name("user-trash-symbolic").tooltip_text("Retirer cette ligne").valign(gtk::Align::Center).build();
            del.add_css_class("flat");
            let b = gtk::Box::new(gtk::Orientation::Horizontal, 8);
            b.set_margin_top(6);
            b.set_margin_bottom(6);
            b.set_margin_start(8);
            b.set_margin_end(4);
            b.append(&d);
            b.append(&e);
            b.append(&del);
            let row = gtk::ListBoxRow::builder().child(&b).activatable(false).build();
            list.append(&row);
            for entry in [&d, &e] {
                let r = refresh.clone();
                entry.connect_changed(move |_| r());
            }
            {
                let (rows, list, row, refresh) = (rows.clone(), list.clone(), row.clone(), refresh.clone());
                del.connect_clicked(move |_| {
                    list.remove(&row);
                    rows.borrow_mut().retain(|(r, _, _)| r != &row);
                    refresh();
                });
            }
            rows.borrow_mut().push((row, d, e));
        })
    };
    for (d, e) in &f0.events {
        add_row(d, e);
    }
    {
        let (add_row, refresh, rows) = (add_row.clone(), refresh.clone(), rows.clone());
        add.connect_clicked(move |_| {
            add_row("", "");
            if let Some((_, d, _)) = rows.borrow().last() {
                d.grab_focus();
            }
            refresh();
        });
    }
    {
        let r = refresh.clone();
        title.connect_changed(move |_| r());
    }
    refresh();

    let d = dialog.downgrade();
    ok.connect_clicked(move |_| {
        let f = current();
        if f.events.iter().all(|(d, e)| d.trim().is_empty() && e.trim().is_empty()) {
            return;
        }
        match crate::frise::render_png(&f, &family) {
            Ok(p) => apply(f, p),
            Err(e) => eprintln!("frise : {e}"),
        }
        if let Some(d) = d.upgrade() {
            d.close();
        }
    });
    {
        let last_png = last_png.clone();
        dialog.connect_closed(move |_| {
            if let Some(p) = last_png.take() {
                let _ = std::fs::remove_file(p);
            }
        });
    }
    dialog.present(Some(parent));
    title.grab_focus();
}

/// La phrase d'essai du choix de police : le début du Manifeste du parti
/// communiste (traduction de Laura Lafargue, 1885).
pub const FONT_SAMPLE: &str = "Un spectre hante l’Europe\u{a0}: le spectre du communisme. Toutes les puissances de la vieille Europe se sont unies en une Sainte-Alliance pour traquer ce spectre\u{a0}: le pape et le tsar, Metternich et Guizot, les radicaux de France et les policiers d’Allemagne.";

/// Choisir une famille de police, avec la phrase d'essai en français.
/// (GtkFontDialog ne permet pas de choisir la phrase d'essai : on garde
/// l'ancienne fenêtre de choix, qui le permet.)
#[allow(deprecated)]
pub fn choose_font_family(parent: &impl IsA<gtk::Widget>, title: &str, current: &str, done: impl Fn(String) + 'static) {
    let window = parent.as_ref().root().and_then(|r| r.downcast::<gtk::Window>().ok());
    let d = gtk::FontChooserDialog::new(Some(title), window.as_ref());
    d.set_modal(true);
    d.set_level(gtk::FontChooserLevel::FAMILY);
    d.set_preview_text(FONT_SAMPLE);
    if !current.is_empty() {
        d.set_font(&format!("{current} 12"));
    }
    d.connect_response(move |d, r| {
        if r == gtk::ResponseType::Ok {
            if let Some(f) = d.font_family() {
                done(f.name().to_string());
            }
        }
        d.destroy();
    });
    d.present();
}
