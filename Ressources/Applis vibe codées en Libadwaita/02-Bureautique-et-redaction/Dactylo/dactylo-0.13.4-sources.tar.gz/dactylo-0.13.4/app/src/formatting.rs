#![allow(dead_code)]
// formatting.rs — balises de formatage et bascules reliées au modèle.
// Extrait de gtk-office-suite (letters/src/actions.rs), sans TabView.
// SPDX-License-Identifier: GPL-3.0-or-later

use gtk4::{self as gtk, glib, prelude::*};

/// Register all text formatting tags with the buffer's tag table.
pub fn register_formatting_tags(buffer: &gtk::TextBuffer) {
    let tag_table = buffer.tag_table();
    let tags: &[(&str, &[(&str, &glib::Value)])] = &[
        ("bold", &[]),
        ("italic", &[]),
        ("underline", &[]),
        ("strikethrough", &[]),
        ("highlight", &[]),
        ("code", &[]),
        ("superscript", &[]),
        ("subscript", &[]),
        ("h1", &[]),
        ("h2", &[]),
        ("h3", &[]),
        ("h4", &[]),
        ("h5", &[]),
        ("h6", &[]),
        ("blockquote", &[]),
        ("h-title", &[]),
        ("h-subtitle", &[]),
        ("code-block", &[]),
        ("align-left", &[]),
        ("align-center", &[]),
        ("align-right", &[]),
        ("align-justify", &[]),
        ("line-spacing-1.0", &[]),
        ("line-spacing-1.15", &[]),
        ("line-spacing-1.5", &[]),
        ("line-spacing-2.0", &[]),
        ("search-match", &[]),
        ("search-current", &[]),
        ("table-line", &[]),
        ("spelling-error", &[]),
        ("table-delim", &[]),
        ("textbox-line", &[]),
        ("textbox-white", &[]),
        ("textbox-hide", &[]),
        (crate::bridge::PAGE_BREAK_TAG, &[]),
    ];

    for &(name, _) in tags {
        if tag_table.lookup(name).is_none() {
            let tag = match name {
                "bold" => gtk::TextTag::builder().name(name).weight(700).build(),
                "italic" => gtk::TextTag::builder().name(name).style(gtk4::pango::Style::Italic).build(),
                "underline" => gtk::TextTag::builder().name(name).underline(gtk4::pango::Underline::Single).build(),
                "strikethrough" => gtk::TextTag::builder().name(name).strikethrough(true).build(),
                "highlight" => gtk::TextTag::builder().name(name).background("#fce94f").build(),
                "code" => gtk::TextTag::builder().name(name).family("monospace").background("#f0f0f0").build(),
                // 58% size, as LibreOffice and Word draw super/subscript;
                // the rise is in Pango units (1/1024 pt), a third of an
                // 11 pt line up and a sixth down.
                "superscript" => gtk::TextTag::builder().name(name).scale(0.58).rise(4 * gtk4::pango::SCALE).build(),
                "subscript" => gtk::TextTag::builder().name(name).scale(0.58).rise(-2 * gtk4::pango::SCALE).build(),
                "h1" => gtk::TextTag::builder().name(name).weight(700).scale(1.6).build(),
                "h2" => gtk::TextTag::builder().name(name).weight(700).scale(1.4).build(),
                "h3" => gtk::TextTag::builder().name(name).weight(700).scale(1.2).build(),
                "h4" => gtk::TextTag::builder().name(name).weight(700).scale(1.1).build(),
                "h5" => gtk::TextTag::builder().name(name).weight(700).scale(1.0).build(),
                "h6" => gtk::TextTag::builder().name(name).weight(700).scale(0.9).build(),
                "blockquote" => gtk::TextTag::builder().name(name).left_margin(crate::bridge::EDITOR_LEFT_MARGIN_PX + 32).style(gtk4::pango::Style::Italic).build(),
                // The page's Title, Subtitle and code block looks
                // (letters_core::layout::Look); the document state rides on
                // the paragraph's `para:` tag, these only draw it.
                "h-title" => gtk::TextTag::builder().name(name).weight(700).scale(26.0 / 11.0).build(),
                "h-subtitle" => gtk::TextTag::builder().name(name).scale(15.0 / 11.0).foreground("#666666").build(),
                "code-block" => gtk::TextTag::builder().name(name).family("monospace").paragraph_background("#f0f0f0").build(),
                // A page break has no text of its own, so it has to be
                // visible as space above the paragraph it starts — the
                // paragraph tag *is* the break (see bridge.rs), and an
                // invisible one would leave the user with no way to see
                // or remove what they inserted.
                crate::bridge::PAGE_BREAK_TAG => gtk::TextTag::builder()
                    .name(name)
                    .pixels_above_lines(28)
                    .paragraph_background("#e6e6e6")
                    .build(),
                "align-left" => gtk::TextTag::builder().name(name).justification(gtk::Justification::Left).build(),
                "align-center" => gtk::TextTag::builder().name(name).justification(gtk::Justification::Center).build(),
                "align-right" => gtk::TextTag::builder().name(name).justification(gtk::Justification::Right).build(),
                "align-justify" => gtk::TextTag::builder().name(name).justification(gtk::Justification::Fill).build(),
                "line-spacing-1.0" => gtk::TextTag::builder().name(name).pixels_inside_wrap(0).pixels_below_lines(0).build(),
                "line-spacing-1.15" => gtk::TextTag::builder().name(name).pixels_inside_wrap(3).pixels_below_lines(3).build(),
                "line-spacing-1.5" => gtk::TextTag::builder().name(name).pixels_inside_wrap(8).pixels_below_lines(8).build(),
                "line-spacing-2.0" => gtk::TextTag::builder().name(name).pixels_inside_wrap(16).pixels_below_lines(16).build(),
                "spelling-error" => {
                    let t = gtk::TextTag::builder().name(name).underline(gtk4::pango::Underline::Error).build();
                    t.set_underline_rgba(Some(&gtk4::gdk::RGBA::new(0.88, 0.11, 0.14, 1.0)));
                    t
                }
                "table-line" => gtk::TextTag::builder().name(name).family("monospace").paragraph_background("#f3f2f1").build(),
                "table-delim" => gtk::TextTag::builder().name(name).foreground("#b0afac").build(),
                // Zone de texte : encadré gris clair, en retrait des deux côtés.
                "textbox-line" => gtk::TextTag::builder()
                    .name(name)
                    .paragraph_background("#f6f5f4")
                    .left_margin(crate::bridge::EDITOR_LEFT_MARGIN_PX + 14)
                    .right_margin(crate::bridge::EDITOR_LEFT_MARGIN_PX + 14)
                    .pixels_above_lines(10)
                    .pixels_below_lines(10)
                    .build(),
                "textbox-white" => gtk::TextTag::builder()
                    .name(name)
                    .paragraph_background("#fdfdfc")
                    .left_margin(crate::bridge::EDITOR_LEFT_MARGIN_PX + 14)
                    .right_margin(crate::bridge::EDITOR_LEFT_MARGIN_PX + 14)
                    .pixels_above_lines(10)
                    .pixels_below_lines(10)
                    .build(),
                "textbox-hide" => gtk::TextTag::builder().name(name).invisible(true).build(),
                "search-match" => gtk::TextTag::builder().name(name).background("#fff3bf").build(),
                "search-current" => gtk::TextTag::builder().name(name).background("#f59f00").foreground("#000000").build(),
                _ => gtk::TextTag::builder().name(name).build(),
            };
            tag_table.add(&tag);
        }
    }
}


/// Toggle `tag_name` over the selection, or, with nothing selected, for
/// the text typed next at the caret: Bold, then type, types bold.
///
/// On a tab's document the toggle is a model op (`Op::Mark`), one undo step
/// that the buffer then shows, rather than a tag applied to the buffer and
/// read back (#1202 stage 3). The first selected character decides: bold
/// already, the selection loses bold; otherwise it gains it.
pub(crate) fn toggle_tag_in(buf: &gtk::TextBuffer, tag_name: &str) {
    let Some((start, end)) = buf.selection_bounds() else {
        toggle_pending(buf, tag_name);
        return;
    };
    let (from, to) = (start.offset().max(0), end.offset().max(0));
    if let (Some(live), Some(key)) = (crate::live::of(buf), mark_key(tag_name)) {
        let mut m = live.borrow_mut();
        let (s, e) = (m.sequence_offset(buf, from as usize), m.sequence_offset(buf, to as usize));
        let first = letters_core::edit::slice(m.document(buf), s, e)
            .and_then(|paras| paras.into_iter().flat_map(|p| p.runs).find(|r| !r.text.is_empty()));
        let has = first.is_some_and(|r| {
            let mut style = r.style;
            style_flag(&mut style, tag_name).is_some_and(|f| *f)
        });
        let mut value = letters_core::RunStyle::default();
        if let Some(flag) = style_flag(&mut value, tag_name) {
            *flag = !has;
        }
        let applied = m.apply_user_ops(buf, &[letters_core::edit::Op::Mark { start: s, end: e, key, value }], false);
        drop(m);
        // Marks move no text, so the selection's offsets still hold; the
        // model's projection put the caret at the change's end.
        if applied {
            buf.select_range(&buf.iter_at_offset(from), &buf.iter_at_offset(to));
        }
        return;
    }
    let Some(tag) = buf.tag_table().lookup(tag_name) else { return };
    let has = start.tags().iter().any(|t| t.name().as_deref() == Some(tag_name));
    if has {
        buf.remove_tag(&tag, &start, &end);
    } else {
        buf.apply_tag(&tag, &start, &end);
    }
}

/// Align the paragraphs the selection touches, or the caret's paragraph,
/// as a model op (#1202 stage 3). It used to tag buffer lines from the line
/// *before* the anchor, so a neighbouring paragraph was aligned too, and
/// with nothing selected the anchor was the document's start rather than
/// the caret.
pub(crate) fn align_in(buf: &gtk::TextBuffer, name: &str) {
    let alignment = match name {
        "align-left" => letters_core::Alignment::Left,
        "align-center" => letters_core::Alignment::Center,
        "align-right" => letters_core::Alignment::Right,
        "align-justify" => letters_core::Alignment::Justify,
        _ => return,
    };
    let Some(live) = crate::live::of(buf) else { return };
    let (start, end) = buf.selection_bounds().unwrap_or_else(|| {
        let caret = buf.iter_at_mark(&buf.get_insert());
        (caret, caret)
    });
    let (from, to) = (start.offset().max(0), end.offset().max(0));
    let restyled = live.borrow_mut().restyle(buf, from as usize, to as usize, |style| letters_core::ParaStyle { alignment, ..style.clone() });
    // A paragraph style moves no text: put the caret or selection back
    // where the projection found it.
    if restyled {
        buf.select_range(&buf.iter_at_offset(from), &buf.iter_at_offset(to));
    }
}

/// The selection's buffer offsets, or the caret's twice.
pub(crate) fn caret_or_selection(buf: &gtk::TextBuffer) -> (usize, usize) {
    let (start, end) = buf.selection_bounds().unwrap_or_else(|| {
        let caret = buf.iter_at_mark(&buf.get_insert());
        (caret, caret)
    });
    (start.offset().max(0) as usize, end.offset().max(0) as usize)
}

/// Restyle the caret's or the selection's paragraphs with `f` as one model
/// op, putting the caret or selection back where it was.
pub(crate) fn restyle_here(buf: &gtk::TextBuffer, f: impl Fn(&letters_core::ParaStyle) -> letters_core::ParaStyle) -> bool {
    let Some(live) = crate::live::of(buf) else { return false };
    let (from, to) = caret_or_selection(buf);
    let restyled = live.borrow_mut().restyle(buf, from, to, f);
    if restyled {
        buf.select_range(&buf.iter_at_offset(from as i32), &buf.iter_at_offset(to as i32));
    }
    restyled
}

/// The line spacings Cycle Line Spacing steps through.
const LINE_SPACINGS: [f32; 4] = [1.0, 1.15, 1.5, 2.0];

/// Give the caret's or selection's paragraphs the line spacing after the
/// first one's, as a model op (#1202 stage 3), and return it. It used to
/// tag buffer lines from the line before the caret, so a neighbouring
/// paragraph changed too, and the model never saw the spacing: it was not
/// saved.
pub(crate) fn cycle_line_spacing_in(buf: &gtk::TextBuffer) -> Option<f32> {
    let live = crate::live::of(buf)?;
    let current = live.borrow_mut().paragraph_style_at(buf, caret_or_selection(buf).0)?.line_spacing;
    let next = *LINE_SPACINGS.iter().find(|s| **s > current + 0.01).unwrap_or(&LINE_SPACINGS[0]);
    restyle_here(buf, |style| letters_core::ParaStyle { line_spacing: next, ..style.clone() }).then_some(next)
}

/// Set the caret's or selection's paragraphs' tab stops (points from the
/// paragraph's left edge) as a model op. The ruler used to put them on a
/// buffer tag the model never read, so they were not saved.
pub(crate) fn set_tab_stops_in(buf: &gtk::TextBuffer, tabs: &[f64]) -> bool {
    restyle_here(buf, |style| letters_core::ParaStyle { tab_stops_pt: tabs.to_vec(), ..style.clone() })
}

/// The model mark a toggle name sets, if it is one of the toggles.
fn mark_key(name: &str) -> Option<letters_core::edit::MarkKey> {
    use letters_core::edit::MarkKey;
    Some(match name {
        "bold" => MarkKey::Bold,
        "italic" => MarkKey::Italic,
        "underline" => MarkKey::Underline,
        "strikethrough" => MarkKey::Strikethrough,
        "highlight" => MarkKey::Highlight,
        _ => return None,
    })
}

/// Character formatting chosen with nothing selected, waiting for the next
/// text typed at buffer offset `at` (`take_pending`).
#[derive(Clone, Debug, Default, PartialEq)]
pub(crate) struct PendingFormat {
    pub at: i32,
    /// Formatting name (as `toggle_tag` takes it) and whether it turns on.
    pub marks: Vec<(String, bool)>,
    /// Valeurs (police, taille, couleur) choisies sans sélection.
    pub values: Vec<(letters_core::edit::MarkKey, letters_core::RunStyle)>,
}

const PENDING_KEY: &str = "letters-pending-format";

/// The run-style field a toggle name sets, if it is one of the toggles.
pub(crate) fn style_flag<'a>(style: &'a mut letters_core::RunStyle, name: &str) -> Option<&'a mut bool> {
    Some(match name {
        "bold" => &mut style.bold,
        "italic" => &mut style.italic,
        "underline" => &mut style.underline,
        "strikethrough" => &mut style.strikethrough,
        "highlight" => &mut style.highlight,
        _ => return None,
    })
}

fn toggle_pending(buf: &gtk::TextBuffer, name: &str) {
    let at = buf.iter_at_mark(&buf.get_insert()).offset();
    // Pending formatting belongs to one caret position: moved, it is gone.
    let mut pending = take_pending(buf).filter(|p| p.at == at).unwrap_or(PendingFormat { at, ..Default::default() });
    if let Some(i) = pending.marks.iter().position(|(n, _)| n == name) {
        // A second press takes the first back.
        pending.marks.remove(i);
    } else {
        // The opposite of what typing here would get: what the model's
        // typing rule gives at the caret.
        let mut typed = match crate::live::of(buf) {
            Some(m) => {
                let mut m = m.borrow_mut();
                let seq = m.sequence_offset(buf, at.max(0) as usize);
                letters_core::edit::typing_style(m.document(buf), seq)
            }
            None => letters_core::RunStyle::default(),
        };
        let Some(current) = style_flag(&mut typed, name) else { return };
        pending.marks.push((name.to_string(), !*current));
    }
    if !pending.marks.is_empty() || !pending.values.is_empty() {
        unsafe { buf.set_data(PENDING_KEY, pending) };
    }
}

/// Take the formatting waiting for typing at buffer offset `at`; pending
/// formatting left at another offset is dropped.
pub(crate) fn take_pending(buf: &gtk::TextBuffer) -> Option<PendingFormat> {
    unsafe { buf.steal_data::<PendingFormat>(PENDING_KEY) }
}


/// Remettre en place un formatage en attente lu par `take_pending`.
pub(crate) fn put_pending(buf: &gtk::TextBuffer, pending: PendingFormat) {
    unsafe { buf.set_data(PENDING_KEY, pending) };
}
