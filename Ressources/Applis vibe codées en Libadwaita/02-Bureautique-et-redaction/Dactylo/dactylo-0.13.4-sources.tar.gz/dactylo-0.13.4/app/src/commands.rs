// commands.rs — commandes d'édition passant par le modèle (une étape
// d'annulation chacune) : police, couleur, retraits, recherche/remplacement,
// tableaux, mise en page, images.
// SPDX-License-Identifier: GPL-3.0-or-later

use gtk4::{self as gtk, prelude::*};
use letters_core::edit::{self, MarkKey, Op};
use letters_core::{Paragraph, ParaStyle, Run, RunStyle};

fn selection(buf: &gtk::TextBuffer) -> Option<(i32, i32)> {
    buf.selection_bounds().map(|(a, b)| (a.offset(), b.offset()))
}

/// Applique une marque à valeur (police, taille, couleur) à la sélection,
/// ou la met en attente pour le texte tapé ensuite au curseur.
pub fn apply_value(buf: &gtk::TextBuffer, key: MarkKey, value: RunStyle) {
    let Some(live) = crate::live::of(buf) else { return };
    match selection(buf) {
        Some((from, to)) => {
            let mut m = live.borrow_mut();
            let (s, e) = (m.sequence_offset(buf, from as usize), m.sequence_offset(buf, to as usize));
            let applied = m.apply_user_ops(buf, &[Op::Mark { start: s, end: e, key, value }], false);
            drop(m);
            if applied {
                buf.select_range(&buf.iter_at_offset(from), &buf.iter_at_offset(to));
            }
        }
        None => {
            let at = buf.iter_at_mark(&buf.get_insert()).offset();
            let mut p = crate::formatting::take_pending(buf).filter(|p| p.at == at).unwrap_or_default();
            p.at = at;
            p.values.retain(|(k, _)| *k != key);
            p.values.push((key, value));
            crate::formatting::put_pending(buf, p);
        }
    }
    crate::live::sync_actions(buf);
}

pub fn set_font_family(buf: &gtk::TextBuffer, family: Option<String>) {
    apply_value(buf, MarkKey::FontFamily, RunStyle { font_family: family, ..Default::default() });
}

pub fn set_font_size(buf: &gtk::TextBuffer, size_pt: f64) {
    let hp = (size_pt * 2.0).round().clamp(2.0, 3276.0) as u16;
    apply_value(buf, MarkKey::FontSize, RunStyle { font_size_hp: Some(hp), ..Default::default() });
}

/// `None` : couleur automatique. Sinon « RRGGBB » (sans dièse, comme le DOCX).
pub fn set_color(buf: &gtk::TextBuffer, color: Option<String>) {
    apply_value(buf, MarkKey::Color, RunStyle { color, ..Default::default() });
}

/// Modifie le style des paragraphes de la sélection (ou du curseur).
pub fn restyle(buf: &gtk::TextBuffer, f: impl Fn(&ParaStyle) -> ParaStyle) -> bool {
    crate::formatting::restyle_here(buf, f)
}

/// Pas d'un retrait : 1,25 cm.
pub const INDENT_STEP_PT: f64 = 35.43;

/// Augmente ou diminue le retrait : d'un niveau pour un élément de liste,
/// de 1,25 cm sinon.
pub fn indent(buf: &gtk::TextBuffer, more: bool) {
    let in_list = crate::live::of(buf)
        .and_then(|m| {
            let mut m = m.try_borrow_mut().ok()?;
            let at = buf.iter_at_mark(&buf.get_insert()).offset().max(0) as usize;
            m.paragraph_style_at(buf, at)
        })
        .is_some_and(|p| p.list != letters_core::ListKind::None);
    if in_list {
        crate::bridge::apply_structured_edit(buf, |e| {
            if more {
                e.indent_list_at_cursor();
            } else {
                e.outdent_list_at_cursor();
            }
        });
        return;
    }
    restyle(buf, |s| {
        let step = if more { INDENT_STEP_PT } else { -INDENT_STEP_PT };
        ParaStyle { left_indent_pt: (s.left_indent_pt + step).max(0.0), ..s.clone() }
    });
}

/// Le paragraphe du curseur est-il en retrait (ou, dans une liste, à un
/// sous-niveau) ?
pub fn is_indented(st: &ParaStyle) -> bool {
    if st.list != letters_core::ListKind::None {
        st.list_level > 0
    } else {
        st.left_indent_pt > 0.5
    }
}

/// Un seul bouton de retrait : met un retrait s'il n'y en a pas, l'enlève
/// s'il y en a un. Dans une liste : un sous-niveau, ou retour au premier
/// niveau (Tab et Maj+Tab gardent les niveaux un par un).
pub fn toggle_indent(buf: &gtk::TextBuffer) {
    let style = crate::live::of(buf).and_then(|m| {
        let mut m = m.try_borrow_mut().ok()?;
        let at = buf.iter_at_mark(&buf.get_insert()).offset().max(0) as usize;
        m.paragraph_style_at(buf, at)
    });
    let Some(st) = style else { return };
    if st.list != letters_core::ListKind::None {
        let levels = if st.list_level > 0 { st.list_level } else { 0 };
        crate::bridge::apply_structured_edit(buf, |e| {
            if levels == 0 {
                e.indent_list_at_cursor();
            } else {
                for _ in 0..levels {
                    e.outdent_list_at_cursor();
                }
            }
        });
        return;
    }
    let on = !is_indented(&st);
    restyle(buf, |s| ParaStyle { left_indent_pt: if on { INDENT_STEP_PT } else { 0.0 }, ..s.clone() });
}

// ---- Recherche et remplacement ------------------------------------------

/// Occurrences de `needle` dans le tampon (décalages de caractères).
pub fn find_all(buf: &gtk::TextBuffer, needle: &str, match_case: bool) -> Vec<(i32, i32)> {
    if needle.is_empty() {
        return Vec::new();
    }
    let norm = |c: char| if match_case { c } else { c.to_lowercase().next().unwrap_or(c) };
    let hay: Vec<char> = buf.slice(&buf.start_iter(), &buf.end_iter(), true).chars().map(norm).collect();
    let pat: Vec<char> = needle.chars().map(norm).collect();
    let mut out = Vec::new();
    let mut i = 0;
    while i + pat.len() <= hay.len() {
        if hay[i..i + pat.len()] == pat[..] {
            out.push((i as i32, (i + pat.len()) as i32));
            i += pat.len();
        } else {
            i += 1;
        }
    }
    out
}

/// Remplace les plages (décalages du tampon) par `with`, en une seule étape
/// d'annulation. Le texte inséré prend le style du texte remplacé.
pub fn replace_ranges(buf: &gtk::TextBuffer, ranges: &[(i32, i32)], with: &str) -> usize {
    let each: Vec<(i32, i32, String)> = ranges.iter().map(|(a, b)| (*a, *b, with.to_string())).collect();
    replace_each(buf, &each)
}

/// Remplace chaque plage par son texte, en une seule étape d'annulation.
pub fn replace_each(buf: &gtk::TextBuffer, ranges: &[(i32, i32, String)]) -> usize {
    let Some(live) = crate::live::of(buf) else { return 0 };
    let mut m = live.borrow_mut();
    let mut seq: Vec<(usize, usize, &str)> = ranges
        .iter()
        .map(|(a, b, w)| (m.sequence_offset(buf, *a as usize), m.sequence_offset(buf, *b as usize), w.as_str()))
        .filter(|(a, b, _)| b > a)
        .collect();
    // De la fin vers le début : les décalages restants ne bougent pas.
    seq.sort_by(|x, y| y.0.cmp(&x.0));
    let mut scratch = m.document(buf).clone();
    let mut ops = Vec::new();
    for (s, e, with) in &seq {
        let style = edit::slice(&scratch, *s, *e)
            .and_then(|ps| ps.into_iter().flat_map(|p| p.runs).find(|r| !r.text.is_empty()))
            .map(|r| r.style)
            .unwrap_or_default();
        let del = Op::Delete { at: *s, len: e - s };
        if edit::apply(&mut scratch, &del).is_err() {
            continue;
        }
        ops.push(del);
        if !with.is_empty() {
            let ins = Op::Insert { at: *s, content: vec![Paragraph { style: ParaStyle::default(), runs: vec![Run { text: with.to_string(), style: style.clone() }] }] };
            if edit::apply(&mut scratch, &ins).is_ok() {
                ops.push(ins);
            }
        }
    }
    let n = seq.len();
    if !ops.is_empty() {
        m.apply_user_ops(buf, &ops, false);
    }
    drop(m);
    crate::live::sync_actions(buf);
    n
}

// ---- Tableaux -------------------------------------------------------------

pub enum TableEdit {
    #[cfg_attr(not(test), allow(dead_code))]
    Insert(u32, u32),
    RowAbove,
    RowBelow,
    ColLeft,
    ColRight,
    DeleteRow,
    DeleteCol,
}

pub fn table(buf: &gtk::TextBuffer, what: TableEdit) {
    crate::bridge::apply_structured_edit(buf, |e| {
        match what {
            TableEdit::Insert(r, c) => {
                e.insert_table(r.max(1), c.max(1));
            }
            TableEdit::RowAbove => {
                e.insert_row_at_cursor(false);
            }
            TableEdit::RowBelow => {
                e.insert_row_at_cursor(true);
            }
            TableEdit::ColLeft => {
                e.insert_col_at_cursor(false);
            }
            TableEdit::ColRight => {
                e.insert_col_at_cursor(true);
            }
            TableEdit::DeleteRow => {
                e.delete_row_at_cursor();
            }
            TableEdit::DeleteCol => {
                e.delete_col_at_cursor();
            }
        };
    });
}

/// Le curseur est-il dans un tableau ?
pub fn in_table(buf: &gtk::TextBuffer) -> bool {
    let Some(m) = crate::live::of(buf) else { return false };
    let Ok(mut m) = m.try_borrow_mut() else { return false };
    let at = buf.iter_at_mark(&buf.get_insert()).offset().max(0) as usize;
    let seq = m.sequence_offset(buf, at);
    edit::locate(m.document(buf), seq).is_some_and(|(p, _)| m.document(buf).paragraphs[p].style.table_cell.is_some())
}

// ---- Mise en page ---------------------------------------------------------

pub fn document(buf: &gtk::TextBuffer) -> letters_core::Document {
    crate::bridge::document_of(buf)
}

pub fn set_page(buf: &gtk::TextBuffer, page: letters_core::PageGeometry, header: Option<String>, footer: Option<String>) {
    let Some(live) = crate::live::of(buf) else { return };
    live.borrow_mut().edit_with(buf, |_| vec![Op::SetPage { page: Some(page) }, Op::SetHeaderFooter { header, footer }]);
    buf.set_modified(true);
    crate::live::sync_actions(buf);
}

// ---- Images ---------------------------------------------------------------

/// Pixels CSS par EMU (914 400 EMU par pouce, 96 px par pouce).
pub const EMU_PER_PX: f64 = 9525.0;
pub const EMU_PER_CM: f64 = 360000.0;

/// Taille naturelle d'une image, en pixels.
pub fn image_size(path: &str) -> Option<(i32, i32)> {
    gtk::gdk_pixbuf::Pixbuf::file_info(path).map(|(_, w, h)| (w, h))
}

/// Dossier où Samizdat garde les images insérées ou recadrées.
fn image_dir() -> std::path::PathBuf {
    let d = gtk::glib::user_cache_dir().join(crate::DIR).join("images");
    let _ = std::fs::create_dir_all(&d);
    d
}

pub(crate) fn unique_name(ext: &str) -> std::path::PathBuf {
    let t = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0);
    image_dir().join(format!("img-{t:x}.{ext}"))
}

/// Insère l'image `path` au curseur. Une image plus large que la page est
/// réduite à 16 cm de large.
pub fn insert_image(buf: &gtk::TextBuffer, path: &std::path::Path) -> Result<(), String> {
    insert_image_sized(buf, path, None)
}

/// Comme `insert_image`, avec une largeur imposée en cm (formes).
pub fn insert_image_sized(buf: &gtk::TextBuffer, path: &std::path::Path, width_cm: Option<f64>) -> Result<(), String> {
    let run = image_run(path, width_cm, None)?;
    insert_block_image(buf, run);
    Ok(())
}

/// Le run d'une image : une copie du fichier `path`, à `width_cm` de
/// large (sinon sa taille, 16 cm au plus), et son texte de remplacement
/// (sinon le nom du fichier).
pub fn image_run(path: &std::path::Path, width_cm: Option<f64>, alt: Option<String>) -> Result<Run, String> {
    let src = path.to_string_lossy().to_string();
    let (w, h) = image_size(&src).ok_or_else(|| format!("« {} » n'est pas une image lisible.", path.display()))?;
    // Copie : le document ne dépend plus de l'emplacement d'origine.
    let ext = path.extension().map(|e| e.to_string_lossy().to_lowercase()).unwrap_or_else(|| "png".into());
    let copy = unique_name(&ext);
    std::fs::copy(path, &copy).map_err(|e| e.to_string())?;
    let max_emu = 16.0 * EMU_PER_CM;
    let (mut ew, mut eh) = (w as f64 * EMU_PER_PX, h as f64 * EMU_PER_PX);
    if ew > max_emu {
        eh *= max_emu / ew;
        ew = max_emu;
    }
    if let Some(cm) = width_cm {
        let target = cm * EMU_PER_CM;
        eh *= target / ew;
        ew = target;
    }
    let alt = alt.unwrap_or_else(|| path.file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_default());
    Ok(Run {
        text: alt,
        style: RunStyle { image: Some(copy.to_string_lossy().to_string()), image_extent_emu: Some((ew as u64, eh as u64)), ..Default::default() },
    })
}

/// Insère une image venue du presse-papiers (capture d'écran…) ou d'un
/// glisser-déposer.
pub fn insert_image_texture(buf: &gtk::TextBuffer, texture: &gtk::gdk::Texture) -> Result<(), String> {
    let path = unique_name("png");
    texture.save_to_png(&path).map_err(|e| e.to_string())?;
    insert_image_sized(buf, &path, None)
}

/// Insère l'image `run` au curseur, seule sur sa ligne et centrée : du
/// texte à côté d'une image prendrait toute sa hauteur (sélection,
/// surlignage).
pub fn insert_block_image(buf: &gtk::TextBuffer, run: Run) {
    let Some(live) = crate::live::of(buf) else { return };
    let mut m = live.borrow_mut();
    let caret = buf.iter_at_mark(&buf.get_insert()).offset().max(0) as usize;
    let at = m.sequence_offset(buf, caret);
    let doc = m.document(buf).clone();
    // Préférence : l'image dans le fil du texte, là où est le curseur.
    let ops = if crate::prefs::get().image_own_line {
        image_block_ops(&doc, at, run)
    } else {
        vec![Op::Insert { at, content: vec![Paragraph { style: ParaStyle::default(), runs: vec![run] }] }]
    };
    m.apply_user_ops(buf, &ops, false);
    drop(m);
    crate::live::sync_actions(buf);
}

/// Les opérations qui posent `run` dans un paragraphe à lui, centré.
pub fn image_block_ops(doc: &letters_core::Document, at: usize, run: Run) -> Vec<Op> {
    let centered = |style: &ParaStyle| ParaStyle { alignment: letters_core::Alignment::Center, list: letters_core::ListKind::None, heading: None, ..style.clone() };
    let Some((pi, po)) = edit::locate(doc, at) else {
        return vec![Op::Insert { at, content: vec![Paragraph { style: ParaStyle::default(), runs: vec![run] }] }];
    };
    let para = &doc.paragraphs[pi];
    let len: usize = para.runs.iter().map(|r| r.text.chars().count()).sum();
    let image = |style: ParaStyle| Paragraph { style, runs: vec![run.clone()] };
    if len == 0 {
        // Paragraphe vide : l'image le remplit.
        return vec![Op::Insert { at, content: vec![image(ParaStyle::default())] }, Op::SetParaStyle { at, style: centered(&para.style) }];
    }
    if po == 0 {
        // Début d'un paragraphe : l'image avant, le texte sur la ligne suivante.
        return vec![
            Op::Insert { at, content: vec![image(ParaStyle::default()), Paragraph { style: para.style.clone(), runs: vec![] }] },
            Op::SetParaStyle { at, style: centered(&para.style) },
        ];
    }
    // Ailleurs : coupure avant et après.
    vec![Op::Insert {
        at,
        content: vec![Paragraph { style: ParaStyle::default(), runs: vec![] }, image(centered(&para.style)), Paragraph { style: para.style.clone(), runs: vec![] }],
    }]
}

/// L'image juste après (ou juste avant) le curseur : décalage dans le
/// modèle et son run.
pub fn image_at_caret(buf: &gtk::TextBuffer) -> Option<(usize, Run)> {
    let live = crate::live::of(buf)?;
    let mut m = live.try_borrow_mut().ok()?;
    let caret = buf.iter_at_mark(&buf.get_insert());
    let mut candidates = vec![caret];
    let mut before = caret;
    if before.backward_char() {
        candidates.push(before);
    }
    if let Some((a, _)) = buf.selection_bounds() {
        candidates.insert(0, a);
    }
    for it in candidates {
        if it.paintable().is_none() {
            continue;
        }
        let seq = m.sequence_offset(buf, it.offset().max(0) as usize);
        let run = edit::slice(m.document(buf), seq, seq + 1)?.into_iter().flat_map(|p| p.runs).find(|r| r.style.image.is_some())?;
        return Some((seq, run));
    }
    None
}

/// Remplace l'image à `seq` par `run` (taille ou recadrage modifiés).
pub fn replace_image(buf: &gtk::TextBuffer, seq: usize, run: Run) {
    let Some(live) = crate::live::of(buf) else { return };
    let ops = [Op::Delete { at: seq, len: 1 }, Op::Insert { at: seq, content: vec![Paragraph { style: ParaStyle::default(), runs: vec![run] }] }];
    live.borrow_mut().apply_user_ops(buf, &ops, false);
    crate::live::sync_actions(buf);
}

/// Recadre l'image `src` (marges en fractions 0..1 : gauche, haut, droite,
/// bas) dans un nouveau fichier PNG ; renvoie son chemin et sa taille.
#[cfg(test)]
pub fn crop_image(src: &str, l: f64, t: f64, r: f64, b: f64) -> Result<(String, i32, i32), String> {
    crate::retouch::apply(src, &crate::retouch::Retouch { crop: (l, t, r, b), ..Default::default() })
}

// ---- Surlignage, lien, colonnes ---------------------------------------------

/// Surligne la sélection (ou le texte tapé ensuite) ; `None` retire le
/// surlignage. Couleur en RRGGBB ; le jaune est la couleur par défaut.
pub fn set_highlight(buf: &gtk::TextBuffer, color: Option<&str>) {
    let style = match color {
        Some(c) => {
            let hex = c.trim_start_matches('#').to_uppercase();
            RunStyle { highlight: true, highlight_color: (hex != "FFFF00").then_some(hex), ..Default::default() }
        }
        None => RunStyle::default(),
    };
    apply_value(buf, MarkKey::Highlight, style);
}

/// Insère un lien au curseur, ou transforme la sélection en lien.
pub fn insert_link(buf: &gtk::TextBuffer, text: &str, url: &str) {
    let Some(live) = crate::live::of(buf) else { return };
    let url = url.trim().to_string();
    if url.is_empty() {
        return;
    }
    if let Some((from, to)) = selection(buf) {
        let mut m = live.borrow_mut();
        let (s, e) = (m.sequence_offset(buf, from as usize), m.sequence_offset(buf, to as usize));
        m.apply_user_ops(buf, &[Op::Mark { start: s, end: e, key: MarkKey::Link, value: RunStyle { link: Some(url), ..Default::default() } }], false);
    } else {
        let text = if text.trim().is_empty() { url.clone() } else { text.to_string() };
        let mut m = live.borrow_mut();
        let caret = buf.iter_at_mark(&buf.get_insert()).offset().max(0) as usize;
        let at = m.sequence_offset(buf, caret);
        let run = Run { text, style: RunStyle { link: Some(url), ..Default::default() } };
        m.apply_user_ops(buf, &[Op::Insert { at, content: vec![Paragraph { style: ParaStyle::default(), runs: vec![run] }] }], false);
    }
    crate::live::sync_actions(buf);
}

/// Nombre de colonnes de tout le document (1, 2 ou 3).
pub fn set_columns(buf: &gtk::TextBuffer, n: u8) {
    let Some(live) = crate::live::of(buf) else { return };
    let doc = document(buf);
    let mut page = doc.page.clone().unwrap_or_else(default_page);
    page.columns = n.clamp(1, 3);
    if page.column_gap_pt <= 0.0 {
        page.column_gap_pt = 35.43;
    }
    live.borrow_mut().edit_with(buf, |_| vec![Op::SetPage { page: Some(page) }]);
    buf.set_modified(true);
    crate::live::sync_actions(buf);
}

pub fn columns(buf: &gtk::TextBuffer) -> u8 {
    document(buf).page.map(|p| p.columns.max(1)).unwrap_or(1)
}

/// A4, marges de 2 cm.
pub fn default_page() -> letters_core::PageGeometry {
    let cm = 72.0 / 2.54;
    letters_core::PageGeometry {
        width_pt: 595.28,
        height_pt: 841.89,
        margin_top_pt: 2.0 * cm,
        margin_bottom_pt: 2.0 * cm,
        margin_left_pt: 2.0 * cm,
        margin_right_pt: 2.0 * cm,
        columns: 1,
        ..Default::default()
    }
}

// ---- Tableau : lecture et réécriture d'un bloc ------------------------------

/// Un tableau du modèle : où il commence, ses cases (texte et paragraphe
/// d'origine), sa taille.
#[derive(Clone, Debug)]
pub struct TableBlock {
    pub first: usize,
    pub count: usize,
    pub id: u32,
    #[cfg_attr(not(test), allow(dead_code))]
    pub rows: usize,
    #[cfg_attr(not(test), allow(dead_code))]
    pub cols: usize,
    /// cells[r][c] = paragraphe d'origine (s'il existe).
    pub cells: Vec<Vec<Option<Paragraph>>>,
}

/// Le tableau sous le curseur, s'il y en a un.
pub fn table_at_caret(buf: &gtk::TextBuffer) -> Option<TableBlock> {
    let live = crate::live::of(buf)?;
    let mut m = live.try_borrow_mut().ok()?;
    let at = buf.iter_at_mark(&buf.get_insert()).offset().max(0) as usize;
    let seq = m.sequence_offset(buf, at);
    let doc = m.document(buf).clone();
    let (pi, _) = edit::locate(&doc, seq)?;
    let id = doc.paragraphs[pi].style.table_cell?.table;
    let mut first = pi;
    while first > 0 && doc.paragraphs[first - 1].style.table_cell.is_some_and(|c| c.table == id) {
        first -= 1;
    }
    let mut end = pi;
    while end + 1 < doc.paragraphs.len() && doc.paragraphs[end + 1].style.table_cell.is_some_and(|c| c.table == id) {
        end += 1;
    }
    let paras = &doc.paragraphs[first..=end];
    let rows = paras.iter().filter_map(|p| p.style.table_cell).map(|c| c.row as usize).max().unwrap_or(0) + 1;
    let cols = paras.iter().filter_map(|p| p.style.table_cell).map(|c| c.col as usize).max().unwrap_or(0) + 1;
    let mut cells = vec![vec![None; cols]; rows];
    for p in paras {
        let c = p.style.table_cell?;
        let slot = &mut cells[c.row as usize][c.col as usize];
        if slot.is_none() {
            *slot = Some(p.clone());
        }
    }
    Some(TableBlock { first, count: end - first + 1, id, rows, cols, cells })
}

/// Les paragraphes d'un tableau `texts` (lignes × colonnes). Une case dont
/// le texte n'a pas changé garde sa mise en forme ; une case modifiée prend
/// celle du début de la case d'origine.
pub fn table_paragraphs(id: u32, texts: &[Vec<String>], old: Option<&TableBlock>) -> Vec<Paragraph> {
    let mut out = Vec::new();
    for (r, row) in texts.iter().enumerate() {
        for (c, text) in row.iter().enumerate() {
            let orig = old.and_then(|t| t.cells.get(r)).and_then(|row| row.get(c)).and_then(|p| p.clone());
            let cell = letters_core::TableCell { table: id, row: r as u32, col: c as u32 };
            let para = match orig {
                Some(p) if p.text() == *text => Paragraph { style: ParaStyle { table_cell: Some(cell), ..p.style.clone() }, runs: p.runs.clone() },
                Some(p) => {
                    let style = p.runs.iter().find(|r| !r.text.is_empty() && r.style.image.is_none()).map(|r| r.style.clone()).unwrap_or_default();
                    Paragraph {
                        style: ParaStyle { table_cell: Some(cell), ..p.style.clone() },
                        runs: if text.is_empty() { vec![] } else { vec![Run { text: text.clone(), style }] },
                    }
                }
                None => Paragraph {
                    style: ParaStyle { table_cell: Some(cell), ..Default::default() },
                    runs: if text.is_empty() { vec![] } else { vec![Run::plain(text)] },
                },
            };
            out.push(para);
        }
    }
    out
}

/// Remplace le tableau `old` par `texts`, ou insère un nouveau tableau
/// après le paragraphe du curseur. Une seule étape d'annulation.
pub fn write_table(buf: &gtk::TextBuffer, texts: &[Vec<String>], old: Option<&TableBlock>) {
    let Some(live) = crate::live::of(buf) else { return };
    if texts.is_empty() || texts[0].is_empty() {
        return;
    }
    let caret = buf.iter_at_mark(&buf.get_insert()).offset().max(0) as usize;
    let mut m = live.borrow_mut();
    let seq = m.sequence_offset(buf, caret);
    let ops = {
        let doc = m.document(buf);
        match old {
            Some(t) => vec![Op::SetParagraphs { para: t.first, remove: t.count, insert: table_paragraphs(t.id, texts, Some(t)) }],
            None => {
                let id = doc.paragraphs.iter().filter_map(|p| p.style.table_cell).map(|c| c.table + 1).max().unwrap_or(1);
                let pi = edit::locate(doc, seq).map(|(p, _)| p).unwrap_or(doc.paragraphs.len().saturating_sub(1));
                let mut insert = table_paragraphs(id, texts, None);
                // Un paragraphe vide après le tableau, pour continuer à écrire.
                let next_is_text = doc.paragraphs.get(pi + 1).is_some_and(|p| p.style.table_cell.is_none());
                if !next_is_text {
                    insert.push(Paragraph::default());
                }
                vec![Op::SetParagraphs { para: pi + 1, remove: 0, insert }]
            }
        }
    };
    m.apply_user_ops(buf, &ops, false);
    drop(m);
    crate::live::sync_actions(buf);
}

// ---- Cartouches ---------------------------------------------------------------

/// Les six cartouches proposés : nom, allure décrite, allure. Deux familles
/// (arrondi sur fond gris, carré sur fond blanc), trois traits.
pub const CARTOUCHES: [(&str, &str, letters_core::Cartouche); 6] = {
    use letters_core::{Cartouche, CartoucheLine::*};
    [
        ("Définition", "Arrondi, fond gris, sans trait", Cartouche { square: false, line: None, white: false }),
        ("Problématique", "Arrondi, fond gris, trait fin", Cartouche { square: false, line: Thin, white: false }),
        ("À retenir", "Arrondi, fond gris, trait épais", Cartouche { square: false, line: Thick, white: false }),
        ("Extrait", "Carré, fond blanc, sans trait : un morceau de document mis à part", Cartouche { square: true, line: None, white: true }),
        ("Document", "Carré, fond blanc, trait fin", Cartouche { square: true, line: Thin, white: true }),
        ("Sujet", "Carré, fond blanc, trait épais", Cartouche { square: true, line: Thick, white: true }),
    ]
};

/// Les paragraphes du tableau d'une seule case qui contient le paragraphe
/// `pi` : un cartouche. None ailleurs (ou dans un vrai tableau).
fn cartouche_range(doc: &letters_core::Document, pi: usize) -> Option<std::ops::RangeInclusive<usize>> {
    let id = doc.paragraphs.get(pi)?.style.table_cell?.table;
    let mut first = pi;
    while first > 0 && doc.paragraphs[first - 1].style.table_cell.is_some_and(|c| c.table == id) {
        first -= 1;
    }
    let mut last = pi;
    while last + 1 < doc.paragraphs.len() && doc.paragraphs[last + 1].style.table_cell.is_some_and(|c| c.table == id) {
        last += 1;
    }
    doc.paragraphs[first..=last].iter().all(|p| p.style.table_cell.is_some_and(|c| c.row == 0 && c.col == 0)).then_some(first..=last)
}

/// Les décalages de la sélection (ou du curseur), dans l'ordre.
fn selection_span(buf: &gtk::TextBuffer) -> (usize, usize) {
    let a = buf.iter_at_mark(&buf.get_insert()).offset().max(0) as usize;
    let b = buf.iter_at_mark(&buf.selection_bound()).offset().max(0) as usize;
    (a.min(b), a.max(b))
}

/// L'allure du cartouche sous le curseur, s'il est dans un cartouche.
pub fn cartouche_at_caret(buf: &gtk::TextBuffer) -> Option<letters_core::Cartouche> {
    let live = crate::live::of(buf)?;
    let mut m = live.try_borrow_mut().ok()?;
    let at = buf.iter_at_mark(&buf.get_insert()).offset().max(0) as usize;
    let seq = m.sequence_offset(buf, at);
    let doc = m.document(buf);
    let (pi, _) = edit::locate(doc, seq)?;
    let range = cartouche_range(doc, pi)?;
    Some(doc.paragraphs[*range.start()].style.cartouche.unwrap_or_default())
}

/// Ce que fait `cartouche`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CartoucheDone {
    /// Le cartouche du curseur a changé d'allure.
    Restyled,
    /// Les paragraphes sont mis en cartouche.
    Wrapped,
    /// Rien : le curseur est dans un tableau.
    InTable,
}

/// Le cartouche sous le curseur prend l'allure `look` ; ailleurs, les
/// paragraphes de la sélection (ou celui du curseur) deviennent un
/// cartouche de cette allure, leurs textes à la suite. Une seule étape
/// d'annulation.
pub fn cartouche(buf: &gtk::TextBuffer, look: letters_core::Cartouche) -> CartoucheDone {
    let Some(live) = crate::live::of(buf) else { return CartoucheDone::InTable };
    let (a, b) = selection_span(buf);
    let mut m = live.borrow_mut();
    let (sa, sb) = (m.sequence_offset(buf, a), m.sequence_offset(buf, b));
    let (ops, done) = {
        let doc = m.document(buf);
        let Some((p0, _)) = edit::locate(doc, sa) else { return CartoucheDone::InTable };
        let p1 = edit::locate(doc, sb).map_or(p0, |(p, _)| p).max(p0);
        if doc.paragraphs[p0].style.table_cell.is_some() {
            let Some(range) = cartouche_range(doc, p0) else { return CartoucheDone::InTable };
            let ops: Vec<Op> = range
                .map(|pi| Op::SetParaStyle { at: edit::paragraph_start(doc, pi), style: ParaStyle { cartouche: Some(look), ..doc.paragraphs[pi].style.clone() } })
                .collect();
            (ops, CartoucheDone::Restyled)
        } else {
            // Jusqu'au premier tableau rencontré.
            let p1 = (p0..=p1).take_while(|&pi| doc.paragraphs[pi].style.table_cell.is_none()).last().unwrap_or(p0);
            // Les paragraphes deviennent les lignes du cartouche.
            let mut runs: Vec<Run> = Vec::new();
            for pi in p0..=p1 {
                if pi > p0 && !runs.is_empty() {
                    runs.push(Run::plain(LINE_BREAK));
                }
                for r in &doc.paragraphs[pi].runs {
                    match runs.last_mut() {
                        Some(last) if last.style == r.style && r.style.image.is_none() && last.style.image.is_none() => last.text.push_str(&r.text),
                        _ if r.text.is_empty() && r.style.image.is_none() => {}
                        _ => runs.push(r.clone()),
                    }
                }
            }
            let first = &doc.paragraphs[p0].style;
            let id = doc.paragraphs.iter().filter_map(|p| p.style.table_cell).map(|c| c.table + 1).max().unwrap_or(1);
            let cell = Paragraph {
                style: ParaStyle {
                    table_cell: Some(letters_core::TableCell { table: id, row: 0, col: 0 }),
                    cartouche: Some(look),
                    alignment: first.alignment,
                    line_numbers: first.line_numbers,
                    ..Default::default()
                },
                runs,
            };
            let mut insert = vec![cell];
            // Un paragraphe après le cartouche, pour continuer à écrire.
            if doc.paragraphs.get(p1 + 1).is_none_or(|p| p.style.table_cell.is_some()) {
                insert.push(Paragraph::default());
            }
            // Et avant, s'il ouvre le document ou suit un tableau.
            if p0 == 0 || doc.paragraphs[p0 - 1].style.table_cell.is_some() {
                insert.insert(0, Paragraph::default());
            }
            (vec![Op::SetParagraphs { para: p0, remove: p1 - p0 + 1, insert }], CartoucheDone::Wrapped)
        }
    };
    m.apply_user_ops(buf, &ops, false);
    drop(m);
    crate::live::sync_actions(buf);
    done
}

/// Le cartouche sous le curseur redevient du texte simple. `false` hors
/// d'un cartouche.
pub fn remove_cartouche(buf: &gtk::TextBuffer) -> bool {
    let Some(live) = crate::live::of(buf) else { return false };
    let at = buf.iter_at_mark(&buf.get_insert()).offset().max(0) as usize;
    let mut m = live.borrow_mut();
    let seq = m.sequence_offset(buf, at);
    let ops = {
        let doc = m.document(buf);
        let Some((pi, _)) = edit::locate(doc, seq) else { return false };
        let Some(range) = cartouche_range(doc, pi) else { return false };
        // Chaque ligne du cartouche redevient un paragraphe.
        let insert: Vec<Paragraph> = doc.paragraphs[range.clone()]
            .iter()
            .flat_map(|p| {
                let style = ParaStyle { alignment: p.style.alignment, line_numbers: p.style.line_numbers, heading: p.style.heading, ..Default::default() };
                split_lines(&p.runs).into_iter().map(move |runs| Paragraph { style: style.clone(), runs })
            })
            .collect();
        vec![Op::SetParagraphs { para: *range.start(), remove: range.count(), insert }]
    };
    let ok = m.apply_user_ops(buf, &ops, false);
    drop(m);
    crate::live::sync_actions(buf);
    ok
}

/// Le saut de ligne dans un paragraphe (un cartouche à plusieurs lignes).
pub const LINE_BREAK: &str = "\u{2028}";

/// Les runs coupés à chaque saut de ligne.
fn split_lines(runs: &[Run]) -> Vec<Vec<Run>> {
    let mut out: Vec<Vec<Run>> = vec![Vec::new()];
    for r in runs {
        let mut parts = r.text.split('\u{2028}').peekable();
        while let Some(part) = parts.next() {
            if !part.is_empty() || r.style.image.is_some() {
                out.last_mut().expect("une ligne").push(Run { text: part.to_string(), style: r.style.clone() });
            }
            if parts.peek().is_some() {
                out.push(Vec::new());
            }
        }
    }
    out
}

/// Ce qu'Entrée a fait dans un cartouche.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum EnterDone {
    NewLine,
    Left,
}

/// Entrée au curseur, s'il est dans un cartouche : une nouvelle ligne, ou
/// (sur une ligne vide, sans Maj) la sortie du cartouche, le curseur au
/// paragraphe qui suit. None hors d'un cartouche.
pub fn cartouche_enter(buf: &gtk::TextBuffer, shift: bool) -> Option<EnterDone> {
    let it = buf.iter_at_mark(&buf.get_insert());
    let table = buf.tag_table();
    // Le début de la ligne : le texte qu'on vient de taper n'a pas encore
    // l'habillage du cartouche.
    let mut line_start = it;
    line_start.set_line_offset(0);
    let boxed = ["textbox-line", "textbox-white"].iter().filter_map(|n| table.lookup(n)).any(|t| line_start.has_tag(&t));
    if !boxed {
        return None;
    }
    buf.delete_selection(true, true);
    let it = buf.iter_at_mark(&buf.get_insert());
    // La fin du texte visible : avant le « | » caché de la ligne.
    let mut end = it;
    if !end.ends_line() {
        end.forward_to_line_end();
    }
    let rest = buf.text(&it, &end, true).to_string();
    let at_end = rest.trim_end().trim_end_matches('|').trim().is_empty();
    let mut before = it;
    let prev = if before.backward_char() { before.char() } else { '\n' };
    let line_empty = prev == '\u{2028}' || prev == '|' || (prev == ' ' && {
        let mut b2 = before;
        b2.backward_char() && b2.char() == '|'
    });
    if !shift && at_end && line_empty {
        // Sortir : retirer la ligne vide, aller au paragraphe suivant.
        if prev == '\u{2028}' {
            let (mut a, mut b) = (before, buf.iter_at_mark(&buf.get_insert()));
            buf.delete(&mut a, &mut b);
        }
        leave_cartouche(buf);
        return Some(EnterDone::Left);
    }
    buf.insert_interactive_at_cursor(LINE_BREAK, true);
    Some(EnterDone::NewLine)
}

/// Le curseur au paragraphe qui suit le cartouche du curseur (un paragraphe
/// neuf, sauf si celui qui suit est déjà vide).
fn leave_cartouche(buf: &gtk::TextBuffer) {
    let Some(live) = crate::live::of(buf) else { return };
    let caret = buf.iter_at_mark(&buf.get_insert()).offset().max(0) as usize;
    let mut m = live.borrow_mut();
    let seq = m.sequence_offset(buf, caret);
    let (after, ops) = {
        let doc = m.document(buf);
        let Some((pi, _)) = edit::locate(doc, seq) else { return };
        let Some(range) = cartouche_range(doc, pi) else { return };
        let after = *range.end() + 1;
        let empty = doc.paragraphs.get(after).is_some_and(|p| p.style.table_cell.is_none() && p.text().is_empty());
        let ops = if empty { vec![] } else { vec![Op::SetParagraphs { para: after, remove: 0, insert: vec![Paragraph::default()] }] };
        (after, ops)
    };
    if !ops.is_empty() {
        m.apply_user_ops(buf, &ops, false);
    }
    let start = edit::paragraph_start(m.document(buf), after);
    let off = m.buffer_offset(buf, start);
    drop(m);
    if let Some(off) = off {
        buf.place_cursor(&buf.iter_at_offset(off as i32));
    }
    crate::live::sync_actions(buf);
}
