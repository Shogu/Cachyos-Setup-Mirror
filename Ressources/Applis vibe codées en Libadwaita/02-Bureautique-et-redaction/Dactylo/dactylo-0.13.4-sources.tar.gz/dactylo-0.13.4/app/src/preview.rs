// preview.rs — aperçu des pages, tel que le PDF les montrera.
// SPDX-License-Identifier: GPL-3.0-or-later

use std::cell::Cell;
use std::rc::Rc;

use gtk4::{self as gtk, prelude::*};
use libadwaita::{self as adw, prelude::*};
use letters_core::layout::{pango::Typeset, LayoutOptions};

pub fn show(parent: &impl IsA<gtk::Widget>, doc: letters_core::Document, title: &str) {
    let typeset = Rc::new(Typeset::new(doc, LayoutOptions::default()));
    let pages: Vec<(f64, f64)> = typeset.tree().pages.iter().map(|p| (p.width_pt, p.height_pt)).collect();
    let n = pages.len();

    // 1 point = 1,333 px à 100 % ; on démarre à 75 %.
    let scale = Rc::new(Cell::new(1.0_f64));
    let column = gtk::Box::new(gtk::Orientation::Vertical, 24);
    column.set_margin_top(24);
    column.set_margin_bottom(24);
    column.set_halign(gtk::Align::Center);
    let mut areas = Vec::new();
    for (i, (w, h)) in pages.iter().copied().enumerate() {
        let area = gtk::DrawingArea::new();
        area.add_css_class("samizdat-preview-page");
        let (ts, sc) = (typeset.clone(), scale.clone());
        area.set_draw_func(move |_, cr, aw, ah| {
            cr.set_source_rgb(1.0, 1.0, 1.0);
            cr.rectangle(0.0, 0.0, aw as f64, ah as f64);
            let _ = cr.fill();
            let s = sc.get() * 96.0 / 72.0;
            cr.scale(s, s);
            ts.draw_page(cr, i);
        });
        let label = gtk::Label::new(Some(&format!("Page {} sur {n}", i + 1)));
        label.add_css_class("dim-label");
        label.add_css_class("caption");
        let b = gtk::Box::new(gtk::Orientation::Vertical, 6);
        b.append(&area);
        b.append(&label);
        column.append(&b);
        areas.push((area, w, h));
    }
    let areas = Rc::new(areas);
    let resize = {
        let (areas, scale) = (areas.clone(), scale.clone());
        move || {
            let s = scale.get() * 96.0 / 72.0;
            for (a, w, h) in areas.iter() {
                a.set_content_width((w * s) as i32);
                a.set_content_height((h * s) as i32);
                a.queue_draw();
            }
        }
    };
    let resize = Rc::new(resize);
    resize();

    let scroller = gtk::ScrolledWindow::builder().child(&column).vexpand(true).hexpand(true).build();
    scroller.add_css_class("samizdat-desk");

    let zoom_label = gtk::Label::builder().label("100 %").width_chars(6).build();
    zoom_label.add_css_class("numeric");
    let minus = gtk::Button::from_icon_name("list-remove-symbolic");
    let plus = gtk::Button::from_icon_name("list-add-symbolic");
    minus.set_tooltip_text(Some("Réduire"));
    plus.set_tooltip_text(Some("Agrandir"));
    for b in [&minus, &plus] {
        b.add_css_class("flat");
    }
    let zoom_box = gtk::Box::new(gtk::Orientation::Horizontal, 0);
    zoom_box.append(&minus);
    zoom_box.append(&zoom_label);
    zoom_box.append(&plus);
    let step = {
        let (scale, resize, zoom_label) = (scale.clone(), resize.clone(), zoom_label.clone());
        move |up: bool| {
            let v = (scale.get() + if up { 0.25 } else { -0.25 }).clamp(0.25, 3.0);
            scale.set(v);
            zoom_label.set_text(&format!("{} %", (v * 100.0).round()));
            resize();
        }
    };
    let step = Rc::new(step);
    {
        let s = step.clone();
        minus.connect_clicked(move |_| s(false));
        let s = step.clone();
        plus.connect_clicked(move |_| s(true));
    }

    let header = adw::HeaderBar::new();
    header.set_title_widget(Some(&adw::WindowTitle::new("Aperçu", &format!("{title} — {n} page{}", if n > 1 { "s" } else { "" }))));
    header.pack_start(&zoom_box);
    let tv = adw::ToolbarView::new();
    tv.add_top_bar(&header);
    tv.set_content(Some(&scroller));
    let dialog = adw::Dialog::builder().title("Aperçu").content_width(900).content_height(1000).child(&tv).build();
    dialog.present(Some(parent));
}
