// window/actions.rs — les actions de la fenêtre et leurs raccourcis.
// SPDX-License-Identifier: GPL-3.0-or-later

use super::*;

impl Window {
    // ---- Actions ---------------------------------------------------------

    pub(super) fn add_actions(self: &Rc<Self>) {
        // Une action s'exécute au prochain temps mort : choisie dans un menu,
        // elle modifiait le texte pendant la fermeture du menu, et la page
        // cessait de se redessiner (jusqu'au prochain redimensionnement).
        let add = |name: &str, f: Box<dyn Fn(&Rc<Self>)>| {
            let a = gio::SimpleAction::new(name, None);
            let w = Rc::downgrade(self);
            let f = Rc::new(f);
            a.connect_activate(move |_, _| {
                let (w, f) = (w.clone(), f.clone());
                glib::idle_add_local_once(move || {
                    if let Some(w) = w.upgrade() {
                        f(&w);
                    }
                });
            });
            self.win.add_action(&a);
        };
        let add_str = |name: &str, f: Box<dyn Fn(&Rc<Self>, String)>| {
            let a = gio::SimpleAction::new(name, Some(glib::VariantTy::STRING));
            let w = Rc::downgrade(self);
            let f = Rc::new(f);
            a.connect_activate(move |_, p| {
                let Some(s) = p.and_then(|v| v.get::<String>()) else { return };
                let (w, f) = (w.clone(), f.clone());
                glib::idle_add_local_once(move || {
                    if let Some(w) = w.upgrade() {
                        f(&w, s);
                    }
                });
            });
            self.win.add_action(&a);
        };
        add("none", Box::new(|_| {}));
        if let Some(a) = self.win.lookup_action("none").and_then(|a| a.downcast::<gio::SimpleAction>().ok()) {
            a.set_enabled(false);
        }
        add("open", Box::new(|w| w.open_dialog()));
        add("close-tab", Box::new(|w| w.close_current_tab()));
        add("focus-mode", Box::new(|w| w.set_focus_mode(!w.focus.get())));
        add("focus-exit", Box::new(|w| w.set_focus_mode(false)));
        if let Some(a) = self.win.lookup_action("focus-exit").and_then(|a| a.downcast::<gio::SimpleAction>().ok()) {
            a.set_enabled(false);
        }
        add_str("open-recent", Box::new(|w, p| {
            if let Some(app) = w.win.application() {
                app.open(&[gio::File::for_path(p)], "");
            }
        }));
        add("clear-recents", Box::new(|w| {
            crate::store::clear_recents();
            w.refresh_recents();
        }));
        add("save", Box::new(|w| w.save(|_| {})));
        add("save-template", Box::new(|w| w.save_template()));
        add("import-templates", Box::new(|w| w.import_templates()));
        add("open-templates", Box::new(|w| w.open_templates_folder()));
        add("save-as", Box::new(|w| w.save_as(|_| {})));
        add("export-pdf", Box::new(|w| w.export_pdf()));
        add("save-both", Box::new(|w| w.save_both()));
        add("export-usb", Box::new(|w| w.export_usb()));
        add("livret", Box::new(|w| w.livret_dialog()));
        add("undo", Box::new(|w| {
            crate::live::undo(&w.buf(), false);
            w.sync_toolbar();
        }));
        add("redo", Box::new(|w| {
            crate::live::undo(&w.buf(), true);
            w.sync_toolbar();
        }));
        add("find", Box::new(|w| match &w.doc().pdf {
            Some(pdf) => pdf.show_search(),
            None => w.search.show(false),
        }));
        add("replace", Box::new(|w| w.search.show(true)));
        add("page-setup", Box::new(|w| crate::dialogs::page_setup(&w.win, &w.buf())));
        add("amenagements", Box::new(|w| w.amenagements_dialog()));
        add("preview", Box::new(|w| crate::preview::show(&w.win, w.typeset_document(), &w.display_name())));
        add("zoom-in", Box::new(|w| w.zoom_step(true)));
        add("zoom-out", Box::new(|w| w.zoom_step(false)));
        add("zoom-reset", Box::new(|w| w.set_zoom(1.0)));
        add("indent-more", Box::new(|w| {
            crate::commands::indent(&w.buf(), true);
            w.after_format();
        }));
        add("indent-less", Box::new(|w| {
            crate::commands::indent(&w.buf(), false);
            w.after_format();
        }));
        add("indent-toggle", Box::new(|w| {
            crate::commands::toggle_indent(&w.buf());
            w.after_format();
        }));
        add("toggle-bullets", Box::new(|w| {
            editor::toggle_list(&w.buf(), ListKind::Bullet);
            w.after_format();
        }));
        add("toggle-numbers", Box::new(|w| {
            editor::toggle_list(&w.buf(), ListKind::Numbered);
            w.after_format();
        }));
        {
            let a = gio::SimpleAction::new_stateful("align", Some(glib::VariantTy::STRING), &"left".to_variant());
            let w = Rc::downgrade(self);
            a.connect_activate(move |a, p| {
                let Some(s) = p.and_then(|v| v.get::<String>()) else { return };
                a.set_state(&s.to_variant());
                let w = w.clone();
                glib::idle_add_local_once(move || {
                    let Some(w) = w.upgrade() else { return };
                    crate::formatting::align_in(&w.buf(), &format!("align-{s}"));
                    w.after_format();
                });
            });
            self.win.add_action(&a);
        }
        {
            let a = gio::SimpleAction::new_stateful("line-spacing", Some(glib::VariantTy::STRING), &"1".to_variant());
            let w = Rc::downgrade(self);
            a.connect_activate(move |a, p| {
                let Some(s) = p.and_then(|v| v.get::<String>()) else { return };
                let Ok(v) = s.parse::<f32>() else { return };
                a.set_state(&s.to_variant());
                let w = w.clone();
                glib::idle_add_local_once(move || {
                    let Some(w) = w.upgrade() else { return };
                    crate::commands::restyle(&w.buf(), |st| letters_core::ParaStyle { line_spacing: v, ..st.clone() });
                    w.after_format();
                });
            });
            self.win.add_action(&a);
        }
        add("insert-toc", Box::new(|w| w.insert_toc()));
        add("toggle-outline", Box::new(|w| w.split.set_show_sidebar(!w.split.shows_sidebar())));
        add("insert-image", Box::new(|w| w.insert_image_dialog()));
        add("insert-link", Box::new(|w| crate::dialogs::link(&w.win, &w.buf())));
        add("insert-textbox", Box::new(|w| crate::dialogs::table_editor(&w.win, &w.buf(), true)));
        add("cartouche-default", Box::new(|w| w.apply_cartouche(letters_core::Cartouche::default())));
        add("remove-cartouche", Box::new(|w| {
            if crate::commands::remove_cartouche(&w.buf()) {
                w.after_format();
            }
        }));
        add("toggle-line-numbers", Box::new(|w| {
            let at = w.buf().iter_at_mark(&w.buf().get_insert()).offset().max(0) as usize;
            let on = crate::live::of(&w.buf())
                .and_then(|m| m.try_borrow_mut().ok()?.paragraph_style_at(&w.buf(), at))
                .is_some_and(|s| s.line_numbers);
            crate::commands::restyle(&w.buf(), |st| letters_core::ParaStyle { line_numbers: !on, ..st.clone() });
            w.after_format();
            w.toast(if on { "Lignes non numérotées" } else { "Lignes numérotées de 5 en 5 dans la marge (aperçu, PDF, DOCX)" });
        }));
        add("insert-table", Box::new(|w| {
            // Le curseur dans un tableau : on le modifie plutôt.
            crate::dialogs::table_editor(&w.win, &w.buf(), false);
        }));
        add("edit-table", Box::new(|w| {
            if crate::commands::table_at_caret(&w.buf()).is_none() {
                w.toast("Placez le curseur dans un tableau");
                return;
            }
            crate::dialogs::table_editor(&w.win, &w.buf(), false);
        }));
        add("insert-frise", Box::new(|w| w.frise_dialog(false)));
        add("edit-frise", Box::new(|w| w.frise_dialog(true)));
        add("image-properties", Box::new(|w| {
            let (t, o) = (Rc::downgrade(w), Rc::downgrade(w));
            crate::dialogs::image(
                &w.win,
                &w.buf(),
                move |msg| {
                    if let Some(t) = t.upgrade() {
                        t.toast(msg);
                    }
                },
                move |path, offset| {
                    if let Some(o) = o.upgrade() {
                        o.ocr_image(path, offset);
                    }
                },
            );
        }));
        add_str("spell-replace", Box::new(|w, arg| {
            let mut it = arg.splitn(3, '|');
            let (Some(a), Some(b), Some(s)) = (it.next().and_then(|v| v.parse().ok()), it.next().and_then(|v| v.parse().ok()), it.next()) else { return };
            crate::commands::replace_ranges(&w.buf(), &[(a, b)], s);
            w.after_format();
        }));
        add_str("spell-add", Box::new(|w, word| {
            w.doc().spell.add_word(&word);
            w.doc().spell.check_buffer(&w.buf());
        }));
        {
            use crate::commands::TableEdit;
            let table_actions: [(&str, fn() -> TableEdit); 6] = [
                ("table-row-above", || TableEdit::RowAbove),
                ("table-row-below", || TableEdit::RowBelow),
                ("table-col-left", || TableEdit::ColLeft),
                ("table-col-right", || TableEdit::ColRight),
                ("table-delete-row", || TableEdit::DeleteRow),
                ("table-delete-col", || TableEdit::DeleteCol),
            ];
            for (name, what) in table_actions {
                add(
                    name,
                    Box::new(move |w| {
                        if !crate::commands::in_table(&w.buf()) {
                            w.toast("Placez le curseur dans un tableau");
                            return;
                        }
                        crate::commands::table(&w.buf(), what());
                        w.after_format();
                    }),
                );
            }
        }
        for name in ["bold", "italic", "underline", "strikethrough"] {
            add(
                &format!("toggle-{name}"),
                Box::new(move |w| {
                    crate::formatting::toggle_tag_in(&w.buf(), name);
                    w.after_format();
                }),
            );
        }
        for (i, (block, _)) in BLOCK_STYLES.iter().enumerate() {
            let block: BlockStyle = *block;
            add(
                &format!("block-{i}"),
                Box::new(move |w| {
                    editor::set_block_style(&w.buf(), block);
                    w.after_format();
                }),
            );
        }
    }
}

pub fn set_accels(app: &adw::Application) {
    let accels: &[(&str, &[&str])] = &[
        ("app.new", &["<Control>n", "<Control>t"]),
        ("app.new-window", &["<Control><Shift>n"]),
        ("win.close-tab", &["<Control>w"]),
        ("app.quit", &["<Control>q"]),
        ("win.open", &["<Control>o"]),
        ("win.save", &["<Control>s"]),
        ("win.save-as", &["<Control><Shift>s"]),
        ("win.export-pdf", &["<Control>e"]),
        ("win.undo", &["<Control>z"]),
        ("win.redo", &["<Control><Shift>z", "<Control>y"]),
        ("win.toggle-bold", &["<Control>b"]),
        ("win.toggle-italic", &["<Control>i"]),
        ("win.toggle-underline", &["<Control>u"]),
        ("win.find", &["<Control>f"]),
        ("win.replace", &["<Control>h"]),
        ("app.preferences", &["<Control>comma"]),
        ("win.focus-mode", &["F11"]),
        ("win.focus-exit", &["Escape"]),
        ("win.toggle-outline", &["F9"]),
        ("win.live-preview", &["F12"]),
        ("win.ruler", &["<Control>r"]),
        ("win.insert-link", &["<Control>k"]),
        ("win.zoom-in", &["<Control>plus", "<Control>equal", "<Control>KP_Add"]),
        ("win.zoom-out", &["<Control>minus", "<Control>KP_Subtract"]),
        ("win.zoom-reset", &["<Control>0"]),
        ("win.block-1", &["<Control>1"]),
        ("win.block-2", &["<Control>2"]),
        ("win.block-3", &["<Control>3"]),
        ("window.close", &["<Control><Shift>w"]),
    ];
    for (action, keys) in accels {
        app.set_accels_for_action(action, keys);
    }
}
