// spell.rs — vérification orthographique en français (Hunspell).
//
// Les mots inconnus sont soulignés d'une vague rouge (balise de présentation
// « spelling-error », que le modèle ignore). Clic droit sur un mot souligné :
// suggestions et « Ajouter au dictionnaire » (dictionnaire personnel dans
// ~/.local/share/samizdat/dictionnaire.txt).
// SPDX-License-Identifier: GPL-3.0-or-later

use std::cell::{Cell, RefCell};
use std::collections::HashSet;
use std::ffi::{c_char, c_int, c_void, CStr, CString};
use std::rc::Rc;

use gtk4::{self as gtk, glib, prelude::*};

#[link(name = "hunspell-1.7")]
extern "C" {
    fn Hunspell_create(affpath: *const c_char, dpath: *const c_char) -> *mut c_void;
    fn Hunspell_destroy(h: *mut c_void);
    fn Hunspell_spell(h: *mut c_void, word: *const c_char) -> c_int;
    fn Hunspell_suggest(h: *mut c_void, slst: *mut *mut *mut c_char, word: *const c_char) -> c_int;
    fn Hunspell_free_list(h: *mut c_void, slst: *mut *mut *mut c_char, n: c_int);
    fn Hunspell_add(h: *mut c_void, word: *const c_char) -> c_int;
}

/// Un dictionnaire Hunspell chargé.
pub struct Dictionary {
    h: *mut c_void,
}

impl Drop for Dictionary {
    fn drop(&mut self) {
        unsafe { Hunspell_destroy(self.h) };
    }
}

impl Dictionary {
    /// Le dictionnaire français installé (paquet hunspell-fr).
    pub fn french() -> Option<Self> {
        for base in [
            "/usr/share/hunspell/fr_FR",
            "/usr/share/myspell/dicts/fr_FR",
            "/usr/share/hunspell/fr",
            "/usr/share/myspell/fr_FR",
        ] {
            let (aff, dic) = (format!("{base}.aff"), format!("{base}.dic"));
            if std::path::Path::new(&aff).exists() && std::path::Path::new(&dic).exists() {
                let (a, d) = (CString::new(aff).ok()?, CString::new(dic).ok()?);
                let h = unsafe { Hunspell_create(a.as_ptr(), d.as_ptr()) };
                if !h.is_null() {
                    return Some(Self { h });
                }
            }
        }
        None
    }

    pub fn check(&self, word: &str) -> bool {
        let Ok(w) = CString::new(word) else { return true };
        unsafe { Hunspell_spell(self.h, w.as_ptr()) != 0 }
    }

    pub fn suggest(&self, word: &str) -> Vec<String> {
        let Ok(w) = CString::new(word) else { return Vec::new() };
        let mut list: *mut *mut c_char = std::ptr::null_mut();
        let n = unsafe { Hunspell_suggest(self.h, &mut list, w.as_ptr()) };
        let mut out = Vec::new();
        for i in 0..n.max(0) {
            let p = unsafe { *list.add(i as usize) };
            if !p.is_null() {
                out.push(unsafe { CStr::from_ptr(p) }.to_string_lossy().to_string());
            }
        }
        if n > 0 {
            unsafe { Hunspell_free_list(self.h, &mut list, n) };
        }
        out
    }

    pub fn add(&self, word: &str) {
        if let Ok(w) = CString::new(word) {
            unsafe { Hunspell_add(self.h, w.as_ptr()) };
        }
    }
}

fn personal_path() -> std::path::PathBuf {
    glib::user_data_dir().join(crate::DIR).join("dictionnaire.txt")
}

/// Les mots d'un texte : (début, fin) en caractères, et le mot.
/// Lettres, apostrophes et traits d'union internes (« aujourd'hui »,
/// « peut-être »).
pub fn words(text: &str) -> Vec<(usize, usize, String)> {
    let chars: Vec<char> = text.chars().collect();
    let mut out = Vec::new();
    let mut i = 0;
    while i < chars.len() {
        if !chars[i].is_alphabetic() {
            i += 1;
            continue;
        }
        let start = i;
        while i < chars.len() {
            let c = chars[i];
            let joiner = matches!(c, '\'' | '’' | '-') && chars.get(i + 1).is_some_and(|n| n.is_alphabetic());
            if c.is_alphabetic() || joiner {
                i += 1;
            } else {
                break;
            }
        }
        // Un mot collé à des chiffres (« 2e », « A4 ») n'est pas vérifié.
        let glued = (start > 0 && chars[start - 1].is_ascii_digit()) || chars.get(i).is_some_and(|c| c.is_ascii_digit());
        if !glued {
            out.push((start, i, chars[start..i].iter().collect()));
        }
    }
    out
}

/// Le dictionnaire et le dictionnaire personnel, chargés une fois et
/// partagés par tous les documents ouverts.
struct Lexicon {
    dict: Option<Dictionary>,
    personal: RefCell<HashSet<String>>,
}

thread_local! {
    static LEXICON: Rc<Lexicon> = {
        let dict = Dictionary::french();
        let personal: HashSet<String> = std::fs::read_to_string(personal_path())
            .map(|s| s.lines().map(str::trim).filter(|l| !l.is_empty()).map(str::to_string).collect())
            .unwrap_or_default();
        if let Some(d) = &dict {
            for w in &personal {
                d.add(w);
            }
        }
        Rc::new(Lexicon { dict, personal: RefCell::new(personal) })
    };
}

/// La vérification d'un document (tampon).
pub struct Checker {
    lex: Rc<Lexicon>,
    pub enabled: Cell<bool>,
    pending: Cell<bool>,
    /// Lignes (paragraphes) modifiées depuis la dernière vérification.
    dirty: Cell<Option<(i32, i32)>>,
}

/// Au-delà, on revérifie tout le tampon (chargement, collage d'un long
/// texte).
const MAX_DIRTY_LINES: i32 = 200;

impl Checker {
    pub fn new() -> Rc<Self> {
        Rc::new(Self { lex: LEXICON.with(Rc::clone), enabled: Cell::new(true), pending: Cell::new(false), dirty: Cell::new(None) })
    }

    pub fn available(&self) -> bool {
        self.lex.dict.is_some()
    }

    /// Le mot est-il correct ? Les élisions (« l'homme », « qu'il ») sont
    /// vérifiées partie par partie si le mot entier est inconnu.
    pub fn correct(&self, word: &str) -> bool {
        let Some(d) = &self.lex.dict else { return true };
        if word.chars().count() < 2 || self.lex.personal.borrow().contains(word) {
            return true;
        }
        // Sigles et mots en capitales : laissés tranquilles.
        if word.chars().all(|c| !c.is_lowercase()) {
            return true;
        }
        if d.check(word) || d.check(&word.replace('’', "'")) {
            return true;
        }
        let w = word.replace('’', "'");
        if let Some((head, tail)) = w.split_once('\'') {
            return d.check(&format!("{head}'")) && (tail.is_empty() || self.correct(tail));
        }
        false
    }

    pub fn suggestions(&self, word: &str) -> Vec<String> {
        self.lex.dict.as_ref().map(|d| d.suggest(word)).unwrap_or_default().into_iter().take(6).collect()
    }

    pub fn add_word(&self, word: &str) {
        if let Some(d) = &self.lex.dict {
            d.add(word);
        }
        if self.lex.personal.borrow_mut().insert(word.to_string()) {
            let path = personal_path();
            if let Some(dir) = path.parent() {
                let _ = std::fs::create_dir_all(dir);
            }
            let mut words: Vec<String> = self.lex.personal.borrow().iter().cloned().collect();
            words.sort();
            let _ = std::fs::write(path, words.join("\n") + "\n");
        }
    }

    /// Les mots fautifs de tout le tampon et leur première suggestion :
    /// (début, fin, remplacement), et ceux restés sans suggestion. Les
    /// mots soulignés (noms propres exclus, comme pour le soulignement).
    pub fn corrections(&self, buf: &gtk::TextBuffer) -> (Vec<(i32, i32, String)>, usize) {
        let (mut fixes, mut left) = (Vec::new(), 0);
        if !self.available() {
            return (fixes, left);
        }
        let text = buf.slice(&buf.start_iter(), &buf.end_iter(), true);
        let chars: Vec<char> = text.chars().collect();
        for (a, b, w) in words(&text) {
            let capital = w.chars().next().is_some_and(char::is_uppercase);
            let sentence_start = chars[..a].iter().rev().find(|c| !c.is_whitespace()).is_none_or(|c| matches!(c, '.' | '!' | '?' | '…' | ':' | '\n' | '•' | '\t'));
            if (capital && !sentence_start) || self.correct(&w) {
                continue;
            }
            match self.suggestions(&w).into_iter().next() {
                Some(s) => fixes.push((a as i32, b as i32, s)),
                None => left += 1,
            }
        }
        (fixes, left)
    }

    /// Souligne les mots inconnus de tout le tampon.
    pub fn check_buffer(&self, buf: &gtk::TextBuffer) {
        self.dirty.set(None);
        let (s, e) = buf.bounds();
        self.check_range(buf, s, e);
    }

    /// Souligne les mots inconnus des lignes `from..=to`.
    fn check_lines(&self, buf: &gtk::TextBuffer, from: i32, to: i32) {
        let start = buf.iter_at_line(from.max(0)).unwrap_or_else(|| buf.start_iter());
        let mut end = buf.iter_at_line(to.max(0)).unwrap_or_else(|| buf.end_iter());
        if !end.ends_line() {
            end.forward_to_line_end();
        }
        self.check_range(buf, start, end);
    }

    fn check_range(&self, buf: &gtk::TextBuffer, s: gtk::TextIter, e: gtk::TextIter) {
        let modified = buf.is_modified();
        buf.remove_tag_by_name("spelling-error", &s, &e);
        if self.enabled.get() && self.available() {
            let base = s.offset();
            let text = buf.slice(&s, &e, true);
            let chars: Vec<char> = text.chars().collect();
            for (a, b, w) in words(&text) {
                // Majuscule au milieu d'une phrase : sans doute un nom propre.
                let capital = w.chars().next().is_some_and(char::is_uppercase);
                let sentence_start = chars[..a].iter().rev().find(|c| !c.is_whitespace()).is_none_or(|c| matches!(c, '.' | '!' | '?' | '…' | ':' | '\n' | '•' | '\t'));
                if capital && !sentence_start {
                    continue;
                }
                if !self.correct(&w) {
                    buf.apply_tag_by_name("spelling-error", &buf.iter_at_offset(base + a as i32), &buf.iter_at_offset(base + b as i32));
                }
            }
        }
        buf.set_modified(modified);
    }

    fn mark_dirty(&self, from: i32, to: i32) {
        let (a, b) = match self.dirty.get() {
            Some((a, b)) => (a.min(from), b.max(to)),
            None => (from, to),
        };
        self.dirty.set(Some((a, b)));
    }

    /// Note les paragraphes que chaque modification du tampon touche : seuls
    /// ceux-là sont revérifiés.
    pub fn track(self: &Rc<Self>, buf: &gtk::TextBuffer) {
        let me = Rc::downgrade(self);
        buf.connect_insert_text(move |_, at, text| {
            if let Some(me) = me.upgrade() {
                let line = at.line();
                me.mark_dirty(line, line + text.matches('\n').count() as i32);
            }
        });
        let me = Rc::downgrade(self);
        buf.connect_delete_range(move |_, s, _| {
            if let Some(me) = me.upgrade() {
                me.mark_dirty(s.line(), s.line());
            }
        });
        let me = Rc::downgrade(self);
        buf.connect_insert_paintable(move |_, at, _| {
            if let Some(me) = me.upgrade() {
                me.mark_dirty(at.line(), at.line());
            }
        });
    }

    /// Vérifie au prochain temps mort ce qui vient de changer.
    pub fn schedule(self: &Rc<Self>, buf: &gtk::TextBuffer) {
        if self.pending.replace(true) {
            return;
        }
        let (me, buf) = (Rc::downgrade(self), buf.clone());
        glib::timeout_add_local_once(std::time::Duration::from_millis(350), move || {
            if let Some(me) = me.upgrade() {
                me.pending.set(false);
                if crate::live::is_busy(&buf) {
                    // Le modèle écrit encore : on repassera.
                    me.schedule(&buf);
                    return;
                }
                match me.dirty.take() {
                    Some((a, b)) if b - a <= MAX_DIRTY_LINES => me.check_lines(&buf, a - 1, b + 1),
                    Some(_) => me.check_buffer(&buf),
                    None => {}
                }
            }
        });
    }

    /// Le mot souligné sous la position `iter`, avec ses bornes.
    pub fn misspelled_at(&self, buf: &gtk::TextBuffer, iter: &gtk::TextIter) -> Option<(i32, i32, String)> {
        let tag = buf.tag_table().lookup("spelling-error")?;
        if !iter.has_tag(&tag) {
            let mut before = *iter;
            if !(before.backward_char() && before.has_tag(&tag)) {
                return None;
            }
            return self.misspelled_at(buf, &before);
        }
        let mut s = *iter;
        if !s.starts_tag(Some(&tag)) {
            s.backward_to_tag_toggle(Some(&tag));
        }
        let mut e = *iter;
        e.forward_to_tag_toggle(Some(&tag));
        Some((s.offset(), e.offset(), buf.text(&s, &e, false).to_string()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn split_words() {
        let w: Vec<String> = words("L'homme, aujourd'hui : peut-être 2e A4.").into_iter().map(|x| x.2).collect();
        assert_eq!(w, vec!["L'homme", "aujourd'hui", "peut-être"]);
    }
}
