// livret.rs — le livret de séquence : plusieurs documents (DOCX, ODT, PDF…)
// en un seul PDF, avec une page de garde, un sommaire et les pages
// numérotées.
// SPDX-License-Identifier: GPL-3.0-or-later

use std::path::{Path, PathBuf};

use gtk4::cairo;
use letters_core::layout::pango::Typeset;
use letters_core::layout::LayoutOptions;
use letters_core::{Alignment, Document, Paragraph, ParaStyle, Run, RunStyle};
use pangocairo::pango;

/// Les réglages du livret.
#[derive(Clone, Debug)]
pub struct Options {
    pub title: String,
    pub cover: bool,
    pub contents: bool,
    pub numbers: bool,
}

/// Un document du livret, mis en page.
enum Part {
    Text(Box<Typeset>),
    Pdf(crate::pdfview::Document),
}

impl Part {
    fn pages(&self) -> usize {
        match self {
            Part::Text(t) => t.tree().pages.len(),
            Part::Pdf(d) => d.page_count(),
        }
    }

    fn size(&self, i: usize) -> (f64, f64) {
        match self {
            Part::Text(t) => t.tree().pages.get(i).map_or((595.28, 841.89), |p| (p.width_pt, p.height_pt)),
            Part::Pdf(d) => d.size(i),
        }
    }

    fn draw(&self, cr: &cairo::Context, i: usize) {
        match self {
            Part::Text(t) => t.draw_page(cr, i),
            Part::Pdf(d) => d.render(i, cr),
        }
    }
}

/// Les fichiers qu'un livret peut réunir.
pub fn accepts(path: &Path) -> bool {
    let ext = path.extension().map(|e| e.to_string_lossy().to_lowercase()).unwrap_or_default();
    matches!(ext.as_str(), "docx" | "odt" | "md" | "txt" | "pdf")
}

/// Les documents d'un dossier, dans l'ordre des noms (« Séance 2 » avant
/// « Séance 10 ») ; un PDF qui a son DOCX ou son ODT à côté n'y est pas
/// deux fois.
pub fn folder_documents(dir: &Path) -> Vec<PathBuf> {
    let Ok(rd) = std::fs::read_dir(dir) else { return Vec::new() };
    let all: Vec<PathBuf> = rd.flatten().map(|e| e.path()).filter(|p| p.is_file() && accepts(p)).collect();
    let stem = |p: &Path| p.file_stem().map(|s| s.to_string_lossy().to_lowercase()).unwrap_or_default();
    let mut out: Vec<PathBuf> = all
        .iter()
        .filter(|p| {
            let is_pdf = p.extension().is_some_and(|e| e.eq_ignore_ascii_case("pdf"));
            !is_pdf || !all.iter().any(|q| q != *p && stem(q) == stem(p) && !q.extension().is_some_and(|e| e.eq_ignore_ascii_case("pdf")))
        })
        .cloned()
        .collect();
    out.sort_by_key(|p| natural_key(&p.file_name().map(|n| n.to_string_lossy().to_lowercase()).unwrap_or_default()));
    out
}

/// Une clé de tri où les nombres comptent pour leur valeur.
fn natural_key(s: &str) -> Vec<(String, u64)> {
    let mut out = Vec::new();
    let (mut text, mut num) = (String::new(), String::new());
    for c in s.chars() {
        if c.is_ascii_digit() {
            num.push(c);
        } else {
            if !num.is_empty() {
                out.push((std::mem::take(&mut text), num.parse().unwrap_or(0)));
                num.clear();
            }
            text.push(c);
        }
    }
    out.push((text, num.parse().unwrap_or(0)));
    out
}

/// Le nom d'un document dans le sommaire : son premier Titre 1, sinon le
/// nom du fichier.
fn entry_name(path: &Path, doc: Option<&Document>) -> String {
    doc.and_then(|d| d.paragraphs.iter().find(|p| p.style.heading == Some(1) && p.style.table_cell.is_none()).map(|p| p.text().replace('\u{2028}', " ")))
        .filter(|t| !t.trim().is_empty())
        .unwrap_or_else(|| path.file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_default())
}

fn a4(paragraphs: Vec<Paragraph>, family: &str) -> Document {
    let mut d = Document::new();
    let cm = 72.0 / 2.54;
    d.page = Some(letters_core::PageGeometry { width_pt: 595.28, height_pt: 841.89, margin_top_pt: 2.5 * cm, margin_bottom_pt: 2.0 * cm, margin_left_pt: 2.0 * cm, margin_right_pt: 2.0 * cm, columns: 1, ..Default::default() });
    d.base_font = letters_core::model::BaseFont { family: Some(family.to_string()), size_hp: Some(26) };
    d.paragraphs = paragraphs;
    d
}

fn styled(text: &str, hp: u16, bold: bool, color: &str) -> Run {
    Run { text: text.into(), style: RunStyle { bold, font_size_hp: Some(hp), color: Some(color.into()), ..Default::default() } }
}

/// La page de garde.
fn cover(title: &str, family: &str) -> Document {
    let centered = |runs: Vec<Run>, before: f64, after: f64| Paragraph { style: ParaStyle { alignment: Alignment::Center, space_before_pt: before, space_after_pt: after, ..Default::default() }, runs };
    let p = vec![
        centered(vec![styled("LIVRET DE SÉQUENCE", 24, true, "5E5C64")], 160.0, 18.0),
        centered(vec![styled(title, 52, true, "1A5FB4")], 0.0, 40.0),
    ];
    a4(p, family)
}

/// Le sommaire : un document par ligne, sa page dans le livret.
fn contents(entries: &[(String, usize)], family: &str) -> Document {
    let mut p = vec![Paragraph { style: ParaStyle { space_after_pt: 24.0, ..Default::default() }, runs: vec![styled("Sommaire", 44, true, "1A5FB4")] }];
    for (name, page) in entries {
        p.push(Paragraph {
            style: ParaStyle { toc: Some(1), space_after_pt: 8.0, ..Default::default() },
            runs: vec![Run::plain(format!("{name}\t{page}"))],
        });
    }
    a4(p, family)
}

/// Fabrique le livret `out` à partir de `files`. `prepare` met chaque
/// document en forme comme l'aperçu (police de l'éditeur, aménagements) ;
/// `tint` : une ligne sur deux teintée. Rend le nombre de pages.
pub fn build(files: &[PathBuf], o: &Options, family: &str, prepare: &dyn Fn(&mut Document), tint: bool, out: &Path) -> Result<usize, String> {
    let mut parts: Vec<(String, Part)> = Vec::new();
    for f in files {
        let is_pdf = f.extension().is_some_and(|e| e.eq_ignore_ascii_case("pdf"));
        if is_pdf {
            let d = crate::pdfview::Document::open(f).map_err(|e| format!("{} : {e}", f.display()))?;
            parts.push((entry_name(f, None), Part::Pdf(d)));
        } else {
            let mut d = letters_core::save::read(f).map_err(|e| format!("{} : {e}", f.display()))?;
            let name = entry_name(f, Some(&d));
            prepare(&mut d);
            let mut t = Typeset::new(d, LayoutOptions::default());
            t.set_alternate_tint(tint);
            parts.push((name, Part::Text(Box::new(t))));
        }
    }
    if parts.is_empty() {
        return Err("Aucun document dans le livret.".into());
    }
    let mut front: Vec<Part> = Vec::new();
    if o.cover {
        front.push(Part::Text(Box::new(Typeset::new(cover(&o.title, family), LayoutOptions::default()))));
    }
    if o.contents {
        // Deux passes : le sommaire peut tenir sur plusieurs pages.
        let mut pages = 1;
        for _ in 0..3 {
            let mut at = front.iter().map(Part::pages).sum::<usize>() + pages + 1;
            let entries: Vec<(String, usize)> = parts.iter().map(|(n, p)| {
                let e = (n.clone(), at);
                at += p.pages();
                e
            }).collect();
            let t = Typeset::new(contents(&entries, family), LayoutOptions::default());
            if t.tree().pages.len() == pages {
                front.push(Part::Text(Box::new(t)));
                break;
            }
            pages = t.tree().pages.len();
        }
    }
    let all: Vec<&Part> = front.iter().chain(parts.iter().map(|(_, p)| p)).collect();
    let total: usize = all.iter().map(|p| p.pages()).sum();
    let (w0, h0) = all[0].size(0);
    let surface = cairo::PdfSurface::new(w0, h0, out).map_err(|e| format!("{} : {e}", out.display()))?;
    let cr = cairo::Context::new(&surface).map_err(|e| e.to_string())?;
    let mut n = 0;
    for part in &all {
        for i in 0..part.pages() {
            n += 1;
            let (w, h) = part.size(i);
            surface.set_size(w, h).map_err(|e| e.to_string())?;
            let _ = cr.save();
            part.draw(&cr, i);
            let _ = cr.restore();
            if o.numbers && n > 1 {
                page_number(&cr, family, n, total, w, h);
            }
            cr.show_page().map_err(|e| e.to_string())?;
        }
    }
    drop(cr);
    surface.finish();
    surface.status().map_err(|e| e.to_string())?;
    Ok(total)
}

/// Le numéro de page du livret, dans le coin bas droit.
fn page_number(cr: &cairo::Context, family: &str, n: usize, total: usize, w: f64, h: f64) {
    let layout = pangocairo::functions::create_layout(cr);
    let mut d = pango::FontDescription::new();
    d.set_family(family);
    d.set_absolute_size(9.0 * pango::SCALE as f64);
    layout.set_font_description(Some(&d));
    layout.set_text(&format!("{n} / {total}"));
    let (_, r) = layout.pixel_extents();
    let _ = cr.save();
    cr.set_source_rgb(0.37, 0.36, 0.39);
    cr.move_to(w - 28.0 - r.width() as f64, h - 22.0);
    pangocairo::functions::show_layout(cr, &layout);
    let _ = cr.restore();
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn documents_of_a_folder_in_natural_order_without_duplicate_pdfs() {
        let dir = std::env::temp_dir().join(format!("samizdat-livret-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        for f in ["Séance 10.docx", "Séance 2.docx", "Séance 2.pdf", "Carte.pdf", "notes.png"] {
            std::fs::write(dir.join(f), b"x").unwrap();
        }
        let names: Vec<String> = folder_documents(&dir).iter().map(|p| p.file_name().unwrap().to_string_lossy().to_string()).collect();
        assert_eq!(names, ["Carte.pdf", "Séance 2.docx", "Séance 10.docx"]);
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn a_livret_has_cover_contents_and_documents() {
        let dir = std::env::temp_dir().join(format!("samizdat-livret2-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let mut d = Document::new();
        d.paragraphs = vec![Paragraph { style: ParaStyle { heading: Some(1), ..Default::default() }, runs: vec![Run::plain("Séance 1")] }];
        let a = dir.join("a.docx");
        letters_core::save::write(&d, &a).unwrap();
        let out = dir.join("livret.pdf");
        let o = Options { title: "La Grande Guerre".into(), cover: true, contents: true, numbers: true };
        let n = build(&[a.clone(), a], &o, "Sans", &|_| {}, false, &out).unwrap();
        assert_eq!(n, 4);
        assert!(std::fs::metadata(&out).unwrap().len() > 1000);
        let _ = std::fs::remove_dir_all(dir);
    }
}
