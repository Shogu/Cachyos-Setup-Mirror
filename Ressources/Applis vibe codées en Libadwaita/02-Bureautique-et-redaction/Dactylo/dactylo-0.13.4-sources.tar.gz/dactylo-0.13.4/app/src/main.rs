// Dactylo (ex Samizdat) — traitement de texte GTK4/libadwaita bâti sur letters-core.
// SPDX-License-Identifier: GPL-3.0-or-later

mod amenagements;
mod bridge;
mod commands;
mod dialogs;
mod prefs;
mod pdfview;
mod preview;
mod ruler;
mod resize;
mod retouch;
mod shapes;
mod spell;
mod store;
mod web;
mod search;
mod editor;
mod formatting;
mod frise;
mod live;
mod livepreview;
mod livret;
mod modele;
mod ocr;
mod window;
mod zoom;

use std::rc::Rc;

use gtk4::{self as gtk, gio, glib, prelude::*};
use libadwaita::{self as adw, prelude::*};

const APP_ID: &str = "io.gitlab.shogu.Dactylo";
/// Nom des dossiers personnels (~/.config, ~/.local/share, ~/.cache).
pub const DIR: &str = "dactylo";
/// L'ancien nom de l'appli : ses dossiers sont repris au premier lancement.
const OLD_DIR: &str = "samizdat";
/// Les types de documents que Dactylo ouvre (boîte « Ouvrir »). Les .doc et
/// .rtf sont lus par letters_core::legacy (AbiWord s'il est installé).
pub const MIME_TYPES: [&str; 13] = [
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.ms-word.document.macroEnabled.12",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.template",
    "application/vnd.ms-word.template.macroEnabled.12",
    "application/vnd.oasis.opendocument.text",
    "application/vnd.oasis.opendocument.text-template",
    "application/msword",
    "application/msword-template",
    "application/rtf",
    "text/rtf",
    "text/markdown",
    "text/plain",
    "application/pdf",
];

/// Samizdat est devenu Dactylo : on renomme ses dossiers (préférences,
/// fichiers récents, modèles, dictionnaire, cache) s'il n'y a encore rien
/// sous le nouveau nom. Sans effet ensuite.
fn migrate_old_dirs() {
    for base in [glib::user_config_dir(), glib::user_data_dir(), glib::user_cache_dir()] {
        let (old, new) = (base.join(OLD_DIR), base.join(DIR));
        if old.is_dir() && !new.exists() {
            if let Err(e) = std::fs::rename(&old, &new) {
                glib::g_warning!("dactylo", "Reprise de {} impossible : {e}", old.display());
            }
        }
    }
}
const VERSION: &str = env!("CARGO_PKG_VERSION");

const CSS: &str = "
splitbutton.samizdat-on > button:first-child { background-color: alpha(currentColor, 0.1); }
/* L'aperçu en direct par-dessus le texte (fenêtre étroite) : opaque. */
.samizdat-live.overlaid { background-color: @window_bg_color; box-shadow: -2px 0 8px alpha(black, 0.15); }
.samizdat-desk { background-color: alpha(@window_fg_color, 0.06); }
/* Mode concentration : tout l'écran est la page, blanche, sans bord. */
window.samizdat-zen, window.samizdat-zen .samizdat-desk { background-color: #ffffff; }
window.samizdat-zen textview.samizdat-page { box-shadow: none; border-radius: 0; }
/* La page reste une feuille blanche, même en mode sombre : les couleurs
   du document (texte noir, surlignage…) sont absolues. */
textview.samizdat-page {
  font-size: 12pt;
  color: #1e1e1e;
  caret-color: #1e1e1e;
  border-radius: 6px;
  box-shadow: 0 1px 3px alpha(black, 0.18), 0 0 0 1px alpha(black, 0.06);
}
textview.samizdat-page, textview.samizdat-page text { background-color: #ffffff; }
/* Sélection : le bleu d'accent franc, texte blanc. */
textview.samizdat-page text selection { background-color: @accent_bg_color; color: @accent_fg_color; }
label.samizdat-highlight-label {
  background-color: #f8e45c; color: #1e1e1e;
  border-radius: 3px; padding: 0 4px; font-weight: bold;
}
button.samizdat-swatch { padding: 3px; min-width: 0; min-height: 0; }
/* Aperçu d'une image retouchée : damier pour voir les coins transparents. */
button.samizdat-focus-exit { opacity: 0.35; transition: opacity 200ms; }
button.samizdat-focus-exit:hover { opacity: 1; }
picture.samizdat-checker { background-color: alpha(@window_fg_color, 0.08); border-radius: 8px; }
button.samizdat-cartouche { padding: 2px; }
button.samizdat-cartouche.samizdat-current { background-color: alpha(@accent_bg_color, 0.25); }
";

/// Propose de récupérer les copies de secours d'une session interrompue :
/// chacune revient dans un onglet de la fenêtre `w`.
fn offer_recovery(w: &Rc<window::Window>) {
    let pending = store::pending_recoveries();
    if pending.is_empty() {
        return;
    }
    let n = pending.len();
    let body = if n == 1 {
        "Un document n'a pas été enregistré lors de la dernière session. Le récupérer ?".to_string()
    } else {
        format!("{n} documents n'ont pas été enregistrés lors de la dernière session. Les récupérer ?")
    };
    let d = adw::AlertDialog::new(Some("Récupérer des documents ?"), Some(&body));
    d.add_responses(&[("forget", "Ne pas récupérer"), ("restore", "Récupérer")]);
    d.set_response_appearance("forget", adw::ResponseAppearance::Destructive);
    d.set_response_appearance("restore", adw::ResponseAppearance::Suggested);
    d.set_default_response(Some("restore"));
    d.set_close_response("restore");
    let w = w.clone();
    d.choose(Some(&w.win.clone()), gtk::gio::Cancellable::NONE, move |resp| {
        if resp == "restore" {
            for r in &pending {
                w.restore(r);
            }
        } else {
            for r in &pending {
                store::forget_recovery(r);
            }
        }
    });
}

/// La fenêtre où ouvrir : l'active, sinon une nouvelle.
fn target_window(app: &adw::Application) -> Rc<window::Window> {
    window::active(app).unwrap_or_else(|| {
        let w = window::create(app, true);
        w.present();
        w
    })
}

fn main() -> glib::ExitCode {
    migrate_old_dirs();
    let app = adw::Application::builder()
        .application_id(APP_ID)
        .flags(gio::ApplicationFlags::HANDLES_OPEN)
        .build();

    gio::resources_register_include!("samizdat.gresource").expect("ressources Dactylo");
    app.connect_startup(|app| {
        if let Some(display) = gtk::gdk::Display::default() {
            gtk::IconTheme::for_display(&display).add_resource_path("/io/gitlab/shogu/Samizdat/icons");
        }
        let provider = gtk::CssProvider::new();
        provider.load_from_string(CSS);
        if let Some(display) = gtk::gdk::Display::default() {
            gtk::style_context_add_provider_for_display(&display, &provider, gtk::STYLE_PROVIDER_PRIORITY_APPLICATION);
        }
        window::set_accels(app);
    });

    {
        let checked = std::rc::Rc::new(std::cell::Cell::new(false));
        app.connect_activate(move |app| {
            let w = window::create(app, true);
            w.present();
            // Au premier lancement : documents laissés par un plantage ?
            if !checked.replace(true) {
                offer_recovery(&w);
            }
        });
    }
    // Fichiers ouverts (Fichiers, récents, glisser-déposer) : en onglets.
    app.connect_open(|app, files, _| {
        let w = target_window(app);
        for file in files {
            w.open_file(file);
        }
        w.present();
    });

    {
        // Nouveau document à partir d'un modèle (chemin en paramètre).
        let a = gio::SimpleAction::new("new-from-template", Some(glib::VariantTy::STRING));
        let app2 = app.downgrade();
        a.connect_activate(move |_, p| {
            let (Some(app), Some(path)) = (app2.upgrade(), p.and_then(|v| v.get::<String>())) else { return };
            let w = target_window(&app);
            w.load_template(std::path::Path::new(&path));
            w.present();
        });
        app.add_action(&a);
    }

    {
        // Préférences : appliquées aussitôt aux documents qui suivent la
        // police par défaut.
        let a = gio::SimpleAction::new("preferences", None);
        let app2 = app.downgrade();
        a.connect_activate(move |_, _| {
            let Some(win) = app2.upgrade().and_then(|a| a.active_window()) else { return };
            prefs::dialog(&win, move || {
                for w in window::all_windows() {
                    w.preferences_changed();
                }
            });
        });
        app.add_action(&a);
    }

    let actions: [(&str, Box<dyn Fn(&adw::Application)>); 4] = [
        // Nouveau document : un onglet de la fenêtre active.
        ("new", Box::new(|app: &adw::Application| {
            let w = target_window(app);
            w.add_blank_tab();
            if let Some(t) = prefs::get().start_template.filter(|t| std::path::Path::new(t).is_file()) {
                w.load_template(std::path::Path::new(&t));
            }
            w.present();
        })),
        ("new-window", Box::new(|app: &adw::Application| window::create(app, true).present())),
        ("quit", Box::new(|app: &adw::Application| {
            for w in app.windows() {
                w.close();
            }
        })),
        ("about", Box::new(|app: &adw::Application| {
            let about = adw::AboutDialog::builder()
                .application_name("Dactylo")
                .application_icon(APP_ID)
                .version(VERSION)
                .developer_name("Shogu")
                .license_type(gtk::License::Gpl30)
                .comments("Traitement de texte simple pour GNOME, bâti sur letters-core (gtk-office-suite).")
                .website("https://gitlab.com/shogu")
                .build();
            about.add_credit_section(Some("Moteur de documents"), &["letters-core — projet gtk-office-suite (tuna-os) https://github.com/tuna-os/gtk-office-suite"]);
            if let Some(win) = app.active_window() {
                about.present(Some(&win));
            }
        })),
    ];
    for (name, f) in actions {
        let a = gio::SimpleAction::new(name, None);
        let app2 = app.downgrade();
        a.connect_activate(move |_, _| {
            if let Some(app) = app2.upgrade() {
                f(&app);
            }
        });
        app.add_action(&a);
    }

    app.run()
}
