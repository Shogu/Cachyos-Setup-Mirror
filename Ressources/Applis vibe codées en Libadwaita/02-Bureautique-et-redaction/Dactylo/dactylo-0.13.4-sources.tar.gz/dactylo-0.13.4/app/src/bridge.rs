#![allow(dead_code)]
// bridge.rs — GtkTextBuffer ⇄ letters_core::Document.
// Repris tel quel de gtk-office-suite (letters/src/bridge.rs), tests retirés.
// SPDX-License-Identifier: GPL-3.0-or-later
//
// The buffer is a *view*: letters-core owns document semantics and all file
// I/O. This module is the only place buffer tags are translated to/from
// model styles. Tag names map 1:1 to RunStyle fields / heading levels
// (see register_formatting_tags in window.rs).
//
// Links use dynamic "link:<url>" tags; alignment uses the align-* tags;
// list kinds translate to/from the editor's "•" / "N." markers (letters_core::lists).

use gtk4::{self as gtk, prelude::*};
use letters_core::model::{Document, PageGeometry, Paragraph, Run, RunStyle};

const RUN_TAGS: [&str; 8] = ["bold", "italic", "underline", "strikethrough", "highlight", "code", "superscript", "subscript"];

/// The formatting tags a run with `style` is drawn with. The one mapping
/// from model to buffer: render and paste both use it, so a style can't be
/// drawn by one and dropped by the other (super/subscript were in the model
/// and in every reader and writer, and drawn by neither).
pub(crate) fn run_tag_names(style: &RunStyle) -> Vec<&'static str> {
    let mut names = Vec::new();
    if style.bold { names.push("bold"); }
    if style.italic { names.push("italic"); }
    if style.underline { names.push("underline"); }
    if style.strikethrough { names.push("strikethrough"); }
    if style.highlight && style.highlight_color.is_none() { names.push("highlight"); }
    if style.code { names.push("code"); }
    match style.vert_align {
        Some(letters_core::model::VertAlign::Superscript) => names.push("superscript"),
        Some(letters_core::model::VertAlign::Subscript) => names.push("subscript"),
        None => {}
    }
    names
}

/// Every tag a run with `style` is drawn with: the fixed formatting tags,
/// plus the per-value ones for a link, a font family, a size and a colour,
/// created on first use. Render and paste both use it.
///
/// Family, size and colour used to have no tags at all, so every one of
/// them was dropped on the way into the editor and was gone on the next
/// save: a docx with red 18pt headings came back black and default-sized.
pub(crate) fn run_tags(buf: &gtk::TextBuffer, style: &RunStyle) -> Vec<String> {
    let mut names: Vec<String> = run_tag_names(style).into_iter().map(str::to_string).collect();
    let table = buf.tag_table();
    let mut dynamic = |name: String, build: &dyn Fn(gtk::TextTag)| {
        if table.lookup(&name).is_none() {
            let tag = gtk::TextTag::builder().name(&name).build();
            build(tag.clone());
            table.add(&tag);
        }
        names.push(name);
    };
    if let Some(url) = &style.link {
        dynamic(format!("{LINK_TAG_PREFIX}{url}"), &|t| {
            t.set_foreground(Some("#1a5fb4"));
            t.set_underline(gtk4::pango::Underline::Single);
        });
    }
    if let Some(family) = &style.font_family {
        let family = family.clone();
        dynamic(format!("{FONT_TAG_PREFIX}{family}"), &move |t| t.set_family(Some(&family)));
    }
    if let Some(hp) = style.font_size_hp {
        dynamic(format!("{SIZE_TAG_PREFIX}{hp}"), &move |t| t.set_size_points(f64::from(hp) / 2.0));
    }
    if let Some(color) = &style.color {
        let hex = format!("#{}", color.trim_start_matches('#'));
        dynamic(format!("{COLOR_TAG_PREFIX}{}", color.trim_start_matches('#')), &move |t| t.set_foreground(Some(&hex)));
    }
    if let (true, Some(hl)) = (style.highlight, &style.highlight_color) {
        let hex = format!("#{}", hl.trim_start_matches('#'));
        dynamic(format!("{HL_TAG_PREFIX}{}", hl.trim_start_matches('#')), &move |t| {
            t.set_background(Some(&hex));
            t.set_foreground(Some("#1e1e1e"));
        });
    }
    if let Some(rev) = &style.revision {
        names.push(revision_tag(buf, rev));
    }
    for id in &style.comments {
        names.push(comment_tag(buf, *id));
    }
    names
}

/// A comment's tag, "comment:ID": the text is tinted while its thread is
/// open (`set_comments` clears the tint of a resolved one).
fn comment_tag(buf: &gtk::TextBuffer, id: u32) -> String {
    let name = format!("{COMMENT_TAG_PREFIX}{id}");
    if buf.tag_table().lookup(&name).is_none() {
        let tag = gtk::TextTag::builder().name(&name).build();
        let resolved = comments_sidecar(buf).iter().any(|c| c.id == id && c.resolved);
        tint_comment(&tag, !resolved);
        buf.tag_table().add(&tag);
    }
    name
}

fn tint_comment(tag: &gtk::TextTag, on: bool) {
    let tint = gtk4::gdk::RGBA::new(0.98, 0.76, 0.1, 0.3);
    tag.set_background_rgba(on.then_some(&tint));
}

/// The comments on the char at `iter`.
fn comments_at(iter: &gtk::TextIter) -> Vec<u32> {
    let mut ids: Vec<u32> = iter.tags().into_iter().filter_map(|t| t.name()?.strip_prefix(COMMENT_TAG_PREFIX)?.parse().ok()).collect();
    ids.sort_unstable();
    ids
}

/// A tracked change's tag: "rev:" and the revision as JSON (author and
/// date are free text), drawn as the page draws it (track::author_color).
fn revision_tag(buf: &gtk::TextBuffer, rev: &letters_core::Revision) -> String {
    let name = format!("{REVISION_TAG_PREFIX}{}", serde_json::to_string(rev).expect("a revision serializes"));
    if buf.tag_table().lookup(&name).is_none() {
        let tag = gtk::TextTag::builder().name(&name).foreground(letters_core::track::author_hex(&rev.author)).build();
        match rev.kind {
            letters_core::RevisionKind::Insert => tag.set_underline(gtk4::pango::Underline::Single),
            letters_core::RevisionKind::Delete => tag.set_strikethrough(true),
        }
        buf.tag_table().add(&tag);
    }
    name
}

/// The tracked change on the char at `iter`, if any.
fn revision_at(iter: &gtk::TextIter) -> Option<letters_core::Revision> {
    iter.tags().into_iter().find_map(|t| {
        let name = t.name()?;
        serde_json::from_str(name.strip_prefix(REVISION_TAG_PREFIX)?).ok()
    })
}

/// Tag an object's char (or chip label) at `start..end` with the marks
/// objects take: its tracked change and its comments.
fn tag_object(buf: &gtk::TextBuffer, start: i32, end: &gtk::TextIter, style: &RunStyle) {
    let names = style.revision.iter().map(|rev| revision_tag(buf, rev)).chain(style.comments.iter().map(|id| comment_tag(buf, *id)));
    for name in names.collect::<Vec<_>>() {
        buf.apply_tag_by_name(&name, &buf.iter_at_offset(start), end);
    }
}

const LINK_TAG_PREFIX: &str = "link:";
const FONT_TAG_PREFIX: &str = "font:";
const SIZE_TAG_PREFIX: &str = "size-hp:";
const COLOR_TAG_PREFIX: &str = "color:";
/// Samizdat : surlignage de couleur (« hl:RRGGBB »).
const HL_TAG_PREFIX: &str = "hl:";
const REVISION_TAG_PREFIX: &str = "rev:";
const COMMENT_TAG_PREFIX: &str = "comment:";

/// Read a per-value tag back into `style`. Inverse of `run_tags`.
fn apply_dynamic_tag(name: &str, style: &mut RunStyle) {
    if let Some(url) = name.strip_prefix(LINK_TAG_PREFIX) {
        style.link = Some(url.to_string());
    } else if let Some(family) = name.strip_prefix(FONT_TAG_PREFIX) {
        style.font_family = Some(family.to_string());
    } else if let Some(hp) = name.strip_prefix(SIZE_TAG_PREFIX).and_then(|v| v.parse().ok()) {
        style.font_size_hp = Some(hp);
    } else if let Some(color) = name.strip_prefix(COLOR_TAG_PREFIX) {
        style.color = Some(color.to_string());
    } else if let Some(hl) = name.strip_prefix(HL_TAG_PREFIX) {
        style.highlight = true;
        style.highlight_color = Some(hl.to_string());
    } else if let Some(json) = name.strip_prefix(REVISION_TAG_PREFIX) {
        style.revision = serde_json::from_str(json).ok();
    } else if let Some(id) = name.strip_prefix(COMMENT_TAG_PREFIX).and_then(|v| v.parse::<u32>().ok()) {
        if let Err(i) = style.comments.binary_search(&id) {
            style.comments.insert(i, id);
        }
    }
}

/// GtkTextTag name for a discrete line-spacing multiplier — reuses the
/// same "line-spacing-1.0"/"1.15"/"1.5"/"2.0" tags window.rs's
/// register_formatting_tags already registers and its cycle-line-spacing
/// action already applies live; this just makes the choice persist
/// through Document/DOCX/ODT instead of being GTK-buffer-only. `None`
/// for the default single spacing (1.0 — no tag needed on render, mirrors
/// `Alignment::Left`); capture still recognizes an explicit
/// "line-spacing-1.0" tag if present (the live-editing action applies
/// one for that case too), mapping it back to 1.0 all the same.
fn line_spacing_tag_name(spacing: f32) -> Option<&'static str> {
    if (spacing - 1.15).abs() < 0.01 {
        Some("line-spacing-1.15")
    } else if (spacing - 1.5).abs() < 0.01 {
        Some("line-spacing-1.5")
    } else if (spacing - 2.0).abs() < 0.01 {
        Some("line-spacing-2.0")
    } else {
        None
    }
}

/// Inverse of [`line_spacing_tag_name`] — covers "line-spacing-1.0" too
/// (captured back as 1.0, same as no tag) since the live-editing action
/// applies it explicitly for the default case.
fn line_spacing_from_tag_name(name: &str) -> Option<f32> {
    match name {
        "line-spacing-1.0" => Some(1.0),
        "line-spacing-1.15" => Some(1.15),
        "line-spacing-1.5" => Some(1.5),
        "line-spacing-2.0" => Some(2.0),
        _ => None,
    }
}

/// Rebuild a Document from the buffer's text and tags.
pub fn capture_from_buffer(buf: &gtk::TextBuffer) -> Document {
    capture_with_starts(buf).0
}

/// `capture_from_buffer`, plus where each captured paragraph's text starts
/// in the buffer (a char offset, after any list marker or table pipe).
/// With `buffer_offset`/`paragraph_offset` it maps a place in the document
/// to a buffer offset and back: how the page view edits the buffer.
pub fn capture_with_starts(buf: &gtk::TextBuffer) -> (Document, Vec<usize>) {
    let (mut paragraphs, mut starts) = capture_span(buf, 0, buf.char_count().max(0));
    // Footnotes, header, footer and page geometry are document state that has
    // no representation in the text buffer, so they ride on the buffer itself
    // (set by render/insert) rather than being reconstructed from the text.
    // Returning `None` for them here — as this function used to — discarded
    // them on every save, because `save_buffer_to_path` writes exactly the
    // Document this returns and both the ODT and DOCX writers emit all three
    // (#438).
    capture_tables(&mut paragraphs, &mut starts, 1);
    let mut doc = Document { paragraphs, ..Document::new() };
    read_sidecars(buf, &mut doc);
    if let (Some(style), Some(last)) = (trailing_style(buf), doc.paragraphs.last_mut()) {
        if last.runs.is_empty() && last.style == letters_core::ParaStyle::default() {
            last.style = style;
        }
    }
    (doc, starts)
}

/// Buffer data key holding the style of an empty last paragraph.
const TRAILING_KEY: &str = "letters-trailing-style";

/// Keep the style of `doc`'s last paragraph beside the buffer when that
/// paragraph is empty (#1278). An empty paragraph's tags cover its
/// terminating newline, but the last paragraph has none: GTK cannot tag
/// an empty range, so a heading, page break or spacing set on an empty
/// last line was gone from the next capture, which is what a save writes.
/// Render and every live-model change set it; capture reads it back.
pub(crate) fn set_trailing_style(buf: &gtk::TextBuffer, doc: &Document) {
    let style = doc
        .paragraphs
        .last()
        .filter(|p| p.runs.iter().all(|r| r.text.is_empty() && r.style == RunStyle::default()))
        .filter(|p| p.style.table_cell.is_none() && p.style != letters_core::ParaStyle::default())
        .map(|p| p.style.clone());
    // SAFETY: stored and read back as the same type, under this key only.
    unsafe { buf.set_data(TRAILING_KEY, style) };
}

fn trailing_style(buf: &gtk::TextBuffer) -> Option<letters_core::ParaStyle> {
    // SAFETY: only ever set by set_trailing_style, with this type.
    unsafe { buf.data::<Option<letters_core::ParaStyle>>(TRAILING_KEY).and_then(|p| p.as_ref().clone()) }
}

/// The paragraphs of whole buffer lines from offset `from` (a line start)
/// to `to` (a line end), and where each one's text starts, without folding
/// table rows into cells: `capture_with_starts` does that for the whole
/// buffer, and the live model uses this for the lines an edit touched.
pub(crate) fn capture_span(buf: &gtk::TextBuffer, from: i32, to: i32) -> (Vec<Paragraph>, Vec<usize>) {
    let table = buf.tag_table();
    let run_tags: Vec<(usize, gtk::TextTag)> = RUN_TAGS
        .iter()
        .enumerate()
        .filter_map(|(i, n)| table.lookup(n).map(|t| (i, t)))
        .collect();
    let heading_tags: Vec<(u8, gtk::TextTag)> = (1u8..=6)
        .filter_map(|l| table.lookup(&format!("h{l}")).map(|t| (l, t)))
        .collect();

    let style_at = |iter: &gtk::TextIter| -> RunStyle {
        let mut s = RunStyle::default();
        for (i, tag) in &run_tags {
            if iter.has_tag(tag) {
                match RUN_TAGS[*i] {
                    "bold" => s.bold = true,
                    "italic" => s.italic = true,
                    "underline" => s.underline = true,
                    "strikethrough" => s.strikethrough = true,
                    "highlight" => s.highlight = true,
                    "code" => s.code = true,
                    "superscript" => s.vert_align = Some(letters_core::model::VertAlign::Superscript),
                    "subscript" => s.vert_align = Some(letters_core::model::VertAlign::Subscript),
                    _ => unreachable!(),
                }
            }
        }
        // Links, fonts, sizes and colours use one tag per value.
        for tag in iter.tags() {
            if let Some(name) = tag.name() {
                apply_dynamic_tag(&name, &mut s);
            }
        }
        s
    };

    let align_tags: Vec<(letters_core::Alignment, gtk::TextTag)> = [
        (letters_core::Alignment::Center, "align-center"),
        (letters_core::Alignment::Right, "align-right"),
        (letters_core::Alignment::Justify, "align-justify"),
    ]
    .into_iter()
    .filter_map(|(a, n)| table.lookup(n).map(|t| (a, t)))
    .collect();

    let page_break_tag = table.lookup(PAGE_BREAK_TAG);

    let line_spacing_tags: Vec<(f32, gtk::TextTag)> =
        ["line-spacing-1.15", "line-spacing-1.5", "line-spacing-2.0", "line-spacing-1.0"]
            .into_iter()
            .filter_map(|n| table.lookup(n).map(|t| (line_spacing_from_tag_name(n).unwrap(), t)))
            .collect();

    let mut paragraphs: Vec<Paragraph> = Vec::new();
    let mut current = Paragraph::default();
    let mut current_run: Option<Run> = None;
    let mut at_line_start = true;
    let mut line_list_level: Option<u8> = None;
    let mut starts: Vec<usize> = Vec::new();
    let mut line_start = 0usize;

    let mut iter = buf.iter_at_offset(from);
    // An empty line ending the span still has its style read at its end,
    // as a whole-buffer capture reads it at that line's newline.
    while !iter.is_end() && (iter.offset() < to || (at_line_start && iter.offset() == to)) {
        if at_line_start {
            line_start = iter.offset().max(0) as usize;
            for (level, tag) in &heading_tags {
                if iter.has_tag(tag) {
                    current.style.heading = Some(*level);
                    break;
                }
            }
            for (align, tag) in &align_tags {
                if iter.has_tag(tag) {
                    current.style.alignment = *align;
                    break;
                }
            }
            for (spacing, tag) in &line_spacing_tags {
                if iter.has_tag(tag) {
                    current.style.line_spacing = *spacing;
                    break;
                }
            }
            // A page break is paragraph state with no text of its own. It
            // rides on a tag for the same reason headings and alignment
            // do: anything written into the text would be indistinguishable
            // from a user typing the same characters, and capture would
            // have to guess. Without this the break was lost on the next
            // capture, so it never reached a saved DOCX or ODT.
            if let Some(tag) = &page_break_tag {
                if iter.has_tag(tag) {
                    current.style.page_break_before = true;
                }
            }
            line_list_level = iter.tags().iter().find_map(|t| t.name().and_then(|n| list_level_from_tag_name(&n)));
            for tag in iter.tags() {
                if let Some(name) = tag.name() {
                    apply_para_tag_name(&name, &mut current.style);
                }
            }
            at_line_start = false;
            if iter.offset() >= to {
                break;
            }
        }
        // Embedded images appear as the object-replacement char; the source
        // path and alt text ride on the paintable itself (see render side).
        if let Some(paintable) = iter.paintable() {
            let src: Option<String> = unsafe {
                paintable.data::<String>("letters-image-src").map(|p| p.as_ref().clone())
            };
            let alt: String = unsafe {
                paintable.data::<String>("letters-image-alt")
                    .map(|p| p.as_ref().clone()).unwrap_or_default()
            };
            let extent: Option<(u64, u64)> = unsafe {
                paintable.data::<Option<(u64, u64)>>("letters-image-extent").and_then(|p| *p.as_ref())
            };
            if let Some(src) = src {
                if let Some(r) = current_run.take() {
                    current.runs.push(r);
                }
                current.runs.push(Run {
                    text: alt,
                    style: RunStyle { image: Some(src), image_extent_emu: extent, revision: revision_at(&iter), comments: comments_at(&iter), ..Default::default() },
                });
                iter.forward_char();
                continue;
            }
        }
        // A smart chip is its label under one "chip:KIND:VALUE" tag: one
        // object run, however many chars the label takes in the buffer.
        let chip = iter.tags().into_iter().find_map(|t| {
            let chip = parse_chip_tag(t.name()?.as_str())?;
            Some((t, chip))
        });
        if let Some((tag, chip)) = chip {
            if let Some(r) = current_run.take() {
                current.runs.push(r);
            }
            let mut label = String::new();
            let (revision, comments) = (revision_at(&iter), comments_at(&iter));
            while !iter.is_end() && iter.char() != '\n' && iter.has_tag(&tag) {
                label.push(iter.char());
                iter.forward_char();
            }
            let mut run = letters_core::chips::chip_run(chip, label);
            run.style.revision = revision;
            run.style.comments = comments;
            current.runs.push(run);
            continue;
        }
        // Footnote markers carry an "fnref:N" tag; the visible "[n]"
        // text is presentation only — capture emits a reference run.
        let fn_idx = iter.tags().iter().find_map(|t| {
            t.name()
                .and_then(|n| n.strip_prefix("fnref:").map(str::to_string))
                .and_then(|v| v.parse::<usize>().ok())
        });
        if let Some(idx) = fn_idx {
            if let Some(r) = current_run.take() {
                current.runs.push(r);
            }
            current.runs.push(Run {
                text: String::new(),
                style: RunStyle { footnote: Some(idx), revision: revision_at(&iter), comments: comments_at(&iter), ..Default::default() },
            });
            while !iter.is_end()
                && iter.tags().iter().any(|t| {
                    t.name().map(|n| n.starts_with("fnref:")).unwrap_or(false)
                })
            {
                iter.forward_char();
            }
            continue;
        }
        let ch = iter.char();
        if ch == '\n' {
            if let Some(r) = current_run.take() {
                current.runs.push(r);
            }
            let marker = capture_list_marker(&mut current, line_list_level);
            starts.push(line_start + marker);
            paragraphs.push(std::mem::take(&mut current));
            at_line_start = true;
        } else {
            let style = style_at(&iter);
            match &mut current_run {
                Some(r) if r.style == style => r.text.push(ch),
                _ => {
                    if let Some(r) = current_run.take() {
                        current.runs.push(r);
                    }
                    current_run = Some(Run { text: ch.to_string(), style });
                }
            }
        }
        iter.forward_char();
    }
    if let Some(r) = current_run.take() {
        current.runs.push(r);
    }
    if at_line_start {
        // An empty last line at the very end of the buffer.
        line_start = to.max(0) as usize;
    }
    let marker = capture_list_marker(&mut current, line_list_level);
    starts.push(line_start + marker);
    paragraphs.push(current);
    (paragraphs, starts)
}

/// Chars a run takes in the layout text (an image or footnote reference is
/// one object char) and in the buffer (a footnote reference is its visible
/// "[n]" marker).
fn run_lengths(run: &Run) -> (usize, usize) {
    if run.style.image.is_some() {
        (1, 1)
    } else if run.style.chip.is_some() {
        (1, run.text.chars().count())
    } else if let Some(idx) = run.style.footnote {
        (1, format!("[{}]", idx + 1).chars().count())
    } else {
        let n = run.text.chars().count();
        (n, n)
    }
}

/// The document between buffer offsets `start` and `end`, as a clipboard
/// fragment.
///
/// Buffer offsets are not document offsets: a list item's marker, a
/// table's pipes and a footnote's "[n]" are in the buffer only. Copying
/// used to pass buffer offsets as document offsets, so a selection after a
/// list or a table came out shifted by those characters.
pub fn selection_fragment(buf: &gtk::TextBuffer, start: usize, end: usize) -> letters_core::fragment::Fragment {
    let (doc, starts) = match crate::live::of(buf) {
        Some(m) => m.borrow_mut().snapshot(buf),
        None => capture_with_starts(buf),
    };
    let seq = |off: usize| {
        let (para, offset) = paragraph_offset(&doc, &starts, off);
        letters_core::edit::paragraph_start(&doc, para) + offset
    };
    letters_core::fragment::from_sequence(&doc, seq(start), seq(end))
}

/// Buffer offset of char `offset` of paragraph `para`'s layout text, the
/// paragraph's text starting at buffer offset `start`.
pub fn buffer_offset(para: &Paragraph, start: usize, offset: usize) -> usize {
    let (mut layout, mut buffer) = (0usize, 0usize);
    for run in &para.runs {
        let (l, b) = run_lengths(run);
        if offset < layout + l {
            // Inside this run; text maps char for char.
            return start + buffer + (offset - layout).min(b);
        }
        layout += l;
        buffer += b;
    }
    start + buffer
}

/// The paragraph and layout offset of buffer offset `off`, given the
/// captured paragraphs and their buffer starts. An offset inside a list
/// marker or a table's pipes belongs to the start of the paragraph after it.
pub fn paragraph_offset(doc: &Document, starts: &[usize], off: usize) -> (usize, usize) {
    let i = starts.partition_point(|&s| s <= off).saturating_sub(1);
    let Some(para) = doc.paragraphs.get(i) else { return (0, 0) };
    let start = starts[i];
    if off < start {
        return (i, 0);
    }
    let buffer_len: usize = para.runs.iter().map(|r| run_lengths(r).1).sum();
    if off > start + buffer_len && i + 1 < doc.paragraphs.len() {
        return (i + 1, 0);
    }
    let (mut layout, mut buffer) = (0usize, 0usize);
    for run in &para.runs {
        let (l, b) = run_lengths(run);
        if off - start < buffer + b {
            return (i, layout + (off - start - buffer).min(l));
        }
        layout += l;
        buffer += b;
    }
    (i, layout)
}

/// Fold rendered pipe grids back into table-cell paragraphs.
///
/// A separate pass rather than part of the character walk above: a table
/// is only recognizable once a whole line is known (a row line means
/// nothing until the *next* line proves to be a delimiter), and the walk
/// deliberately knows nothing beyond the character in hand.
///
/// Without this, `render_to_buffer` → `capture_from_buffer` turned every
/// table into literal "| a | b |" prose — which is how a table inserted
/// into the editor used to reach DOCX as text and vanish as a table.
/// `first_id` is the id the first table found gets (tables are numbered in
/// document order; the live model folds a span that starts after others).
pub(crate) fn capture_tables(paragraphs: &mut Vec<Paragraph>, starts: &mut Vec<usize>, first_id: u32) {
    use letters_core::table_text;

    let mut out: Vec<Paragraph> = Vec::with_capacity(paragraphs.len());
    let mut out_starts: Vec<usize> = Vec::with_capacity(starts.len());
    let mut table_id = first_id.saturating_sub(1);
    let mut i = 0;
    while i < paragraphs.len() {
        let header_cells = table_text::parse_row(&paragraphs[i].text());
        let delimiter_ok = paragraphs
            .get(i + 1)
            .is_some_and(|p| table_text::is_delimiter_line(&p.text()));
        let Some(header_cells) = header_cells.filter(|_| delimiter_ok) else {
            out.push(std::mem::take(&mut paragraphs[i]));
            out_starts.push(starts[i]);
            i += 1;
            continue;
        };
        // A table's column count is its header's. A body row with a
        // different count is not part of this table — stopping there keeps
        // the grid rectangular, which every reader of (row, col) assumes.
        let cols = header_cells.len();
        table_id += 1;
        let mut row = 0u32;
        let push_row = |out: &mut Vec<Paragraph>, out_starts: &mut Vec<usize>, para: &Paragraph, start: usize, ranges: &[std::ops::Range<usize>], row: u32| {
            for (col, range) in ranges.iter().enumerate() {
                out_starts.push(start + range.start);
                out.push(Paragraph {
                    style: letters_core::ParaStyle {
                        table_cell: Some(letters_core::TableCell { table: table_id, row, col: col as u32 }),
                        ..Default::default()
                    },
                    runs: table_text::slice_runs(&para.runs, range),
                });
            }
        };
        push_row(&mut out, &mut out_starts, &paragraphs[i], starts[i], &header_cells, row);
        i += 2; // header + delimiter
        while i < paragraphs.len() {
            let Some(ranges) = table_text::parse_row(&paragraphs[i].text()) else { break };
            if ranges.len() != cols || table_text::is_delimiter_line(&paragraphs[i].text()) {
                break;
            }
            // A row followed by a delimiter row is the next table's header:
            // two tables with nothing between them stay two (#1299). Read
            // as this table's body, the header joined it and its delimiter
            // came back as the user's own prose.
            if paragraphs.get(i + 1).is_some_and(|p| table_text::is_delimiter_line(&p.text())) {
                break;
            }
            row += 1;
            push_row(&mut out, &mut out_starts, &paragraphs[i], starts[i], &ranges, row);
            i += 1;
        }
    }
    *paragraphs = out;
    *starts = out_starts;
}

/// GtkTextTag marking a paragraph that starts on a new page. Registered
/// by `register_formatting_tags`, which also gives it the space and rule
/// that make the break visible in the editor.
pub const PAGE_BREAK_TAG: &str = "page-break";

/// Buffer data key holding the document's footnote texts.
pub const FOOTNOTES_KEY: &str = "letters-footnotes";
/// Buffer data key holding the document's header text, if it has one.
pub const HEADER_KEY: &str = "letters-header";
/// Buffer data key holding the document's footer text, if it has one.
pub const FOOTER_KEY: &str = "letters-footer";
/// Buffer data key holding the document's page geometry, if it has one.
pub const PAGE_KEY: &str = "letters-page";
/// Buffer data key holding the document's heading styles.
pub const HEADING_STYLES_KEY: &str = "letters-heading-styles";
/// Buffer data key holding the document's base (body) font.
pub const BASE_FONT_KEY: &str = "letters-base-font";
/// The document's comments (`letters_core::comments`).
pub const COMMENTS_KEY: &str = "letters-comments";

// GObject data is an untyped pointer: reading a key back at a type other than
// the one it was written with is undefined behaviour, not a panic, and no test
// will catch it. So each key gets one reader and the type appears exactly
// once per key — rather than a generic helper any future caller could
// instantiate at the wrong type.
//
// The outer `Option` distinguishes "key never set" (a buffer that was never
// rendered from a Document) from a document that genuinely has no header;
// both flatten to `None`, but only the former is worth keeping separate for
// anyone extending this.

/// Copy the document state that lives beside the buffer's text (footnotes,
/// header, footer, page geometry, base font) from `buf` into `doc`.
pub(crate) fn read_sidecars(buf: &gtk::TextBuffer, doc: &mut Document) {
    doc.footnotes = unsafe { buf.data::<Vec<String>>(FOOTNOTES_KEY).map(|p| p.as_ref().clone()).unwrap_or_default() };
    doc.header = header_sidecar(buf);
    doc.footer = footer_sidecar(buf);
    doc.page = page_sidecar(buf);
    doc.base_font = base_font_sidecar(buf);
    doc.heading_styles = heading_styles_sidecar(buf);
    doc.comments = comments_sidecar(buf);
}

fn comments_sidecar(buf: &gtk::TextBuffer) -> Vec<letters_core::Comment> {
    unsafe { buf.data::<Vec<letters_core::Comment>>(COMMENTS_KEY).map(|p| p.as_ref().clone()).unwrap_or_default() }
}

/// Keep `comments` beside `buf`'s text (the live model's comment ops change
/// them without a buffer edit), and tint only open threads' text.
pub fn set_comments(buf: &gtk::TextBuffer, comments: &[letters_core::Comment]) {
    unsafe { buf.set_data(COMMENTS_KEY, comments.to_vec()) };
    for c in comments.iter().filter(|c| c.parent.is_none()) {
        if let Some(tag) = buf.tag_table().lookup(&format!("{COMMENT_TAG_PREFIX}{}", c.id)) {
            tint_comment(&tag, !c.resolved);
        }
    }
}

fn header_sidecar(buf: &gtk::TextBuffer) -> Option<String> {
    unsafe { buf.data::<Option<String>>(HEADER_KEY).and_then(|p| p.as_ref().clone()) }
}

fn footer_sidecar(buf: &gtk::TextBuffer) -> Option<String> {
    unsafe { buf.data::<Option<String>>(FOOTER_KEY).and_then(|p| p.as_ref().clone()) }
}

fn heading_styles_sidecar(buf: &gtk::TextBuffer) -> Vec<RunStyle> {
    unsafe { buf.data::<Vec<RunStyle>>(HEADING_STYLES_KEY).map(|p| p.as_ref().clone()).unwrap_or_default() }
}

/// Set the body font of the document in `buf`, beside its text.
pub fn set_base_font(buf: &gtk::TextBuffer, base: letters_core::model::BaseFont) {
    unsafe { buf.set_data(BASE_FONT_KEY, base) };
}

fn base_font_sidecar(buf: &gtk::TextBuffer) -> letters_core::model::BaseFont {
    unsafe { buf.data::<letters_core::model::BaseFont>(BASE_FONT_KEY).map(|p| p.as_ref().clone()).unwrap_or_default() }
}

fn page_sidecar(buf: &gtk::TextBuffer) -> Option<PageGeometry> {
    unsafe { buf.data::<Option<PageGeometry>>(PAGE_KEY).and_then(|p| *p.as_ref()) }
}

/// Read the page geometry currently attached to `buf`, if it has one.
pub fn buffer_page_geometry(buf: &gtk::TextBuffer) -> Option<PageGeometry> {
    page_sidecar(buf)
}

/// Read the header/footer currently attached to `buf`.
pub fn buffer_header_footer(buf: &gtk::TextBuffer) -> (Option<String>, Option<String>) {
    (header_sidecar(buf), footer_sidecar(buf))
}

/// Update just the header/footer, leaving the rest of the buffer's document
/// state alone.
///
/// Empty text means "no header", not an empty one: the ODT and DOCX writers
/// both emit a header block for `Some("")`, so treating a cleared entry as
/// `Some("")` would put an empty header into every saved file.
pub fn set_buffer_header_footer(buf: &gtk::TextBuffer, header: &str, footer: &str) {
    let present = |text: &str| (!text.is_empty()).then(|| text.to_string());
    unsafe {
        buf.set_data(HEADER_KEY, present(header));
        buf.set_data(FOOTER_KEY, present(footer));
    }
}

/// Keep `doc`'s header, footer, footnotes and page setup beside `buf`'s
/// text (the live model's ops change them without a buffer edit).
pub fn set_page_furniture(buf: &gtk::TextBuffer, doc: &Document) {
    unsafe {
        buf.set_data(HEADER_KEY, doc.header.clone());
        buf.set_data(FOOTER_KEY, doc.footer.clone());
        buf.set_data(FOOTNOTES_KEY, doc.footnotes.clone());
        buf.set_data(PAGE_KEY, doc.page);
    }
}

/// Attach the document state that the text buffer cannot represent.
///
/// Called by `render_to_buffer`, and by anything else that replaces a
/// buffer's document wholesale, so a later `capture_from_buffer` can put the
/// Document back together.
pub fn set_buffer_sidecars(doc: &Document, buf: &gtk::TextBuffer) {
    unsafe {
        buf.set_data(FOOTNOTES_KEY, doc.footnotes.clone());
        buf.set_data(HEADER_KEY, doc.header.clone());
        buf.set_data(FOOTER_KEY, doc.footer.clone());
        buf.set_data(PAGE_KEY, doc.page);
        buf.set_data(BASE_FONT_KEY, doc.base_font.clone());
        buf.set_data(HEADING_STYLES_KEY, doc.heading_styles.clone());
    }
    set_comments(buf, &doc.comments);
    apply_heading_looks(buf, doc);
}

/// Les titres de l'éditeur prennent l'apparence que le document leur donne
/// (couleur, taille, police), comme dans le PDF, Word et LibreOffice.
fn apply_heading_looks(buf: &gtk::TextBuffer, doc: &Document) {
    let base_pt = doc.base_font.size_hp.map_or(12.0, |hp| f64::from(hp) / 2.0);
    let defaults = [1.6, 1.4, 1.2, 1.1, 1.0, 0.9];
    for (i, default_scale) in defaults.iter().enumerate() {
        let Some(tag) = buf.tag_table().lookup(&format!("h{}", i + 1)) else { continue };
        let look = doc.heading_styles.get(i);
        tag.set_scale(look.and_then(|h| h.font_size_hp).map_or(*default_scale, |hp| f64::from(hp) / 2.0 / base_pt));
        tag.set_foreground(look.and_then(|h| h.color.as_deref()).map(|c| format!("#{c}")).as_deref());
        tag.set_family(look.and_then(|h| h.font_family.as_deref()));
    }
}

const PARA_TAG_PREFIX: &str = "para:";

/// The paragraph properties the fixed tags do not carry, as one tag name:
/// spacing, indents, tab stops, a line spacing no `line-spacing-*` tag
/// names, block quote, code block, named style and a list restart. `None` when the
/// paragraph has none of them.
///
/// Without it all of these were dropped on the way into the editor, so a
/// save wrote the document back without its paragraph spacing and indents,
/// and Print Layout (which reads the document back from the editor) drew
/// every paragraph tight.
fn para_tag_name(style: &letters_core::ParaStyle) -> Option<String> {
    let mut parts: Vec<String> = Vec::new();
    let mut num = |key: &str, v: f64| {
        if v != 0.0 {
            parts.push(format!("{key}={v}"));
        }
    };
    num("b", style.space_before_pt);
    num("a", style.space_after_pt);
    num("l", style.left_indent_pt);
    num("r", style.right_indent_pt);
    num("f", style.first_line_indent_pt);
    if !style.tab_stops_pt.is_empty() {
        let tabs: Vec<String> = style.tab_stops_pt.iter().map(f64::to_string).collect();
        parts.push(format!("t={}", tabs.join(",")));
    }
    if line_spacing_tag_name(style.line_spacing).is_none() && (style.line_spacing - 1.0).abs() > 0.001 {
        parts.push(format!("ls={}", style.line_spacing));
    }
    if style.block_quote {
        parts.push("q".into());
    }
    if let Some(start) = style.list_start {
        parts.push(format!("n={start}"));
    }
    if style.keep_with_next {
        parts.push("k".into());
    }
    if let Some(level) = style.toc {
        parts.push(format!("toc={level}"));
    }
    if style.line_numbers {
        parts.push("ln".into());
    }
    if let Some(lang) = &style.code_block {
        parts.push(format!("c={}", lang.replace(';', "")));
    }
    if let Some(name) = &style.named_style {
        // Last, and the only free text: everything after "s=" is the name.
        parts.push(format!("s={name}"));
    }
    (!parts.is_empty()).then(|| format!("{PARA_TAG_PREFIX}{}", parts.join(";")))
}

/// Read a `para:` tag back into `style`. Inverse of `para_tag_name`.
fn apply_para_tag_name(name: &str, style: &mut letters_core::ParaStyle) {
    let Some(mut rest) = name.strip_prefix(PARA_TAG_PREFIX) else { return };
    while !rest.is_empty() {
        if let Some(named) = rest.strip_prefix("s=") {
            style.named_style = Some(named.to_string());
            return;
        }
        let (part, tail) = rest.split_once(';').unwrap_or((rest, ""));
        rest = tail;
        let (key, value) = part.split_once('=').unwrap_or((part, ""));
        let f = || value.parse::<f64>().ok();
        match key {
            "b" => style.space_before_pt = f().unwrap_or(0.0),
            "a" => style.space_after_pt = f().unwrap_or(0.0),
            "l" => style.left_indent_pt = f().unwrap_or(0.0),
            "r" => style.right_indent_pt = f().unwrap_or(0.0),
            "f" => style.first_line_indent_pt = f().unwrap_or(0.0),
            "t" => style.tab_stops_pt = value.split(',').filter_map(|t| t.parse().ok()).collect(),
            "ls" => style.line_spacing = value.parse().unwrap_or(1.0),
            "q" => style.block_quote = true,
            "k" => style.keep_with_next = true,
            "ln" => style.line_numbers = true,
            "toc" => style.toc = value.parse().ok(),
            "n" => style.list_start = value.parse().ok(),
            "c" => style.code_block = Some(value.to_string()),
            _ => {}
        }
    }
}

/// Create (on first use) the `para:` tag for `style` and return its name.
/// It also draws what it can in the Draft editor: spacing above and below,
/// and — outside lists, whose own tag owns the margin — the indents.
/// Position du numéro de page d'une entrée de table des matières : la
/// largeur du texte d'une page pleine (840 px moins les marges).
const TOC_TAB_PX: i32 = 700;

fn para_tag(buf: &gtk::TextBuffer, style: &letters_core::ParaStyle) -> Option<String> {
    let name = para_tag_name(style)?;
    if buf.tag_table().lookup(&name).is_none() {
        let px = |pt: f64| (pt * 96.0 / 72.0).round() as i32;
        let tag = gtk::TextTag::builder().name(&name).build();
        if style.space_before_pt > 0.0 {
            tag.set_pixels_above_lines(px(style.space_before_pt));
        }
        if style.space_after_pt > 0.0 {
            tag.set_pixels_below_lines(px(style.space_after_pt));
        }
        if style.list == letters_core::ListKind::None {
            if style.left_indent_pt != 0.0 {
                tag.set_left_margin(EDITOR_LEFT_MARGIN_PX + px(style.left_indent_pt));
            }
            if style.first_line_indent_pt != 0.0 {
                tag.set_indent(px(style.first_line_indent_pt));
            }
        }
        if style.right_indent_pt > 0.0 {
            tag.set_right_margin(EDITOR_LEFT_MARGIN_PX + px(style.right_indent_pt));
        }
        // Samizdat : lignes numérotées, un fond bleuté discret.
        if style.line_numbers {
            tag.set_paragraph_background(Some("#eef3fb"));
        }
        // Entrée de table des matières : le numéro de page calé à droite.
        if style.toc.is_some() {
            let mut tabs = gtk4::pango::TabArray::new(1, true);
            tabs.set_tab(0, gtk4::pango::TabAlign::Right, TOC_TAB_PX - px(style.left_indent_pt));
            tag.set_tabs(Some(&tabs));
        }
        buf.tag_table().add(&tag);
    }
    Some(name)
}

/// GtkTextTag name for the list geometry of nesting level `level`.
fn list_level_tag_name(level: u8) -> String {
    format!("list-level-{}", level.min(letters_core::lists::MAX_LEVEL))
}

/// Inverse of [`list_level_tag_name`].
fn list_level_from_tag_name(name: &str) -> Option<u8> {
    name.strip_prefix("list-level-")?.parse().ok()
}

/// The editor's left margin in pixels (`TextView::set_left_margin`). A tag
/// with its own left margin *replaces* the view's, so list indents are
/// measured from this.
pub const EDITOR_LEFT_MARGIN_PX: i32 = 64;

/// Tag giving a list item at `level` its hanging indent: the marker sits at
/// the level's indent, a tab carries the text to the text indent, and
/// wrapped lines line up with the text rather than under the marker.
/// Created on first use, like the `link:` tags. Returns its name.
pub(crate) fn list_level_tag(buf: &gtk::TextBuffer, level: u8) -> String {
    use letters_core::lists;
    let name = list_level_tag_name(level);
    if buf.tag_table().lookup(&name).is_none() {
        // Points to the editor's pixels (GTK's 96 dpi), as fonts are drawn.
        let px = |pt: f64| (pt * 96.0 / 72.0).round() as i32;
        let hang = px(lists::HANGING_PT);
        let marker_x = px(lists::text_indent_pt(level) - lists::HANGING_PT);
        let mut tabs = gtk4::pango::TabArray::new(1, true);
        tabs.set_tab(0, gtk4::pango::TabAlign::Left, hang);
        let tag = gtk::TextTag::builder()
            .name(&name)
            .left_margin(EDITOR_LEFT_MARGIN_PX + marker_x)
            .indent(-hang)
            .tabs(&tabs)
            .build();
        buf.tag_table().add(&tag);
    }
    name
}

/// The editor shows a list item as its marker ("•", "3.") and a tab,
/// followed by the item's text; the model wants `ListKind` and the text
/// alone. Strip the marker and set the kind when capturing.
///
/// `tag_level` is the level carried by the paragraph's `list-level-N` tag.
/// A line without one (typed by hand, or pasted) still counts as a list
/// item when it starts with a marker; then four leading spaces make one
/// nesting level. Markdown's "- " and "N. " are accepted as typed markers.
/// A list marker at the start of an editor line: its kind, the number of
/// leading spaces, the marker's own length in chars (marker and separator),
/// and a numbered item's number.
fn list_marker_prefix(text: &str) -> Option<(letters_core::ListKind, usize, usize, u32)> {
    let indent = text.len() - text.trim_start_matches(' ').len();
    let body = &text[indent..];
    // A marker is followed by a tab (as rendered) or a space (as typed).
    let separated = |rest: &str| rest.starts_with(['\t', ' ']);
    if let Some(rest) = body.strip_prefix(letters_core::lists::BULLET) {
        return separated(rest).then_some((letters_core::ListKind::Bullet, indent, 2, 0));
    }
    if body.starts_with("- ") {
        return Some((letters_core::ListKind::Bullet, indent, 2, 0));
    }
    let digits = body.chars().take_while(|c| c.is_ascii_digit()).count();
    match body[digits..].strip_prefix('.') {
        Some(rest) if digits > 0 && separated(rest) => {
            Some((letters_core::ListKind::Numbered, indent, digits + 2, body[..digits].parse().unwrap_or(0)))
        }
        _ => None,
    }
}

/// Enter at the caret inside a list item: continue the list with the next
/// marker (at the same level), or, on an empty item, end the list by
/// removing that item's marker. `false` when the caret is not in a list
/// item, so Enter does what it always does. Shared by both views.
pub(crate) fn enter_in_list(buf: &gtk::TextBuffer) -> bool {
    let cursor = buf.iter_at_mark(&buf.get_insert());
    let mut line_start = cursor;
    line_start.set_line_offset(0);
    let mut line_end = cursor;
    if !line_end.ends_line() {
        line_end.forward_to_line_end();
    }
    let line = buf.text(&line_start, &line_end, false).to_string();
    let Some((kind, indent, marker, number)) = list_marker_prefix(&line) else { return false };
    // The caret inside the marker itself is not "in the item".
    if (cursor.line_offset() as usize) < indent + marker {
        return false;
    }
    let level_tag = line_start
        .tags()
        .into_iter()
        .find(|t| t.name().is_some_and(|n| list_level_from_tag_name(&n).is_some()));
    let body_empty = line.chars().skip(indent + marker).all(char::is_whitespace);
    buf.begin_user_action();
    if body_empty {
        let mut s = line_start;
        let mut e = line_start;
        e.forward_chars((indent + marker) as i32);
        buf.delete(&mut s, &mut e);
        if let Some(tag) = &level_tag {
            let mut end = buf.iter_at_mark(&buf.get_insert());
            if !end.ends_line() {
                end.forward_to_line_end();
            }
            let mut start = end;
            start.set_line_offset(0);
            buf.remove_tag(tag, &start, &end);
        }
    } else {
        buf.delete_selection(true, true);
        let next = match kind {
            letters_core::ListKind::Numbered => format!("{}.\t", number + 1),
            _ => format!("{}\t", letters_core::lists::BULLET),
        };
        // An untagged (typed) item keeps its indent as spaces.
        let prefix = if level_tag.is_some() { next } else { format!("{}{next}", " ".repeat(indent)) };
        let mut at = buf.iter_at_mark(&buf.get_insert());
        buf.insert(&mut at, &format!("\n{prefix}"));
        if let Some(tag) = &level_tag {
            let mut start = buf.iter_at_mark(&buf.get_insert());
            start.set_line_offset(0);
            let mut end = start;
            if !end.ends_line() {
                end.forward_to_line_end();
            }
            buf.apply_tag(tag, &start, &end);
        }
    }
    buf.end_user_action();
    true
}

fn capture_list_marker(para: &mut Paragraph, tag_level: Option<u8>) -> usize {
    let text = para.text();
    let Some((kind, indent, marker_chars, _)) = list_marker_prefix(&text) else { return 0 };
    para.style.list = kind;
    para.style.list_level = tag_level.unwrap_or((indent / 4) as u8);
    // Remove the indent and marker from the front of the run list. Counts
    // are in chars (the bullet is one char, three bytes), as runs slice.
    let stripped = indent + marker_chars;
    let mut remaining = stripped;
    while remaining > 0 {
        let Some(first) = para.runs.first_mut() else { break };
        let n = first.text.chars().count();
        if n <= remaining {
            remaining -= n;
            para.runs.remove(0);
        } else {
            let byte = first.text.char_indices().nth(remaining).map(|(b, _)| b).unwrap();
            first.text = first.text[byte..].to_string();
            remaining = 0;
        }
    }
    stripped
}

/// Largeur maximale d'une image à l'écran (la colonne de texte de Samizdat).
const MAX_IMAGE_PX: f64 = 680.0;

/// Samizdat : l'image à la taille enregistrée dans le document (EMU), et pas
/// à sa taille brute ; bornée à la largeur de la colonne de texte.
fn load_image_texture(src: &str, extent: Option<(u64, u64)>) -> Result<gtk4::gdk::Texture, String> {
    use gtk4::gdk_pixbuf::Pixbuf;
    let (_, nw, nh) = Pixbuf::file_info(src).ok_or_else(|| format!("unreadable image {src}"))?;
    let (mut w, mut h) = match extent {
        Some((ew, eh)) if ew > 0 && eh > 0 => (ew as f64 / 9525.0, eh as f64 / 9525.0),
        _ => (nw as f64, nh as f64),
    };
    if w > MAX_IMAGE_PX {
        h *= MAX_IMAGE_PX / w;
        w = MAX_IMAGE_PX;
    }
    let pb = Pixbuf::from_file_at_scale(src, w.round().max(1.0) as i32, h.round().max(1.0) as i32, false).map_err(|e| e.to_string())?;
    Ok(gtk4::gdk::Texture::for_pixbuf(&pb))
}

/// Flatten a document's paragraphs into the lines the editor shows.
///
/// Everything is one line per paragraph, except a table: its cells are
/// paragraphs in the model but a *grid* on screen, so each row's cells
/// collapse into one pipe line and a delimiter line follows the header.
/// `capture_tables` reverses exactly this.
pub(crate) fn render_lines(paragraphs: &[Paragraph]) -> Vec<std::borrow::Cow<'_, Paragraph>> {
    use letters_core::table_text;
    use std::borrow::Cow;

    let mut lines: Vec<Cow<Paragraph>> = Vec::with_capacity(paragraphs.len());
    let mut i = 0;
    while i < paragraphs.len() {
        let Some(cell) = paragraphs[i].style.table_cell else {
            lines.push(Cow::Borrowed(&paragraphs[i]));
            i += 1;
            continue;
        };
        let table = cell.table;
        let end = paragraphs[i..]
            .iter()
            .position(|p| p.style.table_cell.is_none_or(|c| c.table != table))
            .map_or(paragraphs.len(), |n| i + n);
        let cells = &paragraphs[i..end];
        let cols = cells.iter().filter_map(|p| p.style.table_cell).map(|c| c.col).max().unwrap_or(0) + 1;

        // Cells arrive in row-major order (the model keeps them that way);
        // chunking by the column count is what turns them back into rows.
        for (row, chunk) in cells.chunks(cols as usize).enumerate() {
            let row_cells: Vec<Vec<letters_core::Run>> = chunk.iter().map(|p| p.runs.clone()).collect();
            lines.push(Cow::Owned(Paragraph {
                style: letters_core::ParaStyle::default(),
                runs: table_text::layout_row_runs(&row_cells),
            }));
            if row == 0 {
                lines.push(Cow::Owned(Paragraph {
                    style: letters_core::ParaStyle::default(),
                    runs: vec![letters_core::Run::plain(table_text::delimiter_line(cols as usize))],
                }));
            }
        }
        i = end;
    }
    lines
}

/// Samizdat : le style d'une case de tableau, par (tableau dans l'ordre du
/// texte, ligne, colonne). La grille « | … | » de l'éditeur n'en dit rien :
/// sans lui, une relecture rendait chaque case à son style par défaut
/// (l'allure d'un cartouche, l'alignement…).
pub(crate) type CellStyles = Vec<((usize, u32, u32), letters_core::ParaStyle)>;

const CELL_STYLES_KEY: &str = "samizdat-cell-styles";

/// Les styles des cases de `paras` (la première de chaque case).
pub(crate) fn cell_styles_of(paras: &[Paragraph]) -> CellStyles {
    let mut out: CellStyles = Vec::new();
    let (mut ordinal, mut prev, mut first): (usize, Option<u32>, bool) = (0, None, true);
    for p in paras {
        let Some(c) = p.style.table_cell else {
            prev = None;
            continue;
        };
        if prev != Some(c.table) {
            if !first {
                ordinal += 1;
            }
            first = false;
        }
        prev = Some(c.table);
        let key = (ordinal, c.row, c.col);
        if out.iter().any(|(k, _)| *k == key) {
            continue;
        }
        let mut st = p.style.clone();
        st.table_cell = None;
        if st != letters_core::ParaStyle::default() {
            out.push((key, st));
        }
    }
    out
}

/// Rendre aux cases de `paras` les styles `styles`.
pub(crate) fn apply_cell_styles(styles: &CellStyles, paras: &mut [Paragraph]) {
    if styles.is_empty() {
        return;
    }
    let (mut ordinal, mut prev): (usize, Option<u32>) = (0, None);
    let mut first = true;
    for p in paras.iter_mut() {
        let Some(c) = p.style.table_cell else {
            prev = None;
            continue;
        };
        if prev != Some(c.table) {
            if !first {
                ordinal += 1;
            }
            first = false;
        }
        prev = Some(c.table);
        if p.style != (letters_core::ParaStyle { table_cell: Some(c), ..Default::default() }) {
            continue;
        }
        if let Some((_, st)) = styles.iter().find(|(k, _)| *k == (ordinal, c.row, c.col)) {
            p.style = letters_core::ParaStyle { table_cell: Some(c), ..st.clone() };
        }
    }
}

pub(crate) fn set_cell_styles(buf: &gtk::TextBuffer, paras: &[Paragraph]) {
    // SAFETY: stored and read back as the same type, under this key only.
    unsafe { buf.set_data(CELL_STYLES_KEY, cell_styles_of(paras)) };
}

pub(crate) fn cell_styles(buf: &gtk::TextBuffer) -> CellStyles {
    // SAFETY: only ever set by set_cell_styles, with this type.
    unsafe { buf.data::<CellStyles>(CELL_STYLES_KEY).map(|p| p.as_ref().clone()).unwrap_or_default() }
}

/// Replace the buffer's content with a rendered Document.
pub fn render_to_buffer(doc: &Document, buf: &gtk::TextBuffer) {
    set_buffer_sidecars(doc, buf);
    set_trailing_style(buf, doc);
    set_cell_styles(buf, &doc.paragraphs);
    buf.set_text("");
    let mut insert = buf.start_iter();
    let lines = render_lines(&doc.paragraphs);
    let ordinals = letters_core::lists::ordinals(lines.iter().map(|p| &p.style));
    let lines: Vec<&Paragraph> = lines.iter().map(|p| p.as_ref()).collect();
    render_paragraphs(buf, &mut insert, &lines, &ordinals);
    buf.set_modified(false);
}

/// Insert `paras` (not table cells: `render_lines` makes those pipe rows)
/// at `insert`, one line each, separated by newlines, with their list
/// markers (`ordinals` gives each numbered item's number), run tags and
/// paragraph tags. `render_to_buffer` renders a whole document with it; the
/// live model re-renders just the paragraphs an undo changed.
pub(crate) fn render_paragraphs(buf: &gtk::TextBuffer, insert: &mut gtk::TextIter, paras: &[&Paragraph], ordinals: &[u32]) {
    let mut insert = *insert;
    // Paragraph tags are applied after all the text (see below).
    let mut tagged: Vec<(i32, i32, Vec<String>)> = Vec::new();
    for (i, para) in paras.iter().copied().enumerate() {
        if i > 0 {
            buf.insert(&mut insert, "\n");
        }
        let para_start = insert.offset();
        if let Some(marker) = letters_core::lists::marker(para.style.list, ordinals[i]) {
            buf.insert(&mut insert, &format!("{marker}\t"));
        }
        for run in &para.runs {
            if let Some(src) = &run.style.image {
                match load_image_texture(src, run.style.image_extent_emu) {
                    Ok(texture) => {
                        unsafe {
                            texture.set_data("letters-image-src", src.clone());
                            texture.set_data("letters-image-alt", run.text.clone());
                            texture.set_data("letters-image-extent", run.style.image_extent_emu);
                        }
                        let start = insert.offset();
                        buf.insert_paintable(&mut insert, &texture);
                        tag_object(buf, start, &insert, &run.style);
                    }
                    // Unloadable image degrades to visible alt text.
                    Err(_) => buf.insert(&mut insert, &run.text),
                }
                continue;
            }
            if let Some(idx) = run.style.footnote {
                let start = insert.offset();
                insert_footnote_marker(buf, &mut insert, idx);
                tag_object(buf, start, &insert, &run.style);
                continue;
            }
            if run.style.chip.is_some() {
                let start = insert.offset();
                insert_chip(buf, &mut insert, run);
                tag_object(buf, start, &insert, &run.style);
                continue;
            }
            let tags = run_tags(buf, &run.style);
            let names: Vec<&str> = tags.iter().map(String::as_str).collect();
            if names.is_empty() {
                buf.insert(&mut insert, &run.text);
            } else {
                buf.insert_with_tags_by_name(&mut insert, &run.text, &names);
            }
        }
        let mut para_tags: Vec<String> = Vec::new();
        // Looks only: the code block's language, a named style and a
        // quote are read back from the `para:` tag. (Code blocks used to
        // wear the run-level `code` tag, so the Draft view read them back
        // as code-formatted text and the paragraph lost its code block.)
        match (para.style.heading, &para.style.code_block) {
            (Some(l), _) => para_tags.push(format!("h{}", l.clamp(1, 6))),
            (None, Some(_)) => para_tags.push("code-block".to_string()),
            _ => {}
        }
        match letters_core::layout::paragraph_look(&para.style) {
            letters_core::layout::Look::Title => para_tags.push("h-title".into()),
            letters_core::layout::Look::Subtitle => para_tags.push("h-subtitle".into()),
            letters_core::layout::Look::Quote => para_tags.push("blockquote".into()),
            letters_core::layout::Look::Body => {}
        }
        match para.style.alignment {
            letters_core::Alignment::Center => para_tags.push("align-center".into()),
            letters_core::Alignment::Right => para_tags.push("align-right".into()),
            letters_core::Alignment::Justify => para_tags.push("align-justify".into()),
            letters_core::Alignment::Left => {}
        }
        if let Some(name) = line_spacing_tag_name(para.style.line_spacing) {
            para_tags.push(name.to_string());
        }
        if para.style.page_break_before {
            para_tags.push(PAGE_BREAK_TAG.to_string());
        }
        if para.style.list != letters_core::ListKind::None {
            para_tags.push(list_level_tag(buf, para.style.list_level));
        }
        if let Some(name) = para_tag(buf, &para.style) {
            para_tags.push(name);
        }
        tagged.push((para_start, insert.offset(), para_tags));
    }
    // Paragraph tags cover their paragraph's text. An empty paragraph owns
    // no character of its own, and a tag applied over an empty range sticks
    // to nothing: the capture reads the line back with default spacing,
    // alignment and style, so an empty styled line lost all three on every
    // save and drew tight in Print Layout. Its tags cover its terminating
    // newline instead — the one character an empty line owns. Non-empty
    // paragraphs keep exactly the range they had, so typing at their ends
    // inherits what it always did.
    for (k, (start, end, names)) in tagged.iter().enumerate() {
        let mut end = *end;
        if end <= *start && k + 1 < tagged.len() {
            end = tagged[k + 1].0;
        } else if end <= *start && buf.iter_at_offset(*start).char() == '\n' {
            // The last line of a partial render (the live model re-renders
            // only what changed) still has its newline, just past the
            // span: an empty line's style held in the model and was gone
            // from the next capture (#1279). That newline kept the old
            // line's paragraph tags, which the new style replaces.
            let (s, e) = (buf.iter_at_offset(*start), buf.iter_at_offset(*start + 1));
            for tag in s.tags() {
                if tag.name().is_some_and(|n| is_paragraph_tag(&n)) {
                    buf.remove_tag(&tag, &s, &e);
                }
            }
            end = *start + 1;
        }
        if end <= *start {
            continue;
        }
        let s = buf.iter_at_offset(*start);
        let e = buf.iter_at_offset(end);
        for name in names {
            buf.apply_tag_by_name(name, &s, &e);
        }
    }
}

/// Whether `name` is one of the tags that carry a paragraph's style
/// (render_paragraphs's `para_tags`), as opposed to a run's.
fn is_paragraph_tag(name: &str) -> bool {
    matches!(name, "h1" | "h2" | "h3" | "h4" | "h5" | "h6" | "h-title" | "h-subtitle" | "blockquote" | "code-block")
        || name.starts_with("align-")
        || name.starts_with("line-spacing-")
        || name == PAGE_BREAK_TAG
        || name.starts_with(PARA_TAG_PREFIX)
        || list_level_from_tag_name(name).is_some()
}

/// Show a freshly opened (or recovered) document in `buf`: its live
/// model's history starts here, so undo does not un-open it.
pub fn load_document(doc: &Document, buf: &gtk::TextBuffer) {
    crate::live::load(buf, || render_to_buffer(doc, buf));
}

/// Read any supported file through letters-core into the buffer.
///
/// The dispatch lives beside the writer's in `letters_core::save`, which
/// is permissive here on purpose — an unfamiliar extension still opens —
/// but no longer runs a `.txt` file through the Markdown parser (#436).
pub fn load_file_to_buffer(path: &str, buf: &gtk::TextBuffer) -> Result<(), String> {
    let doc = letters_core::save::read(std::path::Path::new(path))?;
    load_document(&doc, buf);
    Ok(())
}

/// Save the buffer through letters-core in the format the path implies.
/// Capture the buffer as a document and write it in the format `path`
/// names, reporting what that format could not carry.
///
/// The format decision itself lives in `letters_core::save` — this used to
/// be a two-arm match with a Markdown catch-all, so every extension it did
/// not name received Markdown bytes (#436).
pub fn save_buffer_to_file(
    buf: &gtk::TextBuffer,
    path: &std::path::Path,
) -> Result<suite_common_core::interop::CompatibilityReport, String> {
    letters_core::save::write(&document_of(buf), path)
}

/// The document `buf` shows: its live model, or a read of a buffer without
/// one.
pub fn document_of(buf: &gtk::TextBuffer) -> letters_core::Document {
    match crate::live::of(buf) {
        Some(m) => m.borrow_mut().document(buf).clone(),
        None => capture_from_buffer(buf),
    }
}

/// Prefix of a smart chip's tag: "chip:ID:date:2026-09-25". Every chip
/// gets its own tag (ID), so two identical chips side by side read back as
/// two; the value comes last because a URL may hold ':' or '#'.
pub const CHIP_TAG_PREFIX: &str = "chip:";

thread_local! {
    static NEXT_CHIP_TAG: std::cell::Cell<u64> = const { std::cell::Cell::new(0) };
}

pub(crate) fn parse_chip_tag(name: &str) -> Option<letters_core::chips::Chip> {
    use letters_core::chips::{Chip, ChipKind};
    let (_id, rest) = name.strip_prefix(CHIP_TAG_PREFIX)?.split_once(':')?;
    let (kind, value) = rest.split_once(':')?;
    let kind = match kind {
        "date" => ChipKind::Date,
        "person" => ChipKind::Person,
        "link" => ChipKind::Link,
        _ => return None,
    };
    Some(Chip { kind, value: value.to_string() })
}

/// Insert smart chip `run` (its label) at `insert`, under its chip tag:
/// the Draft view's pill, in the chip's colours.
pub fn insert_chip(buf: &gtk::TextBuffer, insert: &mut gtk::TextIter, run: &Run) {
    use letters_core::chips::ChipKind;
    let Some(chip) = &run.style.chip else { return };
    let (kind, fg, bg) = match chip.kind {
        ChipKind::Date => ("date", "#1a57b5", "#e8effc"),
        ChipKind::Person => ("person", "#222222", "#ededed"),
        ChipKind::Link => ("link", "#176b38", "#e6f5eb"),
    };
    let id = NEXT_CHIP_TAG.with(|n| n.replace(n.get() + 1));
    let name = format!("{CHIP_TAG_PREFIX}{id}:{kind}:{}", chip.value);
    let tag = gtk::TextTag::builder().name(&name).foreground(fg).background(bg).build();
    buf.tag_table().add(&tag);
    buf.insert_with_tags_by_name(insert, &run.text, &[&name]);
}

/// Insert the visible "[n]" marker for footnote index `idx`, tagged
/// "fnref:idx" (superscript, accent color). Shared by render and the
/// Insert Footnote action.
pub fn insert_footnote_marker(buf: &gtk::TextBuffer, insert: &mut gtk::TextIter, idx: usize) {
    let name = format!("fnref:{idx}");
    if buf.tag_table().lookup(&name).is_none() {
        let tag = gtk::TextTag::builder()
            .name(&name)
            .foreground("#1a5fb4")
            .rise(4000)
            .scale(0.75)
            .build();
        buf.tag_table().add(&tag);
    }
    buf.insert_with_tags_by_name(insert, &format!("[{}]", idx + 1), &[&name]);
}

/// Model offset (`Document`'s global char offsets) of buffer offset `off`.
fn model_offset(doc: &Document, starts: &[usize], off: usize) -> usize {
    let (para, offset) = paragraph_offset(doc, starts, off);
    doc.paragraph_offset(para) + offset
}

/// Buffer offset of model offset `off`.
fn buffer_offset_of_model(doc: &Document, starts: &[usize], off: usize) -> usize {
    let para = doc.paragraph_at(off).min(doc.paragraphs.len().saturating_sub(1));
    let within = off.saturating_sub(doc.paragraph_offset(para));
    starts.get(para).map_or(0, |s| buffer_offset(&doc.paragraphs[para], *s, within))
}

fn structured_edit_on_model<F>(buf: &gtk::TextBuffer, m: &std::rc::Rc<std::cell::RefCell<crate::live::LiveModel>>, edit: F)
where
    F: FnOnce(&mut letters_core::structured::StructuredEditor),
{
    let (doc, starts) = m.borrow_mut().snapshot(buf);
    let mut editor = letters_core::structured::StructuredEditor::new(doc.clone());
    editor.set_cursor(model_offset(&doc, &starts, buf.iter_at_mark(&buf.get_insert()).offset().max(0) as usize));
    if let Some((start, end)) = buf.selection_bounds() {
        editor.select(
            model_offset(&doc, &starts, start.offset().max(0) as usize),
            model_offset(&doc, &starts, end.offset().max(0) as usize),
        );
    }
    edit(&mut editor);
    let ops = letters_core::edit::diff(&doc, editor.document());
    if ops.is_empty() {
        return;
    }
    let mut m = m.borrow_mut();
    if m.apply_user_ops(buf, &ops, false) {
        // The caret where the command left it (the new table's first cell).
        let (doc, starts) = m.snapshot(buf);
        let off = buffer_offset_of_model(&doc, &starts, editor.cursor());
        buf.place_cursor(&buf.iter_at_offset(off as i32));
    }
}

/// Apply a structured editing operation directly to the GtkTextBuffer through
/// letters_core::StructuredEditor, preserving document structure and cursor position.
pub fn apply_structured_edit<F>(buf: &gtk::TextBuffer, edit: F)
where
    F: FnOnce(&mut letters_core::structured::StructuredEditor),
{
    // With a live model the command runs on the model: its change becomes
    // ops (`edit::diff`) and only the changed paragraphs are re-rendered —
    // inserting a table row no longer rewrites and re-reads the document.
    if let Some(m) = crate::live::of(buf) {
        structured_edit_on_model(buf, &m, edit);
        return;
    }
    let doc = capture_from_buffer(buf);
    let mut editor = letters_core::structured::StructuredEditor::new(doc);
    // The caret, not the selection start: `unwrap_or(0)` for an unselected
    // buffer — which is what this used to do — told every structured
    // command that the cursor was at the very start of the document, so
    // "Insert Table" put its table before the first character no matter
    // where the user was typing.
    let cursor_offset = buf.iter_at_mark(&buf.get_insert()).offset().max(0) as usize;
    editor.set_cursor(cursor_offset);
    if let Some((start, end)) = buf.selection_bounds() {
        editor.select(start.offset().max(0) as usize, end.offset().max(0) as usize);
    }
    edit(&mut editor);
    // One undoable change to the live model; and a changed document, which
    // re-rendering (it marks the buffer saved) used to hide from the close
    // guard.
    crate::live::rewrite(buf, || render_to_buffer(editor.document(), buf));
    buf.set_modified(true);

    // Re-rendering replaces the buffer's contents, which drops the caret at
    // the start. Put it back where the edit left it so typing continues in
    // the new table's first cell rather than at the top of the document.
    let restored = (editor.cursor() as i32).min(buf.char_count());
    buf.place_cursor(&buf.iter_at_offset(restored));
}
