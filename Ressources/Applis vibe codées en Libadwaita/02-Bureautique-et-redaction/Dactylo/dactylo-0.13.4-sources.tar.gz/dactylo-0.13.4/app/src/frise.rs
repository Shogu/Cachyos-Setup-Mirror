// frise.rs — la frise chronologique : des dates et des événements, dessinés
// en image. Ses données voyagent dans le texte de remplacement de l'image
// (lisible : « Frise chronologique — Titre | 1914 : … »), pour la modifier
// d'un double-clic, même après un aller-retour en DOCX.
// SPDX-License-Identifier: GPL-3.0-or-later

use gtk4 as gtk;
use gtk::cairo;
use pangocairo::pango;

pub const PREFIX: &str = "Frise chronologique";

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Frise {
    pub title: String,
    /// (date, événement), dans l'ordre de saisie.
    pub events: Vec<(String, String)>,
}

impl Frise {
    /// Le texte de remplacement de l'image.
    pub fn to_alt(&self) -> String {
        let clean = |s: &str| s.replace('|', "/").replace('\n', " ").trim().to_string();
        let mut out = String::from(PREFIX);
        if !self.title.trim().is_empty() {
            out.push_str(" — ");
            out.push_str(&clean(&self.title));
        }
        for (d, e) in self.events.iter().filter(|(d, e)| !d.trim().is_empty() || !e.trim().is_empty()) {
            out.push_str(&format!(" | {} : {}", clean(d), clean(e)));
        }
        out
    }

    /// L'inverse de `to_alt` ; None pour une autre image.
    pub fn from_alt(alt: &str) -> Option<Self> {
        let rest = alt.trim().strip_prefix(PREFIX)?;
        let mut parts = rest.split(" | ");
        let head = parts.next().unwrap_or("").trim();
        let title = head.strip_prefix('—').or_else(|| head.strip_prefix('-')).unwrap_or(head).trim().to_string();
        let events = parts
            .map(|p| match p.split_once(" : ") {
                Some((d, e)) => (d.trim().to_string(), e.trim().to_string()),
                None => (p.trim().to_string(), String::new()),
            })
            .collect();
        Some(Self { title, events })
    }
}

/// Une date lue : son année (fractionnaire avec mois et jour), et la fin
/// d'une période (« 1914-1918 », « de 1939 à 1945 »).
pub fn parse_date(s: &str) -> Option<(f64, Option<f64>)> {
    let low = s.to_lowercase();
    let bc = low.contains("av") && (low.contains("j.-c") || low.contains("jc") || low.contains("j-c") || low.contains("j.c"));
    const MONTHS: [&str; 12] = ["janv", "févr", "mars", "avr", "mai", "juin", "juil", "août", "sept", "oct", "nov", "déc"];
    let month = MONTHS.iter().position(|m| low.contains(m)).or_else(|| if low.contains("fevr") { Some(1) } else if low.contains("aout") { Some(7) } else if low.contains("dec") && !low.contains("déc") { Some(11) } else { None });
    // Les nombres de la chaîne.
    let mut nums: Vec<i64> = Vec::new();
    let mut cur = String::new();
    for c in low.chars().chain([' ']) {
        if c.is_ascii_digit() {
            cur.push(c);
        } else if !cur.is_empty() {
            if let Ok(n) = cur.parse() {
                nums.push(n);
            }
            cur.clear();
        }
    }
    // Une année : le plus grand nombre de plus de deux chiffres, ou le seul.
    let years: Vec<i64> = nums.iter().copied().filter(|n| *n >= 100 || nums.len() == 1 || bc).collect();
    let sign = if bc { -1.0 } else { 1.0 };
    match years.as_slice() {
        [] => None,
        [y] => {
            let mut v = sign * *y as f64;
            if let Some(m) = month {
                let day = nums.iter().copied().find(|n| (1..=31).contains(n) && *n != *y).unwrap_or(1);
                v += (m as f64 + (day as f64 - 1.0) / 31.0) / 12.0;
            }
            Some((v, None))
        }
        [a, .., b] => {
            let (a, b) = (sign * *a as f64, sign * *b as f64);
            Some((a.min(b), Some(a.max(b) + 0.999)))
        }
    }
}

const W: f64 = 1400.0;
const MARGIN: f64 = 60.0;
const LABEL_W: f64 = 250.0;
const AXIS: (f64, f64, f64) = (0.14, 0.12, 0.19);
const BLUE: (f64, f64, f64) = (0.10, 0.37, 0.71);
const PERIODS: [(f64, f64, f64); 5] = [(0.60, 0.76, 0.95), (0.56, 0.94, 0.64), (0.98, 0.94, 0.42), (1.0, 0.75, 0.44), (0.86, 0.54, 0.87)];

struct Label {
    x: f64,
    w: f64,
    h: f64,
    date: pango::Layout,
    text: pango::Layout,
    /// Une période : sa bande sur l'axe.
    band: Option<(f64, f64, usize)>,
    above: bool,
    level: usize,
}

fn layout(cr: &cairo::Context, family: &str, px: f64, bold: bool, text: &str, width: Option<f64>) -> pango::Layout {
    let l = pangocairo::functions::create_layout(cr);
    let mut d = pango::FontDescription::new();
    d.set_family(family);
    d.set_absolute_size(px * pango::SCALE as f64);
    if bold {
        d.set_weight(pango::Weight::Bold);
    }
    l.set_font_description(Some(&d));
    if let Some(w) = width {
        l.set_width((w * pango::SCALE as f64) as i32);
        l.set_wrap(pango::WrapMode::WordChar);
        l.set_alignment(pango::Alignment::Center);
    }
    l.set_text(text);
    l
}

fn size(l: &pango::Layout) -> (f64, f64) {
    let (_, r) = l.pixel_extents();
    (r.width() as f64, r.height() as f64)
}

/// Dessine la frise en PNG (1400 px de large) ; rend son chemin.
pub fn render_png(f: &Frise, family: &str) -> Result<std::path::PathBuf, String> {
    // Mesurer sur une petite surface, puis dessiner à la bonne hauteur.
    let probe = cairo::ImageSurface::create(cairo::Format::ARgb32, 8, 8).map_err(|e| e.to_string())?;
    let height = {
        let cr = cairo::Context::new(&probe).map_err(|e| e.to_string())?;
        draw(&cr, f, family, None)
    };
    let surface = cairo::ImageSurface::create(cairo::Format::ARgb32, W as i32, height.ceil() as i32).map_err(|e| e.to_string())?;
    {
        let cr = cairo::Context::new(&surface).map_err(|e| e.to_string())?;
        draw(&cr, f, family, Some(height));
    }
    let dir = gtk::glib::user_cache_dir().join(crate::DIR).join("images");
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let t = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0);
    let path = dir.join(format!("frise-{t:x}.png"));
    let mut file = std::fs::File::create(&path).map_err(|e| e.to_string())?;
    surface.write_to_png(&mut file).map_err(|e| e.to_string())?;
    Ok(path)
}

/// Mesure (`height` None) ou dessine la frise ; rend sa hauteur.
fn draw(cr: &cairo::Context, f: &Frise, family: &str, height: Option<f64>) -> f64 {
    let events: Vec<&(String, String)> = f.events.iter().filter(|(d, e)| !d.trim().is_empty() || !e.trim().is_empty()).collect();
    let dates: Vec<Option<(f64, Option<f64>)>> = events.iter().map(|(d, _)| parse_date(d)).collect();
    let numeric = !dates.is_empty() && dates.iter().all(Option::is_some);
    let (x0, x1) = (MARGIN + LABEL_W / 2.0 - 40.0, W - MARGIN - LABEL_W / 2.0 + 40.0);
    // L'échelle : les années, ou un pas régulier si une date ne se lit pas.
    let (lo, hi) = if numeric {
        let lo = dates.iter().flatten().map(|d| d.0).fold(f64::INFINITY, f64::min);
        let hi = dates.iter().flatten().map(|d| d.1.unwrap_or(d.0)).fold(f64::NEG_INFINITY, f64::max);
        let pad = ((hi - lo) * 0.04).max(0.5);
        (lo - pad, hi + pad)
    } else {
        (0.0, events.len().max(1) as f64)
    };
    let xof = |v: f64| x0 + (v - lo) / (hi - lo).max(1e-9) * (x1 - x0);

    let mut labels: Vec<Label> = Vec::new();
    let mut order: Vec<usize> = (0..events.len()).collect();
    if numeric {
        order.sort_by(|a, b| dates[*a].unwrap().0.partial_cmp(&dates[*b].unwrap().0).unwrap_or(std::cmp::Ordering::Equal));
    }
    let mut period_n = 0;
    for (k, &i) in order.iter().enumerate() {
        let (d, e) = events[i];
        let (x, band) = match dates[i] {
            Some((a, Some(b))) if numeric => {
                let band = Some((xof(a), xof(b), period_n));
                period_n += 1;
                ((xof(a) + xof(b)) / 2.0, band)
            }
            Some((a, None)) if numeric => (xof(a), None),
            _ => (xof(k as f64 + 0.5), None),
        };
        let date = layout(cr, family, 27.0, true, d.trim(), Some(LABEL_W));
        let text = layout(cr, family, 24.0, false, e.trim(), Some(LABEL_W));
        let (dw, dh) = size(&date);
        let (tw, th) = size(&text);
        let w = dw.max(tw).min(LABEL_W) + 16.0;
        labels.push(Label { x, w, h: dh + th + 6.0 + 12.0, date, text, band, above: k % 2 == 0, level: 0 });
    }
    // Les niveaux : une étiquette qui en chevauche une autre du même côté
    // s'éloigne de l'axe.
    for side in [true, false] {
        let mut ends: Vec<f64> = Vec::new();
        for l in labels.iter_mut().filter(|l| l.above == side) {
            let left = (l.x - l.w / 2.0).max(MARGIN);
            let lvl = ends.iter().position(|e| left > *e + 14.0).unwrap_or(ends.len());
            if lvl == ends.len() {
                ends.push(0.0);
            }
            ends[lvl] = left + l.w;
            l.level = lvl;
        }
    }
    let level_h = |side: bool| labels.iter().filter(|l| l.above == side).map(|l| l.h).fold(0.0, f64::max) + 26.0;
    let levels = |side: bool| labels.iter().filter(|l| l.above == side).map(|l| l.level + 1).max().unwrap_or(0) as f64;
    let (ha, hb) = (level_h(true), level_h(false));
    let title = (!f.title.trim().is_empty()).then(|| layout(cr, family, 36.0, true, f.title.trim(), None));
    let title_h = title.as_ref().map_or(0.0, |t| size(t).1 + 24.0);
    let top = 24.0 + title_h;
    let axis_y = top + levels(true) * ha + 30.0;
    let total = axis_y + 44.0 + levels(false) * hb + 24.0;
    let Some(_) = height else { return total.max(160.0) };

    // Le fond blanc.
    cr.set_source_rgb(1.0, 1.0, 1.0);
    let _ = cr.paint();
    if let Some(t) = &title {
        let (tw, _) = size(t);
        cr.set_source_rgb(AXIS.0, AXIS.1, AXIS.2);
        cr.move_to((W - tw) / 2.0, 20.0);
        pangocairo::functions::show_layout(cr, t);
    }
    // Les périodes, sous l'axe.
    for l in &labels {
        if let Some((a, b, n)) = l.band {
            let (r, g, bl) = PERIODS[n % PERIODS.len()];
            cr.set_source_rgba(r, g, bl, 0.85);
            rounded(cr, a, axis_y - 15.0, (b - a).max(8.0), 30.0, 8.0);
            let _ = cr.fill();
        }
    }
    // L'axe et sa flèche.
    cr.set_source_rgb(AXIS.0, AXIS.1, AXIS.2);
    cr.set_line_width(5.0);
    cr.move_to(MARGIN - 20.0, axis_y);
    cr.line_to(W - MARGIN + 6.0, axis_y);
    let _ = cr.stroke();
    cr.move_to(W - MARGIN + 26.0, axis_y);
    cr.line_to(W - MARGIN + 2.0, axis_y - 13.0);
    cr.line_to(W - MARGIN + 2.0, axis_y + 13.0);
    cr.close_path();
    let _ = cr.fill();
    // Les étiquettes, reliées à l'axe : les traits d'abord, les cartes
    // par-dessus.
    let place = |l: &Label| {
        let bx = (l.x - l.w / 2.0).clamp(MARGIN - 30.0, W - MARGIN + 30.0 - l.w);
        let by = if l.above { axis_y - 30.0 - (l.level as f64 + 1.0) * ha + 26.0 } else { axis_y + 44.0 + l.level as f64 * hb + 10.0 };
        (bx, by)
    };
    for l in &labels {
        let (_, by) = place(l);
        cr.set_source_rgba(BLUE.0, BLUE.1, BLUE.2, 0.7);
        cr.set_line_width(2.0);
        let (ya, yb) = if l.above { (by + l.h, axis_y - if l.band.is_some() { 15.0 } else { 0.0 }) } else { (axis_y + if l.band.is_some() { 15.0 } else { 0.0 }, by) };
        cr.move_to(l.x, ya);
        cr.line_to(l.x, yb);
        let _ = cr.stroke();
        if l.band.is_none() {
            cr.set_source_rgb(BLUE.0, BLUE.1, BLUE.2);
            cr.arc(l.x, axis_y, 9.0, 0.0, std::f64::consts::TAU);
            let _ = cr.fill();
            cr.set_source_rgb(1.0, 1.0, 1.0);
            cr.arc(l.x, axis_y, 4.0, 0.0, std::f64::consts::TAU);
            let _ = cr.fill();
        }
    }
    for l in &labels {
        let (bx, by) = place(l);
        // La carte : coins arrondis, fond très clair, trait fin.
        rounded(cr, bx, by, l.w, l.h, 10.0);
        cr.set_source_rgb(0.973, 0.969, 0.965);
        let _ = cr.fill_preserve();
        cr.set_source_rgba(AXIS.0, AXIS.1, AXIS.2, 0.35);
        cr.set_line_width(1.5);
        let _ = cr.stroke();
        let (_, dh) = size(&l.date);
        cr.set_source_rgb(BLUE.0, BLUE.1, BLUE.2);
        l.date.set_width(((l.w - 16.0) * pango::SCALE as f64) as i32);
        cr.move_to(bx + 8.0, by + 6.0);
        pangocairo::functions::show_layout(cr, &l.date);
        cr.set_source_rgb(AXIS.0, AXIS.1, AXIS.2);
        l.text.set_width(((l.w - 16.0) * pango::SCALE as f64) as i32);
        cr.move_to(bx + 8.0, by + 6.0 + dh + 6.0);
        pangocairo::functions::show_layout(cr, &l.text);
    }
    // Les graduations (années rondes), par-dessus les traits.
    if numeric && hi - lo > 1.5 {
        let span = hi - lo;
        let step = [1.0, 2.0, 5.0, 10.0, 20.0, 25.0, 50.0, 100.0, 200.0, 250.0, 500.0, 1000.0, 2000.0, 5000.0].into_iter().find(|s| span / s <= 10.0).unwrap_or(10000.0);
        let mut v = (lo / step).ceil() * step;
        while v <= hi {
            let x = xof(v);
            cr.set_source_rgb(AXIS.0, AXIS.1, AXIS.2);
            cr.set_line_width(2.0);
            cr.move_to(x, axis_y - 8.0);
            cr.line_to(x, axis_y + 8.0);
            let _ = cr.stroke();
            let t = layout(cr, family, 18.0, false, &format!("{}", v as i64), None);
            let (tw, th) = size(&t);
            cr.set_source_rgb(1.0, 1.0, 1.0);
            cr.rectangle(x - tw / 2.0 - 3.0, axis_y + 17.0, tw + 6.0, th + 2.0);
            let _ = cr.fill();
            cr.set_source_rgba(AXIS.0, AXIS.1, AXIS.2, 0.6);
            cr.move_to(x - tw / 2.0, axis_y + 17.0);
            pangocairo::functions::show_layout(cr, &t);
            v += step;
        }
    }
    total
}

fn rounded(cr: &cairo::Context, x: f64, y: f64, w: f64, h: f64, r: f64) {
    let r = r.min(w / 2.0).min(h / 2.0);
    let pi = std::f64::consts::PI;
    cr.new_sub_path();
    cr.arc(x + w - r, y + r, r, -pi / 2.0, 0.0);
    cr.arc(x + w - r, y + h - r, r, 0.0, pi / 2.0);
    cr.arc(x + r, y + h - r, r, pi / 2.0, pi);
    cr.arc(x + r, y + r, r, pi, 3.0 * pi / 2.0);
    cr.close_path();
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn dates_are_read_the_french_way() {
        assert_eq!(parse_date("1914"), Some((1914.0, None)));
        assert_eq!(parse_date("1914-1918").map(|d| d.0), Some(1914.0));
        assert!(parse_date("1914–1918").unwrap().1.unwrap() > 1918.0);
        assert!(parse_date("de 1939 à 1945").unwrap().1.is_some());
        assert_eq!(parse_date("52 av. J.-C.").map(|d| d.0), Some(-52.0));
        let armistice = parse_date("11 novembre 1918").unwrap().0;
        assert!(armistice > 1918.8 && armistice < 1919.0, "{armistice}");
        assert_eq!(parse_date("la Renaissance"), None);
    }

    #[test]
    fn the_alt_text_carries_the_frise() {
        let f = Frise { title: "La Grande Guerre".into(), events: vec![("1914".into(), "Début | de la guerre".into()), ("1914-1918".into(), "Première Guerre mondiale".into())] };
        let alt = f.to_alt();
        assert!(alt.starts_with("Frise chronologique — La Grande Guerre | 1914 : Début / de la guerre"));
        let back = Frise::from_alt(&alt).unwrap();
        assert_eq!(back.title, "La Grande Guerre");
        assert_eq!(back.events[1], ("1914-1918".to_string(), "Première Guerre mondiale".to_string()));
        assert_eq!(Frise::from_alt("photo"), None);
    }

    #[test]
    fn a_frise_renders() {
        let f = Frise {
            title: "La Grande Guerre".into(),
            events: vec![
                ("28 juin 1914".into(), "Attentat de Sarajevo".into()),
                ("1914-1918".into(), "Première Guerre mondiale".into()),
                ("1916".into(), "Verdun".into()),
                ("1917".into(), "Entrée en guerre des États-Unis".into()),
                ("11 novembre 1918".into(), "Armistice".into()),
                ("1919".into(), "Traité de Versailles".into()),
            ],
        };
        let p = render_png(&f, "Sans").unwrap();
        let out = std::env::var("SAMIZDAT_FRISE").ok();
        if let Some(o) = out {
            std::fs::copy(&p, o).unwrap();
        }
        assert!(std::fs::metadata(&p).unwrap().len() > 1000);
        let _ = std::fs::remove_file(p);
    }
}
