// window/livepane.rs — le panneau d'aperçu en direct : l'ouvrir, le placer
// (à côté du texte, ou par-dessus dans une fenêtre étroite), le tenir à jour
// pendant la frappe et y suivre le curseur.
// SPDX-License-Identifier: GPL-3.0-or-later

use super::*;
use letters_core::layout::pango::TextPos;

/// Attente après la dernière frappe avant de redessiner les pages.
const LIVE_DELAY_MS: u64 = 450;

impl Window {
    pub(super) fn connect_live(self: &Rc<Self>) {
        // L'action F12, bouton « Aperçu » et croix du panneau.
        {
            let a = gio::SimpleAction::new_stateful("live-preview", None, &false.to_variant());
            let w = Rc::downgrade(self);
            a.connect_activate(move |_, _| {
                if let Some(w) = w.upgrade() {
                    w.set_live(!w.live_on.get());
                }
            });
            self.win.add_action(&a);
        }
        // Un clic sur une page : le curseur y va, dans le texte. Un double-clic
        // ouvre de quoi modifier ce qui est là (image, frise, tableau,
        // cartouche), comme dans le texte.
        {
            let pop = gtk::Popover::new();
            pop.set_parent(&self.live.area);
            pop.set_position(gtk::PositionType::Left);
            self.build_cartouche_popover(&pop);
            let w = Rc::downgrade(self);
            self.live.connect_clicked(move |pos, n, x, y| {
                if let Some(w) = w.upgrade() {
                    w.live_clicked(pos, n, x, y, &pop);
                }
            });
        }
        // Largeur retenue quand on déplace la séparation.
        {
            let w = Rc::downgrade(self);
            self.live_paned.connect_position_notify(move |p| {
                let Some(w) = w.upgrade() else { return };
                if !w.live_on.get() || !w.live_ready.get() || w.narrow.get() || p.end_child().is_none() || p.width() <= 0 {
                    return;
                }
                let width = p.width() - p.position();
                if width >= 220 && (crate::prefs::get().live_width - width).abs() > 4 {
                    crate::prefs::update(|pr| pr.live_width = width);
                }
            });
        }
        // Fenêtre étroite : par-dessus le texte.
        {
            let w = Rc::downgrade(self);
            self.win.connect_current_breakpoint_notify(move |win| {
                let Some(w) = w.upgrade() else { return };
                let narrow = win.current_breakpoint().is_some_and(|b| w.narrow_points.contains(&b));
                if narrow != w.narrow.replace(narrow) {
                    w.place_live();
                }
            });
        }
    }

    /// Ouvre ou ferme l'aperçu en direct.
    pub(super) fn set_live(self: &Rc<Self>, on: bool) {
        self.live_on.set(on);
        if let Some(a) = self.win.lookup_action("live-preview").and_then(|a| a.downcast::<gio::SimpleAction>().ok()) {
            a.set_state(&on.to_variant());
        }
        if on {
            self.preview_btn.add_css_class("samizdat-on");
        } else {
            self.preview_btn.remove_css_class("samizdat-on");
        }
        self.place_live();
        if on {
            self.live.jump_to_caret();
            self.refresh_live();
        } else {
            // Rien ne reste en mémoire : les pages seront refaites.
            self.live.clear();
            *self.live_map.borrow_mut() = None;
            self.live_stale.set(true);
        }
    }

    /// Met le panneau où il doit être : à côté du texte, par-dessus (fenêtre
    /// étroite), ou nulle part (fermé, PDF, mode concentration).
    pub(super) fn place_live(&self) {
        let widget: gtk::Widget = self.live.widget.clone().upcast();
        let shown = self.live_on.get() && !self.doc().is_pdf() && !self.focus.get();
        // Le retirer d'abord de là où il est.
        if self.live_paned.end_child().as_ref() == Some(&widget) {
            self.live_paned.set_end_child(None::<&gtk::Widget>);
        }
        if widget.parent().as_ref() == Some(self.stage.upcast_ref()) {
            self.stage.remove_overlay(&widget);
        }
        if !shown {
            return;
        }
        if self.narrow.get() {
            widget.add_css_class("overlaid");
            widget.set_halign(gtk::Align::End);
            let width = (self.win.width() as f64 * 0.55) as i32;
            widget.set_size_request(width.clamp(220, 420), -1);
            self.stage.add_overlay(&widget);
        } else {
            widget.remove_css_class("overlaid");
            widget.set_halign(gtk::Align::Fill);
            widget.set_size_request(220, -1);
            self.live_paned.set_end_child(Some(&widget));
            self.place_divider();
        }
    }

    /// La séparation à la largeur retenue, dès que le panneau a sa taille
    /// définitive (au démarrage, la fenêtre s'agrandit encore pendant
    /// quelques images) ; la largeur n'est retenue qu'ensuite.
    fn place_divider(&self) {
        self.live_ready.set(false);
        let ready = self.live_ready.clone();
        let last = Cell::new(-1);
        let frames = Cell::new(0);
        self.live_paned.add_tick_callback(move |p, _| {
            let total = p.width();
            frames.set(frames.get() + 1);
            if (total <= 0 || total != last.replace(total)) && frames.get() < 60 {
                return glib::ControlFlow::Continue;
            }
            let width = crate::prefs::get().live_width.clamp(220, (total - 320).max(220));
            p.set_position(total - width);
            ready.set(true);
            glib::ControlFlow::Break
        });
    }

    /// Le texte a changé : l'aperçu se refait quand la frappe s'arrête.
    pub(super) fn schedule_live(self: &Rc<Self>) {
        if !self.live_on.get() {
            return;
        }
        self.live_stale.set(true);
        let gen = self.live_gen.get().wrapping_add(1);
        self.live_gen.set(gen);
        let w = Rc::downgrade(self);
        glib::timeout_add_local_once(std::time::Duration::from_millis(LIVE_DELAY_MS), move || {
            if let Some(w) = w.upgrade() {
                if w.live_gen.get() == gen {
                    w.refresh_live();
                }
            }
        });
    }

    /// Refait les pages de l'aperçu depuis le document.
    pub(super) fn refresh_live(&self) {
        if !self.live_on.get() || self.doc().is_pdf() || crate::live::is_busy(&self.buf()) {
            return;
        }
        let doc = self.typeset_document();
        let map = crate::bridge::capture_with_starts(&self.buf());
        // Les deux lectures doivent compter les mêmes paragraphes pour passer
        // de l'une à l'autre ; sinon pas de curseur ni de clic, mais les
        // pages restent justes.
        let usable = map.0.paragraphs.len() == doc.paragraphs.len();
        self.live.set_document(doc);
        *self.live_map.borrow_mut() = usable.then_some(map);
        self.live_stale.set(false);
        self.live_caret();
    }

    /// Montre le curseur du texte dans l'aperçu.
    pub(super) fn live_caret(&self) {
        if !self.live_on.get() || self.live_stale.get() || self.doc().is_pdf() {
            return;
        }
        let pos = {
            let map = self.live_map.borrow();
            map.as_ref().map(|(doc, starts)| {
                let buf = self.buf();
                let off = buf.iter_at_mark(&buf.get_insert()).offset().max(0) as usize;
                let (para, offset) = crate::bridge::paragraph_offset(doc, starts, off);
                TextPos { para, offset }
            })
        };
        self.live.show_caret(pos);
    }

    /// Un autre onglet : l'aperçu le suit.
    pub(super) fn live_switched(&self) {
        if !self.live_on.get() {
            return;
        }
        self.place_live();
        self.live_stale.set(true);
        *self.live_map.borrow_mut() = None;
        if self.doc().is_pdf() {
            self.live.clear();
            return;
        }
        self.live.jump_to_caret();
        self.refresh_live();
    }

    /// Un clic dans l'aperçu : le curseur va au même endroit du texte ; au
    /// double-clic, l'outil de ce qui est là s'ouvre.
    fn live_clicked(&self, pos: TextPos, n: i32, x: f64, y: f64, pop: &gtk::Popover) {
        if self.live_stale.get() {
            return;
        }
        let off = {
            let map = self.live_map.borrow();
            let Some((doc, starts)) = map.as_ref() else { return };
            let (Some(para), Some(&start)) = (doc.paragraphs.get(pos.para), starts.get(pos.para)) else { return };
            crate::bridge::buffer_offset(para, start, pos.offset)
        };
        let buf = self.buf();
        let it = buf.iter_at_offset(off as i32);
        buf.place_cursor(&it);
        let view = self.view();
        view.grab_focus();
        editor::scroll_to_iter(&view, &it, 0.3);
        if n != 2 {
            return;
        }
        // Une image (ou une frise) : le clic tombe juste avant ou juste après.
        let image = [off as i32, off as i32 - 1].into_iter().filter(|o| *o >= 0).map(|o| buf.iter_at_offset(o)).find(|i| i.paintable().is_some());
        if let Some(i) = image {
            buf.place_cursor(&i);
            // SAFETY: posé par bridge, du type String, sous cette clé.
            let frise = i.paintable().and_then(|p| unsafe { p.data::<String>("letters-image-alt").map(|a| a.as_ref().starts_with(crate::frise::PREFIX)) }).unwrap_or(false);
            let _ = WidgetExt::activate_action(&self.win, if frise { "win.edit-frise" } else { "win.image-properties" }, None);
            return;
        }
        // Un cartouche (un tableau d'une seule case) avant un tableau.
        if crate::commands::cartouche_at_caret(&buf).is_some() {
            pop.set_pointing_to(Some(&gtk::gdk::Rectangle::new(x as i32, y as i32, 1, 1)));
            pop.popup();
            return;
        }
        if buf.tag_table().lookup("table-line").is_some_and(|t| it.has_tag(&t)) {
            let _ = WidgetExt::activate_action(&self.win, "win.edit-table", None);
        }
    }

    /// La règle : son action (Ctrl+R), le retrait qu'on y tire, les lignes
    /// repères.
    pub(super) fn connect_ruler(self: &Rc<Self>) {
        let on = crate::prefs::get().show_ruler;
        let a = gio::SimpleAction::new_stateful("ruler", None, &on.to_variant());
        let w = Rc::downgrade(self);
        a.connect_activate(move |a, _| {
            let Some(w) = w.upgrade() else { return };
            let on = !crate::prefs::get().show_ruler;
            crate::prefs::update(|p| p.show_ruler = on);
            a.set_state(&on.to_variant());
            w.place_ruler();
        });
        self.win.add_action(&a);
        let w = Rc::downgrade(self);
        self.ruler.connect_indent(move |cm| {
            let Some(w) = w.upgrade() else { return };
            let pt = cm * crate::ruler::PT_PER_CM;
            crate::commands::restyle(&w.buf(), |s| letters_core::ParaStyle { left_indent_pt: pt, ..s.clone() });
            w.after_format();
        });
        self.ruler.connect_guides(|| {
            for d in Doc::all() {
                d.guides_area.queue_draw();
            }
        });
        self.place_ruler();
    }

    /// La règle : visible si demandée, sur un document texte.
    pub(super) fn place_ruler(&self) {
        let doc = self.doc();
        let shown = crate::prefs::get().show_ruler && !doc.is_pdf();
        self.ruler.widget.set_visible(shown);
        self.ruler.set_view(if doc.is_pdf() { None } else { Some(&doc.view) });
    }
}
