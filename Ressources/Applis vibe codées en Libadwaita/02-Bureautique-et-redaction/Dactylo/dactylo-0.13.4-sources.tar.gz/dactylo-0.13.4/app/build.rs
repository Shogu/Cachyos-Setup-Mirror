// Icônes symboliques de Samizdat, compilées dans le binaire.
fn main() {
    glib_build_tools::compile_resources(&["icons"], "icons/samizdat.gresource.xml", "samizdat.gresource");
}
