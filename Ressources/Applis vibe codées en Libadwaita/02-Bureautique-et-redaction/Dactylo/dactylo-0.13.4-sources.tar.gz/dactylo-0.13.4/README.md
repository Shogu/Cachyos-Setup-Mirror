# Samizdat

Samizdat est un traitement de texte simple pour GNOME, écrit en Rust avec GTK 4
et libadwaita. Il ouvre, modifie et enregistre des documents Word (DOCX),
OpenDocument (ODT) et Markdown, et les exporte en PDF.

L'objectif n'est pas de remplacer LibreOffice ou OnlyOffice : c'est un éditeur
léger, rapide à lancer, intégré au bureau GNOME, pour écrire et retoucher des
documents courants.

## D'où vient-il ?

Samizdat repose sur **letters-core**, le moteur de documents du projet
[gtk-office-suite](https://github.com/tuna-os/gtk-office-suite) (GPL-3.0). Ce
moteur fournit le modèle de document et la lecture et l'écriture des formats.
Samizdat y ajoute sa propre interface.

## Ce qu'il sait faire

- **Formats :** il ouvre le DOCX, l'ODT, le Markdown, le texte brut et le HTML,
  enregistre dans ces mêmes formats et exporte en PDF.
- **Mise en forme du texte :** police, taille, couleur, surlignage en six
  couleurs, gras, italique, souligné et barré.
- **Paragraphes :** styles (corps de texte, titres), alignements,
  interligne (simple, 1,15, 1,5, double), listes à puces et numérotées sur
  plusieurs niveaux, retraits.
- **Typographie française** pendant la frappe : espace insécable avant
  « : ; ! ? », guillemets « », apostrophe ’ (désactivable).
- **Cartouches :** la sélection encadrée d'un clic, six cartouches nommés
  (Définition, Problématique, À retenir, Extrait, Document, Sujet) et toutes
  les autres allures dans « Personnaliser… », conservées en DOCX et en ODT
  (Word n'a que des coins carrés). Entrée passe à la ligne dans le
  cartouche, Entrée sur une ligne vide en sort. Un titre mis dans un
  cartouche reste dans le Plan.
- **Lignes numérotées** de 5 en 5 dans la marge, comme dans les sujets
  d'examen : de nouveau à 1 pour chaque texte (aperçu, PDF, DOCX, ODT).
- **Tableaux :** un éditeur en vraie grille (double-clic sur un tableau pour le
  modifier), ajout et suppression de lignes et de colonnes.
- **Formes** simples (flèches, carré, rectangle, rond, étoile ; pleines ou
  transparentes) et **liens**.
- **Frise chronologique :** dates, périodes (« 1914-1918 ») et événements,
  dessinés à l'échelle, avec un aperçu ; un double-clic sur la frise la
  rouvre pour la modifier, même après un passage par Word.
- **Images :** insertion, redimensionnement à la souris par une poignée au coin,
  et une fenêtre Image (double-clic) : taille, recadrage, rotation,
  retournement, luminosité, contraste, coins arrondis, cadre fin, légende
  (éventuellement numérotée « Document 1, 2… »). Une image se colle
  (Ctrl+V, capture d'écran ou « Copier l'image » d'un navigateur) ou se
  glisse depuis le gestionnaire de fichiers ou une page web ; elle se place
  toujours seule sur sa ligne.
- **Orthographe** en français (Hunspell), avec suggestions au clic droit et
  dictionnaire personnel.
- **Mise en page :** format du papier, orientation, marges (avec un réglage
  « marges étroites »), en-tête et pied de page en trois zones (à gauche,
  au centre, à droite) sur une ou deux lignes, numéros de page placés où on
  veut, une à trois colonnes (équilibrées sur la dernière page).
- **Table des matières** insérée depuis le panneau Plan, avec les numéros
  de page, mise à jour à chaque enregistrement.
- **Modèles :** le bouton Nouveau propose les modèles rangés dans
  ~/.local/share/samizdat/modeles ; on peut y importer ses propres modèles
  ou enregistrer le document courant comme modèle. Quatre modèles sont
  fournis : Cours, Page de garde de séquence, Bac blanc Français et Bac
  blanc Histoire-Géographie (sur le modèle des sujets académiques : trois
  parties, dossier documentaire, questions, annexes à rendre).
- **Aménagements :** un PDF adapté, « Nom (aménagé).pdf », sans toucher au
  document : police Luciole (basse vision) ou OpenDyslexic (dyslexie),
  toutes deux fournies, 16 ou 20 points, interligne aéré, texte aligné à
  gauche, une ligne sur deux teintée, grand contraste.
- **Livret de séquence :** les documents d'un dossier (DOCX, ODT, PDF…),
  dans l'ordre voulu, réunis en un seul PDF avec une page de garde, un
  sommaire et les pages numérotées.
- **Préférences :** police et taille des nouveaux documents, modèle de
  départ, dossier des documents, premier titre comme nom de fichier,
  orthographe à l'ouverture, PDF enregistré à chaque enregistrement,
  images seules sur leur ligne, légendes numérotées, boutons de la barre
  d'outils à afficher, Plan au démarrage, zoom, mode concentration.
- **Aperçu** des pages et **zoom** de toute la feuille (texte et images).
- **Onglets :** plusieurs documents dans une fenêtre (Ctrl+T, Ctrl+W,
  Ctrl+Pg.Préc/Pg.Suiv, Alt+1…9), vue d'ensemble en miniatures, onglet
  glissé hors de la fenêtre pour en faire une nouvelle.
- **PDF en lecture seule** dans un onglet, à côté des documents qu'on
  rédige : zoom, recherche (Ctrl+F), sélection du texte à la souris, copié
  aussitôt pour être collé dans un document.
- **Mode concentration** (F11) : plein écran, barres cachées, la ligne en
  cours reste au milieu de l'écran.
- **Navigation :** plan du document dans un panneau latéral, rechercher et
  remplacer.
- **Enregistrer et Exporter :** deux boutons. Enregistrer (et dans sa
  flèche : enregistrer sous, comme modèle). Exporter en PDF (et dans sa
  flèche : DOCX et PDF d'un coup, livret de séquence, copie sur une clé
  USB dans le dossier choisi).
- **Confort :** annuler et rétablir, documents récents, copie de secours et
  récupération après un plantage, glisser-déposer d'un fichier, alerte avant
  de fermer un document non enregistré (une seule question pour tous les
  onglets).

L'interface n'utilise que les composants natifs de GNOME (barre de titre,
dialogues, panneau latéral, notifications, sélecteurs de police et de
couleur…), et suit le thème clair ou sombre du système. La barre d'outils
s'adapte à la largeur de la fenêtre : les groupes se replient en menus quand
la place manque. La page reste blanche, comme une feuille de papier.

## Ce qui a été ajouté par rapport au projet d'origine

- **Une nouvelle interface**, plus simple, construite autour de l'éditeur de
  texte de GTK.
- **Les commandes** de police, de couleur, de retraits, de recherche, de
  tableaux, de mise en page, d'images et de plan, toutes branchées sur le
  modèle de letters-core : chaque action s'annule d'un seul Ctrl+Z.
- **La frappe passe par le modèle de document :** le texte tapé reprend le style
  voulu, et le curseur reste au bon endroit après un saut de paragraphe.
- **Des corrections dans letters-core :**
  - à la lecture d'un DOCX, les tableaux restaient en fin de document ; ils
    sont remis à leur place ;
  - chaque enregistrement ajoutait des paragraphes vides autour des images et
    après les tableaux ; le document reste maintenant identique d'un
    enregistrement à l'autre ;
  - les images restent dans leur paragraphe, ce qui conserve leur alignement ;
  - les tableaux sont enregistrés avec un quadrillage (Word les affichait sans
    bordure) ;
  - le surlignage peut avoir une couleur, lue et écrite en DOCX et en ODT ;
  - les colonnes sont équilibrées sur la dernière page dans l'aperçu et le
    PDF ;
  - un en-tête ou un pied de page qui numérote les pages est centré, dans
    le PDF comme dans le DOCX et l'ODT.

## Limites connues

- Les tableaux s'affichent sous forme de grille de texte dans l'éditeur. Ce
  sont de vrais tableaux dans le DOCX, l'ODT et le PDF.
- Pendant la saisie, le texte défile en continu, sans séparation en pages.
  L'export PDF, lui, est paginé.
- Les colonnes ne s'affichent pas dans l'éditeur, seulement dans l'aperçu
  et le PDF. Word, lui, remplit les colonnes l'une après l'autre sans les
  équilibrer.
- Dans l'éditeur, la table des matières n'a pas de points de conduite
  (ils apparaissent dans l'aperçu et le PDF).
- Les cartouches ne flottent pas : ils restent dans le fil du texte. Leurs
  lignes sont des sauts de ligne d'un même paragraphe (une seule liste ou
  un seul alignement par cartouche).
- Word ne numérote pas les lignes dans un tableau : un cartouche aux lignes
  numérotées ne l'est que dans l'aperçu et le PDF. Dans Word, la numérotation
  repart à 1 à chaque page.
- Les images ne se placent pas librement sur la page : elles suivent le
  texte, seules sur leur ligne.
- Les formes sont des images : dans Word, elles ne sont pas modifiables comme
  des formes.
- Les commentaires et le suivi des modifications ne sont pas proposés.

## Compiler et installer

Sur Arch Linux, avec le PKGBUILD fourni :

    makepkg -si

À la main :

    cargo build --release
    xvfb-run cargo test -p samizdat    # les tests GTK ont besoin d'un affichage

Le `[patch.crates-io]` du `Cargo.toml` (fork épinglé d'`oxml-layout`) est
nécessaire à la compilation.

## Licence

GPL-3.0-or-later, comme letters-core.
