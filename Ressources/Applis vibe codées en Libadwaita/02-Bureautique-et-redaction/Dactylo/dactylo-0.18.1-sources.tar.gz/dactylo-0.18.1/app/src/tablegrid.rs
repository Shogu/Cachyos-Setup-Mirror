// tablegrid.rs — les tableaux dessinés dans l'éditeur.
//
// L'éditeur garde les tableaux en texte (« | a | b | ») ; ici on les habille
// pour qu'ils ressemblent à l'Aperçu : la ligne de tirets est masquée, les
// colonnes sont alignées (un espacement ajouté après le texte de chaque case,
// d'après la largeur du document quand elle est connue), les barres sont
// effacées et un quadrillage, avec le fond des cases, est dessiné par-dessus
// la page.
// SPDX-License-Identifier: GPL-3.0-or-later

use gtk4 as gtk;
use gtk::glib;
use gtk::prelude::*;

const VIEW_KEY: &str = "dactylo-view";

/// La vue d'un tampon (pour mesurer le texte).
pub fn remember_view(buf: &gtk::TextBuffer, view: &gtk::TextView) {
    unsafe { buf.set_data(VIEW_KEY, view.downgrade()) };
}

fn view_of(buf: &gtk::TextBuffer) -> Option<gtk::TextView> {
    unsafe { buf.data::<glib::WeakRef<gtk::TextView>>(VIEW_KEY).and_then(|w| w.as_ref().upgrade()) }
}

fn is_row(l: &str) -> bool {
    let t = l.trim();
    t.starts_with('|') && t.ends_with('|') && t.len() >= 2
}

fn single(l: &str) -> bool {
    let t = l.trim();
    t.len() >= 2 && !t[1..t.len() - 1].contains('|')
}

/// Les tableaux du texte : (rang du tableau parmi tous, lignes du tableau
/// sans la ligne de tirets, ligne de tirets, zone de texte d'une case).
fn all_tables(lines: &[&str]) -> Vec<(usize, Vec<usize>, usize, bool)> {
    let mut out = Vec::new();
    let mut ordinal: Option<usize> = None;
    let mut i = 0;
    while i < lines.len() {
        let header = is_row(lines[i]) && lines.get(i + 1).is_some_and(|d| letters_core::table_text::is_delimiter_line(d));
        if !header {
            i += 1;
            continue;
        }
        ordinal = Some(ordinal.map_or(0, |n| n + 1));
        let mut rows = vec![i];
        let mut j = i + 2;
        while j < lines.len() && is_row(lines[j]) && !lines.get(j + 1).is_some_and(|d| letters_core::table_text::is_delimiter_line(d)) {
            rows.push(j);
            j += 1;
        }
        // Une zone de texte (une case) a son propre habillage.
        let textbox = rows.len() == 1 && single(lines[i]);
        out.push((ordinal.unwrap_or(0), rows, i + 1, textbox));
        i = j;
    }
    out
}

/// Les tableaux à plusieurs cases.
fn tables(lines: &[&str]) -> Vec<(usize, Vec<usize>, usize)> {
    all_tables(lines).into_iter().filter(|t| !t.3).map(|(o, r, d, _)| (o, r, d)).collect()
}

/// Le cadre des cartouches (zones de texte d'une case) : coins, trait.
fn draw_cartouches(view: &gtk::TextView, area: &gtk::DrawingArea, cr: &gtk::cairo::Context, lines: &[&str], styles: &crate::bridge::CellStyles) {
    let buf = view.buffer();
    let inset = f64::from(crate::bridge::EDITOR_LEFT_MARGIN_PX + 14);
    let ink = view.color();
    for (ordinal, rows, _, textbox) in all_tables(lines) {
        if !textbox {
            continue;
        }
        let look = styles.iter().find(|((o, r, c), _)| *o == ordinal && *r == 0 && *c == 0).and_then(|(_, st)| st.cartouche).unwrap_or_default();
        let width = match look.line {
            letters_core::model::CartoucheLine::None => continue,
            letters_core::model::CartoucheLine::Thin => 1.0,
            letters_core::model::CartoucheLine::Medium => 2.0,
            letters_core::model::CartoucheLine::Thick => 3.0,
        };
        let Some(it) = buf.iter_at_line(rows[0] as i32) else { continue };
        let (y, h) = view.line_yrange(&it);
        let (wx0, wy) = view.buffer_to_window_coords(gtk::TextWindowType::Widget, inset as i32, y);
        let wx1 = f64::from(view.width()) - inset;
        let (Some(p0), Some(p1)) = (
            view.compute_point(area, &gtk::graphene::Point::new(wx0 as f32, wy as f32)),
            view.compute_point(area, &gtk::graphene::Point::new(wx1 as f32, (wy + h) as f32)),
        ) else {
            continue;
        };
        let (x0, y0, x1, y1) = (f64::from(p0.x()) + width / 2.0, f64::from(p0.y()) + width / 2.0, f64::from(p1.x()) - width / 2.0, f64::from(p1.y()) - width / 2.0);
        let r = if look.square { 0.0 } else { 8.0f64.min((y1 - y0) / 2.0) };
        cr.new_sub_path();
        if r > 0.0 {
            use std::f64::consts::{FRAC_PI_2, PI};
            cr.arc(x1 - r, y0 + r, r, -FRAC_PI_2, 0.0);
            cr.arc(x1 - r, y1 - r, r, 0.0, FRAC_PI_2);
            cr.arc(x0 + r, y1 - r, r, FRAC_PI_2, PI);
            cr.arc(x0 + r, y0 + r, r, PI, 1.5 * PI);
            cr.close_path();
        } else {
            cr.rectangle(x0, y0, x1 - x0, y1 - y0);
        }
        // Le fond du paragraphe commence avec le texte : on le prolonge
        // jusqu'au cadre, pour laisser de l'air autour du texte.
        let frame = cr.copy_path();
        let _ = cr.save();
        cr.clip();
        let gap = 12.0;
        let fill = if look.white { (0xfd, 0xfd, 0xfc) } else { (0xf6, 0xf5, 0xf4) };
        cr.set_source_rgb(f64::from(fill.0) / 255.0, f64::from(fill.1) / 255.0, f64::from(fill.2) / 255.0);
        cr.rectangle(x0 - width, y0, gap + width, y1 - y0);
        cr.rectangle(x1 - gap, y0, gap + width, y1 - y0);
        let _ = cr.fill();
        let _ = cr.restore();
        if let Ok(frame) = frame {
            cr.append_path(&frame);
        }
        cr.set_source_rgba(f64::from(ink.red()), f64::from(ink.green()), f64::from(ink.blue()), 0.75);
        cr.set_line_width(width);
        let _ = cr.stroke();
    }
}

/// Les cases d'une ligne : (décalage du premier caractère, nombre de
/// caractères) entre deux barres.
fn cells(line: &str) -> Vec<(usize, usize)> {
    let mut out = Vec::new();
    let chars: Vec<char> = line.chars().collect();
    let pipes: Vec<usize> = chars.iter().enumerate().filter(|(_, c)| **c == '|').map(|(i, _)| i).collect();
    for w in pipes.windows(2) {
        out.push((w[0] + 1, w[1] - w[0] - 1));
    }
    out
}

/// Aligne les colonnes et masque la ligne de tirets.
pub fn decorate(buf: &gtk::TextBuffer) {
    // Les anciens espacements et réductions.
    let mut old = Vec::new();
    buf.tag_table().foreach(|t| {
        if t.name().is_some_and(|n| n.starts_with("table-pad-") || n.starts_with("table-scale-")) {
            old.push(t.clone());
        }
    });
    let (s, e) = buf.bounds();
    for t in &old {
        buf.remove_tag(t, &s, &e);
    }
    let Some(view) = view_of(buf) else { return };
    // Barres effacées et ligne de tirets masquée : au-dessus de toute autre
    // balise (la couleur propre d'un texte, par exemple).
    for (name, hide) in [("table-pipe", false), ("table-hide", true)] {
        let t = buf.tag_table().lookup(name).unwrap_or_else(|| {
            let t = gtk::TextTag::new(Some(name));
            buf.tag_table().add(&t);
            t
        });
        if hide {
            t.set_invisible(true);
        } else {
            // Presque transparente (une couleur tout à fait transparente
            // est ignorée par le rendu du texte).
            t.set_foreground_rgba(Some(&gtk::gdk::RGBA::new(0.5, 0.5, 0.5, 0.01)));
        }
        t.set_priority(buf.tag_table().size() - 1);
    }
    let text = buf.slice(&s, &e, true);
    let lines: Vec<&str> = text.split('\n').collect();
    let mut starts = Vec::with_capacity(lines.len());
    let mut off = 0i32;
    for l in &lines {
        starts.push(off);
        off += l.chars().count() as i32 + 1;
    }
    let styles = crate::bridge::cell_styles(buf);
    // px par point : la largeur de texte de la vue sur celle de la page.
    let page = crate::bridge::page_sidecar(buf).unwrap_or_default();
    let text_pt = if page.width_pt > 0.0 { page.width_pt - page.margin_left_pt - page.margin_right_pt } else { 481.9 };
    // (un peu de marge : la ligne ne doit jamais passer à la ligne)
    let text_px = f64::from(view.width() - view.left_margin() - view.right_margin()).max(200.0) * 0.96;
    let px_per_pt = text_px / text_pt.max(100.0);
    let pipe = buf.tag_table().lookup("table-pipe");
    let nowrap = buf.tag_table().lookup("table-nowrap").unwrap_or_else(|| {
        let t = gtk::TextTag::builder().name("table-nowrap").wrap_mode(gtk::WrapMode::None).build();
        buf.tag_table().add(&t);
        t
    });
    buf.remove_tag(&nowrap, &s, &e);
    for (ordinal, rows, delim) in tables(&lines) {
        // Mesurées sans retour à la ligne : la largeur naturelle de chaque case.
        let last_row = *rows.last().unwrap_or(&rows[0]);
        let (first, last) = (buf.iter_at_offset(starts[rows[0]]), buf.iter_at_offset(starts[last_row] + lines[last_row].chars().count() as i32));
        buf.apply_tag(&nowrap, &first, &last);
        let grid: Vec<Vec<(usize, usize)>> = rows.iter().map(|&r| cells(lines[r])).collect();
        let cols = grid.iter().map(Vec::len).max().unwrap_or(0);
        if cols == 0 {
            continue;
        }
        let prop = |r: usize, c: usize| {
            styles.iter().find(|((o, rr, cc), _)| *o == ordinal && *rr as usize == r && *cc as usize == c).and_then(|(_, st)| st.table_cell)
        };
        let span = |r: usize, c: usize| prop(r, c).map_or(1, |t| if t.covered { 0 } else { t.span() as usize });
        // La largeur réelle de chaque case, mesurée dans la vue (la ligne ne
        // passe pas à la ligne : table-line l'interdit) — police, gras,
        // accents compris ; et celle d'une barre.
        let x_at = |off: i32| {
            let it = buf.iter_at_offset(off);
            let loc = view.iter_location(&it);
            (f64::from(loc.x()), f64::from(loc.width()))
        };
        let measure = || {
            let mut natural: Vec<Vec<f64>> = Vec::with_capacity(rows.len());
            let mut bar = 0.0f64;
            for (ri, &r) in rows.iter().enumerate() {
                let mut row = Vec::with_capacity(grid[ri].len());
                for &(start, n) in &grid[ri] {
                    let (x0, w0) = x_at(starts[r] + start as i32 - 1);
                    let (x1, _) = x_at(starts[r] + (start + n) as i32);
                    bar = bar.max(w0);
                    row.push((x1 - x0 - w0).max(0.0));
                }
                natural.push(row);
            }
            (natural, bar)
        };
        let (mut natural, mut bar) = measure();
        // La largeur de chaque colonne : celle du document si elle est
        // connue, au moins celle du texte des cases non fusionnées.
        let mut floor = vec![0.0f64; cols];
        for (r, row) in natural.iter().enumerate() {
            for (c, &w) in row.iter().enumerate() {
                if span(r, c) == 1 {
                    floor[c] = floor[c].max(w);
                }
            }
        }
        let mut target = floor.clone();
        for (c, t) in target.iter_mut().enumerate() {
            let w = styles
                .iter()
                .filter(|((o, _, col), _)| *o == ordinal && *col as usize == c)
                .filter_map(|(_, st)| st.table_cell)
                .find(|tc| tc.span() == 1 && !tc.covered && tc.width_tw > 0)
                .map(|tc| f64::from(tc.width_tw) / 20.0 * px_per_pt - bar);
            if let Some(w) = w {
                *t = t.max(w);
            }
        }
        // Une case fusionnée plus large que ses colonnes : la dernière grandit.
        for (r, row) in natural.iter().enumerate() {
            for (c, &w) in row.iter().enumerate() {
                let k = span(r, c);
                if k > 1 && c + k <= cols {
                    let have: f64 = target[c..c + k].iter().sum::<f64>() + (k - 1) as f64 * bar;
                    if w > have {
                        target[c + k - 1] += w - have;
                    }
                }
            }
        }
        // Pas plus large que la page : d'abord les colonnes qui ont de la
        // place ; si le texte seul est trop large, le tableau est réduit
        // (jusqu'aux deux tiers), comme une case dont le texte serait plus
        // petit. Au-delà, il garde sa grille de texte.
        let bars = (cols + 1) as f64 * bar;
        let avail = text_px - bars;
        let total: f64 = target.iter().sum();
        if total > avail {
            let room: f64 = target.iter().zip(&floor).map(|(t, f)| t - f).sum();
            let k = ((total - avail) / room.max(1.0)).min(1.0);
            for (t, f) in target.iter_mut().zip(&floor) {
                *t -= (*t - f) * k;
            }
        }
        let needed: f64 = target.iter().sum::<f64>() + bars;
        let scale = if needed > text_px { text_px / needed } else { 1.0 };
        if scale < 0.66 {
            // Trop large même réduit : la grille de texte, qui passe à la ligne.
            buf.remove_tag(&nowrap, &first, &last);
            continue;
        }
        if scale < 1.0 {
            let step = (scale * 20.0).floor() / 20.0; // par pas de 5 %
            let name = format!("table-scale-{}", (step * 100.0) as i32);
            let tag = buf.tag_table().lookup(&name).unwrap_or_else(|| {
                let t = gtk::TextTag::builder().name(&name).scale(step).build();
                buf.tag_table().add(&t);
                t
            });
            buf.apply_tag(&tag, &first, &last);
        }
        // Réduit : on mesure à nouveau (la taille des polices ne varie pas
        // tout à fait en proportion), et les colonnes suivent la réduction.
        if scale < 1.0 {
            let step = (scale * 20.0).floor() / 20.0;
            for t in target.iter_mut() {
                *t *= step;
            }
            (natural, bar) = measure();
            // (sans jamais passer sous le texte réduit)
            for (r, row) in natural.iter().enumerate() {
                for (c, &w) in row.iter().enumerate() {
                    if span(r, c) == 1 {
                        target[c] = target[c].max(w);
                    }
                }
            }
        }
        let k = 1.0;
        for (ri, &r) in rows.iter().enumerate() {
            for (c, &(start, n)) in grid[ri].iter().enumerate() {
                let sp = span(ri, c);
                if sp == 0 {
                    continue; // masquée : la case fusionnée prend sa place
                }
                // Une case fusionnée couvre ses colonnes et le texte des
                // cases masquées (avec leurs barres).
                let end = (c + sp).min(cols);
                let width: f64 = target[c..end].iter().sum::<f64>() + (end - c - 1) as f64 * bar;
                let covered: f64 = natural[ri][c + 1..end.min(natural[ri].len())].iter().map(|w| w + bar).sum();
                let need = ((width - natural[ri][c] - covered) * k * f64::from(gtk::pango::SCALE)).round() as i32;
                if need < gtk::pango::SCALE {
                    continue;
                }
                // L'espace après le texte de la case (ou la barre d'avant).
                let at = starts[r] + (if n > 0 { start + n - 1 } else { start - 1 }) as i32;
                // (par pas d'un quart de pixel : peu de balises différentes)
                let need = need / (gtk::pango::SCALE / 4) * (gtk::pango::SCALE / 4);
                let name = format!("table-pad-{need}");
                let tag = buf.tag_table().lookup(&name).unwrap_or_else(|| {
                    let t = gtk::TextTag::builder().name(&name).letter_spacing(need).build();
                    buf.tag_table().add(&t);
                    t
                });
                buf.apply_tag(&tag, &buf.iter_at_offset(at), &buf.iter_at_offset(at + 1));
            }
            // Les barres : effacées, le quadrillage les remplace.
            if let Some(pipe) = &pipe {
                for (i, ch) in lines[r].chars().enumerate() {
                    if ch == '|' {
                        let a = starts[r] + i as i32;
                        buf.apply_tag(pipe, &buf.iter_at_offset(a), &buf.iter_at_offset(a + 1));
                    }
                }
            }
        }
        // La ligne de tirets disparaît.
        let a = buf.iter_at_offset(starts[delim]);
        let b = buf.iter_at_offset(starts[delim] + lines[delim].chars().count() as i32 + 1);
        buf.apply_tag_by_name("table-hide", &a, &b);
    }
}

/// Le quadrillage et le fond des cases, dessinés sur `area` (posée sur la
/// page, au-dessus de la vue).
pub fn draw(view: &gtk::TextView, area: &gtk::DrawingArea, cr: &gtk::cairo::Context) {
    let buf = view.buffer();
    let (s, e) = buf.bounds();
    let text = buf.slice(&s, &e, true);
    if !text.contains('|') {
        draw_para_borders(view, area, cr);
        return;
    }
    let lines: Vec<&str> = text.split('\n').collect();
    let styles = crate::bridge::cell_styles(&buf);
    let ink = view.color();
    let to_area = |x: i32, y: i32| -> Option<(f64, f64)> {
        let (wx, wy) = view.buffer_to_window_coords(gtk::TextWindowType::Widget, x, y);
        let p = view.compute_point(area, &gtk::graphene::Point::new(wx as f32, wy as f32))?;
        Some((f64::from(p.x()), f64::from(p.y())))
    };
    draw_cartouches(view, area, cr, &lines, &styles);
    draw_para_borders(view, area, cr);
    let pipe = buf.tag_table().lookup("table-pipe");
    for (ordinal, rows, _) in tables(&lines) {
        // Un tableau trop long pour être aligné garde sa grille de texte.
        let dressed = pipe.as_ref().zip(buf.iter_at_line(rows[0] as i32)).is_some_and(|(t, it)| it.has_tag(t));
        if !dressed {
            continue;
        }
        // Chaque ligne : son haut, son bas et l'abscisse de ses barres.
        let mut geo: Vec<(f64, f64, Vec<f64>)> = Vec::new();
        for &r in &rows {
            let Some(it) = buf.iter_at_line(r as i32) else { continue };
            let (y, h) = view.line_yrange(&it);
            let Some((_, top)) = to_area(0, y) else { continue };
            let bottom = top + f64::from(h) - f64::from(view.pixels_below_lines()) / 2.0;
            let mut xs = Vec::new();
            let mut it = it;
            for ch in lines[r].chars() {
                if ch == '|' {
                    let loc = view.iter_location(&it);
                    if let Some((x, _)) = to_area(loc.x() + loc.width() / 2, loc.y()) {
                        xs.push(x);
                    }
                }
                it.forward_char();
            }
            geo.push((top - 2.0, bottom, xs));
        }
        let prop = |r: usize, c: usize| {
            styles.iter().find(|((o, rr, cc), _)| *o == ordinal && *rr as usize == r && *cc as usize == c).and_then(|(_, st)| st.table_cell)
        };
        // Fonds (légers : le texte reste lisible au-dessus).
        for (r, (top, bottom, xs)) in geo.iter().enumerate() {
            for c in 0..xs.len().saturating_sub(1) {
                if let Some([red, g, b]) = prop(r, c).and_then(|t| t.fill) {
                    cr.set_source_rgba(f64::from(red) / 255.0, f64::from(g) / 255.0, f64::from(b) / 255.0, 0.4);
                    cr.rectangle(xs[c], *top, xs[c + 1] - xs[c], bottom - top);
                    let _ = cr.fill();
                }
            }
        }
        let no_border = styles.iter().filter(|((o, _, _), _)| *o == ordinal).filter_map(|(_, st)| st.table_cell).all(|t| t.no_border)
            && styles.iter().any(|((o, _, _), _)| *o == ordinal);
        cr.set_source_rgba(f64::from(ink.red()), f64::from(ink.green()), f64::from(ink.blue()), if no_border { 0.15 } else { 0.5 });
        cr.set_line_width(1.0);
        for (r, (top, bottom, xs)) in geo.iter().enumerate() {
            let (Some(&x0), Some(&x1)) = (xs.first(), xs.last()) else { continue };
            // Le trait du haut, sauf au-dessus d'une case fusionnée vers le haut.
            for c in 0..xs.len().saturating_sub(1) {
                if prop(r, c).is_some_and(|t| t.vmerge == 2) {
                    continue;
                }
                cr.move_to(xs[c], top.round() + 0.5);
                cr.line_to(xs[c + 1], top.round() + 0.5);
            }
            if r + 1 == geo.len() {
                cr.move_to(x0, bottom.round() + 0.5);
                cr.line_to(x1, bottom.round() + 0.5);
            }
            // Les traits verticaux, sauf à gauche d'une case masquée par une fusion.
            for (c, x) in xs.iter().enumerate() {
                if c > 0 && c + 1 < xs.len() && prop(r, c).is_some_and(|t| t.covered) {
                    continue;
                }
                cr.move_to(x.round() + 0.5, *top);
                cr.line_to(x.round() + 0.5, *bottom);
            }
        }
        let _ = cr.stroke();
    }
}

/// Samizdat : le cadre des paragraphes encadrés ; des paragraphes voisins
/// au même cadre n'en forment qu'un, comme dans Word.
fn draw_para_borders(view: &gtk::TextView, area: &gtk::DrawingArea, cr: &gtk::cairo::Context) {
    let buf = view.buffer();
    let n = buf.line_count();
    // (ligne de début, ligne de fin, cadre, tag)
    let mut boxes: Vec<(i32, i32, letters_core::model::ParaBorder, gtk::TextTag)> = Vec::new();
    for line in 0..n {
        let Some(it) = buf.iter_at_line(line) else { continue };
        let found = it.tags().into_iter().find_map(|t| {
            let name = t.name()?;
            let bd = name.split(';').find_map(|p| p.strip_prefix("bd=").or_else(|| p.split_once("bd=").map(|x| x.1)))?;
            let mut f = bd.split(',');
            let sides: u8 = f.next()?.parse().ok()?;
            let width: u16 = f.next()?.parse().ok()?;
            let c = f.next()?;
            let h = |i: usize| c.get(i..i + 2).and_then(|x| u8::from_str_radix(x, 16).ok());
            Some((letters_core::model::ParaBorder { sides, width, color: [h(0)?, h(2)?, h(4)?] }, t))
        });
        match (found, boxes.last_mut()) {
            (Some((bd, _)), Some(last)) if last.1 == line - 1 && last.2 == bd => last.1 = line,
            (Some((bd, t)), _) => boxes.push((line, line, bd, t)),
            _ => {}
        }
    }
    for (first, last, bd, tag) in boxes {
        let (Some(a), Some(b)) = (buf.iter_at_line(first), buf.iter_at_line(last)) else { continue };
        let (ya, _) = view.line_yrange(&a);
        let (yb, hb) = view.line_yrange(&b);
        let lm = if tag.is_left_margin_set() { tag.left_margin() } else { view.left_margin() };
        let rm = if tag.is_right_margin_set() { tag.right_margin() } else { view.right_margin() };
        let pad = 4;
        let (wx0, wy0) = view.buffer_to_window_coords(gtk::TextWindowType::Widget, lm - pad, ya + tag.pixels_above_lines() / 2);
        let (wx1, wy1) = view.buffer_to_window_coords(gtk::TextWindowType::Widget, view.width() - rm + pad, yb + hb - tag.pixels_below_lines() / 2);
        let (Some(p0), Some(p1)) = (
            view.compute_point(area, &gtk::graphene::Point::new(wx0 as f32, wy0 as f32)),
            view.compute_point(area, &gtk::graphene::Point::new(wx1 as f32, wy1 as f32)),
        ) else {
            continue;
        };
        let (x0, y0, x1, y1) = (f64::from(p0.x()).round() + 0.5, f64::from(p0.y()).round() + 0.5, f64::from(p1.x()).round() + 0.5, f64::from(p1.y()).round() + 0.5);
        let [r, g, b] = bd.color;
        cr.set_source_rgb(f64::from(r) / 255.0, f64::from(g) / 255.0, f64::from(b) / 255.0);
        cr.set_line_width((f64::from(bd.width) / 8.0 * 96.0 / 72.0).max(1.0));
        use letters_core::model::ParaBorder as B;
        let seg = |a: (f64, f64), b: (f64, f64)| {
            cr.move_to(a.0, a.1);
            cr.line_to(b.0, b.1);
        };
        if bd.sides & B::TOP != 0 { seg((x0, y0), (x1, y0)); }
        if bd.sides & B::BOTTOM != 0 { seg((x0, y1), (x1, y1)); }
        if bd.sides & B::LEFT != 0 { seg((x0, y0), (x0, y1)); }
        if bd.sides & B::RIGHT != 0 { seg((x1, y0), (x1, y1)); }
        let _ = cr.stroke();
    }
}
