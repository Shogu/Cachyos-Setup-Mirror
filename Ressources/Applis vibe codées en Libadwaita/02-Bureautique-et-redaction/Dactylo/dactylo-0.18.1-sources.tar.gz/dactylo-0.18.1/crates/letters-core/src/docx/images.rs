// images.rs — partie de docx.rs, découpé par thème.
// SPDX-License-Identifier: GPL-3.0-or-later

#![allow(unused_imports)]
use super::*;
use crate::model::{Alignment, Document, ListKind, PageGeometry, Paragraph, ParaStyle, Run, RunStyle};
use rdocx_oxml::shared::ST_Jc;

/// Samizdat : un EMF/WMF (format vectoriel de Windows) ne se décode pas ici.
/// On le remplace par un cadre gris légendé, en PNG.
#[cfg(feature = "render")]
pub(crate) fn metafile_placeholder(bytes: &[u8]) -> Option<Vec<u8>> {
    let emf = bytes.len() > 44 && bytes[..4] == [1, 0, 0, 0] && &bytes[40..44] == b" EMF";
    let wmf = bytes.starts_with(&[0xD7, 0xCD, 0xC6, 0x9A]) || bytes.starts_with(&[1, 0, 9, 0]) || bytes.starts_with(&[2, 0, 9, 0]);
    if !emf && !wmf {
        return None;
    }
    let (w, h) = (480, 270);
    let surface = cairo::ImageSurface::create(cairo::Format::ARgb32, w, h).ok()?;
    {
        let cr = cairo::Context::new(&surface).ok()?;
        cr.set_source_rgb(0.96, 0.96, 0.95);
        cr.paint().ok()?;
        cr.set_source_rgb(0.6, 0.6, 0.59);
        cr.set_line_width(3.0);
        cr.set_dash(&[10.0, 6.0], 0.0);
        cr.rectangle(4.0, 4.0, w as f64 - 8.0, h as f64 - 8.0);
        cr.stroke().ok()?;
        cr.set_source_rgb(0.37, 0.36, 0.39);
        cr.select_font_face("Sans", cairo::FontSlant::Normal, cairo::FontWeight::Normal);
        cr.set_font_size(22.0);
        for (i, line) in ["Image au format Windows (EMF/WMF)", "non affichable"].iter().enumerate() {
            let ext = cr.text_extents(line).ok()?;
            cr.move_to((w as f64 - ext.width()) / 2.0, h as f64 / 2.0 - 6.0 + i as f64 * 32.0);
            cr.show_text(line).ok()?;
        }
    }
    let mut png = Vec::new();
    surface.write_to_png(&mut png).ok()?;
    Some(png)
}

/// Samizdat : les recadrages de Word (<a:srcRect>), appliqués aux images
/// elles-mêmes, dans l'ordre du document. Si le nombre d'images ne
/// correspond pas (image dans une zone non lue), on ne touche à rien.
#[cfg(feature = "render")]
pub(crate) fn apply_crops(path: &str, doc: &mut Document) {
    let Ok(bytes) = std::fs::read(path) else { return };
    let mut xml = String::new();
    let Some(_) = zip::ZipArchive::new(std::io::Cursor::new(&bytes))
        .ok()
        .and_then(|mut z| std::io::Read::read_to_string(&mut z.by_name("word/document.xml").ok()?, &mut xml).ok())
    else {
        return;
    };
    if !xml.contains("srcRect") {
        return;
    }
    let xml = crate::docx_alt::unwrap(&xml).unwrap_or(xml);
    let crops = crate::docx_alt::crops(&xml);
    let images: Vec<&mut Run> = doc.paragraphs.iter_mut().flat_map(|p| p.runs.iter_mut()).filter(|r| r.style.image.is_some()).collect();
    if images.len() != crops.len() {
        return;
    }
    for (run, crop) in images.into_iter().zip(crops) {
        let Some([l, t, r, b]) = crop else { continue };
        let Some(src) = run.style.image.clone() else { continue };
        let Ok(pb) = gdk_pixbuf::Pixbuf::from_file(&src) else { continue };
        let (w, h) = (pb.width() as f64, pb.height() as f64);
        // Valeurs en millièmes de pour cent ; négatives = marge ajoutée,
        // ignorée ici.
        let f = |v: i32| (v.max(0) as f64) / 100_000.0;
        let x = (w * f(l)).round() as i32;
        let y = (h * f(t)).round() as i32;
        let cw = (w * (1.0 - f(l) - f(r))).round() as i32;
        let ch = (h * (1.0 - f(t) - f(b))).round() as i32;
        if cw < 1 || ch < 1 {
            continue;
        }
        let sub = pb.new_subpixbuf(x, y, cw, ch);
        let jpeg = std::fs::read(&src).map(|b| b.starts_with(&[0xFF, 0xD8])).unwrap_or(false);
        let saved = if jpeg { sub.save_to_bufferv("jpeg", &[("quality", "92")]) } else { sub.save_to_bufferv("png", &[]) };
        if let Ok(out) = saved {
            if let Ok(p) = suite_common_core::media_cache::persist(&out) {
                run.style.image = Some(p.to_string_lossy().into_owned());
            }
        }
    }
}


/// Samizdat : les formes dessinées de Word, en une image, insérée au
/// paragraphe où la première forme est ancrée (docx_shapes).
#[cfg(feature = "render")]
pub(crate) fn insert_shapes_picture(path: &str, doc: &mut Document) {
    let Ok(bytes) = std::fs::read(path) else { return };
    let mut xml = String::new();
    let Some(_) = zip::ZipArchive::new(std::io::Cursor::new(&bytes))
        .ok()
        .and_then(|mut z| std::io::Read::read_to_string(&mut z.by_name("word/document.xml").ok()?, &mut xml).ok())
    else {
        return;
    };
    if !xml.contains("<wps:wsp") {
        return;
    }
    let para_h = paragraph_height(&bytes);
    let Some((png, w_pt, h_pt, at, cut)) = crate::docx_shapes::picture(&xml, para_h) else { return };
    let Ok(p) = suite_common_core::media_cache::persist(&png) else { return };
    // Le dessin suit le paragraphe qui porte la première ancre (souvent un
    // titre posé dessus) : retrouvé par son texte, sinon par son rang.
    let host_text: String = {
        let p0 = [xml[..at].rfind("<w:p>"), xml[..at].rfind("<w:p ")].into_iter().flatten().max().unwrap_or(0);
        let p1 = xml[at..].find("</w:p>").map_or(xml.len(), |e| at + e);
        let mut t = String::new();
        let seg = &xml[p0..p1];
        // (sans le texte des zones de texte et des variantes de secours)
        let seg = strip_blocks(seg, &[("<mc:AlternateContent", "</mc:AlternateContent>")]);
        let mut i = 0;
        while let Some(k) = seg[i..].find("<w:t") {
            let s0 = i + k;
            let Some(g) = seg[s0..].find('>') else { break };
            if seg[s0 + 4..].starts_with(['>', ' ']) {
                let body = s0 + g + 1;
                let end = seg[body..].find("</w:t>").map_or(seg.len(), |e| body + e);
                t.push_str(&seg[body..end]);
                i = end;
            } else {
                i = s0 + 4;
            }
        }
        t.split_whitespace().collect::<Vec<_>>().join(" ")
    };
    let by_text = (!host_text.is_empty())
        .then(|| doc.paragraphs.iter().position(|p| p.text().split_whitespace().collect::<Vec<_>>().join(" ") == host_text))
        .flatten();
    let index = by_text.map_or_else(|| crate::docx_shapes::body_paragraphs_before(&xml, at), |i| i + 1).min(doc.paragraphs.len());
    // Pas plus large que la zone de texte de la page.
    let max_w = doc.page.as_ref().map(|g| g.width_pt - g.margin_left_pt - g.margin_right_pt).unwrap_or(w_pt);
    let mut k = (max_w / w_pt).min(1.0);
    // Une zone de texte posée sur le bas du dessin vient ici après lui :
    // le dessin s'arrête là où elle commençait dans Word.
    if let Some(cut) = cut {
        k = k.min(cut / h_pt);
    }
    let emu = |pt: f64| (pt * k * 12700.0) as u64;
    let mut para = Paragraph::default();
    para.style.alignment = crate::model::Alignment::Center;
    let mut run = Run::plain("Croquis");
    run.style.image = Some(p.to_string_lossy().into_owned());
    run.style.image_extent_emu = Some((emu(w_pt), emu(h_pt)));
    para.runs.push(run);
    doc.paragraphs.insert(index, para);
}

/// Hauteur d'un paragraphe ordinaire selon les réglages par défaut du
/// document (taille, interligne, espace après), en points.
#[cfg(feature = "render")]
pub(crate) fn paragraph_height(bytes: &[u8]) -> f64 {
    let mut st = String::new();
    let _ = zip::ZipArchive::new(std::io::Cursor::new(bytes))
        .ok()
        .and_then(|mut z| std::io::Read::read_to_string(&mut z.by_name("word/styles.xml").ok()?, &mut st).ok());
    let defaults = st.find("<w:docDefaults").map(|i| &st[i..i + st[i..].find("</w:docDefaults>").unwrap_or(0)]).unwrap_or("");
    let num = |key: &str| -> Option<f64> {
        let i = defaults.find(key)? + key.len();
        defaults[i..].split('"').next()?.parse().ok()
    };
    let size = num("<w:sz w:val=\"").unwrap_or(20.0) / 2.0;
    let line = num("w:line=\"").unwrap_or(240.0) / 240.0;
    let after = num("w:after=\"").unwrap_or(0.0) / 20.0;
    size * 1.22 * line + after
}

/// `xml` sans les blocs `open…close` (non imbriqués entre eux).
#[cfg(feature = "render")]
pub(crate) fn strip_blocks(xml: &str, blocks: &[(&str, &str)]) -> String {
    let mut out = xml.to_string();
    for (open, close) in blocks {
        while let Some(a) = out.find(open) {
            let Some(b) = out[a..].find(close) else { break };
            out.replace_range(a..a + b + close.len(), "");
        }
    }
    out
}
