// lecture.rs — partie de odt.rs, découpé par thème.
// SPDX-License-Identifier: GPL-3.0-or-later

#![allow(unused_imports)]
use super::*;
use crate::model::*;
use quick_xml::events::{BytesRef, BytesText, Event};
use quick_xml::Reader;
use std::io::Write;
use suite_common_core::zip_guard::{BoundedArchive, ZipBudget};

/// Read an .odt into the model.
pub fn read(path: &str) -> Result<Document, String> {
    read_parts(path).map(|(doc, _)| doc)
}

/// A picture frame being read: its size, its image's package member, its
/// alt text so far, whether that text is being read, and the depth of the
/// frame element (frames nest: a captioned picture is a text box frame
/// holding a picture frame).
pub(crate) struct FrameReading {
    pub(crate) extent: Option<(u64, u64)>,
    pub(crate) href: Option<String>,
    pub(crate) alt: String,
    pub(crate) in_alt: bool,
    pub(crate) depth: usize,
}

/// The document, and the package members its pictures were read from
/// (which are therefore not opaque, #1292).
pub(crate) fn read_parts(path: &str) -> Result<(Document, Vec<String>), String> {
    let file = std::fs::File::open(path).map_err(|e| e.to_string())?;
    let mut zip = zip::ZipArchive::new(file).map_err(|e| e.to_string())?;
    // An ODT arrives from a download or an attachment; its parts are read
    // under a budget so a member that claims to decompress to gigabytes is
    // refused rather than allocated (#442).
    let mut budget = ZipBudget::default();
    budget.check_entry_count(zip.len())?;
    let content = zip.part_to_string("content.xml", &mut budget).map_err(|e| {
        if e.is_missing() { "no content.xml — not an ODT?".to_string() } else { e.to_string() }
    })?;
    let styles = zip.optional_part_to_string("styles.xml", &mut budget);

    // Samizdat : les formes dessinées, retirées du fil (odt_shapes) et
    // redessinées en une image après la lecture.
    let (content, drawn) = match crate::odt_shapes::take(&content) {
        Some((patched, found)) => (patched, found),
        None => (content, Vec::new()),
    };
    let auto = parse_auto_styles(&content);
    // Samizdat : largeur des colonnes, hauteur des lignes, fond des cases.
    let tstyles = table_styles(&content);
    let mut list_styles = list_style_kinds(&styles);
    list_styles.extend(list_style_kinds(&content));

    // styles.xml's named styles, the parents of content.xml's automatic ones.
    let named = parse_auto_styles(&styles);
    // Samizdat : la numérotation des lignes est active.
    let line_numbering = styles.contains("<text:linenumbering-configuration") && !styles.contains("text:linenumbering-configuration text:number-lines=\"false\"");
    // Samizdat : l'allure de chaque cartouche lu, par tableau.
    let mut cartouches: std::collections::HashMap<u32, crate::model::Cartouche> = Default::default();
    let mut doc = Document { paragraphs: Vec::new(), footnotes: Vec::new(), header: None, footer: None, page: None, base_font: read_base_font(&styles), heading_styles: read_heading_styles(&styles), comments: Vec::new(), kept: Vec::new() };
    let mut reader = Reader::from_str(&content);
    let mut in_body = false;
    let mut para: Option<Paragraph> = None;
    // Span/link style stack: (style, depth marker)
    let mut span_stack: Vec<RunStyle> = Vec::new();
    // Body paragraphs open, each with its text base on `span_stack`.
    let mut paragraph_bases = 0usize;
    let mut link_stack: Vec<String> = Vec::new();
    let mut list_kind = ListKind::None;
    let mut list_level: u8 = 0;
    // The kind of each open text:list, so a nested list without a style of
    // its own takes its parent's, and closing it restores the parent's.
    let mut list_kinds: Vec<ListKind> = Vec::new();
    // The list style of each open text:list: a nested list naming none
    // continues its parent's, at its own level.
    let mut list_style_names: Vec<Option<String>> = Vec::new();
    // A list item's `text:start-value`, for the item's first paragraph.
    let mut pending_start: Option<u32> = None;
    // A `text:note` nests its body *inside* the referencing paragraph, so
    // its `text:p` children have to be kept out of the body stream: while
    // a note is open, text accumulates into the note instead. The citation
    // (the rendered marker) is a consumer's business and is skipped, or it
    // would arrive as a stray "1" in the footnote text.
    let mut note: Option<String> = None;
    let mut note_paras = 0usize;
    let mut in_citation = false;
    // A smart chip being read: what it is and its label so far, and the
    // element that closes it (a content control, or a standard date field
    // from another application).
    let mut chip: Option<(crate::chips::Chip, String, &'static str)> = None;
    // Tracked changes. `text:tracked-changes` comes first in `office:text`:
    // each region's change (who, when, and a deletion's text) is read into
    // `regions`; the body then marks insertions (change-start/end, whose
    // revision applies to the text between) and deletions (a change mark
    // where the deleted text goes back in).
    let mut regions: std::collections::HashMap<String, (crate::model::Revision, Vec<Run>)> = std::collections::HashMap::new();
    // The region being read: its id, its changes in order (kind, author,
    // date) and a deletion's text.
    type Entry = (crate::model::RevisionKind, String, String);
    let mut region: Option<(String, Vec<Entry>, Vec<Run>)> = None;
    let mut in_changes = false;
    let mut change_field: Option<&'static str> = None;
    let mut rev_stack: Vec<crate::model::Revision> = Vec::new();
    // Comments: each annotation is read whole into `annotation` (the
    // comment, its parent's name, the field being read, its paragraphs so
    // far); one whose range ends somewhere (`ended`) puts a start marker in
    // the text, and its end an end marker, which `docx_comments::restore`
    // turns into marks.
    let ended: std::collections::HashSet<String> = content
        .match_indices("<office:annotation-end ")
        .filter_map(|(at, _)| {
            let tag = &content[at..at + content[at..].find('>')?];
            let v = tag.find("office:name=\"")? + "office:name=\"".len();
            Some(tag[v..v + tag[v..].find('"')?].to_string())
        })
        .collect();
    let mut names: std::collections::HashMap<String, u32> = std::collections::HashMap::new();
    // Ids: ours are in our annotations' names ("__Annotation__7"), so a
    // document reopens with its own; any other annotation takes a free one.
    let own_id = |name: &str| name.strip_prefix("__Annotation__").and_then(|n| n.parse::<u32>().ok()).filter(|n| *n > 0);
    let reserved: std::collections::HashSet<u32> = content
        .match_indices("<office:annotation ")
        .filter_map(|(at, _)| {
            let tag = &content[at..at + content[at..].find('>')?];
            let v = tag.find("office:name=\"")? + "office:name=\"".len();
            own_id(&tag[v..v + tag[v..].find('"')?])
        })
        .collect();
    let mut next_free = 1u32;
    // A table of contents index: inside its body (not its title), each
    // paragraph is an entry of the level its "Contents N" style names.
    let mut in_toc = false;
    let mut in_index_title = false;
    let mut comments: Vec<(crate::model::Comment, Option<String>)> = Vec::new();
    type Reading = (crate::model::Comment, Option<String>, Option<&'static str>, usize);
    let mut annotation: Option<Reading> = None;
    let mut frame: Option<FrameReading> = None;
    let mut frame_depth = 0usize;
    // The outermost table being read (#1296): its id, the current row and
    // column (-1 before the first), its element depth, and whether the
    // current cell has had a paragraph. A table nested in a cell belongs
    // to its outer cell.
    let mut table: Option<(u32, i64, i64, usize, bool)> = None;
    let mut table_depth = 0usize;
    let mut tables_read = 0u32;
    // Samizdat : la mise en forme des cases du tableau en cours de lecture.
    let mut tcols: Vec<u32> = Vec::new();
    let mut trow: (u32, bool) = (0, false);
    let mut tprops: std::collections::HashMap<(u32, u32, u32), crate::model::TableCell> = Default::default();
    // Colonne → dernière ligne couverte par une fusion verticale.
    let mut vspan: std::collections::HashMap<(u32, u32), u32> = Default::default();
    let cell_of = |t: &Option<(u32, i64, i64, usize, bool)>| {
        t.map(|(id, r, c, _, _)| crate::model::TableCell { table: id, row: r.max(0) as u32, col: c.max(0) as u32, ..Default::default() })
    };
    let mut consumed: Vec<String> = Vec::new();

    loop {
        let event = reader.read_event();
        if let Some((c, _, field, paras)) = annotation.as_mut() {
            let field_now = *field;
            let mut text = |t: &str| match field_now {
                Some("author") => c.author.push_str(t),
                Some("date") => c.date.push_str(t),
                Some(_) => {}
                None => c.text.push_str(t),
            };
            match &event {
                Ok(Event::Start(e)) => match e.name().as_ref() {
                    "dc:creator" => *field = Some("author"),
                    "dc:date" => *field = Some("date"),
                    "meta:creator-initials" => *field = Some("initials"),
                    "text:p" | "text:h" => {
                        if *paras > 0 {
                            c.text.push('\n');
                        }
                        *paras += 1;
                    }
                    _ => {}
                },
                Ok(Event::End(e)) if e.name().as_ref() == "office:annotation" => {
                    let (mut c, parent, _, _) = annotation.take().expect("reading one");
                    c.date = crate::docx_comments::normalize_date(&c.date);
                    let spans = names.iter().any(|(n, id)| *id == c.id && ended.contains(n));
                    if let (None, true, Some(p)) = (&parent, spans, para.as_mut()) {
                        p.runs.push(Run::plain(crate::docx_comments::marker(c.id, true)));
                    }
                    comments.push((c, parent));
                }
                Ok(Event::End(e)) if matches!(e.name().as_ref(), "dc:creator" | "dc:date" | "meta:creator-initials") => *field = None,
                Ok(Event::Text(t)) => text(&unescape_text(t)),
                Ok(Event::GeneralRef(r)) => text(&resolve_general_ref(r)),
                Ok(Event::Empty(e)) if e.name().as_ref() == "text:s" => {
                    let n = attr_val(e, "text:c").and_then(|v| v.parse::<usize>().ok()).unwrap_or(1);
                    text(&" ".repeat(n));
                }
                Ok(Event::Empty(e)) if e.name().as_ref() == "text:tab" => text("\t"),
                Err(e) => return Err(format!("XML parse error: {e}")),
                _ => {}
            }
            continue;
        }
        match event {
            Ok(Event::Start(e)) if e.name().as_ref() == "office:annotation" && para.is_some() && note.is_none() => {
                let name = attr_val(&e, "office:name");
                let id = match name.as_deref().and_then(own_id) {
                    Some(n) if !comments.iter().any(|(c, _)| c.id == n) => n,
                    _ => {
                        while reserved.contains(&next_free) || comments.iter().any(|(c, _)| c.id == next_free) {
                            next_free += 1;
                        }
                        next_free
                    }
                };
                if let Some(name) = name {
                    names.insert(name, id);
                }
                let comment = crate::model::Comment {
                    id,
                    author: String::new(),
                    date: String::new(),
                    text: String::new(),
                    resolved: attr_val(&e, "loext:resolved").as_deref() == Some("true"),
                    parent: None,
                };
                annotation = Some((comment, attr_val(&e, "loext:parent-name"), None, 0));
            }
            Ok(Event::Empty(e)) if e.name().as_ref() == "office:annotation-end" => {
                let root = attr_val(&e, "office:name")
                    .and_then(|n| names.get(&n).copied())
                    .filter(|id| comments.iter().any(|(c, p)| c.id == *id && p.is_none()));
                if let (Some(id), Some(p)) = (root, para.as_mut()) {
                    p.runs.push(Run::plain(crate::docx_comments::marker(id, false)));
                }
            }
            Ok(Event::Start(e)) if in_changes || e.name().as_ref() == "text:tracked-changes" => match e.name().as_ref() {
                "text:tracked-changes" => in_changes = true,
                "text:changed-region" => {
                    let id = attr_val(&e, "text:id").or_else(|| attr_val(&e, "xml:id")).unwrap_or_default();
                    region = Some((id, Vec::new(), Vec::new()));
                }
                "text:insertion" | "text:deletion" => {
                    if let Some(r) = region.as_mut() {
                        let kind = if e.name().as_ref() == "text:insertion" { crate::model::RevisionKind::Insert } else { crate::model::RevisionKind::Delete };
                        r.1.push((kind, String::new(), String::new()));
                    }
                }
                "dc:creator" => change_field = Some("author"),
                "dc:date" => change_field = Some("date"),
                "text:p" | "text:h" => para = Some(Paragraph::default()),
                "text:span" => {
                    let st = attr_val(&e, "text:style-name").and_then(|n| auto.text.get(&n).cloned()).unwrap_or_default();
                    span_stack.push(st);
                }
                _ => {}
            },
            Ok(Event::End(e)) if in_changes => match e.name().as_ref() {
                "text:tracked-changes" => in_changes = false,
                "text:changed-region" => {
                    // A region with a deletion is that deletion; an insertion
                    // in the same region is the one it deleted (LibreOffice
                    // writes a deletion of an insertion so).
                    if let Some((id, entries, runs)) = region.take() {
                        let rev = |e: &Entry| crate::model::Revision { kind: e.0, author: e.1.clone(), date: e.2.clone(), under: None };
                        let deletion = entries.iter().find(|e| e.0 == crate::model::RevisionKind::Delete);
                        let insertion = entries.iter().find(|e| e.0 == crate::model::RevisionKind::Insert);
                        let revision = match (deletion, insertion) {
                            (Some(d), under) => crate::model::Revision { under: under.map(|i| Box::new(rev(i))), ..rev(d) },
                            (None, Some(i)) => rev(i),
                            (None, None) => continue,
                        };
                        regions.insert(id, (revision, runs));
                    }
                }
                "dc:creator" | "dc:date" => change_field = None,
                "text:p" | "text:h" => {
                    if let (Some(p), Some(r)) = (para.take(), region.as_mut()) {
                        if !r.2.is_empty() && !p.runs.is_empty() {
                            r.2.push(Run::plain(" "));
                        }
                        r.2.extend(p.runs);
                    }
                }
                "text:span" => {
                    span_stack.pop();
                }
                _ => {}
            },
            Ok(Event::Text(t)) if in_changes => {
                let txt = unescape_text(&t);
                match (change_field, region.as_mut()) {
                    (Some("author"), Some(r)) => {
                        if let Some(e) = r.1.last_mut() {
                            e.1.push_str(&txt);
                        }
                    }
                    (Some("date"), Some(r)) => {
                        if let Some(e) = r.1.last_mut() {
                            e.2.push_str(&txt);
                        }
                    }
                    _ => push_text(&mut para, &span_stack, &link_stack, &[], &txt),
                }
            }
            Ok(Event::Empty(e)) if matches!(e.name().as_ref(), "text:change-start" | "text:change-end" | "text:change") && !in_changes => {
                let id = attr_val(&e, "text:change-id").unwrap_or_default();
                let Some((rev, runs)) = regions.get(&id).cloned() else { continue };
                match e.name().as_ref() {
                    "text:change-start" => rev_stack.push(rev),
                    "text:change-end" => {
                        rev_stack.pop();
                    }
                    _ => {
                        if let Some(p) = para.as_mut() {
                            for mut r in runs {
                                r.style.revision = Some(rev.clone());
                                match p.runs.last_mut() {
                                    Some(last) if last.style == r.style => last.text.push_str(&r.text),
                                    _ => p.runs.push(r),
                                }
                            }
                        }
                    }
                }
            }
            Ok(Event::Start(e)) => match e.name().as_ref() {
                "office:text" => in_body = true,
                "table:table" if in_body && note.is_none() => {
                    table_depth += 1;
                    if table.is_none() {
                        table = Some((tables_read, -1, -1, table_depth, false));
                        tables_read += 1;
                        tcols.clear();
                    }
                }
                "table:table-row" => {
                    if let Some(t) = table.as_mut().filter(|t| t.3 == table_depth) {
                        t.1 += 1;
                        t.2 = -1;
                        trow = attr_val(&e, "table:style-name").and_then(|n| tstyles.get(&n)).map_or((0, false), |s| (s.height_tw, s.exact));
                    }
                }
                "table:table-column" => {
                    if table.is_some_and(|t| t.3 == table_depth) {
                        odt_column(&e, &tstyles, &mut tcols);
                    }
                }
                "table:table-cell" | "table:covered-table-cell" => {
                    if let Some(t) = table.as_mut().filter(|t| t.3 == table_depth) {
                        t.2 += 1;
                        t.4 = false;
                        let c = odt_cell(&e, &tstyles, &tcols, trow, *t, &mut vspan);
                        tprops.insert((c.table, c.row, c.col), c);
                        if let Some(look) = attr_val(&e, "table:style-name").as_deref().and_then(crate::model::Cartouche::parse) {
                            cartouches.insert(t.0, look);
                        }
                    }
                }
                "draw:frame" => {
                    frame_depth += 1;
                    if frame.is_none() && para.is_some() && note.is_none() {
                        let size = |a: &str| attr_val(&e, a).as_deref().and_then(length_emu);
                        frame = Some(FrameReading {
                            extent: size("svg:width").zip(size("svg:height")),
                            href: None,
                            alt: String::new(),
                            in_alt: false,
                            depth: frame_depth,
                        });
                    }
                }
                // Samizdat : un cadre de texte (une image avec sa légende,
                // dans LibreOffice) n'est pas une image ; celle qu'il contient
                // sera lue dans son propre cadre, avec ses paragraphes.
                "draw:text-box" => {
                    if frame.as_ref().is_some_and(|f| f.depth == frame_depth && f.href.is_none()) {
                        frame = None;
                    }
                }
                "svg:title" | "svg:desc" => {
                    if let Some(f) = frame.as_mut().filter(|f| f.alt.is_empty()) {
                        f.in_alt = true;
                    }
                }
                "draw:image" => {
                    // Samizdat : LibreOffice range parfois une image en deux
                    // versions (PDF ou SVG, puis PNG) ; on prend celle qui
                    // s'affiche.
                    if let Some(f) = frame.as_mut().filter(|f| f.href.as_deref().is_none_or(|h| !raster(h))) {
                        if let Some(h) = attr_val(&e, "xlink:href") {
                            if f.href.is_none() || raster(&h) {
                                f.href = Some(h);
                            }
                        }
                    }
                }
                "text:note" if para.is_some() => {
                    // The reference run is empty on purpose: it marks the
                    // position, and the text lives in `Document::footnotes`.
                    // Notes are read in document order, so the next free
                    // index is this note's.
                    if let Some(p) = para.as_mut() {
                        p.runs.push(Run {
                            text: String::new(),
                            style: RunStyle { footnote: Some(doc.footnotes.len()), ..Default::default() },
                        });
                    }
                    note = Some(String::new());
                    note_paras = 0;
                }
                "text:note-citation" => in_citation = true,
                "text:p" if note.is_some() => {
                    if note_paras > 0 {
                        if let Some(n) = note.as_mut() { n.push('\n'); }
                    }
                    note_paras += 1;
                }
                "text:p" | "text:h" if in_body => {
                    let mut style = ParaStyle::default();
                    if e.name().as_ref() == "text:h" {
                        let lvl = attr_val(&e, "text:outline-level")
                            .and_then(|v| v.parse::<u8>().ok())
                            .unwrap_or(1);
                        style.heading = Some(lvl.clamp(1, 6));
                    }
                    if let Some(name) = attr_val(&e, "text:style-name") {
                        if let Some(auto_para) = auto.para.get(&name) {
                            style.alignment = auto_para.alignment;
                            style.page_break_before = auto_para.page_break_before;
                            style.keep_with_next = auto_para.keep_with_next;
                            style.shading = auto_para.shading;
                            style.border = auto_para.border;
                            style.line_spacing = auto_para.line_spacing;
                            style.space_before_pt = auto_para.space_before_pt;
                            style.space_after_pt = auto_para.space_after_pt;
                            style.left_indent_pt = auto_para.left_indent_pt;
                            style.right_indent_pt = auto_para.right_indent_pt;
                            style.first_line_indent_pt = auto_para.first_line_indent_pt;
                            style.tab_stops_pt = auto_para.tab_stops_pt.clone();
                            style.line_numbers = line_numbering && auto_para.number_lines.unwrap_or(true);
                        }
                        // What the paragraph's own style leaves unset, its
                        // parent named style decides: Writer's "Standard" is
                        // where most documents keep their space after and
                        // line height.
                        let (before, after, line) = inherited_spacing(&name, &auto, &named);
                        if let Some(v) = before {
                            style.space_before_pt = v;
                        }
                        if let Some(v) = after {
                            style.space_after_pt = v;
                        }
                        if let Some(v) = line {
                            style.line_spacing = v;
                        }
                        // Direct built-in name, or an automatic style
                        // inheriting from one (LO's rewrite pattern).
                        let base = auto
                            .para_parent
                            .get(&name)
                            .cloned()
                            .unwrap_or_else(|| name.clone());
                        // ODF display names use _20_ for spaces.
                        let base = base.replace("_20_", " ");
                        match base.as_str() {
                            "Title" | "Subtitle" | "Caption" => style.named_style = Some(base),
                            // Writer's own quote style, and the name a docx
                            // "Quote" arrives under (#1205).
                            "Quotations" | "Quote" => style.block_quote = true,
                            "Preformatted Text" => style.code_block = Some(String::new()),
                            _ => {}
                        }
                    }
                    style.list = list_kind;
                    style.list_level = list_level.saturating_sub(1);
                    style.list_start = pending_start.take();
                    if in_toc && !in_index_title {
                        let name = attr_val(&e, "text:style-name").unwrap_or_default();
                        let base = auto.para_parent.get(&name).cloned().unwrap_or(name);
                        let level = base.rsplit(|c: char| !c.is_ascii_digit()).next().and_then(|d| d.parse::<u8>().ok()).filter(|l| (1..=10).contains(l)).unwrap_or(1);
                        style.toc = Some(level);
                        style.left_indent_pt = crate::toc::INDENT_PT * f64::from(level - 1);
                        style.tab_stops_pt.clear();
                    }
                    para = Some(Paragraph { style, runs: Vec::new() });
                    // The paragraph style's own text properties are how
                    // its text looks where no span says otherwise: a title
                    // written straight into a bold, 12pt paragraph.
                    let text_base = attr_val(&e, "text:style-name").and_then(|n| auto.para_text.get(&n).cloned()).unwrap_or_default();
                    span_stack.push(text_base);
                    paragraph_bases += 1;
                }
                "text:span" => {
                    let name = attr_val(&e, "text:style-name");
                    let own = name.as_ref().and_then(|n| auto.text.get(n).cloned()).unwrap_or_default();
                    let mut st = inherit(span_stack.last(), own);
                    // Inline code is Writer's "Source Text", named or as
                    // the parent of an automatic style (#1205).
                    if let Some(n) = &name {
                        if n == "Source_20_Text" || auto.text_parent.get(n).is_some_and(|p| p == "Source_20_Text") {
                            st.code = true;
                            st.font_family = None;
                        }
                    }
                    span_stack.push(st);
                }
                "text:a" => {
                    link_stack.push(attr_val(&e, "xlink:href").unwrap_or_default());
                }
                // A Word content control as LibreOffice writes it in ODF
                // (a .docx chip saved as .odt): ours by its tag, or any
                // date control by its date.
                "loext:content-control" if para.is_some() => {
                    let tagged = attr_val(&e, "loext:tag").as_deref().and_then(chip_from_name);
                    let dated = || {
                        let v = attr_val(&e, "loext:current-date")?.get(..10)?.to_string();
                        crate::chips::NaiveDate::parse_from_str(&v, "%Y-%m-%d").ok()?;
                        (attr_val(&e, "loext:date").as_deref() == Some("true"))
                            .then_some(crate::chips::Chip { kind: crate::chips::ChipKind::Date, value: v })
                    };
                    if let Some(c) = tagged.or_else(dated) {
                        chip = Some((c, String::new(), "loext:content-control"));
                    }
                }
                "text:date" if para.is_some() => {
                    let value = attr_val(&e, "text:date-value").and_then(|v| v.get(..10).map(str::to_string));
                    if let Some(v) = value.filter(|v| crate::chips::NaiveDate::parse_from_str(v, "%Y-%m-%d").is_ok()) {
                        chip = Some((crate::chips::Chip { kind: crate::chips::ChipKind::Date, value: v }, String::new(), "text:date"));
                    }
                }
                "text:table-of-content" => in_toc = true,
                "text:index-title" if in_toc => in_index_title = true,
                "text:list" if in_body => {
                    // Bullet vs numbered comes from the list style name we
                    // write; LO-authored lists fall back to bullet. A nested
                    // list naming no style is its parent's kind (#1205: it
                    // read as a bullet, so a numbered sub-list changed kind).
                    let name = attr_val(&e, "text:style-name").or_else(|| list_style_names.last().cloned().flatten());
                    let level = usize::from(list_level);
                    list_kind = match name.as_ref().and_then(|n| list_styles.get(n)) {
                        // The style's own definition of this level.
                        Some(kinds) => kinds.get(level).or(kinds.last()).copied().unwrap_or(ListKind::Bullet),
                        // Not defined here: our own names, else the parent's kind.
                        None => match &name {
                            Some(n) if n.contains('N') && !n.contains("LB") => ListKind::Numbered,
                            Some(_) => ListKind::Bullet,
                            None => list_kinds.last().copied().unwrap_or(ListKind::Bullet),
                        },
                    };
                    list_style_names.push(name);
                    list_kinds.push(list_kind);
                    list_level = list_level.saturating_add(1);
                }
                "text:list-item" if in_body => {
                    pending_start = attr_val(&e, "text:start-value").and_then(|v| v.parse().ok());
                }
                _ => {}
            },
            Ok(Event::Empty(e)) => match e.name().as_ref() {
                // A cell with no paragraph still holds its grid position.
                "table:table-column" => {
                    if table.is_some_and(|t| t.3 == table_depth) {
                        odt_column(&e, &tstyles, &mut tcols);
                    }
                }
                "table:table-cell" | "table:covered-table-cell" => {
                    if let Some(t) = table.as_mut().filter(|t| t.3 == table_depth) {
                        t.2 += 1;
                        let c = odt_cell(&e, &tstyles, &tcols, trow, *t, &mut vspan);
                        tprops.insert((c.table, c.row, c.col), c);
                        if let Some(look) = attr_val(&e, "table:style-name").as_deref().and_then(crate::model::Cartouche::parse) {
                            cartouches.insert(t.0, look);
                        }
                        doc.paragraphs.push(Paragraph { style: ParaStyle { table_cell: cell_of(&table), ..Default::default() }, runs: Vec::new() });
                    }
                }
                "draw:image" => {
                    // Samizdat : LibreOffice range parfois une image en deux
                    // versions (PDF ou SVG, puis PNG) ; on prend celle qui
                    // s'affiche.
                    if let Some(f) = frame.as_mut().filter(|f| f.href.as_deref().is_none_or(|h| !raster(h))) {
                        if let Some(h) = attr_val(&e, "xlink:href") {
                            if f.href.is_none() || raster(&h) {
                                f.href = Some(h);
                            }
                        }
                    }
                }
                "text:s" if chip.is_some() => {
                    let n = attr_val(&e, "text:c").and_then(|v| v.parse::<usize>().ok()).unwrap_or(1);
                    if let Some(c) = chip.as_mut() { c.1.push_str(&" ".repeat(n)); }
                }
                "text:s" if para.is_some() => {
                    let n = attr_val(&e, "text:c")
                        .and_then(|v| v.parse::<usize>().ok())
                        .unwrap_or(1);
                    push_text(&mut para, &span_stack, &link_stack, &rev_stack, &" ".repeat(n));
                }
                "text:tab" if para.is_some() => {
                    push_text(&mut para, &span_stack, &link_stack, &rev_stack, "\t");
                }
                // Samizdat : un saut de ligne dans le paragraphe.
                "text:line-break" if para.is_some() => {
                    push_text(&mut para, &span_stack, &link_stack, &rev_stack, "\u{2028}");
                }
                "text:p" if note.is_some() => {}
                "text:p" | "text:h" if in_body => {
                    let style = ParaStyle { list: list_kind, list_level: list_level.saturating_sub(1), list_start: pending_start.take(), table_cell: cell_of(&table), ..Default::default() };
                    if let Some(t) = table.as_mut() {
                        t.4 = true;
                    }
                    doc.paragraphs.push(Paragraph { style, runs: Vec::new() });
                }
                _ => {}
            },
            Ok(Event::Text(t)) if frame.as_ref().is_some_and(|f| f.in_alt) => {
                if let Some(f) = frame.as_mut() {
                    f.alt.push_str(&unescape_text(&t));
                }
            }
            Ok(Event::Text(t)) => {
                if let Some(n) = note.as_mut() {
                    if !in_citation {
                        n.push_str(&unescape_text(&t));
                    }
                } else if let Some(c) = chip.as_mut() {
                    c.1.push_str(&unescape_text(&t));
                } else if para.is_some() {
                    let txt = unescape_text(&t);
                    push_text(&mut para, &span_stack, &link_stack, &rev_stack, &txt);
                }
            }
            Ok(Event::GeneralRef(r)) => {
                if let Some(c) = chip.as_mut() {
                    c.1.push_str(&resolve_general_ref(&r));
                } else if para.is_some() {
                    let txt = resolve_general_ref(&r);
                    push_text(&mut para, &span_stack, &link_stack, &rev_stack, &txt);
                }
            }
            Ok(Event::End(e)) if chip.as_ref().is_some_and(|c| c.2 == e.name().as_ref()) => {
                if let (Some((c, label, _)), Some(p)) = (chip.take(), para.as_mut()) {
                    p.runs.push(crate::chips::chip_run(c, label));
                }
            }
            Ok(Event::End(e)) => match e.name().as_ref() {
                "svg:title" | "svg:desc" => {
                    if let Some(f) = frame.as_mut() {
                        f.in_alt = false;
                    }
                }
                "draw:frame" => {
                    if frame.as_ref().is_some_and(|f| f.depth == frame_depth) {
                        let f = frame.take().expect("the frame just checked");
                        // A picture whose bytes are in the package: kept in
                        // the media cache, like a docx's (#455), so the
                        // model's path stays readable.
                        let href = f.href.filter(|h| !h.contains("://"));
                        let path = href.as_deref().and_then(|h| {
                            let bytes = zip.part_to_bytes(h.trim_start_matches("./"), &mut budget).ok()?;
                            suite_common_core::media_cache::persist(&bytes).ok()
                        });
                        if let (Some(path), Some(p)) = (path, para.as_mut()) {
                            consumed.push(href.expect("read from it").trim_start_matches("./").to_string());
                            p.runs.push(Run {
                                text: f.alt.trim().to_string(),
                                style: RunStyle {
                                    image: Some(path.to_string_lossy().into_owned()),
                                    image_extent_emu: f.extent,
                                    ..Default::default()
                                },
                            });
                        }
                    }
                    frame_depth = frame_depth.saturating_sub(1);
                }
                "text:note-citation" => in_citation = false,
                "text:note" => {
                    if let Some(text) = note.take() {
                        doc.footnotes.push(text);
                    }
                    note_paras = 0;
                }
                // A note's own paragraphs must not close the paragraph that
                // carries the reference.
                "text:p" if note.is_some() => {}
                "text:p" | "text:h" => {
                    if paragraph_bases > 0 {
                        paragraph_bases -= 1;
                        span_stack.pop();
                    }
                    if let Some(mut p) = para.take() {
                        // An entry's link goes to its heading, not a page.
                        if p.style.toc.is_some() {
                            for r in &mut p.runs {
                                if r.style.link.as_deref().is_some_and(|l| l.starts_with('#')) {
                                    r.style.link = None;
                                }
                            }
                            let mut runs: Vec<Run> = Vec::new();
                            for r in p.runs.drain(..) {
                                match runs.last_mut() {
                                    Some(l) if l.style == r.style && r.style.chip.is_none() && l.style.chip.is_none() => l.text.push_str(&r.text),
                                    _ => runs.push(r),
                                }
                            }
                            p.runs = runs;
                        }
                        if let Some(t) = table.as_mut() {
                            p.style.table_cell = cell_of(&Some(*t));
                            t.4 = true;
                        }
                        doc.paragraphs.push(p);
                    }
                }
                "table:table-cell" => {
                    if let Some(t) = table.filter(|t| t.3 == table_depth && !t.4) {
                        doc.paragraphs.push(Paragraph { style: ParaStyle { table_cell: cell_of(&Some(t)), ..Default::default() }, runs: Vec::new() });
                    }
                }
                "table:table" if table_depth > 0 => {
                    if table.is_some_and(|t| t.3 == table_depth) {
                        table = None;
                    }
                    table_depth -= 1;
                }
                "text:table-of-content" => in_toc = false,
                "text:index-title" => in_index_title = false,
                "text:span" => {
                    span_stack.pop();
                }
                "text:a" => {
                    link_stack.pop();
                }
                "text:list" => {
                    list_level = list_level.saturating_sub(1);
                    list_kinds.pop();
                    list_style_names.pop();
                    list_kind = if list_level == 0 { ListKind::None } else { list_kinds.last().copied().unwrap_or(ListKind::Bullet) };
                },
                "office:text" => in_body = false,
                _ => {}
            },
            Ok(Event::Eof) => break,
            Err(e) => return Err(format!("XML parse error: {e}")),
            _ => {}
        }
    }
    if !comments.is_empty() {
        // A reply names its parent; a reply to a reply is in the thread.
        let parents: Vec<Option<u32>> = comments.iter().map(|(_, p)| p.as_ref().and_then(|n| names.get(n).copied())).collect();
        let root = |mut id: u32| {
            for _ in 0..parents.len() {
                match comments.iter().position(|(c, _)| c.id == id).and_then(|i| parents[i]) {
                    Some(p) if p != id => id = p,
                    _ => break,
                }
            }
            id
        };
        let bodies: Vec<crate::model::Comment> = comments
            .iter()
            .zip(&parents)
            .map(|((c, _), p)| crate::model::Comment { parent: p.map(root).filter(|r| *r != c.id), ..c.clone() })
            .collect();
        let mut bodies = bodies;
        bodies.sort_by_key(|c| c.id);
        crate::docx_comments::restore(&mut doc, bodies);
    }

    // Header/footer and page geometry from styles.xml.
    if !styles.is_empty() {
        let mut reader = Reader::from_str(&styles);
        let mut in_header = false;
        let mut hf_paras = 0usize;
        let mut in_footer = false;
        // Inside a page number or count field: its shown value is skipped.
        let mut in_field = false;
        // Returns the geometry instead of writing to `doc` so the borrow ends
        // with the call; `style:columns` needs `doc.page` mutably right after.
        let read_page_layout = |e: &quick_xml::events::BytesStart| -> Option<PageGeometry> {
            let width_pt = attr_val(e, "fo:page-width").and_then(|v| parse_length_pt(&v))?;
            let height_pt = attr_val(e, "fo:page-height").and_then(|v| parse_length_pt(&v))?;
            let d = PageGeometry::default();
            let m = |name: &str, fallback: f64| {
                attr_val(e, name).and_then(|v| parse_length_pt(&v)).unwrap_or(fallback)
            };
            Some(PageGeometry {
                width_pt,
                height_pt,
                margin_top_pt: m("fo:margin-top", d.margin_top_pt),
                margin_bottom_pt: m("fo:margin-bottom", d.margin_bottom_pt),
                margin_left_pt: m("fo:margin-left", d.margin_left_pt),
                margin_right_pt: m("fo:margin-right", d.margin_right_pt),
                columns: d.columns,
                column_gap_pt: d.column_gap_pt,
            })
        };
        loop {
            match reader.read_event() {
                Ok(Event::Empty(e)) if e.name().as_ref() == "style:page-layout-properties" => {
                    if let Some(page) = read_page_layout(&e) {
                        doc.page = Some(page);
                    }
                }
                Ok(Event::Empty(e)) if e.name().as_ref() == "style:columns" => {
                    if let Some(page) = doc.page.as_mut() {
                        page.columns = attr_val(&e, "fo:column-count")
                            .and_then(|v| v.parse::<u8>().ok()).unwrap_or(1).max(1);
                        page.column_gap_pt = attr_val(&e, "fo:column-gap")
                            .and_then(|v| parse_length_pt(&v)).unwrap_or(page.column_gap_pt);
                    }
                }
                Ok(Event::Empty(e)) if (in_header || in_footer) && matches!(e.name().as_ref(), "text:tab" | "text:p") => {
                    let target = if in_header { &mut doc.header } else { &mut doc.footer };
                    if e.name().as_ref() == "text:tab" {
                        target.get_or_insert_with(String::new).push('\t');
                    } else {
                        if hf_paras > 0 {
                            target.get_or_insert_with(String::new).push('\n');
                        }
                        hf_paras += 1;
                    }
                }
                Ok(Event::Start(e)) => match e.name().as_ref() {
                    "style:header" => {
                        in_header = true;
                        hf_paras = 0;
                    }
                    "style:footer" => {
                        in_footer = true;
                        hf_paras = 0;
                    }
                    "text:p" if in_header || in_footer => {
                        if hf_paras > 0 {
                            let target = if in_header { &mut doc.header } else { &mut doc.footer };
                            target.get_or_insert_with(String::new).push('\n');
                        }
                        hf_paras += 1;
                    }
                    "text:page-number" | "text:page-count" if in_header || in_footer => {
                        let placeholder = if e.name().as_ref() == "text:page-number" { "{page}" } else { "{total}" };
                        let target = if in_header { &mut doc.header } else { &mut doc.footer };
                        target.get_or_insert_with(String::new).push_str(placeholder);
                        in_field = true;
                    }
                    "style:page-layout-properties" => {
                        if let Some(page) = read_page_layout(&e) {
                            doc.page = Some(page);
                        }
                    }
                    _ => {}
                },
                Ok(Event::End(e)) => match e.name().as_ref() {
                    "style:header" => in_header = false,
                    "style:footer" => in_footer = false,
                    "text:page-number" | "text:page-count" => in_field = false,
                    _ => {}
                },
                Ok(Event::Text(_)) if in_field => {}
                Ok(Event::Text(t)) => {
                    let txt = unescape_text(&t);
                    if in_header && !txt.trim().is_empty() {
                        doc.header.get_or_insert_with(String::new).push_str(&txt);
                    }
                    if in_footer && !txt.trim().is_empty() {
                        doc.footer.get_or_insert_with(String::new).push_str(&txt);
                    }
                }
                Ok(Event::GeneralRef(r)) => {
                    let txt = resolve_general_ref(&r);
                    if in_header {
                        doc.header.get_or_insert_with(String::new).push_str(&txt);
                    }
                    if in_footer {
                        doc.footer.get_or_insert_with(String::new).push_str(&txt);
                    }
                }
                Ok(Event::Eof) => break,
                Err(_) => break,
                _ => {}
            }
        }
    }

    doc.ensure_non_empty();
    for p in &mut doc.paragraphs {
        if let Some(c) = p.style.table_cell {
            p.style.cartouche = cartouches.get(&c.table).copied();
            if let Some(props) = tprops.get(&(c.table, c.row, c.col)) {
                p.style.table_cell = Some(props.placed(c));
            }
        }
    }
    #[cfg(feature = "render")]
    if let Some((png, w_pt, h_pt, index)) = crate::odt_shapes::picture(&content, &drawn) {
        if let Ok(p) = suite_common_core::media_cache::persist(&png) {
            let max_w = doc.page.as_ref().map(|g| g.width_pt - g.margin_left_pt - g.margin_right_pt).unwrap_or(w_pt);
            let k = (max_w / w_pt).min(1.0);
            let emu = |pt: f64| (pt * k * 12700.0) as u64;
            let mut para = Paragraph::default();
            para.style.alignment = Alignment::Center;
            let mut run = Run::plain("Croquis");
            run.style.image = Some(p.to_string_lossy().into_owned());
            run.style.image_extent_emu = Some((emu(w_pt), emu(h_pt)));
            para.runs.push(run);
            doc.paragraphs.insert(index.min(doc.paragraphs.len()), para);
        }
    }
    #[cfg(not(feature = "render"))]
    let _ = &drawn;
    // A column count LibreOffice recorded on a section instead of on the
    // page layout. Only consulted when the page layout said nothing, so
    // an explicit page-wide count still wins.
    if let Some((count, gap)) = parse_section_columns(&content) {
        let page = doc.page.get_or_insert_with(PageGeometry::default);
        if page.columns <= 1 {
            page.columns = count;
            if let Some(gap) = gap {
                page.column_gap_pt = gap;
            }
        }
    }

    Ok((doc, consumed))
}

/// A span's text style over the text style around it: what the span
/// does not set, it takes from its paragraph (or outer span).
pub(crate) fn inherit(outer: Option<&RunStyle>, own: RunStyle) -> RunStyle {
    let Some(outer) = outer else { return own };
    RunStyle {
        bold: own.bold || outer.bold,
        italic: own.italic || outer.italic,
        underline: own.underline || outer.underline,
        strikethrough: own.strikethrough || outer.strikethrough,
        highlight: own.highlight || outer.highlight,
        highlight_color: if own.highlight { own.highlight_color.clone() } else { outer.highlight_color.clone() },
        font_family: own.font_family.or_else(|| outer.font_family.clone()),
        font_size_hp: own.font_size_hp.or(outer.font_size_hp),
        color: own.color.or_else(|| outer.color.clone()),
        vert_align: own.vert_align.or(outer.vert_align),
        ..own
    }
}

pub(crate) fn push_text(
    para: &mut Option<Paragraph>,
    span_stack: &[RunStyle],
    link_stack: &[String],
    rev_stack: &[crate::model::Revision],
    text: &str,
) {
    if text.is_empty() {
        return;
    }
    if let Some(p) = para.as_mut() {
        let mut style = span_stack.last().cloned().unwrap_or_default();
        style.revision = rev_stack.last().cloned();
        if let Some(href) = link_stack.last() {
            if !href.is_empty() {
                style.link = Some(href.clone());
            }
        }
        // Merge with the previous run when styles match (normalizes the
        // reader output so round-trip comparisons are stable).
        if let Some(last) = p.runs.last_mut() {
            if last.style == style {
                last.text.push_str(text);
                return;
            }
        }
        p.runs.push(Run { text: text.to_string(), style });
    }
}

/// Une image que l'on sait afficher (pas un PDF ni un SVG).
pub(crate) fn raster(href: &str) -> bool {
    let h = href.to_ascii_lowercase();
    [".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".webp"].iter().any(|x| h.ends_with(x))
}
