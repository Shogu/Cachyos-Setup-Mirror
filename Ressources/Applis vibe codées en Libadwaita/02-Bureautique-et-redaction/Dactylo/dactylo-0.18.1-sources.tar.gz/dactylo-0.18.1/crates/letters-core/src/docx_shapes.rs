// docx_shapes.rs — les formes dessinées de Word (rectangles, ellipses…),
// comme celles d'un croquis de géographie.
//
// Dactylo n'a pas de calque de dessin : ces formes flottantes disparaissaient.
// On les redessine toutes ensemble en une image, à partir de leur variante
// VML (<mc:Fallback>), qui donne directement les positions en points et les
// couleurs résolues ; l'image est placée là où la première forme est ancrée.
// Les zones de texte posées par-dessus deviennent, elles, des cartouches ou
// des tableaux (docx_alt) : elles suivent l'image au lieu de la recouvrir.
// SPDX-License-Identifier: GPL-3.0-or-later

/// Une forme simple, en points (partagée avec la lecture des ODT).
#[derive(Debug, Clone)]
pub(crate) struct Shape {
    pub kind: u8, // 0 rectangle, 1 ellipse, 2 rectangle arrondi
    pub x: f64,
    pub y: f64,
    pub w: f64,
    pub h: f64,
    pub z: i64,
    pub fill: Option<(f64, f64, f64)>,
    pub stroke: Option<(f64, f64, f64)>,
    pub stroke_w: f64,
}

fn attr<'a>(tag: &'a str, name: &str) -> Option<&'a str> {
    let pat = format!(" {name}=\"");
    let i = tag.find(&pat)? + pat.len();
    tag[i..].split('"').next()
}

fn style_pt(style: &str, key: &str) -> Option<f64> {
    style.split(';').find_map(|kv| {
        let (k, v) = kv.split_once(':')?;
        (k.trim() == key).then(|| v.trim().trim_end_matches("pt").parse().ok()).flatten()
    })
}

fn color(v: &str) -> Option<(f64, f64, f64)> {
    let h = v.trim().trim_start_matches('#');
    let h = h.split_whitespace().next()?;
    if h.len() != 6 {
        return None;
    }
    let c = |i: usize| u8::from_str_radix(&h[i..i + 2], 16).ok().map(|b| b as f64 / 255.0);
    Some((c(0)?, c(2)?, c(4)?))
}

/// Nombre de paragraphes du corps avant `at` (sans ceux des zones de texte
/// ni des variantes de secours).
pub fn body_paragraphs_before(xml: &str, at: usize) -> usize {
    let before = &xml[..at];
    let count = |s: &str| s.matches("<w:p>").count() + s.matches("<w:p ").count();
    // On saute les dessins (formes, zones de texte) : leurs paragraphes ne
    // sont pas ceux du corps. Les blocs peuvent s'imbriquer.
    let (mut n, mut i, mut depth, mut from) = (0, 0, 0usize, 0);
    loop {
        let o = before[i..].find("<mc:AlternateContent").map(|k| i + k);
        let c = before[i..].find("</mc:AlternateContent>").map(|k| i + k);
        match (o, c) {
            (Some(o), Some(c)) if o < c => {
                if depth == 0 {
                    n += count(&before[from..o]);
                }
                depth += 1;
                i = o + 1;
            }
            (_, Some(c)) => {
                depth = depth.saturating_sub(1);
                i = c + 1;
                if depth == 0 {
                    from = c;
                }
            }
            (Some(o), None) => {
                if depth == 0 {
                    n += count(&before[from..o]);
                }
                return n;
            }
            (None, None) => {
                if depth == 0 {
                    n += count(&before[from..]);
                }
                return n;
            }
        }
    }
}

/// Les formes sans texte, dans l'ordre du document, et la position (octet)
/// de la première ancre. `para_h` : hauteur estimée d'un paragraphe vide,
/// pour placer les formes ancrées à des paragraphes différents.
fn shapes(xml: &str, para_h: f64) -> (Vec<Shape>, Option<usize>, Vec<f64>) {
    // (zones de texte : leur haut, moins les paragraphes du corps que le
    // dessin recouvrait dans Word et qui ici le suivent.)
    let mut first_para = None;
    // Le haut des zones de texte, dans le même repère que les formes.
    let mut boxes = Vec::new();
    let mut out = Vec::new();
    let mut first = None;
    let mut at = 0;
    while let Some(i) = xml[at..].find("<mc:AlternateContent") {
        let start = at + i;
        let Some(j) = xml[start..].find("</mc:AlternateContent>") else { break };
        let end = start + j;
        let block = &xml[start..end];
        at = end;
        // Une image : traitée ailleurs.
        if !block.contains("<wps:wsp") || block.contains("<pic:pic") {
            continue;
        }
        let text_box = block.contains("<w:txbxContent");
        // Dans une zone de texte : on laisse.
        if xml[..start].rfind("<w:txbxContent").map_or(false, |o| xml[o..start].find("</w:txbxContent>").is_none()) {
            continue;
        }
        let Some(fb) = block.find("<mc:Fallback>") else { continue };
        let fb = &block[fb..];
        let Some(vs) = fb.find("<v:") else { continue };
        let tag = &fb[vs..vs + fb[vs..].find('>').unwrap_or(0)];
        let style = attr(tag, "style").unwrap_or("");
        let (Some(x), Some(mut y), Some(w), Some(h)) =
            (style_pt(style, "margin-left"), style_pt(style, "margin-top"), style_pt(style, "width"), style_pt(style, "height"))
        else {
            continue;
        };
        let host = body_paragraphs_before(xml, start);
        let base = *first_para.get_or_insert(host);
        if block.contains("<wp:positionV relativeFrom=\"paragraph\"") {
            y += (host.saturating_sub(base)) as f64 * para_h;
        }
        // Une zone de texte (elle devient un cartouche ou un tableau) ;
        // dans Word, les paragraphes jusqu'au sien passent sous le dessin.
        if text_box {
            boxes.push(y - (host.saturating_sub(base) + 1) as f64 * para_h);
            continue;
        }
        // Ordre de Word : formes « derrière le texte » d'abord, puis la
        // hauteur relative de l'ancre (la z-index VML est souvent fausse).
        let anchor = block.find("<wp:anchor").map(|i| &block[i..i + block[i..].find('>').unwrap_or(0)]);
        let rel = anchor.and_then(|t| attr(t, "relativeHeight")).and_then(|v| v.parse::<i64>().ok());
        let behind = anchor.and_then(|t| attr(t, "behindDoc")).map_or(false, |v| v == "1");
        let vml_z = style.split(';').find_map(|kv| kv.split_once(':').filter(|(k, _)| k.trim() == "z-index").and_then(|(_, v)| v.trim().parse().ok())).unwrap_or(0);
        let z = match rel {
            Some(r) => if behind { r } else { r + (1 << 40) },
            None => vml_z,
        };
        let kind = if tag.starts_with("<v:oval") || attr(tag, "o:spt") == Some("3") {
            1
        } else if tag.starts_with("<v:roundrect") || attr(tag, "o:spt") == Some("2") {
            2
        } else {
            0
        };
        let filled = attr(tag, "filled").map_or(true, |f| !matches!(f, "f" | "false"));
        let stroked = attr(tag, "stroked").map_or(true, |f| !matches!(f, "f" | "false"));
        let fill = if filled { attr(tag, "fillcolor").and_then(color).or(Some((1.0, 1.0, 1.0))) } else { None };
        let stroke = if stroked { attr(tag, "strokecolor").and_then(color).or(Some((0.0, 0.0, 0.0))) } else { None };
        let stroke_w = attr(tag, "strokeweight").and_then(|v| v.trim_end_matches("pt").parse().ok()).unwrap_or(0.75);
        first.get_or_insert(start);
        out.push(Shape { kind, x, y, w, h, z, fill, stroke, stroke_w });
    }
    (out, first, boxes)
}

/// Les formes redessinées en une image PNG : (octets, largeur et hauteur en
/// points, position de la première ancre dans le XML).
///
/// Aussi : la hauteur (points, depuis le haut du dessin) où commence une
/// zone de texte posée sur le dessin. Dactylo place cette zone après le
/// dessin ; réduire le dessin à cette hauteur garde la page de Word.
pub fn picture(xml: &str, para_h: f64) -> Option<(Vec<u8>, f64, f64, usize, Option<f64>)> {
    let (list, first, boxes) = shapes(xml, para_h);
    let (png, w, h, y0) = draw(list)?;
    let y1 = y0 + h;
    let cut = boxes.iter().copied().filter(|&t| t > y0 + h * 0.3 && t < y1).fold(None, |m: Option<f64>, t| Some(m.map_or(t, |m| m.min(t)))).map(|t| t - y0);
    Some((png, w, h, first?, cut))
}

/// Les formes dessinées en une image PNG : (octets, largeur, hauteur, haut
/// du dessin), en points.
pub(crate) fn draw(mut list: Vec<Shape>) -> Option<(Vec<u8>, f64, f64, f64)> {
    if list.is_empty() {
        return None;
    }
    list.sort_by_key(|s| s.z);
    let pad = list.iter().map(|s| s.stroke_w).fold(1.0, f64::max);
    let x0 = list.iter().map(|s| s.x).fold(f64::MAX, f64::min) - pad;
    let y0 = list.iter().map(|s| s.y).fold(f64::MAX, f64::min) - pad;
    let x1 = list.iter().map(|s| s.x + s.w).fold(f64::MIN, f64::max) + pad;
    let y1 = list.iter().map(|s| s.y + s.h).fold(f64::MIN, f64::max) + pad;
    let (w, h) = (x1 - x0, y1 - y0);
    if !(w > 1.0 && h > 1.0 && w < 5000.0 && h < 5000.0) {
        return None;
    }
    let scale = 3.0; // net à l'impression
    let surface = cairo::ImageSurface::create(cairo::Format::ARgb32, (w * scale) as i32, (h * scale) as i32).ok()?;
    {
        let cr = cairo::Context::new(&surface).ok()?;
        cr.scale(scale, scale);
        cr.translate(-x0, -y0);
        for s in &list {
            cr.new_path();
            match s.kind {
                1 => {
                    cr.save().ok()?;
                    cr.translate(s.x + s.w / 2.0, s.y + s.h / 2.0);
                    cr.scale(s.w / 2.0, s.h / 2.0);
                    cr.arc(0.0, 0.0, 1.0, 0.0, std::f64::consts::TAU);
                    cr.restore().ok()?;
                }
                2 => {
                    let r = s.w.min(s.h) * 0.1;
                    cr.new_sub_path();
                    cr.arc(s.x + s.w - r, s.y + r, r, -std::f64::consts::FRAC_PI_2, 0.0);
                    cr.arc(s.x + s.w - r, s.y + s.h - r, r, 0.0, std::f64::consts::FRAC_PI_2);
                    cr.arc(s.x + r, s.y + s.h - r, r, std::f64::consts::FRAC_PI_2, std::f64::consts::PI);
                    cr.arc(s.x + r, s.y + r, r, std::f64::consts::PI, 1.5 * std::f64::consts::PI);
                    cr.close_path();
                }
                _ => cr.rectangle(s.x, s.y, s.w, s.h),
            }
            if let Some((r, g, b)) = s.fill {
                cr.set_source_rgb(r, g, b);
                cr.fill_preserve().ok()?;
            }
            if let Some((r, g, b)) = s.stroke {
                cr.set_source_rgb(r, g, b);
                cr.set_line_width(s.stroke_w);
                cr.stroke().ok()?;
            }
            cr.new_path();
        }
    }
    let mut png = Vec::new();
    surface.write_to_png(&mut png).ok()?;
    Some((png, w, h, y0))
}

#[cfg(test)]
mod tests {
    #[test]
    fn vml_fallback_shapes_are_drawn() {
        let xml = r##"<w:p><w:r><mc:AlternateContent><mc:Choice Requires="wps"><w:drawing><wps:wsp/></w:drawing></mc:Choice><mc:Fallback><w:pict><v:shape o:spt="3" style="position:absolute;z-index:-2;margin-left:10pt;margin-top:5pt;width:100pt;height:50pt;" fillcolor="#FEF0CC" strokecolor="#2D4D6A" strokeweight="1.00pt"></v:shape></w:pict></mc:Fallback></mc:AlternateContent></w:r></w:p>"##;
        let (png, w, h, at, _) = super::picture(xml, 20.0).unwrap();
        assert!(png.starts_with(&[0x89, b'P', b'N', b'G']));
        assert!((w - 102.0).abs() < 0.01 && (h - 52.0).abs() < 0.01, "{w} {h}");
        assert_eq!(at, xml.find("<mc:AlternateContent").unwrap());
    }
}
