// styles.rs — partie de odt.rs, découpé par thème.
// SPDX-License-Identifier: GPL-3.0-or-later

#![allow(unused_imports)]
use super::*;
use crate::model::*;
use quick_xml::events::{BytesRef, BytesText, Event};
use quick_xml::Reader;
use std::io::Write;
use suite_common_core::zip_guard::{BoundedArchive, ZipBudget};

/// Parse the style:text-properties / paragraph-properties of automatic
/// styles into model styles keyed by style name.
pub(crate) struct AutoStyles {
    pub(crate) text: std::collections::HashMap<String, RunStyle>,
    pub(crate) para: std::collections::HashMap<String, AutoParaStyle>,
    /// Automatic paragraph style → its style:parent-style-name (LO
    /// rewrites named styles as autos inheriting from the built-in).
    pub(crate) para_parent: std::collections::HashMap<String, String>,
    /// Automatic text style → its parent, as for paragraphs.
    pub(crate) text_parent: std::collections::HashMap<String, String>,
    /// A paragraph style's own text properties: in styles.xml, how each
    /// `Heading_20_N` looks (#1297).
    pub(crate) para_text: std::collections::HashMap<String, RunStyle>,
}

/// Paragraph-level values read off one automatic style. Lengths are points.
#[derive(Clone, Debug, Default)]
pub(crate) struct AutoParaStyle {
    /// Samizdat : fond et bordure du paragraphe.
    pub(crate) shading: Option<[u8; 3]>,
    pub(crate) border: Option<crate::model::ParaBorder>,
    pub(crate) alignment: Alignment,
    pub(crate) page_break_before: bool,
    pub(crate) keep_with_next: bool,
    pub(crate) line_spacing: f32,
    pub(crate) space_before_pt: f64,
    pub(crate) space_after_pt: f64,
    pub(crate) left_indent_pt: f64,
    pub(crate) right_indent_pt: f64,
    pub(crate) first_line_indent_pt: f64,
    /// Positions of `style:tab-stops` children, in document order.
    pub(crate) tab_stops_pt: Vec<f64>,
    /// Whether the style itself sets its space before, space after and
    /// line height; what it leaves unset comes from its parent style.
    pub(crate) sets: [bool; 3],
    /// Samizdat : `text:number-lines`, s'il le dit.
    pub(crate) number_lines: Option<bool>,
}

/// Each `text:list-style` in `xml`: whether each of its levels is numbered,
/// by level (1-based in the file, 0-based here). LibreOffice names the list
/// styles it writes "WWNum1", "L2"…, so the kind can't be read off the name.
pub(crate) fn list_style_kinds(xml: &str) -> std::collections::HashMap<String, Vec<ListKind>> {
    let mut out: std::collections::HashMap<String, Vec<ListKind>> = Default::default();
    let mut reader = Reader::from_str(xml);
    let mut current: Option<String> = None;
    loop {
        match reader.read_event() {
            Ok(Event::Start(e)) | Ok(Event::Empty(e)) => match e.name().as_ref() {
                "text:list-style" => current = attr_val(&e, "style:name"),
                name @ ("text:list-level-style-number" | "text:list-level-style-bullet" | "text:list-level-style-image") => {
                    let (Some(style), Some(level)) = (current.as_ref(), attr_val(&e, "text:level").and_then(|l| l.parse::<usize>().ok())) else { continue };
                    let kinds = out.entry(style.clone()).or_default();
                    if (1..=10).contains(&level) {
                        if kinds.len() < level {
                            kinds.resize(level, ListKind::Bullet);
                        }
                        let numbered = name == "text:list-level-style-number"
                            && attr_val(&e, "style:num-format").is_some_and(|f| !f.is_empty());
                        kinds[level - 1] = if numbered { ListKind::Numbered } else { ListKind::Bullet };
                    }
                }
                _ => {}
            },
            Ok(Event::End(e)) if e.name().as_ref() == "text:list-style" => current = None,
            Ok(Event::Eof) | Err(_) => break,
            _ => {}
        }
    }
    out
}

pub(crate) fn parse_auto_styles(xml: &str) -> AutoStyles {
    let mut out = AutoStyles { text: Default::default(), para: Default::default(), para_parent: Default::default(), text_parent: Default::default(), para_text: Default::default() };
    // Samizdat : les polices sont nommées par leur déclaration
    // (« Arial1 ») ; la famille réelle est dans style:font-face.
    let faces: std::collections::HashMap<String, String> = {
        let mut m = std::collections::HashMap::new();
        let mut r = Reader::from_str(xml);
        loop {
            match r.read_event() {
                Ok(Event::Start(e)) | Ok(Event::Empty(e)) if e.name().as_ref() == "style:font-face" => {
                    if let (Some(n), Some(f)) = (attr_val(&e, "style:name"), attr_val(&e, "svg:font-family")) {
                        m.insert(n, f.trim_matches('\'').trim_matches('"').to_string());
                    }
                }
                Ok(Event::Eof) | Err(_) => break,
                _ => {}
            }
        }
        m
    };
    let mut reader = Reader::from_str(xml);
    let mut cur_name: Option<String> = None;
    let mut cur_family = String::new();
    loop {
        match reader.read_event() {
            Ok(Event::Start(e)) | Ok(Event::Empty(e)) => {
                match e.name().as_ref() {
                    "style:style" => {
                        cur_name = attr_val(&e, "style:name");
                        cur_family = attr_val(&e, "style:family").unwrap_or_default();
                        if let (Some(n), Some(parent)) = (cur_name.clone(), attr_val(&e, "style:parent-style-name")) {
                            match cur_family.as_str() {
                                "paragraph" => { out.para_parent.insert(n, parent); }
                                "text" => { out.text_parent.insert(n, parent); }
                                _ => {}
                            }
                        }
                    }
                    "style:text-properties" => {
                        if let Some(name) = cur_name.clone().filter(|_| cur_family == "text" || cur_family == "paragraph") {
                            let mut st = RunStyle::default();
                            if attr_val(&e, "fo:font-weight").as_deref() == Some("bold") {
                                st.bold = true;
                            }
                            if attr_val(&e, "fo:font-style").as_deref() == Some("italic") {
                                st.italic = true;
                            }
                            if attr_val(&e, "style:text-underline-style")
                                .map(|v| v != "none")
                                .unwrap_or(false)
                            {
                                st.underline = true;
                            }
                            if attr_val(&e, "style:text-line-through-style")
                                .map(|v| v != "none")
                                .unwrap_or(false)
                            {
                                st.strikethrough = true;
                            }
                            if let Some(bg) = attr_val(&e, "fo:background-color") {
                                let hex = bg.trim_start_matches('#').to_uppercase();
                                if hex.len() == 6 && hex.chars().all(|c| c.is_ascii_hexdigit()) && hex != "FFFFFF" {
                                    st.highlight = true;
                                    if hex != "FFFF00" {
                                        st.highlight_color = Some(hex);
                                    }
                                }
                            }
                            if let Some(sz) = attr_val(&e, "fo:font-size") {
                                if let Ok(pt) = sz.trim_end_matches("pt").parse::<f32>() {
                                    st.font_size_hp = Some((pt * 2.0).round() as u16);
                                }
                            }
                            if let Some(c) = attr_val(&e, "fo:color") {
                                st.color = Some(c.trim_start_matches('#').to_lowercase());
                            }
                            if let Some(fam) = attr_val(&e, "fo:font-family") {
                                let f = fam.to_lowercase();
                                if f.contains("mono") || f.contains("courier") {
                                    st.code = true;
                                } else {
                                    st.font_family =
                                        Some(fam.trim_matches('\'').to_string());
                                }
                            }
                            if let Some(fname) = attr_val(&e, "style:font-name") {
                                // Exactly what our writer emits for code
                                // spans; LO preserves or maps it to a
                                // mono face.
                                let f = fname.to_lowercase();
                                if f.contains("monospace")
                                    || f.contains("courier")
                                    || f.contains("liberation mono")
                                {
                                    st.code = true;
                                    st.font_family = None;
                                }
                            }
                            if let Some(tp) = attr_val(&e, "style:text-position") {
                                if tp.starts_with("super") {
                                    st.vert_align = Some(VertAlign::Superscript);
                                } else if tp.starts_with("sub") {
                                    st.vert_align = Some(VertAlign::Subscript);
                                }
                            }
                            // Writer names a face by its font declaration
                            // (paragraph and text styles alike).
                            if let Some(fname) = attr_val(&e, "style:font-name").filter(|_| !st.code && st.font_family.is_none()) {
                                st.font_family = Some(faces.get(&fname).cloned().unwrap_or(fname));
                            }
                            if cur_family == "paragraph" {
                                out.para_text.insert(name, st);
                            } else {
                                out.text.insert(name, st);
                            }
                        }
                    }
                    "style:paragraph-properties" => {
                        if let (Some(name), "paragraph") = (cur_name.clone(), cur_family.as_str()) {
                            let align = match attr_val(&e, "fo:text-align").as_deref() {
                                Some("center") => Alignment::Center,
                                Some("end") | Some("right") => Alignment::Right,
                                Some("justify") => Alignment::Justify,
                                _ => Alignment::Left,
                            };
                            let brk = attr_val(&e, "fo:break-before").as_deref() == Some("page");
                            let spacing = attr_val(&e, "fo:line-height")
                                .and_then(|v| v.trim_end_matches('%').parse::<f32>().ok())
                                .map(|pct| pct / 100.0)
                                .unwrap_or(1.0);
                            let length = |name: &str| attr_val(&e, name).and_then(|v| parse_length_pt(&v)).unwrap_or(0.0);
                            out.para.insert(name, AutoParaStyle {
                                shading: attr_val(&e, "fo:background-color").and_then(|c| odt_color(&c)).filter(|c| *c != [255, 255, 255]),
                                border: odt_para_border(&e),
                                alignment: align,
                                page_break_before: brk,
                                keep_with_next: attr_val(&e, "fo:keep-with-next").as_deref() == Some("always"),
                                line_spacing: spacing,
                                // `fo:space-before` is what this writer
                                // used to emit; still accepted so a
                                // document saved by an older build keeps
                                // its spacing.
                                space_before_pt: {
                                    let m = length("fo:margin-top");
                                    if m != 0.0 { m } else { length("fo:space-before") }
                                },
                                space_after_pt: {
                                    let m = length("fo:margin-bottom");
                                    if m != 0.0 { m } else { length("fo:space-after") }
                                },
                                left_indent_pt: length("fo:margin-left"),
                                right_indent_pt: length("fo:margin-right"),
                                first_line_indent_pt: length("fo:text-indent"),
                                // Filled from the `style:tab-stop`
                                // children that follow this element.
                                tab_stops_pt: Vec::new(),
                                sets: [
                                    attr_val(&e, "fo:margin-top").is_some() || attr_val(&e, "fo:space-before").is_some(),
                                    attr_val(&e, "fo:margin-bottom").is_some() || attr_val(&e, "fo:space-after").is_some(),
                                    attr_val(&e, "fo:line-height").is_some(),
                                ],
                                number_lines: attr_val(&e, "text:number-lines").map(|v| v == "true"),
                            });
                        }
                    }
                    // A tab stop is a child of the paragraph properties
                    // just inserted above, so the entry is already there.
                    "style:tab-stop" => {
                        if let (Some(name), "paragraph") = (cur_name.clone(), cur_family.as_str()) {
                            if let Some(pos) =
                                attr_val(&e, "style:position").and_then(|v| parse_length_pt(&v))
                            {
                                if let Some(st) = out.para.get_mut(&name) {
                                    st.tab_stops_pt.push(pos);
                                }
                            }
                        }
                    }
                    _ => {}
                }
            }
            Ok(Event::Eof) => break,
            Err(_) => break,
            _ => {}
        }
    }
    out
}

/// Column layout declared on a `text:section` rather than on the page.
///
/// ODF allows either, and the two live in different parts: a page-wide
/// layout carries `style:columns` inside `style:page-layout-properties`
/// in styles.xml, which is what this writer emits. LibreOffice, reading
/// a docx `w:cols`, models it as a section instead and writes
/// `style:section-properties` into content.xml — so a reader that only
/// looks at the page layout sees a two-column document as one column.
/// Nothing is lost in that conversion; it is simply recorded elsewhere.
///
/// Returns the first section's count and gap, the gap only when stated.
pub(crate) fn parse_section_columns(xml: &str) -> Option<(u8, Option<f64>)> {
    let mut reader = Reader::from_str(xml);
    let mut in_section_props = false;
    loop {
        match reader.read_event() {
            Ok(Event::Start(e)) if e.name().as_ref() == "style:section-properties" => {
                in_section_props = true;
            }
            Ok(Event::End(e)) if e.name().as_ref() == "style:section-properties" => {
                in_section_props = false;
            }
            Ok(Event::Start(e)) | Ok(Event::Empty(e))
                if in_section_props && e.name().as_ref() == "style:columns" =>
            {
                let count = attr_val(&e, "fo:column-count").and_then(|v| v.parse::<u8>().ok())?;
                if count <= 1 {
                    return None;
                }
                let gap = attr_val(&e, "fo:column-gap").and_then(|v| parse_length_pt(&v));
                return Some((count, gap));
            }
            Ok(Event::Eof) | Err(_) => return None,
            _ => {}
        }
    }
}

/// How headings 1-6 look, from styles.xml's `Heading_20_N` (#1297), each
/// with what it inherits from its parent styles; empty when the file
/// defines none, as the docx reader does.
/// The document's body font: the default paragraph style's font and size,
/// with the "Standard" (Default Paragraph Style) style's own over them, as
/// Writer resolves them. A font is named by its font-face declaration.
/// Without it, a Calibri document drew in the application's serif face.
pub(crate) fn read_base_font(styles: &str) -> crate::model::BaseFont {
    let mut faces: std::collections::HashMap<String, String> = Default::default();
    // (font name, size in points) from the default style, then Standard.
    let mut found: [(Option<String>, Option<f64>); 2] = Default::default();
    let mut slot: Option<usize> = None;
    let mut reader = Reader::from_str(styles);
    loop {
        match reader.read_event() {
            Ok(Event::Start(e)) | Ok(Event::Empty(e)) => match e.name().as_ref() {
                "style:font-face" => {
                    if let (Some(n), Some(f)) = (attr_val(&e, "style:name"), attr_val(&e, "svg:font-family")) {
                        faces.insert(n, f.trim_matches(|c| c == '\'' || c == '"').to_string());
                    }
                }
                "style:default-style" => {
                    slot = (attr_val(&e, "style:family").as_deref() == Some("paragraph")).then_some(0);
                }
                "style:style" => {
                    let standard = attr_val(&e, "style:name").as_deref() == Some("Standard")
                        && attr_val(&e, "style:family").as_deref() == Some("paragraph");
                    slot = standard.then_some(1);
                }
                "style:text-properties" => {
                    if let Some(i) = slot {
                        if let Some(n) = attr_val(&e, "style:font-name") {
                            found[i].0 = Some(n);
                        }
                        if let Some(pt) = attr_val(&e, "fo:font-size").and_then(|v| parse_length_pt(&v)) {
                            found[i].1 = Some(pt);
                        }
                    }
                }
                _ => {}
            },
            Ok(Event::End(e)) if matches!(e.name().as_ref(), "style:default-style" | "style:style") => slot = None,
            Ok(Event::Eof) | Err(_) => break,
            _ => {}
        }
    }
    let name = found[1].0.clone().or_else(|| found[0].0.clone());
    let size = found[1].1.or(found[0].1);
    crate::model::BaseFont {
        family: name.map(|n| faces.get(&n).cloned().unwrap_or(n)),
        size_hp: size.map(|pt| (pt * 2.0).round() as u16).filter(|hp| *hp > 0),
    }
}

/// The space before, space after and line height paragraph style `name`
/// has: its own where it sets them, else the nearest style up its parent
/// chain (automatic styles in `auto`, named ones in `named`) that does.
/// None where no style in the chain sets one.
pub(crate) fn inherited_spacing(name: &str, auto: &AutoStyles, named: &AutoStyles) -> (Option<f64>, Option<f64>, Option<f32>) {
    let (mut before, mut after, mut line) = (None, None, None);
    let mut cur = Some(name.to_string());
    for _ in 0..16 {
        let Some(n) = cur else { break };
        if let Some(st) = auto.para.get(&n).or_else(|| named.para.get(&n)) {
            if st.sets[0] && before.is_none() {
                before = Some(st.space_before_pt);
            }
            if st.sets[1] && after.is_none() {
                after = Some(st.space_after_pt);
            }
            if st.sets[2] && line.is_none() {
                line = Some(st.line_spacing);
            }
        }
        cur = auto.para_parent.get(&n).or_else(|| named.para_parent.get(&n)).cloned();
    }
    (before, after, line)
}

pub(crate) fn read_heading_styles(styles: &str) -> Vec<RunStyle> {
    let defs = parse_auto_styles(styles);
    let look = |n: u8| -> Option<RunStyle> {
        let mut chain = Vec::new();
        let mut name = format!("Heading_20_{n}");
        while chain.len() < 8 {
            let own = defs.para_text.get(&name);
            let parent = defs.para_parent.get(&name).cloned();
            if own.is_none() && parent.is_none() {
                break;
            }
            chain.push(own.cloned().unwrap_or_default());
            match parent {
                Some(p) => name = p,
                None => break,
            }
        }
        (!chain.is_empty()).then(|| {
            chain.into_iter().rev().fold(RunStyle::default(), |base, own| RunStyle {
                bold: base.bold || own.bold,
                italic: base.italic || own.italic,
                font_size_hp: own.font_size_hp.or(base.font_size_hp),
                color: own.color.or(base.color),
                font_family: own.font_family.or(base.font_family),
                ..Default::default()
            })
        })
    };
    if !(1..=6).any(|n| defs.para_text.contains_key(&format!("Heading_20_{n}"))) {
        return Vec::new();
    }
    (1..=6).map(|n| look(n).unwrap_or_default()).collect()
}

/// Samizdat : « #rrggbb » en RVB.
pub(crate) fn odt_color(v: &str) -> Option<[u8; 3]> {
    let h = v.trim().trim_start_matches('#');
    if h.len() != 6 {
        return None;
    }
    let c = |i: usize| u8::from_str_radix(&h[i..i + 2], 16).ok();
    Some([c(0)?, c(2)?, c(4)?])
}

/// Samizdat : la bordure d'un paragraphe (fo:border, fo:border-top…).
pub(crate) fn odt_para_border(e: &quick_xml::events::BytesStart<'_>) -> Option<crate::model::ParaBorder> {
    use crate::model::ParaBorder as B;
    let parse = |v: &str| -> Option<(u16, [u8; 3])> {
        if v.trim().starts_with("none") || v.trim().is_empty() {
            return None;
        }
        let mut width = 4u16;
        let mut color = [0u8; 3];
        for tok in v.split_whitespace() {
            if let Some(pt) = parse_length_pt(tok) {
                width = ((pt * 8.0).round() as u16).max(2);
            } else if let Some(c) = odt_color(tok) {
                color = c;
            }
        }
        Some((width, color))
    };
    let mut out: Option<B> = None;
    let mut add = |bits: u8, v: Option<String>| {
        if let Some((w, c)) = v.as_deref().and_then(parse) {
            let b = out.get_or_insert(B { sides: 0, width: w, color: c });
            b.sides |= bits;
            b.width = b.width.max(w);
        }
    };
    add(B::ALL, attr_val(e, "fo:border"));
    add(B::TOP, attr_val(e, "fo:border-top"));
    add(B::BOTTOM, attr_val(e, "fo:border-bottom"));
    add(B::LEFT, attr_val(e, "fo:border-left"));
    add(B::RIGHT, attr_val(e, "fo:border-right"));
    out
}
