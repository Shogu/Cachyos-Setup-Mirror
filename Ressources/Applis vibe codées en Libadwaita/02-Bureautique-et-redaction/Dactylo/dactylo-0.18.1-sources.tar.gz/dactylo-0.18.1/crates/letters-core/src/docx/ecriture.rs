// ecriture.rs — partie de docx.rs, découpé par thème.
// SPDX-License-Identifier: GPL-3.0-or-later

#![allow(unused_imports)]
use super::*;
use crate::model::{Alignment, Document, ListKind, PageGeometry, Paragraph, ParaStyle, Run, RunStyle};
use rdocx_oxml::shared::ST_Jc;

/// Tabs in run text as Word's `w:tab` elements. rdocx writes a tab as a
/// character inside `w:t`, which Word and LibreOffice read as a space.
pub(crate) fn tabs_as_elements(xml: &str) -> String {
    let mut out = String::with_capacity(xml.len());
    let mut rest = xml;
    while let Some(at) = rest.find("<w:t>").into_iter().chain(rest.find("<w:t ")).min() {
        let Some(open_end) = rest[at..].find('>').map(|e| at + e + 1) else { break };
        let Some(close) = rest[open_end..].find("</w:t>").map(|c| open_end + c) else { break };
        out.push_str(&rest[..open_end]);
        let text = &rest[open_end..close];
        out.push_str(&text.replace('\t', "</w:t><w:tab/><w:t xml:space=\"preserve\">"));
        rest = &rest[close..];
    }
    out.push_str(rest);
    out
}

/// A run's text as written: bracketed as a tracked change if it is one.
pub(crate) fn bracketed(revisions: &mut Vec<crate::model::Revision>, run: &Run) -> String {
    match &run.style.revision {
        Some(rev) => {
            revisions.push(rev.clone());
            crate::docx_revisions::bracket(revisions.len() - 1, &run.text)
        }
        None => run.text.clone(),
    }
}

/// `package` with part `name` rewritten by `f`.
/// Samizdat : le texte de la marque d'un paragraphe aux lignes numérotées.
pub(crate) const LINE_NUMBERS_MARK: &str = "\u{E000}samizdat-lignes\u{E000}";

/// Samizdat : la numérotation des lignes de Word. Une ligne sur cinq,
/// de nouveau à partir de 1 à chaque page (`w:lnNumType` de la section) ;
/// les paragraphes sans la marque en sont exclus (`w:suppressLineNumbers`).
pub(crate) fn line_numbering_xml(xml: &str) -> String {
    // Les éléments de `w:pPr` qui précèdent `w:suppressLineNumbers`.
    const BEFORE: [&str; 7] = ["w:pStyle", "w:keepNext", "w:keepLines", "w:pageBreakBefore", "w:framePr", "w:widowControl", "w:numPr"];
    // Ceux de `w:sectPr` qui suivent `w:lnNumType`.
    const AFTER_SECT: [&str; 12] = ["w:pgNumType", "w:cols", "w:formProt", "w:vAlign", "w:noEndnote", "w:titlePg", "w:textDirection", "w:bidi", "w:rtlGutter", "w:docGrid", "w:printerSettings", "w:sectPrChange"];
    let mut out = String::with_capacity(xml.len() + 1024);
    let mut rest = xml;
    loop {
        // Le prochain paragraphe : `<w:p>`, `<w:p …>` ou `<w:p/>`.
        let Some(at) = find_element(rest, "w:p") else {
            out.push_str(rest);
            break;
        };
        out.push_str(&rest[..at]);
        rest = &rest[at..];
        let open_end = rest.find('>').map_or(rest.len(), |i| i + 1);
        if rest[..open_end].ends_with("/>") {
            out.push_str("<w:p><w:pPr><w:suppressLineNumbers/></w:pPr></w:p>");
            rest = &rest[open_end..];
            continue;
        }
        let end = rest.find("</w:p>").map_or(rest.len(), |i| i + "</w:p>".len());
        let para = &rest[..end];
        rest = &rest[end..];
        if let Some(m) = para.find(LINE_NUMBERS_MARK) {
            // Retirer le `w:r` de la marque.
            let start = para[..m].rfind("<w:r>").or_else(|| para[..m].rfind("<w:r ")).unwrap_or(m);
            let stop = para[m..].find("</w:r>").map_or(m + LINE_NUMBERS_MARK.len(), |i| m + i + "</w:r>".len());
            out.push_str(&para[..start]);
            out.push_str(&para[stop..]);
            continue;
        }
        let head = &para[..open_end];
        let body = &para[open_end..];
        if body.starts_with("<w:pPr/>") {
            out.push_str(head);
            out.push_str("<w:pPr><w:suppressLineNumbers/></w:pPr>");
            out.push_str(&body["<w:pPr/>".len()..]);
        } else if let Some(ppr) = body.strip_prefix("<w:pPr>") {
            out.push_str(head);
            out.push_str("<w:pPr>");
            // Après les enfants qui le précèdent.
            let mut i = 0;
            for (name, start, stop) in children(ppr) {
                if !BEFORE.contains(&name) {
                    let _ = start;
                    break;
                }
                i = stop;
            }
            out.push_str(&ppr[..i]);
            out.push_str("<w:suppressLineNumbers/>");
            out.push_str(&ppr[i..]);
        } else {
            out.push_str(head);
            out.push_str("<w:pPr><w:suppressLineNumbers/></w:pPr>");
            out.push_str(body);
        }
    }
    // La section du corps : la dernière.
    let ln = "<w:lnNumType w:countBy=\"5\" w:restart=\"newPage\"/>";
    if let Some(sect) = out.rfind("<w:sectPr") {
        let open_end = out[sect..].find('>').map_or(out.len(), |i| sect + i + 1);
        if out[..open_end].ends_with("/>") {
            out.replace_range(sect..open_end, &format!("<w:sectPr>{ln}</w:sectPr>"));
        } else {
            let close = out[open_end..].find("</w:sectPr>").map_or(out.len(), |i| open_end + i);
            let inner = out[open_end..close].to_string();
            let at = children(&inner).into_iter().find(|(n, _, _)| AFTER_SECT.contains(n)).map_or(inner.len(), |(_, s, _)| s);
            out.insert_str(open_end + at, ln);
        }
    }
    out
}

/// Samizdat : le texte de remplacement des images (`descr` de
/// `wp:docPr`), dans l'ordre où elles ont été écrites : rdocx ne l'écrit
/// pas, et une frise chronologique y garde ses données.
pub(crate) fn image_descriptions_xml(xml: &str, alts: &[String]) -> String {
    let mut out = String::with_capacity(xml.len() + alts.iter().map(String::len).sum::<usize>() * 2);
    let mut rest = xml;
    let mut alts = alts.iter();
    while let Some(at) = find_element(rest, "wp:docPr") {
        out.push_str(&rest[..at]);
        rest = &rest[at..];
        let end = rest.find('>').map_or(rest.len(), |i| i + 1);
        let tag = &rest[..end];
        match alts.next().filter(|a| !a.is_empty() && !tag.contains(" descr=")) {
            Some(alt) => {
                let close = if tag.ends_with("/>") { end - 2 } else { end - 1 };
                out.push_str(&tag[..close]);
                out.push_str(&format!(" descr=\"{}\"", xml_escape(alt)));
                out.push_str(&tag[close..]);
            }
            None => out.push_str(tag),
        }
        rest = &rest[end..];
    }
    out.push_str(rest);
    out
}

/// La position du prochain élément `name` (pas d'un autre dont le nom
/// commence pareil).
pub(crate) fn find_element(xml: &str, name: &str) -> Option<usize> {
    let tag = format!("<{name}");
    let mut from = 0;
    while let Some(i) = xml[from..].find(&tag) {
        let at = from + i;
        match xml[at + tag.len()..].chars().next() {
            Some('>' | ' ' | '/') => return Some(at),
            _ => from = at + tag.len(),
        }
    }
    None
}

/// Les éléments enfants de premier niveau de `xml` : nom, début, fin.
pub(crate) fn children(xml: &str) -> Vec<(&str, usize, usize)> {
    let mut out = Vec::new();
    let mut depth = 0usize;
    let mut i = 0;
    let mut current: Option<(&str, usize)> = None;
    while let Some(lt) = xml[i..].find('<') {
        let at = i + lt;
        let Some(gt) = xml[at..].find('>') else { break };
        let tag = &xml[at..at + gt + 1];
        i = at + gt + 1;
        if tag.starts_with("</") {
            depth = depth.saturating_sub(1);
            if depth == 0 {
                if let Some((n, s)) = current.take() {
                    out.push((n, s, i));
                }
            }
            continue;
        }
        let name_end = tag[1..].find([' ', '>', '/']).map_or(tag.len() - 1, |e| e + 1);
        let name = &tag[1..name_end];
        let empty = tag.ends_with("/>");
        if depth == 0 {
            if empty {
                out.push((name, at, i));
            } else {
                current = Some((name, at));
                depth = 1;
            }
        } else if !empty {
            depth += 1;
        }
    }
    out
}

/// Write a Document to a .docx file.
pub fn write(doc: &Document, path: impl AsRef<std::path::Path>) -> Result<(), String> {
    let mut out = rdocx::Document::new();
    // Smart chips, written as sentinels and made content controls below.
    let mut chips: Vec<(crate::chips::Chip, String)> = Vec::new();
    // Tracked changes, written as bracketed text and made w:ins/w:del below.
    let mut revisions: Vec<crate::model::Revision> = Vec::new();
    // Samizdat : le texte de remplacement de chaque image, dans l'ordre.
    let mut image_alts: Vec<String> = Vec::new();
    let paras = &doc.paragraphs;
    // Comment threads: marker runs where each one's text starts and ends,
    // made range elements below. `open` are the threads the text written
    // so far is in; a thread with no text is written, empty, first.
    let roots = crate::docx_comments::roots(doc);
    let mut open: Vec<u32> = Vec::new();
    let mut orphans: Vec<u32> = {
        let marked: std::collections::HashSet<u32> = paras.iter().flat_map(|p| &p.runs).flat_map(|r| r.style.comments.iter().copied()).collect();
        roots.iter().copied().filter(|id| !marked.contains(id)).collect()
    };
    let wanted = |run: &Run| -> Vec<u32> { crate::docx_comments::threads_of(&roots, &run.style.comments).collect() };
    // Footnote texts first: model index → docx id.
    let footnote_ids: Vec<i32> = doc.footnotes.iter().map(|t| out.add_footnote(t)).collect();
    // The text column's width, where a table of contents' page numbers go
    // (rdocx's default page: Letter with 1in margins).
    let text_width_pt = doc.page.map_or(468.0, |g| g.width_pt - g.margin_left_pt - g.margin_right_pt);
    let mut has_toc = false;
    // The numIds of the bullet and numbered list definitions, once made.
    let mut list_ids: [Option<u32>; 2] = [None, None];
    let mut i = 0;
    while i < paras.len() {
        // Consecutive paragraphs sharing a table id become one rdocx table.
        if let Some(tc0) = paras[i].style.table_cell {
            let start = i;
            while i < paras.len()
                && paras[i].style.table_cell.map(|t| t.table) == Some(tc0.table)
            {
                i += 1;
            }
            let group = &paras[start..i];
            let rows = group.iter().filter_map(|p| p.style.table_cell.map(|t| t.row)).max().unwrap_or(0) as usize + 1;
            let cols = group.iter().filter_map(|p| p.style.table_cell.map(|t| t.col)).max().unwrap_or(0) as usize + 1;
            let mut tbl = out.add_table(rows, cols);
            if rows == 1 && cols == 1 {
                // Samizdat : un cartouche. Word n'a pas de coins arrondis :
                // son nom de style les garde pour la relecture.
                let look = group[0].style.cartouche.unwrap_or_default();
                tbl.set_style(&look.name());
                if look.line_eighths() == 0 {
                    tbl.set_borders(rdocx::BorderStyle::None, 0, "auto");
                } else {
                    tbl.set_borders(rdocx::BorderStyle::Single, look.line_eighths(), crate::model::Cartouche::LINE_HEX);
                }
                let _ = tbl.set_shading_checked(look.fill_hex());
                // LibreOffice ne lit que le fond des cases.
                if let Some(mut cell) = tbl.cell(0, 0) {
                    cell.set_shading(look.fill_hex());
                }
                let pad = rdocx::Length::pt(crate::layout::BOX_PADDING_PT);
                let side = rdocx::Length::pt(crate::layout::CELL_PADDING_PT);
                tbl.set_cell_margins(pad, side, pad, side);
            } else {
                let cells: Vec<crate::model::TableCell> = group.iter().filter_map(|p| p.style.table_cell).collect();
                // Samizdat : un quadrillage fin (sinon Word affiche le
                // tableau sans aucune bordure), sauf tableau sans bordure.
                if cells.iter().all(|c| c.no_border) {
                    tbl.set_borders(rdocx::BorderStyle::None, 0, "auto");
                } else {
                    tbl.set_borders(rdocx::BorderStyle::Single, 4, "808080");
                }
                // La largeur des colonnes, si chacune est connue.
                let widths: Vec<Option<u32>> = (0..cols as u32)
                    .map(|c| cells.iter().find(|t| t.col == c && !t.covered && t.span() == 1 && t.width_tw > 0).map(|t| t.width_tw))
                    .collect();
                if widths.iter().all(Option::is_some) {
                    let w: Vec<rdocx::Length> = widths.iter().map(|w| rdocx::Length::pt(f64::from(w.unwrap_or(0)) / 20.0)).collect();
                    let _ = tbl.set_grid_widths(&w);
                }
                for r in 0..rows as u32 {
                    let Some(c) = cells.iter().find(|t| t.row == r) else { continue };
                    if c.height_tw > 0 {
                        if let Some(mut row) = tbl.row(r as usize) {
                            let h = rdocx::Length::pt(f64::from(c.height_tw) / 20.0);
                            if c.height_exact { row.set_height_exact(h) } else { row.set_height(h) }
                        }
                    }
                }
                for c in &cells {
                    if let (Some([r, g, b]), false) = (c.fill, c.covered) {
                        if let Some(mut cell) = tbl.cell(c.row as usize, c.col as usize) {
                            cell.set_shading(&format!("{r:02X}{g:02X}{b:02X}"));
                        }
                    }
                }
            }
            let mut filled = std::collections::HashSet::new();
            for p in group {
                let tc = p.style.table_cell.expect("grouped by table_cell");
                if let Some(mut cell) = tbl.cell(tc.row as usize, tc.col as usize) {
                    // A new cell already holds an empty paragraph: replace
                    // it, or every cell opens with a blank line in Writer
                    // and Word (our reader skipped empty cell paragraphs,
                    // which hid it; #1296).
                    if filled.insert((tc.row, tc.col)) {
                        cell.remove_first_empty_paragraph();
                    }
                    let mut cp = cell.add_paragraph("");
                    // Samizdat : un titre dans une case (un cartouche) reste
                    // un titre, et figure dans le plan.
                    if let Some(level) = p.style.heading {
                        cp = cp.style(&format!("Heading{}", level.clamp(1, 6)));
                    }
                    // A cell paragraph's indents and alignment, which the
                    // reader maps the same way it maps a body paragraph's.
                    if p.style.left_indent_pt != 0.0 {
                        cp = cp.indent_left(rdocx::Length::pt(p.style.left_indent_pt));
                    }
                    if p.style.right_indent_pt != 0.0 {
                        cp = cp.indent_right(rdocx::Length::pt(p.style.right_indent_pt));
                    }
                    cp = write_para_box(cp, &p.style);
                    cp = match p.style.alignment {
                        Alignment::Center => cp.alignment(rdocx::Alignment::Center),
                        Alignment::Right => cp.alignment(rdocx::Alignment::Right),
                        Alignment::Justify => cp.alignment(rdocx::Alignment::Justify),
                        _ => cp,
                    };
                    // A cell's comments open and close inside it.
                    let mut in_cell: Vec<u32> = Vec::new();
                    for run in p.runs.iter().map(Some).chain([None]) {
                        let want = run.map(wanted).unwrap_or_default();
                        for (id, start) in crate::docx_comments::transition(&mut in_cell, &want) {
                            let _ = cp.add_run(&crate::docx_comments::marker(id, start));
                        }
                        let Some(run) = run else { break };
                        let mut r = cp.add_run(&run.text);
                        if run.style.bold { r = r.bold(true); }
                        if run.style.italic { r = r.italic(true); }
                        if run.style.underline { r = r.underline(true); }
                        if run.style.strikethrough { r = r.strike(true); }
                        if run.style.highlight { r = crate::docx::write_highlight(r, run.style.highlight_color.as_deref()); }
                        if run.style.code { r = r.style("SourceText"); }
                    }
                }
            }
            // Samizdat : les fusions, une fois les cases remplies — de droite
            // à gauche, car une fusion retire les cases qu'elle couvre.
            let merged: Vec<crate::model::TableCell> = group.iter().filter_map(|p| p.style.table_cell).collect();
            // La largeur de chaque colonne (celle du document, sinon un partage
            // égal des 9360 vingtièmes de point que rdocx donne au tableau).
            let col_tw: Vec<u32> = {
                let known: Vec<Option<u32>> = (0..cols as u32)
                    .map(|c| merged.iter().find(|t| t.col == c && !t.covered && t.span() == 1 && t.width_tw > 0).map(|t| t.width_tw))
                    .collect();
                if known.iter().all(Option::is_some) {
                    known.into_iter().map(|w| w.unwrap_or(0)).collect()
                } else {
                    vec![9360 / (cols.max(1) as u32); cols]
                }
            };
            for r in 0..rows as u32 {
                let mut row: Vec<crate::model::TableCell> = merged.iter().filter(|t| t.row == r && !t.covered).copied().collect();
                row.sort_by_key(|t| t.col);
                row.dedup_by_key(|t| t.col);
                for t in row.iter().rev().filter(|t| t.span() > 1) {
                    let _ = tbl.set_cell_grid_span_checked(r as usize, t.col as usize, Some(t.span()));
                }
                // Word attend une largeur (w:tcW) sur chaque case.
                for (idx, t) in row.iter().enumerate() {
                    let tw: u32 = (t.col..(t.col + t.span()).min(cols as u32)).map(|c| col_tw[c as usize]).sum();
                    if let Some(mut cell) = tbl.cell(r as usize, idx) {
                        cell.set_width(rdocx::Length::pt(f64::from(tw) / 20.0));
                    }
                }
                for (idx, t) in row.iter().enumerate() {
                    let v = match t.vmerge {
                        1 => rdocx::VMerge::Restart,
                        2 => rdocx::VMerge::Continue,
                        _ => continue,
                    };
                    let _ = tbl.set_cell_vertical_merge(r as usize, idx, Some(v));
                }
            }
            // OOXML requires a paragraph in every cell, which a cell left
            // empty keeps from its creation, and one after a table.
            // Samizdat : seulement quand rien d'autre ne suit (fin du document)
            // ou qu'un autre tableau suit (sinon les deux fusionneraient) ;
            // l'ajouter toujours faisait grossir le document d'un paragraphe
            // vide par tableau à chaque enregistrement.
            if paras.get(i).is_none_or(|p| p.style.table_cell.is_some()) {
                out.add_paragraph("");
            }
            continue;
        }
        let para = &paras[i];
        i += 1;
        let level = u32::from(para.style.list_level);
        let mut p = match (para.style.list, list_ids[usize::from(para.style.list == ListKind::Numbered)]) {
            (ListKind::None, _) => out.add_paragraph(""),
            // rdocx's add_*_list_item clones the whole document on every
            // call (`clone_for_staging`), so a document with n list items
            // cost O(n²): 5,000 paragraphs took 30 s to save (#1208). It
            // only needs to allocate the list definition once; later items
            // are plain paragraphs on that numId, which is the XML the
            // builder would have written anyway.
            (ListKind::Bullet | ListKind::Numbered, Some(num_id)) => out.add_paragraph("").numbering(num_id, level),
            (kind, None) => {
                let _ = if kind == ListKind::Bullet {
                    out.add_bullet_list_item("", level)
                } else {
                    out.add_numbered_list_item("", level)
                };
                list_ids[usize::from(kind == ListKind::Numbered)] =
                    out.paragraphs().last().and_then(|p| p.numbering()).map(|(num_id, _)| num_id);
                out.last_paragraph_mut().expect("the list item just added")
            }
        };
        if let Some(level) = para.style.heading {
            p = p.style(&format!("Heading{}", level.clamp(1, 6)));
        }
        if para.style.block_quote {
            p = p.style("Quote");
        }
        if para.style.code_block.is_some() && para.style.heading.is_none() {
            p = p.style("PreformattedText");
        }
        if let Some(name) = &para.style.named_style {
            p = p.style(name);
        }
        if para.style.page_break_before {
            p = p.page_break_before(true);
        }
        if para.style.keep_with_next {
            p = p.keep_with_next(true);
        }
        p = write_para_box(p, &para.style);
        // Samizdat : une marque, que `line_numbering_xml` retire en
        // laissant ce paragraphe dans la numérotation des lignes.
        if para.style.line_numbers {
            let _ = p.add_run(LINE_NUMBERS_MARK);
        }
        if (para.style.line_spacing - 1.0).abs() > 0.01 {
            p = p.line_spacing_multiple(para.style.line_spacing as f64);
        }
        // Paragraph indents and spacing. The odt writer has carried these
        // since it was written; this one never emitted them at all, so a
        // document with an indented or spaced paragraph lost that on every
        // .docx save while keeping it on .odt. rdocx has had the builders
        // the whole time — they were simply never called.
        //
        // Only non-zero values are written: OOXML treats an absent `w:ind`
        // or `w:spacing` as "inherit from the style", and writing an
        // explicit zero is a different claim, one that overrides a style's
        // own indent with nothing.
        if para.style.list != ListKind::None {
            // A list item says where its text and marker go, as Letters
            // draws them: the text one list indent per level in from the
            // paragraph's own indent, the marker one hanging indent before
            // it. Left to rdocx's numbering definition (0.5in per level)
            // LibreOffice and Word drew our lists twice as deep as we do;
            // the edit-render journey's bullet showed it (#1201). The reader
            // takes the list's own indent back off.
            let text = para.style.left_indent_pt.max(0.0) + crate::lists::text_indent_pt(para.style.list_level);
            p = p.indent_left(rdocx::Length::pt(text)).hanging_indent(rdocx::Length::pt(crate::lists::HANGING_PT));
        } else if para.style.left_indent_pt != 0.0 {
            p = p.indent_left(rdocx::Length::pt(para.style.left_indent_pt));
        }
        if para.style.right_indent_pt != 0.0 {
            p = p.indent_right(rdocx::Length::pt(para.style.right_indent_pt));
        }
        if para.style.first_line_indent_pt != 0.0 && para.style.list == ListKind::None {
            p = p.first_line_indent(rdocx::Length::pt(para.style.first_line_indent_pt));
        }
        if para.style.space_before_pt != 0.0 {
            p = p.space_before(rdocx::Length::pt(para.style.space_before_pt));
        }
        if para.style.space_after_pt != 0.0 {
            p = p.space_after(rdocx::Length::pt(para.style.space_after_pt));
        }
        // Tab stops, which neither writer persisted: a paragraph's stops
        // were lost on every save in both formats, self round trip
        // included. The model has positions only, so every stop is a
        // left-aligned one.
        // A table of contents entry: Word's TOC style for its level, and
        // its page number at a right tab with a dot leader at the margin.
        if let Some(level) = para.style.toc {
            p = p.style(&format!("TOC{}", level.clamp(1, 9)));
            p = p.add_tab_stop_with_leader(rdocx::TabAlignment::Right, rdocx::Length::pt(text_width_pt), rdocx::TabLeader::Dot);
        } else {
            for pos in &para.style.tab_stops_pt {
                p = p.add_tab_stop(rdocx::TabAlignment::Left, rdocx::Length::pt(*pos));
            }
        }
        p = match para.style.alignment {
            Alignment::Left => p,
            Alignment::Center => p.alignment(rdocx::Alignment::Center),
            Alignment::Right => p.alignment(rdocx::Alignment::Right),
            Alignment::Justify => p.alignment(rdocx::Alignment::Justify),
        };
        let _ = p; // release the builder borrow before append_hyperlink
        // A numbered item that restarts the count (#1205): its own instance
        // of the numbered list's definition, with a start override at its
        // level, which the items after it continue. Without it a list
        // restarted at 5 counted on from the previous one.
        if let (ListKind::Numbered, Some(start), Some(num_id)) = (para.style.list, para.style.list_start, list_ids[1]) {
            let definition = out.numbering_instance(num_id).map(|n| n.definition_id);
            let override_ = rdocx::NumberingLevelOverride {
                level, start: Some(start), replacement: None, paragraph_style_link: None, has_unmodeled_properties: false,
            };
            if let Some(Ok(id)) = definition.map(|d| out.add_numbering_instance(d, &[override_])) {
                out.last_paragraph_mut().expect("the list item").set_numbering(id, level);
                list_ids[1] = Some(id);
            }
        }
        // A table of contents is Word's TOC field around its entries.
        let toc_edge = |k: usize| paras.get(k).is_none_or(|q| q.style.toc.is_none());
        if para.style.toc.is_some() && (i < 2 || toc_edge(i - 2)) {
            let _ = out.last_paragraph_mut().expect("paragraph").add_run(&crate::docx_toc::begin_marker());
            has_toc = true;
        }
        for id in std::mem::take(&mut orphans) {
            for start in [true, false] {
                let _ = out.last_paragraph_mut().expect("paragraph").add_run(&crate::docx_comments::marker(id, start));
            }
        }
        for run in &para.runs {
            for (id, start) in crate::docx_comments::transition(&mut open, &wanted(run)) {
                let _ = out.last_paragraph_mut().expect("paragraph").add_run(&crate::docx_comments::marker(id, start));
            }
            if let Some(src) = &run.style.image {
                // Images embed via add_picture, which appends its own
                // paragraph — mid-paragraph images therefore split the
                // paragraph (documented v1 limitation). Unreadable sources
                // degrade to the alt text.
                match std::fs::read(src) {
                    Ok(bytes) => {
                        let name = std::path::Path::new(src)
                            .file_name().map(|n| n.to_string_lossy().to_string())
                            .unwrap_or_else(|| "image.png".into());
                        // The size it was shown at; every picture used to
                        // be saved 4in x 3in whatever its size.
                        let (w, h) = match run.style.image_extent_emu {
                            Some((w, h)) => (rdocx::Length::emu(w as i64), rdocx::Length::emu(h as i64)),
                            None => (rdocx::Length::inches(4.0), rdocx::Length::inches(3.0)),
                        };
                        // Samizdat : l'image reste dans son paragraphe (alignement,
                        // texte autour) au lieu d'en créer un, suivi d'un
                        // paragraphe vide : chaque enregistrement ajoutait
                        // deux paragraphes vides autour de chaque image.
                        let rel = out.embed_image(&bytes, &name);
                        let mut p = out.last_paragraph_mut().expect("paragraph");
                        let mut r = p.add_run("");
                        r.add_picture(&rel, w, h);
                        image_alts.push(run.text.clone());
                    }
                    Err(_) => {
                        let mut p = out.last_paragraph_mut().expect("paragraph");
                        let _ = p.add_run(&run.text);
                    }
                }
                continue;
            }
            if let Some(idx) = run.style.footnote {
                if let Some(&fid) = footnote_ids.get(idx) {
                    let mut p = out.last_paragraph_mut().expect("paragraph");
                    p.add_footnote_ref(fid);
                }
                continue;
            }
            if let Some(chip) = &run.style.chip {
                let mark = crate::docx_chips::sentinel(chips.len());
                chips.push((chip.clone(), run.text.clone()));
                match &run.style.link {
                    Some(url) => out.append_hyperlink(&mark, url),
                    None => {
                        let _ = out.last_paragraph_mut().expect("paragraph").add_run(&mark);
                    }
                }
                continue;
            }
            if let Some(url) = &run.style.link {
                // Hyperlinks need a document-level relationship; styles on
                // link text are not yet carried through append_hyperlink.
                let text = bracketed(&mut revisions, run);
                out.append_hyperlink(&text, url);
                continue;
            }
            let mut p = out.last_paragraph_mut().expect("paragraph just added");
            let text = bracketed(&mut revisions, run);
            let mut r = p.add_run(&text);
            if run.style.bold { r = r.bold(true); }
            if run.style.italic { r = r.italic(true); }
            if run.style.underline { r = r.underline(true); }
            if run.style.strikethrough { r = r.strike(true); }
            if run.style.highlight { r = crate::docx::write_highlight(r, run.style.highlight_color.as_deref()); }
            if run.style.code { r = r.style("SourceText"); }
            if let Some(f) = &run.style.font_family { r = r.font(f); }
            if let Some(hp) = run.style.font_size_hp { r = r.size(hp as f64 / 2.0); }
            if let Some(c) = &run.style.color { r = r.color(c); }
            match run.style.vert_align {
                Some(crate::model::VertAlign::Superscript) => { r = r.superscript(); }
                Some(crate::model::VertAlign::Subscript) => { r = r.subscript(); }
                None => {}
            }
        }
        if para.style.toc.is_some() && toc_edge(i) {
            let _ = out.last_paragraph_mut().expect("paragraph").add_run(&crate::docx_toc::end_marker());
        }
        // Close the threads the next paragraph's text is not in (all of
        // them before a table, whose cells hold their own).
        let next: Vec<u32> = match paras.get(i) {
            Some(n) if n.style.table_cell.is_none() => n.runs.first().map(wanted).unwrap_or_default(),
            _ => Vec::new(),
        };
        let keep: Vec<u32> = open.iter().copied().filter(|id| next.contains(id)).collect();
        for (id, start) in crate::docx_comments::transition(&mut open, &keep) {
            let _ = out.last_paragraph_mut().expect("paragraph").add_run(&crate::docx_comments::marker(id, start));
        }
    }
    if let Some(h) = &doc.header {
        out.set_header(h);
    }
    if let Some(f) = &doc.footer {
        out.set_footer(f);
    }
    if let Some(pg) = &doc.page {
        out.set_page_size(rdocx::Length::pt(pg.width_pt), rdocx::Length::pt(pg.height_pt));
        out.set_margins(
            rdocx::Length::pt(pg.margin_top_pt),
            rdocx::Length::pt(pg.margin_right_pt),
            rdocx::Length::pt(pg.margin_bottom_pt),
            rdocx::Length::pt(pg.margin_left_pt),
        );
        // A single column is the default section layout, and `w:cols`
        // with `w:num="1"` is noise; more than one has to be written or a
        // two-column document saves as one.
        if pg.columns > 1 {
            out.set_columns(pg.columns as u32, rdocx::Length::pt(pg.column_gap_pt));
        }
    }
    let bytes = out
        .to_bytes()
        .map_err(|e| format!("Cannot save {}: {}", path.as_ref().display(), e))?;
    let bytes = with_letters_styles(&bytes, &doc.base_font, &doc.heading_styles)
        .map_err(|e| format!("Cannot save {}: {}", path.as_ref().display(), e))?;
    let tabbed = paras.iter().flat_map(|p| &p.runs).any(|r| r.text.contains('\t'));
    let numbered = paras.iter().any(|p| p.style.line_numbers);
    let described = image_alts.iter().any(|a| !a.is_empty());
    let broken = paras.iter().flat_map(|p| &p.runs).any(|r| r.text.contains('\u{2028}'));
    let bytes = if chips.is_empty() && revisions.is_empty() && doc.comments.is_empty() && !has_toc && !tabbed && !numbered && !described && !broken {
        bytes
    } else {
        with_part(&bytes, "word/document.xml", |xml| {
            let xml = if tabbed { tabs_as_elements(xml) } else { xml.to_string() };
            let xml = if numbered { line_numbering_xml(&xml) } else { xml };
            let xml = if broken { xml.replace('\u{2028}', "</w:t><w:br/><w:t xml:space=\"preserve\">") } else { xml };
            let xml = if described { image_descriptions_xml(&xml, &image_alts) } else { xml };
            let xml = crate::docx_revisions::wrap(&crate::docx_chips::wrap(&xml, &chips), &revisions);
            let xml = crate::docx_comments::wrap(&xml, &doc.comments);
            if has_toc { crate::docx_toc::wrap(&xml) } else { xml }
        })
        .map_err(|e| format!("Cannot save {}: {}", path.as_ref().display(), e))?
    };
    let bytes = if doc.comments.is_empty() {
        bytes
    } else {
        crate::docx_comments::add_parts(&bytes, &doc.comments).map_err(|e| format!("Cannot save {}: {}", path.as_ref().display(), e))?
    };
    // "{page}" and "{total}" in the header and footer become Word's PAGE
    // and NUMPAGES fields, so every page shows its own number.
    let fielded = |t: &Option<String>| t.as_deref().is_some_and(|t| t.contains("{page}") || t.contains("{total}") || t.contains('\n') || t.contains('\t'));
    let bytes = if fielded(&doc.header) || fielded(&doc.footer) {
        let parts = zip::ZipArchive::new(std::io::Cursor::new(&bytes)).ok().and_then(|mut z| {
            Some(crate::docx_fields::default_parts(&part_text(&mut z, "word/document.xml")?, &part_text(&mut z, "word/_rels/document.xml.rels")?))
        });
        let mut bytes = bytes;
        for part in parts.into_iter().flat_map(|(h, f)| [h, f]).flatten() {
            bytes = with_part(&bytes, &part, |x| crate::docx_fields::fields_zoned(x, (text_width_pt * 20.0).round() as u32))
                .map_err(|e| format!("Cannot save {}: {}", path.as_ref().display(), e))?;
        }
        bytes
    } else {
        bytes
    };
    // Équations, graphiques… gardés tels quels : remis à leur étiquette.
    let bytes = if doc.kept.is_empty() {
        bytes
    } else {
        crate::docx_keep::restore(&bytes, &doc.kept).map_err(|e| format!("Cannot save {}: {}", path.as_ref().display(), e))?
    };
    // Ce que Word exige au-delà du schéma (docx_compat).
    let bytes = crate::docx_compat::harden(&bytes).map_err(|e| format!("Cannot save {}: {}", path.as_ref().display(), e))?;
    suite_common_core::atomic_save::atomic_write_bytes(path.as_ref(), &bytes)
}

/// The styles a document written by Letters must carry so that Word and
/// LibreOffice show it as Letters does.
///
/// rdocx's template says body text is Calibri 11pt with 8pt after each
/// paragraph at 1.08 line spacing, and defines only Heading 1 (16pt blue)
/// — Heading 2 to 6 fell back to body text. Letters draws none of that,
/// so every saved document looked different elsewhere, and, now that the
/// reader resolves styles, would look different in Letters after a reload.
/// This writes the document's base font with no paragraph spacing, and
/// Heading 1–6 as Letters draws them: bold, `layout::heading_scale` times
/// the body size.
pub(crate) fn with_letters_styles(package: &[u8], base: &crate::model::BaseFont, heading_styles: &[RunStyle]) -> Result<Vec<u8>, String> {
    let family = base.family.clone().unwrap_or_else(|| crate::layout::LayoutOptions::default().font_family);
    let size_hp = base.size_hp.unwrap_or((crate::layout::LayoutOptions::default().font_size_pt * 2.0) as u16);
    let family = xml_escape(&family);
    let defaults = format!(
        "<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii=\"{family}\" w:hAnsi=\"{family}\" \
         w:eastAsia=\"{family}\" w:cs=\"{family}\"/><w:sz w:val=\"{size_hp}\"/><w:szCs w:val=\"{size_hp}\"/>\
         </w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:before=\"0\" w:after=\"0\" w:line=\"240\" \
         w:lineRule=\"auto\"/></w:pPr></w:pPrDefault></w:docDefaults>"
    );
    let headings: String = (1u8..=6)
        .map(|n| {
            // The document's own heading look if it has one, else Letters'.
            let rpr = match heading_styles.get(usize::from(n) - 1) {
                Some(h) => {
                    let mut r = String::new();
                    if let Some(f) = &h.font_family {
                        let f = xml_escape(f);
                        r.push_str(&format!("<w:rFonts w:ascii=\"{f}\" w:hAnsi=\"{f}\" w:cs=\"{f}\"/>"));
                    }
                    if h.bold {
                        r.push_str("<w:b/><w:bCs/>");
                    }
                    if h.italic {
                        r.push_str("<w:i/><w:iCs/>");
                    }
                    if let Some(c) = &h.color {
                        r.push_str(&format!("<w:color w:val=\"{}\"/>", xml_escape(c)));
                    }
                    let hp = h.font_size_hp.map_or(u32::from(size_hp), u32::from);
                    r.push_str(&format!("<w:sz w:val=\"{hp}\"/><w:szCs w:val=\"{hp}\"/>"));
                    r
                }
                None => {
                    let hp = (f64::from(size_hp) * crate::layout::heading_scale(n)).round() as u32;
                    format!("<w:b/><w:bCs/><w:sz w:val=\"{hp}\"/><w:szCs w:val=\"{hp}\"/>")
                }
            };
            format!(
                "<w:style w:type=\"paragraph\" w:styleId=\"Heading{n}\"><w:name w:val=\"heading {n}\"/>\
                 <w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/><w:qFormat/><w:pPr><w:keepNext/>\
                 <w:outlineLvl w:val=\"{lvl}\"/></w:pPr><w:rPr>{rpr}</w:rPr></w:style>",
                lvl = n - 1
            )
        })
        .collect();

    let mut zin = zip::ZipArchive::new(std::io::Cursor::new(package)).map_err(|e| e.to_string())?;
    let mut out = zip::ZipWriter::new(std::io::Cursor::new(Vec::new()));
    let options = zip::write::SimpleFileOptions::default().compression_method(zip::CompressionMethod::Deflated);
    for i in 0..zin.len() {
        let mut f = zin.by_index(i).map_err(|e| e.to_string())?;
        let name = f.name().to_string();
        let mut data = Vec::new();
        std::io::Read::read_to_end(&mut f, &mut data).map_err(|e| e.to_string())?;
        if name == "word/styles.xml" {
            let xml = String::from_utf8(data).map_err(|e| e.to_string())?;
            data = patch_styles_xml(&xml, &defaults, &headings).into_bytes();
        } else if name.starts_with("word/theme/") && name.ends_with(".xml") {
            let xml = String::from_utf8(data).map_err(|e| e.to_string())?;
            data = patch_theme_fonts(&xml, &family).into_bytes();
        }
        out.start_file(name, options).map_err(|e| e.to_string())?;
        std::io::Write::write_all(&mut out, &data).map_err(|e| e.to_string())?;
    }
    Ok(out.finish().map_err(|e| e.to_string())?.into_inner())
}

/// Name `family` as the theme's heading and body fonts (`a:majorFont` and
/// `a:minorFont`'s Latin typeface). rdocx 0.14 writes Office's default
/// theme, whose fonts are Aptos Display and Aptos: the text still renders
/// in `family` (docDefaults names it outright), but Word offers the theme's
/// fonts as the document's "(Headings)" and "(Body)" fonts, and anything
/// that resolves a theme font would get Aptos, usually not installed.
pub(crate) fn patch_theme_fonts(xml: &str, family: &str) -> String {
    let mut xml = xml.to_string();
    for scheme in ["<a:majorFont>", "<a:minorFont>"] {
        let Some(at) = xml.find(scheme) else { continue };
        let Some(latin) = xml[at..].find("<a:latin ").map(|l| at + l) else { continue };
        let Some(end) = xml[latin..].find("/>").map(|e| latin + e + 2) else { continue };
        xml.replace_range(latin..end, &format!("<a:latin typeface=\"{family}\"/>"));
    }
    xml
}

/// Replace `styles.xml`'s docDefaults and its Heading1–6 styles.
pub(crate) fn patch_styles_xml(xml: &str, defaults: &str, headings: &str) -> String {
    let mut xml = xml.to_string();
    if let (Some(a), Some(b)) = (xml.find("<w:docDefaults"), xml.find("</w:docDefaults>")) {
        xml.replace_range(a..b + "</w:docDefaults>".len(), defaults);
    } else if let Some(at) = xml.find("<w:style ") {
        xml.insert_str(at, defaults);
    }
    for n in 1..=6 {
        let id = format!("w:styleId=\"Heading{n}\"");
        while let Some(at) = xml.find(&id) {
            let Some(start) = xml[..at].rfind("<w:style ") else { break };
            let Some(len) = xml[start..].find("</w:style>") else { break };
            xml.replace_range(start..start + len + "</w:style>".len(), "");
        }
    }
    if let Some(end) = xml.rfind("</w:styles>") {
        xml.insert_str(end, headings);
    }
    // The quote, code block and inline code styles paragraphs and runs
    // name, which the template lacks (#1205). A style a paragraph names
    // but the file doesn't define is dropped by LibreOffice, so a block
    // quote and inline code read back as plain text after a pass through
    // Writer. The names are the ones Writer itself uses for these.
    for (id, def) in [
        ("Quote", "<w:style w:type=\"paragraph\" w:styleId=\"Quote\"><w:name w:val=\"Quote\"/><w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/><w:qFormat/><w:pPr><w:ind w:left=\"720\" w:right=\"720\"/></w:pPr><w:rPr><w:i/></w:rPr></w:style>"),
        ("PreformattedText", "<w:style w:type=\"paragraph\" w:styleId=\"PreformattedText\"><w:name w:val=\"Preformatted Text\"/><w:basedOn w:val=\"Normal\"/><w:qFormat/><w:pPr><w:spacing w:before=\"0\" w:after=\"0\"/></w:pPr><w:rPr><w:rFonts w:ascii=\"Liberation Mono\" w:hAnsi=\"Liberation Mono\" w:cs=\"Liberation Mono\"/><w:sz w:val=\"20\"/></w:rPr></w:style>"),
        ("Caption", "<w:style w:type=\"paragraph\" w:styleId=\"Caption\"><w:name w:val=\"caption\"/><w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/><w:qFormat/><w:pPr><w:jc w:val=\"center\"/></w:pPr><w:rPr><w:i w:val=\"0\"/><w:sz w:val=\"22\"/></w:rPr></w:style>"),
        ("SourceText", "<w:style w:type=\"character\" w:styleId=\"SourceText\"><w:name w:val=\"Source Text\"/><w:qFormat/><w:rPr><w:rFonts w:ascii=\"Liberation Mono\" w:hAnsi=\"Liberation Mono\" w:cs=\"Liberation Mono\"/></w:rPr></w:style>"),
    ] {
        if !xml.contains(&format!("w:styleId=\"{id}\"")) {
            if let Some(end) = xml.rfind("</w:styles>") {
                xml.insert_str(end, def);
            }
        }
    }
    // Word's table of contents entry styles, which the template lacks; a
    // table of contents' entries name them (their indents are direct).
    if !xml.contains("w:styleId=\"TOC1\"") {
        let toc: String = (1..=9)
            .map(|n| format!("<w:style w:type=\"paragraph\" w:styleId=\"TOC{n}\"><w:name w:val=\"toc {n}\"/><w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/><w:uiPriority w:val=\"39\"/><w:unhideWhenUsed/></w:style>"))
            .collect();
        if let Some(end) = xml.rfind("</w:styles>") {
            xml.insert_str(end, &toc);
        }
    }
    xml
}

/// Write a DOCX and append previously captured, non-conflicting package parts.
pub fn write_with_opaque(
    doc: &Document,
    path: impl AsRef<std::path::Path>,
    opaque: &suite_common_core::interop::OpaquePackage,
) -> Result<(), String> {
    let path = path.as_ref();
    write(doc, path)?;
    opaque.append_to(path)
}

/// Samizdat : les couleurs de surlignage de Word (`w:highlight`) et leur
/// équivalent RRGGBB. Une couleur hors de cette liste s'écrit en trame
/// (`w:shd`), que Word et LibreOffice affichent aussi en fond de texte.
pub(crate) const WORD_HIGHLIGHTS: [(&str, &str); 6] = [
    ("yellow", "FFFF00"),
    ("green", "00FF00"),
    ("cyan", "00FFFF"),
    ("magenta", "FF00FF"),
    ("red", "FF0000"),
    ("blue", "0000FF"),
];

pub(crate) fn write_highlight<'a>(mut r: rdocx::Run<'a>, color: Option<&str>) -> rdocx::Run<'a> {
    let hex = color.unwrap_or("FFFF00").trim_start_matches('#').to_uppercase();
    match WORD_HIGHLIGHTS.iter().find(|(_, h)| *h == hex) {
        Some((name, _)) => {
            r.set_highlight_value(Some(name));
            r
        }
        None => r.highlight(&hex),
    }
}

/// Samizdat : trame et bordure d'un paragraphe à l'écriture.
pub(crate) fn write_para_box<'a>(mut p: rdocx::Paragraph<'a>, style: &ParaStyle) -> rdocx::Paragraph<'a> {
    if let Some([r, g, b]) = style.shading {
        p = p.shading(&format!("{r:02X}{g:02X}{b:02X}"));
    }
    if let Some(bd) = style.border {
        let color = format!("{:02X}{:02X}{:02X}", bd.color[0], bd.color[1], bd.color[2]);
        let w = u32::from(bd.width.max(2));
        p = if bd.sides == crate::model::ParaBorder::BOTTOM {
            p.border_bottom(rdocx::BorderStyle::Single, w, &color)
        } else {
            p.border_all(rdocx::BorderStyle::Single, w, &color)
        };
    }
    p
}
