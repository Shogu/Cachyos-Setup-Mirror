// docx_keep.rs — ce que Dactylo ne sait pas éditer, gardé tel quel.
//
// Équations, graphiques, SmartArt, objets incorporés : à l'ouverture, chacun
// est retiré du XML et remplacé dans le texte par une étiquette visible
// (« ⟦équation 1⟧ »). Son XML d'origine, ses relations et les fichiers
// qu'elles désignent (le classeur d'un graphique, ses styles…) sont gardés
// dans le document. À l'enregistrement en .docx, chaque étiquette encore
// présente redevient l'objet d'origine ; une étiquette effacée supprime
// l'objet. Les fichiers gardés sont rangés sous word/kept/N/ en conservant
// leur arborescence, pour que leurs propres liens relatifs restent justes.
// SPDX-License-Identifier: GPL-3.0-or-later

use crate::model::{KeptPart, Keepsake};
use std::io::Read;

fn attr<'a>(tag: &'a str, name: &str) -> Option<&'a str> {
    let pat = format!(" {name}=\"");
    let i = tag.find(&pat)? + pat.len();
    tag[i..].split('"').next()
}

/// The end of the element opened at `start` (just past its closing tag),
/// nested elements of the same name counted.
pub(crate) fn element_end(xml: &str, start: usize, name: &str) -> Option<usize> {
    let open_a = format!("<{name}>");
    let open_b = format!("<{name} ");
    let close = format!("</{name}>");
    let first_gt = start + xml[start..].find('>')?;
    if xml[..first_gt].ends_with('/') {
        return Some(first_gt + 1);
    }
    let mut depth = 1;
    let mut i = first_gt + 1;
    loop {
        let c = i + xml[i..].find(&close)?;
        let mut j = i;
        while let Some(o) = [xml[j..c].find(&open_a), xml[j..c].find(&open_b)].into_iter().flatten().min() {
            let o = j + o;
            let gt = o + xml[o..].find('>')?;
            if !xml[..gt].ends_with('/') {
                depth += 1;
            }
            j = gt + 1;
        }
        depth -= 1;
        i = c + close.len();
        if depth == 0 {
            return Some(i);
        }
    }
}

/// The run (`w:r`) around position `at`.
fn run_around(xml: &str, at: usize) -> Option<(usize, usize)> {
    let s = [xml[..at].rfind("<w:r>"), xml[..at].rfind("<w:r ")].into_iter().flatten().max()?;
    let e = element_end(xml, s, "w:r")?;
    (e > at).then_some((s, e))
}

/// What one piece is, from its markup.
fn kind(piece: &str) -> &'static str {
    if piece.starts_with("<m:") {
        "équation"
    } else if piece.contains("/chart\"") || piece.contains("<c:chart") {
        "graphique"
    } else if piece.contains("dgm:relIds") {
        "SmartArt"
    } else if piece.contains("<w:object") {
        "objet"
    } else {
        "dessin"
    }
}

/// The pieces to keep: (start, end) in `xml`, outermost only, in order.
fn pieces(xml: &str) -> Vec<(usize, usize)> {
    let mut out: Vec<(usize, usize)> = Vec::new();
    let push = |s: usize, e: usize, out: &mut Vec<(usize, usize)>| {
        if !out.iter().any(|&(a, b)| a <= s && e <= b) {
            out.retain(|&(a, b)| !(s <= a && b <= e));
            out.push((s, e));
        }
    };
    // Équations : un paragraphe d'équation, ou une équation dans le texte.
    for name in ["m:oMathPara", "m:oMath"] {
        let mut i = 0;
        while let Some(k) = [xml[i..].find(&format!("<{name}>")), xml[i..].find(&format!("<{name} "))].into_iter().flatten().min() {
            let s = i + k;
            let Some(e) = element_end(xml, s, name) else { break };
            push(s, e, &mut out);
            i = e;
        }
    }
    // Objets incorporés, graphiques, SmartArt, zones de dessin : le run entier.
    for needle in ["<w:object", "<c:chart ", "dgm:relIds", "<wpc:wpc", "<lc:lockedCanvas"] {
        let mut i = 0;
        while let Some(k) = xml[i..].find(needle) {
            let at = i + k;
            i = at + needle.len();
            if let Some((s, e)) = run_around(xml, at) {
                push(s, e, &mut out);
                i = e;
            }
        }
    }
    out.sort_unstable();
    out
}

/// Relationship ids referenced by a piece of markup.
fn rel_ids(piece: &str) -> Vec<String> {
    let mut ids = Vec::new();
    for a in ["r:id", "r:embed", "r:link", "r:dm", "r:lo", "r:qs", "r:cs", "r:pict"] {
        let pat = format!(" {a}=\"");
        let mut i = 0;
        while let Some(k) = piece[i..].find(&pat) {
            let s = i + k + pat.len();
            if let Some(v) = piece[s..].split('"').next() {
                if !v.is_empty() && !ids.iter().any(|x| x == v) {
                    ids.push(v.to_string());
                }
            }
            i = s;
        }
    }
    ids
}

/// The relationships of a rels part: (id, type, target, external).
fn relationships(rels: &str) -> Vec<(String, String, String, bool)> {
    let mut out = Vec::new();
    let mut i = 0;
    while let Some(k) = rels[i..].find("<Relationship ") {
        let s = i + k;
        let e = s + rels[s..].find('>').unwrap_or(0);
        let tag = &rels[s..e];
        if let (Some(id), Some(ty), Some(target)) = (attr(tag, "Id"), attr(tag, "Type"), attr(tag, "Target")) {
            out.push((id.to_string(), ty.to_string(), target.to_string(), attr(tag, "TargetMode") == Some("External")));
        }
        i = e;
    }
    out
}

/// `target` (relative to the part `from`) as a package path.
fn resolve(from: &str, target: &str) -> String {
    if let Some(abs) = target.strip_prefix('/') {
        return abs.to_string();
    }
    let mut parts: Vec<&str> = from.split('/').collect();
    parts.pop();
    for seg in target.split('/') {
        match seg {
            ".." => {
                parts.pop();
            }
            "." | "" => {}
            s => parts.push(s),
        }
    }
    parts.join("/")
}

fn rels_of(part: &str) -> String {
    match part.rsplit_once('/') {
        Some((dir, name)) => format!("{dir}/_rels/{name}.rels"),
        None => format!("_rels/{part}.rels"),
    }
}

/// The content type of a package part, from [Content_Types].xml.
fn content_type(types: &str, part: &str) -> String {
    let over = format!("PartName=\"/{part}\"");
    if let Some(k) = types.find(&over) {
        let s = types[..k].rfind('<').unwrap_or(0);
        let e = k + types[k..].find('>').unwrap_or(0);
        if let Some(ct) = attr(&types[s..e], "ContentType") {
            return ct.to_string();
        }
    }
    let ext = part.rsplit('.').next().unwrap_or("").to_ascii_lowercase();
    let mut i = 0;
    while let Some(k) = types[i..].find("<Default ") {
        let s = i + k;
        let e = s + types[s..].find('>').unwrap_or(0);
        let tag = &types[s..e];
        if attr(tag, "Extension").is_some_and(|x| x.eq_ignore_ascii_case(&ext)) {
            return attr(tag, "ContentType").unwrap_or("application/octet-stream").to_string();
        }
        i = e;
    }
    "application/octet-stream".to_string()
}

/// Takes the pieces out of `xml` (word/document.xml of the package
/// `package`), leaving a labelled run in each place.
pub fn extract(xml: &str, package: &[u8]) -> Option<(String, Vec<Keepsake>)> {
    let found = pieces(xml);
    if found.is_empty() {
        return None;
    }
    let mut zip = zip::ZipArchive::new(std::io::Cursor::new(package)).ok()?;
    let mut text = |name: &str| -> String {
        let mut s = String::new();
        if let Ok(mut f) = zip.by_name(name) {
            let _ = f.read_to_string(&mut s);
        }
        s
    };
    let doc_rels = relationships(&text("word/_rels/document.xml.rels"));
    let types = text("[Content_Types].xml");
    drop(text);
    let mut bytes_of = |name: &str| -> Option<Vec<u8>> {
        let mut f = zip.by_name(name).ok()?;
        let mut v = Vec::new();
        f.read_to_end(&mut v).ok()?;
        Some(v)
    };

    let mut out = String::with_capacity(xml.len());
    let mut kept = Vec::new();
    let mut counts: std::collections::HashMap<&str, usize> = Default::default();
    let mut last = 0;
    for (s, e) in found {
        let piece = &xml[s..e];
        let k = kind(piece);
        let n = counts.entry(k).or_insert(0);
        *n += 1;
        let label = format!("⟦{k} {n}⟧");
        // Ses relations, et les fichiers qu'elles désignent (avec les
        // leurs, de proche en proche).
        let mut rels = Vec::new();
        let mut parts: Vec<KeptPart> = Vec::new();
        let mut todo: Vec<String> = Vec::new();
        for id in rel_ids(piece) {
            if let Some((_, ty, target, external)) = doc_rels.iter().find(|r| r.0 == id) {
                rels.push((id.clone(), ty.clone(), target.clone(), *external));
                if !external {
                    todo.push(resolve("word/document.xml", target));
                }
            }
        }
        while let Some(part) = todo.pop() {
            if parts.iter().any(|p| p.path == part) || parts.len() > 64 {
                continue;
            }
            let Some(data) = bytes_of(&part) else { continue };
            parts.push(KeptPart { path: part.clone(), content_type: content_type(&types, &part), data });
            let rp = rels_of(&part);
            if let Some(data) = bytes_of(&rp) {
                for (_, _, target, external) in relationships(&String::from_utf8_lossy(&data)) {
                    if !external {
                        todo.push(resolve(&part, &target));
                    }
                }
                parts.push(KeptPart { path: rp, content_type: String::new(), data });
            }
        }
        // L'étiquette prend la mise en forme du texte autour, si c'est un run.
        let rpr = piece
            .starts_with("<w:r")
            .then(|| piece.find("<w:rPr>").and_then(|a| piece[a..].find("</w:rPr>").map(|b| &piece[a..a + b + 8])))
            .flatten()
            .unwrap_or("");
        out.push_str(&xml[last..s]);
        // Un paragraphe d'équation tient seul dans son paragraphe : un run
        // suffit (il est déjà dans un w:p).
        out.push_str(&format!("<w:r>{rpr}<w:t>{label}</w:t></w:r>"));
        last = e;
        kept.push(Keepsake { label, xml: piece.to_string(), rels, parts });
    }
    out.push_str(&xml[last..]);
    Some((out, kept))
}

/// Puts the kept pieces back into a package written by Dactylo.
pub fn restore(package: &[u8], kept: &[Keepsake]) -> Result<Vec<u8>, String> {
    let mut zin = zip::ZipArchive::new(std::io::Cursor::new(package)).map_err(|e| e.to_string())?;
    let mut files: Vec<(String, Vec<u8>)> = Vec::new();
    for i in 0..zin.len() {
        let mut f = zin.by_index(i).map_err(|e| e.to_string())?;
        let mut v = Vec::new();
        f.read_to_end(&mut v).map_err(|e| e.to_string())?;
        files.push((f.name().to_string(), v));
    }
    let take = |files: &Vec<(String, Vec<u8>)>, name: &str| files.iter().find(|f| f.0 == name).map(|f| String::from_utf8_lossy(&f.1).into_owned());
    let mut document = take(&files, "word/document.xml").ok_or("no document.xml")?;
    let mut rels = take(&files, "word/_rels/document.xml.rels").unwrap_or_else(|| {
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"></Relationships>".into()
    });
    let mut types = take(&files, "[Content_Types].xml").unwrap_or_default();
    let mut added: Vec<(String, Vec<u8>)> = Vec::new();
    let mut new_rels = String::new();
    for (n, k) in kept.iter().enumerate() {
        if !document.contains(&k.label) {
            continue; // effacé par l'utilisateur
        }
        let base = format!("word/kept/{n}/");
        let moved = |path: &str| match path.strip_prefix("word/") {
            Some(rest) => format!("{base}{rest}"),
            None => format!("{base}{path}"),
        };
        let mut piece = k.xml.clone();
        for (i, (id, ty, target, external)) in k.rels.iter().enumerate() {
            let new_id = format!("rIdKeep{n}x{i}");
            for a in ["r:id", "r:embed", "r:link", "r:dm", "r:lo", "r:qs", "r:cs", "r:pict"] {
                piece = piece.replace(&format!(" {a}=\"{id}\""), &format!(" {a}=\"{new_id}\""));
            }
            let (target, mode) = if *external {
                (target.clone(), " TargetMode=\"External\"")
            } else {
                let full = resolve("word/document.xml", target);
                (moved(&full).trim_start_matches("word/").to_string(), "")
            };
            new_rels.push_str(&format!("<Relationship Id=\"{new_id}\" Type=\"{ty}\" Target=\"{}\"{mode}/>", xml_escape(&target)));
        }
        for p in &k.parts {
            let path = moved(&p.path);
            if !p.content_type.is_empty() && !types.contains(&format!("PartName=\"/{path}\"")) {
                let over = format!("<Override PartName=\"/{path}\" ContentType=\"{}\"/>", p.content_type);
                types = types.replacen("</Types>", &format!("{over}</Types>"), 1);
            }
            added.push((path, p.data.clone()));
        }
        // L'étiquette, où qu'elle soit dans un w:t : on coupe le run.
        let label = &k.label;
        let mut out = String::with_capacity(document.len() + piece.len());
        let mut rest = document.as_str();
        while let Some(at) = rest.find(label.as_str()) {
            let run_start = [rest[..at].rfind("<w:r>"), rest[..at].rfind("<w:r ")].into_iter().flatten().max();
            let rpr = run_start
                .and_then(|r| rest[r..at].find("<w:rPr>").map(|a| r + a))
                .and_then(|a| rest[a..at].find("</w:rPr>").map(|b| &rest[a..a + b + 8]))
                .unwrap_or("");
            out.push_str(&rest[..at]);
            if piece.starts_with("<w:r") {
                out.push_str(&format!("</w:t></w:r>{piece}<w:r>{rpr}<w:t xml:space=\"preserve\">"));
            } else {
                // Une équation se place entre deux runs.
                out.push_str(&format!("</w:t></w:r>{piece}<w:r>{rpr}<w:t xml:space=\"preserve\">"));
            }
            rest = &rest[at + label.len()..];
        }
        out.push_str(rest);
        document = out.replace("<w:t></w:t>", "").replace("<w:t xml:space=\"preserve\"></w:t>", "");
    }
    rels = rels.replacen("</Relationships>", &format!("{new_rels}</Relationships>"), 1);
    // Les types de fichier courants que les fichiers gardés utilisent.
    for (path, _) in &added {
        let ext = path.rsplit('.').next().unwrap_or("").to_ascii_lowercase();
        if ext == "rels" || types.contains(&format!("Extension=\"{ext}\"")) || types.contains(&format!("PartName=\"/{path}\"")) {
            continue;
        }
        let ct = match ext.as_str() {
            "png" => "image/png",
            "jpeg" | "jpg" => "image/jpeg",
            "emf" => "image/x-emf",
            "wmf" => "image/x-wmf",
            "bin" => "application/vnd.openxmlformats-officedocument.oleObject",
            "xlsx" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            _ => "application/octet-stream",
        };
        types = types.replacen("</Types>", &format!("<Default Extension=\"{ext}\" ContentType=\"{ct}\"/></Types>"), 1);
    }
    // Les espaces de noms des pièces gardées (m:, c:, dgm:, wpc:…) : ceux
    // du document d'origine sont ajoutés à la racine s'ils manquent.
    document = with_namespaces(&document, kept);
    let mut out = zip::ZipWriter::new(std::io::Cursor::new(Vec::new()));
    let options = zip::write::SimpleFileOptions::default().compression_method(zip::CompressionMethod::Deflated);
    let mut write = |name: &str, data: &[u8]| -> Result<(), String> {
        out.start_file(name, options).map_err(|e| e.to_string())?;
        std::io::Write::write_all(&mut out, data).map_err(|e| e.to_string())
    };
    for (name, data) in &files {
        match name.as_str() {
            "word/document.xml" => write(name, document.as_bytes())?,
            "word/_rels/document.xml.rels" => write(name, rels.as_bytes())?,
            "[Content_Types].xml" => write(name, types.as_bytes())?,
            _ => write(name, data)?,
        }
    }
    if !files.iter().any(|f| f.0 == "word/_rels/document.xml.rels") {
        write("word/_rels/document.xml.rels", rels.as_bytes())?;
    }
    for (name, data) in &added {
        if !files.iter().any(|f| &f.0 == name) {
            write(name, data)?;
        }
    }
    Ok(out.finish().map_err(|e| e.to_string())?.into_inner())
}

fn xml_escape(s: &str) -> String {
    s.replace('&', "&amp;").replace('"', "&quot;").replace('<', "&lt;")
}

/// The namespace declarations the kept pieces need, added to the root of
/// document.xml.
fn with_namespaces(document: &str, kept: &[Keepsake]) -> String {
    const KNOWN: [(&str, &str); 12] = [
        ("m", "http://schemas.openxmlformats.org/officeDocument/2006/math"),
        ("c", "http://schemas.openxmlformats.org/drawingml/2006/chart"),
        ("dgm", "http://schemas.openxmlformats.org/drawingml/2006/diagram"),
        ("wpc", "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"),
        ("lc", "http://schemas.openxmlformats.org/drawingml/2006/lockedCanvas"),
        ("o", "urn:schemas-microsoft-com:office:office"),
        ("v", "urn:schemas-microsoft-com:vml"),
        ("w10", "urn:schemas-microsoft-com:office:word"),
        ("wp", "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"),
        ("a", "http://schemas.openxmlformats.org/drawingml/2006/main"),
        ("pic", "http://schemas.openxmlformats.org/drawingml/2006/picture"),
        ("r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships"),
    ];
    let Some(root) = document.find("<w:document") else { return document.to_string() };
    let Some(end) = document[root..].find('>').map(|e| root + e) else { return document.to_string() };
    let mut decl = String::new();
    for (prefix, uri) in KNOWN {
        let used = kept.iter().any(|k| k.xml.contains(&format!("<{prefix}:")) || k.xml.contains(&format!(" {prefix}:")));
        if used && !document[root..end].contains(&format!("xmlns:{prefix}=")) {
            decl.push_str(&format!(" xmlns:{prefix}=\"{uri}\""));
        }
    }
    format!("{}{decl}{}", &document[..end], &document[end..])
}

#[cfg(test)]
mod tests {
    #[test]
    fn equation_is_labelled_then_restored() {
        let xml = r#"<w:document><w:body><w:p><w:r><w:t>Soit </w:t></w:r><m:oMath><m:r><m:t>x+1</m:t></m:r></m:oMath><w:r><w:t> fin</w:t></w:r></w:p></w:body></w:document>"#;
        let mut z = zip::ZipWriter::new(std::io::Cursor::new(Vec::new()));
        z.start_file("word/document.xml", zip::write::SimpleFileOptions::default()).unwrap();
        std::io::Write::write_all(&mut z, xml.as_bytes()).unwrap();
        z.start_file("[Content_Types].xml", zip::write::SimpleFileOptions::default()).unwrap();
        std::io::Write::write_all(&mut z, b"<Types></Types>").unwrap();
        let pkg = z.finish().unwrap().into_inner();
        let (patched, kept) = super::extract(xml, &pkg).unwrap();
        assert!(patched.contains("⟦équation 1⟧") && !patched.contains("m:oMath"), "{patched}");
        // Dactylo's own output, with the label inside some text.
        let mut z = zip::ZipWriter::new(std::io::Cursor::new(Vec::new()));
        z.start_file("word/document.xml", zip::write::SimpleFileOptions::default()).unwrap();
        std::io::Write::write_all(&mut z, "<w:document><w:body><w:p><w:r><w:t xml:space=\"preserve\">Soit ⟦équation 1⟧ fin</w:t></w:r></w:p></w:body></w:document>".as_bytes()).unwrap();
        z.start_file("[Content_Types].xml", zip::write::SimpleFileOptions::default()).unwrap();
        std::io::Write::write_all(&mut z, b"<Types></Types>").unwrap();
        let out = super::restore(&z.finish().unwrap().into_inner(), &kept).unwrap();
        let mut a = zip::ZipArchive::new(std::io::Cursor::new(out)).unwrap();
        let mut d = String::new();
        std::io::Read::read_to_string(&mut a.by_name("word/document.xml").unwrap(), &mut d).unwrap();
        assert!(d.contains("<m:oMath><m:r><m:t>x+1</m:t></m:r></m:oMath>") && !d.contains('⟦'), "{d}");
        assert!(d.contains("xmlns:m="), "{d}");
    }
}
