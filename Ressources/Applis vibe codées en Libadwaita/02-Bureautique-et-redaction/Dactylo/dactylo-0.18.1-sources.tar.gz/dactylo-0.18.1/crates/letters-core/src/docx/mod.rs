// docx.rs — Document ⇄ DOCX via rdocx.
// SPDX-License-Identifier: GPL-3.0-or-later
//
// Model-level DOCX I/O: paragraphs, styled runs (incl. highlight and inline
// code via SourceText), headings, alignment, lists, hyperlinks. Tables are
// flattened (see read()). Fidelity is measured by tests/docx.rs and the
// LO-authored corpus in tests/lo_parity.rs.

#[allow(unused_imports)]
use crate::model::{Alignment, Document, ListKind, PageGeometry, Paragraph, ParaStyle, Run, RunStyle};
#[allow(unused_imports)]
use rdocx_oxml::shared::ST_Jc;

mod brut;
mod ecriture;
mod lecture;
mod images;
#[allow(unused_imports)]
pub use self::brut::*;
#[allow(unused_imports)]
pub use self::ecriture::*;
#[allow(unused_imports)]
pub use self::lecture::*;
#[allow(unused_imports)]
pub use self::images::*;

/// Read a .docx file into a Document.
/// How deeply a docx's XML may nest before it is refused unread. rdocx
/// parses a table inside a cell by recursing, at about 100 KB of stack a
/// level in a debug build, and an overflow aborts the app rather than
/// failing the read: 25 nested tables were enough on a 2 MiB thread
/// (#1206). Real documents nest a few dozen elements deep.
pub const MAX_XML_DEPTH: usize = 256;

/// The stack a docx is read on: room for [`MAX_XML_DEPTH`] levels of the
/// deepest recursion with a wide margin. Only the pages used are committed.
const READ_STACK_BYTES: usize = 64 << 20;

/// Read a docx: refused when it nests past [`MAX_XML_DEPTH`], otherwise
/// read on a thread with [`READ_STACK_BYTES`] of stack, whatever thread
/// asked. A panic in the reader reaches the caller as before.
pub fn read(path: &str) -> Result<Document, String> {
    suite_common_core::zip_guard::check_xml_depth(std::path::Path::new(path), MAX_XML_DEPTH)
        .map_err(|e| format!("Cannot open .docx {path}: {e}"))?;
    let owned = path.to_string();
    let reader = std::thread::Builder::new()
        .name("docx-read".into())
        .stack_size(READ_STACK_BYTES)
        .spawn(move || read_on_this_thread(&owned))
        .map_err(|e| format!("Cannot open .docx {path}: {e}"))?;
    reader.join().unwrap_or_else(|panic| std::panic::resume_unwind(panic))
}

fn read_on_this_thread(path: &str) -> Result<Document, String> {
    // Smart chips are content controls rdocx does not read runs from:
    // they become sentinel runs first (docx_chips).
    KEPT.with(|k| k.borrow_mut().clear());
    PATCHED.with(|p| *p.borrow_mut() = None);
    let (doc, (chips, revisions)) = open_with_chips(path).map_err(|e| format!("Cannot open .docx {}: {}", path, e))?;
    let comments = crate::docx_comments::bodies(&doc);
    let mut read = read_opened(path, doc)?;
    // Tracked changes first: a bracket may hold a chip's sentinel.
    crate::docx_revisions::restore(&mut read, &revisions);
    crate::docx_chips::restore(&mut read, &chips);
    // Comments last: their markers may sit in a tracked change.
    if !comments.is_empty() {
        crate::docx_comments::restore(&mut read, comments);
    }
    crate::docx_toc::restore(&mut read);
    read.kept = KEPT.with(|k| std::mem::take(&mut *k.borrow_mut()));
    // Images recadrées dans Word : on découpe l'image elle-même.
    #[cfg(feature = "render")]
    apply_crops(path, &mut read);
    // Formes dessinées (croquis) : redessinées en une image.
    #[cfg(feature = "render")]
    insert_shapes_picture(path, &mut read);
    // Page-number fields in the header and footer, as "{page}"/"{total}".
    let (header, footer) = header_footer_templates(path);
    if header.is_some() {
        read.header = header;
    }
    if footer.is_some() {
        read.footer = footer;
    }
    Ok(read)
}

/// A zip part's text, if it is there.
fn part_text(zip: &mut zip::ZipArchive<impl std::io::Read + std::io::Seek>, name: &str) -> Option<String> {
    let mut s = String::new();
    std::io::Read::read_to_string(&mut zip.by_name(name).ok()?, &mut s).ok()?;
    Some(s)
}

/// The default header and footer as templates with their PAGE/NUMPAGES
/// fields ("{page}", "{total}"); `None` for a part without such fields.
fn header_footer_templates(path: &str) -> (Option<String>, Option<String>) {
    let Some(mut zip) = std::fs::File::open(path).ok().and_then(|f| zip::ZipArchive::new(f).ok()) else { return (None, None) };
    let (Some(document), Some(rels)) = (part_text(&mut zip, "word/document.xml"), part_text(&mut zip, "word/_rels/document.xml.rels")) else {
        return (None, None);
    };
    let (h, f) = crate::docx_fields::default_parts(&document, &rels);
    let mut template = |part: Option<String>| part.and_then(|p| part_text(&mut zip, &p)).and_then(|xml| crate::docx_fields::template(&xml));
    (template(h), template(f))
}

/// The package at `path`, with its chip controls as sentinel runs.
/// What `open_with_chips` took out of the markup for rdocx: the smart
/// chips and the tracked changes, restored after reading.
type Unwrapped = (Vec<(crate::chips::Chip, String)>, Vec<crate::model::Revision>);

fn open_with_chips(path: &str) -> Result<(rdocx::Document, Unwrapped), String> {
    let bytes = std::fs::read(path).map_err(|e| e.to_string())?;
    let mut xml = String::new();
    let found = zip::ZipArchive::new(std::io::Cursor::new(&bytes))
        .ok()
        .and_then(|mut z| std::io::Read::read_to_string(&mut z.by_name("word/document.xml").ok()?, &mut xml).ok())
        .is_some();
    // Images enveloppées dans mc:AlternateContent, zones de texte : remises
    // dans le fil du document (docx_alt) avant toute autre lecture.
    let alt = if found { crate::docx_alt::unwrap(&xml) } else { None };
    if let Some(a) = &alt {
        xml = a.clone();
    }
    // Équations, graphiques, SmartArt, objets : gardés tels quels, une
    // étiquette à leur place (docx_keep).
    let kept = if found { crate::docx_keep::extract(&xml, &bytes) } else { None };
    let keeping = kept.is_some();
    if let Some((patched, pieces)) = kept {
        xml = patched;
        KEPT.with(|k| *k.borrow_mut() = pieces);
    }
    if !found || !(alt.is_some() || keeping || xml.contains("<w:sdt") || xml.contains("<w:ins ") || xml.contains("<w:del ") || xml.contains("<w:comment") || xml.contains("TOC \\")) {
        return Ok((rdocx::Document::open(path).map_err(|e| e.to_string())?, (Vec::new(), Vec::new())));
    }
    // A table of contents first: it lifts the paragraphs out of their
    // content control before chips look at controls.
    let toc = crate::docx_toc::unwrap(&xml);
    let (patched, chips) = crate::docx_chips::unwrap(toc.as_deref().unwrap_or(&xml));
    let (patched, revisions) = crate::docx_revisions::unwrap(&patched);
    let commented = crate::docx_comments::unwrap(&patched);
    let patched = commented.clone().unwrap_or(patched);
    if alt.is_none() && !keeping && chips.is_empty() && revisions.is_empty() && commented.is_none() && toc.is_none() {
        return Ok((rdocx::Document::open(path).map_err(|e| e.to_string())?, (Vec::new(), Vec::new())));
    }
    let bytes = with_part(&bytes, "word/document.xml", |_| patched.clone())?;
    // Samizdat : la relecture brute (place des tableaux, retraits…) doit
    // voir le même XML que rdocx, sinon une zone de texte devenue tableau
    // décale tout et les tableaux finissent en fin de document.
    PATCHED.with(|p| *p.borrow_mut() = Some(patched.clone()));
    Ok((rdocx::Document::from_bytes(&bytes).map_err(|e| e.to_string())?, (chips, revisions)))
}

fn with_part(package: &[u8], name: &str, f: impl Fn(&str) -> String) -> Result<Vec<u8>, String> {
    let mut zin = zip::ZipArchive::new(std::io::Cursor::new(package)).map_err(|e| e.to_string())?;
    let mut out = zip::ZipWriter::new(std::io::Cursor::new(Vec::new()));
    let options = zip::write::SimpleFileOptions::default().compression_method(zip::CompressionMethod::Deflated);
    for i in 0..zin.len() {
        let mut part = zin.by_index(i).map_err(|e| e.to_string())?;
        let part_name = part.name().to_string();
        let mut data = Vec::new();
        std::io::Read::read_to_end(&mut part, &mut data).map_err(|e| e.to_string())?;
        if part_name == name {
            let xml = String::from_utf8(data).map_err(|e| e.to_string())?;
            data = f(&xml).into_bytes();
        }
        out.start_file(part_name, options).map_err(|e| e.to_string())?;
        std::io::Write::write_all(&mut out, &data).map_err(|e| e.to_string())?;
    }
    Ok(out.finish().map_err(|e| e.to_string())?.into_inner())
}

/// Read a DOCX and retain package members this reader does not interpret.
/// The report is suitable for a structured save-warning UI; the opaque
/// package can be passed to [`write_with_opaque`] after an unrelated edit.
pub fn read_with_report(path: &str) -> Result<(Document, suite_common_core::interop::CompatibilityReport, suite_common_core::interop::OpaquePackage), String> {
    let document = read(path)?;
    let opaque = suite_common_core::interop::OpaquePackage::capture(
        path,
        &[
            "[Content_Types].xml",
            "_rels/.rels",
            "word/document.xml",
            "word/_rels/document.xml.rels",
            // Comments are read (docx_comments) and written anew.
            "word/comments.xml",
            "word/commentsExtended.xml",
            "word/commentsIds.xml",
            "word/commentsExtensible.xml",
        ],
    )?;
    let mut report = suite_common_core::interop::CompatibilityReport::new("docx");
    for name in opaque.part_names() {
        report.record(suite_common_core::interop::UnsupportedFeature::new(
            "uninterpreted-package-part", "Uninterpreted package part", name,
            suite_common_core::interop::FeatureDisposition::OpaquePassThrough,
            "will be copied through on an opaque save",
        ));
    }
    Ok((document, report, opaque))
}

thread_local! {
    /// Le document.xml que rdocx a lu, quand il a été retouché.
    static PATCHED: std::cell::RefCell<Option<String>> = const { std::cell::RefCell::new(None) };
    /// Ce que `open_with_chips` a gardé tel quel, repris par la lecture.
    static KEPT: std::cell::RefCell<Vec<crate::model::Keepsake>> = const { std::cell::RefCell::new(Vec::new()) };
}

fn xml_escape(s: &str) -> String {
    s.replace('&', "&amp;").replace('"', "&quot;").replace('<', "&lt;").replace('>', "&gt;")
}


#[cfg(test)]
mod tests;



/// Samizdat : « RRGGBB » en RVB (« auto » : aucune couleur).
fn hex_rgb(h: &str) -> Option<[u8; 3]> {
    let h = h.trim().trim_start_matches('#');
    if h.len() != 6 {
        return None;
    }
    let c = |i: usize| u8::from_str_radix(&h[i..i + 2], 16).ok();
    let rgb = [c(0)?, c(2)?, c(4)?];
    // Un fond blanc n'en est pas un.
    (rgb != [255, 255, 255]).then_some(rgb)
}

/// Un surlignage qui en est vraiment un.
fn real_highlight(h: Option<String>) -> Option<String> {
    h.filter(|v| !matches!(v.to_ascii_lowercase().as_str(), "none" | "auto" | "ffffff" | "white" | "clear" | ""))
}

/// Samizdat : « RRGGBB » en RVB, blanc compris (une couleur de trait).
fn hex_rgb_any(h: &str) -> Option<[u8; 3]> {
    let h = h.trim().trim_start_matches('#');
    if h.len() != 6 {
        return None;
    }
    let c = |i: usize| u8::from_str_radix(&h[i..i + 2], 16).ok();
    Some([c(0)?, c(2)?, c(4)?])
}
