// docx_compat.rs — un .docx que Microsoft Word accepte.
//
// Le fichier écrit par rdocx est valide au regard du schéma, mais Word est
// plus exigeant que le schéma et déclarait « corrompus » les documents de
// Dactylo. En cause d'abord : docProps/app.xml annonce <AppVersion>0.14.0
// (la version de rdocx), alors que Word n'accepte que la forme « XX.YYYY ».
// On durcit aussi le reste comme le fait Word lui-même : propriétés du
// document remplies, mode de compatibilité déclaré, polices utilisées
// déclarées, identifiants de relations classiques.
// SPDX-License-Identifier: GPL-3.0-or-later

use std::io::Read;

pub fn harden(package: &[u8]) -> Result<Vec<u8>, String> {
    let mut zin = zip::ZipArchive::new(std::io::Cursor::new(package)).map_err(|e| e.to_string())?;
    let mut parts: Vec<(String, Vec<u8>)> = Vec::with_capacity(zin.len());
    for i in 0..zin.len() {
        let mut f = zin.by_index(i).map_err(|e| e.to_string())?;
        if f.is_dir() {
            continue; // pas d'entrée de dossier
        }
        let mut v = Vec::new();
        f.read_to_end(&mut v).map_err(|e| e.to_string())?;
        parts.push((f.name().to_string(), v));
    }
    let text = |parts: &[(String, Vec<u8>)], n: &str| parts.iter().find(|p| p.0 == n).map(|p| String::from_utf8_lossy(&p.1).into_owned());
    let document = text(&parts, "word/document.xml").unwrap_or_default();
    // [Content_Types].xml en tête.
    if let Some(i) = parts.iter().position(|p| p.0 == "[Content_Types].xml") {
        let ct = parts.remove(i);
        parts.insert(0, ct);
    }
    for (name, data) in parts.iter_mut() {
        let Ok(xml) = std::str::from_utf8(data) else { continue };
        let fixed = match name.as_str() {
            "docProps/app.xml" => Some(app(xml)),
            "docProps/core.xml" => Some(core(xml)),
            "word/settings.xml" => Some(settings(xml)),
            "word/fontTable.xml" => Some(fonts(xml, &document)),
            "word/_rels/document.xml.rels" => Some(rel_ids(xml, &document)),
            _ => None,
        };
        if let Some(f) = fixed {
            *data = f.into_bytes();
        }
    }
    let mut out = zip::ZipWriter::new(std::io::Cursor::new(Vec::new()));
    let options = zip::write::SimpleFileOptions::default().compression_method(zip::CompressionMethod::Deflated);
    for (name, data) in &parts {
        out.start_file(name.as_str(), options).map_err(|e| e.to_string())?;
        std::io::Write::write_all(&mut out, data).map_err(|e| e.to_string())?;
    }
    Ok(out.finish().map_err(|e| e.to_string())?.into_inner())
}

/// Word refuse une version d'application qui n'est pas « XX.YYYY ».
fn app(xml: &str) -> String {
    let mut s = xml.to_string();
    if let (Some(a), Some(b)) = (s.find("<AppVersion>"), s.find("</AppVersion>")) {
        s.replace_range(a..b + "</AppVersion>".len(), "<AppVersion>16.0000</AppVersion>");
    }
    if let (Some(a), Some(b)) = (s.find("<Application>"), s.find("</Application>")) {
        s.replace_range(a..b + "</Application>".len(), "<Application>Dactylo</Application>");
    }
    s
}

fn core(xml: &str) -> String {
    if xml.contains("dcterms:created") {
        return xml.to_string();
    }
    let now = chrono::Utc::now().format("%Y-%m-%dT%H:%M:%SZ").to_string();
    let who = std::env::var("USER").ok().filter(|u| !u.is_empty() && u.chars().all(|c| c.is_alphanumeric() || "._-".contains(c))).unwrap_or_else(|| "Dactylo".into());
    let mut s = xml.to_string();
    let mut ns = String::new();
    for (p, uri) in [
        ("dc", "http://purl.org/dc/elements/1.1/"),
        ("dcterms", "http://purl.org/dc/terms/"),
        ("xsi", "http://www.w3.org/2001/XMLSchema-instance"),
    ] {
        if !s.contains(&format!("xmlns:{p}=")) {
            ns.push_str(&format!(" xmlns:{p}=\"{uri}\""));
        }
    }
    if let Some(root) = s.find("<cp:coreProperties") {
        if let Some(gt) = s[root..].find('>') {
            let gt = root + gt;
            if s[..gt].ends_with('/') {
                // <cp:coreProperties .../> : on l'ouvre.
                s.replace_range(gt - 1..gt + 1, &format!("{ns}></cp:coreProperties>"));
            } else {
                s.insert_str(gt, &ns);
            }
        }
    }
    let mut add = String::new();
    if !s.contains("<dc:creator") {
        add.push_str(&format!("<dc:creator>{who}</dc:creator>"));
    }
    if !s.contains("<cp:lastModifiedBy") {
        add.push_str(&format!("<cp:lastModifiedBy>{who}</cp:lastModifiedBy>"));
    }
    add.push_str(&format!("<dcterms:created xsi:type=\"dcterms:W3CDTF\">{now}</dcterms:created>"));
    if !s.contains("dcterms:modified") {
        add.push_str(&format!("<dcterms:modified xsi:type=\"dcterms:W3CDTF\">{now}</dcterms:modified>"));
    }
    s.replacen("</cp:coreProperties>", &format!("{add}</cp:coreProperties>"), 1)
}

/// Le mode de compatibilité de Word 2013 et suivants, à sa place dans la
/// séquence des réglages (avant docVars, rsids, mathPr…).
fn settings(xml: &str) -> String {
    if xml.contains("<w:compat>") || xml.contains("<w:compat ") {
        return xml.to_string();
    }
    let compat = "<w:compat><w:compatSetting w:name=\"compatibilityMode\" w:uri=\"http://schemas.microsoft.com/office/word\" w:val=\"15\"/></w:compat>";
    let mut s = xml.to_string();
    if let Some(i) = s.find("<w:settings") {
        if let Some(gt) = s[i..].find('>').map(|g| i + g) {
            if s[..gt].ends_with('/') {
                s.replace_range(gt - 1..gt + 1, "></w:settings>");
            }
        }
    }
    let after = ["<w:docVars", "<w:rsids", "<m:mathPr", "<w:attachedSchema", "<w:themeFontLang", "<w:clrSchemeMapping", "<w:doNotIncludeSubdocsInStats", "<w:doNotAutoCompressPictures", "<w:forceUpgrade", "<w:captions", "<w:readModeInkLockDown", "<w:smartTagType", "<sl:schemaLibrary", "<w:shapeDefaults", "<w:doNotEmbedSmartTags", "<w:decimalSymbol", "<w:listSeparator", "</w:settings>"];
    let at = after.iter().filter_map(|t| s.find(t)).min();
    if let Some(at) = at {
        s.insert_str(at, compat);
    }
    s
}

/// Chaque police utilisée est déclarée.
fn fonts(xml: &str, document: &str) -> String {
    let mut used: Vec<String> = Vec::new();
    for key in ["w:ascii=\"", "w:hAnsi=\""] {
        let mut i = 0;
        while let Some(k) = document[i..].find(key) {
            let s = i + k + key.len();
            if let Some(name) = document[s..].split('"').next() {
                if !name.is_empty() && !used.iter().any(|u| u == name) {
                    used.push(name.to_string());
                }
            }
            i = s;
        }
    }
    let mut s = xml.to_string();
    if s.contains("<w:fonts") && !s.contains("</w:fonts>") {
        if let Some(i) = s.find("<w:fonts") {
            if let Some(gt) = s[i..].find("/>").map(|g| i + g) {
                s.replace_range(gt..gt + 2, "></w:fonts>");
            }
        }
    }
    let mut add = String::new();
    for f in used {
        let esc = f.replace('&', "&amp;").replace('"', "&quot;").replace('<', "&lt;");
        if !s.contains(&format!("w:name=\"{esc}\"")) {
            add.push_str(&format!("<w:font w:name=\"{esc}\"/>"));
        }
    }
    s.replacen("</w:fonts>", &format!("{add}</w:fonts>"), 1)
}

/// Des identifiants « rIdN » (N ≥ 1) pour les relations que le document
/// ne cite pas lui-même (styles, réglages, thème, polices).
fn rel_ids(xml: &str, document: &str) -> String {
    let mut s = xml.to_string();
    let mut next = 900;
    for odd in ["rId0", "rdocxSettings", "rdocxTheme", "rdocxFontTable", "rdocxStyles", "rdocxNumbering", "rdocxWebSettings"] {
        let pat = format!("Id=\"{odd}\"");
        if s.contains(&pat) && !document.contains(&format!("\"{odd}\"")) {
            while s.contains(&format!("Id=\"rId{next}\"")) {
                next += 1;
            }
            s = s.replace(&pat, &format!("Id=\"rId{next}\""));
            next += 1;
        }
    }
    s
}

#[cfg(test)]
mod tests {
    #[test]
    fn word_strict_bits_are_fixed() {
        assert!(super::app("<Properties><Application>rdocx</Application><AppVersion>0.14.0</AppVersion></Properties>").contains("<AppVersion>16.0000</AppVersion>"));
        let s = super::settings("<w:settings xmlns:w=\"x\"></w:settings>");
        assert!(s.contains("compatibilityMode") && s.ends_with("</w:compat></w:settings>"), "{s}");
        let c = super::core("<cp:coreProperties xmlns:cp=\"x\" xmlns:dc=\"d\" xmlns:dcterms=\"t\" xmlns:xsi=\"i\">\n</cp:coreProperties>");
        assert!(c.contains("<dcterms:created xsi:type=\"dcterms:W3CDTF\">") && c.contains("<dc:creator>"), "{c}");
        let f = super::fonts("<w:fonts><w:font w:name=\"Calibri\"/></w:fonts>", "<w:rFonts w:ascii=\"Adwaita Sans\" w:hAnsi=\"Adwaita Sans\"/>");
        assert!(f.contains("<w:font w:name=\"Adwaita Sans\"/></w:fonts>"), "{f}");
        let r = super::rel_ids("<Relationship Id=\"rId0\" Target=\"styles.xml\"/><Relationship Id=\"rdocxTheme\"/>", "");
        assert!(!r.contains("rId0\"") && !r.contains("rdocx"), "{r}");
    }
}
