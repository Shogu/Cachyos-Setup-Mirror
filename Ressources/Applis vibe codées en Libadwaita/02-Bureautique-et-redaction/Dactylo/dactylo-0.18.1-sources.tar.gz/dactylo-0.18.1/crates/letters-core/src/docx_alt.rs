// docx_alt.rs — ce que Word range « à côté » du texte : variantes
// mc:AlternateContent et zones de texte.
//
// 1. Word (et d'autres) enveloppent souvent une image dans
//    <mc:AlternateContent> : une variante moderne (<mc:Choice>, un
//    <w:drawing>) et une variante ancienne (<mc:Fallback>, du VML). Le lecteur
//    DOCX ne lit pas cette enveloppe : l'image disparaissait. On la remplace
//    par sa variante moderne quand celle-ci porte un <w:drawing>.
// 2. Le texte d'une zone de texte (<w:txbxContent>) est rangé dans une forme
//    dessinée, hors du fil du document : il était invisible, puis perdu à
//    l'enregistrement. Chaque zone de texte devient un cartouche de Dactylo
//    (un tableau d'une case), placé juste après le paragraphe qui l'ancre,
//    avec son texte et la mise en forme de ses caractères. La position
//    flottante sur la page est perdue ; ses paragraphes sont réunis en un
//    seul, séparés par des retours à la ligne (un cartouche tient en un
//    paragraphe).
// SPDX-License-Identifier: GPL-3.0-or-later

/// Début de la prochaine balise ouvrante `<name` (suivie de `>`, `/` ou
/// d'une espace) à partir de `from`.
fn find_open(xml: &str, name: &str, from: usize) -> Option<usize> {
    let pat = format!("<{name}");
    let mut at = from;
    while let Some(i) = xml.get(at..)?.find(&pat) {
        let i = at + i;
        match xml.as_bytes().get(i + pat.len()) {
            Some(b'>' | b' ' | b'/' | b'\n' | b'\t' | b'\r') => return Some(i),
            _ => at = i + pat.len(),
        }
    }
    None
}

/// La fin (après `</name>`) de l'élément qui commence en `start`, en tenant
/// compte des éléments de même nom imbriqués.
fn matching_close(xml: &str, name: &str, start: usize) -> Option<usize> {
    let open_end = start + xml[start..].find('>')? + 1;
    if xml.as_bytes()[open_end - 2] == b'/' {
        return Some(open_end);
    }
    let close = format!("</{name}>");
    let mut depth = 1usize;
    let mut at = open_end;
    loop {
        let next_close = at + xml[at..].find(&close)?;
        match find_open(xml, name, at).filter(|&o| o < next_close) {
            Some(o) => {
                let oe = o + xml[o..].find('>')? + 1;
                if xml.as_bytes()[oe - 2] != b'/' {
                    depth += 1;
                }
                at = oe;
            }
            None => {
                depth -= 1;
                at = next_close + close.len();
                if depth == 0 {
                    return Some(at);
                }
            }
        }
    }
}

/// Le contenu (entre les balises) de l'élément `[start, end)`.
fn inner<'a>(xml: &'a str, name: &str, start: usize, end: usize) -> &'a str {
    let open_end = start + xml[start..end].find('>').map_or(0, |i| i + 1);
    let close = format!("</{name}>");
    if xml[start..end].ends_with(&close) && open_end <= end - close.len() {
        &xml[open_end..end - close.len()]
    } else {
        ""
    }
}

/// Le premier élément `name` dans `xml` : (début, fin).
fn first(xml: &str, name: &str) -> Option<(usize, usize)> {
    let s = find_open(xml, name, 0)?;
    Some((s, matching_close(xml, name, s)?))
}

/// Les paragraphes d'une zone de texte réunis en un seul (sauts de ligne),
/// avec la mise en forme de paragraphe du premier. `None` sans texte.
fn box_paragraph(content: &str) -> Option<String> {
    if !content.contains("<w:t") {
        return None;
    }
    // Une zone qui porte un tableau : on insère son contenu tel quel
    // (tableau et paragraphes), sans cadre autour.
    if content.contains("<w:tbl") {
        return Some(format!("{RAW}{}", content.trim()));
    }
    let mut ppr = String::new();
    let mut runs: Vec<String> = Vec::new();
    let mut at = 0usize;
    while let Some(s) = find_open(content, "w:p", at) {
        let Some(e) = matching_close(content, "w:p", s) else { break };
        let mut body = inner(content, "w:p", s, e).to_string();
        if let Some((ps, pe)) = first(&body, "w:pPr") {
            if runs.is_empty() {
                ppr = body[ps..pe].to_string();
            }
            body.replace_range(ps..pe, "");
        }
        runs.push(body);
        at = e;
    }
    if runs.is_empty() {
        return None;
    }
    Some(format!("<w:p>{ppr}{}</w:p>", runs.join("<w:r><w:br/></w:r>")))
}

/// Marque d'un contenu à insérer tel quel (pas de cartouche).
const RAW: &str = "\u{1}RAW";

/// Un cartouche de Dactylo (tableau d'une case) qui porte `paragraph`.
fn cartouche(paragraph: &str) -> String {
    if let Some(raw) = paragraph.strip_prefix(RAW) {
        return raw.to_string();
    }
    format!(
        "<w:tbl><w:tblPr><w:tblStyle w:val=\"Cartouche_carre_fin_blanc\"/><w:tblW w:w=\"9360\" w:type=\"dxa\"/>\
         <w:tblBorders><w:top w:val=\"single\" w:sz=\"6\" w:space=\"0\" w:color=\"5E5C64\"/><w:left w:val=\"single\" w:sz=\"6\" w:space=\"0\" w:color=\"5E5C64\"/>\
         <w:bottom w:val=\"single\" w:sz=\"6\" w:space=\"0\" w:color=\"5E5C64\"/><w:right w:val=\"single\" w:sz=\"6\" w:space=\"0\" w:color=\"5E5C64\"/>\
         <w:insideH w:val=\"single\" w:sz=\"6\" w:space=\"0\" w:color=\"5E5C64\"/><w:insideV w:val=\"single\" w:sz=\"6\" w:space=\"0\" w:color=\"5E5C64\"/></w:tblBorders>\
         <w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"FFFFFF\"/><w:tblCellMar><w:top w:w=\"140\" w:type=\"dxa\"/><w:left w:w=\"108\" w:type=\"dxa\"/>\
         <w:bottom w:w=\"140\" w:type=\"dxa\"/><w:right w:w=\"108\" w:type=\"dxa\"/></w:tblCellMar></w:tblPr>\
         <w:tblGrid><w:gridCol w:w=\"9360\"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"FFFFFF\"/></w:tcPr>{paragraph}</w:tc></w:tr></w:tbl>"
    )
}

/// Une image flottante (<wp:anchor>, avec habillage) devient une image dans
/// la ligne (<wp:inline>), là où elle est ancrée : le lecteur ne lit que
/// celles-ci, la flottante disparaissait. Sa position libre sur la page est
/// perdue. Les formes et zones de texte flottantes ne sont pas touchées.
fn anchors_inline(xml: &str) -> Option<String> {
    if !xml.contains("<wp:anchor") {
        return None;
    }
    let mut out = xml.to_string();
    let mut at = 0usize;
    while let Some(start) = find_open(&out, "wp:anchor", at) {
        let Some(end) = matching_close(&out, "wp:anchor", start) else { break };
        let block = out[start..end].to_string();
        if !block.contains("<pic:pic") || block.contains("<wps:") || block.contains("<wpg:") {
            at = end;
            continue;
        }
        let take = |name: &str| first(&block, name).map(|(s, e)| block[s..e].to_string()).unwrap_or_default();
        // Les espaces de noms déclarés sur l'ancre (a:, pic:…) suivent l'image.
        let open_tag = &block[..block.find('>').unwrap_or(0)];
        let ns: String = open_tag
            .split_whitespace()
            .filter(|t| t.starts_with("xmlns:"))
            .map(|t| format!(" {}", t.trim_end_matches('/')))
            .collect();
        let inline = format!(
            "<wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\"{ns}>{}{}{}{}</wp:inline>",
            take("wp:extent"),
            take("wp:docPr"),
            take("wp:cNvGraphicFramePr"),
            take("a:graphic")
        );
        out.replace_range(start..end, &inline);
        at = start + inline.len();
    }
    (out != xml).then_some(out)
}

/// Le recadrage (<a:srcRect>, en millièmes de pour cent : l, t, r, b) de
/// chaque image du document, dans l'ordre. `None` : pas de recadrage.
pub fn crops(xml: &str) -> Vec<Option<[i32; 4]>> {
    let mut out = Vec::new();
    let mut at = 0usize;
    while let Some(start) = find_open(xml, "pic:pic", at) {
        let Some(end) = matching_close(xml, "pic:pic", start) else { break };
        let block = &xml[start..end];
        let crop = find_open(block, "a:srcRect", 0).and_then(|s| {
            let tag = &block[s..s + block[s..].find('>')?];
            let get = |k: &str| {
                let pat = format!(" {k}=\"");
                tag.find(&pat).and_then(|i| tag[i + pat.len()..].split('"').next()?.parse::<i32>().ok()).unwrap_or(0)
            };
            let c = [get("l"), get("t"), get("r"), get("b")];
            (c.iter().any(|v| *v != 0)).then_some(c)
        });
        out.push(crop);
        at = end;
    }
    out
}

/// Le document sans enveloppes, zones de texte ni images flottantes, ou
/// `None` s'il n'y avait rien à changer.
pub fn unwrap(xml: &str) -> Option<String> {
    let first_pass = unwrap_alt(xml);
    let base = first_pass.as_deref().unwrap_or(xml);
    let second = anchors_inline(base).or(first_pass);
    let base = second.as_deref().unwrap_or(xml);
    split_drawing_runs(base).or(second)
}

/// Samizdat : plusieurs images dans un même run (deux photos côte à côte)
/// deviennent un run chacune — la lecture n'en voyait que la première.
fn split_drawing_runs(xml: &str) -> Option<String> {
    let mut out = String::with_capacity(xml.len());
    let mut last = 0;
    let mut changed = false;
    let mut i = 0;
    // (« <w:r> » ou « <w:r … » : une seule recherche, sinon chercher la
    // forme absente parcourait tout le document à chaque run)
    while let Some(k) = xml[i..].find("<w:r").filter(|_| xml.len() > i) {
        let s = i + k;
        if !matches!(xml.as_bytes().get(s + 4), Some(b'>' | b' ')) {
            i = s + 4;
            continue;
        }
        let Some(e) = crate::docx_keep::element_end(xml, s, "w:r") else { break };
        let run = &xml[s..e];
        i = e;
        if run.matches("<w:drawing>").count() < 2 {
            continue;
        }
        let open_end = run.find('>').map_or(0, |g| g + 1);
        let inner = &run[open_end..run.len() - "</w:r>".len()];
        let (rpr, body) = match (inner.find("<w:rPr>"), inner.find("</w:rPr>")) {
            (Some(a), Some(b)) if inner[..a].trim().is_empty() => (&inner[a..b + 8], &inner[b + 8..]),
            _ => ("", inner),
        };
        let mut pieces = Vec::new();
        let mut j = 0;
        while let Some(d) = body[j..].find("<w:drawing>") {
            let ds = j + d;
            let Some(de) = crate::docx_keep::element_end(body, ds, "w:drawing") else { break };
            pieces.push(&body[j..ds]);
            pieces.push(&body[ds..de]);
            j = de;
        }
        pieces.push(&body[j..]);
        out.push_str(&xml[last..s]);
        for piece in pieces.into_iter().filter(|p| !p.trim().is_empty()) {
            out.push_str(&format!("<w:r>{rpr}{piece}</w:r>"));
        }
        last = e;
        changed = true;
    }
    if !changed {
        return None;
    }
    out.push_str(&xml[last..]);
    Some(out)
}

fn unwrap_alt(xml: &str) -> Option<String> {
    if !xml.contains("<mc:AlternateContent") && !xml.contains("<w:txbxContent") {
        return None;
    }
    let mut out = xml.to_string();
    // Les zones de texte trouvées, et l'endroit (dans `out`) après lequel les
    // placer : on les insère à la fin, de la dernière à la première.
    let mut boxes: Vec<(usize, String)> = Vec::new();
    let mut at = 0usize;
    loop {
        // Le prochain élément à traiter : une enveloppe, ou une image/forme
        // nue qui porte une zone de texte.
        let candidates = [
            ("mc:AlternateContent", find_open(&out, "mc:AlternateContent", at)),
            ("w:drawing", find_open(&out, "w:drawing", at)),
            ("w:pict", find_open(&out, "w:pict", at)),
        ];
        let Some((name, start)) = candidates.iter().filter_map(|(n, s)| s.map(|s| (*n, s))).min_by_key(|(_, s)| *s) else {
            break;
        };
        let Some(end) = matching_close(&out, name, start) else { break };
        let block = out[start..end].to_string();
        // Le contenu à garder à cet endroit, et la zone de texte éventuelle.
        let keep: Option<String> = if name == "mc:AlternateContent" {
            let choice = first(&block, "mc:Choice").map(|(s, e)| inner(&block, "mc:Choice", s, e).to_string()).unwrap_or_default();
            if let Some((s, e)) = first(&choice, "w:txbxContent") {
                // La variante moderne porte la zone de texte : l'enveloppe
                // entière s'en va, le texte devient un cartouche.
                if let Some(p) = box_paragraph(inner(&choice, "w:txbxContent", s, e)) {
                    boxes.push((start, cartouche(&p)));
                }
                Some(String::new())
            } else if choice.contains("<w:drawing") {
                Some(choice)
            } else {
                None
            }
        } else if let Some((s, e)) = first(&block, "w:txbxContent") {
            if let Some(p) = box_paragraph(inner(&block, "w:txbxContent", s, e)) {
                boxes.push((start, cartouche(&p)));
            }
            Some(String::new())
        } else {
            None
        };
        match keep {
            Some(k) => {
                out.replace_range(start..end, &k);
                // Les zones déjà relevées plus loin n'existent pas encore :
                // seules les positions avant `start` comptent.
                at = start;
                if name == "mc:AlternateContent" && !k.is_empty() {
                    // Le <w:drawing> remis à plat ne porte pas de zone de
                    // texte : on peut le sauter.
                    at = start + k.len();
                }
            }
            None => at = end,
        }
    }
    // Chaque cartouche va après la fin du paragraphe qui ancrait sa zone.
    for (pos, table) in boxes.into_iter().rev() {
        let Some(rel) = out[pos..].find("</w:p>") else { continue };
        let close = pos + rel + "</w:p>".len();
        // Dans une case de tableau, une case doit finir par un paragraphe.
        let table = if out[close..].trim_start().starts_with("</w:tc>") { format!("{table}<w:p/>") } else { table };
        out.insert_str(close, &table);
    }
    (out != xml).then_some(out)
}

#[cfg(test)]
mod tests {
    #[test]
    fn two_pictures_in_one_run_become_two_runs() {
        let xml = "<w:p><w:r><w:rPr><w:b/></w:rPr><w:drawing>A</w:drawing><w:t>x</w:t><w:drawing>B</w:drawing></w:r></w:p>";
        assert_eq!(super::split_drawing_runs(xml).unwrap(), "<w:p><w:r><w:rPr><w:b/></w:rPr><w:drawing>A</w:drawing></w:r><w:r><w:rPr><w:b/></w:rPr><w:t>x</w:t></w:r><w:r><w:rPr><w:b/></w:rPr><w:drawing>B</w:drawing></w:r></w:p>");
    }

    use super::*;

    #[test]
    fn picture_in_alternate_content_is_unwrapped() {
        let xml = r#"<w:body><w:p><w:r><mc:AlternateContent><mc:Choice Requires="wpg"><w:drawing><wp:inline><a:blip r:embed="rId8"/></wp:inline></w:drawing></mc:Choice><mc:Fallback><w:pict><v:shape><v:imagedata r:id="rId8"/></v:shape></w:pict></mc:Fallback></mc:AlternateContent></w:r></w:p></w:body>"#;
        let out = unwrap(xml).unwrap();
        assert_eq!(out, r#"<w:body><w:p><w:r><w:drawing><wp:inline><a:blip r:embed="rId8"/></wp:inline></w:drawing></w:r></w:p></w:body>"#);
    }

    #[test]
    fn text_box_becomes_a_cartouche_after_its_paragraph() {
        let xml = r#"<w:body><w:p><w:r><w:t>Avant</w:t></w:r><w:r><mc:AlternateContent><mc:Choice Requires="wps"><w:drawing><wp:anchor><wps:txbx><w:txbxContent><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>Titre</w:t></w:r></w:p><w:p><w:r><w:t>Seconde ligne</w:t></w:r></w:p></w:txbxContent></wps:txbx></wp:anchor></w:drawing></mc:Choice><mc:Fallback><w:pict><v:textbox><w:txbxContent><w:p><w:r><w:t>Titre</w:t></w:r></w:p></w:txbxContent></v:textbox></w:pict></mc:Fallback></mc:AlternateContent></w:r></w:p><w:p><w:r><w:t>Après</w:t></w:r></w:p></w:body>"#;
        let out = unwrap(xml).unwrap();
        assert!(!out.contains("AlternateContent") && !out.contains("txbxContent"), "{out}");
        let table = out.find("<w:tbl>").unwrap();
        assert!(out.find("Avant").unwrap() < table && table < out.find("Après").unwrap());
        assert!(out.contains("<w:jc w:val=\"center\"/></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>Titre</w:t></w:r><w:r><w:br/></w:r><w:r><w:t>Seconde ligne"), "{out}");
        assert_eq!(out.matches("Titre").count(), 1);
    }

    #[test]
    fn floating_picture_becomes_inline_and_crop_is_read() {
        let xml = r#"<w:p><w:r><w:drawing><wp:anchor behindDoc="0"><wp:simplePos x="0" y="0"/><wp:positionH relativeFrom="column"><wp:posOffset>10</wp:posOffset></wp:positionH><wp:extent cx="100" cy="50"/><wp:wrapSquare wrapText="bothSides"/><wp:docPr id="1" name="Image"/><a:graphic><a:graphicData><pic:pic><pic:blipFill><a:blip r:embed="rId5"/><a:srcRect l="10000" r="5000"/></pic:blipFill></pic:pic></a:graphicData></a:graphic></wp:anchor></w:drawing></w:r></w:p>"#;
        let out = unwrap(xml).unwrap();
        assert!(out.contains("<wp:inline") && !out.contains("wp:anchor") && !out.contains("positionH"), "{out}");
        assert!(out.contains(r#"<wp:extent cx="100" cy="50"/>"#) && out.contains("rId5"));
        assert_eq!(crops(&out), vec![Some([10000, 0, 5000, 0])]);
    }

    #[test]
    fn plain_documents_are_left_alone() {
        assert!(unwrap("<w:body><w:p><w:r><w:t>Rien</w:t></w:r></w:p></w:body>").is_none());
    }
}
