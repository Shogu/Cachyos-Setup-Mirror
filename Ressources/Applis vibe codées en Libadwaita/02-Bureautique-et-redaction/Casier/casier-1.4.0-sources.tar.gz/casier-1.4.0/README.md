# Casier

Casier récupère, corrige et archive les devoirs que les élèves déposent en ligne.
Les élèves envoient leur fichier par un simple lien Dropbox, sans compte ; Casier
retrouve à qui appartient chaque copie, l'affiche à côté de la note et de
l'appréciation, puis archive le tout.

Appli GTK4 / libadwaita en Python, pour un usage personnel.

## Installation

```
sudo pacman -U casier-1.3.0-1-any.pkg.tar.zst
```

Dépendances installées automatiquement : `python-gobject`, `python-cairo`,
`python-qrcode`, `gtk4`, `libadwaita`, `poppler-glib`, `libsoup3`, `libsecret`.
Facultatif : `gst-plugins-good` (aperçu des vidéos), `libheif` (photos HEIC).

## Connecter Dropbox (une seule fois)

Préférences → Dropbox → **Connecter**, puis :

1. Sur la console Dropbox (bouton « Ouvrir la console »), **Create app** →
   *Scoped access* → *Full Dropbox*, avec le nom de ton choix.
2. Onglet **Permissions** : cocher `account_info.read`, `files.metadata.read`,
   `files.content.read`, `files.content.write`, `file_requests.read`,
   `file_requests.write`, `sharing.read`, `sharing.write`, puis **Submit**.
3. Onglet **Settings** : copier l'**App key** dans Casier.
4. **Ouvrir la page d'autorisation**, accepter, coller le code affiché.

La connexion est gardée dans le trousseau GNOME. Si tu ajoutes des permissions
plus tard, déconnecte puis reconnecte Casier.

## Utilisation

1. **Créer une classe** (bouton + de la barre latérale), puis **importer la liste
   des élèves** : un élève par ligne (« NOM Prénom ») ou un CSV `Nom;Prénom`.
   Pour réorganiser les classes d'une même année : glisser-déposer dans la
   barre latérale, clic droit *Monter* / *Descendre*, ou Alt+↑ / Alt+↓.
2. **Nouveau devoir** : titre, barème, date limite, consignes et, si tu veux,
   un document de consignes. Casier crée la demande de fichiers Dropbox.
3. **Donner le lien aux élèves** : bouton *QR code* à projeter (consignes +
   dépôt), ou copier le lien.
4. **Suivre les rendus** : Casier récupère les copies toutes les 2 minutes tant
   que la page du devoir est ouverte. Chaque élève est marqué *Rendu*,
   *En retard* ou *Manquant*. Les fichiers non reconnus s'attribuent à la main.
5. **Corriger** : un clic sur un élève ouvre sa copie (PDF, image, vidéo, texte
   d'un Word ou d'un ODT) avec la note et l'appréciation. Ctrl+Page suivante /
   précédente pour changer d'élève.
6. **Fermer les dépôts** à la date limite (interrupteur ou bandeau).
7. Menu ⋮ du devoir : **Renommer les fichiers** (`NOM_Prénom_Devoir`),
   **Exporter les notes** (CSV), **Archiver le devoir**.

Un devoir peut aussi utiliser un dossier local (Dropbox synchronisée sur le PC)
au lieu d'une demande de fichiers : il suffit de décocher l'option à la création.

## Où sont les données

| Quoi | Où |
|---|---|
| Base (classes, élèves, notes) | `~/.local/share/casier/casier.db` |
| Sauvegardes automatiques (30 derniers jours) | `~/.local/share/casier/sauvegardes/` |
| Copies récupérées de Dropbox | `~/.local/share/casier/depots/` |
| Archives (copies renommées, notes.csv, .zip) | `~/Documents/Casier/` (modifiable dans les Préférences) |
| Côté Dropbox | `Casier/<année>/<classe>/<devoir>` et `…/<classe>/Consignes/` |

Menu principal : **Sauvegarder la base…** et **Restaurer une sauvegarde…**.

## Nettoyage

- Supprimer un devoir ou une classe propose de supprimer aussi le lien, les
  copies et les consignes dans Dropbox.
- Préférences → Dropbox → **Nettoyer une année** supprime `Casier/<année>` ;
  les notes et les copies déjà récupérées restent dans Casier.

Ce qui est supprimé de Dropbox reste récupérable 30 jours dans ses
« Fichiers supprimés ».
