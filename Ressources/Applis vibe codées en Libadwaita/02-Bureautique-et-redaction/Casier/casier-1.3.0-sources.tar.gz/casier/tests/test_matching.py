import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from casier.matching import Student, FileEntry, assign, match_file, parse_student_lines, IGNORED, UNASSIGNED

S = [Student(1, "DUPONT", "Marie"), Student(2, "DUPONT", "Léa"), Student(3, "LE GALL", "Yann"),
     Student(4, "MARTIN-DURAND", "Lucas"), Student(5, "LI", "Chen"), Student(6, "BENALI", "Inès")]

def m(name):
    r = match_file(name, S)
    return r.id if r else None

cases = {
    "Dupont Marie - devoir.pdf": 1, "lea_dupont.docx": 2, "dupont.pdf": None,
    "LeGall_Yann.jpg": 3, "le gall.pdf": 3, "martin durand lucas.pdf": 4, "MartinDurand.odt": 4,
    "liste.pdf": None, "Li Chen.pdf": 5, "ines.jpg": 6, "IMG_2024.jpg": None,
    "Benali Ines/photo1.jpg": 6, "yann.pdf": 3,
}
ok = True
for name, want in cases.items():
    got = m(name)
    flag = "OK " if got == want else "ERR"
    ok &= got == want
    print(flag, name, got, want)

files = [FileEntry(n, "/x/" + n, i, 1) for i, n in enumerate(["dupont.pdf", "Li Chen.pdf", "x.pdf", "y.pdf"])]
sub = assign(files, S, {"dupont.pdf": 2, "x.pdf": IGNORED, "Li Chen.pdf": UNASSIGNED})
print(sub.by_student.keys(), [e.rel_path for e in sub.unassigned], [e.rel_path for e in sub.ignored])
ok &= list(sub.by_student) == [2] and [e.rel_path for e in sub.ignored] == ["x.pdf"]
print(parse_student_lines("Nom;Prénom\nDUPONT;Marie\nLE GALL Yann\nMARTIN-DURAND Lucas Paul\nBenali Inès\n\n"))
print("ALL OK" if ok else "FAILURES")
