import datetime
from gi.repository import GLib
from casier.dropbox import DropboxError


class FakeDropbox:
    """Simule l'API Dropbox en mémoire : demandes de fichiers, dossiers, téléchargements."""

    def __init__(self, db):
        self.db = db
        self.files = {}
        self.requests = {}
        self.calls = []
        self.app_key = "cle"
        self.account_label = "Test (test@example.org)"

    connected = True

    def add_file(self, path, data, when):
        rev = f"r{len(self.files)}{len(data)}"
        self.files[path.lower()] = {"path_display": path, "data": data, "rev": rev,
                                     "server_modified": when.strftime("%Y-%m-%dT%H:%M:%SZ"), "id": "id:" + path}

    def rpc(self, endpoint, args, callback):
        self.calls.append(endpoint)
        GLib.timeout_add(50, lambda: self._answer(endpoint, args, callback) and False)

    def _answer(self, endpoint, args, callback):
        try:
            callback(self._handle(endpoint, args), None)
        except DropboxError as error:
            callback(None, error)

    def _handle(self, endpoint, args):
        if endpoint == "file_requests/create":
            rid = f"req{len(self.requests)+1}"
            req = {"id": rid, "url": f"https://www.dropbox.com/request/{rid}ABCDEFghijkl", "title": args["title"],
                   "destination": args["destination"], "is_open": True, "file_count": 0}
            self.requests[rid] = req
            return req
        if endpoint == "file_requests/get":
            return self.requests[args["id"]]
        if endpoint == "file_requests/update":
            self.requests[args["id"]]["is_open"] = args["open"]
            return self.requests[args["id"]]
        if endpoint == "files/list_folder":
            root = args["path"].lower().rstrip("/") + "/"
            entries = [{".tag": "file", "path_display": f["path_display"], "rev": f["rev"], "id": f["id"],
                        "server_modified": f["server_modified"], "size": len(f["data"])}
                       for p, f in self.files.items() if p.startswith(root)]
            if not entries and not any(r["destination"].lower() + "/" == root for r in self.requests.values()):
                raise DropboxError("path/not_found/..", 409)
            return {"entries": entries, "has_more": False, "cursor": "c"}
        if endpoint == "files/move_v2":
            f = self.files.pop(args["from_path"].lower())
            f["path_display"] = args["to_path"]
            f["rev"] = f["rev"] + "m"
            f["id"] = "id:" + args["to_path"]
            self.files[args["to_path"].lower()] = f
            return {"metadata": {}}
        if endpoint == "files/delete_v2":
            prefix = args["path"].lower()
            gone = [p for p in self.files if p == prefix or p.startswith(prefix + "/")]
            if not gone:
                raise DropboxError("path_lookup/not_found/..", 409)
            for p in gone:
                del self.files[p]
            return {"metadata": {}}
        if endpoint == "file_requests/delete":
            for rid in args["ids"]:
                if self.requests[rid]["is_open"]:
                    raise DropboxError("file_request_open", 409)
                del self.requests[rid]
            return {"file_requests": []}
        raise DropboxError("unknown", 400)

    def download(self, path, callback):
        f = next(f for f in self.files.values() if f["id"] == path)
        GLib.timeout_add(20, lambda: callback(f["data"], None) and False)


def _upload(self, path, data, callback):
    self.calls.append("files/upload")
    self.add_file(path, data, datetime.datetime(2026, 11, 13, 12, 0))
    GLib.timeout_add(30, lambda: callback({"path_display": path}, None) and False)


def _share(self, path, callback):
    self.calls.append("sharing/create_shared_link_with_settings")
    GLib.timeout_add(30, lambda: callback("https://www.dropbox.com/scl/fi/abc123/consignes.pdf?dl=0", None) and False)


FakeDropbox.upload = _upload
FakeDropbox.share = _share
FakeDropbox.shutdown = lambda self: None
