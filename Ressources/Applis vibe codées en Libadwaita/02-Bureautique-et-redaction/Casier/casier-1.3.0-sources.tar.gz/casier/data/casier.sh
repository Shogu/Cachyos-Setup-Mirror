#!/bin/sh
exec python3 /usr/lib/casier/main.py "$@"
