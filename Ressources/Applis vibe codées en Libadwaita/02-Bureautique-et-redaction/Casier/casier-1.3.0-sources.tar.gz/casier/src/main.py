import ctypes
import sys

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("Poppler", "0.18")
gi.require_version("Soup", "3.0")
gi.require_version("Secret", "1")
gi.require_foreign("cairo")

from gi.repository import GLib  # noqa: E402

PR_SET_NAME = 15


def set_process_name(name):
    libc = ctypes.CDLL(None)
    libc.prctl(PR_SET_NAME, name.encode(), 0, 0, 0)
    GLib.set_prgname(name)


def main():
    set_process_name("casier")
    from casier.application import CasierApplication
    return CasierApplication().run(sys.argv)


if __name__ == "__main__":
    sys.exit(main())
