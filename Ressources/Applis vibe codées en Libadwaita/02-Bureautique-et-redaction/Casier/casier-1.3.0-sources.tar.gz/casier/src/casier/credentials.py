from gi.repository import GLib, Secret

SCHEMA = Secret.Schema.new(
    "io.gitlab.shogu.Casier.Dropbox",
    Secret.SchemaFlags.NONE,
    {"service": Secret.SchemaAttributeType.STRING},
)
ATTRIBUTES = {"service": "dropbox"}


def load_refresh_token():
    try:
        return Secret.password_lookup_sync(SCHEMA, ATTRIBUTES, None)
    except GLib.Error:
        return None


def store_refresh_token(token):
    Secret.password_store_sync(SCHEMA, ATTRIBUTES, Secret.COLLECTION_DEFAULT, "Casier — connexion Dropbox", token, None)


def clear_refresh_token():
    try:
        Secret.password_clear_sync(SCHEMA, ATTRIBUTES, None)
    except GLib.Error:
        return
