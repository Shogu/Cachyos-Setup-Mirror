import datetime
import os
import threading

from gi.repository import Adw, Gio, GLib, Gtk

from . import cleanup, files, model
from .correction_page import CorrectionPage
from .dialogs import AssignmentDialog
from .dropbox import attach_instructions, web_url
from .dropbox_ui import QrDialog, copy_text
from .sync import run_operations
from .matching import IGNORED
from .preview import open_file, open_folder

STATUS_STYLE = {"rendu": ("Rendu", "status-ok"), "en retard": ("En retard", "status-late"), "manquant": ("Manquant", "status-missing")}
RESCAN_DELAY_MS = 600
DROPBOX_REFRESH_S = 120


def status_pill(status):
    label, css = STATUS_STYLE[status]
    return Gtk.Label(label=label, valign=Gtk.Align.CENTER, css_classes=["status-pill", css])


def grade_text(grade, scale):
    if grade is None or grade.grade is None:
        return None
    return f"{files.format_grade(grade.grade)}/{scale:g}"


def find_scrolled(widget):
    while widget is not None and not isinstance(widget, Gtk.ScrolledWindow):
        widget = widget.get_first_child()
    return widget


class AssignmentPage(Adw.NavigationPage):
    __gtype_name__ = "CasierAssignmentPage"

    def __init__(self, window, assignment_id):
        super().__init__(title="Devoir", tag=f"devoir-{assignment_id}")
        self.window = window
        self.db = window.db
        self.assignment_id = assignment_id
        self.state = None
        self.monitor = None
        self.monitor_handler = 0
        self.rescan_source = 0
        self.periodic_source = 0
        self.progress_toast = None
        self.sync_error = None

        self.window_title = Adw.WindowTitle()
        header = Adw.HeaderBar(title_widget=self.window_title)
        folder_button = Gtk.Button(icon_name="folder-open-symbolic", tooltip_text="Ouvrir le dossier des rendus")
        folder_button.connect("clicked", lambda _b: open_folder(self.get_root(), self.state.folder))
        header.pack_end(self._menu_button())
        header.pack_end(folder_button)

        self.banner = Adw.Banner()
        self.banner.connect("button-clicked", self._banner_clicked)
        self.toolbar = Adw.ToolbarView()
        self.toolbar.add_top_bar(header)
        self.toolbar.add_top_bar(self.banner)
        self.set_child(self.toolbar)

        self._install_actions()
        self.connect("showing", self._on_showing)
        self.connect("hidden", self._on_hidden)

    def _menu_button(self):
        menu = Gio.Menu()
        work = Gio.Menu()
        work.append("Renommer les fichiers…", "devoir.rename")
        work.append("Exporter les notes (CSV)…", "devoir.export")
        work.append("Archiver le devoir…", "devoir.archive")
        menu.append_section(None, work)
        edit = Gio.Menu()
        edit.append("Ouvrir dans Dropbox", "devoir.web")
        edit.append("Modifier le devoir…", "devoir.edit")
        edit.append("Supprimer le devoir", "devoir.delete")
        menu.append_section(None, edit)
        return Gtk.MenuButton(icon_name="view-more-symbolic", menu_model=menu, tooltip_text="Menu du devoir")

    def _install_actions(self):
        group = Gio.SimpleActionGroup()
        for name, callback in (("rename", self._rename), ("export", self._export), ("archive", self._archive),
                               ("edit", self._edit), ("delete", self._delete), ("web", self._open_web)):
            action = Gio.SimpleAction.new(name, None)
            action.connect("activate", callback)
            group.add_action(action)
        self.web_action = group.lookup_action("web")
        self.insert_action_group("devoir", group)

    def _on_showing(self, _page):
        self.refresh()
        if self.state.assignment.on_dropbox:
            self._sync()
            self.periodic_source = GLib.timeout_add_seconds(DROPBOX_REFRESH_S, self._periodic_sync)
        else:
            self._watch_folder()

    def _on_hidden(self, _page):
        if self.rescan_source:
            GLib.source_remove(self.rescan_source)
            self.rescan_source = 0
        if self.periodic_source:
            GLib.source_remove(self.periodic_source)
            self.periodic_source = 0
        self._stop_watching()

    def _periodic_sync(self):
        self._sync()
        return GLib.SOURCE_CONTINUE

    def _sync(self, *_args):
        if not self.window.dropbox.connected:
            self.sync_error = "Casier n'est pas connecté à Dropbox (Préférences)."
            self.refresh()
            return
        self.window.sync.sync(self.assignment_id, self._synced)
        self.refresh()

    def _synced(self, result, error):
        self.sync_error = str(error) if error else None
        if result and result["downloaded"]:
            count = result["downloaded"]
            self.window.toast(f"{count} nouvelle{'s' if count > 1 else ''} copie{'s' if count > 1 else ''} récupérée{'s' if count > 1 else ''}")
        self.refresh()

    def _open_web(self, *_args):
        Gtk.UriLauncher.new(web_url(self.state.assignment.dropbox_path)).launch(self.get_root(), None, None)

    def _watch_folder(self):
        self._stop_watching()
        if not self.state.folder_exists:
            return
        self.monitor = Gio.File.new_for_path(self.state.folder).monitor_directory(Gio.FileMonitorFlags.WATCH_MOVES, None)
        self.monitor_handler = self.monitor.connect("changed", self._folder_changed)

    def _stop_watching(self):
        if self.monitor is None:
            return
        self.monitor.disconnect(self.monitor_handler)
        self.monitor.cancel()
        self.monitor = None
        self.monitor_handler = 0

    def _folder_changed(self, *_args):
        if self.rescan_source:
            GLib.source_remove(self.rescan_source)
        self.rescan_source = GLib.timeout_add(RESCAN_DELAY_MS, self._rescan_timeout)

    def _rescan_timeout(self):
        self.rescan_source = 0
        self.refresh()
        return GLib.SOURCE_REMOVE

    def refresh(self):
        self.state = model.load(self.db, self.assignment_id)
        assignment = self.state.assignment
        self.set_title(assignment.title)
        self.window_title.set_title(assignment.title)
        subtitle = self.state.school_class.name
        if assignment.due_date:
            subtitle += " · à rendre le " + datetime.date.fromisoformat(assignment.due_date).strftime("%d/%m/%Y")
        self.window_title.set_subtitle(subtitle)
        self._update_banner()
        self.web_action.set_enabled(assignment.on_dropbox)

        previous = find_scrolled(self.toolbar.get_content())
        scroll = previous.get_vadjustment().get_value() if previous else 0
        page = Adw.PreferencesPage()
        if assignment.on_dropbox and not self.state.from_archive:
            page.add(self._dropbox_group())
        page.add(self._summary_group())
        page.add(self._students_group())
        if self.state.submissions.unassigned or self.state.submissions.ignored:
            page.add(self._unassigned_group())
        self.toolbar.set_content(page)
        if scroll:
            GLib.idle_add(self._restore_scroll, page, scroll)

    @staticmethod
    def _restore_scroll(page, value):
        scrolled = find_scrolled(page)
        if scrolled is not None:
            scrolled.get_vadjustment().set_value(value)
        return GLib.SOURCE_REMOVE

    def _update_banner(self):
        assignment = self.state.assignment
        overdue = assignment.deadline is not None and datetime.datetime.now().timestamp() > assignment.deadline
        if assignment.on_dropbox and assignment.request_open and overdue and not assignment.archived_at:
            self.banner.set_title("La date limite est passée et les dépôts sont toujours ouverts.")
            self.banner.set_button_label("Fermer les dépôts")
            self.banner.set_revealed(True)
        elif not assignment.on_dropbox and not os.path.isdir(assignment.folder) and not self.state.from_archive:
            self.banner.set_title("Le dossier des rendus est introuvable. La Dropbox est-elle synchronisée ?")
            self.banner.set_button_label("Choisir un dossier")
            self.banner.set_revealed(True)
        elif assignment.archived_at:
            day = datetime.date.fromisoformat(assignment.archived_at[:10]).strftime("%d/%m/%Y")
            source = " Copies affichées depuis l'archive." if self.state.from_archive else ""
            self.banner.set_title(f"Devoir archivé le {day}.{source}")
            self.banner.set_button_label("Ouvrir l'archive")
            self.banner.set_revealed(True)
        else:
            self.banner.set_revealed(False)

    def _banner_clicked(self, _banner):
        assignment = self.state.assignment
        if assignment.on_dropbox and assignment.request_open and not assignment.archived_at:
            self._set_request_open(False)
        elif self.state.assignment.archived_at and (self.state.from_archive or os.path.isdir(self.state.assignment.folder)):
            open_folder(self.get_root(), model.archive_folder(self.db, self.state.school_class, self.state.assignment))
        else:
            self._edit()

    def _dropbox_group(self):
        assignment = self.state.assignment
        group = Adw.PreferencesGroup(title="Lien de dépôt",
                                     description="Les élèves déposent leur fichier avec ce lien, sans compte Dropbox.")
        link = Adw.ActionRow(title=assignment.request_url, use_markup=False, title_selectable=True)
        copy = Gtk.Button(icon_name="edit-copy-symbolic", valign=Gtk.Align.CENTER, css_classes=["flat"], tooltip_text="Copier le lien")
        copy.connect("clicked", self._copy_link)
        qr = Gtk.Button(label="QR code", valign=Gtk.Align.CENTER, css_classes=["flat"], tooltip_text="Afficher le QR code à projeter")
        qr.connect("clicked", lambda _b: QrDialog(assignment.title, assignment.request_url, assignment.instructions_url)
                   .present(self.get_root()))
        link.add_suffix(qr)
        link.add_suffix(copy)
        group.add(link)

        if assignment.instructions_url:
            document = Adw.ActionRow(title=os.path.basename(assignment.instructions_path), subtitle="Document de consignes, en lecture seule",
                                     use_markup=False, activatable=True)
            copy_doc = Gtk.Button(icon_name="edit-copy-symbolic", valign=Gtk.Align.CENTER, css_classes=["flat"],
                                  tooltip_text="Copier le lien des consignes")
            copy_doc.connect("clicked", self._copy_instructions)
            document.add_suffix(copy_doc)
            document.connect("activated", lambda _r: Gtk.UriLauncher.new(assignment.instructions_url).launch(self.get_root(), None, None))
            group.add(document)

        switch = Adw.SwitchRow(title="Accepter les dépôts", active=assignment.request_open,
                               subtitle="Les élèves peuvent envoyer leur fichier" if assignment.request_open
                               else "Le lien affiche « demande fermée »")
        switch.connect("notify::active", lambda row, _p: self._set_request_open(row.get_active()))
        group.add(switch)

        running = self.window.sync.is_running(self.assignment_id)
        status = Adw.ActionRow(title="Copies en ligne", subtitle=self._sync_text(running), use_markup=False)
        if self.sync_error and not running:
            status.add_css_class("error")
        if running:
            spinner = Gtk.Spinner(spinning=True, valign=Gtk.Align.CENTER)
            status.add_suffix(spinner)
        else:
            refresh = Gtk.Button(icon_name="view-refresh-symbolic", valign=Gtk.Align.CENTER, css_classes=["flat"],
                                 tooltip_text="Récupérer les nouvelles copies")
            refresh.connect("clicked", self._sync)
            status.add_suffix(refresh)
        group.add(status)
        return group

    def _sync_text(self, running):
        if running:
            return "Récupération des copies…"
        if self.sync_error:
            return self.sync_error
        last = self.state.assignment.last_sync
        if not last:
            return "Pas encore synchronisé"
        moment = datetime.datetime.fromisoformat(last)
        prefix = "aujourd'hui" if moment.date() == datetime.date.today() else moment.strftime("le %d/%m")
        return f"Synchronisé {prefix} à {moment.strftime('%H:%M')}, vérifié toutes les 2 minutes"

    def _request_details_updated(self, _request, error):
        if error:
            self.window.toast(str(error))

    def _copy_instructions(self, _button):
        copy_text(self.state.assignment.instructions_url)
        self.window.toast("Lien des consignes copié")

    def instructions_attached(self, error):
        self.window.toast(f"Document de consignes non envoyé : {error}" if error else "Document de consignes ajouté")
        self.refresh()

    def _copy_link(self, _button):
        copy_text(self.state.assignment.request_url)
        self.window.toast("Lien copié")

    def _set_request_open(self, is_open):
        if is_open == self.state.assignment.request_open:
            return
        args = {"id": self.state.assignment.request_id, "open": is_open}
        self.window.dropbox.rpc("file_requests/update", args, lambda request, error: self._request_updated(request, error))

    def _request_updated(self, request, error):
        if error:
            self.window.toast(str(error))
        else:
            self.db.set_request_open(self.assignment_id, request["is_open"])
            self.window.toast("Dépôts ouverts" if request["is_open"] else "Dépôts fermés")
        self.refresh()

    def _summary_group(self):
        counts = self.state.counts()
        handed = counts["rendu"] + counts["en retard"]
        parts = [f"{handed} rendu{'s' if handed > 1 else ''} sur {counts['total']}"]
        if counts["en retard"]:
            parts.append(f"{counts['en retard']} en retard")
        parts.append(f"{counts['manquant']} manquant{'s' if counts['manquant'] > 1 else ''}")
        parts.append(f"{counts['notés']} noté{'s' if counts['notés'] > 1 else ''}")
        group = Adw.PreferencesGroup(title="Avancement", description=" · ".join(parts))
        bar = Gtk.LevelBar(min_value=0, max_value=max(counts["total"], 1), value=handed, margin_top=4)
        bar.remove_offset_value(Gtk.LEVEL_BAR_OFFSET_LOW)
        bar.remove_offset_value(Gtk.LEVEL_BAR_OFFSET_HIGH)
        bar.remove_offset_value(Gtk.LEVEL_BAR_OFFSET_FULL)
        group.add(bar)
        return group

    def _students_group(self):
        group = Adw.PreferencesGroup(title="Élèves")
        if not self.state.students:
            group.set_description("Cette classe n'a pas encore d'élèves. Ajoute-les dans l'onglet Élèves.")
            return group
        for student in self.state.students:
            entries = self.state.submissions.files_for(student.id)
            row = Adw.ActionRow(title=student.display_name, subtitle=model.format_deposit(entries), activatable=True,
                                title_lines=1, use_markup=False)
            text = grade_text(self.state.grades.get(student.id), self.state.assignment.scale)
            if text:
                row.add_suffix(Gtk.Label(label=text, valign=Gtk.Align.CENTER, css_classes=["numeric", "heading"]))
            row.add_suffix(status_pill(files.status_of(entries, self.state.assignment)))
            row.add_suffix(Gtk.Image(icon_name="go-next-symbolic"))
            row.connect("activated", self._open_correction, student.id)
            group.add(row)
        return group

    def _unassigned_group(self):
        submissions = self.state.submissions
        group = Adw.PreferencesGroup(
            title="Fichiers non attribués",
            description="Casier n'a pas reconnu l'élève dans le nom de ces fichiers. Choisis à qui ils appartiennent.",
        )
        labels = ["Attribuer à…"] + [s.display_name for s in self.state.students] + ["Ignorer ce fichier"]
        for entry in submissions.unassigned:
            moment = datetime.datetime.fromtimestamp(entry.mtime).strftime("%d/%m à %H:%M")
            row = Adw.ActionRow(title=os.path.basename(entry.rel_path), subtitle=moment, activatable=True, use_markup=False)
            dropdown = Gtk.DropDown.new_from_strings(labels)
            dropdown.set_valign(Gtk.Align.CENTER)
            dropdown.connect("notify::selected", self._assign_file, entry.rel_path)
            row.add_suffix(dropdown)
            row.connect("activated", lambda _r, path=entry.path: open_file(self.get_root(), Gio.File.new_for_path(path)))
            group.add(row)
        if submissions.ignored:
            expander = Adw.ExpanderRow(title="Fichiers ignorés", subtitle=f"{len(submissions.ignored)} fichier{'s' if len(submissions.ignored) > 1 else ''}")
            for entry in submissions.ignored:
                row = Adw.ActionRow(title=os.path.basename(entry.rel_path), use_markup=False)
                restore = Gtk.Button(label="Rétablir", valign=Gtk.Align.CENTER, css_classes=["flat"])
                restore.connect("clicked", self._restore_file, entry.rel_path)
                row.add_suffix(restore)
                expander.add_row(row)
            group.add(expander)
        return group

    def _assign_file(self, dropdown, _pspec, rel_path):
        selected = dropdown.get_selected()
        if selected == 0:
            return
        students = self.state.students
        student_id = IGNORED if selected == len(students) + 1 else students[selected - 1].id
        self.db.set_override(self.assignment_id, rel_path, student_id)
        GLib.idle_add(self._idle_refresh)

    def _restore_file(self, _button, rel_path):
        self.db.clear_override(self.assignment_id, rel_path)
        self.refresh()

    def _idle_refresh(self):
        self.refresh()
        return GLib.SOURCE_REMOVE

    def _open_correction(self, _row, student_id):
        ids = [s.id for s in self.state.students]
        self.window.push(CorrectionPage(self.window, self.assignment_id, ids, ids.index(student_id)))

    def _rename(self, *_args):
        if self.state.from_archive:
            self.window.toast("Les copies archivées sont déjà renommées.")
            return
        plan = [p for p in files.planned_names(self.state.submissions, self.state.students, self.state.assignment.title)
                if os.path.basename(p[0].path) != p[2]]
        if not plan:
            self.window.toast("Tous les fichiers attribués sont déjà bien nommés.")
            return
        example = plan[0][2]
        dialog = Adw.AlertDialog(
            heading=f"Renommer {len(plan)} fichier{'s' if len(plan) > 1 else ''} ?",
            body=f"Les fichiers attribués seront renommés dans le dossier des rendus, par exemple « {example} ».",
        )
        dialog.add_response("cancel", "Annuler")
        dialog.add_response("rename", "Renommer")
        dialog.set_response_appearance("rename", Adw.ResponseAppearance.SUGGESTED)
        dialog.connect("response", self._rename_response)
        dialog.present(self.get_root())

    def _rename_response(self, _dialog, response):
        if response != "rename":
            return
        if self.state.assignment.on_dropbox:
            self._rename_remote()
            return
        self._stop_watching()
        try:
            renamed = files.rename_all(self.state.folder, self.state.submissions, self.state.students, self.state.assignment.title)
        except OSError as error:
            self.window.toast(f"Renommage interrompu : {error.strerror}")
            renamed = []
        for old, new in renamed:
            self.db.move_override(self.assignment_id, old, new)
        self.refresh()
        self._watch_folder()
        if renamed:
            self.window.toast(f"{len(renamed)} fichier{'s' if len(renamed) > 1 else ''} renommé{'s' if len(renamed) > 1 else ''}")

    def _rename_remote(self):
        root = self.state.assignment.dropbox_path
        plan = files.planned_names(self.state.submissions, self.state.students, self.state.assignment.title)
        moves = []
        renamed = []
        taken = {e.rel_path for entries in self.state.submissions.by_student.values() for e in entries}
        for entry, _student, new_name in plan:
            directory = os.path.dirname(entry.rel_path)
            new_rel = os.path.join(directory, new_name) if directory else new_name
            if new_rel == entry.rel_path or new_rel in taken:
                continue
            taken.add(new_rel)
            moves.append(("files/move_v2", {"from_path": f"{root}/{entry.rel_path}", "to_path": f"{root}/{new_rel}", "autorename": True}))
            renamed.append((entry.rel_path, new_rel))
        self.window.toast("Renommage dans Dropbox…")
        run_operations(self.window.dropbox, moves, lambda done, error: self._remote_renamed(renamed[:done], error))

    def _remote_renamed(self, renamed, error):
        for old, new in renamed:
            self.db.move_override(self.assignment_id, old, new)
        if error:
            self.window.toast(f"Renommage interrompu : {error}")
        elif renamed:
            self.window.toast(f"{len(renamed)} fichier{'s' if len(renamed) > 1 else ''} renommé{'s' if len(renamed) > 1 else ''}")
        self._sync()

    def _export(self, *_args):
        name = f"Notes - {files.safe_file_part(self.state.school_class.name)} - {files.safe_file_part(self.state.assignment.title)}.csv"
        dialog = Gtk.FileDialog(title="Exporter les notes", initial_name=name)
        dialog.save(self.get_root(), None, self._export_chosen)

    def _export_chosen(self, dialog, result):
        try:
            file = dialog.save_finish(result)
        except GLib.Error:
            return
        state = self.state
        files.write_grades_csv(file.get_path(), state.assignment, state.students, state.submissions, state.grades)
        self.window.toast("Notes exportées")

    def _archive(self, *_args):
        if self.state.from_archive:
            self.window.toast("Ce devoir est déjà archivé.")
            return
        destination = model.archive_folder(self.db, self.state.school_class, self.state.assignment)
        dialog = Adw.AlertDialog(
            heading="Archiver ce devoir ?",
            body=f"Les copies renommées et les notes seront copiées dans « {destination.replace(os.path.expanduser('~'), '~', 1)} », "
                 "avec une archive .zip. Les fichiers d'origine ne sont pas touchés.",
        )
        dialog.add_response("cancel", "Annuler")
        dialog.add_response("archive", "Archiver")
        dialog.set_response_appearance("archive", Adw.ResponseAppearance.SUGGESTED)
        dialog.connect("response", self._archive_response, destination)
        dialog.present(self.get_root())

    def _archive_response(self, _dialog, response, destination):
        if response != "archive":
            return
        state = self.state
        self.progress_toast = Adw.Toast(title="Archivage en cours…", timeout=0)
        self.window.toasts.add_toast(self.progress_toast)
        thread = threading.Thread(target=self._archive_worker, args=(destination, state), daemon=True)
        thread.start()

    def _archive_worker(self, destination, state):
        try:
            zip_path = files.archive(destination, state.assignment, state.students, state.submissions, state.grades)
        except OSError as error:
            GLib.idle_add(self._archive_failed, error.strerror or str(error))
            return
        GLib.idle_add(self._archive_done, zip_path, state)

    def _archive_failed(self, message):
        self.progress_toast.dismiss()
        self.window.toast(f"Archivage impossible : {message}")
        return GLib.SOURCE_REMOVE

    def _archive_done(self, zip_path, state):
        self.progress_toast.dismiss()
        self.db.set_archived(self.assignment_id, datetime.datetime.now().isoformat(timespec="seconds"))
        self.refresh()
        handed = [e for entries in state.submissions.by_student.values() for e in entries] + state.submissions.unassigned
        dialog = Adw.AlertDialog(
            heading="Devoir archivé",
            body=f"Archive créée : {os.path.basename(zip_path)}.\n\nTu peux maintenant mettre les fichiers rendus à la corbeille "
                 "pour libérer de la place dans ta Dropbox. Casier affichera alors les copies depuis l'archive.",
        )
        dialog.add_response("keep", "Garder les fichiers")
        dialog.add_response("trash", "Supprimer de Dropbox" if state.assignment.on_dropbox else "Mettre à la corbeille")
        dialog.set_response_appearance("trash", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.connect("response", self._trash_response, handed)
        dialog.present(self.get_root())
        return GLib.SOURCE_REMOVE

    def _trash_response(self, _dialog, response, entries):
        if response != "trash":
            return
        if self.state.assignment.on_dropbox:
            root = self.state.assignment.dropbox_path
            deletions = [("files/delete_v2", {"path": f"{root}/{e.rel_path}"}) for e in entries]
            run_operations(self.window.dropbox, deletions, self._remote_trashed)
            return
        try:
            files.trash_files(entries)
        except GLib.Error as error:
            self.window.toast(f"Corbeille impossible : {error.message}")
        self.refresh()
        self._watch_folder()

    def _remote_trashed(self, _done, error):
        if error:
            self.window.toast(f"Suppression interrompue : {error}")
        self._sync()

    def _edit(self, *_args):
        AssignmentDialog(self._edited, self.window.dropbox, self.state.assignment).present(self.get_root())

    def _edited(self, title, folder, due_date, scale, _use_dropbox, instructions, instructions_file):
        before = self.state.assignment
        self.db.update_assignment(self.assignment_id, title, folder, due_date, scale)
        if before.on_dropbox:
            self.db.set_instructions(self.assignment_id, instructions)
            if instructions != before.instructions or title != before.title:
                args = {"id": before.request_id, "title": f"{self.state.school_class.name} — {title}", "description": instructions}
                self.window.dropbox.rpc("file_requests/update", args, self._request_details_updated)
            if instructions_file:
                self.window.toast("Envoi du document de consignes…")
                attach_instructions(self.window.dropbox, self.db, self.assignment_id, instructions_file, self.instructions_attached)
        self.refresh()
        self._watch_folder()

    def _delete(self, *_args):
        dialog = Adw.AlertDialog(
            heading="Supprimer ce devoir ?",
            body="Les notes et appréciations de ce devoir seront effacées de Casier. Les fichiers des élèves ne sont pas supprimés.",
        )
        dialog.add_response("cancel", "Annuler")
        dialog.add_response("delete", "Supprimer")
        dialog.set_response_appearance("delete", Adw.ResponseAppearance.DESTRUCTIVE)
        check = None
        if self.state.assignment.on_dropbox and self.window.dropbox.connected:
            check = cleanup.dropbox_checkbox("Supprimer aussi dans Dropbox (lien, copies et consignes)")
            dialog.set_extra_child(check)
        dialog.connect("response", self._delete_response, check)
        dialog.present(self.get_root())

    def _delete_response(self, _dialog, response, check):
        if response != "delete":
            return
        assignment = self.state.assignment
        if check is not None and check.get_active():
            self.window.toast("Suppression dans Dropbox…")
            cleanup.run(self.window.dropbox, cleanup.assignment_operations(assignment), self._dropbox_cleaned)
        cleanup.remove_cache(assignment)
        self.db.delete_assignment(self.assignment_id)
        self.window.pop()

    def _dropbox_cleaned(self, error):
        self.window.toast(f"Dropbox n'a pas pu être nettoyé : {error}" if error else "Supprimé aussi dans Dropbox")
