import qrcode
from gi.repository import Adw, Gdk, Gtk, Pango

from .dropbox import CONSOLE_URL

SETUP_STEPS = (
    "Sur la console Dropbox, clique sur « Create app », choisis « Scoped access » puis « Full Dropbox », "
    "et donne-lui un nom (par exemple Casier-Ogu).\n\n"
    "Dans l'onglet « Permissions », coche account_info.read, files.metadata.read, files.content.read, "
    "files.content.write, file_requests.read, file_requests.write, sharing.read et sharing.write, puis clique sur « Submit ».\n\n"
    "Dans l'onglet « Settings », copie l'« App key » et colle-la ci-dessous."
)


def open_uri(widget, uri):
    Gtk.UriLauncher.new(uri).launch(widget.get_root(), None, None)


def copy_text(text):
    Gdk.Display.get_default().get_clipboard().set(text)


class ConnectDialog(Adw.Dialog):
    __gtype_name__ = "CasierConnectDialog"

    def __init__(self, client, on_connected):
        super().__init__(title="Connecter Dropbox", content_width=560, content_height=720)
        self.client = client
        self.on_connected = on_connected
        self.authorize_opened = False

        header = Adw.HeaderBar(show_start_title_buttons=False, show_end_title_buttons=False)
        cancel = Gtk.Button(label="Annuler")
        cancel.connect("clicked", lambda _b: self.close())
        header.pack_start(cancel)
        self.spinner = Gtk.Spinner()
        self.confirm = Gtk.Button(label="Connecter", css_classes=["suggested-action"])
        self.confirm.connect("clicked", self._connect)
        header.pack_end(self.confirm)
        header.pack_end(self.spinner)

        page = Adw.PreferencesPage()
        step1 = Adw.PreferencesGroup(title="1. Créer ton appli Dropbox", description=SETUP_STEPS)
        console = Gtk.Button(label="Ouvrir la console", valign=Gtk.Align.CENTER, css_classes=["flat"])
        console.connect("clicked", lambda b: open_uri(b, CONSOLE_URL))
        step1.set_header_suffix(console)
        self.key_row = Adw.EntryRow(title="App key")
        self.key_row.set_text(client.app_key)
        step1.add(self.key_row)
        page.add(step1)

        step2 = Adw.PreferencesGroup(title="2. Autoriser Casier",
                                     description="Connecte-toi à Dropbox dans le navigateur, accepte, puis copie le code affiché.")
        self.authorize_button = Gtk.Button(label="Ouvrir la page d'autorisation", halign=Gtk.Align.START, css_classes=["pill"])
        self.authorize_button.connect("clicked", self._authorize)
        step2.add(self.authorize_button)
        page.add(step2)

        step3 = Adw.PreferencesGroup(title="3. Coller le code")
        self.code_row = Adw.EntryRow(title="Code d'autorisation")
        step3.add(self.code_row)
        self.error_label = Gtk.Label(xalign=0, wrap=True, margin_top=12, css_classes=["error"], visible=False)
        step3.add(self.error_label)
        page.add(step3)

        toolbar = Adw.ToolbarView(content=page)
        toolbar.add_top_bar(header)
        self.set_child(toolbar)

        self.key_row.connect("changed", self._update)
        self.code_row.connect("changed", self._update)
        self._update()

    def _update(self, *_args):
        has_key = bool(self.key_row.get_text().strip())
        self.authorize_button.set_sensitive(has_key)
        self.confirm.set_sensitive(has_key and self.authorize_opened and bool(self.code_row.get_text().strip()))

    def _authorize(self, button):
        open_uri(button, self.client.authorize_url(self.key_row.get_text().strip()))
        self.authorize_opened = True
        self._update()

    def _connect(self, _button):
        self.confirm.set_sensitive(False)
        self.spinner.start()
        self.error_label.set_visible(False)
        self.client.finish_authorization(self.code_row.get_text(), self._finished)

    def _finished(self, label, error):
        self.spinner.stop()
        if error:
            self.error_label.set_label(str(error))
            self.error_label.set_visible(True)
            self._update()
            return
        self.on_connected(label)
        self.close()


class QrCode(Gtk.DrawingArea):
    __gtype_name__ = "CasierQrCode"

    def __init__(self, text):
        super().__init__(content_width=420, content_height=420, hexpand=True, vexpand=True)
        code = qrcode.QRCode(border=2, error_correction=qrcode.constants.ERROR_CORRECT_M)
        code.add_data(text)
        code.make(fit=True)
        self.matrix = code.get_matrix()
        self.set_draw_func(self._draw)

    def _draw(self, _area, cr, width, height):
        size = min(width, height)
        cells = len(self.matrix)
        cell = size / cells
        left = (width - size) / 2
        top = (height - size) / 2
        cr.set_source_rgb(1, 1, 1)
        cr.rectangle(left, top, size, size)
        cr.fill()
        cr.set_source_rgb(0, 0, 0)
        for y, line in enumerate(self.matrix):
            for x, dark in enumerate(line):
                if dark:
                    cr.rectangle(left + x * cell, top + y * cell, cell + 0.5, cell + 0.5)
        cr.fill()


class QrDialog(Adw.Dialog):
    __gtype_name__ = "CasierQrDialog"

    def __init__(self, title, url, instructions_url=None):
        both = instructions_url is not None
        super().__init__(title=title, content_width=1100 if both else 640, content_height=720)
        codes = Gtk.Box(spacing=48, homogeneous=True, vexpand=True)
        if both:
            codes.append(self._code("1. Lire les consignes", instructions_url))
            codes.append(self._code("2. Déposer ton travail", url))
        else:
            codes.append(self._code("Déposer ton travail", url))
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18, margin_top=12, margin_bottom=24, margin_start=24,
                      margin_end=24)
        box.append(codes)
        box.append(Gtk.Label(label="Flashe les codes avec l'appareil photo de ton téléphone." if both
                             else "Flashe ce code avec l'appareil photo de ton téléphone pour déposer ton travail.",
                             wrap=True, justify=Gtk.Justification.CENTER, css_classes=["title-4"]))
        toolbar = Adw.ToolbarView(content=box)
        toolbar.add_top_bar(Adw.HeaderBar())
        self.set_child(toolbar)

    @staticmethod
    def _code(label, url):
        column = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        column.append(Gtk.Label(label=label, css_classes=["title-1"]))
        column.append(QrCode(url))
        column.append(Gtk.Label(label=url, selectable=True, wrap=True, wrap_mode=Pango.WrapMode.CHAR, css_classes=["dim-label", "caption"]))
        return column
