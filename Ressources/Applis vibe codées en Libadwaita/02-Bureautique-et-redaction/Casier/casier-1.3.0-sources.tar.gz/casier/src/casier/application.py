import datetime
import os
import sqlite3

from gi.repository import Adw, Gdk, Gio, GLib, Gtk

from .backup import daily_backup
from .database import Database
from .dropbox import DropboxClient
from .sync import SyncRunner
from .window import CasierWindow, PreferencesDialog

APP_ID = "io.gitlab.shogu.Casier"
ICONS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "icons")
VERSION = "1.3.0"

CSS = """
.status-pill { padding: 2px 10px; border-radius: 999px; font-size: 0.85em; font-weight: 700; }
.status-ok { background-color: alpha(@success_color, 0.15); color: @success_color; }
.status-late { background-color: alpha(@warning_color, 0.18); color: @warning_color; }
.status-missing { background-color: alpha(@error_color, 0.12); color: @error_color; }
row.current-file { background-color: alpha(@accent_bg_color, 0.12); }
"""


class CasierApplication(Adw.Application):
    __gtype_name__ = "CasierApplication"

    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.DEFAULT_FLAGS)
        data_dir = os.path.join(GLib.get_user_data_dir(), "casier")
        self.backup_folder = os.path.join(data_dir, "sauvegardes")
        self.depots_folder = os.path.join(data_dir, "depots")
        self.db = Database(os.path.join(data_dir, "casier.db"))
        self.dropbox = DropboxClient(self.db)
        self.sync = SyncRunner(self.dropbox, self.db)

    def do_startup(self):
        Adw.Application.do_startup(self)
        provider = Gtk.CssProvider()
        provider.load_from_string(CSS)
        display = Gdk.Display.get_default()
        Gtk.StyleContext.add_provider_for_display(display, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        Gtk.IconTheme.get_for_display(display).add_search_path(ICONS_DIR)
        for name, callback, accels in (
            ("about", self._about, []),
            ("preferences", self._preferences, ["<Control>comma"]),
            ("backup", self._backup, []),
            ("restore", self._restore, []),
            ("quit", lambda *_a: self.quit(), ["<Control>q"]),
        ):
            action = Gio.SimpleAction.new(name, None)
            action.connect("activate", callback)
            self.add_action(action)
            self.set_accels_for_action(f"app.{name}", accels)
        daily_backup(self.db, self.backup_folder)

    def do_activate(self):
        window = self.get_active_window() or CasierWindow(self)
        window.present()

    def do_shutdown(self):
        self.dropbox.shutdown()
        daily_backup(self.db, self.backup_folder)
        self.db.close()
        Adw.Application.do_shutdown(self)

    def _about(self, *_args):
        dialog = Adw.AboutDialog(
            application_name="Casier",
            application_icon=APP_ID,
            version=VERSION,
            developer_name="Shogu",
            comments="Récupère, corrige et archive les devoirs déposés par les élèves dans une demande de fichiers Dropbox.",
        )
        dialog.present(self.get_active_window())

    def _preferences(self, *_args):
        PreferencesDialog(self).present(self.get_active_window())

    def _backup(self, *_args):
        name = f"Casier - sauvegarde du {datetime.date.today().strftime('%d-%m-%Y')}.db"
        Gtk.FileDialog(title="Sauvegarder la base", initial_name=name).save(self.get_active_window(), None, self._backup_chosen)

    def _backup_chosen(self, dialog, result):
        try:
            file = dialog.save_finish(result)
        except GLib.Error:
            return
        self.db.backup_to(file.get_path())
        self.get_active_window().toast("Base sauvegardée")

    def _restore(self, *_args):
        db_filter = Gtk.FileFilter(name="Bases Casier")
        db_filter.add_pattern("*.db")
        filters = Gio.ListStore.new(Gtk.FileFilter)
        filters.append(db_filter)
        dialog = Gtk.FileDialog(title="Restaurer une sauvegarde", filters=filters)
        if os.path.isdir(self.backup_folder):
            dialog.set_initial_folder(Gio.File.new_for_path(self.backup_folder))
        dialog.open(self.get_active_window(), None, self._restore_chosen)

    def _restore_chosen(self, dialog, result):
        try:
            path = dialog.open_finish(result).get_path()
        except GLib.Error:
            return
        alert = Adw.AlertDialog(
            heading="Restaurer cette sauvegarde ?",
            body=f"Le contenu actuel de Casier sera remplacé par « {os.path.basename(path)} ». "
                 "Une copie de l'état actuel est faite avant, dans le dossier des sauvegardes.",
        )
        alert.add_response("cancel", "Annuler")
        alert.add_response("restore", "Restaurer")
        alert.set_response_appearance("restore", Adw.ResponseAppearance.DESTRUCTIVE)
        alert.connect("response", self._restore_response, path)
        alert.present(self.get_active_window())

    def _restore_response(self, _dialog, response, path):
        if response != "restore":
            return
        window = self.get_active_window()
        stamp = datetime.datetime.now().strftime("%Y-%m-%d-%H%M%S")
        os.makedirs(self.backup_folder, exist_ok=True)
        self.db.backup_to(os.path.join(self.backup_folder, f"avant-restauration-{stamp}.db"))
        try:
            self.db.restore_from(path)
        except (ValueError, OSError, sqlite3.DatabaseError) as error:
            window.toast(str(error))
            return
        window.reload_after_restore()
        window.toast("Sauvegarde restaurée")
