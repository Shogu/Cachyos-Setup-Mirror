import datetime
import os
from dataclasses import dataclass

from gi.repository import GLib

from . import files
from .matching import Submissions, assign

ARCHIVE_SETTING = "archive-root"
ARCHIVE_SKIPPED = {"notes.csv"}


@dataclass
class AssignmentState:
    assignment: object
    school_class: object
    students: list
    submissions: Submissions
    grades: dict
    folder: str
    from_archive: bool

    @property
    def folder_exists(self):
        return os.path.isdir(self.folder)

    def counts(self):
        statuses = [files.status_of(self.submissions.files_for(s.id), self.assignment) for s in self.students]
        graded = sum(1 for s in self.students if s.id in self.grades and self.grades[s.id].grade is not None)
        return {
            "total": len(self.students),
            "rendu": statuses.count("rendu"),
            "en retard": statuses.count("en retard"),
            "manquant": statuses.count("manquant"),
            "notés": graded,
        }


def default_archive_root():
    documents = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOCUMENTS) or os.path.expanduser("~/Documents")
    return os.path.join(documents, "Casier")


def archive_root(db):
    return db.get_setting(ARCHIVE_SETTING, default_archive_root())


def archive_folder(db, school_class, assignment):
    return files.archive_destination(archive_root(db), school_class, assignment)


def load(db, assignment_id):
    assignment = db.get_assignment(assignment_id)
    school_class = db.get_class(assignment.class_id)
    students = db.students(assignment.class_id)
    folder = assignment.folder
    entries = files.scan(folder)
    from_archive = False
    if assignment.archived_at and not entries:
        archived = archive_folder(db, school_class, assignment)
        if os.path.isdir(archived):
            folder = archived
            entries = [e for e in files.scan(archived) if e.rel_path not in ARCHIVE_SKIPPED]
            from_archive = True
    overrides = {} if from_archive else db.overrides(assignment_id)
    submissions = assign(entries, students, overrides)
    return AssignmentState(assignment, school_class, students, submissions, db.grades(assignment_id), folder, from_archive)


def format_deposit(entries):
    if not entries:
        return "Pas encore rendu"
    moment = datetime.datetime.fromtimestamp(entries[0].mtime)
    text = moment.strftime("Déposé le %d/%m à %H:%M")
    if len(entries) > 1:
        text += f" · {len(entries)} fichiers"
    return text


def parse_grade(text, scale):
    cleaned = text.strip().replace(",", ".")
    if not cleaned:
        return None, True
    try:
        value = float(cleaned)
    except ValueError:
        return None, False
    return value, 0 <= value <= scale
