from gi.repository import Adw, Gio, GLib, Gtk, Pango

from . import cleanup, model
from .class_page import ClassPage
from .dialogs import ClassDialog
from .dropbox_ui import ConnectDialog


class CasierWindow(Adw.ApplicationWindow):
    __gtype_name__ = "CasierWindow"

    def __init__(self, application):
        super().__init__(application=application, title="Casier", default_width=1180, default_height=780,
                         width_request=360, height_request=420)
        self.db = application.db
        self.dropbox = application.dropbox
        self.sync = application.sync
        self.depots_folder = application.depots_folder
        self.selected_class_id = None
        self.row_class_ids = []

        self.class_list = Gtk.ListBox(css_classes=["navigation-sidebar"], selection_mode=Gtk.SelectionMode.SINGLE)
        self.class_list.connect("row-selected", self._class_selected)
        sidebar_header = Adw.HeaderBar()
        add_button = Gtk.Button(icon_name="list-add-symbolic", tooltip_text="Nouvelle classe")
        add_button.connect("clicked", lambda _b: self.new_class())
        sidebar_header.pack_start(add_button)
        sidebar_header.pack_end(self._primary_menu())
        self.sidebar_stack = Gtk.Stack()
        self.sidebar_stack.add_named(Gtk.ScrolledWindow(child=self.class_list, hscrollbar_policy=Gtk.PolicyType.NEVER), "list")
        self.sidebar_stack.add_named(Adw.StatusPage(icon_name="io.gitlab.shogu.Casier-symbolic", title="Aucune classe",
                                                    css_classes=["compact"]), "empty")
        sidebar_toolbar = Adw.ToolbarView(content=self.sidebar_stack)
        sidebar_toolbar.add_top_bar(sidebar_header)
        sidebar = Adw.NavigationPage(title="Casier", child=sidebar_toolbar)

        self.content_view = Adw.NavigationView()
        content = Adw.NavigationPage(title="Classe", child=self.content_view)

        self.split_view = Adw.NavigationSplitView(sidebar=sidebar, content=content, min_sidebar_width=220, max_sidebar_width=300)
        self.toasts = Adw.ToastOverlay(child=self.split_view)
        self.set_content(self.toasts)

        narrow = Adw.Breakpoint.new(Adw.BreakpointCondition.parse("max-width: 640sp"))
        narrow.add_setter(self.split_view, "collapsed", True)
        self.add_breakpoint(narrow)

        self.refresh_classes()

    def _primary_menu(self):
        menu = Gio.Menu()
        data = Gio.Menu()
        data.append("Sauvegarder la base…", "app.backup")
        data.append("Restaurer une sauvegarde…", "app.restore")
        menu.append_section(None, data)
        about = Gio.Menu()
        about.append("Préférences", "app.preferences")
        about.append("À propos de Casier", "app.about")
        menu.append_section(None, about)
        return Gtk.MenuButton(icon_name="open-menu-symbolic", menu_model=menu, primary=True, tooltip_text="Menu principal")

    def toast(self, message):
        self.toasts.add_toast(Adw.Toast(title=message, timeout=3))

    def push(self, page):
        self.content_view.push(page)
        self.split_view.set_show_content(True)

    def pop(self):
        self.content_view.pop()

    def refresh_classes(self):
        classes = self.db.classes()
        known = {c.id for c in classes}
        if self.selected_class_id not in known:
            self.selected_class_id = None
        self.class_list.remove_all()
        self.row_class_ids = [c.id for c in classes]
        selected_row = None
        for school_class in classes:
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
            box.append(Gtk.Label(label=school_class.name, xalign=0, ellipsize=Pango.EllipsizeMode.END))
            box.append(Gtk.Label(label=school_class.school_year, xalign=0, css_classes=["caption", "dim-label"]))
            row = Gtk.ListBoxRow(child=box)
            self.class_list.append(row)
            if school_class.id == self.selected_class_id:
                selected_row = row
        self.sidebar_stack.set_visible_child_name("list" if classes else "empty")
        if selected_row is not None:
            self.class_list.select_row(selected_row)
        elif classes:
            self.class_list.select_row(self.class_list.get_row_at_index(0))
        else:
            self._show_welcome()

    def _show_welcome(self):
        button = Gtk.Button(label="Créer une classe", halign=Gtk.Align.CENTER, css_classes=["pill", "suggested-action"])
        button.connect("clicked", lambda _b: self.new_class())
        status = Adw.StatusPage(icon_name="io.gitlab.shogu.Casier", title="Bienvenue dans Casier",
                                description="Crée une classe, importe la liste des élèves, puis relie chaque devoir au dossier "
                                            "de ta demande de fichiers Dropbox.", child=button)
        toolbar = Adw.ToolbarView(content=status)
        toolbar.add_top_bar(Adw.HeaderBar(show_title=False))
        self.content_view.replace([Adw.NavigationPage(title="Casier", child=toolbar)])

    def _class_selected(self, _listbox, row):
        if row is None:
            return
        class_id = self.row_class_ids[row.get_index()]
        root = self.content_view.get_navigation_stack().get_item(0)
        if not (isinstance(root, ClassPage) and root.class_id == class_id):
            self.selected_class_id = class_id
            self.content_view.replace([ClassPage(self, class_id)])
        self.split_view.set_show_content(True)

    def new_class(self):
        ClassDialog(self._class_created).present(self)

    def _class_created(self, name, school_year):
        self.selected_class_id = self.db.add_class(name, school_year)
        self.refresh_classes()
        root = self.content_view.get_navigation_stack().get_item(0)
        if isinstance(root, ClassPage):
            root.import_students()

    def reload_after_restore(self):
        self.selected_class_id = None
        self._show_welcome()
        self.refresh_classes()


class PreferencesDialog(Adw.PreferencesDialog):
    __gtype_name__ = "CasierPreferencesDialog"

    def __init__(self, application):
        super().__init__(title="Préférences")
        self.db = application.db
        self.client = application.dropbox
        backup_folder = application.backup_folder
        page = Adw.PreferencesPage(title="Général", icon_name="preferences-system-symbolic")
        archives = Adw.PreferencesGroup(title="Archives", description="Dossier où Casier range les copies et les notes des devoirs archivés.")
        self.archive_row = Adw.ActionRow(title="Dossier des archives", activatable=True)
        self.archive_row.add_suffix(Gtk.Image(icon_name="folder-open-symbolic"))
        self.archive_row.connect("activated", self._choose_archive)
        archives.add(self.archive_row)
        page.add(archives)
        dropbox = Adw.PreferencesGroup(title="Dropbox",
                                       description="Casier crée lui-même les liens de dépôt et récupère les copies en ligne.")
        self.account_row = Adw.ActionRow(title="Compte Dropbox")
        self.account_button = Gtk.Button(valign=Gtk.Align.CENTER)
        self.account_button.connect("clicked", self._account_clicked)
        self.account_row.add_suffix(self.account_button)
        dropbox.add(self.account_row)
        self.years = application.db.school_years()
        self.year_row = Adw.ComboRow(title="Nettoyer une année", subtitle="Supprime le dossier Casier de l'année dans Dropbox",
                                     model=Gtk.StringList.new(self.years))
        clean = Gtk.Button(label="Nettoyer…", valign=Gtk.Align.CENTER, css_classes=["destructive-action"])
        clean.connect("clicked", self._clean_year)
        self.year_row.add_suffix(clean)
        dropbox.add(self.year_row)
        page.add(dropbox)
        backups = Adw.PreferencesGroup(title="Sauvegardes automatiques",
                                       description="Une copie de la base est faite chaque jour d'utilisation. Les 30 dernières sont gardées.")
        backup_row = Adw.ActionRow(title="Dossier des sauvegardes", subtitle=backup_folder, activatable=True)
        backup_row.add_suffix(Gtk.Image(icon_name="folder-open-symbolic"))
        backup_row.connect("activated", lambda _r: Gtk.FileLauncher.new(Gio.File.new_for_path(backup_folder)).launch(self.get_root(), None, None))
        backups.add(backup_row)
        page.add(backups)
        self.add(page)
        self._update()

    def _update(self):
        self.archive_row.set_subtitle(model.archive_root(self.db))
        connected = self.client.connected
        self.account_row.set_subtitle(self.client.account_label if connected else "Non connecté")
        self.account_button.set_label("Déconnecter" if connected else "Connecter")
        self.account_button.set_css_classes(["flat"] if connected else ["suggested-action"])
        self.year_row.set_visible(connected and bool(self.years))

    def _clean_year(self, _button):
        year = self.years[self.year_row.get_selected()]
        dialog = Adw.AlertDialog(
            heading=f"Nettoyer l'année {year} dans Dropbox ?",
            body=f"Les demandes de fichiers de l'année sont supprimées, ainsi que « {cleanup.year_folder(year)} » "
                 "(copies et consignes). Pense à archiver tes devoirs avant. Dans Casier, les classes, notes et copies déjà "
                 "récupérées restent. Tout reste récupérable 30 jours dans les fichiers supprimés de Dropbox.",
        )
        dialog.add_response("cancel", "Annuler")
        dialog.add_response("clean", "Nettoyer")
        dialog.set_response_appearance("clean", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.connect("response", self._clean_year_response, year)
        dialog.present(self)

    def _clean_year_response(self, _dialog, response, year):
        if response != "clean":
            return
        assignments = [a for c in self.db.classes() if c.school_year == year for a in self.db.assignments(c.id) if a.on_dropbox]
        operations = [op for a in assignments for op in cleanup.request_operations(a)]
        operations.append(("files/delete_v2", {"path": cleanup.year_folder(year)}))
        for assignment in assignments:
            self.db.detach_dropbox(assignment.id)
        self.add_toast(Adw.Toast(title="Nettoyage de Dropbox…"))
        cleanup.run(self.client, operations, self._year_cleaned)

    def _year_cleaned(self, error):
        self.add_toast(Adw.Toast(title=f"Dropbox n'a pas pu être nettoyé : {error}" if error else "Année nettoyée dans Dropbox"))

    def _account_clicked(self, _button):
        if self.client.connected:
            self.client.disconnect(lambda *_a: self._update())
        else:
            ConnectDialog(self.client, lambda _label: self._update()).present(self)

    def _choose_archive(self, _row):
        dialog = Gtk.FileDialog(title="Dossier des archives")
        dialog.select_folder(self.get_root(), None, self._archive_chosen)

    def _archive_chosen(self, dialog, result):
        try:
            folder = dialog.select_folder_finish(result)
        except GLib.Error:
            return
        self.db.set_setting(model.ARCHIVE_SETTING, folder.get_path())
        self._update()
