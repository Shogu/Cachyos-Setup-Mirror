import csv
import datetime
import os
import shutil

from gi.repository import Gio

from .matching import FileEntry, safe_file_part

SKIPPED_NAMES = {"desktop.ini", "thumbs.db", ".ds_store", "icon\r"}
SKIPPED_PREFIXES = (".", "~$", ".~lock")
MAX_DEPTH = 3


def scan(folder):
    entries = []
    if not os.path.isdir(folder):
        return entries
    base_depth = folder.rstrip(os.sep).count(os.sep)
    for root, dirs, names in os.walk(folder):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        if root.count(os.sep) - base_depth >= MAX_DEPTH:
            dirs[:] = []
        for name in names:
            if name.startswith(SKIPPED_PREFIXES) or name.lower() in SKIPPED_NAMES:
                continue
            path = os.path.join(root, name)
            stat = os.stat(path)
            entries.append(FileEntry(os.path.relpath(path, folder), path, stat.st_mtime, stat.st_size))
    entries.sort(key=lambda e: e.rel_path.lower())
    return entries


def target_name(student, assignment_title, extension, index):
    parts = [safe_file_part(student.last_name).upper(), safe_file_part(student.first_name), safe_file_part(assignment_title)]
    stem = "_".join(p for p in parts if p)
    suffix = f"_{index}" if index > 1 else ""
    return f"{stem}{suffix}{extension.lower()}"


def planned_names(submissions, students, assignment_title):
    plan = []
    by_id = {s.id: s for s in students}
    for student_id, entries in submissions.by_student.items():
        student = by_id[student_id]
        for index, entry in enumerate(entries, start=1):
            extension = os.path.splitext(entry.path)[1]
            plan.append((entry, student, target_name(student, assignment_title, extension, index)))
    return plan


def rename_all(folder, submissions, students, assignment_title):
    renamed = []
    for entry, _student, new_name in planned_names(submissions, students, assignment_title):
        directory = os.path.dirname(entry.path)
        if os.path.basename(entry.path) == new_name:
            continue
        destination = _free_path(os.path.join(directory, new_name))
        os.rename(entry.path, destination)
        renamed.append((entry.rel_path, os.path.relpath(destination, folder)))
    return renamed


def _free_path(path):
    if not os.path.exists(path):
        return path
    stem, extension = os.path.splitext(path)
    counter = 2
    while os.path.exists(f"{stem}-{counter}{extension}"):
        counter += 1
    return f"{stem}-{counter}{extension}"


def format_grade(grade):
    if grade is None:
        return ""
    return f"{grade:g}".replace(".", ",")


def status_of(entries, assignment):
    if not entries:
        return "manquant"
    deadline = assignment.deadline
    if deadline is not None and entries[0].mtime > deadline:
        return "en retard"
    return "rendu"


def write_grades_csv(path, assignment, students, submissions, grades):
    with open(path, "w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.writer(handle, delimiter=";")
        writer.writerow(["Nom", "Prénom", "Statut", "Date de dépôt", f"Note /{assignment.scale:g}", "Appréciation", "Fichiers"])
        for student in students:
            entries = submissions.files_for(student.id)
            grade = grades.get(student.id)
            deposit = datetime.datetime.fromtimestamp(entries[0].mtime).strftime("%d/%m/%Y %H:%M") if entries else ""
            writer.writerow([
                student.last_name,
                student.first_name,
                status_of(entries, assignment),
                deposit,
                format_grade(grade.grade) if grade else "",
                grade.comment if grade else "",
                " | ".join(e.rel_path for e in entries),
            ])


def archive(destination, assignment, students, submissions, grades):
    if os.path.isdir(destination):
        shutil.rmtree(destination)
    os.makedirs(destination)
    plan = planned_names(submissions, students, assignment.title)
    for entry, _student, new_name in plan:
        shutil.copy2(entry.path, _free_path(os.path.join(destination, new_name)))
    unassigned_dir = os.path.join(destination, "Non attribués")
    for entry in submissions.unassigned:
        os.makedirs(unassigned_dir, exist_ok=True)
        shutil.copy2(entry.path, _free_path(os.path.join(unassigned_dir, os.path.basename(entry.path))))
    write_grades_csv(os.path.join(destination, "notes.csv"), assignment, students, submissions, grades)
    return shutil.make_archive(destination, "zip", root_dir=destination)


def archive_destination(root, school_class, assignment):
    return os.path.join(root, safe_file_part(school_class.school_year), safe_file_part(school_class.name), safe_file_part(assignment.title))


def trash_files(entries):
    for entry in entries:
        Gio.File.new_for_path(entry.path).trash(None)
