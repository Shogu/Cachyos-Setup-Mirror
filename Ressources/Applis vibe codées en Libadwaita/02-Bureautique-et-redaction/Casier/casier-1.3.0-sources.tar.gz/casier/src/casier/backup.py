import datetime
import os

KEEP = 30


def daily_backup(database, folder):
    os.makedirs(folder, exist_ok=True)
    target = os.path.join(folder, f"casier-{datetime.date.today().isoformat()}.db")
    database.backup_to(target)
    backups = sorted(name for name in os.listdir(folder) if name.startswith("casier-") and name.endswith(".db"))
    for name in backups[:-KEEP]:
        os.remove(os.path.join(folder, name))
    return target
