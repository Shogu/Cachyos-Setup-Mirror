import datetime
import os

from gi.repository import Adw, Gio, GLib, Gtk

from . import files, model
from .matching import UNASSIGNED
from .preview import Preview, open_file

COMMENT_SAVE_DELAY_MS = 500


class CorrectionPage(Adw.NavigationPage):
    __gtype_name__ = "CasierCorrectionPage"

    def __init__(self, window, assignment_id, student_ids, index):
        super().__init__(title="Correction")
        self.window = window
        self.db = window.db
        self.assignment_id = assignment_id
        self.student_ids = student_ids
        self.index = index
        self.state = None
        self.current_file = None
        self.comment_source = 0
        self.loading = False

        self.window_title = Adw.WindowTitle()
        header = Adw.HeaderBar(title_widget=self.window_title)
        self.prev_button = Gtk.Button(icon_name="go-previous-symbolic", tooltip_text="Élève précédent (Ctrl+Page précédente)")
        self.next_button = Gtk.Button(icon_name="go-next-symbolic", tooltip_text="Élève suivant (Ctrl+Page suivante)")
        self.prev_button.connect("clicked", lambda _b: self._step(-1))
        self.next_button.connect("clicked", lambda _b: self._step(1))
        arrows = Gtk.Box(css_classes=["linked"])
        arrows.append(self.prev_button)
        arrows.append(self.next_button)
        header.pack_end(arrows)
        self.open_button = Gtk.Button(icon_name="document-open-symbolic", tooltip_text="Ouvrir avec une autre application")
        self.open_button.connect("clicked", lambda _b: open_file(self.get_root(), Gio.File.new_for_path(self.current_file.path)))
        header.pack_end(self.open_button)

        self.preview = Preview()
        self.side = self._build_side()
        self.paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL, start_child=self.preview, end_child=self.side,
                               resize_start_child=True, shrink_start_child=False, resize_end_child=False, shrink_end_child=False,
                               wide_handle=True)
        bin_ = Adw.BreakpointBin(width_request=360, height_request=360, child=self.paned)
        narrow = Adw.Breakpoint.new(Adw.BreakpointCondition.parse("max-width: 760sp"))
        narrow.add_setter(self.paned, "orientation", Gtk.Orientation.VERTICAL)
        bin_.add_breakpoint(narrow)

        toolbar = Adw.ToolbarView(content=bin_)
        toolbar.add_top_bar(header)
        self.set_child(toolbar)

        shortcuts = Gtk.ShortcutController(scope=Gtk.ShortcutScope.MANAGED)
        shortcuts.add_shortcut(Gtk.Shortcut(trigger=Gtk.ShortcutTrigger.parse_string("<Control>Page_Down"),
                                            action=Gtk.CallbackAction.new(lambda *_a: self._step(1) or True)))
        shortcuts.add_shortcut(Gtk.Shortcut(trigger=Gtk.ShortcutTrigger.parse_string("<Control>Page_Up"),
                                            action=Gtk.CallbackAction.new(lambda *_a: self._step(-1) or True)))
        self.add_controller(shortcuts)

        self.connect("showing", lambda _p: self.load())
        self.connect("hidden", lambda _p: self._flush_comment())

    def _build_side(self):
        page = Adw.PreferencesPage(width_request=340)
        self.files_group = Adw.PreferencesGroup(title="Fichiers rendus")
        page.add(self.files_group)
        self.file_rows = []

        evaluation = Adw.PreferencesGroup(title="Évaluation")
        self.grade_row = Adw.EntryRow(input_purpose=Gtk.InputPurpose.NUMBER)
        self.grade_row.connect("changed", self._grade_changed)
        evaluation.add(self.grade_row)
        page.add(evaluation)

        comment_group = Adw.PreferencesGroup(title="Appréciation")
        self.comment_view = Gtk.TextView(wrap_mode=Gtk.WrapMode.WORD_CHAR, top_margin=10, bottom_margin=10, left_margin=12,
                                         right_margin=12, accepts_tab=False)
        self.comment_view.get_buffer().connect("changed", self._comment_changed)
        comment_group.add(Gtk.ScrolledWindow(child=self.comment_view, min_content_height=160, css_classes=["card"]))
        page.add(comment_group)
        return page

    @property
    def student(self):
        student_id = self.student_ids[self.index]
        return next(s for s in self.state.students if s.id == student_id)

    def load(self):
        current = self.student_ids[self.index]
        self.state = model.load(self.db, self.assignment_id)
        self.student_ids = [s.id for s in self.state.students]
        self.index = self.student_ids.index(current) if current in self.student_ids else min(self.index, len(self.student_ids) - 1)
        student = self.student
        scale = self.state.assignment.scale
        self.set_title(student.display_name)
        self.window_title.set_title(student.display_name)
        self.window_title.set_subtitle(f"{self.state.assignment.title} · {self.index + 1} sur {len(self.student_ids)}")
        self.prev_button.set_sensitive(self.index > 0)
        self.next_button.set_sensitive(self.index < len(self.student_ids) - 1)

        grade = self.db.get_grade(self.assignment_id, student.id)
        self.loading = True
        self.grade_row.set_title(f"Note sur {scale:g}")
        self.grade_row.set_text(files.format_grade(grade.grade))
        self.grade_row.remove_css_class("error")
        self.comment_view.get_buffer().set_text(grade.comment)
        self.loading = False

        entries = self.state.submissions.files_for(student.id)
        self._fill_files(entries)
        self._show_entry(entries[0] if entries else None)

    def _fill_files(self, entries):
        for row in self.file_rows:
            self.files_group.remove(row)
        self.file_rows = []
        if not entries:
            row = Adw.ActionRow(title="Aucun fichier rendu", subtitle="Tu peux quand même saisir une note")
            self.files_group.add(row)
            self.file_rows.append(row)
            return
        for entry in entries:
            moment = datetime.datetime.fromtimestamp(entry.mtime).strftime("%d/%m à %H:%M")
            row = Adw.ActionRow(title=os.path.basename(entry.rel_path), subtitle=moment, activatable=True, use_markup=False)
            row.connect("activated", lambda _r, e=entry: self._show_entry(e))
            if not self.state.from_archive:
                wrong = Gtk.Button(icon_name="edit-clear-symbolic", valign=Gtk.Align.CENTER, css_classes=["flat"],
                                   tooltip_text="Ce fichier n'est pas à cet élève")
                wrong.connect("clicked", self._detach_file, entry)
                row.add_suffix(wrong)
            self.files_group.add(row)
            self.file_rows.append(row)

    def _show_entry(self, entry):
        self.current_file = entry
        self.open_button.set_sensitive(entry is not None)
        for row, candidate in zip(self.file_rows, self.state.submissions.files_for(self.student.id)):
            if candidate is entry:
                row.add_css_class("current-file")
            else:
                row.remove_css_class("current-file")
        if entry is None:
            self.preview.clear("Pas de copie", "Cet élève n'a encore rien déposé.")
        else:
            self.preview.show_file(entry.path)

    def _detach_file(self, _button, entry):
        self.db.set_override(self.assignment_id, entry.rel_path, UNASSIGNED)
        self.window.toast(f"« {os.path.basename(entry.rel_path)} » est repassé dans les fichiers non attribués")
        self.load()

    def _step(self, delta):
        target = self.index + delta
        if not 0 <= target < len(self.student_ids):
            return
        self._flush_comment()
        self.index = target
        self.load()

    def _grade_changed(self, row):
        if self.loading:
            return
        value, valid = model.parse_grade(row.get_text(), self.state.assignment.scale)
        if not valid:
            row.add_css_class("error")
            return
        row.remove_css_class("error")
        self.db.set_grade(self.assignment_id, self.student.id, value)

    def _comment_changed(self, _buffer):
        if self.loading:
            return
        if self.comment_source:
            GLib.source_remove(self.comment_source)
        self.comment_source = GLib.timeout_add(COMMENT_SAVE_DELAY_MS, self._comment_timeout)

    def _comment_timeout(self):
        self.comment_source = 0
        self._save_comment()
        return GLib.SOURCE_REMOVE

    def _flush_comment(self):
        if not self.comment_source:
            return
        GLib.source_remove(self.comment_source)
        self.comment_source = 0
        self._save_comment()

    def _save_comment(self):
        buffer = self.comment_view.get_buffer()
        text = buffer.get_text(buffer.get_start_iter(), buffer.get_end_iter(), False).strip()
        self.db.set_comment(self.assignment_id, self.student.id, text)
