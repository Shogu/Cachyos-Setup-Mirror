import zipfile
from xml.etree import ElementTree

from gi.repository import Adw, Gio, GLib, Graphene, Gtk, Poppler

TEXT_LIMIT = 512 * 1024
OFFICE_TEXT = {
    ".docx": ("word/document.xml", "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}", "p", "t"),
    ".odt": ("content.xml", "{urn:oasis:names:tc:opendocument:xmlns:text:1.0}", None, None),
}


def office_text(path):
    extension = path[path.rfind("."):].lower()
    member, namespace, paragraph_tag, text_tag = OFFICE_TEXT[extension]
    with zipfile.ZipFile(path) as archive:
        root = ElementTree.fromstring(archive.read(member))
    if paragraph_tag is None:
        paragraphs = (node for node in root.iter() if node.tag in (f"{namespace}p", f"{namespace}h"))
        return "\n\n".join("".join(p.itertext()) for p in paragraphs).strip()
    lines = []
    for paragraph in root.iter(f"{namespace}{paragraph_tag}"):
        lines.append("".join(node.text or "" for node in paragraph.iter(f"{namespace}{text_tag}")))
    return "\n\n".join(line for line in lines if line.strip())


class PdfPage(Gtk.Widget):
    __gtype_name__ = "CasierPdfPage"

    def __init__(self, page):
        super().__init__(hexpand=True, css_classes=["card"], overflow=Gtk.Overflow.HIDDEN)
        self.page = page
        self.page_width, self.page_height = page.get_size()

    def do_get_request_mode(self):
        return Gtk.SizeRequestMode.HEIGHT_FOR_WIDTH

    def do_measure(self, orientation, for_size):
        if orientation == Gtk.Orientation.HORIZONTAL:
            return 120, int(self.page_width), -1, -1
        width = for_size if for_size > 0 else self.page_width
        height = int(width * self.page_height / self.page_width)
        return height, height, -1, -1

    def do_snapshot(self, snapshot):
        width = self.get_width()
        height = self.get_height()
        cr = snapshot.append_cairo(Graphene.Rect().init(0, 0, width, height))
        cr.set_source_rgb(1, 1, 1)
        cr.paint()
        scale = width / self.page_width
        cr.scale(scale, scale)
        self.page.render(cr)


class Preview(Adw.Bin):
    __gtype_name__ = "CasierPreview"

    def __init__(self):
        super().__init__(hexpand=True, vexpand=True)

    def show_file(self, path):
        file = Gio.File.new_for_path(path)
        info = file.query_info("standard::content-type,standard::size", Gio.FileQueryInfoFlags.NONE, None)
        content_type = info.get_content_type()
        if Gio.content_type_is_a(content_type, "application/pdf"):
            self.set_child(self._pdf(file))
        elif content_type.startswith("image/"):
            self.set_child(Gtk.Picture(file=file, content_fit=Gtk.ContentFit.CONTAIN, margin_top=12, margin_bottom=12))
        elif content_type.startswith(("video/", "audio/")):
            self.set_child(Gtk.Video(file=file, autoplay=False, margin_top=12, margin_bottom=12, margin_start=12, margin_end=12))
        elif Gio.content_type_is_a(content_type, "text/plain") and info.get_size() <= TEXT_LIMIT:
            _ok, contents, _etag = file.load_contents(None)
            self.set_child(self._text(contents.decode("utf-8", errors="replace"), monospace=True))
        elif path.lower().endswith(tuple(OFFICE_TEXT)):
            self.set_child(self._office(file, path, content_type))
        else:
            self.set_child(self._unsupported(file, content_type))

    def clear(self, title, description):
        self.set_child(Adw.StatusPage(icon_name="folder-documents-symbolic", title=title, description=description))

    def _pdf(self, file):
        try:
            document = Poppler.Document.new_from_gfile(file, None, None)
        except GLib.Error as error:
            return Adw.StatusPage(icon_name="dialog-warning-symbolic", title="PDF illisible", description=error.message)
        pages = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin_top=12, margin_bottom=12, margin_start=12, margin_end=12)
        for index in range(document.get_n_pages()):
            pages.append(PdfPage(document.get_page(index)))
        clamp = Adw.Clamp(maximum_size=1000, child=pages)
        return Gtk.ScrolledWindow(child=clamp, hscrollbar_policy=Gtk.PolicyType.NEVER)

    def _text(self, text, monospace=False):
        view = Gtk.TextView(editable=False, cursor_visible=False, monospace=monospace, wrap_mode=Gtk.WrapMode.WORD_CHAR,
                            top_margin=24, bottom_margin=24, left_margin=28, right_margin=28, css_classes=["card"])
        view.get_buffer().set_text(text)
        clamp = Adw.Clamp(maximum_size=900, child=view, margin_top=12, margin_bottom=12, margin_start=12, margin_end=12)
        return Gtk.ScrolledWindow(child=clamp, hscrollbar_policy=Gtk.PolicyType.NEVER)

    def _office(self, file, path, content_type):
        try:
            text = office_text(path)
        except (zipfile.BadZipFile, KeyError, ElementTree.ParseError):
            return self._unsupported(file, content_type)
        banner = Adw.Banner(title="Aperçu du texte seul, sans la mise en page", button_label="Ouvrir le document", revealed=True)
        banner.connect("button-clicked", lambda b: open_file(b.get_root(), file))
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        box.append(banner)
        scrolled = self._text(text or "(document vide)")
        scrolled.set_vexpand(True)
        box.append(scrolled)
        return box

    def _unsupported(self, file, content_type):
        button = Gtk.Button(label="Ouvrir avec l'application par défaut", halign=Gtk.Align.CENTER, css_classes=["pill", "suggested-action"])
        button.connect("clicked", lambda b: open_file(b.get_root(), file))
        description = Gio.content_type_get_description(content_type)
        return Adw.StatusPage(icon_name="x-office-document-symbolic", title="Pas d'aperçu pour ce type de fichier", description=description, child=button)


def open_file(window, file):
    Gtk.FileLauncher.new(file).launch(window, None, None)


def open_folder(window, path):
    Gtk.FileLauncher.new(Gio.File.new_for_path(path)).launch(window, None, None)
