import datetime
import os
import sqlite3
from dataclasses import dataclass

from .matching import Student, sort_key

SCHEMA = """
CREATE TABLE IF NOT EXISTS classes (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    school_year TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY,
    class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
    last_name TEXT NOT NULL,
    first_name TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS assignments (
    id INTEGER PRIMARY KEY,
    class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    folder TEXT NOT NULL,
    due_date TEXT,
    scale REAL NOT NULL DEFAULT 20,
    archived_at TEXT
);
CREATE TABLE IF NOT EXISTS overrides (
    assignment_id INTEGER NOT NULL REFERENCES assignments(id) ON DELETE CASCADE,
    rel_path TEXT NOT NULL,
    student_id INTEGER NOT NULL,
    PRIMARY KEY (assignment_id, rel_path)
);
CREATE TABLE IF NOT EXISTS grades (
    assignment_id INTEGER NOT NULL REFERENCES assignments(id) ON DELETE CASCADE,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    grade REAL,
    comment TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (assignment_id, student_id)
);
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""


DROPBOX_COLUMNS = (
    ("dropbox_path", "TEXT"),
    ("request_id", "TEXT"),
    ("request_url", "TEXT"),
    ("request_open", "INTEGER NOT NULL DEFAULT 0"),
    ("last_sync", "TEXT"),
    ("instructions", "TEXT NOT NULL DEFAULT ''"),
    ("instructions_path", "TEXT"),
    ("instructions_url", "TEXT"),
)


@dataclass
class SchoolClass:
    id: int
    name: str
    school_year: str


@dataclass
class Assignment:
    id: int
    class_id: int
    title: str
    folder: str
    due_date: str | None
    scale: float
    archived_at: str | None
    dropbox_path: str | None = None
    request_id: str | None = None
    request_url: str | None = None
    request_open: bool = False
    last_sync: str | None = None
    instructions: str = ""
    instructions_path: str | None = None
    instructions_url: str | None = None

    @property
    def on_dropbox(self):
        return self.request_id is not None

    @property
    def deadline(self):
        if not self.due_date:
            return None
        day = datetime.date.fromisoformat(self.due_date)
        return datetime.datetime.combine(day, datetime.time(23, 59, 59)).timestamp()


@dataclass
class Grade:
    grade: float | None
    comment: str


def current_school_year(today=None):
    today = today or datetime.date.today()
    start = today.year if today.month >= 8 else today.year - 1
    return f"{start}-{start + 1}"


class Database:
    def __init__(self, path):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self._open()

    def _open(self):
        self.conn = sqlite3.connect(self.path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.executescript(SCHEMA)
        self._migrate()
        self.conn.commit()

    def _migrate(self):
        columns = {row["name"] for row in self.conn.execute("PRAGMA table_info(assignments)")}
        for name, kind in DROPBOX_COLUMNS:
            if name not in columns:
                self.conn.execute(f"ALTER TABLE assignments ADD COLUMN {name} {kind}")

    def close(self):
        self.conn.close()

    def backup_to(self, target):
        destination = sqlite3.connect(target)
        with destination:
            self.conn.backup(destination)
        destination.close()

    def restore_from(self, source):
        check = sqlite3.connect(source)
        tables = {row[0] for row in check.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
        if not {"classes", "students", "assignments"} <= tables:
            check.close()
            raise ValueError("Ce fichier n'est pas une base Casier.")
        with self.conn:
            check.backup(self.conn)
        check.close()
        self.conn.executescript(SCHEMA)
        self._migrate()

    def _write(self, sql, params=()):
        with self.conn:
            return self.conn.execute(sql, params)

    def get_setting(self, key, default):
        row = self.conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
        return row["value"] if row else default

    def set_setting(self, key, value):
        self._write("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, value))

    def classes(self):
        rows = self.conn.execute("SELECT * FROM classes ORDER BY school_year DESC, name COLLATE NOCASE")
        return [SchoolClass(r["id"], r["name"], r["school_year"]) for r in rows]

    def get_class(self, class_id):
        r = self.conn.execute("SELECT * FROM classes WHERE id = ?", (class_id,)).fetchone()
        return SchoolClass(r["id"], r["name"], r["school_year"])

    def add_class(self, name, school_year):
        return self._write("INSERT INTO classes (name, school_year) VALUES (?, ?)", (name, school_year)).lastrowid

    def update_class(self, class_id, name, school_year):
        self._write("UPDATE classes SET name = ?, school_year = ? WHERE id = ?", (name, school_year, class_id))

    def delete_class(self, class_id):
        self._write("DELETE FROM classes WHERE id = ?", (class_id,))

    def students(self, class_id):
        rows = self.conn.execute("SELECT * FROM students WHERE class_id = ?", (class_id,))
        students = [Student(r["id"], r["last_name"], r["first_name"]) for r in rows]
        return sorted(students, key=sort_key)

    def add_students(self, class_id, names):
        with self.conn:
            self.conn.executemany(
                "INSERT INTO students (class_id, last_name, first_name) VALUES (?, ?, ?)",
                [(class_id, last, first) for last, first in names],
            )

    def update_student(self, student_id, last_name, first_name):
        self._write("UPDATE students SET last_name = ?, first_name = ? WHERE id = ?", (last_name, first_name, student_id))

    def delete_student(self, student_id):
        self._write("DELETE FROM students WHERE id = ?", (student_id,))

    def assignments(self, class_id):
        rows = self.conn.execute(
            "SELECT * FROM assignments WHERE class_id = ? ORDER BY archived_at IS NOT NULL, due_date IS NULL, due_date DESC, id DESC",
            (class_id,),
        )
        return [self._assignment(r) for r in rows]

    def get_assignment(self, assignment_id):
        return self._assignment(self.conn.execute("SELECT * FROM assignments WHERE id = ?", (assignment_id,)).fetchone())

    @staticmethod
    def _assignment(r):
        return Assignment(r["id"], r["class_id"], r["title"], r["folder"], r["due_date"], r["scale"], r["archived_at"],
                          r["dropbox_path"], r["request_id"], r["request_url"], bool(r["request_open"]), r["last_sync"],
                          r["instructions"], r["instructions_path"], r["instructions_url"])

    def add_assignment(self, class_id, title, folder, due_date, scale):
        sql = "INSERT INTO assignments (class_id, title, folder, due_date, scale) VALUES (?, ?, ?, ?, ?)"
        return self._write(sql, (class_id, title, folder, due_date, scale)).lastrowid

    def set_dropbox_request(self, assignment_id, folder, dropbox_path, request):
        sql = "UPDATE assignments SET folder = ?, dropbox_path = ?, request_id = ?, request_url = ?, request_open = ? WHERE id = ?"
        self._write(sql, (folder, dropbox_path, request["id"], request["url"], int(request["is_open"]), assignment_id))

    def set_instructions(self, assignment_id, text):
        self._write("UPDATE assignments SET instructions = ? WHERE id = ?", (text, assignment_id))

    def set_instructions_document(self, assignment_id, path, url):
        self._write("UPDATE assignments SET instructions_path = ?, instructions_url = ? WHERE id = ?", (path, url, assignment_id))

    def detach_dropbox(self, assignment_id):
        sql = (
            "UPDATE assignments SET dropbox_path = NULL, request_id = NULL, request_url = NULL, request_open = 0, "
            "instructions_path = NULL, instructions_url = NULL WHERE id = ?"
        )
        self._write(sql, (assignment_id,))

    def school_years(self):
        return [r[0] for r in self.conn.execute("SELECT DISTINCT school_year FROM classes ORDER BY school_year DESC")]

    def set_request_open(self, assignment_id, is_open):
        self._write("UPDATE assignments SET request_open = ? WHERE id = ?", (int(is_open), assignment_id))

    def set_last_sync(self, assignment_id, moment):
        self._write("UPDATE assignments SET last_sync = ? WHERE id = ?", (moment, assignment_id))

    def update_assignment(self, assignment_id, title, folder, due_date, scale):
        sql = "UPDATE assignments SET title = ?, folder = ?, due_date = ?, scale = ? WHERE id = ?"
        self._write(sql, (title, folder, due_date, scale, assignment_id))

    def set_archived(self, assignment_id, archived_at):
        self._write("UPDATE assignments SET archived_at = ? WHERE id = ?", (archived_at, assignment_id))

    def delete_assignment(self, assignment_id):
        self._write("DELETE FROM assignments WHERE id = ?", (assignment_id,))

    def overrides(self, assignment_id):
        rows = self.conn.execute("SELECT rel_path, student_id FROM overrides WHERE assignment_id = ?", (assignment_id,))
        return {r["rel_path"]: r["student_id"] for r in rows}

    def set_override(self, assignment_id, rel_path, student_id):
        sql = (
            "INSERT INTO overrides (assignment_id, rel_path, student_id) VALUES (?, ?, ?) "
            "ON CONFLICT(assignment_id, rel_path) DO UPDATE SET student_id = excluded.student_id"
        )
        self._write(sql, (assignment_id, rel_path, student_id))

    def clear_override(self, assignment_id, rel_path):
        self._write("DELETE FROM overrides WHERE assignment_id = ? AND rel_path = ?", (assignment_id, rel_path))

    def move_override(self, assignment_id, old_rel_path, new_rel_path):
        self._write("UPDATE overrides SET rel_path = ? WHERE assignment_id = ? AND rel_path = ?", (new_rel_path, assignment_id, old_rel_path))

    def grades(self, assignment_id):
        rows = self.conn.execute("SELECT * FROM grades WHERE assignment_id = ?", (assignment_id,))
        return {r["student_id"]: Grade(r["grade"], r["comment"]) for r in rows}

    def get_grade(self, assignment_id, student_id):
        r = self.conn.execute("SELECT * FROM grades WHERE assignment_id = ? AND student_id = ?", (assignment_id, student_id)).fetchone()
        return Grade(r["grade"], r["comment"]) if r else Grade(None, "")

    def set_grade(self, assignment_id, student_id, grade):
        sql = (
            "INSERT INTO grades (assignment_id, student_id, grade) VALUES (?, ?, ?) "
            "ON CONFLICT(assignment_id, student_id) DO UPDATE SET grade = excluded.grade"
        )
        self._write(sql, (assignment_id, student_id, grade))

    def set_comment(self, assignment_id, student_id, comment):
        sql = (
            "INSERT INTO grades (assignment_id, student_id, comment) VALUES (?, ?, ?) "
            "ON CONFLICT(assignment_id, student_id) DO UPDATE SET comment = excluded.comment"
        )
        self._write(sql, (assignment_id, student_id, comment))
