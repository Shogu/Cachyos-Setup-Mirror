import shutil

from gi.repository import Gtk

from .dropbox import path_part
from .sync import run_operations


def request_operations(assignment):
    operations = []
    if assignment.request_open:
        operations.append(("file_requests/update", {"id": assignment.request_id, "open": False}))
    operations.append(("file_requests/delete", {"ids": [assignment.request_id]}))
    return operations


def assignment_operations(assignment):
    operations = request_operations(assignment) + [("files/delete_v2", {"path": assignment.dropbox_path})]
    if assignment.instructions_path:
        operations.append(("files/delete_v2", {"path": assignment.instructions_path}))
    return operations


def year_folder(school_year):
    return f"/Casier/{path_part(school_year)}"


def class_folder(school_class):
    return f"{year_folder(school_class.school_year)}/{path_part(school_class.name)}"


def remove_cache(assignment):
    if assignment.on_dropbox:
        shutil.rmtree(assignment.folder, ignore_errors=True)


def run(client, operations, callback):
    run_operations(client, operations, lambda _done, error: callback(error), ignore_missing=True)


def dropbox_checkbox(label):
    return Gtk.CheckButton(label=label, active=True, halign=Gtk.Align.CENTER)
