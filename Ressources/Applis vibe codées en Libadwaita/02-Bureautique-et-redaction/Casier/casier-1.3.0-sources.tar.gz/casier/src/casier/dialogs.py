import datetime
import os

from gi.repository import Adw, Gio, GLib, Gtk

from .database import current_school_year
from .dropbox_ui import ConnectDialog
from .matching import parse_student_lines


class FormDialog(Adw.Dialog):
    __gtype_name__ = "CasierFormDialog"

    def __init__(self, title, confirm_label, on_confirm):
        super().__init__(title=title, content_width=460)
        self._on_confirm = on_confirm
        header = Adw.HeaderBar(show_start_title_buttons=False, show_end_title_buttons=False)
        cancel = Gtk.Button(label="Annuler")
        cancel.connect("clicked", lambda _b: self.close())
        header.pack_start(cancel)
        self.confirm = Gtk.Button(label=confirm_label, css_classes=["suggested-action"])
        self.confirm.connect("clicked", self._confirm_clicked)
        header.pack_end(self.confirm)
        self.page = Adw.PreferencesPage()
        toolbar = Adw.ToolbarView(content=self.page)
        toolbar.add_top_bar(header)
        self.set_child(toolbar)
        self.set_default_widget(self.confirm)

    def _confirm_clicked(self, _button):
        if self._on_confirm(*self.values()) is not False:
            self.close()


class ClassDialog(FormDialog):
    __gtype_name__ = "CasierClassDialog"

    def __init__(self, on_confirm, school_class=None):
        editing = school_class is not None
        super().__init__("Modifier la classe" if editing else "Nouvelle classe", "Enregistrer" if editing else "Créer", on_confirm)
        group = Adw.PreferencesGroup()
        self.name = Adw.EntryRow(title="Nom de la classe", activates_default=True)
        self.year = Adw.EntryRow(title="Année scolaire", activates_default=True)
        self.name.set_text(school_class.name if editing else "")
        self.year.set_text(school_class.school_year if editing else current_school_year())
        group.add(self.name)
        group.add(self.year)
        self.page.add(group)
        self.name.connect("changed", self._validate)
        self._validate()

    def _validate(self, *_args):
        self.confirm.set_sensitive(bool(self.name.get_text().strip()))

    def values(self):
        return self.name.get_text().strip(), self.year.get_text().strip() or current_school_year()


class StudentDialog(FormDialog):
    __gtype_name__ = "CasierStudentDialog"

    def __init__(self, on_confirm, student=None):
        editing = student is not None
        super().__init__("Modifier l'élève" if editing else "Ajouter un élève", "Enregistrer" if editing else "Ajouter", on_confirm)
        group = Adw.PreferencesGroup()
        self.last = Adw.EntryRow(title="Nom", activates_default=True)
        self.first = Adw.EntryRow(title="Prénom", activates_default=True)
        if editing:
            self.last.set_text(student.last_name)
            self.first.set_text(student.first_name)
        group.add(self.last)
        group.add(self.first)
        self.page.add(group)
        self.last.connect("changed", self._validate)
        self._validate()

    def _validate(self, *_args):
        self.confirm.set_sensitive(bool(self.last.get_text().strip()))

    def values(self):
        return self.last.get_text().strip().upper(), self.first.get_text().strip()


class ImportDialog(FormDialog):
    __gtype_name__ = "CasierImportDialog"

    def __init__(self, on_confirm):
        super().__init__("Importer une liste d'élèves", "Importer", on_confirm)
        self.set_content_height(560)
        group = Adw.PreferencesGroup(
            title="Liste des élèves",
            description="Un élève par ligne : « NOM Prénom », ou deux colonnes Nom et Prénom copiées depuis un tableur.",
        )
        choose = Gtk.Button(icon_name="document-open-symbolic", tooltip_text="Ouvrir un fichier CSV ou texte", valign=Gtk.Align.CENTER,
                            css_classes=["flat"])
        choose.connect("clicked", self._choose_file)
        group.set_header_suffix(choose)
        self.view = Gtk.TextView(wrap_mode=Gtk.WrapMode.NONE, top_margin=10, bottom_margin=10, left_margin=12, right_margin=12)
        scrolled = Gtk.ScrolledWindow(child=self.view, min_content_height=260, css_classes=["card"])
        group.add(scrolled)
        self.summary = Gtk.Label(xalign=0, margin_top=12, css_classes=["dim-label"])
        group.add(self.summary)
        self.page.add(group)
        self.view.get_buffer().connect("changed", self._update_summary)
        self._update_summary()

    def _text(self):
        buffer = self.view.get_buffer()
        return buffer.get_text(buffer.get_start_iter(), buffer.get_end_iter(), False)

    def _update_summary(self, *_args):
        count = len(parse_student_lines(self._text()))
        self.summary.set_label(f"{count} élève{'s' if count > 1 else ''} reconnu{'s' if count > 1 else ''}")
        self.confirm.set_sensitive(count > 0)

    def _choose_file(self, _button):
        text_filter = Gtk.FileFilter(name="Listes (CSV, texte)")
        for pattern in ("*.csv", "*.txt", "*.tsv"):
            text_filter.add_pattern(pattern)
        filters = Gio.ListStore.new(Gtk.FileFilter)
        filters.append(text_filter)
        dialog = Gtk.FileDialog(title="Ouvrir une liste d'élèves", filters=filters)
        dialog.open(self.get_root(), None, self._file_chosen)

    def _file_chosen(self, dialog, result):
        try:
            file = dialog.open_finish(result)
        except GLib.Error:
            return
        _ok, contents, _etag = file.load_contents(None)
        for encoding in ("utf-8-sig", "cp1252"):
            try:
                self.view.get_buffer().set_text(contents.decode(encoding))
                return
            except UnicodeDecodeError:
                continue

    def values(self):
        return (parse_student_lines(self._text()),)


class AssignmentDialog(FormDialog):
    __gtype_name__ = "CasierAssignmentDialog"

    def __init__(self, on_confirm, client, assignment=None):
        editing = assignment is not None
        super().__init__("Modifier le devoir" if editing else "Nouveau devoir", "Enregistrer" if editing else "Créer", on_confirm)
        self.client = client
        self.editing = editing
        self.on_dropbox = editing and assignment.on_dropbox
        self.folder = assignment.folder if editing else ""
        self.instructions_file = None
        self.current_document = os.path.basename(assignment.instructions_path) if editing and assignment.instructions_path else None
        self.due = datetime.date.fromisoformat(assignment.due_date) if editing and assignment.due_date else None

        main = Adw.PreferencesGroup()
        self.title_row = Adw.EntryRow(title="Titre du devoir", activates_default=True)
        self.title_row.set_text(assignment.title if editing else "")
        main.add(self.title_row)
        self.scale_row = Adw.SpinRow.new_with_range(1, 200, 1)
        self.scale_row.set_title("Noté sur")
        self.scale_row.set_value(assignment.scale if editing else 20)
        main.add(self.scale_row)
        self.page.add(main)

        self.link_group = Adw.PreferencesGroup(title="Dépôt des copies")
        self.link_switch = Adw.SwitchRow(title="Créer le lien de dépôt Dropbox", active=True,
                                         subtitle="Casier crée la demande de fichiers et récupère les copies tout seul")
        self.connect_row = Adw.ActionRow(title="Lien de dépôt automatique",
                                         subtitle="Connecte ton compte Dropbox pour que Casier crée le lien lui-même")
        connect_button = Gtk.Button(label="Connecter", valign=Gtk.Align.CENTER, css_classes=["suggested-action"])
        connect_button.connect("clicked", lambda _b: ConnectDialog(self.client, lambda _label: self._update()).present(self))
        self.connect_row.add_suffix(connect_button)
        self.link_group.add(self.link_switch)
        self.link_group.add(self.connect_row)
        self.page.add(self.link_group)

        self.instructions_group = Adw.PreferencesGroup(
            title="Consignes",
            description="Affichées sur la page de dépôt. Ce qu'il faut rendre, le format, le nom du fichier…",
        )
        self.instructions_view = Gtk.TextView(wrap_mode=Gtk.WrapMode.WORD_CHAR, top_margin=10, bottom_margin=10,
                                              left_margin=12, right_margin=12, accepts_tab=False)
        self.instructions_view.get_buffer().set_text(assignment.instructions if editing else "")
        self.instructions_group.add(Gtk.ScrolledWindow(child=self.instructions_view, min_content_height=90, css_classes=["card"]))
        self.document_row = Adw.ActionRow(title="Document de consignes", activatable=True, margin_top=12)
        self.document_row.add_suffix(Gtk.Image(icon_name="document-open-symbolic"))
        self.document_row.connect("activated", self._choose_document)
        self.instructions_group.add(self.document_row)
        self.page.add(self.instructions_group)

        self.folder_group = Adw.PreferencesGroup(
            title="Dossier des rendus",
            description="Le dossier de la demande de fichiers, dans ta Dropbox synchronisée sur ce PC.",
        )
        self.folder_row = Adw.ActionRow(title="Dossier", activatable=True)
        self.folder_row.add_suffix(Gtk.Image(icon_name="folder-open-symbolic"))
        self.folder_row.connect("activated", self._choose_folder)
        self.folder_group.add(self.folder_row)
        self.page.add(self.folder_group)

        due_group = Adw.PreferencesGroup(title="Date limite")
        self.due_switch = Adw.SwitchRow(title="Fixer une date limite", subtitle="Les dépôts après cette date sont marqués en retard")
        self.calendar = Gtk.Calendar()
        self.popover = Gtk.Popover(child=self.calendar)
        self.due_button = Gtk.MenuButton(popover=self.popover, valign=Gtk.Align.CENTER, css_classes=["flat"])
        self.due_row = Adw.ActionRow(title="Jour")
        self.due_row.add_suffix(self.due_button)
        due_group.add(self.due_switch)
        due_group.add(self.due_row)
        self.page.add(due_group)

        if self.due:
            self.calendar.select_day(GLib.DateTime.new_local(self.due.year, self.due.month, self.due.day, 0, 0, 0))
        self.due_switch.set_active(self.due is not None)
        self.calendar.connect("day-selected", self._day_selected)
        self.due_switch.connect("notify::active", self._update)
        self.link_switch.connect("notify::active", self._update)
        self.title_row.connect("changed", self._update)
        self._update()

    def _day_selected(self, calendar):
        date = calendar.get_date()
        self.due = datetime.date(date.get_year(), date.get_month(), date.get_day_of_month())
        self.popover.popdown()
        self._update()

    def _choose_folder(self, _row):
        dialog = Gtk.FileDialog(title="Choisir le dossier des rendus")
        start = self.folder or os.path.expanduser("~/Dropbox")
        if os.path.isdir(start):
            dialog.set_initial_folder(Gio.File.new_for_path(start))
        dialog.select_folder(self.get_root(), None, self._folder_chosen)

    def _folder_chosen(self, dialog, result):
        try:
            self.folder = dialog.select_folder_finish(result).get_path()
        except GLib.Error:
            return
        self._update()

    def _choose_document(self, _row):
        Gtk.FileDialog(title="Choisir le document de consignes").open(self.get_root(), None, self._document_chosen)

    def _document_chosen(self, dialog, result):
        try:
            self.instructions_file = dialog.open_finish(result).get_path()
        except GLib.Error:
            return
        self._update()

    def _update(self, *_args):
        if self.instructions_file:
            document = os.path.basename(self.instructions_file)
        else:
            document = self.current_document or "Aucun, facultatif (PDF, Word, image…)"
        self.document_row.set_subtitle(document)
        self.folder_row.set_subtitle(self.folder.replace(os.path.expanduser("~"), "~", 1) if self.folder else "Aucun dossier choisi")
        active = self.due_switch.get_active()
        if active and self.due is None:
            self.due = datetime.date.today()
        self.due_row.set_sensitive(active)
        self.due_button.set_label(self.due.strftime("%d/%m/%Y") if self.due else "—")
        connected = self.client.connected
        self.link_group.set_visible(not self.editing)
        self.link_switch.set_visible(connected)
        self.connect_row.set_visible(not connected)
        uses_dropbox = self._uses_dropbox()
        self.folder_group.set_visible(not uses_dropbox and not self.on_dropbox)
        self.instructions_group.set_visible(uses_dropbox or self.on_dropbox)
        has_place = uses_dropbox or self.on_dropbox or bool(self.folder)
        self.confirm.set_sensitive(bool(self.title_row.get_text().strip()) and has_place)

    def _uses_dropbox(self):
        return not self.editing and self.client.connected and self.link_switch.get_active()

    def values(self):
        due = self.due.isoformat() if self.due_switch.get_active() and self.due else None
        buffer = self.instructions_view.get_buffer()
        instructions = buffer.get_text(buffer.get_start_iter(), buffer.get_end_iter(), False).strip()
        return (self.title_row.get_text().strip(), self.folder, due, self.scale_row.get_value(), self._uses_dropbox(),
                instructions, self.instructions_file)
