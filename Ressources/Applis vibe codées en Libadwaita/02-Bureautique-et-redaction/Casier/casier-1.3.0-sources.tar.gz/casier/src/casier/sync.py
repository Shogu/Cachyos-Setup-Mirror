import datetime
import json
import os

MANIFEST = ".casier-dropbox.json"
PAGE_LIMIT = 2000


def remote_time(value):
    return datetime.datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()


def relative(root, path_display):
    return path_display[len(root.rstrip("/")) + 1:]


class AssignmentSync:
    def __init__(self, client, root, folder, callback):
        self.client = client
        self.root = root
        self.folder = folder
        self.callback = callback
        self.remote = []
        self.queue = []
        self.manifest = {}
        self.downloaded = 0
        self.removed = 0

    def start(self):
        args = {"path": self.root, "recursive": True, "limit": PAGE_LIMIT}
        self.client.rpc("files/list_folder", args, self._listed)

    def _listed(self, result, error):
        if error:
            if "path/not_found" in error.summary:
                self._plan()
                return
            self.callback(None, error)
            return
        self.remote.extend(e for e in result["entries"] if e[".tag"] == "file")
        if result["has_more"]:
            self.client.rpc("files/list_folder/continue", {"cursor": result["cursor"]}, self._listed)
            return
        self._plan()

    def _manifest_path(self):
        return os.path.join(self.folder, MANIFEST)

    def _plan(self):
        os.makedirs(self.folder, exist_ok=True)
        if os.path.exists(self._manifest_path()):
            with open(self._manifest_path(), encoding="utf-8") as handle:
                self.manifest = json.load(handle)
        remote_rels = set()
        for entry in self.remote:
            rel = relative(self.root, entry["path_display"])
            remote_rels.add(rel)
            local = os.path.join(self.folder, rel)
            if self.manifest.get(rel, {}).get("rev") != entry["rev"] or not os.path.exists(local):
                self.queue.append((rel, entry))
        for rel in [r for r in self.manifest if r not in remote_rels]:
            local = os.path.join(self.folder, rel)
            if os.path.exists(local):
                os.remove(local)
            del self.manifest[rel]
            self.removed += 1
        self._next()

    def _next(self):
        if not self.queue:
            self._save_manifest()
            self.callback({"downloaded": self.downloaded, "removed": self.removed, "total": len(self.remote)}, None)
            return
        rel, entry = self.queue.pop(0)
        self.client.download(entry["id"], lambda data, error: self._downloaded(rel, entry, data, error))

    def _downloaded(self, rel, entry, data, error):
        if error:
            self._save_manifest()
            self.callback(None, error)
            return
        local = os.path.join(self.folder, rel)
        os.makedirs(os.path.dirname(local), exist_ok=True)
        with open(local, "wb") as handle:
            handle.write(bytes(data))
        moment = remote_time(entry["server_modified"])
        os.utime(local, (moment, moment))
        self.manifest[rel] = {"rev": entry["rev"], "path": entry["path_display"]}
        self.downloaded += 1
        self._next()

    def _save_manifest(self):
        with open(self._manifest_path(), "w", encoding="utf-8") as handle:
            json.dump(self.manifest, handle, ensure_ascii=False, indent=1)


def run_operations(client, operations, callback, done=0, ignore_missing=False):
    if not operations:
        callback(done, None)
        return
    endpoint, args = operations[0]

    def finished(_result, error):
        if error and not (ignore_missing and "not_found" in error.summary):
            callback(done, error)
            return
        run_operations(client, operations[1:], callback, done + 1, ignore_missing)
    client.rpc(endpoint, args, finished)


class SyncRunner:
    def __init__(self, client, db):
        self.client = client
        self.db = db
        self.waiting = {}

    def is_running(self, assignment_id):
        return assignment_id in self.waiting

    def sync(self, assignment_id, callback):
        if assignment_id in self.waiting:
            self.waiting[assignment_id].append(callback)
            return
        self.waiting[assignment_id] = [callback]
        assignment = self.db.get_assignment(assignment_id)
        AssignmentSync(self.client, assignment.dropbox_path, assignment.folder,
                       lambda result, error: self._synced(assignment, result, error)).start()

    def _synced(self, assignment, result, error):
        if error:
            self._finish(assignment.id, None, error)
            return
        self.db.set_last_sync(assignment.id, datetime.datetime.now().isoformat(timespec="seconds"))
        self.client.rpc("file_requests/get", {"id": assignment.request_id},
                        lambda request, err: self._request_loaded(assignment.id, result, request, err))

    def _request_loaded(self, assignment_id, result, request, error):
        if request is not None:
            self.db.set_request_open(assignment_id, request["is_open"])
        self._finish(assignment_id, result, error)

    def _finish(self, assignment_id, result, error):
        for callback in self.waiting.pop(assignment_id):
            callback(result, error)
