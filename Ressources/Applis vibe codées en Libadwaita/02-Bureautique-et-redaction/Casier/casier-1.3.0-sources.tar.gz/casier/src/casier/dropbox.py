import base64
import hashlib
import json
import os
import secrets
import time
import urllib.parse

from gi.repository import Gio, GLib, Soup

from . import credentials

API = "https://api.dropboxapi.com/2/"
CONTENT = "https://content.dropboxapi.com/2/"
TOKEN_URL = "https://api.dropboxapi.com/oauth2/token"
AUTHORIZE_URL = "https://www.dropbox.com/oauth2/authorize"
CONSOLE_URL = "https://www.dropbox.com/developers/apps"
APP_KEY_SETTING = "dropbox-app-key"
ACCOUNT_SETTING = "dropbox-account"
SCOPES = (
    "account_info.read files.metadata.read files.content.read files.content.write "
    "file_requests.read file_requests.write sharing.read sharing.write"
)
EXPIRY_MARGIN_S = 120

ERROR_MESSAGES = {
    "missing_scope": "Il manque une autorisation à ton appli Dropbox. Coche toutes les cases de l'onglet Permissions, "
                     "puis reconnecte Casier.",
    "invalid_access_token": "La connexion à Dropbox a expiré. Reconnecte Casier dans les Préférences.",
    "expired_access_token": "La connexion à Dropbox a expiré. Reconnecte Casier dans les Préférences.",
    "invalid_grant": "Le code d'autorisation est invalide ou a déjà servi. Recommence l'étape 2.",
    "path/not_found": "Ce dossier n'existe plus dans ta Dropbox.",
    "insufficient_space": "Ta Dropbox est pleine.",
}


class DropboxError(Exception):
    def __init__(self, summary, status=0):
        self.summary = summary
        self.status = status
        super().__init__(friendly_message(summary, status))


def friendly_message(summary, status):
    for key, message in ERROR_MESSAGES.items():
        if key in summary:
            return message
    if status == 0:
        return f"Dropbox est injoignable ({summary}). Vérifie la connexion internet."
    return f"Dropbox a refusé l'opération : {summary}"


def api_arg(value):
    return json.dumps(value, ensure_ascii=True)


def web_url(path):
    return "https://www.dropbox.com/home" + urllib.parse.quote(path)


class DropboxClient:
    def __init__(self, db):
        self.db = db
        self.session = Soup.Session(timeout=60)
        self.cancellable = Gio.Cancellable()
        self.refresh_token = credentials.load_refresh_token()
        self.access_token = None
        self.access_expiry = 0
        self.verifier = None

    @property
    def app_key(self):
        return self.db.get_setting(APP_KEY_SETTING, "")

    @property
    def connected(self):
        return bool(self.refresh_token and self.app_key)

    @property
    def account_label(self):
        return self.db.get_setting(ACCOUNT_SETTING, "")

    def shutdown(self):
        self.cancellable.cancel()
        self.session.abort()

    def authorize_url(self, app_key):
        self.db.set_setting(APP_KEY_SETTING, app_key)
        self.verifier = secrets.token_urlsafe(64)
        challenge = base64.urlsafe_b64encode(hashlib.sha256(self.verifier.encode()).digest()).rstrip(b"=").decode()
        query = urllib.parse.urlencode({
            "client_id": app_key,
            "response_type": "code",
            "code_challenge": challenge,
            "code_challenge_method": "S256",
            "token_access_type": "offline",
            "scope": SCOPES,
        })
        return f"{AUTHORIZE_URL}?{query}"

    def finish_authorization(self, code, callback):
        form = {"code": code.strip(), "grant_type": "authorization_code", "code_verifier": self.verifier, "client_id": self.app_key}
        self._token_request(form, lambda result, error: self._authorized(result, error, callback))

    def _authorized(self, result, error, callback):
        if error:
            callback(None, error)
            return
        try:
            credentials.store_refresh_token(result["refresh_token"])
        except GLib.Error as err:
            callback(None, DropboxError(f"trousseau GNOME indisponible ({err.message})"))
            return
        self.refresh_token = result["refresh_token"]
        self._accept_token(result)
        self.rpc("users/get_current_account", None, lambda account, err: self._account_loaded(account, err, callback))

    def _account_loaded(self, account, error, callback):
        if error:
            callback(None, error)
            return
        label = f"{account['name']['display_name']} ({account['email']})"
        self.db.set_setting(ACCOUNT_SETTING, label)
        callback(label, None)

    def disconnect(self, callback):
        def forget(_result, _error):
            credentials.clear_refresh_token()
            self.refresh_token = None
            self.access_token = None
            self.db.set_setting(ACCOUNT_SETTING, "")
            callback(None, None)
        if self.access_token:
            self.rpc("auth/token/revoke", None, forget)
        else:
            forget(None, None)

    def _accept_token(self, result):
        self.access_token = result["access_token"]
        self.access_expiry = time.monotonic() + result.get("expires_in", 14400) - EXPIRY_MARGIN_S

    def _token_request(self, form, callback):
        message = Soup.Message.new("POST", TOKEN_URL)
        body = urllib.parse.urlencode(form).encode()
        message.set_request_body_from_bytes("application/x-www-form-urlencoded", GLib.Bytes.new(body))
        self._send(message, lambda data, error: callback(json.loads(data) if data is not None else None, error))

    def _with_token(self, callback):
        if self.access_token and time.monotonic() < self.access_expiry:
            callback(self.access_token, None)
            return
        if not self.connected:
            callback(None, DropboxError("invalid_access_token", 401))
            return
        form = {"grant_type": "refresh_token", "refresh_token": self.refresh_token, "client_id": self.app_key}

        def refreshed(result, error):
            if error:
                callback(None, error)
                return
            self._accept_token(result)
            callback(self.access_token, None)
        self._token_request(form, refreshed)

    def rpc(self, endpoint, args, callback):
        def go(token, error):
            if error:
                callback(None, error)
                return
            message = Soup.Message.new("POST", API + endpoint)
            message.get_request_headers().append("Authorization", f"Bearer {token}")
            if args is not None:
                message.set_request_body_from_bytes("application/json", GLib.Bytes.new(json.dumps(args).encode()))
            self._send(message, lambda data, err: self._rpc_done(data, err, callback))
        self._with_token(go)

    def _rpc_done(self, data, error, callback):
        if error:
            if error.status == 401:
                self.access_token = None
            callback(None, error)
            return
        callback(json.loads(data) if data else {}, None)

    def download(self, path, callback):
        def go(token, error):
            if error:
                callback(None, error)
                return
            message = Soup.Message.new("POST", CONTENT + "files/download")
            headers = message.get_request_headers()
            headers.append("Authorization", f"Bearer {token}")
            headers.append("Dropbox-API-Arg", api_arg({"path": path}))
            self._send(message, callback)
        self._with_token(go)

    def upload(self, path, data, callback):
        def go(token, error):
            if error:
                callback(None, error)
                return
            message = Soup.Message.new("POST", CONTENT + "files/upload")
            headers = message.get_request_headers()
            headers.append("Authorization", f"Bearer {token}")
            headers.append("Dropbox-API-Arg", api_arg({"path": path, "mode": "overwrite", "mute": True}))
            message.set_request_body_from_bytes("application/octet-stream", GLib.Bytes.new(data))
            self._send(message, lambda raw, err: self._rpc_done(raw, err, callback))
        self._with_token(go)

    def share(self, path, callback):
        settings = {"requested_visibility": "public", "audience": "public", "access": "viewer"}

        def created(result, error):
            if error is None:
                callback(result["url"], None)
            elif "shared_link_already_exists" in error.summary:
                self.rpc("sharing/list_shared_links", {"path": path, "direct_only": True}, listed)
            else:
                callback(None, error)

        def listed(result, error):
            if error or not result["links"]:
                callback(None, error or DropboxError("lien de partage introuvable"))
                return
            callback(result["links"][0]["url"], None)
        self.rpc("sharing/create_shared_link_with_settings", {"path": path, "settings": settings}, created)

    def _send(self, message, callback):
        self.session.send_and_read_async(message, GLib.PRIORITY_DEFAULT, self.cancellable, self._received, (message, callback))

    @staticmethod
    def _received(session, result, user_data):
        message, callback = user_data
        try:
            data = session.send_and_read_finish(result).get_data()
        except GLib.Error as error:
            if error.matches(Gio.io_error_quark(), Gio.IOErrorEnum.CANCELLED):
                return
            callback(None, DropboxError(error.message))
            return
        status = message.get_status()
        if 200 <= status < 300:
            callback(data, None)
            return
        callback(None, DropboxError(_error_summary(data), status))


def _error_summary(data):
    text = bytes(data or b"").decode("utf-8", errors="replace")
    try:
        payload = json.loads(text)
    except ValueError:
        return text.strip()[:200] or "erreur inconnue"
    if isinstance(payload, dict):
        return payload.get("error_summary") or payload.get("error_description") or payload.get("error") or text[:200]
    return text[:200]


def path_part(text):
    cleaned = "".join("-" if c in '\\/:*?"<>|' else c for c in text).strip(" .")
    return cleaned or "Sans titre"


def request_destination(school_class, title):
    return f"/Casier/{path_part(school_class.school_year)}/{path_part(school_class.name)}/{path_part(title)}"


def instructions_destination(school_class, title, filename):
    extension = filename[filename.rfind("."):] if "." in filename else ""
    return f"/Casier/{path_part(school_class.school_year)}/{path_part(school_class.name)}/Consignes/{path_part(title)}{extension}"


def attach_instructions(client, db, assignment_id, local_path, callback):
    assignment = db.get_assignment(assignment_id)
    school_class = db.get_class(assignment.class_id)
    destination = instructions_destination(school_class, assignment.title, os.path.basename(local_path))
    with open(local_path, "rb") as handle:
        data = handle.read()

    def uploaded(result, error):
        if error:
            callback(error)
            return
        client.share(result["path_display"], lambda url, err: shared(result["path_display"], url, err))

    def shared(path, url, error):
        if error:
            callback(error)
            return
        db.set_instructions_document(assignment_id, path, url)
        callback(None)
    client.upload(destination, data, uploaded)
