import datetime
import os

from gi.repository import Adw, Gio, Gtk

from . import cleanup, model
from .dropbox import attach_instructions, request_destination
from .assignment_page import AssignmentPage
from .dialogs import AssignmentDialog, ClassDialog, ImportDialog, StudentDialog


DEFAULT_INSTRUCTIONS = "Dépose ton travail ici. Nomme ton fichier avec ton NOM et ton prénom."


def plural(count, word):
    return f"{count} {word}{'s' if count > 1 else ''}"


class ClassPage(Adw.NavigationPage):
    __gtype_name__ = "CasierClassPage"

    def __init__(self, window, class_id):
        super().__init__(title="Classe", tag=f"classe-{class_id}")
        self.window = window
        self.db = window.db
        self.class_id = class_id

        self.stack = Adw.ViewStack()
        self.assignments_bin = Adw.Bin()
        self.students_bin = Adw.Bin()
        self.stack.add_titled_with_icon(self.assignments_bin, "devoirs", "Devoirs", "folder-documents-symbolic")
        self.stack.add_titled_with_icon(self.students_bin, "eleves", "Élèves", "system-users-symbolic")

        header = Adw.HeaderBar(title_widget=Adw.ViewSwitcher(stack=self.stack, policy=Adw.ViewSwitcherPolicy.WIDE))
        add_menu = Gio.Menu()
        add_menu.append("Nouveau devoir…", "classe.new-assignment")
        add_menu.append("Importer une liste d'élèves…", "classe.import")
        add_menu.append("Ajouter un élève…", "classe.add-student")
        header.pack_start(Gtk.MenuButton(icon_name="list-add-symbolic", menu_model=add_menu, tooltip_text="Ajouter"))
        header.pack_end(self._menu_button())

        toolbar = Adw.ToolbarView(content=self.stack)
        toolbar.add_top_bar(header)
        self.set_child(toolbar)

        group = Gio.SimpleActionGroup()
        for name, callback in (("edit", self._edit_class), ("delete", self._delete_class), ("import", self.import_students),
                               ("add-student", self._add_student), ("new-assignment", self._new_assignment)):
            action = Gio.SimpleAction.new(name, None)
            action.connect("activate", callback)
            group.add_action(action)
        self.insert_action_group("classe", group)

        self.connect("showing", self._on_showing)

    def _menu_button(self):
        menu = Gio.Menu()
        menu.append("Modifier la classe…", "classe.edit")
        menu.append("Supprimer la classe", "classe.delete")
        return Gtk.MenuButton(icon_name="view-more-symbolic", menu_model=menu, tooltip_text="Menu de la classe")

    def _on_showing(self, _page):
        self.refresh()
        if not self.window.dropbox.connected:
            return
        for assignment in self.db.assignments(self.class_id):
            if assignment.on_dropbox and not assignment.archived_at:
                self.window.sync.sync(assignment.id, self._synced)

    def _synced(self, _result, _error):
        self.refresh()

    def refresh(self):
        school_class = self.db.get_class(self.class_id)
        self.set_title(school_class.name)
        self.assignments_bin.set_child(self._assignments_view())
        self.students_bin.set_child(self._students_view())

    def _assignments_view(self):
        assignments = self.db.assignments(self.class_id)
        if not assignments:
            button = Gtk.Button(label="Nouveau devoir", halign=Gtk.Align.CENTER, css_classes=["pill", "suggested-action"])
            button.connect("clicked", self._new_assignment)
            return Adw.StatusPage(icon_name="folder-documents-symbolic", title="Aucun devoir",
                                  description="Crée un devoir et relie-le au dossier de ta demande de fichiers Dropbox.", child=button)
        page = Adw.PreferencesPage()
        for title, archived in (("En cours", False), ("Archivés", True)):
            selected = [a for a in assignments if bool(a.archived_at) == archived]
            if not selected:
                continue
            group = Adw.PreferencesGroup(title=title)
            for assignment in selected:
                group.add(self._assignment_row(assignment))
            page.add(group)
        return page

    def _assignment_row(self, assignment):
        state = model.load(self.db, assignment.id)
        counts = state.counts()
        handed = counts["rendu"] + counts["en retard"]
        parts = [f"{handed}/{counts['total']} rendus"]
        if assignment.due_date:
            parts.append("à rendre le " + datetime.date.fromisoformat(assignment.due_date).strftime("%d/%m"))
        if counts["notés"]:
            parts.append(plural(counts["notés"], "noté"))
        if assignment.on_dropbox and not assignment.archived_at:
            parts.append("dépôts ouverts" if assignment.request_open else "dépôts fermés")
        row = Adw.ActionRow(title=assignment.title, subtitle=" · ".join(parts), activatable=True, use_markup=False)
        bar = Gtk.LevelBar(min_value=0, max_value=max(counts["total"], 1), value=handed, valign=Gtk.Align.CENTER, width_request=90)
        for offset in (Gtk.LEVEL_BAR_OFFSET_LOW, Gtk.LEVEL_BAR_OFFSET_HIGH, Gtk.LEVEL_BAR_OFFSET_FULL):
            bar.remove_offset_value(offset)
        row.add_suffix(bar)
        row.add_suffix(Gtk.Image(icon_name="go-next-symbolic"))
        row.connect("activated", lambda _r: self.window.push(AssignmentPage(self.window, assignment.id)))
        return row

    def _students_view(self):
        students = self.db.students(self.class_id)
        if not students:
            button = Gtk.Button(label="Importer une liste", halign=Gtk.Align.CENTER, css_classes=["pill", "suggested-action"])
            button.connect("clicked", self.import_students)
            return Adw.StatusPage(icon_name="system-users-symbolic", title="Aucun élève",
                                  description="Colle la liste de la classe, copiée depuis un tableur ou Pronote.", child=button)
        page = Adw.PreferencesPage()
        group = Adw.PreferencesGroup(title=plural(len(students), "élève"), description="Par ordre alphabétique")
        import_button = Gtk.Button(icon_name="document-open-symbolic", tooltip_text="Importer une liste", valign=Gtk.Align.CENTER,
                                   css_classes=["flat"])
        import_button.connect("clicked", self.import_students)
        group.set_header_suffix(import_button)
        for student in students:
            row = Adw.ActionRow(title=student.display_name, use_markup=False)
            edit = Gtk.Button(icon_name="document-edit-symbolic", valign=Gtk.Align.CENTER, css_classes=["flat"], tooltip_text="Modifier")
            edit.connect("clicked", self._edit_student, student)
            delete = Gtk.Button(icon_name="user-trash-symbolic", valign=Gtk.Align.CENTER, css_classes=["flat"], tooltip_text="Retirer")
            delete.connect("clicked", self._delete_student, student)
            row.add_suffix(edit)
            row.add_suffix(delete)
            group.add(row)
        page.add(group)
        return page

    def _new_assignment(self, *_args):
        AssignmentDialog(self._assignment_created, self.window.dropbox).present(self.get_root())

    def _assignment_created(self, title, folder, due_date, scale, use_dropbox, instructions, instructions_file):
        if not use_dropbox:
            assignment_id = self.db.add_assignment(self.class_id, title, folder, due_date, scale)
            self.refresh()
            self.window.push(AssignmentPage(self.window, assignment_id))
            return
        school_class = self.db.get_class(self.class_id)
        destination = request_destination(school_class, title)
        args = {
            "title": f"{school_class.name} — {title}",
            "destination": destination,
            "open": True,
            "description": instructions or DEFAULT_INSTRUCTIONS,
        }
        self.window.toast("Création du lien de dépôt…")
        details = (title, due_date, scale, destination, instructions, instructions_file)
        self.window.dropbox.rpc("file_requests/create", args, lambda request, error: self._request_created(request, error, details))

    def _request_created(self, request, error, details):
        title, due_date, scale, destination, instructions, instructions_file = details
        if error:
            dialog = Adw.AlertDialog(heading="Lien de dépôt non créé", body=str(error))
            dialog.add_response("ok", "OK")
            dialog.present(self.window)
            return
        assignment_id = self.db.add_assignment(self.class_id, title, "", due_date, scale)
        folder = os.path.join(self.window.depots_folder, str(assignment_id))
        self.db.set_dropbox_request(assignment_id, folder, request.get("destination") or destination, request)
        self.db.set_instructions(assignment_id, instructions)
        page = AssignmentPage(self.window, assignment_id)
        self.refresh()
        self.window.push(page)
        if instructions_file:
            self.window.toast("Envoi du document de consignes…")
            attach_instructions(self.window.dropbox, self.db, assignment_id, instructions_file, page.instructions_attached)

    def import_students(self, *_args):
        ImportDialog(self._students_imported).present(self.get_root())

    def _students_imported(self, names):
        existing = {(s.last_name.upper(), s.first_name.lower()) for s in self.db.students(self.class_id)}
        fresh = [n for n in names if (n[0].upper(), n[1].lower()) not in existing]
        self.db.add_students(self.class_id, fresh)
        self.stack.set_visible_child_name("eleves")
        self.refresh()
        skipped = len(names) - len(fresh)
        message = f"{plural(len(fresh), 'élève')} ajouté{'s' if len(fresh) > 1 else ''}"
        if skipped:
            message += f", {skipped} déjà présent{'s' if skipped > 1 else ''}"
        self.window.toast(message)

    def _add_student(self, *_args):
        StudentDialog(self._student_added).present(self.get_root())

    def _student_added(self, last_name, first_name):
        self.db.add_students(self.class_id, [(last_name, first_name)])
        self.stack.set_visible_child_name("eleves")
        self.refresh()

    def _edit_student(self, _button, student):
        StudentDialog(lambda last, first: self._student_edited(student.id, last, first), student).present(self.get_root())

    def _student_edited(self, student_id, last_name, first_name):
        self.db.update_student(student_id, last_name, first_name)
        self.refresh()

    def _delete_student(self, _button, student):
        dialog = Adw.AlertDialog(heading=f"Retirer {student.display_name} ?",
                                 body="Ses notes et appréciations dans cette classe seront effacées.")
        dialog.add_response("cancel", "Annuler")
        dialog.add_response("delete", "Retirer")
        dialog.set_response_appearance("delete", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.connect("response", lambda _d, response: response == "delete" and self._student_deleted(student.id))
        dialog.present(self.get_root())

    def _student_deleted(self, student_id):
        self.db.delete_student(student_id)
        self.refresh()

    def _edit_class(self, *_args):
        ClassDialog(self._class_edited, self.db.get_class(self.class_id)).present(self.get_root())

    def _class_edited(self, name, school_year):
        self.db.update_class(self.class_id, name, school_year)
        self.refresh()
        self.window.refresh_classes()

    def _delete_class(self, *_args):
        dialog = Adw.AlertDialog(heading="Supprimer cette classe ?",
                                 body="Les élèves, devoirs, notes et appréciations de la classe seront effacés de Casier. "
                                      "Les fichiers et les archives restent sur le disque.")
        dialog.add_response("cancel", "Annuler")
        dialog.add_response("delete", "Supprimer")
        dialog.set_response_appearance("delete", Adw.ResponseAppearance.DESTRUCTIVE)
        on_dropbox = [a for a in self.db.assignments(self.class_id) if a.on_dropbox]
        check = None
        if on_dropbox and self.window.dropbox.connected:
            school_class = self.db.get_class(self.class_id)
            check = cleanup.dropbox_checkbox(f"Supprimer aussi « {cleanup.class_folder(school_class)} » dans Dropbox")
            dialog.set_extra_child(check)
        dialog.connect("response", self._delete_class_response, check)
        dialog.present(self.get_root())

    def _delete_class_response(self, _dialog, response, check):
        if response != "delete":
            return
        assignments = self.db.assignments(self.class_id)
        if check is not None and check.get_active():
            operations = [op for a in assignments if a.on_dropbox for op in cleanup.request_operations(a)]
            operations.append(("files/delete_v2", {"path": cleanup.class_folder(self.db.get_class(self.class_id))}))
            window = self.window
            window.toast("Suppression dans Dropbox…")
            cleanup.run(window.dropbox, operations,
                        lambda error: window.toast(f"Dropbox n'a pas pu être nettoyé : {error}" if error else "Supprimé aussi dans Dropbox"))
        for assignment in assignments:
            cleanup.remove_cache(assignment)
        self.db.delete_class(self.class_id)
        self.window.refresh_classes()
