import re
import unicodedata
from dataclasses import dataclass, field


@dataclass
class Student:
    id: int
    last_name: str
    first_name: str

    @property
    def display_name(self):
        return f"{self.last_name.upper()} {self.first_name}"


@dataclass
class FileEntry:
    rel_path: str
    path: str
    mtime: float
    size: int


@dataclass
class Submissions:
    by_student: dict = field(default_factory=dict)
    unassigned: list = field(default_factory=list)
    ignored: list = field(default_factory=list)

    def files_for(self, student_id):
        return self.by_student.get(student_id, [])


IGNORED = 0
UNASSIGNED = -1


def normalize(text):
    decomposed = unicodedata.normalize("NFKD", text)
    stripped = "".join(c for c in decomposed if not unicodedata.combining(c))
    return re.sub(r"[^a-z0-9]+", " ", stripped.lower()).strip()


def tokens(text):
    return normalize(text).split()


def compact(text):
    return normalize(text).replace(" ", "")


def sort_key(student):
    return (normalize(student.last_name), normalize(student.first_name))


def _hit(parts, name_tokens, name_compact):
    if not parts:
        return False
    if all(t in name_tokens for t in parts):
        return True
    joined = "".join(parts)
    return len(joined) >= 4 and joined in name_compact


def _score(student, name_tokens, name_compact):
    last_hit = _hit(tokens(student.last_name), name_tokens, name_compact)
    first_hit = _hit(tokens(student.first_name), name_tokens, name_compact)
    return 2 * last_hit + first_hit, last_hit, first_hit


def match_file(rel_path, students):
    stem = rel_path.rsplit(".", 1)[0] if "." in rel_path.rsplit("/", 1)[-1] else rel_path
    name_tokens = set(tokens(stem))
    name_compact = compact(stem)
    scored = []
    for student in students:
        score, last_hit, first_hit = _score(student, name_tokens, name_compact)
        if score:
            scored.append((score, last_hit, first_hit, student))
    if not scored:
        return None
    best = max(s[0] for s in scored)
    leaders = [s for s in scored if s[0] == best]
    if len(leaders) != 1:
        return None
    _score_value, last_hit, _first_hit, student = leaders[0]
    if last_hit:
        return student
    first_key = compact(student.first_name)
    same_first = [s for s in students if compact(s.first_name) == first_key]
    return student if len(same_first) == 1 else None


def assign(files, students, overrides):
    result = Submissions()
    known = {s.id for s in students}
    for entry in files:
        forced = overrides.get(entry.rel_path)
        if forced == IGNORED:
            result.ignored.append(entry)
            continue
        if forced in known:
            result.by_student.setdefault(forced, []).append(entry)
            continue
        student = None if forced == UNASSIGNED else match_file(entry.rel_path, students)
        if student is None:
            result.unassigned.append(entry)
        else:
            result.by_student.setdefault(student.id, []).append(entry)
    for entries in result.by_student.values():
        entries.sort(key=lambda e: e.mtime)
    return result


def parse_student_lines(text):
    students = []
    for raw in text.splitlines():
        line = raw.strip().strip("﻿")
        if not line:
            continue
        parts = [p.strip().strip('"') for p in re.split(r"[;\t,]", line) if p.strip()]
        if len(parts) >= 2:
            last, first = parts[0], parts[1]
        else:
            last, first = _split_single(line)
        if normalize(last) in ("nom", "eleve", "eleves") and normalize(first) in ("prenom", "prenoms", ""):
            continue
        if last:
            students.append((last.upper(), first))
    return students


def _split_single(line):
    words = line.split()
    upper = []
    for word in words:
        letters = [c for c in word if c.isalpha()]
        if letters and all(c.isupper() for c in letters):
            upper.append(word)
        else:
            break
    if upper and len(upper) < len(words):
        return " ".join(upper), " ".join(words[len(upper):])
    if len(words) == 1:
        return words[0], ""
    return words[0], " ".join(words[1:])


def safe_file_part(text):
    decomposed = unicodedata.normalize("NFKD", text)
    stripped = "".join(c for c in decomposed if not unicodedata.combining(c))
    return re.sub(r"[^A-Za-z0-9]+", "-", stripped).strip("-")
