# Livret

Appréciations, conseils de classe et stages des élèves (PFMP), dans une seule appli GTK4/libadwaita en Python (PyGObject), pour CachyOS / GNOME 51.

Toutes les données restent sur l'ordinateur, dans `~/.local/share/livret/` (dossier en `700`, base en `600`). Aucune connexion réseau, sauf deux actions explicites : le bouton **Itinéraire** (l'adresse de l'entreprise part vers GNOME Cartes ou OpenStreetMap) et le bouton **Distances** des visites (les adresses de l'établissement et des lieux de stage sont localisées une fois par OpenStreetMap Nominatim ; aucun nom d'élève n'est transmis).

## Installation

Paquet prêt à installer (`arch=any`) :

```sh
shelly install --standard ./livret-1.2.0-1-any.pkg.tar.zst
# ou, équivalent pacman :
sudo pacman -U ./livret-1.2.0-1-any.pkg.tar.zst
```

Ou reconstruire depuis les sources :

```sh
cd livret
makepkg -si          # lance aussi les tests (check)
```

Le paquet prêt à installer ne contient pas de fichiers `.pyc` : Python 3.14 compile les modules au lancement, ce qui prend quelques millisecondes. Un `makepkg` fait sur la machine les ajoute.

Dépendances : `python`, `python-gobject`, `python-cairo`, `gtk4`, `libadwaita`, `pango`. Facultatif : `gnome-maps`, pour les itinéraires dans GNOME Cartes (sans lui, OpenStreetMap s'ouvre dans le navigateur).

Pour essayer sans installer :

```sh
python -m livret                                     # depuis la racine du projet
XDG_DATA_HOME=/tmp/essai python tests/donnees_demo.py  # base de démonstration (élèves fictifs)
XDG_DATA_HOME=/tmp/essai python -m livret
```

## Disposition des fichiers (résistante aux mises à jour de Python)

Le code n'est **pas** dans `/usr/lib/python3.X/site-packages/`, dossier numéroté qui serait ignoré au passage à une nouvelle version de Python :

```
/usr/lib/livret/lancer.py        ← point d'entrée
/usr/lib/livret/livret/        ← le code (paquet Python)
/usr/lib/livret/icons/           ← icônes symboliques de l'interface
/usr/bin/livret                  ← contient : exec python3 /usr/lib/livret/lancer.py "$@"
```

N'importe quelle version de Python 3 lit ces fichiers. Les dépendances (`python-gobject`, `python-cairo`) sont reconstruites par Arch. Les éventuels `.pyc` d'une ancienne version sont simplement ignorés.

Vérification : `pacman -Qlm | grep -E ' /usr/lib/python3\.[0-9]+/'` n'affiche aucune ligne pour `livret`.

## Nom et icône dans les gestionnaires de tâches

* Le processus s'appelle **livret** (et non `python3`) : `lancer.py` renomme le processus au démarrage (`prctl`, visible dans `/proc/PID/comm`).
* L'identifiant d'application `io.gitlab.shogu.Livret` est partout le même : nom du fichier `.desktop`, `application_id` (identifiant de fenêtre sous Wayland), nom de programme et `WM_CLASS` sous X11, `StartupWMClass`. GNOME Shell rattache donc la fenêtre à son icône dans le dock et dans la vue d'ensemble.
* Lancée depuis la grille d'applications ou le dock, l'appli tourne dans son propre groupe systemd (`app-gnome-io.gitlab.shogu.Livret-….scope`). Ressources s'en sert pour l'afficher dans **Applications** avec son nom et son icône. Lancée depuis un terminal, elle reste rangée sous le terminal.

## Ce que fait l'appli

**Barre latérale.** On y trouve le sélecteur d'année scolaire, puis deux sections : **Appréciations** (une entrée par classe, avec le compteur d'élèves terminés) et **PFMP** (une entrée par classe *suivie en PFMP*, avec le compteur de conventions finalisées). Le réglage « Suivi des PFMP » de chaque classe décide si elle apparaît dans la section PFMP : on peut avoir plusieurs classes pour les appréciations et une seule pour les stages. L'ordre des classes se règle à la main, et vaut pour les deux sections : glisser-déposer une classe, clic droit *Monter* / *Descendre*, ou Alt+↑ / Alt+↓. Une nouvelle classe s'ajoute en dernier ; une nouvelle année reprend l'ordre de l'année copiée.

**Appréciations**

* À gauche, la saisie : appréciation de la matière choisie, puis bilan général. Au-dessus de chaque zone, les périodes précédentes en lecture seule.
* À droite, la liste des élèves (état, moyenne de la période, moyenne cumulée de l'année) et la liste des matières (état et moyenne importée pour l'élève affiché), avec un champ de recherche au-dessus (Ctrl+F).
* Le prénom s'inscrit automatiquement au début d'une appréciation vide, **sans virgule** par défaut (« Léa … »). La forme se règle dans Préférences : `Léa ` / `Léa, ` / `Léa : ` / `Léa – `. Un texte réduit au prénom compte comme vide.
* Banque de phrases : recherche par mots-clés sans tenir compte des accents, insertion en un clic, phrases personnelles avec catégorie et mots-clés, variable `{prénom}`. Juste après le prénom (« Léa » ou « Léa, »), la majuscule de la phrase insérée passe en minuscule.
* Compteur de caractères, avec une limite réglable par classe (avertissement à 90 %, erreur au-delà).
* Bouton **Copier** sur chaque zone, et un toast confirme la copie.
* Chaque appréciation est *vide*, *brouillon* ou *terminée* : les deux premiers états sont automatiques, *Terminé* se coche à la main. Un élève est terminé quand son bilan et toutes ses matières le sont. Une barre de progression suit la classe.
* Classe en 3 trimestres ou en 2 semestres.
* **Import des commentaires des collègues** (csv, xlsx, ods) : disciplines, moyennes et commentaires, soit une ligne par élève et par discipline, soit une colonne par discipline. Les disciplines manquantes peuvent être créées, et la moyenne générale calculée si elle manque.
* Import d'un tableur (csv, xlsx, ods) : les colonnes sont détectées, l'aperçu permet de corriger. Le nom et le prénom peuvent être dans une même colonne (« NOM Prénom »). La moyenne est rattachée à une période, et les élèves absents de la classe peuvent être ajoutés.
* **Mode conseil** (F11) : plein écran, un élève par page. Décision du conseil (aucune, félicitations, compliments, encouragements, avertissement travail, avertissement comportement, avertissement assiduité) et remarque.
* Export : récapitulatif PDF de la période, et ODS de l'année avec une feuille par période.

**PFMP**

* Deux PFMP par an, communes aux classes suivies, avec dates réglables.
* Pour chaque élève et chaque PFMP : la recherche (en cours ou terminée) et la convention (signature profs → signature parents → signature direction → finalisée), avec indicateur d'étapes et bouton « étape suivante ». La convention n'apparaît qu'une fois la recherche terminée ; le sélecteur de recherche est alors grisé dans la liste (on peut la rouvrir depuis la vue Élève). Les colonnes restent alignées d'une ligne à l'autre.
* Deux vues (Classe, Élève), avec recherche et filtres sur la recherche et sur la convention.
* **Répartition des suivis** : on définit l'équipe de l'année, puis les heures de chaque collègue par classe (saisies une fois par classe et par année). Le nombre d'élèves suivis vaut (heures ÷ total) × effectif. Le calcul se fait en fractions exactes, sans arrondi. L'affichage montre la fraction et une valeur à une décimale, par exemple `14/3 ≈ 4,7`, ou la valeur exacte quand elle tombe juste (`8`, `4,5`). Un bouton génère un PDF de bilan par collègue, qui liste aussi ses élèves attribués.
* **Visites PFMP** : élèves attribués à chaque collègue, avec entreprise d'accueil, adresse, téléphone, tuteur et date de visite. Chaque entreprise saisie entre dans un carnet réutilisable, conservé d'une année à l'autre. Le bouton Itinéraire ouvre `maps:q=…` dans GNOME Cartes s'il est installé, sinon `openstreetmap.org/search` dans le navigateur par défaut. La fenêtre d'attribution des élèves affiche l'entreprise et l'adresse du lieu de stage.
* **Carnet d'entreprises** (menu Modifier) : ajouter, modifier, retirer une entreprise, ouvrir son itinéraire. En modifiant une fiche, on peut reporter le nom, l'adresse et le téléphone sur les stages de cette entreprise (le tuteur seulement là où il était vide ou identique). Retirer une fiche ne touche pas aux stages déjà saisis.
* **Distances** : depuis l'adresse de l'établissement (Préférences), à vol d'oiseau. Les adresses sont localisées à la demande (bouton Distances, une requête par seconde) puis gardées dans la base ; une adresse modifiée est relocalisée au prochain calcul.
* **Exports des visites** : PDF avec une section par professeur référent (élèves, lieux de stage, téléphones, tuteurs, distances, dates de visite) et classeur xlsx des mêmes informations.

**Données**

* Chaque modification est écrite tout de suite dans SQLite (avec un délai de 0,5 s pendant la frappe). Une copie de la base est faite à chaque démarrage, et les 10 dernières sont gardées dans `sauvegardes/`.
* Export et import JSON complets. L'import remplace tout, après confirmation et sauvegarde.
* **Tout exporter (tableurs)** dans le menu général : un classeur xlsx par thème (classes, élèves, matières, appréciations, bilans, PFMP, visites, professeurs, entreprises).
* **Modifier** dans le menu général : un sous-menu qui rassemble toutes les éditions — chaque classe (élèves, matières, réglages, suivi PFMP), nouvelle classe, carnet d'entreprises, dates des PFMP, équipe pédagogique et heures, visites (élèves suivis, entreprises, tuteurs), banque de phrases, adresse de l'établissement et préférences, nouvelle année.
* **Toutes les commandes** dans le menu général : chaque commande, groupée par thème et classée par ordre alphabétique, avec recherche.
* Journal d'erreurs (`~/.local/share/livret/journal-erreurs.log`), ouvrable depuis le menu : une exception dans un bouton y laisse une trace au lieu de passer inaperçue.
* Le dossier de données de l'ancien nom (`~/.local/share/bulletin/`) est repris automatiquement.
* Archivage de l'année : elle passe en consultation seule, et un instantané JSON est écrit dans `archives/`. Elle peut être désarchivée. « Nouvelle année » reprend les classes, les matières et l'équipe, sans les élèves.

## Raccourcis

| Raccourci | Action |
|---|---|
| Ctrl+F | Rechercher un élève ou une matière |
| Alt+↓ / Alt+↑ | Élève suivant / précédent |
| Alt+→ / Alt+← | Matière suivante / précédente |
| Ctrl+Maj+C | Copier l'appréciation |
| Ctrl+Maj+B | Copier le bilan général |
| F11 | Mode conseil |
| Page suivante / précédente, Échap | Navigation et sortie dans le mode conseil |
| Ctrl+, / Ctrl+Q | Préférences / Quitter |

## Icônes

* L'icône installée est un **livret agrafé** portant un **faux portrait** (silhouette grise sur fond clair, comme l'avatar de GNOME), agrandi et centré sur la face avant (le dos agrafé exclu). Ni cartouche ni écriture manuscrite.
* Trois palettes GNOME officielles, dans `data/icons/variantes/` : `livret-rouge.svg` (rouge 3 `#e01b24` / rouge 5 `#a51d2d`, par défaut), `livret-vert.svg` (vert 3 `#33d17a` / vert 5 `#26a269`), `livret-violet.svg` (violet 1 `#dc8add` / violet 3 `#9141ac`). On change avec `_icone=` dans le `PKGBUILD`. `apercu-livret.png` les montre de 32 à 256 px.
* Version symbolique : `livret-symbolic.svg` (16 px, monochrome).
* Le dessin ne dépend pas du nom : Livret ou Bulletin, c'est la même icône.
* Icônes d'interface propres à l'appli : `data/icons/actions/` (phrases, itinéraire, répartition, visites, conseil). Les autres viennent du thème Adwaita.

Pour renommer l'appli : `APP_ID` dans `livret/__init__.py`, les noms des fichiers dans `data/`, et `pkgname` dans le `PKGBUILD`.

## Contraintes respectées

* 100 % GTK/libadwaita, sans Qt.
* Widgets Adw natifs : `ToolbarView`, `NavigationSplitView`, `OverlaySplitView`, `AlertDialog`, `Dialog`, `PreferencesDialog`, `*Row`, `ToggleGroup`, `ToastOverlay`, `Banner`, `Carousel`, `AboutDialog`, points de rupture.
* Couleurs de `style.css` uniquement par variables CSS libadwaita (`--accent-color`, `--success-bg-color`…). Les PDF, qui ne passent pas par CSS, utilisent la palette GNOME.
* Pas d'API dépréciée. Une recherche dans les GIR de GTK 4.24 et libadwaita 1.10 n'a trouvé que `Gtk.StyleContext.add_provider_for_display`. C'est une fonction non dépréciée de la classe dépréciée `GtkStyleContext`, et elle reste la manière officielle de charger une feuille de style. `GtkFileChooser`, `Adw.MessageDialog`, `Adw.PreferencesWindow`, `Gtk.show_uri` et `GtkTreeView` ne sont pas utilisés.
* Aucun module Python hors bibliothèque standard : xlsx, ods et csv sont lus avec `zipfile`, `xml` et `csv`, et les PDF sont produits avec cairo et Pango.

## Tests

### Testé hors session (conteneur, sans GNOME Shell)

Environnement : Ubuntu 24.04 avec une pile recompilée **GTK 4.24.1, libadwaita 1.10.0, GLib 2.90.1, Pango 1.58.2, PyGObject 3.58.1**, et **Python 3.13** (pas 3.14). Serveur X virtuel Xvfb, rendu `GSK_RENDERER=cairo`, `G_ENABLE_DIAGNOSTIC=1`.

* `python -m unittest discover -s tests` : 24 tests, tous réussis (base, états, moyennes, imports, archivage, phrases, PFMP, carnet, JSON, sauvegardes, répartition exacte, tableurs csv/xlsx/ods, PDF, **classes suivies en PFMP et migration d'une base existante**, **distances** avec réponses réseau simulées, **exports des visites** PDF et xlsx, **carnet d'entreprises** : modification avec report sur les stages, doublons refusés, suppression).
* `tests/saisie_clavier.sh` : **vraies frappes clavier** (xdotool) — nom complet d'une nouvelle classe, validation par Entrée, ajout d'un élève. Réussi. Le même test échoue sur la 1.0 (seul le dernier caractère restait).
* `tests/pilote_interface.py` : scénario complet sur une base de démonstration, **sans exception ni avertissement GTK ou Adwaita** : saisie T1/T2, phrase insérée sans virgule après le prénom, réglages de classe, mode conseil, vue PFMP (une seule classe suivie, colonnes alignées, recherche terminée grisée), répartition, visites avec distances (localisation simulée), exports des visites, sous-menu Modifier, carnet d'entreprises, toutes les commandes, banque de phrases, import csv, préférences, année archivée, fenêtre étroite, « À propos ».
* Paquet `livret-1.2.0-1-any.pkg.tar.zst` installé avec pacman dans une racine factice, vérifié avec `pacman -Qkk`, lancé depuis cette racine, désinstallé proprement. Aucun fichier sous `/usr/lib/python3.X/`.
* **Non testé ici** : la localisation réelle par Nominatim (le réseau du conteneur ne l'atteint pas).

### Testé en session GNOME réelle

**Rien pour l'instant.** À vérifier sur CachyOS / GNOME 51 :

- [ ] Python 3.14 (testé seulement en 3.13).
- [ ] Bouton Distances avec le vrai service Nominatim (adresses réelles, message en cas d'adresse introuvable ou de réseau absent).
- [ ] Sélecteurs de fichiers (`Gtk.FileDialog` via le portail) pour l'import, les exports et le dossier des PDF. Le scénario hors session les contourne faute de D-Bus.
- [ ] Coller dans le logiciel de vie scolaire depuis le bouton Copier (presse-papiers Wayland).
- [ ] Bouton Itinéraire : ouverture de GNOME Cartes (`maps:q=`), puis repli sur OpenStreetMap sans `gnome-maps`.
- [ ] Ouverture des PDF ou ODS exportés et du dossier des données (`Gtk.FileLauncher`).
- [ ] Ressources et Moniteur système : Livret listé parmi les applications, avec son nom et son icône, après un lancement depuis la grille.
- [ ] Icône dans la grille d'applications et dans le dock, plein écran du mode conseil sous Mutter, mise à l'échelle fractionnaire, thème clair et sombre, couleur d'accent.
- [ ] Lecteur d'écran (Orca) sur les pastilles d'état et les listes.
- [ ] Imports réels depuis l'export Pronote ou ENT de ton établissement (noms de colonnes).

## Arborescence

```
livret/            code Python (db, calculs, tableur, exports, interface) + style.css
lancer.py            point d'entrée installé dans /usr/lib/livret/
bin/livret         lanceur shell installé dans /usr/bin
data/                .desktop, metainfo, icônes (app, actions, variantes)
tests/               tests unitaires, pilote d'interface, base de démonstration
PKGBUILD
```

Licence : GPL-3.0-or-later.
