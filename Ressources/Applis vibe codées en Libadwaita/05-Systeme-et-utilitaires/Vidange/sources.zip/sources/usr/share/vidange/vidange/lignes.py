"""Vidange — lignes Adw affichant du texte brut.

Passé au constructeur, use_markup=False arrive après le titre et le sous-titre :
un texte contenant « < » ou « & » est alors lu comme du balisage. On le règle en premier.
"""


def rangee(classe, **proprietes):
    row = classe()
    row.set_use_markup(False)
    for nom, valeur in proprietes.items():
        row.set_property(nom.replace("_", "-"), valeur)
    return row
