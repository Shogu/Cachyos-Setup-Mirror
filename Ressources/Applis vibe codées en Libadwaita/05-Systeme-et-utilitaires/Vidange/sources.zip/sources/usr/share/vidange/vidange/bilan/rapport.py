"""Bilan : orchestration, versions suivies, rapport texte."""

import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from .. import backend as be
from . import extensions, lancement, paquets
from .commun import (A_CORRIGER, CASSE, ETAT, INFO, MARQUEUR, NIVEAUX, OK, SOI, Constat, Element, ecrire_json,
                     lignes, lire_json, maintenant, pluriel)

SUIVIS = ["gtk4", "libadwaita", "glib2", "python", "python-gobject", "gjs", "gnome-shell", "mutter", "nautilus"]
FAMILLES = [
    ("versions", "Système"),
    ("appli", "Applis"),
    ("nautilus", "Greffons Nautilus"),
    ("extension", "Extensions GNOME Shell"),
    ("python", "Python"),
    ("paquet", "Autres paquets hors dépôts"),
]

@dataclass
class Rapport:
    date: str
    elements: list

    def par_famille(self, famille):
        elements = [e for e in self.elements if e.famille == famille]
        if famille == "paquet":
            elements = [e for e in elements if e.niveau >= A_CORRIGER]
        return sorted(elements, key=lambda e: (-e.niveau, e.nom.lower()))

    def sans_probleme(self, famille):
        return sum(1 for e in self.elements if e.famille == famille and e.niveau < A_CORRIGER)

    @property
    def visibles(self):
        return [e for famille, _ in FAMILLES for e in self.par_famille(famille)]

    @property
    def niveau(self):
        return max((e.niveau for e in self.visibles), default=OK)

    @property
    def resume(self):
        compte = {n: sum(1 for e in self.visibles if e.niveau == n) for n in (CASSE, A_CORRIGER, INFO)}
        morceaux = [texte for n, texte in ((CASSE, pluriel(compte[CASSE], "cassé")),
                                           (A_CORRIGER, f"{compte[A_CORRIGER]} à corriger"),
                                           (INFO, pluriel(compte[INFO], "remarque"))) if compte[n]]
        return " · ".join(morceaux) if morceaux else "Aucun problème trouvé"

    @property
    def date_locale(self):
        return datetime.fromisoformat(self.date).astimezone().strftime("%d/%m/%Y à %H:%M")


def _courte(version):
    return re.sub(r"^\d+:", "", version).rsplit("-", 1)[0]


def versions_systeme():
    return dict(ligne.split()[:2] for ligne in lignes(["pacman", "-Q", *SUIVIS]) if len(ligne.split()) >= 2)


def element_versions(versions, precedentes):
    el = Element("versions", "Bibliothèques et GNOME",
                 " · ".join(f"{nom} {_courte(v)}" for nom, v in versions.items() if nom in ("gtk4", "libadwaita", "python", "gnome-shell")))
    if precedentes is None:
        el.ajouter(INFO, "Premier bilan", "Les changements de version seront signalés au prochain bilan.")
        return el
    for nom, version in versions.items():
        avant = precedentes.get(nom)
        if avant and avant != version:
            el.ajouter(INFO, f"{nom} : {_courte(avant)} → {_courte(version)}", "Depuis le bilan précédent.")
    return el


def element_python():
    el = Element("python", f"Python 3.{paquets.PYTHON_MINEUR}", "Dossiers laissés par les versions précédentes")
    for dossier in sorted(Path("/usr/lib").glob("python3.*")):
        mineur = dossier.name.removeprefix("python3.")
        if not mineur.isdigit() or int(mineur) == paquets.PYTHON_MINEUR or not dossier.is_dir():
            continue
        proprietaires = sorted(set(lignes(["pacman", "-Qoq", str(dossier)], timeout=120)))
        if proprietaires:
            el.ajouter(CASSE, f"{pluriel(len(proprietaires), 'paquet')} encore installé{'s' if len(proprietaires) > 1 else ''} "
                              f"pour Python 3.{mineur}", "À reconstruire : " + ", ".join(proprietaires))
        else:
            el.ajouter(INFO, f"{dossier} sans propriétaire", "Restes de pip ou de fichiers compilés ; peut être supprimé.")
    for dossier in sorted((be.HOME / ".local/lib").glob("python3.*")):
        mineur = dossier.name.removeprefix("python3.")
        if mineur.isdigit() and int(mineur) != paquets.PYTHON_MINEUR and any(dossier.rglob("*.py")):
            el.ajouter(INFO, f"Paquets pip --user pour Python 3.{mineur}", f"{dossier} n'est plus lu : réinstaller avec pip si besoin.")
    return el


def _cible(paquet):
    if paquet.nom == SOI or not paquet.desktops:
        return None
    return lancement.cible_desktop(paquet.desktops)


def applis_disponibles(reglages):
    """Liste (clé, nom, sous-titre, cochée) des applis qu'on peut lancer pendant le bilan."""
    choix = reglages["applis"]
    applis = []
    for paquet in paquets.inventaire():
        cible = _cible(paquet)
        if cible:
            applis.append((paquet.nom, cible[0], paquet.nom + ("" if paquet.maison else " · AUR ?"),
                           choix.get(paquet.nom, paquet.maison)))
    for path in lancement.appimages(reglages["dossiers_appimage"]):
        applis.append((str(path), path.stem, "AppImage", choix.get(str(path), True)))
    return sorted(applis, key=lambda a: a[1].lower())


def _famille(paquet):
    if paquet.desktops:
        return "appli"
    if paquet.greffons_nautilus:
        return "nautilus"
    if paquet.dossiers_extensions:
        return "paquet-extension"
    return "paquet"


def _journal_nautilus():
    return lignes(["journalctl", "-b", "-o", "cat", "--no-pager", "-n", "3000", "/usr/bin/nautilus"])


def _constats_nautilus(paquet, journal):
    noms = {Path(f).stem for f in paquet.greffons_nautilus} | {paquet.nom}
    trouvees = list(dict.fromkeys(ligne[:300] for ligne in journal if any(n in ligne for n in noms)))
    if not trouvees:
        return []
    return [Constat(A_CORRIGER, f"{pluriel(len(trouvees), 'message')} dans le journal de Fichiers depuis le démarrage",
                    "\n".join(trouvees[:15]))]


def faire_bilan(reglages, progression=lambda texte, fraction: None):
    choix = reglages["applis"]
    lancer = reglages["lancer"] and lancement.session_graphique()
    delai = reglages["delai"]

    progression("Inventaire des paquets hors dépôts…", 0.0)
    liste = paquets.inventaire()
    versions = versions_systeme()
    etat = lire_json(ETAT, None)
    elements = [element_versions(versions, etat and etat.get("versions")), element_python()]
    if reglages["lancer"] and not lancer:
        elements[0].ajouter(INFO, "Pas de session graphique", "Les applis n'ont pas été lancées.")

    journal_nautilus = _journal_nautilus() if any(p.greffons_nautilus for p in liste) else []
    dossiers_maison = {d for p in liste for d in p.dossiers_extensions}
    appimages = lancement.appimages(reglages["dossiers_appimage"])
    total = len(liste) + len(appimages) + 1

    for i, paquet in enumerate(liste):
        progression(f"Analyse de {paquet.nom}…", i / total)
        famille = _famille(paquet)
        el = Element(famille, paquet.nom, f"{paquet.nom} {paquet.version}", cle=paquet.nom)
        el.constats = paquets.analyser(paquet)
        if famille == "nautilus":
            el.constats += _constats_nautilus(paquet, journal_nautilus)
        cible = _cible(paquet)
        if cible:
            el.nom = cible[0]
            if lancer and choix.get(paquet.nom, paquet.maison):
                progression(f"Lancement de {cible[0]} ({delai} s)…", i / total)
                el.constats += lancement.tester(cible[1], delai, cible[2])
            else:
                el.sous_titre += " · non lancée"
        if famille == "paquet-extension":
            el.famille = "paquet"
        elements.append(el)

    for j, path in enumerate(appimages):
        progression(f"AppImage {path.name}…", (len(liste) + j) / total)
        el = Element("appli", path.stem, f"AppImage · {path.parent}", cle=str(path))
        el.constats = lancement.constats_appimage(path)
        if lancer and choix.get(str(path), True) and el.niveau < CASSE:
            progression(f"Lancement de {path.stem} ({delai} s)…", (len(liste) + j) / total)
            el.constats += lancement.tester([str(path)], delai)
        else:
            el.sous_titre += " · non lancée"
        elements.append(el)

    progression("Extensions GNOME Shell…", (total - 1) / total)
    elements += extensions.analyser(dossiers_maison)

    date = maintenant()
    ecrire_json(ETAT, {"date": date, "versions": versions})
    progression("Bilan terminé", 1.0)
    return Rapport(date, elements)


def bilan_conseille():
    """Résumé de la dernière mise à jour importante si aucun bilan n'a été fait depuis, sinon None."""
    marqueur = lire_json(MARQUEUR, None)
    if not marqueur or not marqueur.get("date"):
        return None
    etat = lire_json(ETAT, {}) or {}
    if etat.get("date", "") >= marqueur["date"]:
        return None
    return marqueur.get("resume", "mise à jour importante")


def texte(rapport):
    sortie = [f"Bilan Vidange du {rapport.date_locale}", rapport.resume, ""]
    for famille, titre in FAMILLES:
        elements = rapport.par_famille(famille)
        if not elements:
            continue
        sortie.append(f"== {titre} ==")
        for el in elements:
            sortie.append(f"[{NIVEAUX[el.niveau].upper()}] {el.nom}" + (f" — {el.sous_titre}" if el.sous_titre else ""))
            for c in sorted(el.constats, key=lambda c: -c.niveau):
                sortie.append(f"    • {c.texte}")
                sortie += [f"        {ligne}" for ligne in c.detail.splitlines()]
        if famille == "paquet" and rapport.sans_probleme("paquet"):
            sortie.append(f"    ({pluriel(rapport.sans_probleme('paquet'), 'autre paquet')} sans problème)")
        sortie.append("")
    return "\n".join(sortie).rstrip() + "\n"
