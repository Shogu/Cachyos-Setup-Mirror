# Vidange — guide détaillé

Nettoyage du système pour CachyOS / GNOME 51, en GTK4 et libadwaita (Python, PyGObject).
Vidange remplace la fonction fish `clean` et couvre tout ce que fait `archclean full`.

## Installation

```fish
cd vidange
makepkg -si
```

Ou, avec le paquet déjà compilé :

```fish
sudo pacman -U vidange-1.4.2-1-any.pkg.tar.zst
```

Ensuite, `archclean` peut être désinstallé :

```fish
sudo pacman -Rns archclean
```

## Ce que fait chaque ligne

Chaque catégorie affiche la place qu'elle libérera, calculée avant le nettoyage, et un interrupteur qui l'inclut dans « Tout nettoyer ». Les réglages sont gardés dans `~/.config/vidange/settings.json`.

### Vérification

Ce groupe réunit les quatre vues d'orphelins. Seuls les **orphelins sûrs** font partie de « Tout nettoyer ».


| Niveau | Recherche | Par défaut | Action |
|---|---|---|---|
| Orphelins sûrs | `pacman -Qtdq` | tout coché | `pacman -Rns`, après confirmation ; inclus dans « Tout nettoyer » |
| Orphelins à vérifier | `pacman -Qdq` puis simulation `pacman -Rsu --print` | rien de coché | suppression de la sélection, après confirmation |
| Installés explicitement, à vérifier | `pacman -Qetq`, après un avertissement | rien de coché | « Marquer comme dépendance » (`pacman -D --asdeps`) |

Les orphelins à vérifier excluent les orphelins sûrs : elles montrent ce que `orphans+` trouve en plus (paquets qui ne servent qu'entre eux, ou seulement comme dépendances optionnelles).

Chaque paquet se déplie sur l'essentiel de `pacman -Qi` : description, « requis par », « optionnel pour », date d'installation.

Cas typique du troisième niveau : `ttf-carlito` resté après la désinstallation d'OnlyOffice. On le marque comme dépendance, la liste des orphelins est relancée, et il y apparaît s'il ne sert vraiment à rien.

La place libérée n'est affichée qu'après une recherche.

### Caches système

- **Cache pacman** : `paccache -rk2` (2 versions gardées pour pouvoir revenir en arrière), ou `paccache -rk2` puis `paccache -ruk0` (vide aussi les paquets désinstallés), ou `pacman -Scc`.
- **Cache AUR** : uniquement `shelly purify standard --aur-cache`, sans moteur maison. Vidange répond « oui » aux confirmations de Shelly (l'option `-n` choisirait des réponses « sûres », qui peuvent être « non »). L'estimation ne compte que les paquets construits et leurs signatures ; le récapitulatif mesure ce que Shelly a réellement supprimé. Shelly appelle `sudo` en interne : la commande passe donc par le helper root, avec le même mot de passe unique que le reste, et vise bien ton cache `~/.cache/Shelly`. Si Shelly échoue, la ligne passe en avertissement avec son message.
- **Flatpak inutilisés** : `flatpak uninstall --unused -y`. La ligne reste disponible même sans Flatpak installé (« Flatpak n'est pas installé »).
- **Journaux systemd** : `journalctl --vacuum-size`, taille conservée réglable (200 Mo par défaut).

- **Cache des micrologiciels** : vide `/var/cache/fwupd` (métadonnées et micrologiciels téléchargés par fwupd), via le helper.

### Dossier personnel

- **Cache web des navigateurs** : vide le cache HTTP (`~/.cache/vivaldi`, `~/.cache/mozilla/firefox`, `~/.cache/chromium`, `~/.cache/google-chrome`). Un navigateur ouvert est sauté, avec un avertissement « Fermez … ». `profile-cleaner` ne touche pas à ce cache.
- **Caches de shaders** : `~/.cache/mesa_shader_cache`, `mesa_shader_cache_db`, `radv_builtin_shaders`, et les caches NVIDIA s'ils existent. GNOME Shell et les navigateurs les remplissent même sans jeu ; ils se reconstruisent à la demande.

- **Miniatures et corbeille** : `~/.cache/thumbnails`, puis `gio trash --empty`.
- **Caches de développement** : `pip cache purge`, `npm cache clean --force`, `yarn cache clean`, `go clean -cache -modcache`, `ccache -C` ; pour Rust (`~/.cargo/registry/cache`, `registry/src`, `git/checkouts`) et Zig (`~/.cache/zig`), qui n'ont pas de commande de nettoyage stable, les dossiers sont vidés. Ces caches se remplissent aussi quand Shelly construit des paquets AUR.
  Autres outils de build reconnus : `uv cache clean`, `pnpm store prune`, `bun pm cache rm`, `deno clean` ; et, sans commande de nettoyage stable, dossiers vidés pour sccache, Gradle (`~/.gradle/caches`), Electron et node-gyp. Vala et Meson n'ont pas de cache global : rien à vider. Seuls les outils dont le cache existe apparaissent.
- **Conteneurs** : `docker builder prune -f` et `docker image prune -f`, `podman image prune -f`. Uniquement le cache de build et les images orphelines (`<none>`) : jamais les conteneurs, les volumes ni les images utilisées. La place libérée vient du compte rendu de Docker ; la ligne affiche « ≈ » avant. Seuls les outils dont le cache existe sont traités.
- **Navigateurs** : `profile-cleaner` pour chaque profil trouvé (Vivaldi, Firefox, Chromium, Chrome). Le gain n'est pas prévisible (compactage des bases SQLite) : la ligne affiche « ≈ » et le récapitulatif donne le gain réel. Fermez le navigateur avant.

### Dossiers de configuration orphelins

Vue de vérification, hors de « Tout nettoyer ». Elle liste les dossiers de `~/.config`, `~/.local/share`, `~/.cache` et `~/.var/app` dont aucune appli installée ne semble correspondre.

La correspondance est **devinée d'après les noms** : le nom du dossier, ou l'un de ses morceaux (`org.gnome.TextEditor` → `TextEditor`), doit être identique à un paquet installé (`pacman -Qq`), à un fichier `.desktop` (nom, `Exec`, `StartupWMClass`), à un exécutable de `/usr/bin` ou à une appli Flatpak. La règle est volontairement stricte : la liste est complète quitte à proposer trop de dossiers, le tri se fait à la main. Un bouton ouvre chaque dossier dans Fichiers. Les dossiers partagés (`dconf`, `gtk-4.0`, `autostart`…) et ceux gérés par d'autres catégories ne le sont jamais.

Rien n'est coché par défaut, la liste est triée par taille, et chaque dossier coché part **à la corbeille** avec `gio trash` : on peut le récupérer.

### Mode simulation

Dans le menu, « Mode simulation » affiche un bandeau et transforme « Tout nettoyer » en « Simuler le nettoyage ». Rien n'est supprimé ni modifié, et aucun mot de passe n'est demandé :

- orphelins : `pacman -Rns --print` sur la sélection (pacman dit aussi s'il refuserait) ;
- cache pacman : `paccache -d` (simulation officielle) ;
- cache AUR : `shelly purify standard --aur-cache --dry-run` ;
- journaux, miniatures, corbeille, caches de développement : tailles mesurées ;
- navigateurs : liste des profils que `profile-cleaner` traiterait.

Les boutons des pages de paquets simulent aussi : « Supprimer la sélection » montre ce que `pacman -Rns` retirerait, « Marquer comme dépendance » ce qui serait marqué.

### Vérification après nettoyage

Chaque catégorie compare la place occupée avant et après. Si une commande a réussi alors qu'il y avait plus de 1 Mo à libérer et que rien n'a bougé, la ligne passe en avertissement au lieu d'afficher une coche.

### Tout nettoyer

Reproduit l'ancienne fonction : orphelins, cache pacman, journaux, puis navigateurs, cache AUR, miniatures et corbeille, caches de développement. Une confirmation liste les opérations, puis un récapitulatif donne la place réellement libérée par catégorie et les éventuelles erreurs.

Pas d'analyse ni de prévisualisation des gros fichiers : c'est voulu.

## Bilan après une mise à jour

Ligne « Bilan après une mise à jour » en haut de la fenêtre, ou `vidange --bilan` dans un terminal. Le bilan ne modifie rien : il lit l'état du système et lance quelques secondes les applis cochées.

| Famille | Ce qui est vérifié |
|---|---|
| Système | Versions de gtk4, libadwaita, glib2, python, python-gobject, gjs, gnome-shell, mutter, nautilus, et ce qui a changé depuis le bilan précédent |
| Applis (paquets hors dépôts avec un `.desktop`) | Bibliothèques introuvables (`ldd`), fichiers installés pour un ancien Python, erreurs et avertissements de syntaxe Python, widgets GTK/libadwaita dépréciés (paquets maison seulement), lancement de quelques secondes avec relevé des `Gtk-WARNING`, `Adwaita-CRITICAL`, exceptions Python et `DeprecationWarning` |
| AppImage | Fichiers des dossiers choisis : bit exécutable, présence de `fusermount3`, lancement de quelques secondes |
| Greffons Nautilus | Bibliothèques, syntaxe Python, messages de Fichiers dans le journal depuis le démarrage |
| Extensions GNOME Shell | Extensions de l'utilisateur et celles des paquets hors dépôts : état (via D-Bus), erreur de chargement, version de GNOME absente de `shell-version`, erreurs dans le journal du Shell depuis le démarrage, widgets dépréciés dans `prefs.js` |
| Python | Dossiers `/usr/lib/python3.X` d'anciennes versions et paquets qui y ont encore des fichiers (à reconstruire), paquets `pip --user` d'anciennes versions |
| Autres paquets hors dépôts | Mêmes vérifications statiques ; seuls ceux qui posent problème sont listés |

Niveaux : **Cassé** (ne démarre plus ou ne se charge plus), **À corriger** (petits bugs : avertissements, CSS, syntaxe qui cassera plus tard), **Remarque** (dépréciations, changements de version), **OK**.

Options, gardées dans `~/.config/vidange/bilan.json` : lancer ou non les applis, durée du test (5 s par défaut), applis à lancer (les paquets maison sont cochés d'office, ceux qui semblent venir de l'AUR non), dossiers d'AppImage (`~/Applications`, `~/AppImages`, `~/Applis`, `~/.local/bin` par défaut). Une appli déjà ouverte n'est pas relancée : la fermer avant le bilan.

En ligne de commande : `vidange --bilan [--sans-lancement] [--delai S]`. Code de sortie : 0 sans problème, 1 à corriger, 2 cassé. Le bouton de copie, en haut de la page, met le même rapport dans le presse-papiers.

### Rappel automatique

Le hook pacman `vidange-bilan.hook` retient les versions suivies dans `/var/lib/vidange/versions.json`. Quand l'une change de branche (GTK 4.20 → 4.22, libadwaita 1.8 → 1.9, Python 3.14 → 3.15, GNOME 50 → 51…), il l'écrit à la fin de la mise à jour, envoie une notification aux sessions ouvertes et Vidange affiche un bandeau jusqu'au prochain bilan. Les versions correctives (4.20.3 → 4.20.4) ne déclenchent rien.

## Sécurité

L'appli ne tourne jamais en root. Les opérations système passent par `/usr/lib/vidange/vidange-helper`, lancé par `pkexec` avec l'action polkit `io.gitlab.shogu.Vidange.helper` (`auth_admin_keep`).

- « Tout nettoyer » envoie toutes les opérations root en un seul appel : un seul mot de passe.
- Le helper n'accepte qu'une liste fermée d'actions : `remove`, `asdeps`, `pacman-cache` (3 modes), `journal`.
- Les noms de paquets sont validés, le `PATH` est fixé à `/usr/bin`, Python tourne en mode isolé (`-I`).
- Toutes les commandes passent par `subprocess.run([...])`, sans shell.

## Icône

Un bidon d'huile rouge qu'on remplit : le filet d'huile tombe dans le goulot, la jauge à droite montre le niveau. Version couleur 128 px et version symbolique 16 px dans `data/icons/`.

D'autres pistes sont gardées dans `data/icons/variantes/` (bidon rétro) et `data/icons/pistes/` (Écope, Bonde, Crépine, Tamis, Râteau, Benne).

## Fichiers installés

```
/usr/bin/vidange
/usr/lib/vidange/vidange-helper
/usr/lib/vidange/vidange-bilan-hook
/usr/share/vidange/vidange/*.py
/usr/share/vidange/vidange/bilan/*.py
/usr/share/libalpm/hooks/vidange-bilan.hook
/var/lib/vidange/
/usr/share/applications/io.gitlab.shogu.Vidange.desktop
/usr/share/polkit-1/actions/io.gitlab.shogu.Vidange.policy
/usr/share/icons/hicolor/scalable/apps/io.gitlab.shogu.Vidange.svg
/usr/share/icons/hicolor/symbolic/apps/io.gitlab.shogu.Vidange-symbolic.svg
```
