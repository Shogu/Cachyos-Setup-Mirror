"""Vidange — exécution des tâches bloquantes hors du fil GTK."""

import threading

from gi.repository import GLib


def in_background(func, done, *args):
    """Exécute func(*args) dans un fil, puis done(résultat, erreur) dans GTK."""
    def worker():
        try:
            result, error = func(*args), None
        except Exception as exc:  # noqa: BLE001 — remonté à l'interface
            result, error = None, exc
        GLib.idle_add(lambda: done(result, error) and False)
    threading.Thread(target=worker, daemon=True).start()
