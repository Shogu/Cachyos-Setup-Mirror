"""Bilan : lecture des sources (syntaxe Python, API GTK/libadwaita dépréciées)."""

import io
import re
import token
import tokenize
import warnings
from collections import Counter
from pathlib import Path

from .commun import A_CORRIGER, CASSE, INFO, Constat, pluriel

MAX_FICHIERS = 1500
MAX_OCTETS = 2_000_000
EXTENSIONS = (".py", ".js", ".ui", ".blp", ".vala")


def _classe(nom):
    espace, classe = nom.split(".", 1)
    return re.compile(rf"\b{espace}\.?{classe}\b")


_REMPLACANTS = [
    ("Gtk.TreeView", "Gtk.ColumnView ou Gtk.ListView"),
    ("Gtk.TreeStore", "Gio.ListStore + Gtk.TreeListModel"),
    ("Gtk.ListStore", "Gio.ListStore"),
    ("Gtk.IconView", "Gtk.GridView"),
    ("Gtk.ComboBox", "Gtk.DropDown"),
    ("Gtk.ComboBoxText", "Gtk.DropDown"),
    ("Gtk.EntryCompletion", "une liste de suggestions dans un Gtk.Popover"),
    ("Gtk.FileChooserDialog", "Gtk.FileDialog"),
    ("Gtk.FileChooserNative", "Gtk.FileDialog"),
    ("Gtk.FileChooserWidget", "Gtk.FileDialog"),
    ("Gtk.AppChooserDialog", "une liste Gio.AppInfo dans un Adw.Dialog"),
    ("Gtk.AppChooserButton", "Gtk.DropDown alimenté par Gio.AppInfo"),
    ("Gtk.ColorChooserDialog", "Gtk.ColorDialog"),
    ("Gtk.ColorButton", "Gtk.ColorDialogButton"),
    ("Gtk.FontChooserDialog", "Gtk.FontDialog"),
    ("Gtk.FontButton", "Gtk.FontDialogButton"),
    ("Gtk.MessageDialog", "Adw.AlertDialog"),
    ("Gtk.Dialog", "Adw.Dialog ou Adw.AlertDialog"),
    ("Gtk.InfoBar", "Adw.Banner"),
    ("Gtk.Statusbar", "un Gtk.Label ou un Adw.Toast"),
    ("Gtk.VolumeButton", "Gtk.Scale"),
    ("Gtk.show_uri", "Gtk.UriLauncher"),
    ("Adw.MessageDialog", "Adw.AlertDialog"),
    ("Adw.Leaflet", "Adw.NavigationSplitView"),
    ("Adw.Flap", "Adw.OverlaySplitView"),
    ("Adw.Squeezer", "Adw.MultiLayoutView ou Adw.Breakpoint"),
    ("Adw.ViewSwitcherTitle", "Adw.ViewSwitcher + Adw.Breakpoint"),
    ("Adw.AboutWindow", "Adw.AboutDialog"),
]

DEPRECIES = [(_classe(ancien), ancien, nouveau) for ancien, nouveau in _REMPLACANTS] + [
    (re.compile(r"\bget_style_context\s*\("), "get_style_context()", "add_css_class() / remove_css_class()"),
    (re.compile(r"\bGtk\.?StyleContext\b(?!\.(add|remove)_provider_for_display)"), "Gtk.StyleContext",
     "add_css_class(), ou Gtk.StyleContext.add_provider_for_display() qui reste valable"),
    (re.compile(r"new\s+Adw\.PreferencesWindow|\bAdw\.PreferencesWindow\s*\("), "Adw.PreferencesWindow", "Adw.PreferencesDialog"),
    (re.compile(r"\.load_from_data\s*\("), "Gtk.CssProvider.load_from_data()", "load_from_string() ou load_from_bytes()"),
    (re.compile(r"\bTexture\.new_for_pixbuf\b"), "Gdk.Texture.new_for_pixbuf()", "Gdk.MemoryTexture ou Gdk.Texture.new_from_bytes()"),
]


def est_python(chemin):
    if chemin.endswith(".py"):
        return True
    nom = Path(chemin).name
    if "." in nom or not chemin.startswith(("/usr/bin/", "/usr/lib/", "/usr/share/")):
        return False
    try:
        with open(chemin, "rb") as f:
            tete = f.readline(120)
    except OSError:
        return False
    return tete.startswith(b"#!") and b"python" in tete


RE_COMMENTAIRE_C = re.compile(r"/\*.*?\*/|(?<![:'\"\w])//[^\n]*", re.S)
RE_COMMENTAIRE_XML = re.compile(r"<!--.*?-->", re.S)
MASQUES_PY = {token.COMMENT, token.STRING} | {getattr(token, n) for n in ("FSTRING_MIDDLE", "TSTRING_MIDDLE") if hasattr(token, n)}


def _masquer_python(texte):
    """Remplace commentaires et chaînes par des espaces, pour ne chercher que dans le code."""
    debuts = [0]
    for ligne in texte.splitlines(keepends=True):
        debuts.append(debuts[-1] + len(ligne))
    caracteres = list(texte)
    try:
        for tok in tokenize.generate_tokens(io.StringIO(texte).readline):
            if tok.type in MASQUES_PY:
                debut = debuts[tok.start[0] - 1] + tok.start[1]
                fin = debuts[tok.end[0] - 1] + tok.end[1]
                caracteres[debut:fin] = [c if c == "\n" else " " for c in texte[debut:fin]]
    except (tokenize.TokenError, SyntaxError):
        return texte
    return "".join(caracteres)


def code_seul(texte, chemin, python):
    if python:
        return _masquer_python(texte)
    if chemin.endswith(".ui"):
        return RE_COMMENTAIRE_XML.sub(" ", texte)
    return RE_COMMENTAIRE_C.sub(" ", texte)


def _lire(chemin):
    path = Path(chemin)
    try:
        if path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_OCTETS:
            return None
        return path.read_text(errors="replace")
    except OSError:
        return None


def _compiler(texte, chemin, erreurs, alertes):
    with warnings.catch_warnings(record=True) as releves:
        warnings.simplefilter("always")
        try:
            compile(texte, chemin, "exec", dont_inherit=True)
        except SyntaxError as exc:
            erreurs.append(f"{chemin}:{exc.lineno} : {exc.msg}")
    for w in releves:
        if issubclass(w.category, (SyntaxWarning, DeprecationWarning)):
            alertes.append(f"{chemin}:{w.lineno} : {w.message}")


def analyser(fichiers, python=True, api=True):
    """Constats sur une liste de fichiers : erreurs de syntaxe Python et API dépréciées."""
    erreurs, alertes = [], []
    compteur = Counter()
    lus = 0
    for chemin in fichiers:
        py = python and est_python(chemin)
        if not py and not (api and chemin.endswith(EXTENSIONS)):
            continue
        texte = _lire(chemin)
        if texte is None:
            continue
        lus += 1
        if lus > MAX_FICHIERS:
            break
        if py:
            _compiler(texte, chemin, erreurs, alertes)
        if api:
            code = code_seul(texte, chemin, py)
            for motif, ancien, nouveau in DEPRECIES:
                n = len(motif.findall(code))
                if n:
                    compteur[(ancien, nouveau)] += n

    constats = []
    if erreurs:
        constats.append(Constat(CASSE, f"{pluriel(len(erreurs), 'erreur')} de syntaxe Python", "\n".join(erreurs[:15])))
    if alertes:
        constats.append(Constat(A_CORRIGER, f"{pluriel(len(alertes), 'avertissement')} de syntaxe Python",
                                "Deviendront des erreurs dans une future version de Python.\n" + "\n".join(alertes[:15])))
    for (ancien, nouveau), n in sorted(compteur.items()):
        constats.append(Constat(INFO, f"{ancien} ×{n} : déprécié", f"Remplaçant : {nouveau}. Fonctionne jusqu'à GTK 5 / libadwaita 2."))
    return constats
