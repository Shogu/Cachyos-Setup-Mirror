"""Bilan après une mise à jour : applis maison, greffons Nautilus, extensions, Python.

Rien n'est modifié : ces modules lisent l'état du système et lancent les applis
cochées quelques secondes pour relever leurs messages.
"""
