"""Bilan : paquets installés hors des dépôts (maison et AUR)."""

import re
import sys
from dataclasses import dataclass, field
from pathlib import Path

from .. import backend as be
from . import sources
from .commun import A_CORRIGER, CASSE, INFO, SOI, Constat, lignes

PYTHON_MINEUR = sys.version_info.minor
RE_PYTHON = re.compile(r"^/usr/lib/python3\.(\d+)/")
DOSSIERS_ELF = ("/usr/bin/", "/usr/lib/", "/usr/libexec/", "/opt/")
MAX_ELF = 200
EXTENSIONS_SHELL = "/usr/share/gnome-shell/extensions/"
NAUTILUS = ("/usr/lib/nautilus/extensions-4/", "/usr/share/nautilus-python/extensions/")
CACHES_AUR = [be.XDG_CACHE / "yay", be.XDG_CACHE / "paru" / "clone", be.XDG_CACHE / "Shelly",
              be.XDG_CACHE / "pikaur" / "build", be.XDG_CACHE / "trizen"]
SIGNES_MAISON = ("shogu", "ogu")


@dataclass
class Paquet:
    nom: str
    version: str
    url: str = ""
    packager: str = ""
    fichiers: list = field(default_factory=list)

    @property
    def desktops(self):
        return [f for f in self.fichiers if f.startswith("/usr/share/applications/") and f.endswith(".desktop")]

    @property
    def dossiers_extensions(self):
        return sorted({"/".join(f.split("/")[:6]) for f in self.fichiers
                       if f.startswith(EXTENSIONS_SHELL) and f.count("/") > 5})

    @property
    def greffons_nautilus(self):
        return [f for f in self.fichiers if f.startswith(NAUTILUS) and f.endswith((".so", ".py"))]

    @property
    def maison(self):
        """Devine si le paquet est fait maison (coché par défaut) plutôt que venu de l'AUR."""
        signes = " ".join([self.nom, self.url, self.packager, *self.desktops]).lower()
        if any(s in signes for s in SIGNES_MAISON):
            return True
        return not any((d / self.nom).is_dir() for d in CACHES_AUR)


def _infos(noms):
    infos, courant = {}, {}
    for ligne in lignes(["pacman", "-Qi", *noms]) + [""]:
        if not ligne.strip():
            if "Name" in courant:
                infos[courant["Name"]] = courant
            courant = {}
            continue
        cle, sep, valeur = ligne.partition(" : ")
        if sep:
            courant[cle.strip()] = valeur.strip()
    return infos


def inventaire():
    paquets = {}
    for ligne in lignes(["pacman", "-Qm"]):
        nom, _, version = ligne.partition(" ")
        if nom and not nom.endswith("-debug"):
            paquets[nom] = Paquet(nom, version.strip())
    for ligne in lignes(["pacman", "-Qlm"], timeout=120):
        nom, _, chemin = ligne.partition(" ")
        if nom in paquets and not chemin.endswith("/"):
            paquets[nom].fichiers.append(chemin)
    if paquets:
        for nom, info in _infos(list(paquets)).items():
            if nom in paquets:
                paquets[nom].url = info.get("URL", "")
                paquets[nom].packager = info.get("Packager", "")
    return sorted(paquets.values(), key=lambda p: p.nom)


def _version_python(chemin):
    m = RE_PYTHON.match(chemin)
    return int(m.group(1)) if m else None


def constats_python(paquet, appli):
    constats = []
    for mineur in sorted({v for f in paquet.fichiers if (v := _version_python(f)) is not None}):
        if mineur != PYTHON_MINEUR:
            constats.append(Constat(CASSE, f"Installé pour Python 3.{mineur}, ignoré par Python 3.{PYTHON_MINEUR}",
                                    "Reconstruire le paquet (pkgrel + 1)."))
        elif appli:
            constats.append(Constat(A_CORRIGER, f"Code dans /usr/lib/python3.{mineur}/ : cassera à la prochaine version de Python",
                                    f"Le déplacer dans /usr/lib/{paquet.nom}/ avec un lanceur minimal dans /usr/bin."))
        else:
            constats.append(Constat(INFO, "Bibliothèque Python : à reconstruire à chaque version de Python"))
    return constats


def _est_elf(chemin):
    try:
        with open(chemin, "rb") as f:
            return f.read(4) == b"\x7fELF"
    except OSError:
        return False


def _manquantes(chemin):
    r = be.run(["ldd", chemin], timeout=15)
    if r is None:
        return []
    return [ligne.split("=>")[0].strip() for ligne in r.stdout.splitlines() if "=> not found" in ligne]


def constats_bibliotheques(paquet):
    manquantes = {}
    elf = 0
    for chemin in paquet.fichiers:
        if elf >= MAX_ELF:
            break
        if not chemin.startswith(DOSSIERS_ELF) or _version_python(chemin) not in (None, PYTHON_MINEUR):
            continue
        path = Path(chemin)
        if path.is_symlink() or not path.is_file() or not _est_elf(chemin):
            continue
        elf += 1
        for lib in _manquantes(chemin):
            manquantes.setdefault(lib, []).append(chemin)
    fournies = {Path(f).name for f in paquet.fichiers}
    manquantes = {lib: fichiers for lib, fichiers in manquantes.items() if lib not in fournies}
    return [Constat(CASSE, f"Bibliothèque introuvable : {lib}", "Recompiler le paquet. Concerné : " + ", ".join(fichiers[:5]))
            for lib, fichiers in sorted(manquantes.items())]


def constats_sources(paquet):
    fichiers = [f for f in paquet.fichiers
                if _version_python(f) in (None, PYTHON_MINEUR) and not f.startswith(EXTENSIONS_SHELL)]
    return sources.analyser(fichiers, api=paquet.maison and paquet.nom != SOI)


def analyser(paquet):
    """Constats statiques d'un paquet ; le lancement éventuel se fait à part."""
    appli = bool(paquet.desktops) or any(f.startswith("/usr/bin/") for f in paquet.fichiers)
    return (constats_bibliotheques(paquet) + constats_python(paquet, appli) + constats_sources(paquet))
