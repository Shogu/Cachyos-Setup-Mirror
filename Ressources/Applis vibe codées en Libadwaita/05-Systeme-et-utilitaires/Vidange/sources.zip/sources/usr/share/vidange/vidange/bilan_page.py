"""Vidange — page « Bilan après une mise à jour »."""

from pathlib import Path

from gi.repository import Adw, Gdk, GLib, GObject, Gtk, Pango

from . import backend as be
from .bilan import commun as bc
from .bilan import rapport
from .bilan.commun import A_CORRIGER, CASSE, INFO, OK
from .lignes import rangee
from .taches import in_background

ICONES = {
    OK: ("object-select-symbolic", "success"),
    INFO: ("dialog-information-symbolic", "accent"),
    A_CORRIGER: ("dialog-warning-symbolic", "warning"),
    CASSE: ("dialog-error-symbolic", "error"),
}


def icone(niveau):
    nom, style = ICONES[niveau]
    return Gtk.Image(icon_name=nom, css_classes=[style], tooltip_text=bc.NIVEAUX[niveau])


def ligne_element(el):
    if not el.constats:
        row = rangee(Adw.ActionRow, title=el.nom, subtitle=el.sous_titre)
        row.add_prefix(icone(OK))
        return row
    row = rangee(Adw.ExpanderRow, title=el.nom, subtitle=el.sous_titre, expanded=el.niveau == CASSE)
    row.add_prefix(icone(el.niveau))
    for c in sorted(el.constats, key=lambda c: -c.niveau):
        sub = rangee(Adw.ActionRow, title=c.texte, subtitle=c.detail, title_lines=0, subtitle_lines=0,
                            subtitle_selectable=True)
        sub.add_prefix(icone(c.niveau))
        row.add_row(sub)
    return row


def _replier(chemin):
    path = Path(chemin)
    return "~/" + str(path.relative_to(be.HOME)) if path.is_relative_to(be.HOME) else str(path)


class BilanPage(Adw.NavigationPage):

    def __init__(self, win):
        super().__init__(title="Bilan après une mise à jour", tag="bilan")
        self.win = win
        self.reglages = bc.charger_reglages()
        self.resultat = None
        self.en_cours = False
        self.groupes = []
        self.lignes_applis = []
        self.lignes_dossiers = []

        view = Adw.ToolbarView()
        header = Adw.HeaderBar()
        self.copier_btn = Gtk.Button(icon_name="edit-copy-symbolic", tooltip_text="Copier le rapport", sensitive=False)
        self.copier_btn.connect("clicked", self.on_copier)
        header.pack_end(self.copier_btn)
        view.add_top_bar(header)

        self.page = Adw.PreferencesPage()
        self.page.add(self.groupe_options())
        view.set_content(self.page)

        bar = Gtk.ActionBar()
        self.spinner = Adw.Spinner(visible=False)
        bar.pack_start(self.spinner)
        self.etat_label = Gtk.Label(css_classes=["dim-label"], ellipsize=Pango.EllipsizeMode.END,
                                    label="Rien n'est modifié : le bilan ne fait que lire et lancer.")
        bar.pack_start(self.etat_label)
        self.lancer_btn = Gtk.Button(label="Lancer le bilan", css_classes=["suggested-action", "pill"])
        self.lancer_btn.connect("clicked", self.on_lancer)
        bar.pack_end(self.lancer_btn)
        view.add_bottom_bar(bar)

        self.set_child(view)
        self.charger_applis()

    # -------------------------------------------------------------- options

    def groupe_options(self):
        group = Adw.PreferencesGroup(
            title="Options",
            description="À faire après chaque version de GNOME, de GTK, de libadwaita ou de Python.")
        lancer = Adw.SwitchRow(title="Lancer les applis", active=self.reglages["lancer"],
                               subtitle="Chaque appli cochée s'ouvre quelques secondes, ses messages sont relevés")
        lancer.connect("notify::active", lambda row, _p: self.modifier("lancer", row.get_active()))
        group.add(lancer)

        delai = Adw.SpinRow.new_with_range(3, 30, 1)
        delai.set_title("Durée du test")
        delai.set_subtitle("En secondes, pour chaque appli")
        delai.set_value(self.reglages["delai"])
        delai.connect("notify::value", lambda row, _p: self.modifier("delai", int(row.get_value())))
        group.add(delai)

        self.applis_row = Adw.ExpanderRow(title="Applis à lancer", subtitle="Recherche des applis…")
        group.add(self.applis_row)
        for row in (delai, self.applis_row):
            lancer.bind_property("active", row, "sensitive", GObject.BindingFlags.SYNC_CREATE)

        self.dossiers_row = Adw.ExpanderRow(title="Dossiers d'AppImage", subtitle="Les AppImage qu'ils contiennent sont testées")
        ajouter = Gtk.Button(icon_name="list-add-symbolic", valign=Gtk.Align.CENTER, css_classes=["flat"],
                             tooltip_text="Ajouter un dossier")
        ajouter.connect("clicked", self.on_ajouter_dossier)
        self.dossiers_row.add_suffix(ajouter)
        group.add(self.dossiers_row)
        self.remplir_dossiers()
        return group

    def modifier(self, cle, valeur):
        self.reglages[cle] = valeur
        bc.enregistrer_reglages(self.reglages)

    def charger_applis(self):
        def done(applis, error):
            for row in self.lignes_applis:
                self.applis_row.remove(row)
            self.lignes_applis = []
            if error is not None:
                self.applis_row.set_subtitle(f"Recherche impossible : {error}")
                return
            for cle, nom, sous_titre, cochee in applis:
                row = rangee(Adw.ActionRow, title=nom, subtitle=sous_titre)
                check = Gtk.CheckButton(active=cochee, valign=Gtk.Align.CENTER)
                check.connect("toggled", self.on_appli_cochee, cle)
                row.add_prefix(check)
                row.set_activatable_widget(check)
                self.applis_row.add_row(row)
                self.lignes_applis.append(row)
            self.maj_compte_applis()

        in_background(rapport.applis_disponibles, done, bc.copie(self.reglages))

    def maj_compte_applis(self):
        total = len(self.lignes_applis)
        cochees = sum(1 for row in self.lignes_applis if row.get_activatable_widget().get_active())
        self.applis_row.set_subtitle(f"{cochees} cochée{'s' if cochees > 1 else ''} sur {total}" if total
                                     else "Aucune appli hors dépôts trouvée")

    def on_appli_cochee(self, check, cle):
        self.reglages["applis"][cle] = check.get_active()
        bc.enregistrer_reglages(self.reglages)
        self.maj_compte_applis()

    def remplir_dossiers(self):
        for row in self.lignes_dossiers:
            self.dossiers_row.remove(row)
        self.lignes_dossiers = []
        for dossier in self.reglages["dossiers_appimage"]:
            row = rangee(Adw.ActionRow, title=dossier,
                                subtitle="" if Path(dossier).expanduser().is_dir() else "Dossier absent")
            retirer = Gtk.Button(icon_name="user-trash-symbolic", valign=Gtk.Align.CENTER, css_classes=["flat"],
                                 tooltip_text="Retirer de la liste")
            retirer.connect("clicked", self.on_retirer_dossier, dossier)
            row.add_suffix(retirer)
            self.dossiers_row.add_row(row)
            self.lignes_dossiers.append(row)

    def on_ajouter_dossier(self, *_):
        dialog = Gtk.FileDialog(title="Choisir un dossier d'AppImage")

        def choisi(dlg, resultat):
            try:
                dossier = dlg.select_folder_finish(resultat)
            except GLib.Error:
                return
            chemin = _replier(dossier.get_path())
            if chemin not in self.reglages["dossiers_appimage"]:
                self.modifier("dossiers_appimage", self.reglages["dossiers_appimage"] + [chemin])
                self.remplir_dossiers()
                self.charger_applis()

        dialog.select_folder(self.win, None, choisi)

    def on_retirer_dossier(self, _button, dossier):
        self.modifier("dossiers_appimage", [d for d in self.reglages["dossiers_appimage"] if d != dossier])
        self.remplir_dossiers()
        self.charger_applis()

    # ---------------------------------------------------------------- bilan

    def on_lancer(self, *_):
        if self.en_cours:
            return
        self.en_cours = True
        self.lancer_btn.set_sensitive(False)
        self.copier_btn.set_sensitive(False)
        self.spinner.set_visible(True)
        for group in self.groupes:
            self.page.remove(group)
        self.groupes = []

        def progression(texte, _fraction):
            GLib.idle_add(lambda: self.etat_label.set_label(texte) and False)

        in_background(rapport.faire_bilan, self.on_fini, bc.copie(self.reglages), progression)

    def on_fini(self, resultat, error):
        self.en_cours = False
        self.lancer_btn.set_sensitive(True)
        self.spinner.set_visible(False)
        if error is not None:
            self.etat_label.set_label("Bilan interrompu")
            self.win.toast(f"Bilan interrompu : {error}")
            return
        self.resultat = resultat
        self.copier_btn.set_sensitive(True)
        self.etat_label.set_label(f"{resultat.resume} · {resultat.date_locale}")
        self.afficher(resultat)
        self.win.bilan_fait()

    def afficher(self, resultat):
        resume = Adw.PreferencesGroup(title="Résultat")
        row = rangee(Adw.ActionRow, title=resultat.resume, subtitle=f"Bilan du {resultat.date_locale}")
        row.add_prefix(icone(resultat.niveau))
        resume.add(row)
        self.ajouter_groupe(resume)
        for famille, titre in rapport.FAMILLES:
            elements = resultat.par_famille(famille)
            autres = resultat.sans_probleme(famille) if famille == "paquet" else 0
            if not elements and not autres:
                continue
            group = Adw.PreferencesGroup(
                title=titre,
                description=f"{bc.pluriel(autres, 'autre paquet')} sans problème" if autres else None)
            for el in elements:
                group.add(ligne_element(el))
            self.ajouter_groupe(group)

    def ajouter_groupe(self, group):
        self.page.add(group)
        self.groupes.append(group)

    def on_copier(self, *_):
        texte = rapport.texte(self.resultat)
        self.get_clipboard().set_content(Gdk.ContentProvider.new_for_value(texte))
        self.win.toast("Rapport copié")

