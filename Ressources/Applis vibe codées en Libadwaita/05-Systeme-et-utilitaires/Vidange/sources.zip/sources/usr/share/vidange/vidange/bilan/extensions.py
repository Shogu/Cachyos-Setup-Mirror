"""Bilan : extensions GNOME Shell (état, version déclarée, journal, API dépréciées)."""

import json
import re
from pathlib import Path

from gi.repository import Gio, GLib

from . import sources
from .commun import A_CORRIGER, CASSE, INFO, Constat, Element, lignes

ACTIVE, INACTIVE, ERREUR, PERIMEE = 1, 2, 3, 4
PAR_UTILISATEUR = 2
ETATS = {ACTIVE: "active", INACTIVE: "désactivée", ERREUR: "en erreur", PERIMEE: "version non déclarée"}
RE_FRAME = re.compile(r"@\S*:\d+(:\d+)?$")
RE_ERREUR = re.compile(r"JS ERROR|Error|Exception|TypeError")
MAX_LIGNES = 15


def _appel(bus, interface, methode, parametres, type_retour):
    return bus.call_sync("org.gnome.Shell.Extensions", "/org/gnome/Shell/Extensions", interface, methode, parametres,
                         GLib.VariantType(type_retour), Gio.DBusCallFlags.NONE, 5000, None).unpack()


def lister():
    """(version de GNOME Shell, {uuid: infos}) ; GLib.Error si le Shell est injoignable."""
    bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
    version = _appel(bus, "org.freedesktop.DBus.Properties", "Get",
                     GLib.Variant("(ss)", ("org.gnome.Shell.Extensions", "ShellVersion")), "(v)")[0]
    extensions = _appel(bus, "org.gnome.Shell.Extensions", "ListExtensions", None, "(a{sa{sv}})")[0]
    return version, extensions


def verification_desactivee():
    source = Gio.SettingsSchemaSource.get_default()
    if source is None or source.lookup("org.gnome.shell", True) is None:
        return False
    return Gio.Settings.new("org.gnome.shell").get_boolean("disable-extension-version-validation")


def _blocs(journal):
    bloc = []
    for ligne in journal:
        if bloc and RE_FRAME.search(ligne):
            bloc.append(ligne)
            continue
        if bloc:
            yield bloc
        bloc = [ligne]
    if bloc:
        yield bloc


def journal_shell():
    return list(_blocs(lignes(["journalctl", "-b", "-o", "cat", "--no-pager", "-n", "5000", "/usr/bin/gnome-shell"])))


def _constats_journal(blocs, uuid, dossier):
    erreurs, depreciations = [], []
    for bloc in blocs:
        if not any(uuid in ligne or dossier in ligne for ligne in bloc):
            continue
        resume = " · ".join(bloc[:2])[:300]
        if RE_ERREUR.search(bloc[0]):
            erreurs.append(resume)
        elif "deprecat" in bloc[0].lower() or "WARNING" in bloc[0]:
            depreciations.append(resume)
    constats = []
    for liste, niveau, mot in ((erreurs, A_CORRIGER, "erreur"), (depreciations, INFO, "avertissement")):
        uniques = list(dict.fromkeys(liste))
        if uniques:
            constats.append(Constat(niveau, f"{len(uniques)} {mot}{'s' if len(uniques) > 1 else ''} dans le journal du Shell "
                                            "depuis le démarrage", "\n".join(uniques[:MAX_LIGNES])))
    return constats


def _versions_declarees(dossier):
    try:
        return [str(v) for v in json.loads((Path(dossier) / "metadata.json").read_text()).get("shell-version", [])]
    except (OSError, ValueError):
        return []


def analyser(dossiers_maison):
    """Éléments pour les extensions de l'utilisateur, celles des paquets hors dépôts et celles en erreur."""
    try:
        version, extensions = lister()
    except GLib.Error as exc:
        el = Element("extension", "GNOME Shell injoignable")
        el.ajouter(INFO, "Extensions non vérifiées", f"Lancer le bilan depuis la session GNOME. ({exc.message})")
        return [el]
    majeure = version.split(".")[0]
    sans_verification = verification_desactivee()
    blocs = journal_shell()
    elements = []
    for uuid, infos in extensions.items():
        dossier = infos.get("path", "")
        etat = int(infos.get("state", 0))
        if infos.get("type") != PAR_UTILISATEUR and dossier not in dossiers_maison and etat != ERREUR:
            continue
        el = Element("extension", infos.get("name") or uuid, f"{uuid} · {ETATS.get(etat, 'état ' + str(etat))}", cle=uuid)
        if etat == ERREUR:
            el.ajouter(CASSE, "Erreur au chargement", infos.get("error", ""))
        elif etat == PERIMEE:
            el.ajouter(A_CORRIGER, f"GNOME {majeure} absent de shell-version", f"Ajouter \"{majeure}\" dans metadata.json.")
        elif sans_verification and majeure not in _versions_declarees(dossier):
            el.ajouter(INFO, f"GNOME {majeure} absent de shell-version", "La vérification des versions est désactivée : "
                                                                          "l'extension se charge quand même.")
        if dossier:
            el.constats += _constats_journal(blocs, uuid, dossier)
            fichiers = [str(p) for p in Path(dossier).rglob("*.js")]
            el.constats += sources.analyser(fichiers, python=False)
        elements.append(el)
    return elements
