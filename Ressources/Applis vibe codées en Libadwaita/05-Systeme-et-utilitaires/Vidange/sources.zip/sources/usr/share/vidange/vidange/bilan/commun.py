"""Bilan : niveaux, constats, réglages et état enregistré."""

import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from .. import backend as be

OK, INFO, A_CORRIGER, CASSE = range(4)
SOI = "vidange"
NIVEAUX = {OK: "OK", INFO: "Remarque", A_CORRIGER: "À corriger", CASSE: "Cassé"}

XDG_STATE = Path(os.environ.get("XDG_STATE_HOME") or be.HOME / ".local/state")
REGLAGES = be.XDG_CONFIG / "vidange" / "bilan.json"
ETAT = XDG_STATE / "vidange" / "bilan.json"
MARQUEUR = Path("/var/lib/vidange/bilan-conseille.json")

DEFAUTS = {
    "lancer": True,
    "delai": 5,
    "applis": {},
    "dossiers_appimage": ["~/Applications", "~/AppImages", "~/Applis", "~/.local/bin"],
}


@dataclass
class Constat:
    niveau: int
    texte: str
    detail: str = ""


@dataclass
class Element:
    famille: str
    nom: str
    sous_titre: str = ""
    cle: str = ""
    constats: list = field(default_factory=list)

    @property
    def niveau(self):
        return max((c.niveau for c in self.constats), default=OK)

    def ajouter(self, niveau, texte, detail=""):
        self.constats.append(Constat(niveau, texte, detail))


def maintenant():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def lire_json(path, defaut):
    try:
        return json.loads(Path(path).read_text())
    except (OSError, ValueError):
        return defaut


def ecrire_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False))


def charger_reglages():
    reglages = json.loads(json.dumps(DEFAUTS))
    data = lire_json(REGLAGES, {})
    for cle, defaut in DEFAUTS.items():
        if isinstance(data.get(cle), type(defaut)):
            reglages[cle] = data[cle]
    return reglages


def enregistrer_reglages(reglages):
    ecrire_json(REGLAGES, reglages)


def copie(reglages):
    return json.loads(json.dumps(reglages))


def lignes(cmd, timeout=60):
    """Sortie d'une commande ligne par ligne, quel que soit son code de retour."""
    r = be.run(cmd, timeout=timeout)
    return r.stdout.splitlines() if r else []


def pluriel(n, mot, mots=None):
    return f"{n} {mot if n < 2 else (mots or mot + 's')}"
