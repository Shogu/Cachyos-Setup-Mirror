"""Bilan en ligne de commande : vidange --bilan."""

import argparse
import sys

from . import rapport
from .commun import A_CORRIGER, CASSE, charger_reglages


def main(argv):
    parser = argparse.ArgumentParser(
        prog="vidange --bilan",
        description="Bilan des applis maison, greffons Nautilus, extensions GNOME Shell et paquets Python. "
                    "Code de sortie : 0 sans problème, 1 à corriger, 2 cassé.")
    parser.add_argument("--sans-lancement", action="store_true", help="ne pas lancer les applis")
    parser.add_argument("--delai", type=int, metavar="S", help="durée du test de chaque appli, en secondes")
    args = parser.parse_args(argv)

    reglages = charger_reglages()
    if args.sans_lancement:
        reglages["lancer"] = False
    if args.delai:
        reglages["delai"] = max(1, args.delai)

    terminal = sys.stderr.isatty()

    def progression(texte, _fraction):
        if terminal:
            print(f"\r\033[K{texte}", end="", file=sys.stderr, flush=True)

    resultat = rapport.faire_bilan(reglages, progression)
    if terminal:
        print("\r\033[K", end="", file=sys.stderr, flush=True)
    print(rapport.texte(resultat), end="")
    return {CASSE: 2, A_CORRIGER: 1}.get(resultat.niveau, 0)
