"""Bilan : lancer une appli quelques secondes et relever ses messages."""

import os
import re
import shlex
import shutil
import signal
import subprocess
from pathlib import Path

from gi.repository import Gio, GLib

from .commun import A_CORRIGER, CASSE, INFO, Constat, pluriel

RE_CHAMP = re.compile(r"%[a-zA-Z%]")
RE_ADRESSE = re.compile(r"0x[0-9a-fA-F]+")
RE_PREFIXE = re.compile(r"^\(\S+:\d+\):\s*")
RE_BIBLIOTHEQUE = re.compile(r"error while loading shared libraries")
RE_ERREUR = re.compile(r"^\s*[\w.]*(Error|Exception)\b[^:]*:|JS ERROR|Segmentation fault|core dumped")
RE_DEPRECIE = re.compile(r"deprecat", re.I)
RE_AVERTISSEMENT = re.compile(r"-(WARNING|CRITICAL)\b|\bCRITICAL\b|Warning:")
RE_MINEUR = re.compile(r"ResourceWarning")
IGNORES = [re.compile(r"gi/events\.py:\d+: DeprecationWarning: 'asyncio\."), re.compile(r"SyntaxWarning")]
MAX_LIGNES = 15


def session_graphique():
    return bool(os.environ.get("WAYLAND_DISPLAY") or os.environ.get("DISPLAY"))


def fusermount():
    return shutil.which("fusermount3") or shutil.which("fusermount")


def cible_desktop(chemins):
    """(nom, commande, identifiant) de la première entrée .desktop lançable, ou None."""
    candidats = []
    for chemin in chemins:
        info = Gio.DesktopAppInfo.new_from_filename(chemin)
        if info is None or info.get_boolean("Terminal"):
            continue
        commande = shlex.split(RE_CHAMP.sub("", info.get_commandline() or ""))
        if commande:
            candidats.append((info.get_nodisplay(), info.get_display_name(), commande, Path(chemin).stem))
    if not candidats:
        return None
    _cachee, nom, commande, app_id = min(candidats, key=lambda c: c[0])
    return nom, commande, app_id


def deja_ouverte(app_id):
    try:
        bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
        r = bus.call_sync("org.freedesktop.DBus", "/org/freedesktop/DBus", "org.freedesktop.DBus", "NameHasOwner",
                          GLib.Variant("(s)", (app_id,)), GLib.VariantType("(b)"), Gio.DBusCallFlags.NONE, 2000, None)
    except GLib.Error:
        return False
    return r.unpack()[0]


def _arreter(proc):
    for sig in (signal.SIGTERM, signal.SIGKILL):
        try:
            os.killpg(proc.pid, sig)
        except ProcessLookupError:
            pass
        try:
            return proc.communicate(timeout=3)[0]
        except subprocess.TimeoutExpired:
            continue
    return ""


def _messages(sortie):
    vus, messages = set(), []
    for ligne in sortie.splitlines():
        ligne = RE_ADRESSE.sub("0x…", RE_PREFIXE.sub("", ligne.strip()))[:300]
        if ligne and ligne not in vus:
            vus.add(ligne)
            messages.append(ligne)
    return messages


def _classer(ligne, vivante):
    if RE_BIBLIOTHEQUE.search(ligne):
        return CASSE
    if RE_ERREUR.search(ligne):
        return A_CORRIGER if vivante else CASSE
    if RE_DEPRECIE.search(ligne) or RE_MINEUR.search(ligne):
        return INFO
    if RE_AVERTISSEMENT.search(ligne):
        return A_CORRIGER
    return None


def _interpreter(sortie, vivante, code):
    messages = _messages(sortie)
    constats = []
    if not vivante:
        if code < 0:
            constats.append(Constat(CASSE, f"Plante au lancement (signal {-code})", "\n".join(messages[-MAX_LIGNES:])))
        elif code:
            constats.append(Constat(CASSE, f"S'arrête au lancement (code {code})", "\n".join(messages[-MAX_LIGNES:])))
        else:
            constats.append(Constat(INFO, "S'est fermée aussitôt", "Déjà ouverte sous un autre nom, ou appli sans fenêtre."))
    par_niveau = {}
    for ligne in messages:
        if any(motif.search(ligne) for motif in IGNORES):
            continue
        niveau = _classer(ligne, vivante)
        if niveau is not None:
            par_niveau.setdefault(niveau, []).append(ligne)
    if not vivante and code:
        par_niveau.pop(CASSE, None)
    noms = {CASSE: ("erreur", None), A_CORRIGER: ("avertissement", None), INFO: ("remarque", None)}
    for niveau in sorted(par_niveau, reverse=True):
        trouvees = par_niveau[niveau]
        mot, mots = noms[niveau]
        constats.append(Constat(niveau, f"{pluriel(len(trouvees), mot, mots)} au lancement", "\n".join(trouvees[:MAX_LIGNES])))
    return constats


def tester(commande, delai, app_id=None):
    """Lance la commande `delai` secondes dans sa propre session de processus, puis l'arrête."""
    if app_id and deja_ouverte(app_id):
        return [Constat(INFO, "Déjà ouverte : fermez-la pour tester son lancement")]
    env = {**os.environ, "PYTHONWARNINGS": "default", "G_ENABLE_DIAGNOSTIC": "1", "LC_MESSAGES": "C"}
    try:
        proc = subprocess.Popen(commande, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, errors="replace", env=env, start_new_session=True)
    except OSError as exc:
        return [Constat(CASSE, "Impossible de lancer l'appli", str(exc))]
    try:
        sortie, vivante = proc.communicate(timeout=delai)[0], False
    except subprocess.TimeoutExpired:
        sortie, vivante = _arreter(proc), True
    return _interpreter(sortie, vivante, proc.returncode)


def appimages(dossiers):
    vues, trouvees = set(), []
    for dossier in dossiers:
        racine = Path(dossier).expanduser()
        if not racine.is_dir():
            continue
        for path in sorted(racine.iterdir()):
            if path.suffix.lower() == ".appimage" and path.is_file() and path.resolve() not in vues:
                vues.add(path.resolve())
                trouvees.append(path)
    return trouvees


def constats_appimage(path):
    constats = []
    if not os.access(path, os.X_OK):
        constats.append(Constat(A_CORRIGER, "Fichier non exécutable", f"chmod +x {path}"))
    if not fusermount():
        constats.append(Constat(CASSE, "fusermount3 introuvable", "Installer le paquet fuse3."))
    return constats
