# Perceptron

Coquille GTK4 / libadwaita autour de l'interface web d'**OpenCode 2.x**, avec de vrais onglets
Adwaita (une session OpenCode par onglet) et des notifications GNOME.

Version 0.4.0 — paquet `opencode-perceptron`, identifiant `io.gitlab.shogu.Perceptron`.

## Fonctionnement

- **Démarrage** : Perceptron lance `opencode service start` en arrière-plan, puis `opencode pair`,
  et ouvre le lien d'appairage dans le premier onglet. `opencode` est cherché dans le PATH puis dans
  `~/.opencode/bin`, `~/.local/bin`, `~/.bun/bin` et `~/.npm-global/bin` : l'installateur d'OpenCode
  n'ajoute son dossier qu'au PATH de fish, invisible pour une appli lancée depuis GNOME.
- **Onglets** : chaque onglet est une webview sur une route `#/server/{clé}/session/{id}`. Le titre
  vient de l'API du serveur (`/api/session/{id}`). Les onglets de session sont rouverts au lancement
  suivant.
- **Notifications** : Perceptron s'abonne lui-même au flux `GET /api/event` du serveur (libsoup,
  cookie de la session appairée). Une seule souscription, quel que soit le nombre d'onglets.

| Événement OpenCode 2.x | Notification |
|---|---|
| `permission.asked` / `permission.replied` | « Autorisation requise », retirée une fois la demande traitée |
| `form.created` / `form.replied` / `form.cancelled` | « Question d'OpenCode », retirée une fois répondue |
| `session.status` busy → idle | « Réponse terminée », sauf pour les sessions de sous-agents (`parentID`) |

Les notifications ne sortent que si la fenêtre n'est pas active, disparaissent quand on y revient,
et un clic ouvre l'onglet de la session concernée.

## Réglages conseillés dans OpenCode

| Réglage | Valeur |
|---|---|
| Disposition des sessions | **Inbox** (pas d'onglets natifs en plus des onglets Adwaita) |
| Notifications système : Agent, Permissions, Questions | **désactivées** (Perceptron s'en charge) |

## Raccourcis

Ctrl+T nouvelle session · Ctrl+W fermer l'onglet · Ctrl+Tab / Ctrl+Maj+Tab onglet suivant /
précédent · Alt+1…9 aller à un onglet · Ctrl+R recharger · Alt+Origine reconnecter ·
Ctrl+plus / moins / 0 zoom · F11 plein écran · Ctrl+? raccourcis · Ctrl+Q quitter.

## Diagnostic

`~/.local/share/opencode-perceptron/perceptron.log` est vidé à chaque lancement. On y lit le chemin
d'`opencode` utilisé, le résultat de `service start`, l'abonnement au flux (`flux : abonné à
/api/event`) et ses reconnexions.

## Construire le paquet

```fish
./build.sh          # sans makepkg ni base-devel : bash, bsdtar et zstd suffisent
sudo pacman -U opencode-perceptron-0.4.0-1-any.pkg.tar.zst
```

Le `PKGBUILD` récupère le tag `v0.4.0` du dépôt GitLab (`makepkg` classique, `git` requis).

## Arborescence

```
src/main.py       point d'entrée (nom de processus, prgname)
src/app.py        Adw.Application, actions globales, raccourcis
src/window.py     fenêtre, appairage, pile chargement / onglets / erreur
src/tabs.py       Adw.TabView + Adw.TabBar, une webview par session
src/server.py     flux /api/event et infos de session (libsoup)
src/notifier.py   notifications GNOME
src/opencode.py   lancement du service et appairage (Gio.Subprocess)
src/config.py     constantes, chemins, recherche d'opencode
src/state.py      taille de fenêtre, onglets ouverts, zoom
src/journal.py    journal de diagnostic
data/             lanceur, .desktop, icônes
```
