"""Onglets Adwaita : une webview par session d'OpenCode.

L'interface web route chaque session sur #/server/{clé}/session/{id}. Chaque
onglet suit sa route via la propriété `uri` de sa webview (mise à jour aussi
pour les changements de fragment) et prend le titre de la session auprès du
serveur. Les webviews partagent un même processus web et la même session réseau.
"""

from gi.repository import Adw, GObject, Gtk, WebKit

from config import HOME_URI, NEW_SESSION_URI, SESSION_ROUTE, is_local, session_uri

ROUTE_TITLES = (
    ("#/new-session", "Nouvelle session"),
    ("#/settings", "Réglages"),
)
HOME_TITLE = "Accueil"
SESSION_PLACEHOLDER = "Session"


def route_title(uri):
    for prefix, title in ROUTE_TITLES:
        if "/" + prefix in uri:
            return title
    return HOME_TITLE


class SessionTabs(GObject.Object):
    __gsignals__ = {
        "load-finished": (GObject.SignalFlags.RUN_FIRST, None, (object,)),
        "load-failed": (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        "title-changed": (GObject.SignalFlags.RUN_FIRST, None, (str,)),
    }

    def __init__(self, network_session, server):
        super().__init__()
        self._network_session = network_session
        self._server = server
        self._pages = {}
        self._sessions = {}
        self._server_key = None
        self._zoom = 1.0
        self._background = None

        self.view = Adw.TabView()
        self.bar = Adw.TabBar(view=self.view, autohide=True)
        self.view.connect("close-page", self._on_close_page)
        self.view.connect("notify::selected-page", self._on_selected)

    def open(self, uri, title=HOME_TITLE):
        web = self._new_webview()
        page = self._add(web, title)
        web.load_uri(uri)
        return page

    def new_session(self):
        self.open(NEW_SESSION_URI, route_title(NEW_SESSION_URI))

    def show_session(self, session_id):
        for web, current in self._sessions.items():
            if current == session_id:
                self.view.set_selected_page(self._pages[web])
                return
        if self._server_key:
            self.open(session_uri(self._server_key, session_id), SESSION_PLACEHOLDER)

    def close_selected(self):
        self.view.close_page(self.view.get_selected_page())

    @property
    def selected_web(self):
        page = self.view.get_selected_page()
        return page.get_child() if page else None

    def webviews(self):
        return [self.view.get_nth_page(index).get_child() for index in range(self.view.get_n_pages())]

    def local_uris(self):
        return [web.get_uri() for web in self.webviews() if web.get_uri() and is_local(web.get_uri())]

    def set_zoom(self, level):
        self._zoom = level
        for web in self.webviews():
            web.set_zoom_level(level)

    @property
    def zoom(self):
        return self._zoom

    def set_background(self, color):
        self._background = color
        for web in self.webviews():
            web.set_background_color(color)

    def selected_uri(self):
        web = self.selected_web
        return web.get_uri() if web else None

    def _new_webview(self, related=None):
        related = related or self.selected_web
        if related:
            web = WebKit.WebView(related_view=related, hexpand=True, vexpand=True)
        else:
            web = WebKit.WebView(network_session=self._network_session, hexpand=True, vexpand=True)
        web.set_zoom_level(self._zoom)
        if self._background:
            web.set_background_color(self._background)
        web.connect("notify::uri", self._on_uri)
        web.connect("load-changed", self._on_load_changed)
        web.connect("load-failed", self._on_load_failed)
        web.connect("decide-policy", self._on_decide_policy)
        web.connect("create", self._on_create)
        return web

    def _add(self, web, title):
        page = self.view.add_page(web, None)
        page.set_title(title)
        self._pages[web] = page
        self.view.set_selected_page(page)
        return page

    def _set_title(self, web, title):
        page = self._pages.get(web)
        if page is None:
            return
        page.set_title(title)
        if page == self.view.get_selected_page():
            self.emit("title-changed", title)

    def _on_uri(self, web, _pspec):
        if web not in self._pages:
            return
        uri = web.get_uri() or ""
        match = SESSION_ROUTE.search(uri)
        if not match:
            self._sessions.pop(web, None)
            self._set_title(web, route_title(uri))
            return
        self._server_key, session_id = match.groups()
        if self._sessions.get(web) == session_id:
            return
        self._sessions[web] = session_id
        self._set_title(web, SESSION_PLACEHOLDER)
        self._server.get_session(session_id, lambda info: self._on_session_info(web, session_id, info))

    def _on_session_info(self, web, session_id, info):
        if self._sessions.get(web) == session_id and info and info.get("title"):
            self._set_title(web, info["title"])

    def _on_load_changed(self, web, event):
        page = self._pages.get(web)
        if page is None:
            return
        page.set_loading(event != WebKit.LoadEvent.FINISHED)
        if event == WebKit.LoadEvent.FINISHED:
            self.emit("load-finished", web)

    def _on_load_failed(self, web, _event, _uri, error):
        page = self._pages.get(web)
        if page is None or error.matches(WebKit.NetworkError.quark(), WebKit.NetworkError.CANCELLED):
            return False
        page.set_loading(False)
        self.emit("load-failed", error.message)
        return True

    def _on_decide_policy(self, web, decision, decision_type):
        if decision_type not in (WebKit.PolicyDecisionType.NAVIGATION_ACTION, WebKit.PolicyDecisionType.NEW_WINDOW_ACTION):
            return False
        uri = decision.get_navigation_action().get_request().get_uri()
        if is_local(uri) or not uri.startswith(("http:", "https:", "mailto:")):
            return False
        decision.ignore()
        Gtk.UriLauncher.new(uri).launch(web.get_root())
        return True

    def _on_create(self, web, _action):
        new_web = self._new_webview(related=web)
        self._add(new_web, HOME_TITLE)
        return new_web

    def _on_close_page(self, view, page):
        web = page.get_child()
        self._pages.pop(web, None)
        self._sessions.pop(web, None)
        view.close_page_finish(page, True)
        if view.get_n_pages() == 0:
            self.open(HOME_URI)
        return True

    def _on_selected(self, view, _pspec):
        page = view.get_selected_page()
        if page:
            page.get_child().grab_focus()
            self.emit("title-changed", page.get_title())
