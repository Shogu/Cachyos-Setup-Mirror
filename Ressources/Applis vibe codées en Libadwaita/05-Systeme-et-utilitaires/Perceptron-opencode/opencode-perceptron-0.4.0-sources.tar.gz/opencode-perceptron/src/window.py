import os

from gi.repository import Adw, Gdk, Gio, Gtk, WebKit

import opencode
import state
from config import APP_ID, APP_NAME, BASE_URL, CACHE_DIR, SESSION_ROUTE, VERSION, WEBKIT_DATA_DIR, is_local
from notifier import Notifier
from server import Server
from tabs import SessionTabs

DARK_BACKGROUND = "#1d1d20"
LIGHT_BACKGROUND = "#ffffff"
ZOOM_STEP = 0.1
ZOOM_MIN = 0.3
ZOOM_MAX = 3.0

SHORTCUTS = (
    ("<Control>t", "Nouvelle session"),
    ("<Control>w", "Fermer l’onglet"),
    ("<Control>Tab", "Onglet suivant"),
    ("<Shift><Control>Tab", "Onglet précédent"),
    ("<Alt>1", "Aller à l’onglet 1 (à 9)"),
    ("<Control>r", "Recharger l’onglet"),
    ("<Alt>Home", "Reconnecter"),
    ("<Control>plus", "Zoom avant"),
    ("<Control>minus", "Zoom arrière"),
    ("<Control>0", "Zoom 100 %"),
    ("F11", "Plein écran"),
    ("<Control>question", "Raccourcis clavier"),
    ("<Control>q", "Quitter"),
)


def rgba(spec):
    color = Gdk.RGBA()
    color.parse(spec)
    return color


class MainWindow(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title=APP_NAME)
        self._connecting = False
        self._pairing = False

        saved = state.load()
        self.set_default_size(saved.get("width", 1180), saved.get("height", 820))
        if saved.get("maximized"):
            self.maximize()
        self._restore = (saved.get("tabs", []), saved.get("selected"))

        os.makedirs(WEBKIT_DATA_DIR, exist_ok=True)
        os.makedirs(CACHE_DIR, exist_ok=True)
        network_session = WebKit.NetworkSession.new(WEBKIT_DATA_DIR, CACHE_DIR)

        self.server = Server(network_session)
        self.notifier = Notifier(self, self.server)
        self.tabs = SessionTabs(network_session, self.server)
        self.tabs.set_zoom(saved.get("zoom", 1.0))
        self.tabs.connect("load-finished", self.on_load_finished)
        self.tabs.connect("load-failed", self.on_load_failed)
        self.tabs.connect("title-changed", lambda _tabs, title: self.window_title.set_subtitle(title))

        self.style_manager = Adw.StyleManager.get_default()
        self._dark_id = self.style_manager.connect("notify::dark", self.on_dark_changed)
        self.on_dark_changed(self.style_manager)

        self.set_content(self._build_content())
        self._add_actions()
        self.connect("notify::is-active", self.on_active_changed)
        self.connect("close-request", self.on_close_request)

        self.connect_and_load()

    def _build_content(self):
        self.status_page = Adw.StatusPage(icon_name="network-error-symbolic")
        retry = Gtk.Button(label="Réessayer", halign=Gtk.Align.CENTER, action_name="win.reconnect")
        retry.add_css_class("pill")
        retry.add_css_class("suggested-action")
        self.status_page.set_child(retry)

        spinner = Adw.Spinner(width_request=48, height_request=48, halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER)
        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE)
        self.stack.add_named(spinner, "loading")
        self.stack.add_named(self.tabs.view, "tabs")
        self.stack.add_named(self.status_page, "error")

        self.window_title = Adw.WindowTitle(title=APP_NAME)
        header = Adw.HeaderBar(title_widget=self.window_title)
        header.pack_start(Gtk.Button(
            icon_name="tab-new-symbolic", tooltip_text="Nouvelle session (Ctrl+T)", action_name="win.new-session",
        ))
        header.pack_end(Gtk.MenuButton(
            icon_name="open-menu-symbolic", tooltip_text="Menu principal", primary=True, menu_model=self._build_menu(),
        ))

        toolbar = Adw.ToolbarView(content=self.stack)
        toolbar.add_top_bar(header)
        toolbar.add_top_bar(self.tabs.bar)
        return toolbar

    def _build_menu(self):
        menu = Gio.Menu()
        tabs = Gio.Menu()
        tabs.append("Nouvelle session", "win.new-session")
        tabs.append("Recharger l’onglet", "win.reload")
        tabs.append("Reconnecter", "win.reconnect")
        menu.append_section(None, tabs)

        view = Gio.Menu()
        view.append("Zoom avant", "win.zoom-in")
        view.append("Zoom arrière", "win.zoom-out")
        view.append("Zoom 100 %", "win.zoom-reset")
        view.append("Plein écran", "win.fullscreen")
        menu.append_section(None, view)

        app = Gio.Menu()
        app.append("Ouvrir dans le navigateur", "win.open-browser")
        app.append("Raccourcis clavier", "win.shortcuts")
        app.append("À propos de Perceptron", "win.about")
        menu.append_section(None, app)
        return menu

    def _add_actions(self):
        for name, callback in (
            ("new-session", lambda *_: self.tabs.new_session()),
            ("close-tab", lambda *_: self.tabs.close_selected()),
            ("reload", lambda *_: self.tabs.selected_web.reload()),
            ("reconnect", lambda *_: self.connect_and_load()),
            ("zoom-in", lambda *_: self.zoom_by(ZOOM_STEP)),
            ("zoom-out", lambda *_: self.zoom_by(-ZOOM_STEP)),
            ("zoom-reset", lambda *_: self.tabs.set_zoom(1.0)),
            ("fullscreen", self.on_fullscreen),
            ("open-browser", lambda *_: Gtk.UriLauncher.new(BASE_URL).launch(self)),
            ("shortcuts", self.on_shortcuts),
            ("about", self.on_about),
        ):
            action = Gio.SimpleAction.new(name, None)
            action.connect("activate", callback)
            self.add_action(action)

    def on_dark_changed(self, style_manager, *_):
        self.tabs.set_background(rgba(DARK_BACKGROUND if style_manager.get_dark() else LIGHT_BACKGROUND))

    def connect_and_load(self):
        if self._connecting:
            return
        self._connecting = True
        self.stack.set_visible_child_name("loading")
        opencode.connect(self.on_connected)

    def on_connected(self, link):
        self._connecting = False
        if link is None:
            self.show_error(
                "OpenCode introuvable",
                "Ni le PATH de la session ni ~/.opencode/bin ne contiennent la commande « opencode ».",
            )
            return
        self._pairing = True
        uri = link or BASE_URL
        if self.tabs.selected_web:
            self.tabs.selected_web.load_uri(uri)
        else:
            self.tabs.open(uri)

    def on_load_finished(self, _tabs, web):
        if not self._pairing:
            return
        self._pairing = False
        self.stack.set_visible_child_name("tabs")
        self.server.start()
        for other in self.tabs.webviews():
            if other is not web:
                other.reload()
        if self._restore:
            self._restore_tabs(*self._restore)
            self._restore = None

    def _restore_tabs(self, uris, selected):
        selected_page = None
        for uri in uris:
            if is_local(uri) and SESSION_ROUTE.search(uri):
                page = self.tabs.open(uri)
                if uri == selected:
                    selected_page = page
        if selected_page:
            self.tabs.view.set_selected_page(selected_page)

    def on_load_failed(self, _tabs, message):
        self._pairing = False
        self.show_error("Service OpenCode injoignable", "Pas de réponse sur %s\n%s" % (BASE_URL, message))

    def show_error(self, title, description):
        self.status_page.set_title(title)
        self.status_page.set_description(description)
        self.stack.set_visible_child_name("error")

    def show_session(self, session_id):
        self.tabs.show_session(session_id)
        self.present()

    def on_active_changed(self, *_):
        if self.is_active():
            self.notifier.withdraw_all()

    def zoom_by(self, step):
        self.tabs.set_zoom(min(max(self.tabs.zoom + step, ZOOM_MIN), ZOOM_MAX))

    def on_fullscreen(self, *_):
        if self.is_fullscreen():
            self.unfullscreen()
        else:
            self.fullscreen()

    def on_about(self, *_):
        Adw.AboutDialog(
            application_name=APP_NAME,
            application_icon=APP_ID,
            version=VERSION,
            comments="Interface GTK4/libadwaita pour OpenCode",
            developer_name="ogu",
            website="https://gitlab.com/ogu/opencode-gtk",
            license_type=Gtk.License.MIT_X11,
        ).present(self)

    def on_shortcuts(self, *_):
        section = Adw.ShortcutsSection(title="Général")
        for accelerator, title in SHORTCUTS:
            section.add(Adw.ShortcutsItem(title=title, accelerator=accelerator))
        dialog = Adw.ShortcutsDialog()
        dialog.add(section)
        dialog.present(self)

    def on_close_request(self, *_):
        width, height = self.get_default_size()
        state.save({
            "width": width,
            "height": height,
            "maximized": self.is_maximized(),
            "tabs": self.tabs.local_uris(),
            "selected": self.tabs.selected_uri(),
            "zoom": self.tabs.zoom,
        })
        self.style_manager.disconnect(self._dark_id)
        self.notifier.destroy()
        self.server.destroy()
        return False
