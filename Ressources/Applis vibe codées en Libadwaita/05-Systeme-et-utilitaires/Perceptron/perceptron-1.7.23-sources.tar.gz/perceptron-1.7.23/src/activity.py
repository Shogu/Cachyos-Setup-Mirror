"""Spinner de la barre de titre : visible tant qu'OpenCode répond dans au moins une session.

Adw.Spinner est un type final (pas de sous-classe possible) : on le compose.
"""

from gi.repository import Adw

STARTED = "session.execution.started"
FINISHED = ("session.execution.succeeded", "session.execution.failed", "session.execution.interrupted")


class Activity:
    def __init__(self, server):
        self.spinner = Adw.Spinner(visible=False)
        self._running = set()
        server.connect("event", self._on_event)

    def _on_event(self, _server, kind, data):
        if kind == STARTED:
            self._running.add(data["sessionID"])
        elif kind in FINISHED:
            self._running.discard(data["sessionID"])
        else:
            return
        count = len(self._running)
        self.spinner.set_visible(count > 0)
        self.spinner.set_tooltip_text("OpenCode répond…" if count == 1 else "%d sessions en cours" % count)
