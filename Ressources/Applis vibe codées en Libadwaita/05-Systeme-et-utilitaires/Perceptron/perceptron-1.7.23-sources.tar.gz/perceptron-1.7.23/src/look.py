"""Habillage de l'UI web d'OpenCode : feuille de lisibilité modifiable, couleurs de GNOME (accent, barre de titre)."""

from gi.repository import Adw, Gio, WebKit

from config import OPENCODE_CSS

# Couleurs de la barre de titre Adwaita (libadwaita 1.6+).
HEADERBAR = {False: ("#ffffff", "rgba(0, 0, 6, 0.07)"), True: ("#2e2e32", "rgba(0, 0, 6, 0.36)")}

GNOME_CSS = """
html { accent-color: @ACCENT_BG@; }
::selection { background-color: color-mix(in srgb, @ACCENT_BG@ 35%, transparent); }
a { color: @ACCENT_FG@; }
input, textarea, [contenteditable="true"] { caret-color: @ACCENT_FG@; }
:focus-visible { outline-color: @ACCENT_BG@ !important; }

/* 8. Barre d'onglets et cadre d'OpenCode dans la couleur de la barre de titre
 * GNOME : un seul bandeau. Les onglets restent ceux d'OpenCode. */
:root, [data-color-scheme] { --v2-background-bg-deep: @HEADERBAR_BG@ !important; }
[data-slot="titlebar-v2"], [data-slot="titlebar-v2"] * { border-bottom-color: transparent !important; }
[data-slot="titlebar-v2"] { box-shadow: none !important; border-bottom: 0 !important; }

/* Onglets OpenCode natifs, micro-ajustement GNOME (sans toucher à la géométrie): */
[data-titlebar-tab]:not([data-orientation="vertical"]) { border-radius: 9px !important; }
[data-titlebar-tab]:not([data-orientation="vertical"]):is(:hover, [data-active="true"]) {
  --tab-overlay: color-mix(in srgb, currentColor 9%, transparent) !important;
}

/* Option C : Accueil/Loupe/Plus un peu plus lisibles (+2 px d'icône). */
[data-slot="titlebar-v2"] [data-component="icon-button-v2"] [data-slot="icon-svg"] {
  width: 20px !important;
  height: 20px !important;
}

/* 12. Le modèle (2e info sous chaque réponse, après l'agent) teinté d'accent. */
[data-slot="text-part-meta-item"]:first-child + [data-slot="text-part-meta-separator"] + [data-slot="text-part-meta-item"] {
  background: color-mix(in srgb, @ACCENT_BG@ 24%, transparent) !important;
}

/* 1. Tes messages : bulles teintées à la couleur d'accent. */
[data-slot="user-message-text"] {
  background: color-mix(in srgb, @ACCENT_BG@ 22%, transparent) !important;
}

/* 2. Zone de saisie en carte Adwaita, contour d'accent quand on y tape. */
[data-component="composer"] {
  border-radius: 14px !important;
  box-shadow: 0 0 0 1px color-mix(in srgb, currentColor 10%, transparent) !important;
  transition: box-shadow 150ms ease;
}
[data-component="composer"]:focus-within {
  box-shadow: 0 0 0 2px @ACCENT_BG@ !important;
}

/* 6. Citations : trait d'accent et fond très léger. */
[data-component="markdown"] blockquote {
  border-inline-start: 3px solid @ACCENT_BG@ !important;
  background: color-mix(in srgb, @ACCENT_BG@ 8%, transparent);
  border-radius: 0 8px 8px 0;
  padding: 6px 12px !important;
  color: inherit !important;
}

/* Bouton Envoyer : action principale, en couleur d'accent comme un « suggested-action » GNOME.
 * OpenCode le peint avec un dégradé (background-image) qui recouvrirait la couleur, et lui ajoute un
 * relief (box-shadow) et une ombre sur la flèche : un bouton Adwaita est plat, on retire les trois. */
[data-action="composer-submit"]:not(:disabled):not([aria-disabled="true"]) {
  background-image: none !important;
  box-shadow: none !important;
  text-shadow: none !important;
  background-color: @ACCENT_BG@ !important;
  color: #ffffff !important;
}
[data-action="composer-submit"]:not(:disabled):not([aria-disabled="true"]) svg {
  color: #ffffff !important;
}
[data-action="composer-submit"]:not(:disabled):not([aria-disabled="true"]):hover {
  background-color: color-mix(in srgb, @ACCENT_BG@ 88%, white) !important;
}
[data-action="composer-submit"]:not(:disabled):not([aria-disabled="true"]):active {
  background-color: color-mix(in srgb, @ACCENT_BG@ 85%, black) !important;
}

/* Pastilles de projets sans couleur choisie (gris par défaut) : couleur
 * d'accent et initiale blanche, comme les avatars Adwaita. Une couleur
 * choisie dans les réglages du projet dans OpenCode reste prioritaire. */
[data-slot="project-avatar-surface"][data-variant="gray"]:not([data-has-image]) {
  --project-avatar-bg: @ACCENT_BG@ !important;
  --project-avatar-border: transparent !important;
  color: #ffffff !important;
}
[data-slot="project-avatar-surface"][data-variant="gray"] [data-slot="project-avatar-initial"] {
  color: #ffffff !important;
}
"""


class GnomeLook:
    def __init__(self, content_manager):
        self._manager = content_manager
        self._style = Adw.StyleManager.get_default()
        self._style.connect("notify::accent-color", self._apply)
        self._style.connect("notify::dark", self._apply)
        # Retoucher opencode.css s'applique sans relancer Perceptron.
        self._monitor = Gio.File.new_for_path(OPENCODE_CSS).monitor_file(Gio.FileMonitorFlags.NONE, None)
        self._monitor.connect("changed", self._on_css_changed)
        self._apply()

    def _on_css_changed(self, _monitor, _file, _other, event):
        if event == Gio.FileMonitorEvent.CHANGES_DONE_HINT:
            self._apply()

    def _apply(self, *_):
        dark = self._style.get_dark()
        accent = self._style.get_accent_color()
        headerbar_bg, headerbar_border = HEADERBAR[dark]
        source = self._readability() + (GNOME_CSS
            .replace("@ACCENT_BG@", Adw.AccentColor.to_rgba(accent).to_string())
            .replace("@ACCENT_FG@", Adw.AccentColor.to_standalone_rgba(accent, dark).to_string())
            .replace("@HEADERBAR_BG@", headerbar_bg)
            .replace("@HEADERBAR_BORDER@", headerbar_border))
        self._manager.remove_all_style_sheets()
        self._manager.add_style_sheet(WebKit.UserStyleSheet.new(
            source, WebKit.UserContentInjectedFrames.ALL_FRAMES, WebKit.UserStyleLevel.USER, None, None,
        ))

    @staticmethod
    def _readability():
        try:
            with open(OPENCODE_CSS, encoding="utf-8") as handle:
                return handle.read()
        except OSError:
            return ""
