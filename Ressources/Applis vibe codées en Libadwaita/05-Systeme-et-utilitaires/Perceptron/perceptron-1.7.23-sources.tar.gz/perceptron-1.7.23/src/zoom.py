"""Zoom de la page : facteur de taille du texte de GNOME × zoom choisi dans Perceptron."""

from gi.repository import Gio

STEP = 0.1
MINIMUM = 0.5
MAXIMUM = 2.0


class Zoom:
    def __init__(self, webview, user_level, on_changed):
        self._webview = webview
        self._user = min(max(user_level, MINIMUM), MAXIMUM)
        self._on_changed = on_changed
        self._interface = Gio.Settings.new("org.gnome.desktop.interface")
        self._interface.connect("changed::text-scaling-factor", lambda *_: self._apply())
        self._apply()

    @property
    def user_level(self):
        return self._user

    def step(self, direction):
        self.set(self._user + direction * STEP)

    def set(self, level):
        self._user = round(min(max(level, MINIMUM), MAXIMUM), 2)
        self._apply()
        self._on_changed(self._user)

    def _apply(self):
        self._webview.set_zoom_level(self._interface.get_double("text-scaling-factor") * self._user)
