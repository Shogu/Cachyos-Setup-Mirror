# Perceptron — README de test

Liste des évolutions implémentées depuis **09:30** (6 novembre 2026) et comment
les vérifier manuellement. Lancer l’application avec `perceptron` (ou
`python3 src/main.py` depuis le dépôt).

## 1. Thèmes fixes des cartouches
- Réponses **OpenCode** : cartouche clair, texte sombre.
- Messages **Moi** : cartouche sombre, texte clair.
- Indépendant du thème clair/sombre du système.
- Vert du markdown corrigé en hexadécimal plus clair (`#2ec27e`) : fini le
  vert sombre peu lisible.
- **Test** : passer le système en clair puis en sombre, ouvrir une session ;
  les couleurs des cartouches ne changent pas.

## 2. Zone de saisie redimensionnable
- **Placeholder « Écris ton message… »** visible tant que la zone est vide.
- Poignée au-dessus du compositeur rendue **visible** (barre + grip centré,
  curseur `row-resize`, infobulle) ; la hauteur est mémorisée entre deux
  lancements (bornée à 420 px).
- Le message envoyé est bien **effacé** après envoi (comparaison tolérante aux
  espaces de bord, y compris après insertion d’un tableau).
- **Test** : tirer la poignée, fermer, relancer : la hauteur est conservée ;
  saisir puis envoyer : la zone se vide.

## 3. Historique repliable et progressif
- Les 40 messages les plus récents restent visibles.
- Boutons « Générations précédentes » (+25) et « Tout afficher ».
- **Test** : ouvrir une longue session (> 40 messages), déplier par paliers.

## 4. Bouton « Modèle » unique
- Un seul bouton regroupe modèle, variante de raisonnement et agent.
- **Test** : ouvrir le bouton, changer de modèle puis d’agent, envoyer un
  message : le choix est bien appliqué à la session.

## 5. Badge d’onglet natif
- Quand une session en arrière-plan termine, son onglet reçoit le point
  d’attention Adwaita, plus un bandeau « Voir ».
- **Test** : lancer une génération, changer d’onglet ; à la fin, le point
  apparaît et le bandeau propose d’ouvrir la session.

## 5bis. Réinitialiser la conversation à un message
- Sur chaque **message « Moi »** (sauf le dernier) : bouton `edit-undo-symbolic`
  « Réinitialiser la conversation ici ».
- Le clic ouvre une confirmation destructrice, puis ramène la conversation à ce
  point via l’API de revert native d’OpenCode (supprime les messages suivants).
- **Test** : ouvrir une session avec plusieurs messages, cliquer le bouton de
  retour d’un ancien message « Moi », confirmer : les messages suivants
  disparaissent et la session est rechargée.

## 6. Statut de génération dans le compositeur
- « Génération en cours » (spinner) et bouton **Arrêter** déplacés dans la
  barre du compositeur.
- **Test** : envoyer un prompt long ; le spinner et le bouton Arrêter
  apparaissent au-dessus de la saisie et disparaissent à la fin.

## 7. Aperçu des messages dans la barre de droite
- Les repères de réponse affichent **numéro + aperçu** (ex. « 3 · Explique
  comment… »), avec le texte complet en infobulle.
- La **barre de défilement intrusive est retirée** (défilement en surimpression) :
  les trois points et la zone cliquable ne sont plus gênés.
- **Test** : survoler un repère, cliquer : la conversation défile vers la
  réponse correspondante.

## 8. Copier fiable
- Copie via `wl-copy` sous Wayland (repli GTK/X11), avec retour visuel.
- **Test** : bouton « Copier la réponse » d’une carte, bouton de copie d’un
  bloc de code, menu contextuel « Copier » ; coller dans un autre logiciel.
  L’infobulle du bloc de code affiche « Copié ! ».

## 9. Recherche Ctrl+F dans la conversation
- `Ctrl+F` ouvre la barre de recherche.
- `Entrée` ou `Ctrl+G` passe au résultat suivant.
- **Les mots trouvés sont surlignés en jaune** dans le texte, et la réponse
  contenant le résultat actuel est cerclée de bleu ; le compteur
  « résultat/ total » s’affiche (ex. « 3/5 »). Échap referme et efface le
  surlignage.
- L’historique ancien est déplié automatiquement si le résultat est masqué.
- **Test** : `Ctrl+F`, saisir un mot présent dans plusieurs réponses : le mot
  apparaît surligné en jaune, puis enchaîner avec Entrée.

## 10. Aération des cartouches
- Marges internes augmentées pour les dates et les actions.
- Blocs de code : padding interne (haut/bas/gauche/droite).
- Tableaux : cellules plus spacieuses, marges externes.
- **Auteur détaillé** : les réponses affichent « OpenCode — modèle — fournisseur »
  (ex. « OpenCode — DeepSeek V4 Flash — Albert ») ; vos messages affichent
  « Moi ».
- **Bouton copier présent** dans les réponses **et** dans vos propres messages.
- **Test** : afficher une réponse avec code + tableau : rien ne colle aux
  bords ; vérifier l’auteur et le bouton copier sur un de vos messages.

## 11. Renommer une session
- Menu « … » d’une session → **Renommer la session…**.
- Met à jour le titre côté OpenCode, la liste et l’onglet ouvert.
- **Test** : renommer une session, vérifier la liste et l’onglet.

## 12. Barre latérale redimensionnable
- Poignée **visible** (séparateur drapable entre la liste des sessions et la
  conversation, surbrillance au survol) ; la largeur est mémorisée entre deux
  lancements.
- Le bouton de la barre d’en-tête masque/affiche la liste des sessions.
- **Test** : tirer la poignée, relancer l’application : la largeur est
  conservée.

## 13. Sous-agents
- Masqués par défaut ; filtre « Afficher les sous-agents » dans la barre
  latérale.
- **Test** : activer/désactiver le filtre, la liste se met à jour.

## 14. Palette de couleurs unique + tableau
- Un seul bouton « A » ouvre la palette : rouge, orange, jaune, vert, bleu,
  violet, **rose** (couleurs en hexadécimal dans le markdown et le rendu).
- Bouton « Insérer un tableau simple ».
- **Test** : sélectionner du texte, appliquer une couleur ; insérer un tableau
  puis envoyer le message : la zone de saisie se vide après l’envoi.

## 15. Curseur stable dans la TUI OpenCode
- `~/.config/opencode/cli.json` : `cursor.style = "line"`,
  `cursor.blinking = false` (barre fine, non clignotante).
- **Test** : lancer `opencode` dans le terminal : le curseur de saisie est une
  barre fine et stable.

## 16. Mémoire (instructions globales)
- Menu principal → **Mémoire (instructions globales)…**.
- Édite `systemPrompt` dans `~/.config/opencode/opencode.json`, avec sauvegarde
  horodatée automatique avant écriture.
- **Test** : ouvrir, modifier, enregistrer ; vérifier le fichier et sa
  sauvegarde `.bak-memoire-*`, puis redémarrer OpenCode.

## 17. Menu « Ajouter » avec dossiers par défaut
- Trombone → **Image…**, **Archive / paquet…**, **Tous les fichiers…**.
- Dossiers de départ : `~/Images`, `~/Téléchargements`, `~`.
- **Modifiables dans les Préférences** : groupe « Dossiers du menu Ajouter »
  avec un sélecteur de répertoire (pickeur) pour chaque catégorie ; le choix
  est enregistré dans l’état et appliqué aux ouvertures suivantes.
- Filtres MIME/ motifs adaptés à chaque catégorie.
- **Test** : Préférences → choisir un dossier pour « Images », puis trombone →
  Image… : le sélecteur s’ouvre sur ce dossier.

## 18. Correctifs de lancement
- `set_width_request`/`set_height_request` remplacés par `set_size_request`
  (cause de l’écran vide).
- Boutons de repli d’historique mémorisés (plus d’`AttributeError`).
- **Test** : lancer l’application, l’interface s’affiche immédiatement.

---

### Vérification rapide en ligne de commande

```bash
cd ~/Projets/perceptron-adwaita/src
python3 -m py_compile *.py
timeout 7 python3 main.py    # 124 = toujours vivant, aucune trace = OK
```
