import os
import tempfile
import unittest
from types import SimpleNamespace

from server import Server, _payload, basic_auth_header, http_error_message, prompt_payload
import markdown as markdown_module
import window as window_module
from window import MainWindow


class ServerTests(unittest.TestCase):
    def setUp(self):
        self.tempdir = tempfile.TemporaryDirectory()
        self.server = Server(
            os.path.join(self.tempdir.name, "cookies.txt"),
            os.path.join(self.tempdir.name, "server-password"),
        )

    def tearDown(self):
        self.server.destroy()
        self.tempdir.cleanup()

    def test_session_events_update_and_remove_native_session_cache(self):
        self.server._update_sessions(
            "session.created",
            {"sessionID": "session-1", "title": "Test"},
        )
        self.assertEqual(self.server._sessions["session-1"]["title"], "Test")

        self.server._update_sessions(
            "session.renamed",
            {"sessionID": "session-1", "title": "Renamed"},
        )
        self.assertEqual(self.server._sessions["session-1"]["title"], "Renamed")

        self.server._update_sessions(
            "session.deleted",
            {"sessionID": "session-1"},
        )
        self.assertNotIn("session-1", self.server._sessions)

    def test_api_data_envelope_is_unwrapped(self):
        self.assertEqual(_payload({"data": [{"id": "session-1"}]}), [{"id": "session-1"}])
        self.assertEqual(_payload({"id": "session-1"}), {"id": "session-1"})

    def test_request_json_delivers_success_response_with_configured_envelope(self):
        class FakeMessage:
            def __init__(self):
                self.status = 200
            def get_status(self):
                return self.status
            def get_uri(self):
                return SimpleNamespace(to_string=lambda: "http://localhost/test")

        class FakeResponse:
            def get_data(self):
                return b'{"data":{"ok":true}}'

        class FakeSoup:
            def send_and_read_async(self, message, _priority, _cancellable, callback, request):
                self.pending = (callback, request)
            def send_and_read_finish(self, _result):
                return FakeResponse()
            def abort(self):
                pass

        soup = FakeSoup()
        self.server._soup = soup
        self.server._message = lambda *_args: FakeMessage()
        received = []
        self.server._request_json(
            "GET", "/test", None, lambda value, error: received.append((value, error))
        )
        callback, request = soup.pending
        self.server._on_json_response(soup, object(), request)
        self.assertEqual(received, [({"ok": True}, None)])

        received.clear()
        self.server._request_json(
            "GET", "/test", None,
            lambda value, error: received.append((value, error)),
            unwrap_data=False,
        )
        callback, request = soup.pending
        self.server._on_json_response(soup, object(), request)
        self.assertEqual(received, [({"data": {"ok": True}}, None)])

    def test_session_resource_paths_match_opencode_api_routes(self):
        self.assertEqual(
            self.server.session_path("ses/example", "message"),
            "/api/session/ses%2Fexample/message",
        )
        self.assertEqual(
            self.server.session_path("ses_example", "prompt"),
            "/api/session/ses_example/prompt",
        )
        self.assertEqual(
            self.server.session_path("ses_example", "revert/stage"),
            "/api/session/ses_example/revert/stage",
        )
        self.assertEqual(
            self.server.session_path("ses_example", "interrupt"),
            "/api/session/ses_example/interrupt",
        )

    def test_api_prompt_body_uses_v2_text_field(self):
        self.assertEqual(prompt_payload("Question"), {"text": "Question"})

    def test_api_prompt_supports_queued_delivery_and_local_file_attachments(self):
        files = [{"uri": "file:///tmp/image.png", "name": "image.png"}]
        self.assertEqual(
            prompt_payload("Question", "queue", files),
            {"text": "Question", "delivery": "queue", "files": files},
        )
        self.assertEqual(prompt_payload("Question", "invalid"), {"text": "Question"})

    def test_api_prompt_keeps_default_delivery_compatible(self):
        self.assertEqual(prompt_payload("Question"), {"text": "Question"})

    def test_api_session_updates_and_agent_actions_use_v2_routes(self):
        requests = []
        self.server._request_json = lambda method, path, body, callback, **kwargs: (
            requests.append((method, path, body)),
            callback(None, None),
        )
        self.server.update_session("ses/one", {"archived": True}, lambda *_: None)
        self.server.switch_agent("ses/one", "build", lambda *_: None)
        self.server.interrupt_session("ses/one", lambda *_: None)
        self.server.stage_revert("ses/one", "msg_one", lambda *_: None)
        self.server.commit_revert("ses/one", lambda *_: None)
        self.assertEqual(
            requests,
            [
                ("PATCH", "/api/session/ses%2Fone", {"archived": True}),
                ("POST", "/api/session/ses%2Fone/agent", {"agent": "build"}),
                ("POST", "/api/session/ses%2Fone/interrupt", {}),
                ("POST", "/api/session/ses%2Fone/revert/stage", {"messageID": "msg_one"}),
                ("POST", "/api/session/ses%2Fone/revert/commit", {}),
            ],
        )

    def test_api_provider_catalog_uses_verified_v2_route(self):
        requests = []
        self.server._request_json = lambda method, path, body, callback, **kwargs: (
            requests.append((method, path, body)),
            callback([{"id": "google", "name": "Google Gemini"}], None),
        )
        result = []
        self.server.list_providers(lambda providers, error: result.extend(providers))
        self.assertEqual(requests, [("GET", "/api/provider", None)])
        self.assertEqual(result, [{"id": "google", "name": "Google Gemini"}])

    def test_api_config_uses_verified_v2_route(self):
        requests = []
        self.server._request_json = lambda method, path, body, callback, **kwargs: (
            requests.append((method, path, body)),
            callback([{"type": "document", "info": {"providers": {}}}], None),
        )
        result = []
        self.server.get_config(lambda config, error: result.extend(config))
        self.assertEqual(requests, [("GET", "/api/config", None)])
        self.assertEqual(result[0]["type"], "document")

    def test_get_session_callback_receives_stale_session_error_and_evicts_cache(self):
        self.server._sessions["stale"] = {"id": "stale", "title": "Old"}
        received = []
        self.server._on_session_loaded(
            "stale",
            None,
            "Réponse HTTP 404: Session not found: stale",
        )
        self.assertNotIn("stale", self.server._sessions)

        self.server._sessions["cached"] = {"id": "cached"}
        self.server.get_session(
            "cached",
            lambda info, error: received.append((info, error)),
        )
        self.assertEqual(received, [({"id": "cached"}, None)])

    def test_force_refresh_does_not_reuse_cached_session_after_server_switch(self):
        requests = []
        self.server._sessions["same-id"] = {"id": "same-id", "title": "Old server"}

        def fake_request(method, path, body, callback, **_kwargs):
            requests.append((method, path))
            callback({"id": "same-id", "title": "Current server"}, None)

        self.server._request_json = fake_request
        received = []
        self.server.get_session(
            "same-id",
            lambda info, error: received.append((info, error)),
            force_refresh=True,
        )
        self.assertEqual(requests, [("GET", "/api/session/same-id")])
        self.assertEqual(
            received,
            [({"id": "same-id", "title": "Current server"}, None)],
        )
        self.assertEqual(
            self.server._sessions["same-id"]["title"], "Current server"
        )

    def test_get_session_passes_http_404_to_all_waiting_callers(self):
        callbacks = []
        self.server._waiting["missing"] = [
            lambda info, error: callbacks.append((info, error)),
            lambda info, error: callbacks.append((info, error)),
        ]
        self.server._sessions["missing"] = {"id": "missing"}
        self.server._on_session_loaded(
            "missing", None, "Réponse HTTP 404: Session not found: missing"
        )
        self.assertEqual(
            callbacks,
            [
                (None, "Réponse HTTP 404: Session not found: missing"),
                (None, "Réponse HTTP 404: Session not found: missing"),
            ],
        )
        self.assertNotIn("missing", self.server._sessions)
        self.assertNotIn("missing", self.server._waiting)

    def test_session_listing_follows_opaque_cursors_and_archived_filter(self):
        requests = []
        pages = {
            "/api/session?archived=false": {
                "data": [{"id": "one"}],
                "cursor": {"next": "opaque+/cursor"},
            },
            "/api/session?archived=false&cursor=opaque%2B%2Fcursor": {
                "data": [{"id": "two"}],
                "cursor": {"next": None},
            },
        }

        def fake_request(method, path, body, callback, unwrap_data=True):
            requests.append(path)
            callback(pages[path], None)

        self.server._request_json = fake_request
        result = []
        self.server.list_sessions(lambda sessions, error: result.extend(sessions), archived=False)
        self.assertEqual(result, [{"id": "one"}, {"id": "two"}])
        self.assertEqual(list(pages), requests)

    def test_message_listing_follows_opaque_cursors(self):
        requests = []
        pages = {
            "/api/session/s1/message?limit=100": {
                "data": [{"id": "m2"}],
                "cursor": {"next": "opaque+/next"},
            },
            "/api/session/s1/message?limit=100&cursor=opaque%2B%2Fnext": {
                "data": [{"id": "m1"}],
                "cursor": {"next": None},
            },
        }

        def fake_request(method, path, body, callback, unwrap_data=True):
            requests.append((method, path, unwrap_data))
            callback(pages[path], None)

        self.server._request_json = fake_request
        result = []
        self.server.get_messages("s1", lambda messages, error: result.extend(messages))
        self.assertEqual(result, [{"id": "m2"}, {"id": "m1"}])
        self.assertEqual(
            requests,
            [
                ("GET", "/api/session/s1/message?limit=100", False),
                (
                    "GET",
                    "/api/session/s1/message?limit=100&cursor=opaque%2B%2Fnext",
                    False,
                ),
            ],
        )

    def test_http_error_includes_safe_open_code_message(self):
        message = http_error_message(
            400,
            b'{"_tag":"InvalidRequestError","message":"text field is required","field":"text"}',
        )
        self.assertEqual(message, "Réponse HTTP 400: text field is required (champ : text)")

    def test_http_error_includes_kind_and_redacts_values(self):
        message = http_error_message(
            400,
            b'{"_tag":"InvalidRequestError","message":"Expected string\\n  at [\\"text\\"]","kind":"Payload"}',
        )
        self.assertEqual(
            message,
            'Réponse HTTP 400: Expected string at ["text"] (type : Payload)',
        )

    def test_http_error_redacts_secrets_in_kind_and_message(self):
        message = http_error_message(
            400,
            b'{"_tag":"InvalidRequestError","message":"Invalid token=hidden","kind":"provider"}',
        )
        self.assertNotIn("hidden", message)
        self.assertIn("token=[masqué]", message)

    def test_http_error_handles_malformed_error_properties(self):
        message = http_error_message(400, b'{"message":[],"kind":{},"field":12}')
        self.assertEqual(message, "Réponse HTTP 400")

    def test_http_error_redacts_credentials_and_limits_unstructured_body(self):
        message = http_error_message(
            400,
            b'{"message":"Bad Basic abcdef and password: hunter2"}',
        )
        self.assertNotIn("abcdef", message)
        self.assertNotIn("hunter2", message)
        self.assertIn("[identifiant masqué]", message)
        self.assertIn("password=[masqué]", message)
        self.assertLessEqual(len(http_error_message(400, b"x" * 1000)), 430)

    def test_server_basic_auth_header_uses_configured_username_and_password(self):
        self.assertEqual(basic_auth_header("alice", "secret"), "Basic YWxpY2U6c2VjcmV0")
        self.assertIsNone(basic_auth_header("alice", ""))

    def test_persisted_cookie_file_is_private(self):
        cookie_path = os.path.join(self.tempdir.name, "cookies.txt")
        self.assertEqual(os.stat(cookie_path).st_mode & 0o777, 0o600)

    def test_generated_server_password_is_private_and_reused(self):
        password_path = os.path.join(self.tempdir.name, "server-password")
        self.assertTrue(self.server.password)
        self.assertEqual(os.stat(password_path).st_mode & 0o777, 0o600)
        self.server.destroy()
        second = Server(
            os.path.join(self.tempdir.name, "other-cookies.txt"),
            password_path,
        )
        try:
            self.assertEqual(second.password, self.server.password)
        finally:
            second.destroy()


class NativeConversationTests(unittest.TestCase):
    def test_legacy_message_parts_are_still_rendered(self):
        rendered = MainWindow._message_text({"parts": [
            {"type": "text", "text": "Bonjour"},
            {"type": "tool", "tool": "read", "state": {"title": "src/main.py"}},
        ]})
        self.assertEqual(rendered, "Bonjour\n\nOutil : src/main.py")

    def test_opencode_v2_user_and_assistant_message_shapes_are_rendered(self):
        user = {"type": "user", "text": "Salut"}
        assistant = {
            "type": "assistant",
            "content": [
                {"type": "reasoning", "text": "private reasoning"},
                {"type": "text", "text": "Bonjour"},
                {
                    "type": "tool",
                    "name": "read",
                    "state": {
                        "status": "completed",
                        "metadata": {"title": "src/main.py"},
                    },
                },
            ],
        }
        self.assertEqual(MainWindow._message_text(user), "Salut")
        rendered = MainWindow._message_text(assistant)
        self.assertEqual(rendered, "Bonjour\n\nOutil : src/main.py")
        self.assertNotIn("private reasoning", rendered)

    def test_non_text_parts_are_not_rendered_as_empty_messages(self):
        self.assertEqual(MainWindow._message_text({"content": [{"type": "reasoning"}]}), "")

    def test_session_identity_deduplication_preserves_distinct_and_child_sessions(self):
        sessions = [
            {"id": "parent", "title": "Same title"},
            {"id": "parent", "title": "Duplicate API record"},
            {"id": "child", "title": "Same title", "parentID": "parent"},
            {"id": "other", "title": "Same title"},
        ]
        indexed = MainWindow._index_sessions(sessions)
        self.assertEqual(set(indexed), {"parent", "child", "other"})
        self.assertEqual(indexed["parent"]["title"], "Same title")
        self.assertEqual(
            MainWindow._session_subtitle(indexed["child"], indexed),
            "Sous-agent de « Same title »",
        )

    def test_session_list_filters_subagents_without_title_based_deduplication(self):
        sessions = MainWindow._index_sessions([
            {"id": "parent", "title": "Same"},
            {"id": "child", "title": "Same", "parentID": "parent"},
            {"id": "other", "title": "Same"},
        ])
        self.assertEqual(
            {key for key, value in sessions.items() if not value.get("parentID")},
            {"parent", "other"},
        )

    def test_opencode_millisecond_timestamps_render_as_local_dates(self):
        timestamp_ms = 1793898450421
        timestamp_s = timestamp_ms // 1000
        self.assertEqual(
            MainWindow._format_timestamp(timestamp_ms, "%Y-%m-%d"),
            MainWindow._format_timestamp(timestamp_s, "%Y-%m-%d"),
        )
        self.assertEqual(
            MainWindow._message_created(
                {"time": {"created": timestamp_ms}}
            ),
            MainWindow._format_timestamp(timestamp_s, "%H:%M"),
        )
        self.assertEqual(MainWindow._format_timestamp(10**20, "%x"), "")
        self.assertEqual(MainWindow._format_timestamp(True, "%x"), "")

    def test_sidebar_session_date_uses_french_weekday_and_month(self):
        import datetime

        timestamp = datetime.datetime(2026, 11, 5, 12).timestamp()
        self.assertEqual(
            MainWindow._format_session_date(timestamp),
            "jeudi 5 nov.",
        )
        self.assertEqual(
            MainWindow._format_session_date(timestamp * 1000),
            "jeudi 5 nov.",
        )
        self.assertEqual(MainWindow._format_session_date(True), "")

    def test_provider_model_groups_are_sorted_by_api_provider_and_model_names(self):
        models = [
            {"id": "z", "providerID": "groq", "name": "Zeta"},
            {"id": "b", "providerID": "opencode", "name": "Beta"},
            {"id": "a", "providerID": "groq", "name": "Alpha"},
            {"id": "g", "providerID": "google", "name": "Gemini"},
        ]
        providers = {
            "groq": "Groq",
            "opencode": "OpenCode",
            "google": "Google Gemini",
        }
        groups = MainWindow._group_models_by_provider(models, providers)
        self.assertEqual(
            [(provider_id, label) for provider_id, label, _ in groups],
            [
                ("google", "Google Gemini"),
                ("groq", "Groq"),
                ("opencode", "OpenCode"),
            ],
        )
        self.assertEqual(
            [[model["id"] for model in group] for _, _, group in groups],
            [["g"], ["a", "z"], ["b"]],
        )
        self.assertEqual(
            {model["id"] for _, _, group in groups for model in group},
            {model["id"] for model in models},
        )

    def test_model_catalog_respects_configured_provider_models_and_disabled_flags(self):
        config_files = [{
            "type": "document",
            "info": {
                "providers": {
                    "albert": {
                        "models": {"allowed-albert": {}},
                        "settings": {"apiKey": "must-not-be-retained"},
                    },
                    "google": {"models": {"allowed-google": {}}},
                },
            },
        }]
        configured = MainWindow._configured_model_ids(config_files)
        self.assertEqual(
            configured,
            {"albert": {"allowed-albert"}, "google": {"allowed-google"}},
        )
        models = [
            {"id": "allowed-albert", "providerID": "albert", "enabled": True},
            {"id": "hidden-albert", "providerID": "albert", "enabled": True},
            {"id": "allowed-google", "providerID": "google", "enabled": True},
            {"id": "disabled-google", "providerID": "google", "enabled": False},
            {"id": "builtin-opencode", "providerID": "opencode", "enabled": True},
            {"id": "disabled-provider", "providerID": "groq", "enabled": True},
        ]
        visible = MainWindow._filter_available_models(
            models, configured, {"albert", "google", "opencode"}
        )
        self.assertEqual(
            [(model["providerID"], model["id"]) for model in visible],
            [
                ("albert", "allowed-albert"),
                ("google", "allowed-google"),
                ("opencode", "builtin-opencode"),
            ],
        )

    def test_config_parser_accepts_direct_config_and_keeps_secret_fields_out(self):
        configured = MainWindow._configured_model_ids({
            "providers": {
                "groq": {
                    "models": {"visible": {}},
                    "settings": {"apiKey": "secret-value"},
                },
            },
        })
        self.assertEqual(configured, {"groq": {"visible"}})
        self.assertNotIn("secret-value", repr(configured))

    def test_model_lookup_preserves_provider_and_model_identity(self):
        window = SimpleNamespace(_models=[
            {"id": "same-model", "providerID": "google"},
            {"id": "same-model", "providerID": "groq"},
        ])
        self.assertEqual(
            MainWindow._model_index(window, {"id": "same-model", "providerID": "groq"}),
            1,
        )

    def test_session_not_found_is_distinguished_from_an_empty_message_list(self):
        self.assertTrue(MainWindow._is_session_not_found_error(
            "Réponse HTTP 404: Session not found: ses_missing"
        ))
        self.assertFalse(MainWindow._is_session_not_found_error(None))
        self.assertFalse(MainWindow._is_session_not_found_error(
            "Réponse HTTP 404: File not found"
        ))

    def test_active_session_ids_support_opencode_map_and_list_shapes(self):
        self.assertEqual(
            MainWindow._active_session_ids({
                "ses_one": {"status": "busy"},
                "ses_two": {"status": "busy"},
            }),
            {"ses_one", "ses_two"},
        )
        self.assertEqual(
            MainWindow._active_session_ids([
                {"sessionID": "ses_one"},
                {"id": "ses_two"},
                {"title": "not an active session"},
            ]),
            {"ses_one", "ses_two"},
        )
        self.assertEqual(MainWindow._active_session_ids(None), set())

    def test_user_and_assistant_markdown_text_share_block_renderer(self):
        user_content = MainWindow._message_content({
            "type": "user",
            "text": "| Colonne | Valeur |\n| --- | --- |\n| A | **1** |",
        })
        assistant_content = MainWindow._message_content({
            "type": "assistant",
            "content": [{
                "type": "text",
                "text": "| Colonne | Valeur |\n| --- | --- |\n| B | [lien](https://example.test) |",
            }],
        })
        self.assertEqual([kind for kind, _value in user_content], ["text"])
        self.assertEqual([kind for kind, _value in assistant_content], ["text"])
        self.assertEqual(
            [kind for kind, _value in MainWindow._markdown_blocks(user_content[0][1])],
            ["table"],
        )
        self.assertEqual(
            [kind for kind, _value in MainWindow._markdown_blocks(assistant_content[0][1])],
            ["table"],
        )

    def test_scroll_to_bottom_button_only_shows_when_history_is_scrolled_up(self):
        class Adjustment:
            def __init__(self, value):
                self.value = value

            def get_lower(self):
                return 0

            def get_upper(self):
                return 1000

            def get_page_size(self):
                return 300

            def get_value(self):
                return self.value

        class Scroller:
            def __init__(self, value):
                self.adjustment = Adjustment(value)

            def get_vadjustment(self):
                return self.adjustment

        class Button:
            def set_visible(self, visible):
                self.visible = visible

        window = SimpleNamespace(
            _selected_session="ses_active",
            message_scroller=Scroller(100),
            scroll_bottom_button=Button(),
        )
        MainWindow._update_scroll_bottom_visibility(window)
        self.assertTrue(window.scroll_bottom_button.visible)
        window.message_scroller.adjustment.value = 690
        MainWindow._update_scroll_bottom_visibility(window)
        self.assertFalse(window.scroll_bottom_button.visible)
        window._selected_session = None
        window.message_scroller.adjustment.value = 100
        MainWindow._update_scroll_bottom_visibility(window)
        self.assertFalse(window.scroll_bottom_button.visible)

    def test_prompt_404_preserves_payload_and_offers_replacement_instead_of_retry(self):
        offered = []
        generic_retries = []
        window = SimpleNamespace(
            _sending_prompt=True,
            _selected_session="stale",
            _update_send_sensitivity=lambda: None,
            _is_session_not_found_error=MainWindow._is_session_not_found_error,
            _mark_session_stale=lambda session_id, error: offered.append(
                ("stale", session_id, error)
            ),
            refresh_sessions=lambda: offered.append(("refresh",)),
            _show_stale_prompt_recovery=lambda *args: offered.append(
                ("recover",) + args
            ),
            _offer_prompt_retry=lambda *args: generic_retries.append(args),
        )
        files = [{"uri": "file:///tmp/keep.txt", "name": "keep.txt"}]
        error = "Réponse HTTP 404: Session not found: stale"
        MainWindow._on_prompt_sent(
            window, "stale", "keep this text", files, None, None, error
        )
        self.assertFalse(window._sending_prompt)
        self.assertEqual(offered[0], ("stale", "stale", error))
        self.assertEqual(offered[1], ("refresh",))
        self.assertEqual(
            offered[2],
            ("recover", "stale", "keep this text", files, None, error),
        )
        self.assertEqual(generic_retries, [])

    def test_session_load_error_is_visible_instead_of_appearing_as_empty_list(self):
        class Label:
            def set_text(self, text):
                self.text = text

            def add_css_class(self, _name):
                pass

        class Status:
            def set_visible(self, visible):
                self.visible = visible

        window = SimpleNamespace(
            session_load_message=Label(),
            session_load_status=Status(),
        )
        MainWindow._on_sessions_loaded(window, None, "Réponse HTTP 500")
        self.assertEqual(
            window.session_load_message.text,
            "Impossible de charger les sessions : Réponse HTTP 500",
        )
        self.assertTrue(window.session_load_status.visible)

    def test_markdown_parser_keeps_tables_code_and_lists_as_native_blocks(self):
        blocks = MainWindow._markdown_blocks(
            "See [site](https://example.test).\n\n"
            "| Name | Value |\n| --- | --- |\n| a | b |\n\n"
            "```py\nprint(1)\n```\n\n- item"
        )
        self.assertEqual(
            [kind for kind, _ in blocks],
            ["paragraph", "table", "code", "list"],
        )
        self.assertIn('<a href="https://example.test">site</a>', MainWindow._inline_markup("[site](https://example.test)"))
        self.assertNotIn("<a ", MainWindow._inline_markup("[unsafe](javascript:alert(1))"))

    def test_generated_artifact_paths_allow_local_files_only(self):
        with tempfile.NamedTemporaryFile() as handle:
            local = "file://" + handle.name
            self.assertEqual(
                MainWindow._local_artifact_path(local),
                os.path.realpath(handle.name),
            )
        self.assertIsNone(MainWindow._local_artifact_path("https://example.test/image.png"))
        self.assertIsNone(MainWindow._local_artifact_path("file://remote.invalid/tmp/file"))

    def test_context_paths_allow_local_directories_but_artifacts_remain_files(self):
        with tempfile.TemporaryDirectory() as directory:
            local = "file://" + directory
            self.assertEqual(
                MainWindow._local_path(local, allow_directory=True),
                os.path.realpath(directory),
            )
            self.assertIsNone(MainWindow._local_artifact_path(local))

    def test_prompt_draft_is_only_cleared_after_success_if_unchanged(self):
        self.assertTrue(MainWindow._should_clear_prompt("draft", "draft", None))
        self.assertFalse(MainWindow._should_clear_prompt("draft", "draft", "HTTP 404"))
        self.assertFalse(MainWindow._should_clear_prompt("new text", "draft", None))

    def test_enter_sends_but_shift_enter_keeps_a_newline(self):
        from gi.repository import Gdk
        self.assertTrue(MainWindow._should_send_on_key(Gdk.KEY_Return, 0))
        self.assertTrue(MainWindow._should_send_on_key(Gdk.KEY_KP_Enter, 0))
        self.assertFalse(
            MainWindow._should_send_on_key(
                Gdk.KEY_Return, Gdk.ModifierType.SHIFT_MASK
            )
        )

    def test_session_search_matches_titles_and_message_content(self):
        self.assertTrue(MainWindow._matches_search({"title": "Design notes"}, "design"))
        self.assertTrue(MainWindow._matches_search(
            {}, "searchable phrase",
            [{"type": "user", "text": "A searchable phrase in a message"}],
        ))
        self.assertFalse(MainWindow._matches_search(
            {"title": "Unrelated"}, "missing",
            [{"type": "assistant", "content": [{"type": "text", "text": "Nothing"}]}],
        ))

    def test_last_user_message_is_selected_for_edit_and_regenerate(self):
        messages = [
            {"id": "msg_user_old", "type": "user", "text": "Old"},
            {"id": "msg_assistant", "type": "assistant", "content": [
                {"type": "text", "text": "Answer"},
            ]},
            {"id": "msg_user_last", "type": "user", "text": "Latest"},
        ]
        self.assertEqual(
            MainWindow._find_last_user_message(messages),
            {"id": "msg_user_last", "text": "Latest"},
        )

    def test_api_reasoning_variants_get_readable_labels_without_changing_ids(self):
        labels = [
            MainWindow._variant_label(variant)
            for variant in ("none", "minimal", "low", "medium", "high", "xhigh", "max")
        ]
        self.assertEqual(
            labels,
            ["Aucun", "Minimal", "Faible", "Moyen", "Élevé", "Très élevé (Xhigh)", "Maximum"],
        )
        self.assertEqual(MainWindow._variant_label("provider-custom"), "provider-custom")

    def test_build_plan_agent_choices_require_real_primary_agents(self):
        agents = [
            {"id": "build", "name": "Build", "mode": "primary"},
            {"id": "plan", "name": "Plan", "mode": "primary"},
            {"id": "general", "name": "General", "mode": "subagent"},
            {"id": "hidden", "name": "Hidden", "mode": "primary", "hidden": True},
        ]
        self.assertEqual(
            [
                agent["id"] for agent in MainWindow._primary_agents(agents)
            ],
            ["build", "plan"],
        )

    def test_markdown_supports_safe_colors_strike_and_numbered_lists(self):
        blocks = MainWindow._markdown_blocks("## Summary\n\n1. First\n2. Second")
        self.assertEqual([kind for kind, _ in blocks], ["heading", "ordered"])
        markup = MainWindow._inline_markup(
            "{{red:danger}} ~~removed~~ <img>"
        )
        self.assertIn('<span foreground="#e01b24">danger</span>', markup)
        self.assertIn("<s>removed</s>", markup)
        self.assertNotIn("<img>", markup)

    def test_markdown_renders_blockquotes_and_emphasis_without_changing_identifiers(self):
        blocks = MainWindow._markdown_blocks(
            "Paragraph\n\n> quoted **text**\n> with [link](https://example.test)"
        )
        self.assertEqual(
            blocks,
            [
                ("paragraph", "Paragraph"),
                ("quote", "quoted **text**\nwith [link](https://example.test)"),
            ],
        )
        markup = MainWindow._inline_markup(
            "*italic* **bold** _also italic_ snake_case"
        )
        self.assertIn("<i>italic</i>", markup)
        self.assertIn("<b>bold</b>", markup)
        self.assertIn("<i>also italic</i>", markup)
        self.assertIn("snake_case", markup)

    def test_markup_never_spans_newlines_with_inline_code(self):
        # Un bloc de code inline contenant un \n ne doit jamais produire un
        # <tt>…</tt> à cheval sur deux lignes (Pango le rejette et perd le
        # message). Il doit rester en texte brut.
        markup = MainWindow._inline_markup(
            "appelle `refresh_active_session\n228: ``"
        )
        self.assertTrue(markdown_module.valid_markup(markup))
        self.assertIn("\n", markup)
        self.assertNotIn("<tt>refresh_active_session\n", markup)

    def test_valid_markup_detects_unbalanced_tags(self):
        self.assertTrue(markdown_module.valid_markup("<b>x</b> <i>y</i>"))
        self.assertTrue(
            markdown_module.valid_markup(
                '<a href="https://x.test">lien</a> <span foreground="red">r</span>'
            )
        )
        # Mauvais ordre d'imbrication -> invalide.
        self.assertFalse(markdown_module.valid_markup("<b><i>x</b></i>"))
        # Balise jamais refermée -> invalide.
        self.assertFalse(markdown_module.valid_markup("<tt>ouverte"))
        # Exemple réel du bug (« tt fermé mais i ouvert ») -> invalide.
        self.assertFalse(
            markdown_module.valid_markup("<tt>session.<i></tt> <tt>message.</i></tt>")
        )

    def test_inline_markup_always_yields_valid_markup_under_validation(self):
        samples = [
            "[site](https://example.test)",
            "{{red:danger}} ~~r~~ *i* **b** _u_",
            "=== x < y \"q\" end",
            "<a href=\"https://example.test\">site</a>",
            "Read file /tmp/code/main.py, lines 1-30",
            "*italic* **bold** _also italic_ snake_case",
        ]
        for sample in samples:
            self.assertTrue(
                markdown_module.valid_markup(MainWindow._inline_markup(sample)),
                "markup invalide pour : %r" % sample,
            )

    def test_fork_action_target_uses_the_two_string_action_signature(self):
        target = MainWindow._fork_target("session-id", "message-id")
        self.assertEqual(target.get_type_string(), "(ss)")
        self.assertEqual(target.unpack(), ("session-id", "message-id"))

    def test_sidebar_toggle_icon_and_tooltip_match_visibility(self):
        class SidebarContent:
            visible = True

            def get_visible(self):
                return self.visible

            def set_visible(self, visible):
                self.visible = visible

            def set_sensitive(self, sensitive):
                self.sensitive = sensitive

        class Button:
            def set_icon_name(self, name):
                self.icon = name

            def set_tooltip_text(self, text):
                self.tooltip = text

        window = SimpleNamespace(
            _sidebar_content=SidebarContent(), sidebar_button=Button()
        )
        MainWindow.toggle_sidebar(window)
        self.assertFalse(window._sidebar_content.visible)
        self.assertEqual(window.sidebar_button.icon, "sidebar-show-symbolic")
        self.assertEqual(window.sidebar_button.tooltip, "Masquer la liste des sessions")
        MainWindow.toggle_sidebar(window)
        self.assertTrue(window._sidebar_content.visible)
        self.assertEqual(window.sidebar_button.icon, "sidebar-hide-symbolic")
        self.assertEqual(window.sidebar_button.tooltip, "Afficher la liste des sessions")

    def test_prompt_waits_until_context_switches_complete(self):
        class Button:
            sensitive = True
            def set_sensitive(self, value):
                self.sensitive = value

        calls = []
        notices = []
        window = SimpleNamespace(
            _pending_context_switches={},
            _queued_prompt={
                "session_id": "s1",
                "text": "draft",
                "files": [{"uri": "file:///tmp/x"}],
                "delivery": "queue",
                "editing_message_id": None,
            },
            _selected_session="s1",
            _sending_prompt=False,
            send_button=Button(),
            _update_send_sensitivity=lambda: None,
            _show_notice=notices.append,
            _start_prompt=lambda *args: calls.append(args),
        )
        window._pending_context_switches["s1"] = {"count": 2, "error": None}
        MainWindow._finish_context_switch(window, "s1", None)
        self.assertFalse(calls)
        window._pending_context_switches["s1"]["count"] = 1
        MainWindow._finish_context_switch(window, "s1", None)
        self.assertEqual(
            calls,
            [("s1", "draft", "queue", [{"uri": "file:///tmp/x"}], None)],
        )
        self.assertIsNone(window._queued_prompt)

    def test_failed_context_switch_preserves_queued_prompt(self):
        notices = []
        window = SimpleNamespace(
            _pending_context_switches={"s1": {"count": 1, "error": None}},
            _queued_prompt={"session_id": "s1", "text": "keep"},
            _show_notice=notices.append,
            _update_send_sensitivity=lambda: None,
        )
        MainWindow._finish_context_switch(window, "s1", "HTTP 400")
        self.assertIsNone(window._queued_prompt)
        self.assertTrue(any("Message conservé" in notice for notice in notices))

    def test_saving_window_geometry_preserves_ui_preferences(self):
        stored = {
            "pinned_sessions": ["session-1"],
            "zoom_scale": 1.3,
            "show_subagents": True,
            "show_archived": True,
            "stop_on_close": False,
        }
        original_load, original_save = window_module.state.load, window_module.state.save
        try:
            window_module.state.load = lambda: dict(stored)
            window_module.state.save = lambda value: stored.update(value)
            window = SimpleNamespace(
                get_default_size=lambda: (1100, 800),
                is_maximized=lambda: True,
            )
            MainWindow._save_state(window)
        finally:
            window_module.state.load = original_load
            window_module.state.save = original_save
        self.assertEqual(stored["width"], 1100)
        self.assertEqual(stored["height"], 800)
        self.assertTrue(stored["maximized"])
        self.assertEqual(stored["pinned_sessions"], ["session-1"])
        self.assertEqual(stored["zoom_scale"], 1.3)
        self.assertTrue(stored["show_subagents"])
        self.assertTrue(stored["show_archived"])
        self.assertFalse(stored["stop_on_close"])


class WindowConstructionTests(unittest.TestCase):
    """Construit la fenêtre entière (widgets GTK/Adwaita) pour verrouiller les
    erreurs de construction qui échappent aux tests purement logiques.

    Exemple verrouillé ici : une virgule parasite transformant `description`
    en tuple d'un élément (TypeError: Must be string, not tuple), qui plantait
    au tout premier écran. Skip automatiquement en l'absence d'affichage.
    """

    def _make_app(self):
        import gi
        gi.require_version("Adw", "1")
        gi.require_version("Gtk", "4.0")
        from gi.repository import Adw, Gtk
        if not Gtk.init_check():
            return None
        return Adw.Application(application_id="io.gitlab.shogu.Perceptron.test")

    def test_window_builds_without_widget_errors(self):
        app = self._make_app()
        if app is None:
            self.skipTest("Aucun affichage disponible (Gtk.init_check échoue)")

        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        window_module.DATA_DIR = tmp.name

        class FakeServer:
            def __init__(self, *_a, **_k):
                pass
            def connect(self, *_a, **_k):
                return self
            def destroy(self):
                pass

        class FakeNotifier:
            def __init__(self, *_a, **_k):
                pass
            def destroy(self):
                pass

        orig_server = window_module.Server
        orig_notifier = window_module.Notifier
        orig_connect = window_module.MainWindow.connect_and_load
        window_module.Server = FakeServer
        window_module.Notifier = FakeNotifier
        window_module.MainWindow.connect_and_load = lambda self: None
        self.addCleanup(setattr, window_module, "Server", orig_server)
        self.addCleanup(setattr, window_module, "Notifier", orig_notifier)
        self.addCleanup(
            setattr, window_module.MainWindow, "connect_and_load", orig_connect
        )

        result = {}

        def activate(app_):
            try:
                result["win"] = window_module.MainWindow(app_)
                result["ok"] = True
            except Exception as exc:  # noqa: BLE001 - échec testé
                result["ok"] = False
                result["exc"] = exc
            finally:
                app_.quit()

        app.connect("activate", activate)
        app.run(None)

        self.assertTrue(
            result.get("ok"),
            "La construction de la fenêtre a planté : %r"
            % (result.get("exc"),),
        )
        win = result["win"]
        for attr in ("empty_page", "status_page", "content_stack", "message_area"):
            self.assertTrue(hasattr(win, attr), "attribut manquant : %s" % attr)
        # Verrouille le bug virgule-parasite : description = str et non tuple.
        self.assertIsInstance(win.empty_page.get_description(), str)
        self.assertIsInstance(win.status_page.get_description() or "", str)


if __name__ == "__main__":
    unittest.main()
