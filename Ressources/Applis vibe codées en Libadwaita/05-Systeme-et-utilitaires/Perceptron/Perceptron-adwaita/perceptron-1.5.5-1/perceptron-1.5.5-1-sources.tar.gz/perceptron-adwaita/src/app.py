from gi.repository import Adw, Gio, GLib

from config import APP_ID
from window import MainWindow

ACCELERATORS = {
    "app.quit": ["<Control>q"],
    "win.new-session": ["<Control>t"],
    "win.search": ["<Control>f"],
    "win.search-next": ["<Control>g"],
    "win.close-tab": ["<Control>w"],
    "win.next-tab": ["<Control>Page_Down"],
    "win.previous-tab": ["<Control>Page_Up"],
    "win.zoom-in": ["<Control>plus"],
    "win.zoom-out": ["<Control>minus"],
    "win.zoom-reset": ["<Control>0"],
    "win.reload": ["<Control>r", "F5"],
    "win.reconnect": ["<Alt>Home"],
    "win.send-prompt": ["<Control>Return"],
    "win.toggle-sidebar": ["<Control>backslash"],
    "win.fullscreen": ["F11"],
    "win.shortcuts": ["<Control>question"],
}


class PerceptronApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.DEFAULT_FLAGS)
        quit_action = Gio.SimpleAction.new("quit", None)
        quit_action.connect("activate", lambda *_: self.quit())
        self.add_action(quit_action)

        show_session = Gio.SimpleAction.new("show-session", GLib.VariantType.new("s"))
        show_session.connect("activate", self.on_show_session)
        self.add_action(show_session)

        for action, accels in ACCELERATORS.items():
            self.set_accels_for_action(action, accels)

    def window(self):
        return self.props.active_window or MainWindow(self)

    def do_activate(self):
        self.window().present()

    def on_show_session(self, _action, parameter):
        self.window().show_session(parameter.get_string())
