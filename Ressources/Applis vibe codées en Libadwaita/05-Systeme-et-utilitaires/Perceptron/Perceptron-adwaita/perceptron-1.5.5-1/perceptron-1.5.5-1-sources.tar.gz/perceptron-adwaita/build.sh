#!/usr/bin/env bash
# Construit le paquet pacman depuis l'arbre de travail, sans makepkg ni base-devel.
# Besoins : bash, bsdtar, zstd (déjà présents sur un système Arch/CachyOS).
set -euo pipefail

root=$(cd "$(dirname "$0")" && pwd)
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT

source "$root/PKGBUILD"
startdir="$root"
srcdir="$work/src"
pkgdir="$work/pkg"
mkdir -p "$srcdir" "$pkgdir"
package

builddate=$(date +%s)
size=$(du -sb --apparent-size "$pkgdir" | cut -f1)
{
  echo "# Généré par build.sh"
  echo "pkgname = $pkgname"
  echo "pkgbase = $pkgname"
  echo "xdata = pkgtype=pkg"
  echo "pkgver = $pkgver-$pkgrel"
  echo "pkgdesc = $pkgdesc"
  echo "url = $url"
  echo "builddate = $builddate"
  echo "packager = ogu <ogu@localhost>"
  echo "size = $size"
  echo "arch = any"
  for item in "${license[@]}"; do echo "license = $item"; done
  for item in "${depends[@]}"; do echo "depend = $item"; done
  for item in "${optdepends[@]}"; do echo "optdepend = $item"; done
} > "$pkgdir/.PKGINFO"

cd "$pkgdir"
find . -exec touch -h -d "@$builddate" {} +
LANG=C bsdtar --uid 0 --gid 0 --uname root --gname root -czf .MTREE --format=mtree \
  --options='!all,use-set,type,uid,gid,mode,time,size,md5,sha256,link' .PKGINFO usr
output="$root/$pkgname-$pkgver-$pkgrel-any.pkg.tar.zst"
LANG=C bsdtar --uid 0 --gid 0 --uname root --gname root -cf - .MTREE .PKGINFO usr | zstd -19 -q -T0 -f -o "$output"
sources="$root/$pkgname-$pkgver-$pkgrel-sources.tar.gz"
tar -czf "$work/$pkgname-$pkgver-$pkgrel-sources.tar.gz" -C "$(dirname "$root")" \
  --exclude="$pkgname-*.pkg.tar.zst" \
  --exclude="$pkgname-*-sources.tar.gz" \
  --exclude='__pycache__' \
  --exclude='_wip_backup_*' "$(basename "$root")"
mv "$work/$pkgname-$pkgver-$pkgrel-sources.tar.gz" "$sources"
printf '%s\n%s\n' "$output" "$sources"
