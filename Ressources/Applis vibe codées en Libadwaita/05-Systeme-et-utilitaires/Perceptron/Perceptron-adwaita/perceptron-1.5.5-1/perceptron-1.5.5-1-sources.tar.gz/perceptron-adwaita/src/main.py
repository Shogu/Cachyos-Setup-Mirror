"""Perceptron : interface GTK4/libadwaita native pour OpenCode."""

import ctypes
import sys
import traceback

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")

from gi.repository import GLib  # noqa: E402

import journal  # noqa: E402
from app import PerceptronApp  # noqa: E402
from config import APP_ID, APP_NAME  # noqa: E402

PR_SET_NAME = 15


def _log_exceptions(exc_type, exc_value, exc_tb):
    # Les exceptions levées dans les callbacks GTK/GLib n'apparaissent que sur
    # stderr (jamais dans l'UI ni le journal). On les enregistre aussi dans le
    # journal de diagnostic pour pouvoir les diagnostiquer sans capturer le
    # terminal, avant de laisser le comportement Python par défaut agir.
    try:
        journal.log("TRACEBACK AVALÉ:\n" + "".join(
            traceback.format_exception(exc_type, exc_value, exc_tb)
        ).rstrip("\n"))
    except Exception:
        pass
    sys.__excepthook__(exc_type, exc_value, exc_tb)


def main():
    ctypes.CDLL(None).prctl(PR_SET_NAME, b"perceptron", 0, 0, 0)
    GLib.set_prgname(APP_ID)
    GLib.set_application_name(APP_NAME)
    journal.reset()
    sys.excepthook = _log_exceptions
    return PerceptronApp().run(sys.argv)


if __name__ == "__main__":
    sys.exit(main())
