"""Start and stop the authenticated local OpenCode API server."""

from gi.repository import Gio, GLib

from config import find_opencode
from journal import log

HOST = "127.0.0.1"
PORT = 49375
READY_RETRIES = 80
READY_INTERVAL_MS = 250

_server_process = None


def owns_server():
    """True si l'application a elle-même démarré le serveur OpenCode.

    Si la valeur est False, le serveur a été réutilisé (déjà lancé ailleurs,
    par ex. dans un terminal) : il ne doit jamais être arrêté ici.
    """
    return _server_process is not None


def connect(on_ready, server):
    """Reuse the app's local server or start a new authenticated API server."""
    binary = find_opencode()
    if binary is None:
        on_ready(False, "OpenCode est introuvable dans le PATH.")
        return

    def on_probe(_sessions, error):
        if error is None:
            on_ready(True, None)
            return
        if "HTTP 401" in error:
            on_ready(False, error)
            return
        _start_server(binary, server, on_ready)

    server.list_sessions(on_probe)


def _start_server(binary, server, on_ready):
    global _server_process
    launcher = Gio.SubprocessLauncher.new(
        Gio.SubprocessFlags.STDOUT_SILENCE | Gio.SubprocessFlags.STDERR_SILENCE
    )
    launcher.setenv("OPENCODE_SERVER_USERNAME", server.username, True)
    launcher.setenv("OPENCODE_SERVER_PASSWORD", server.password, True)

    try:
        _server_process = launcher.spawnv([
            binary, "serve", "--hostname", HOST, "--port", str(PORT),
        ])
    except GLib.Error as error:
        log("serveur : démarrage impossible (%s)" % error.message)
        on_ready(False, error.message)
        return

    process = _server_process
    process.wait_async(None, _on_server_exit, None)
    log("serveur : démarrage OpenCode API sur %s:%d" % (HOST, PORT))
    _probe_until_ready(server, on_ready, READY_RETRIES)


def _on_server_exit(process, result, _data):
    global _server_process
    try:
        process.wait_finish(result)
    except GLib.Error as error:
        log("serveur : arrêt (%s)" % error.message)
    if _server_process is process:
        _server_process = None


def _probe_until_ready(server, on_ready, attempts_left):
    def on_probe(_sessions, error):
        if error is None:
            log("serveur : API OpenCode prête")
            on_ready(True, None)
        elif "HTTP 401" in error or attempts_left <= 1:
            log("serveur : connexion impossible (%s)" % error)
            on_ready(False, error)
        else:
            GLib.timeout_add(
                READY_INTERVAL_MS,
                _retry_probe,
                server,
                on_ready,
                attempts_left - 1,
            )

    server.list_sessions(on_probe)


def _retry_probe(server, on_ready, attempts_left):
    _probe_until_ready(server, on_ready, attempts_left)
    return GLib.SOURCE_REMOVE


def stop_service(callback=None):
    """Stop the API server started by this application, if still running.

    Arrêt gracieux : envoie SIGTERM puis force l’arrêt après un court
    délai si le processus n’a pas quitté seul.
    """
    global _server_process
    process, _server_process = _server_process, None
    if process is not None:
        try:
            process.send_signal(GLib.ProcessSignal.TERM)
        except GLib.Error as error:
            log("serveur : signal SIGTERM impossible (%s)" % error.message)
            process.force_exit()
        finally:
            def _force_after_timeout():
                if not process.get_if_exited():
                    process.force_exit()
                return GLib.SOURCE_REMOVE
            GLib.timeout_add(2000, _force_after_timeout)
    if callback:
        callback("")
