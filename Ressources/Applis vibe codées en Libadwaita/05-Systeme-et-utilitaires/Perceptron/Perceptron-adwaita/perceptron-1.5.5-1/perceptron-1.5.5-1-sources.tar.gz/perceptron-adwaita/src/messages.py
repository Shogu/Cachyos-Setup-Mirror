"""Helpers purs sur le modèle de message OpenCode (aucune dépendance GTK).

Ces fonctions ne touchent ni aux widgets ni au serveur : elles interprètent
les objets JSON renvoyés par l'API OpenCode (messages, sessions, modèles,
fournisseurs, config) et produisent des chaînes ou des structures simples.
"""

import os
import re
import urllib.parse

from gi.repository import GLib


# --------------------------------------------------------------------------
# Contenu d'un message
# --------------------------------------------------------------------------

# Types de rôles traités comme du texte simple (pas de structure de parts).
_TEXT_ROLES = ("user", "synthetic", "system", "shell", "skill")


def content(message):
    """Renvoie la liste [(kind, value)] du message (*text* ou *tool*)."""
    info = message.get("info")
    outer_parts = message.get("parts")
    if isinstance(info, dict):
        message = info
    role = message.get("type")
    if role in _TEXT_ROLES:
        text = message.get("text") or message.get("output", {}).get("output")
        return [("text", text)] if text else []

    parts = message.get("content")
    if not isinstance(parts, list):
        parts = outer_parts if isinstance(outer_parts, list) else message.get("parts")
    if not isinstance(parts, list):
        text = message.get("text")
        return [("text", text)] if text else []

    result = []
    for part in parts:
        if not isinstance(part, dict):
            continue
        if part.get("type") == "text" and part.get("text"):
            result.append(("text", part["text"]))
        elif part.get("type") == "tool":
            result.append(("tool", part))
    return result


def tool_title(part):
    """Titre lisible d'un part d'outil, ou une chaîne neutre."""
    state = part.get("state")
    state = state if isinstance(state, dict) else {}
    metadata = state.get("metadata", {})
    metadata = metadata if isinstance(metadata, dict) else {}
    return (
        metadata.get("title")
        or state.get("title")
        or part.get("name")
        or "outil"
    )


def text(message):
    """Texte plat du message (pour copie, recherche, dernier message)."""
    parts = []
    for kind, value in content(message):
        if kind == "text":
            parts.append(value)
        else:
            parts.append("Outil : " + str(tool_title(value)))
    return "\n\n".join(parts)


def role_of(message):
    info = message.get("info")
    if isinstance(info, dict) and info.get("role"):
        return info["role"]
    if isinstance(info, dict) and info.get("type"):
        return info["type"]
    return message.get("type", "assistant")


def find_last_user_message(messages):
    for item in reversed(messages if isinstance(messages, list) else []):
        if not isinstance(item, dict):
            continue
        if role_of(item) != "user":
            continue
        info = item.get("info")
        message_id = info.get("id") if isinstance(info, dict) else item.get("id")
        body = text(item)
        if isinstance(message_id, str) and body:
            return {"id": message_id, "text": body}
    return None


# --------------------------------------------------------------------------
# Dates / horodatage
# --------------------------------------------------------------------------

def format_timestamp(value, date_format):
    if isinstance(value, bool) or not isinstance(value, (float, int)):
        return ""
    timestamp = float(value)
    if abs(timestamp) >= 100_000_000_000:
        timestamp /= 1000
    try:
        date_time = GLib.DateTime.new_from_unix_local(int(timestamp))
    except (OverflowError, TypeError, ValueError):
        return ""
    return date_time.format(date_format) if date_time is not None else ""


def message_created(message):
    return format_timestamp(message.get("time", {}).get("created"), "%H:%M")


_WEEKDAYS = (
    "lundi", "mardi", "mercredi", "jeudi", "vendredi",
    "samedi", "dimanche",
)
_MONTHS = (
    "janv.", "févr.", "mars", "avr.", "mai", "juin",
    "juill.", "août", "sept.", "oct.", "nov.", "déc.",
)


def format_session_date(value):
    if isinstance(value, bool) or not isinstance(value, (float, int)):
        return ""
    timestamp = float(value)
    if abs(timestamp) >= 100_000_000_000:
        timestamp /= 1000
    try:
        date_time = GLib.DateTime.new_from_unix_local(int(timestamp))
    except (OverflowError, TypeError, ValueError):
        return ""
    if date_time is None:
        return ""
    label = "%s %d %s" % (
        _WEEKDAYS[date_time.get_day_of_week() - 1],
        date_time.get_day_of_month(),
        _MONTHS[date_time.get_month() - 1],
    )
    current_year = GLib.DateTime.new_now_local().get_year()
    if date_time.get_year() != current_year:
        label += " %d" % date_time.get_year()
    return label


# --------------------------------------------------------------------------
# Chemins / artefacts
# --------------------------------------------------------------------------

def local_path(uri, allow_directory=False):
    if not isinstance(uri, str) or not uri:
        return None
    parsed = urllib.parse.urlsplit(uri)
    if parsed.scheme:
        if parsed.scheme != "file" or parsed.netloc not in ("", "localhost"):
            return None
        path = urllib.parse.unquote(parsed.path)
    elif os.path.isabs(uri):
        path = uri
    else:
        return None
    path = os.path.realpath(path)
    if os.path.isfile(path) or (allow_directory and os.path.isdir(path)):
        return path
    return None


def local_artifact_path(uri):
    return local_path(uri)


def collect_artifacts(message, sink):
    """Collecte les artefacts locaux d'un message dans le dict *sink*."""
    for file_item in message.get("files", []):
        if not isinstance(file_item, dict):
            continue
        source = file_item.get("source", {})
        uri = source.get("uri") if isinstance(source, dict) else None
        if uri:
            collect_artifact(uri, file_item.get("mime", ""), file_item.get("name"), sink)
    info = message.get("info")
    parts = info.get("content", []) if isinstance(info, dict) else message.get("content", [])
    for part in parts if isinstance(parts, list) else []:
        if not isinstance(part, dict) or part.get("type") != "tool":
            continue
        state = part.get("state")
        if not isinstance(state, dict):
            continue
        for item in state.get("content", []):
            if isinstance(item, dict) and item.get("type") == "file":
                collect_artifact(
                    item.get("uri", ""), item.get("mime", ""), item.get("name"), sink
                )


def collect_artifact(uri, mime, name=None, sink=None):
    """Évalue un artefact local et le range dans *sink* (dict id → info)."""
    if sink is None:
        return
    path = local_artifact_path(uri)
    if path is None:
        return
    key = os.path.realpath(path)
    if key not in sink:
        sink[key] = {
            "path": key,
            "uri": GLib.Uri.build(GLib.UriFlags.NONE, "file", None, key, None)
            if False else "file://" + key,
            "mime": mime,
            "name": name or os.path.basename(key),
        }


# --------------------------------------------------------------------------
# Modèles, fournisseurs, recherche
# --------------------------------------------------------------------------

def session_subtitle(session, sessions):
    parent_id = session.get("parentID")
    if not parent_id:
        return ""
    parent = sessions.get(parent_id)
    if parent and parent.get("title"):
        return "Sous-agent de « %s »" % parent["title"]
    return "Sous-agent"


def model_ref(model):
    if not isinstance(model, dict) or not model.get("id") or not model.get("providerID"):
        return None
    ref = {"id": model["id"], "providerID": model["providerID"]}
    if model.get("variant"):
        ref["variant"] = model["variant"]
    return ref


def configured_model_ids(config_files):
    if isinstance(config_files, dict):
        config = config_files
    else:
        config = next(
            (
                item.get("info")
                for item in config_files if isinstance(item, dict)
                and item.get("type") == "document"
                and isinstance(item.get("info"), dict)
            ),
            None,
        ) if isinstance(config_files, list) else None
    if not isinstance(config, dict):
        return None
    providers = config.get("providers")
    if not isinstance(providers, dict):
        return None
    configured = {}
    for provider_id, provider in providers.items():
        if not isinstance(provider, dict):
            continue
        models = provider.get("models")
        if isinstance(models, dict) and models:
            configured[provider_id] = set(models)
        else:
            configured[provider_id] = None
    return configured


def filter_available_models(models, configured_provider_models, active_provider_ids):
    result = []
    for model in models:
        if model.get("enabled") is False:
            continue
        provider_id = model.get("providerID")
        if active_provider_ids is not None and provider_id not in active_provider_ids:
            continue
        if configured_provider_models is not None and provider_id in configured_provider_models:
            configured_ids = configured_provider_models[provider_id]
            if configured_ids is not None and model.get("id") not in configured_ids:
                continue
        result.append(model)
    return result


def group_models_by_provider(models, providers):
    groups = {}
    for model in models:
        groups.setdefault(model["providerID"], []).append(model)
    return [
        (
            provider_id,
            providers.get(provider_id) or provider_id,
            sorted(items, key=lambda model: model["name"].casefold()),
        )
        for provider_id, items in sorted(
            groups.items(),
            key=lambda pair: (providers.get(pair[0]) or pair[0]).casefold(),
        )
    ]


def matches_search(session, query, messages=None):
    needle = query.casefold()
    if needle in (session.get("title") or "").casefold():
        return True
    if isinstance(messages, list):
        return any(
            needle in text(message).casefold()
            for message in messages if isinstance(message, dict)
        )
    return False
