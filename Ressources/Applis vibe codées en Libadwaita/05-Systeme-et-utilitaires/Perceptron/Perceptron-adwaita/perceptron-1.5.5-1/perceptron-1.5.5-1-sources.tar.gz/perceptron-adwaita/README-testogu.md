# Perceptron — README de test



-  Panneau Artefacts	GET /api/experimental/artifacts : ok mais j'ai l'impression que opencode ne bosse qu'en local donc ya jamais d'artefacts dans la side bar non? Ou alords rempalcer par un panel Files qui borwse? Ou mieux : clic sur un lien local genre /home/ogu/xxx ouvre le dossier XXX dans la sidebar Files? Ou dzns NAutilus?


- Websearch + provider	GET /api/websearch/provider, POST /api/websearch	Bouton « Rechercher sur le web » dans la barre du compositeur + sélection du fournisseur dans Préférences : ok maius cela ne renvoie riene t j'ignore qui sont lrs providers a droite dans le menu deroulanbt, C'est quoi cette fonction enf ait?

- Session en arrière-plan	POST /api/session/{id}/background	Entrée dans le menu « … » de chaque session + notification : je ne le vopis pas, c'es tou?

-  Zone de saisie redimensionnable :ok ca amrche mais je dois tirer vers le haut pour que la zone reduise et inversement, c'est pas intuitif. Et la pougnée es tdififile a repérer. Fais du natif adwaita

- Aperçu des messages dans la barre de droite : c'est fonctionnel mais les trois pts ... sont mpins utiles qu'une numérotation : 1 2 3 etc et clique dessus montre l'aperçu


- Sous-agents : ca ne va pas car les subagents apparaissent dans la side bar ce qui ne sert à rien :  on supprime!

A aprtir des screenshotsjoints  a anayser avec Nemotron FREE : 


- De + ,le temrinal n'envoie aps les commandes, refusent que je saisisse plus d'un eltrre,e t son expace en bas esT RESERVÉ et gene donc l'UI generale. On l'enleve tant pis.

- Perceptron ne se ferme jamais vraiment non plus, quoi qu'on fasse du reglage "fermer le serveur", il reste en mémoire d'apres Ressources le task manager 

-  l'UI avec la barre blue est mocje, les onglets ont le coté superieur qui se fond dans la barre superieure (?), la filtre Filmtres es tdans un cartotuche trop gros, retire la scrollbar dans le elft panel. La sidebar pourrait etre comme sur Nautilus non (voir screenshot)

- Dans les reponses de l'agent les tableaux sont tout petits et illisibles. 

- markdown : retire la focntion Tableu en fait

- les textes de réponses de opencode dispariasse en theme dark light

- les tableaux defilants/deroulants des réponses opencode sont trop petits

- pas de message d'erreur quand la genrration echoue (pas de otkens, free limit dépaséé ou comapctage raté etc...)

- Boutons de regalges geenraux : à mettre juste a gauche du bouton de fermeture comme sur toutes les applis adwaita?