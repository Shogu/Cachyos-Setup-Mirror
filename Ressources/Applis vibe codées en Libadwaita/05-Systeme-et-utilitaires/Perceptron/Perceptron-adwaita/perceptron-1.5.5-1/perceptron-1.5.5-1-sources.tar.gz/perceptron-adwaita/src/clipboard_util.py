"""Copie dans le presse-papiers de façon fiable.

Sous Wayland, ``Gdk.Clipboard.set_text`` fonctionne en théorie, mais selon le
compositeur / l'absence de gestionnaire de presse-papiers le contenu peut ne
jamais être servi. On privilégie donc ``wl-copy`` (outil de référence de
wl-clipboard) quand il est disponible, avec repli sur l'API GTK.
"""

import os
import shutil
import subprocess


def _copy_wayland(text):
    if not os.environ.get("WAYLAND_DISPLAY"):
        return False
    tool = shutil.which("wl-copy")
    if not tool:
        return False
    try:
        subprocess.run(
            [tool],
            input=text.encode("utf-8"),
            timeout=5,
            check=False,
        )
        return True
    except (OSError, subprocess.SubprocessError):
        return False


def _copy_x11(text):
    for name, args in (
        ("xclip", ["xclip", "-selection", "clipboard"]),
        ("xsel", ["xsel", "--clipboard", "--input"]),
    ):
        tool = shutil.which(name)
        if not tool:
            continue
        try:
            subprocess.run(
                args, input=text.encode("utf-8"), timeout=5, check=False
            )
            return True
        except (OSError, subprocess.SubprocessError):
            continue
    return False


def _copy_gtk(widget, text):
    try:
        from gi.repository import Gdk

        display = widget.get_display() if widget is not None else None
        display = display or Gdk.Display.get_default()
        if display is None:
            return False
        display.get_clipboard().set_text(text)
        return True
    except Exception:  # pragma: no cover - dépend du backend GTK
        return False


def copy_text(widget, text):
    """Copie ``text`` et renvoie True si au moins une méthode a réussi."""
    text = "" if text is None else str(text)
    if text == "":
        return False
    # 1) Wayland natif (le plus fiable sur GNOME/Wayland).
    if _copy_wayland(text):
        return True
    # 2) X11 (si session X11).
    if _copy_x11(text):
        return True
    # 3) API GTK (dernier recours).
    return _copy_gtk(widget, text)
