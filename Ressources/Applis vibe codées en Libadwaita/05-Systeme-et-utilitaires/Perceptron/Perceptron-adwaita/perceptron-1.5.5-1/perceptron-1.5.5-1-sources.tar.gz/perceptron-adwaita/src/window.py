import os
import re
import json
import time
import shutil
import pty
import select
import subprocess
import threading
import urllib.parse

import gi

gi.require_version("Adw", "1")
gi.require_version("Gtk", "4.0")

from gi.repository import Adw, Gdk, Gio, GLib, Gtk, Pango

import opencode
import state
import markdown
import conversation
import journal
import clipboard_util
from config import APP_ID, APP_NAME, DATA_DIR, VERSION
from notifier import Notifier
from server import Server

SHORTCUTS = (
    ("<Control>t", "Nouvelle session"),
    ("<Control>w", "Fermer l’onglet actif"),
    ("<Control>Page_Up", "Onglet précédent"),
    ("<Control>Page_Down", "Onglet suivant"),
    ("<Return>", "Envoyer le message"),
    ("<Shift>Return", "Insérer une nouvelle ligne"),
    ("<Control>plus", "Agrandir le texte"),
    ("<Control>minus", "Réduire le texte"),
    ("<Control>0", "Réinitialiser la taille du texte"),
    ("<Control>r", "Recharger les sessions"),
    ("<Control>backslash", "Afficher ou masquer la liste des sessions"),
    ("<Alt>Home", "Reconnecter"),
    ("F11", "Plein écran"),
    ("<Control>question", "Raccourcis clavier"),
    ("<Control>q", "Quitter"),
)


class MainWindow(Adw.ApplicationWindow):
    # Repli de l'historique : on affiche par défaut les N récents, et on
    # déplie progressivement les plus anciens par paquets.
    HISTORY_DEFAULT_KEEP = 40
    HISTORY_STEP = 25

    # Dossiers de départ par catégorie pour le bouton « Ajouter ».
    DEFAULT_FOLDERS = {
        "images": "~/Images",
        "archives": "~/Téléchargements",
        "all": "~",
    }

    def __init__(self, app):
        super().__init__(application=app, title=APP_NAME)
        self._connecting = False
        self._closing = False
        self._selected_session = None
        self._sessions = {}
        self._updating_sessions = False
        self._sending_prompt = False
        saved_state = state.load()
        self._show_subagents = bool(saved_state.get("show_subagents", False))
        self._show_archived = bool(saved_state.get("show_archived", False))
        self._zoom_scale = min(1.6, max(0.8, float(saved_state.get("zoom_scale", 1.0))))
        saved_height = saved_state.get("composer_height")
        try:
            saved_height = int(saved_height)
        except (TypeError, ValueError):
            saved_height = 0
        self._composer_height = min(
            420, max(72, saved_height or 88)
        )
        self._pinned_sessions = set(saved_state.get("pinned_sessions", []))
        self._last_session_id = saved_state.get("last_session")
        self._models = []
        self._all_models = []
        self._models_loaded = False
        self._config_loaded = False
        self._configured_provider_models = None
        self._providers = {}
        self._active_provider_ids = None
        self._current_model = None
        self._default_model = None
        self._loading_model = False
        self._loading_variant = False
        self._agents = []
        self._current_agent = None
        self._loading_agent = False
        self._active_sessions = set()
        self._search_query = ""
        self._search_generation = 0
        self._search_content_ids = set()
        self._search_pending = 0
        self._search_errors = 0
        self._search_scanned = 0
        self._search_total = 0
        self._search_queue = []
        self._session_fetch_generation = 0
        self._session_refresh_timeout = 0
        self._session_rows_signature = None
        self._active_refresh_timeout = 0
        self._message_reload_timeout = 0
        self._artifacts = {}
        self._history_cards = []
        self._history_texts = []
        self._history_reveal = 0
        self._term_master = None
        self._term_proc = None
        self._term_thread = None
        self._term_buffer = None
        self.terminal_revealer = None
        self.terminal_button = None
        self.terminal_entry = None
        self.terminal_view = None
        self._chat_search_matches = []
        self._chat_search_index = 0
        self._history_bar = None
        self._banner_session_id = None
        self._prompt_files = []
        self._markdown_renderer = None
        self._prompt_drafts = {}
        self._editing_message_id = None
        self._last_user_message = None
        self._pending_context_switches = {}
        self._queued_prompt = None
        self._invalid_sessions = set()

        # Raccourci clavier du terminal : Ctrl+@ (backquote) bascule le tiroir.
        term_controller = Gtk.EventControllerKey()
        term_controller.connect("key-pressed", self._on_terminal_key)
        self.add_controller(term_controller)

        self.set_default_size(saved_state.get("width", 1180), saved_state.get("height", 820))
        if saved_state.get("maximized"):
            self.maximize()

        os.makedirs(DATA_DIR, mode=0o700, exist_ok=True)
        os.chmod(DATA_DIR, 0o700)
        cookie_file = os.path.join(DATA_DIR, "cookies.txt")
        cookie_fd = os.open(cookie_file, os.O_CREAT | os.O_RDWR, 0o600)
        os.close(cookie_fd)
        os.chmod(cookie_file, 0o600)
        password_file = os.path.join(DATA_DIR, "server-password")
        self.server = Server(cookie_file, password_file)
        self.server.connect("event", self._on_server_event)
        self.notifier = Notifier(self, self.server)
        self.set_content(self._build_content())
        self._add_actions()
        self.connect("close-request", self.on_close_request)
        self.connect_and_load()

    def _build_content(self):
        self.window_title = Adw.WindowTitle(title=APP_NAME)
        header = Adw.HeaderBar(title_widget=self.window_title)
        self.sidebar_button = Gtk.Button(
            icon_name="sidebar-show-symbolic",
            tooltip_text="Masquer ou afficher la liste des sessions",
            action_name="win.toggle-sidebar",
        )
        header.pack_start(self.sidebar_button)
        header.pack_start(Gtk.Button(
            icon_name="list-add-symbolic",
            tooltip_text="Nouvelle session (Ctrl+T)",
            action_name="win.new-session",
        ))
        self.model_dropdown = Gtk.MenuButton(
            tooltip_text="Choisir le modèle — classé par fournisseur"
        )
        model_button_content = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL, spacing=6
        )
        self.model_label = Gtk.Label(
            label="Chargement des modèles…",
            max_width_chars=24,
            ellipsize=Pango.EllipsizeMode.END,
        )
        model_button_content.append(self.model_label)
        model_button_content.append(Gtk.Image(icon_name="pan-down-symbolic"))
        self.model_dropdown.set_child(model_button_content)
        self.model_dropdown.set_tooltip_text("Modèle utilisé pour la conversation")

        self.variant_dropdown = Gtk.DropDown.new_from_strings(["Défaut"])
        self.variant_dropdown.set_tooltip_text("Niveau de réflexion fourni par le modèle")
        self.variant_dropdown.connect("notify::selected", self._on_variant_selected)

        self.agent_dropdown = Gtk.DropDown.new_from_strings(["Agents…"])
        self.agent_dropdown.set_tooltip_text("Agent utilisé pour la conversation")
        self.agent_dropdown.connect("notify::selected", self._on_agent_selected)

        # Bouton « Modèle » dédié : regroupe modèle, variante et agent dans un
        # seul popover propre, pour épurer le header (au lieu de 3 contrôles
        # alignés + le doublon Build/Plan).
        popover = Gtk.Popover()
        bundle = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        bundle.set_margin_top(8)
        bundle.set_margin_bottom(8)
        bundle.set_margin_start(8)
        bundle.set_margin_end(8)
        bundle.set_size_request(300, -1)

        def _model_row(label, widget):
            row_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            row_label = Gtk.Label(label=label, xalign=0)
            row_label.add_css_class("dim-label")
            row_label.set_margin_start(4)
            row_box.append(row_label)
            widget.set_hexpand(True)
            widget.set_halign(Gtk.Align.FILL)
            row_box.append(widget)
            return row_box

        bundle.append(_model_row("Modèle", self.model_dropdown))
        bundle.append(_model_row("Variante (réflexion)", self.variant_dropdown))
        bundle.append(_model_row("Agent", self.agent_dropdown))
        popover.set_child(bundle)

        self.model_button = Gtk.MenuButton(tooltip_text="Modèle, variante et agent de la conversation")
        model_button_content = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL, spacing=6
        )
        model_button_content.append(
            Gtk.Image(icon_name="applications-science-symbolic")
        )
        model_button_content.append(Gtk.Label(label="Modèle"))
        model_button_content.append(Gtk.Image(icon_name="pan-down-symbolic"))
        self.model_button.set_child(model_button_content)
        self.model_button.set_popover(popover)
        header.pack_end(self.model_button)
        self.artifacts_button = Gtk.Button(
            icon_name="folder-pictures-symbolic",
            tooltip_text="Afficher ou masquer les artefacts de la session",
            action_name="win.toggle-artifacts",
        )
        header.pack_end(self.artifacts_button)
        self.scroll_bottom_button = Gtk.Button(
            icon_name="go-bottom-symbolic",
            tooltip_text="Aller en bas de la conversation",
            action_name="win.scroll-bottom",
        )
        self.scroll_bottom_button.set_visible(False)
        header.pack_end(self.scroll_bottom_button)
        self.terminal_button = Gtk.Button.new_from_icon_name("utilities-terminal-symbolic")
        self.terminal_button.set_tooltip_text("Afficher ou masquer le terminal")
        self.terminal_button.add_css_class("flat")
        self.terminal_button.connect("clicked", self._toggle_terminal)
        header.pack_end(self.terminal_button)
        # Statut de génération placé dans le compositeur (voir plus bas), pas
        # dans le header.
        self.generation_status = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL, spacing=6
        )
        self.generation_status.add_css_class("dim-label")
        self.generation_spinner = Gtk.Spinner()
        self.generation_spinner.set_size_request(16, 16)
        self.generation_status.append(self.generation_spinner)
        self.generation_status.append(Gtk.Label(label="Génération en cours"))
        self.generation_status.set_visible(False)
        self.interrupt_button = Gtk.Button(
            icon_name="process-stop-symbolic",
            tooltip_text="Arrêter la génération",
            action_name="win.interrupt-session",
            sensitive=False,
        )
        header.pack_end(Gtk.MenuButton(
            icon_name="open-menu-symbolic",
            tooltip_text="Menu principal",
            primary=True,
            menu_model=self._build_menu(),
        ))

        self.session_list = Gtk.ListBox(
            selection_mode=Gtk.SelectionMode.SINGLE,
            show_separators=False,
        )
        self.session_list.add_css_class("navigation-sidebar")
        self.session_list.connect("row-selected", self._on_row_selected)
        self.session_search = Gtk.SearchEntry(
            placeholder_text="Rechercher titre et contenu…",
            search_delay=350,
            margin_start=12,
            margin_end=12,
            margin_top=8,
            margin_bottom=8,
        )
        self.session_search.connect("search-changed", self._on_session_search_changed)
        self.session_search.connect("activate", self._on_session_search_activate)
        self.search_status = Gtk.Label(
            xalign=0,
            margin_start=16,
            margin_end=16,
            margin_bottom=4,
            css_classes=["dim-label"],
        )
        self.search_status.set_visible(False)
        self.session_load_status = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL, spacing=8,
            margin_start=12, margin_end=12, margin_bottom=6,
        )
        self.session_load_message = Gtk.Label(
            xalign=0, wrap=True, hexpand=True,
        )
        self.session_load_message.add_css_class("error")
        self.session_load_status.append(self.session_load_message)
        self.session_retry_button = Gtk.Button(
            icon_name="view-refresh-symbolic",
            tooltip_text="Réessayer de charger les sessions",
            action_name="win.reload",
        )
        self.session_load_status.append(self.session_retry_button)
        self.session_load_status.set_visible(False)
        self.session_scroller = Gtk.ScrolledWindow(
            min_content_width=220,
            max_content_width=340,
            hscrollbar_policy=Gtk.PolicyType.NEVER,
            vexpand=True,
        )
        self.session_scroller.set_child(self.session_list)
        self.sessions_heading = Adw.HeaderBar()
        self.sessions_heading.set_title_widget(Adw.WindowTitle(title="Sessions"))
        self.sessions_heading.pack_end(Gtk.Button(
            icon_name="view-refresh-symbolic",
            tooltip_text="Recharger les sessions",
            action_name="win.reload",
        ))
        # Filtres d’affichage — groupe repliable canonique Adwaita.
        # Regroupés dans un Adw.ExpanderRow fermé par défaut avec des
        # Adw.SwitchRow dédiés : discret, économe en espace et conforme à
        # la manière dont GNOME organise les bascules de filtres latérales.
        self.subagent_switch = Adw.SwitchRow(
            title="Afficher les sous-agents",
            subtitle="Masqués par défaut",
            active=self._show_subagents,
        )
        self.subagent_switch.connect("notify::active", self._on_subagents_toggled)
        self.archived_switch = Adw.SwitchRow(
            title="Afficher les archives",
            subtitle="Sessions archivées incluses",
            active=self._show_archived,
        )
        self.archived_switch.connect("notify::active", self._on_archived_toggled)
        self.filters_expander = Adw.ExpanderRow(
            title="Filtres",
            subtitle="Sous-agents et archivage",
            show_enable_switch=False,
        )
        self.filters_expander.add_row(self.subagent_switch)
        self.filters_expander.add_row(self.archived_switch)
        session_options = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        session_options.add_css_class("boxed-list")
        session_options.append(self.filters_expander)
        sidebar_content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        sidebar_content.append(self.sessions_heading)
        sidebar_content.append(self.session_search)
        sidebar_content.append(self.search_status)
        sidebar_content.append(self.session_load_status)
        sidebar_content.append(session_options)
        sidebar_content.append(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL))
        sidebar_content.append(self.session_scroller)
        self._sidebar_content = sidebar_content

        self.message_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.message_box.set_margin_top(18)
        self.message_box.set_margin_bottom(18)
        self.message_box.set_margin_start(18)
        self.message_box.set_margin_end(18)
        self.message_scroller = Gtk.ScrolledWindow(
            hscrollbar_policy=Gtk.PolicyType.NEVER,
            vexpand=True,
            hexpand=True,
        )
        self.message_scroller.set_child(self.message_box)
        adjustment = self.message_scroller.get_vadjustment()
        adjustment.connect("notify::value", self._update_scroll_bottom_visibility)
        adjustment.connect("notify::upper", self._update_scroll_bottom_visibility)
        adjustment.connect("notify::page-size", self._update_scroll_bottom_visibility)
        self.bookmark_box = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL, spacing=4,
            margin_top=2, margin_bottom=2, margin_end=10,
        )
        self.bookmark_scroller = Gtk.ScrolledWindow(
            min_content_width=150,
            max_content_width=210,
            hscrollbar_policy=Gtk.PolicyType.NEVER,
            vscrollbar_policy=Gtk.PolicyType.AUTOMATIC,
            overlay_scrolling=True,
        )
        self.bookmark_scroller.add_css_class("bookmark-scroller")
        self.bookmark_scroller.set_child(self.bookmark_box)
        self.message_area = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        self.message_area.append(self.message_scroller)
        self.message_area.append(self.bookmark_scroller)

        self.empty_page = Adw.StatusPage(
            icon_name="chat-message-new-symbolic",
            title="Perceptron",
            description=(
                "Sélectionne une session dans la barre latérale, ouvre une "
                "nouvelle conversation (Ctrl+T) et commence à coder."
            ),
        )
        welcome_actions = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL, spacing=8,
            halign=Gtk.Align.CENTER,
        )
        new_session_button = Gtk.Button(
            label="Nouvelle session", action_name="win.new-session"
        )
        new_session_button.add_css_class("suggested-action")
        new_session_button.add_css_class("pill")
        welcome_actions.append(new_session_button)
        welcome_content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        welcome_content.append(welcome_actions)
        hint = Gtk.Label(
            label=(
                "Astuce : glisse des fichiers directement dans la zone de "
                "saisie pour les joindre, et utilise Ctrl+ ? pour voir "
                "tous les raccourcis."
            ),
            wrap=True,
            max_width_chars=60,
            css_classes=["dim-label"],
        )
        welcome_content.append(hint)
        self.empty_page.set_child(welcome_content)
        self.conversation = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        # Bandeau Adwaita natif signalant qu'une session en arrière-plan a fini.
        self.activity_banner = Adw.Banner(
            title="Réponse terminée",
            button_label="Voir",
            revealed=False,
        )
        self.activity_banner.connect("button-clicked", self._on_activity_banner_clicked)
        self.conversation.append(self.activity_banner)
        # Recherche native Ctrl+F dans la conversation affichée.
        self.chat_search_bar = Gtk.SearchBar()
        search_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        search_box.set_margin_start(12)
        search_box.set_margin_end(12)
        self.chat_search_entry = Gtk.SearchEntry(
            placeholder_text="Rechercher dans la conversation…",
            hexpand=True,
        )
        self.chat_search_entry.connect(
            "search-changed", self._on_chat_search_changed
        )
        self.chat_search_entry.connect("activate", self._on_chat_search_next)
        self.chat_search_status = Gtk.Label()
        self.chat_search_status.add_css_class("dim-label")
        search_box.append(self.chat_search_entry)
        search_box.append(self.chat_search_status)
        self.chat_search_bar.set_child(search_box)
        self.chat_search_bar.connect_entry(self.chat_search_entry)
        self.chat_search_bar.connect(
            "notify::search-mode-enabled", self._on_chat_search_mode_changed
        )
        self.conversation.append(self.chat_search_bar)
        self.conversation.append(self.message_area)

        self.prompt = Gtk.TextView(
            wrap_mode=Gtk.WrapMode.WORD_CHAR,
            accepts_tab=False,
            height_request=52,
            hexpand=True,
            left_margin=12,
            right_margin=12,
            top_margin=10,
            bottom_margin=10,
        )
        self.prompt.add_css_class("view")
        prompt_toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        prompt_toolbar.set_margin_start(18)
        prompt_toolbar.set_margin_end(18)
        # Bouton « Ajouter » : catégories avec dossier de départ et filtre
        # propres (images, archives, tous fichiers).
        self.add_button = Gtk.MenuButton(
            icon_name="mail-attachment-symbolic",
            tooltip_text="Ajouter une pièce jointe",
        )
        self.add_button.add_css_class("flat")
        add_popover = Gtk.Popover()
        add_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        add_box.set_margin_top(6)
        add_box.set_margin_bottom(6)
        add_box.set_margin_start(6)
        add_box.set_margin_end(6)
        for label, category, icon in (
            ("Image…", "images", "image-x-generic-symbolic"),
            ("Archive / paquet…", "archives", "package-x-generic-symbolic"),
            ("Tous les fichiers…", "all", "text-x-generic-symbolic"),
        ):
            item = Gtk.Button()
            item.set_has_frame(False)
            item.set_child(self._add_menu_row(icon, label))
            item.connect("clicked", self._on_add_category_clicked, category)
            add_box.append(item)
        add_popover.set_child(add_box)
        self.add_button.set_popover(add_popover)
        prompt_toolbar.append(self.add_button)
        self.prompt_attachment_box = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL, spacing=6
        )
        self.prompt_attachment_box.set_margin_start(18)
        self.prompt_attachment_box.set_margin_end(18)
        self.prompt_attachment_box.set_visible(False)
        for icon, tooltip, prefix, suffix, placeholder in (
            ("format-text-bold-symbolic", "Gras", "**", "**", "texte"),
            ("format-text-italic-symbolic", "Italique", "*", "*", "texte"),
            ("format-text-strikethrough-symbolic", "Barré", "~~", "~~", "texte"),
            ("document-edit-symbolic", "Titre", "## ", "", "Titre"),
            ("view-list-symbolic", "Liste numérotée", "1. ", "", "élément"),
        ):
            button = Gtk.Button.new_from_icon_name(icon)
            button.set_tooltip_text(tooltip)
            button.add_css_class("flat")
            button.connect(
                "clicked", self._insert_markdown, prefix, suffix, placeholder
            )
            prompt_toolbar.append(button)
        # Couleurs : un seul bouton ouvrant une palette (dont le rose).
        self.color_button = Gtk.MenuButton(tooltip_text="Couleur du texte")
        self.color_button.add_css_class("flat")
        color_child = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        color_letter = Gtk.Label(label="A")
        color_letter.add_css_class("markdown-color-red")
        color_letter.add_css_class("markdown-color-picker")
        color_child.append(color_letter)
        color_child.append(Gtk.Image(icon_name="pan-down-symbolic"))
        self.color_button.set_child(color_child)
        color_popover = Gtk.Popover()
        color_grid = Gtk.Grid(
            row_spacing=2, column_spacing=2,
            margin_top=6, margin_bottom=6, margin_start=6, margin_end=6,
        )
        for index, color in enumerate(
            ("red", "orange", "yellow", "green", "blue", "purple", "pink")
        ):
            swatch = Gtk.Button()
            swatch.add_css_class("flat")
            swatch.set_tooltip_text(color.capitalize())
            dot = Gtk.Label()
            dot.set_markup(
                '<span foreground="%s" size="large">●</span>'
                % markdown.MARKDOWN_COLORS.get(color, color)
            )
            swatch.set_child(dot)
            swatch.connect("clicked", self._insert_color, color)
            color_grid.attach(swatch, index % 4, index // 4, 1, 1)
        color_popover.set_child(color_grid)
        self.color_button.set_popover(color_popover)
        prompt_toolbar.append(self.color_button)
        # Insertion d'un tableau simple.
        table_button = Gtk.Button.new_from_icon_name("view-grid-symbolic")
        table_button.set_tooltip_text("Insérer un tableau simple")
        table_button.add_css_class("flat")
        table_button.connect("clicked", self._insert_table)
        prompt_toolbar.append(table_button)
        # Recherche web : bouton dans la barre du compositeur, configuré dans
        # les Préférences (fournisseur). Ouvre une fenêtre de recherche.
        prompt_toolbar.append(Gtk.Separator(
            orientation=Gtk.Orientation.VERTICAL
        ))
        websearch_button = Gtk.Button.new_from_icon_name("web-browser-symbolic")
        websearch_button.set_tooltip_text("Rechercher sur le web (fournisseur configuré)")
        websearch_button.add_css_class("flat")
        websearch_button.connect("clicked", self._show_websearch_dialog)
        prompt_toolbar.append(websearch_button)
        prompt_key_controller = Gtk.EventControllerKey()
        prompt_key_controller.connect("key-pressed", self._on_prompt_key_pressed)
        self.prompt.add_controller(prompt_key_controller)
        self.prompt_scroll = Gtk.ScrolledWindow(
            min_content_height=52,
            max_content_height=420,
            hscrollbar_policy=Gtk.PolicyType.NEVER,
        )
        self.prompt_scroll.set_child(self.prompt)
        # Libellé d'invite affiché tant que la zone de saisie est vide : rend
        # immédiatement visible « où écrire ».
        self.prompt_placeholder = Gtk.Label(
            label="Écris ton message…",
            xalign=0,
            yalign=0,
            margin_start=14,
            margin_top=12,
            css_classes=["dim-label"],
        )
        self.prompt_placeholder.set_can_target(False)
        self.prompt_overlay = Gtk.Overlay()
        self.prompt_overlay.set_child(self.prompt_scroll)
        self.prompt_overlay.add_overlay(self.prompt_placeholder)
        self.prompt.get_buffer().connect(
            "changed", self._on_prompt_buffer_changed_placeholder
        )
        self._update_prompt_placeholder()
        self.send_button = Gtk.Button(
            label="Envoyer",
            icon_name="send-to-symbolic",
            valign=Gtk.Align.END,
            action_name="win.send-prompt",
        )
        self.send_button.add_css_class("suggested-action")
        delivery_menu = Gio.Menu()
        delivery_menu.append(
            "Question secondaire — mettre en file",
            "win.send-queued-prompt",
        )
        self.delivery_menu_button = Gtk.MenuButton(
            icon_name="pan-down-symbolic",
            tooltip_text="Options d’envoi",
            menu_model=delivery_menu,
            valign=Gtk.Align.END,
        )
        prompt_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        prompt_row.set_margin_top(12)
        prompt_row.set_margin_bottom(4)
        prompt_row.set_margin_start(18)
        prompt_row.set_margin_end(18)
        prompt_row.append(self.prompt_overlay)
        prompt_row.append(self.send_button)
        prompt_row.append(self.delivery_menu_button)
        prompt_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        prompt_container.append(prompt_toolbar)
        prompt_container.append(self.prompt_attachment_box)
        # Statut de génération + bouton Arrêter, dans la zone du compositeur.
        self.composer_status_bar = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL, spacing=8
        )
        self.composer_status_bar.set_margin_start(18)
        self.composer_status_bar.set_margin_end(18)
        self.composer_status_bar.set_margin_bottom(2)
        self.composer_status_bar.append(self.generation_status)
        self.composer_status_bar.append(self.interrupt_button)
        prompt_container.append(self.composer_status_bar)
        self._build_composer_handle(prompt_container)
        prompt_container.append(prompt_row)
        self.conversation.append(prompt_container)
        # Glisser-déposer de pièces jointes directement sur le compositeur.
        drop_target = Gtk.DropTarget(
            actions=Gdk.DragAction.COPY,
            formats=Gdk.ContentFormats.new_for_gtype(Gdk.FileList),
        )
        drop_target.connect("drop", self._on_prompt_drop)
        prompt_container.add_controller(drop_target)

        self.content_stack = Gtk.Stack(
            transition_type=Gtk.StackTransitionType.CROSSFADE,
            hexpand=True,
            vexpand=True,
        )
        self.content_stack.add_named(self.empty_page, "empty")
        self.content_stack.add_named(self.conversation, "conversation")
        self.content_stack.set_visible_child_name("empty")

        self.tab_view = Adw.TabView()
        self.tab_view.set_vexpand(True)
        self.tab_view.connect("notify::selected-page", self._on_tab_view_changed)
        self.tab_view.connect("close-page", self._on_tab_close_page)
        self.tab_bar = Adw.TabBar(view=self.tab_view, autohide=True)
        self.tab_bar.set_expand_tabs(False)
        self.tab_bar.set_overflow(Gtk.Overflow.HIDDEN)
        self.tab_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.tab_container.append(self.tab_bar)
        self.tab_container.append(self.tab_view)
        self._session_tabs = {}
        self._page_sessions = {}
        self._tab_counter = 0
        empty_tab_content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self._empty_tab = self.tab_view.append(empty_tab_content)
        self._empty_tab.set_title("Accueil")
        empty_tab_content.append(self.content_stack)

        self.status_page = Adw.StatusPage(icon_name="network-error-symbolic")
        retry = Gtk.Button(label="Réessayer", action_name="win.reconnect")
        retry.add_css_class("pill")
        retry.add_css_class("suggested-action")
        self.status_page.set_child(retry)
        self.spinner = Adw.Spinner(
            width_request=48, height_request=48,
            halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER,
        )
        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE)
        self.stack.add_named(self.spinner, "loading")
        self.stack.add_named(self.status_page, "error")
        self.stack.add_named(self._build_workspace(), "workspace")

        toolbar = Adw.ToolbarView(content=self.stack)
        toolbar.add_top_bar(header)
        toolbar.add_css_class("perceptron-content")
        self._zoom_provider = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_display(
            self.get_display(),
            self._zoom_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )
        self._apply_zoom()
        # Conteneur principal : la toolbar (conversation) prend tout l'espace,
        # le terminal s'y ajoute en dessous, replié par défaut.
        main_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        toolbar.set_vexpand(True)
        main_vbox.append(toolbar)

        # Terminal en appui (tiroir en bas) : vrai shell bash via PTY.
        self.terminal_revealer = Gtk.Revealer(
            transition_type=Gtk.RevealerTransitionType.SLIDE_DOWN,
            transition_duration=250,
            child_revealed=False,
        )
        self.terminal_revealer.set_size_request(-1, 0)
        terminal_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        terminal_box.set_size_request(-1, 210)

        self.terminal_scroll = Gtk.ScrolledWindow(vexpand=True)
        self.terminal_view = Gtk.TextView()
        self.terminal_view.set_editable(False)
        self.terminal_view.set_cursor_visible(False)
        self.terminal_view.set_monospace(True)
        self.terminal_view.set_left_margin(8)
        self.terminal_view.set_right_margin(8)
        self.terminal_view.set_top_margin(4)
        self.terminal_view.set_bottom_margin(4)
        self._term_buffer = self.terminal_view.get_buffer()
        self._term_buffer.create_tag("prompt", foreground="#8ab4f8", weight=700)
        self.terminal_scroll.set_child(self.terminal_view)
        terminal_box.append(self.terminal_scroll)

        input_box = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL, spacing=6,
            margin_top=4, margin_bottom=4, margin_start=8, margin_end=8,
        )
        prompt_label = Gtk.Label(label="$ ")
        prompt_label.set_xalign(0)
        prompt_label.add_css_class("dim-label")
        self.terminal_entry = Gtk.Entry(
            placeholder_text="Commande (ex. ls, pacman -U …)"
        )
        self.terminal_entry.set_hexpand(True)
        self.terminal_entry.connect("activate", self._on_terminal_enter)
        send_btn = Gtk.Button(label="Exécuter")
        send_btn.connect("clicked", self._on_terminal_enter)
        stop_btn = Gtk.Button.new_from_icon_name("process-stop-symbolic")
        stop_btn.add_css_class("flat")
        stop_btn.set_tooltip_text("Interrompre (Ctrl+C)")
        stop_btn.connect("clicked", self._on_terminal_stop)
        clear_btn = Gtk.Button.new_from_icon_name("edit-clear-symbolic")
        clear_btn.add_css_class("flat")
        clear_btn.set_tooltip_text("Effacer le terminal")
        clear_btn.connect("clicked", self._on_terminal_clear)
        input_box.append(prompt_label)
        input_box.append(self.terminal_entry)
        input_box.append(send_btn)
        input_box.append(stop_btn)
        input_box.append(clear_btn)
        terminal_box.append(input_box)

        self.terminal_revealer.set_child(terminal_box)
        main_vbox.append(self.terminal_revealer)

        # ToastOverlay : permet les notifications légères natives Adwaita.
        self.toast_overlay = Adw.ToastOverlay()
        self.toast_overlay.set_child(main_vbox)
        return self.toast_overlay

    def _build_workspace(self):
        # Barre latérale redimensionnable : un Gtk.Paned horizontal fournit un
        # vrai séparateur + poignée drapable (visible), contrairement à
        # Adw.OverlaySplitView qui n'exposait aucune prise de redimensionnement.
        # La largeur est lue/mémorisée : on restaure la largeur précédente.
        saved = state.load()
        try:
            saved_width = int(saved.get("sidebar_width") or 0)
        except (TypeError, ValueError):
            saved_width = 0
        sidebar_width = min(400, max(220, saved_width or 300))
        self.workspace_split = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        self.workspace_split.add_css_class("perceptron-sidebar-split")
        self.workspace_split.set_start_child(self._sidebar_content)
        # Le contenu principal est lui-même un Paned : onglets à gauche,
        # panneau « Artefacts » à droite (repliable, largeur mémorisée).
        try:
            artifacts_width = int(saved.get("artifacts_width") or 0)
        except (TypeError, ValueError):
            artifacts_width = 0
        artifacts_width = min(520, max(260, artifacts_width or 340))
        self.artifacts_split = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        self.artifacts_split.set_start_child(self.tab_container)
        self.artifacts_split.set_end_child(self._build_artifacts_panel())
        self.artifacts_split.set_resize_start_child(True)
        self.artifacts_split.set_shrink_start_child(True)
        self.artifacts_split.set_shrink_end_child(False)
        self.artifacts_split.set_position(artifacts_width)
        self.artifacts_split.connect(
            "notify::position", self._on_artifacts_position_changed
        )
        self.workspace_split.set_end_child(self.artifacts_split)
        self.workspace_split.set_resize_start_child(False)
        self.workspace_split.set_shrink_start_child(False)
        self.workspace_split.set_position(sidebar_width)
        self.workspace_split.connect(
            "notify::position", self._on_sidebar_position_changed
        )
        self._sidebar_position = sidebar_width
        return self.workspace_split

    def _build_artifacts_panel(self):
        """Panneau latéral « Artefacts » (à droite) : vignettes des fichiers et
        images générés par les réponses de la session courante."""
        self.artifacts_heading = Adw.HeaderBar()
        self.artifacts_heading.set_title_widget(Adw.WindowTitle(title="Artefacts"))
        self.artifacts_heading.pack_end(Gtk.Button(
            icon_name="window-close-symbolic",
            tooltip_text="Fermer le panneau des artefacts",
            action_name="win.toggle-artifacts",
        ))
        self.artifacts_heading.pack_end(Gtk.Button(
            icon_name="view-refresh-symbolic",
            tooltip_text="Recharger les artefacts",
            action_name="win.reload-artifacts",
        ))
        self.artifacts_list = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL, spacing=4,
            margin_top=4, margin_bottom=4, margin_start=4, margin_end=4,
        )
        self.artifacts_scroller = Gtk.ScrolledWindow(vexpand=True)
        self.artifacts_scroller.set_policy(
            Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC
        )
        self.artifacts_scroller.set_child(self.artifacts_list)
        self.artifacts_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.artifacts_box.set_size_request(300, -1)
        self.artifacts_box.append(self.artifacts_heading)
        self.artifacts_box.append(self.artifacts_scroller)
        self.artifacts_box.set_visible(False)
        return self.artifacts_box

    def _on_artifacts_position_changed(self, paned, _pspec):
        width = int(paned.get_position())
        if width <= 0:
            return
        saved = state.load()
        saved["artifacts_width"] = width
        state.save(saved)

    def _on_sidebar_position_changed(self, paned, _pspec):
        width = int(paned.get_position())
        if width <= 0:
            return
        self._sidebar_position = width
        saved = state.load()
        saved["sidebar_width"] = width
        state.save(saved)

    def _build_menu(self):
        menu = Gio.Menu()
        sessions = Gio.Menu()
        sessions.append("Nouvelle session…", "win.new-session")
        sessions.append("Artefacts de la session", "win.toggle-artifacts")
        menu.append_section("Sessions", sessions)
        view = Gio.Menu()
        view.append("Plein écran", "win.fullscreen")
        view.append("Afficher ou masquer la liste des sessions", "win.toggle-sidebar")
        view.append("Agrandir le texte", "win.zoom-in")
        view.append("Réduire le texte", "win.zoom-out")
        view.append("Taille de texte par défaut", "win.zoom-reset")
        menu.append_section("Affichage", view)
        server_menu = Gio.Menu()
        server_menu.append("Reconnecter au serveur", "win.reconnect")
        server_menu.append("Quitter", "win.quit")
        menu.append_section("Serveur", server_menu)
        app_menu = Gio.Menu()
        app_menu.append("Préférences…", "win.preferences")
        app_menu.append("Mémoire (instructions globales)…", "win.memory")
        app_menu.append("Raccourcis clavier", "win.shortcuts")
        app_menu.append("À propos de Perceptron", "win.about")
        menu.append_section("Application", app_menu)
        return menu

    def _add_actions(self):
        actions = (
            ("new-session", lambda *_: self.new_session()),
            ("search", lambda *_: self._toggle_chat_search()),
            ("search-next", lambda *_: self._on_chat_search_next(None)),
            ("reload", lambda *_: self.refresh_sessions()),
            ("reconnect", lambda *_: self.connect_and_load()),
            ("toggle-sidebar", lambda *_: self.toggle_sidebar()),
            ("send-prompt", lambda *_: self.send_prompt()),
            ("send-queued-prompt", lambda *_: self.send_prompt("queue")),
            ("scroll-bottom", lambda *_: self._scroll_messages_to_end()),
            ("zoom-in", lambda *_: self._change_zoom(0.1)),
            ("zoom-out", lambda *_: self._change_zoom(-0.1)),
            ("zoom-reset", lambda *_: self._change_zoom(0, reset=True)),
            ("close-tab", lambda *_: self._close_current_tab()),
            ("next-tab", lambda *_: self.tab_view.select_next_page()),
            ("previous-tab", lambda *_: self.tab_view.select_previous_page()),
            ("interrupt-session", lambda *_: self.interrupt_session()),
            ("show-artifacts", lambda *_: self.show_artifacts()),
            ("toggle-artifacts", lambda *_: self.toggle_artifacts()),
            ("reload-artifacts", lambda *_: self.reload_artifacts()),
            ("toggle-terminal", lambda *_: self._toggle_terminal()),
            ("quit", lambda *_: self.close()),
            ("preferences", self._show_preferences),
            ("memory", self._show_memory),
            ("fullscreen", self.on_fullscreen),
            ("shortcuts", self.on_shortcuts),
            ("about", self.on_about),
        )
        for name, callback in actions:
            action = Gio.SimpleAction.new(name, None)
            action.connect("activate", callback)
            self.add_action(action)
        select_model = Gio.SimpleAction.new(
            "select-model", GLib.VariantType.new("i")
        )
        select_model.connect("activate", self._select_model_menu_item)
        self.add_action(select_model)
        new_from_stale = Gio.SimpleAction.new("new-from-stale-session", None)
        new_from_stale.connect(
            "activate",
            lambda *_: self._create_replacement_session(self._selected_session),
        )
        self.add_action(new_from_stale)
        delete = Gio.SimpleAction.new("delete-session", GLib.VariantType.new("s"))
        delete.connect("activate", self._confirm_delete_session)
        self.add_action(delete)
        rename = Gio.SimpleAction.new("rename-session", GLib.VariantType.new("s"))
        rename.connect("activate", self._rename_session)
        self.add_action(rename)
        for name, callback in (
            ("toggle-pin-session", self._toggle_pin_session),
            ("toggle-archive-session", self._toggle_archive_session),
            ("open-artifact-folder", self._open_artifact_folder),
            ("save-artifact", self._save_artifact),
            ("copy-text", self._copy_text_action),
            ("open-link", self._open_link_action),
            ("set-session-background", self._toggle_session_background),
        ):
            action = Gio.SimpleAction.new(name, GLib.VariantType.new("s"))
            action.connect("activate", callback)
            self.add_action(action)
        fork = Gio.SimpleAction.new("fork-message", GLib.VariantType.new("(ss)"))
        fork.connect("activate", self._fork_message)
        self.add_action(fork)
        retry_messages = Gio.SimpleAction.new(
            "retry-messages", GLib.VariantType.new("s")
        )
        retry_messages.connect(
            "activate",
            lambda _action, parameter: self._load_messages(
                parameter.get_string(), show_loading=True
            ),
        )
        self.add_action(retry_messages)

    def connect_and_load(self):
        if self._connecting:
            return
        self._connecting = True
        self.stack.set_visible_child_name("loading")
        opencode.connect(self.on_connected, self.server)

    def on_connected(self, success, error):
        if not success:
            self._connecting = False
            self.show_error(
                "Connexion à OpenCode impossible",
                error or "Vérifie que la commande « opencode » est disponible.",
            )
            return
        self._connecting = False
        self.stack.set_visible_child_name("workspace")
        self.window_title.set_subtitle("OpenCode connecté")
        self.server.start()
        journal.log("connecté : workspace affiché, chargement en cours")
        self.refresh_sessions()
        self.refresh_models()
        self.refresh_agents()
        self.refresh_active_sessions()

    def show_error(self, title, description):
        self.status_page.set_title(title)
        self.status_page.set_description(description)
        self.stack.set_visible_child_name("error")

    def refresh_sessions(self):
        if self._session_refresh_timeout:
            GLib.source_remove(self._session_refresh_timeout)
            self._session_refresh_timeout = 0
        self._session_fetch_generation += 1
        generation = self._session_fetch_generation
        self._session_fetch_results = {}
        self.session_load_message.remove_css_class("error")
        self.session_load_message.set_text("Chargement des sessions…")
        self.session_load_status.set_visible(True)
        self.server.list_sessions(
            lambda sessions, error: self._on_session_list_part(
                generation, "active", sessions, error
            ),
            archived=False,
        )
        self.server.list_sessions(
            lambda sessions, error: self._on_session_list_part(
                generation, "archived", sessions, error
            ),
            archived=True,
        )

    def _on_session_list_part(self, generation, key, sessions, error):
        if generation != self._session_fetch_generation:
            return
        self._session_fetch_results[key] = (sessions, error)
        if len(self._session_fetch_results) < 2:
            return
        errors = [error for _sessions, error in self._session_fetch_results.values() if error]
        if errors:
            self._on_sessions_loaded(None, errors[0])
            return
        combined = []
        for value, _error in self._session_fetch_results.values():
            if isinstance(value, list):
                combined.extend(value)
        self._on_sessions_loaded(combined, None)

    def _on_sessions_loaded(self, sessions, error):
        if error:
            self.session_load_message.add_css_class("error")
            self.session_load_message.set_text(
                "Impossible de charger les sessions : " + error
            )
            self.session_load_status.set_visible(True)
            return
        self.session_load_status.set_visible(False)
        self._sessions = self._index_sessions(sessions)
        journal.log("sessions chargées : %d (visible=%d)"
                    % (len(sessions), sum(
                        1 for s in self._sessions.values()
                        if (self._show_subagents or not s.get("parentID"))
                        and (self._show_archived or not s.get("time", {}).get("archived"))
                    )))
        self._refresh_session_rows()
        if (
            not self._selected_session
            and self._last_session_id
            and self._last_session_id in self._sessions
        ):
            self.show_session(self._last_session_id)
        if self._selected_session and self._selected_session not in self._sessions:
            self._mark_session_stale(
                self._selected_session,
                "Cette session n’existe plus sur le serveur OpenCode connecté.",
            )

    def _refresh_session_rows(self):
        selected = self._selected_session
        visible_sessions = [
            session for session in self._sessions.values()
            if (self._show_subagents or not session.get("parentID"))
            and (self._show_archived or not session.get("time", {}).get("archived"))
        ]
        if self._search_query:
            title_matches = {
                session["id"] for session in visible_sessions
                if self._matches_search(session, self._search_query)
            }
            visible_sessions = [
                session for session in visible_sessions
                if session["id"] in title_matches
                or session["id"] in self._search_content_ids
            ]
        ordered_sessions = sorted(
            visible_sessions,
            key=lambda item: (
                item["id"] not in self._pinned_sessions,
                bool(item.get("time", {}).get("archived")),
                -(item.get("time", {}).get("updated")
                  if isinstance(item.get("time", {}).get("updated"), (int, float))
                  else 0),
            ),
        )
        signature = tuple(
            (
                session["id"],
                session.get("title"),
                (session.get("time") or {}).get("created"),
                bool((session.get("time") or {}).get("archived")),
                session.get("parentID"),
                session.get("agent"),
                session["id"] in self._pinned_sessions,
                session["id"] in self._active_sessions,
            )
            for session in ordered_sessions
        )
        if signature == self._session_rows_signature:
            return
        self._session_rows_signature = signature
        self._updating_sessions = True
        child = self.session_list.get_first_child()
        while child:
            next_child = child.get_next_sibling()
            self.session_list.remove(child)
            child = next_child
        for session in ordered_sessions:
            action_row = Adw.ActionRow()
            action_row.set_activatable(True)
            action_row.session_id = session["id"]
            title = session.get("title") or "Nouvelle session"
            page = self._session_tabs.get(session["id"])
            if page:
                page.set_title(title)
            details = []
            if session.get("id") in self._active_sessions:
                details.append("En cours")
            created = self._format_session_date(
                session.get("time", {}).get("created")
            )
            if created:
                details.append(created)
            parent = self._session_subtitle(session, self._sessions)
            if parent:
                details.append(parent)
            if session.get("time", {}).get("archived"):
                details.insert(0, "Archivée")
            subtitle = " · ".join(filter(None, details))
            action_row.set_title(title)
            if session["id"] in self._pinned_sessions:
                action_row.add_prefix(Gtk.Image(icon_name="starred-symbolic"))
            if subtitle:
                action_row.set_subtitle(subtitle)
            actions = Gio.Menu()
            pin_item = Gio.MenuItem.new(
                "Désépingler" if session["id"] in self._pinned_sessions
                else "Épingler", None
            )
            pin_item.set_action_and_target_value(
                "win.toggle-pin-session", GLib.Variant.new_string(session["id"])
            )
            actions.append_item(pin_item)
            archive_item = Gio.MenuItem.new(
                "Restaurer" if session.get("time", {}).get("archived")
                else "Archiver", None
            )
            archive_item.set_action_and_target_value(
                "win.toggle-archive-session",
                GLib.Variant.new_string(session["id"]),
            )
            actions.append_item(archive_item)
            rename_item = Gio.MenuItem.new("Renommer la session…", None)
            rename_item.set_action_and_target_value(
                "win.rename-session", GLib.Variant.new_string(session["id"])
            )
            actions.append_item(rename_item)
            delete_item = Gio.MenuItem.new("Supprimer la session…", None)
            delete_item.set_action_and_target_value(
                "win.delete-session", GLib.Variant.new_string(session["id"])
            )
            actions.append_item(delete_item)
            row_menu = Gtk.MenuButton(
                icon_name="view-more-symbolic",
                tooltip_text="Actions de session",
                menu_model=actions,
                valign=Gtk.Align.CENTER,
            )
            action_row.add_suffix(row_menu)
            middle_click = Gtk.GestureClick()
            middle_click.set_button(Gdk.BUTTON_MIDDLE)
            middle_click.connect(
                "pressed", self._on_session_middle_click, session["id"]
            )
            action_row.add_controller(middle_click)
            self.session_list.append(action_row)
            if session["id"] == selected:
                self.session_list.select_row(action_row)
        self._updating_sessions = False
        if not self._sessions and not self._selected_session:
            self.content_stack.set_visible_child_name("empty")

    def _schedule_session_refresh(self):
        if self._session_refresh_timeout:
            return
        self._session_refresh_timeout = GLib.timeout_add(
            180, self._run_scheduled_session_refresh
        )

    def _run_scheduled_session_refresh(self):
        self._session_refresh_timeout = 0
        self.refresh_sessions()
        return GLib.SOURCE_REMOVE

    @staticmethod
    def _index_sessions(sessions):
        indexed = {}
        for session in sessions if isinstance(sessions, list) else []:
            if isinstance(session, dict) and session.get("id"):
                indexed.setdefault(session["id"], session)
        return indexed

    @staticmethod
    def _session_subtitle(session, sessions):
        parent_id = session.get("parentID")
        if not parent_id:
            return ""
        parent = sessions.get(parent_id)
        if parent and parent.get("title"):
            return "Sous-agent de « %s »" % parent["title"]
        return "Sous-agent"

    def _on_row_selected(self, _listbox, row):
        if row is not None and not self._updating_sessions and hasattr(row, "session_id"):
            self.show_session(row.session_id)

    def _on_session_middle_click(
        self, gesture, _presses, _x, _y, session_id
    ):
        gesture.set_state(Gtk.EventSequenceState.CLAIMED)
        self.show_session(session_id, force_new=True)

    def _on_subagents_toggled(self, switch, _pspec):
        self._show_subagents = switch.get_active()
        saved = state.load()
        saved["show_subagents"] = self._show_subagents
        state.save(saved)
        if self._sessions:
            self._refresh_session_rows()

    def _on_archived_toggled(self, switch, _pspec):
        self._show_archived = switch.get_active()
        saved = state.load()
        saved["show_archived"] = self._show_archived
        state.save(saved)
        self.refresh_sessions()

    def _on_session_search_changed(self, entry):
        self._search_generation += 1
        generation = self._search_generation
        self._search_query = entry.get_text().strip()
        self._search_content_ids.clear()
        self._search_queue = []
        if not self._search_query:
            self.search_status.set_visible(False)
            self._refresh_session_rows()
            return
        self.search_status.set_text("Recherche du contenu…")
        self.search_status.set_visible(True)
        self._refresh_session_rows()
        self._search_queue = list(self._sessions)
        self._search_errors = 0
        self._search_scanned = 0
        self._search_total = len(self._search_queue)
        self._search_pending = 0
        self._pump_search(generation, self._search_query)

    def _on_session_search_activate(self, _entry):
        if self._search_query:
            self._search_generation += 1
            self._search_queue = list(self._sessions)
            self._search_content_ids.clear()
            self._search_errors = 0
            self._search_scanned = 0
            self._search_total = len(self._search_queue)
            self._search_pending = 0
            self._refresh_session_rows()
            self._pump_search(self._search_generation, self._search_query)

    def _scan_next_session(self, generation, query):
        self._pump_search(generation, query)

    def _pump_search(self, generation, query):
        """Maintient un petit bassin de lectures parallèles (moins latent)."""
        if generation != self._search_generation:
            return
        # Démarre autant de lectures que possible en parallèle.
        while self._search_pending < 5 and self._search_queue:
            session_id = self._search_queue.pop(0)
            self._search_pending += 1
            self.server.get_messages(
                session_id,
                lambda messages, error, sid=session_id:
                    self._on_search_messages(generation, query, sid, messages, error),
            )
        self._update_search_status()

    def _update_search_status(self):
        if not self._search_query:
            return
        scanned = min(self._search_scanned, self._search_total)
        done = self._search_pending == 0 and not self._search_queue
        if done:
            self.search_status.set_text(
                "%d session(s) contenant le terme%s" % (
                    len(self._search_content_ids),
                    " · certaines conversations n’ont pas pu être lues"
                    if self._search_errors else "",
                )
            )
        else:
            self.search_status.set_text(
                "Recherche… %d/%d" % (scanned, self._search_total)
            )

    def _on_search_messages(self, generation, query, session_id, messages, error):
        if generation != self._search_generation:
            return
        self._search_pending = max(0, self._search_pending - 1)
        self._search_scanned += 1
        if error:
            self._search_errors += 1
        elif self._matches_search({}, query, messages):
            self._search_content_ids.add(session_id)
        self._refresh_session_rows()
        self._pump_search(generation, query)

    def refresh_agents(self):
        self.server.list_agents(self._on_agents_loaded)

    def _on_agents_loaded(self, agents, error):
        if error:
            self.agent_dropdown.set_model(Gtk.StringList.new(["Agents indisponibles"]))
            self.agent_dropdown.set_sensitive(False)
            self.agent_dropdown.set_tooltip_text("Impossible de charger les agents : " + error)
            return
        self._agents = [
            agent for agent in agents if isinstance(agent, dict)
            and agent.get("id") and agent.get("name")
        ] if isinstance(agents, list) else []
        choices = self._primary_agents(self._agents)
        self._visible_agents = choices
        self._loading_agent = True
        self.agent_dropdown.set_model(Gtk.StringList.new(
            [agent["name"] for agent in choices] or ["Aucun agent disponible"]
        ))
        self.agent_dropdown.set_sensitive(bool(choices))
        self._select_agent(self._current_agent)
        self._loading_agent = False
        self._update_mode_buttons()

    @staticmethod
    def _primary_agents(agents):
        return [
            agent for agent in agents if isinstance(agent, dict)
            and agent.get("id")
            and agent.get("mode") in ("primary", "all")
            and not agent.get("hidden")
        ] if isinstance(agents, list) else []

    def _agent_by_id(self, agent_id):
        return next((agent for agent in self._agents if agent.get("id") == agent_id), None)

    def _select_agent(self, agent_id):
        for index, agent in enumerate(getattr(self, "_visible_agents", [])):
            if agent.get("id") == agent_id:
                self.agent_dropdown.set_selected(index)
                break
        else:
            if getattr(self, "_visible_agents", []):
                self.agent_dropdown.set_selected(Gtk.INVALID_LIST_POSITION)
        self._update_mode_buttons(agent_id)

    def _update_mode_buttons(self, agent_id=None):
        if not hasattr(self, "build_mode_button"):
            return
        if agent_id is None:
            agent_id = self._current_agent
        self._loading_agent = True
        self.build_mode_button.set_active(agent_id == "build")
        self.plan_mode_button.set_active(agent_id == "plan")
        has_session = bool(self._selected_session)
        self.build_mode_button.set_sensitive(
            has_session and self._agent_by_id("build") is not None
        )
        self.plan_mode_button.set_sensitive(
            has_session and self._agent_by_id("plan") is not None
        )
        self._loading_agent = False

    def _on_mode_button_toggled(self, button, agent_id):
        if self._loading_agent or not button.get_active():
            return
        if not self._selected_session or self._agent_by_id(agent_id) is None:
            self._select_agent(self._current_agent)
            return
        self._loading_agent = True
        self._select_agent(agent_id)
        self._loading_agent = False
        self._on_agent_selected(self.agent_dropdown, None)

    def _on_agent_selected(self, dropdown, _pspec):
        index = dropdown.get_selected()
        agents = getattr(self, "_visible_agents", [])
        if self._loading_agent or index >= len(agents) or not self._selected_session:
            return
        agent_id = agents[index]["id"]
        if agent_id == self._current_agent:
            return
        session_id = self._selected_session
        self._begin_context_switch(session_id)
        self.server.switch_agent(
            session_id,
            agent_id,
            lambda _result, error, selected=agent_id, session=session_id:
                self._on_agent_switched(session, selected, error),
        )

    def _on_agent_switched(self, session_id, agent_id, error):
        if error:
            self._show_notice("Impossible de changer d’agent : " + error)
            if self._selected_session == session_id:
                self._loading_agent = True
                self._select_agent(self._current_agent)
                self._loading_agent = False
        elif self._selected_session == session_id:
            self._current_agent = agent_id
            self._select_agent(agent_id)
        self._finish_context_switch(session_id, error)

    def refresh_active_sessions(self):
        self.server.list_active_sessions(self._on_active_sessions_loaded)

    def _on_active_sessions_loaded(self, active, error):
        if error:
            return
        self._active_sessions = self._active_session_ids(active)
        self._update_interrupt_button()
        self._update_generation_status()
        if self._sessions:
            self._refresh_session_rows()

    @staticmethod
    def _active_session_ids(active):
        if isinstance(active, dict):
            return set(active)
        if isinstance(active, list):
            return {
                item.get("sessionID") or item.get("id")
                for item in active
                if isinstance(item, dict)
                and isinstance(item.get("sessionID") or item.get("id"), str)
            }
        return set()

    def _update_generation_status(self):
        generating = self._selected_session in self._active_sessions
        self.generation_status.set_visible(generating)
        if hasattr(self, "interrupt_button"):
            self.interrupt_button.set_visible(generating)
        if generating:
            self.generation_spinner.start()
        else:
            self.generation_spinner.stop()

    def _update_interrupt_button(self):
        self.interrupt_button.set_sensitive(
            bool(self._selected_session in self._active_sessions)
        )
        self._update_generation_status()

    def interrupt_session(self):
        if not self._selected_session:
            return
        session_id = self._selected_session
        self.server.interrupt_session(
            session_id,
            lambda result, error: self._on_interrupt_result(session_id, result, error),
        )

    def _on_interrupt_result(self, session_id, result, error):
        if error:
            self._show_notice("Impossible d’arrêter la génération : " + error)
            return
        if isinstance(result, dict) and result.get("interrupted") is False:
            self._show_notice("Aucune génération active dans cette session.")
        self.refresh_active_sessions()

    def _ensure_session_tab(self, session_id, title, force_new=False):
        page = self._session_tabs.get(session_id)
        if page is not None and not force_new:
            return page
        if page is None:
            page = next(
                (
                    candidate for index in range(self.tab_view.get_n_pages())
                    if (candidate := self.tab_view.get_nth_page(index)) is not None
                    and self._page_sessions.get(candidate.get_child()) == session_id
                ),
                None,
            )
            if page is not None and not force_new:
                self._session_tabs[session_id] = page
                return page
        self._tab_counter += 1
        page_content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        page = self.tab_view.append(page_content)
        page.set_title(title or "Session")
        page.set_tooltip(session_id)
        self._page_sessions[page_content] = session_id
        self._session_tabs[session_id] = page
        return page

    def _on_tab_view_changed(self, tab_view, _pspec):
        page = tab_view.get_selected_page()
        if page is None:
            return
        session_id = self._page_sessions.get(page.get_child())
        if session_id == self._selected_session:
            return
        self._save_current_draft()
        child = page.get_child()
        parent = self.content_stack.get_parent()
        if parent is not None:
            parent.remove(self.content_stack)
        child.append(self.content_stack)
        if session_id is None:
            self._selected_session = None
            self.content_stack.set_visible_child_name("empty")
            self.window_title.set_subtitle("OpenCode connecté")
            self._current_model = None
            self._current_agent = None
            self.interrupt_button.set_sensitive(False)
            self._update_mode_buttons()
            self._update_send_sensitivity()
            return
        self._selected_session = session_id
        self.content_stack.set_visible_child_name("conversation")
        page.set_needs_attention(False)
        if self._banner_session_id == session_id:
            self.activity_banner.set_revealed(False)
            self._banner_session_id = None
        session = self._sessions.get(session_id, {})
        self.window_title.set_subtitle(session.get("title") or "Session OpenCode")
        self._current_agent = session.get("agent")
        self._loading_agent = True
        self._select_agent(self._current_agent)
        self._loading_agent = False
        self._current_model = None
        model_ref = session.get("model") or self._default_model
        if model_ref:
            self._set_model_ref(model_ref)
        else:
            self.model_label.set_text("Choisir un modèle")
            self.variant_dropdown.set_model(Gtk.StringList.new(["Défaut"]))
            self.variant_dropdown.set_sensitive(False)
        self._update_interrupt_button()
        draft = self._prompt_drafts.get(session_id, {})
        self.prompt.get_buffer().set_text(draft.get("text", ""))
        self._prompt_files = list(draft.get("files", []))
        self._editing_message_id = draft.get("editing_message_id")
        self._refresh_prompt_attachments()
        self._update_send_sensitivity()
        self.server.get_session(
            session_id,
            lambda info, error: self._on_session_details_loaded(
                session_id, info, error
            ),
            force_refresh=True,
        )
        self._load_messages(session_id, show_loading=True)

    def _save_current_draft(self):
        if not self._selected_session:
            return
        buffer = self.prompt.get_buffer()
        start, end = buffer.get_bounds()
        self._prompt_drafts[self._selected_session] = {
            "text": buffer.get_text(start, end, False),
            "files": list(self._prompt_files),
            "editing_message_id": self._editing_message_id,
        }

    def _on_tab_close_page(self, tab_view, page):
        if page is self._empty_tab:
            return True
        session_id = self._page_sessions.pop(page.get_child(), None)
        if session_id and self._session_tabs.get(session_id) is page:
            self._session_tabs[session_id] = next(
                (
                    candidate
                    for index in range(self.tab_view.get_n_pages())
                    if (candidate := self.tab_view.get_nth_page(index)) is not page
                    and self._page_sessions.get(candidate.get_child()) == session_id
                ),
                None,
            )
            if self._session_tabs[session_id] is None:
                self._session_tabs.pop(session_id, None)
        page_child = page.get_child()
        if self.content_stack.get_parent() is page_child:
            page_child.remove(self.content_stack)
            empty_child = self._empty_tab.get_child()
            empty_child.append(self.content_stack)
        tab_view.close_page_finish(page, True)
        return True

    def _close_current_tab(self):
        page = self.tab_view.get_selected_page()
        if page is not None and page is not self._empty_tab:
            self.tab_view.close_page(page)

    def mark_session_done(self, session_id):
        """Signale sur l'onglet qu'une session en arrière-plan a fini de
        répondre (Perceptron au premier plan). Point d'attention sur l'onglet
        tant que la session n'est pas rouverte, plus un bandeau « Voir »."""
        page = self._session_tabs.get(session_id)
        if page is None:
            return
        if session_id == self._selected_session:
            # La session est déjà affichée : pas besoin d'attirer l'oeil.
            page.set_needs_attention(False)
            return
        page.set_needs_attention(True)
        session = self._sessions.get(session_id, {})
        title = session.get("title") or "Une session"
        self._banner_session_id = session_id
        self.activity_banner.set_title("« %s » a fini de répondre" % title)
        self.activity_banner.set_revealed(True)

    def _on_activity_banner_clicked(self, _banner):
        session_id = self._banner_session_id
        self.activity_banner.set_revealed(False)
        self._banner_session_id = None
        if session_id:
            self.show_session(session_id)

    def show_session(self, session_id, force_new=False):
        self.present()
        session = self._sessions.get(session_id, {})
        page = self._ensure_session_tab(
            session_id, session.get("title"), force_new=force_new
        )
        if self.tab_view.get_selected_page() is page:
            self._on_tab_view_changed(self.tab_view, None)
            if self._selected_session == session_id:
                self._load_messages(session_id)
        else:
            self.tab_view.set_selected_page(page)

    def _on_session_details_loaded(self, session_id, info, error=None):
        if error and self._is_session_not_found_error(error):
            self._invalid_sessions.add(session_id)
            self._mark_session_stale(session_id, error)
            self.refresh_sessions()
            return
        if session_id != self._selected_session or not isinstance(info, dict):
            return
        self._invalid_sessions.discard(session_id)
        self._sessions[session_id] = info
        self._set_model_ref(info.get("model"))
        self._current_agent = info.get("agent")
        self._loading_agent = True
        self._select_agent(self._current_agent)
        self._loading_agent = False
    def refresh_models(self):
        self._models_loaded = False
        self._config_loaded = False
        self.server.list_models(self._on_models_loaded)
        self.server.list_providers(self._on_providers_loaded)
        self.server.get_config(self._on_model_config_loaded)
        self.server.get_default_model(self._on_default_model_loaded)

    def _on_models_loaded(self, models, error):
        if error:
            self._all_models = []
            self._models_loaded = True
            self.model_label.set_text("Modèles indisponibles")
            self.model_dropdown.set_sensitive(False)
            self.model_dropdown.set_tooltip_text("Impossible de charger les modèles : " + error)
            self.variant_dropdown.set_sensitive(False)
            return
        self._all_models = []
        for model in models if isinstance(models, list) else []:
            if not isinstance(model, dict) or not model.get("id") or not model.get("providerID"):
                continue
            variants = [
                variant.get("id")
                for variant in model.get("variants", [])
                if isinstance(variant, dict) and variant.get("id")
            ]
            self._all_models.append({
                "id": model["id"],
                "providerID": model["providerID"],
                "name": model.get("name") or model["id"],
                "variants": variants,
                "enabled": model.get("enabled", True),
            })
        self._models_loaded = True
        self._refresh_available_models()

    def _on_model_config_loaded(self, config_files, error):
        self._configured_provider_models = (
            self._configured_model_ids(config_files) if error is None else None
        )
        self._config_loaded = True
        self._refresh_available_models()

    @staticmethod
    def _configured_model_ids(config_files):
        if isinstance(config_files, dict):
            config = config_files
        else:
            config = next(
                (
                    item.get("info")
                    for item in config_files if isinstance(item, dict)
                    and item.get("type") == "document"
                    and isinstance(item.get("info"), dict)
                ),
                None,
            ) if isinstance(config_files, list) else None
        if not isinstance(config, dict):
            return None
        providers = config.get("providers")
        if not isinstance(providers, dict):
            return None
        configured = {}
        for provider_id, provider in providers.items():
            if not isinstance(provider, dict):
                continue
            models = provider.get("models")
            if isinstance(models, dict) and models:
                configured[provider_id] = set(models)
            else:
                configured[provider_id] = None
        return configured

    @staticmethod
    def _filter_available_models(models, configured_provider_models, active_provider_ids):
        result = []
        for model in models:
            if model.get("enabled") is False:
                continue
            provider_id = model.get("providerID")
            if active_provider_ids is not None and provider_id not in active_provider_ids:
                continue
            if configured_provider_models is not None and provider_id in configured_provider_models:
                configured_ids = configured_provider_models[provider_id]
                if configured_ids is not None and model.get("id") not in configured_ids:
                    continue
            result.append(model)
        return result

    def _refresh_available_models(self):
        if not self._models_loaded or not self._config_loaded:
            return
        self._models = self._filter_available_models(
            self._all_models,
            self._configured_provider_models,
            self._active_provider_ids,
        )
        self._loading_model = True
        self._rebuild_model_menu()
        target = self._current_model or self._default_model
        if target:
            self._set_model_ref(target)
        else:
            self.variant_dropdown.set_sensitive(False)
        self._loading_model = False

    def _on_providers_loaded(self, providers, error):
        if error:
            return
        self._providers = {
            provider["id"]: provider.get("name") or provider["id"]
            for provider in providers if isinstance(provider, dict) and provider.get("id")
        } if isinstance(providers, list) else {}
        self._active_provider_ids = {
            provider["id"] for provider in providers
            if isinstance(provider, dict) and provider.get("id")
            and provider.get("activation") != "disabled"
        } if isinstance(providers, list) else None
        self._refresh_available_models()
        self._rebuild_model_menu()

    @staticmethod
    def _group_models_by_provider(models, providers):
        groups = {}
        for model in models:
            groups.setdefault(model["providerID"], []).append(model)
        return [
            (
                provider_id,
                providers.get(provider_id) or provider_id,
                sorted(items, key=lambda model: model["name"].casefold()),
            )
            for provider_id, items in sorted(
                groups.items(),
                key=lambda pair: (providers.get(pair[0]) or pair[0]).casefold(),
            )
        ]

    def _rebuild_model_menu(self):
        menu = Gio.Menu()
        groups = self._group_models_by_provider(self._models, self._providers)
        for _provider_id, provider_name, models in groups:
            section = Gio.Menu()
            for model in models:
                index = self._models.index(model)
                item = Gio.MenuItem.new(model["name"], None)
                item.set_action_and_target_value(
                    "win.select-model", GLib.Variant.new_int32(index)
                )
                section.append_item(item)
            menu.append_section(provider_name, section)
        self.model_dropdown.set_menu_model(menu)
        self.model_dropdown.set_sensitive(bool(self._models))
        if not self._models:
            self.model_label.set_text("Aucun modèle disponible")

    def _select_model_menu_item(self, _action, parameter):
        index = parameter.get_int32()
        if index < 0 or index >= len(self._models):
            return
        self._refresh_variant_choices(index)
        self._set_model_button_label(index)
        self._apply_model_selection(index)

    def _set_model_button_label(self, index):
        if 0 <= index < len(self._models):
            model = self._models[index]
            provider = self._providers.get(model["providerID"], model["providerID"])
            self.model_label.set_text(model["name"])
            self.model_dropdown.set_tooltip_text(
                "%s — %s" % (model["name"], provider)
            )
        elif self._current_model:
            model_id = self._current_model["id"]
            provider_id = self._current_model["providerID"]
            provider = self._providers.get(provider_id, provider_id)
            self.model_label.set_text(model_id)
            self.model_dropdown.set_tooltip_text(
                "%s — %s (modèle de la session non listé dans la configuration)"
                % (model_id, provider)
            )

    def _on_default_model_loaded(self, model, error):
        if error:
            self.model_dropdown.set_tooltip_text("Modèle par défaut indisponible : " + error)
            return
        self._default_model = self._model_ref(model)
        if self._current_model is None:
            self._set_model_ref(self._default_model)

    @staticmethod
    def _matches_search(session, query, messages=None):
        needle = query.casefold()
        if needle in (session.get("title") or "").casefold():
            return True
        return any(
            needle in MainWindow._message_text(message).casefold()
            for message in messages if isinstance(message, dict)
        ) if isinstance(messages, list) else False

    @staticmethod
    def _model_ref(model):
        if not isinstance(model, dict) or not model.get("id") or not model.get("providerID"):
            return None
        ref = {
            "id": model["id"],
            "providerID": model["providerID"],
        }
        if model.get("variant"):
            ref["variant"] = model["variant"]
        return ref

    def _model_index(self, model):
        if not model:
            return Gtk.INVALID_LIST_POSITION
        for index, candidate in enumerate(self._models):
            if (
                candidate["id"] == model.get("id")
                and candidate["providerID"] == model.get("providerID")
            ):
                return index
        return Gtk.INVALID_LIST_POSITION

    def _set_model_ref(self, model):
        ref = self._model_ref(model)
        if ref is None:
            return
        self._current_model = ref
        index = self._model_index(ref)
        self._loading_model = True
        self._set_model_button_label(index)
        self._refresh_variant_choices(index, ref.get("variant"))
        self._loading_model = False

    def _refresh_variant_choices(self, model_index, selected_variant=None):
        if model_index >= len(self._models) or model_index < 0:
            self._loading_variant = True
            self.variant_dropdown.set_model(Gtk.StringList.new(["Défaut"]))
            self.variant_dropdown.set_sensitive(False)
            self._loading_variant = False
            return
        variants = self._models[model_index]["variants"]
        labels = ["Défaut"] + [
            self._variant_label(variant) for variant in variants
        ]
        self._loading_variant = True
        self.variant_dropdown.set_model(Gtk.StringList.new(labels))
        self.variant_dropdown.set_sensitive(bool(variants))
        selected_index = (
            variants.index(selected_variant) + 1
            if selected_variant in variants else 0
        )
        self.variant_dropdown.set_selected(selected_index)
        self._loading_variant = False

    @staticmethod
    def _variant_label(variant):
        labels = {
            "none": "Aucun",
            "minimal": "Minimal",
            "low": "Faible",
            "medium": "Moyen",
            "high": "Élevé",
            "xhigh": "Très élevé (Xhigh)",
            "max": "Maximum",
        }
        return labels.get(variant, variant)

    def _on_variant_selected(self, dropdown, _pspec):
        if self._loading_variant or self._loading_model:
            return
        self._apply_model_selection(self._model_index(self._current_model))

    def _apply_model_selection(self, index):
        if index >= len(self._models) or index < 0 or not self._selected_session:
            return
        model = self._models[index]
        variant_index = self.variant_dropdown.get_selected()
        variant = model["variants"][variant_index - 1] if variant_index > 0 else None
        model_ref = {"id": model["id"], "providerID": model["providerID"]}
        if variant:
            model_ref["variant"] = variant
        if model_ref == self._current_model:
            return
        session_id = self._selected_session
        self._begin_context_switch(session_id)
        self.server.switch_model(
            session_id,
            model_ref,
            lambda _result, error, selected=model_ref, session=session_id:
                self._on_model_switched(session, selected, error),
        )

    def _on_model_switched(self, session_id, model, error):
        if error:
            self._show_notice("Impossible de changer de modèle : " + error)
            if self._selected_session == session_id:
                self._set_model_ref(self._current_model or self._default_model)
        elif self._selected_session == session_id:
            self._current_model = model
        self._finish_context_switch(session_id, error)

    def _begin_context_switch(self, session_id):
        state = self._pending_context_switches.setdefault(
            session_id, {"count": 0, "error": None}
        )
        state["count"] += 1
        self._update_send_sensitivity()

    def _finish_context_switch(self, session_id, error):
        state = self._pending_context_switches.get(session_id)
        if state is None:
            return
        if error and state["error"] is None:
            state["error"] = error
        state["count"] -= 1
        if state["count"] > 0:
            return
        state = self._pending_context_switches.pop(session_id)
        queued = self._queued_prompt
        if queued and queued["session_id"] == session_id:
            self._queued_prompt = None
            if state["error"]:
                self._show_notice(
                    "Message conservé : le changement de modèle ou d’agent a échoué."
                )
            else:
                self._start_prompt(
                    session_id,
                    queued["text"],
                    queued["delivery"],
                    queued["files"],
                    queued["editing_message_id"],
                )
        self._update_send_sensitivity()

    def _update_send_sensitivity(self):
        if not hasattr(self, "send_button"):
            return
        pending = self._selected_session in self._pending_context_switches
        self.send_button.set_sensitive(not self._sending_prompt and not pending)

    def _load_messages(self, session_id, show_loading=False):
        if show_loading and session_id == self._selected_session:
            self._show_messages_loading()
        self.server.get_messages(
            session_id,
            lambda messages, error: (
                self._on_messages_loaded(messages, error, session_id)
                if session_id == self._selected_session else None
            ),
        )

    def _show_messages_loading(self):
        while self.message_box.get_first_child():
            self.message_box.remove(self.message_box.get_first_child())
        while self.bookmark_box.get_first_child():
            self.bookmark_box.remove(self.bookmark_box.get_first_child())
        self.bookmark_scroller.set_visible(False)
        page = Adw.StatusPage(
            icon_name="content-loading-symbolic",
            title="Chargement des messages…",
            vexpand=True,
            hexpand=True,
        )
        self.message_box.append(page)

    def _show_messages_error(self, session_id, error):
        while self.message_box.get_first_child():
            self.message_box.remove(self.message_box.get_first_child())
        page = Adw.StatusPage(
            icon_name="network-error-symbolic",
            title="Impossible de charger les messages",
            description=error,
        )
        retry = Gtk.Button(
            label="Réessayer",
            action_name="win.retry-messages",
            action_target=GLib.Variant.new_string(session_id),
        )
        retry.add_css_class("suggested-action")
        retry.add_css_class("pill")
        page.set_child(retry)
        self.message_box.append(page)

    @staticmethod
    def _is_session_not_found_error(error):
        return (
            isinstance(error, str)
            and "HTTP 404" in error
            and "Session not found" in error
        )

    def _mark_session_stale(self, session_id, error):
        self._invalid_sessions.add(session_id)
        if session_id != self._selected_session:
            return
        while self.message_box.get_first_child():
            self.message_box.remove(self.message_box.get_first_child())
        while self.bookmark_box.get_first_child():
            self.bookmark_box.remove(self.bookmark_box.get_first_child())
        self.bookmark_scroller.set_visible(False)
        page = Adw.StatusPage(
            icon_name="dialog-warning-symbolic",
            title="Session introuvable",
            description=(
                "OpenCode ne connaît plus cette session sur le serveur connecté. "
                "Le brouillon reste disponible ci-dessous. " + error
            ),
        )
        self.window_title.set_subtitle("Session introuvable")
        recover = Gtk.Button(
            label="Créer une session de remplacement",
            action_name="win.new-from-stale-session",
        )
        recover.add_css_class("suggested-action")
        recover.add_css_class("pill")
        page.set_child(recover)
        self.message_box.append(page)
        self.artifacts_button.set_sensitive(False)

    def _show_stale_prompt_recovery(self, session_id, text, files, delivery, error):
        dialog = Adw.AlertDialog(
            heading="Cette session n’existe plus",
            body=(
                error + "\n\nLe message et ses pièces jointes sont conservés. "
                "Créer une nouvelle session avec le même modèle et agent, puis "
                "renvoyer ce message ?"
            ),
        )
        dialog.add_response("keep", "Garder le brouillon")
        dialog.add_response("new-session", "Créer et renvoyer")
        dialog.set_response_appearance(
            "new-session", Adw.ResponseAppearance.SUGGESTED
        )
        dialog.set_default_response("keep")
        dialog.connect(
            "response",
            self._on_stale_prompt_recovery_response,
            session_id,
            text,
            list(files),
            delivery,
        )
        dialog.present(self)

    def _on_stale_prompt_recovery_response(
        self, _dialog, response, session_id, text, files, delivery
    ):
        if response == "new-session":
            self._create_replacement_session(
                session_id, text, files, delivery
            )

    def _create_replacement_session(
        self, old_session_id, text=None, files=None, delivery=None
    ):
        if old_session_id == self._selected_session:
            self._save_current_draft()
        draft = dict(self._prompt_drafts.get(old_session_id, {}))
        if text is not None:
            draft.update({
                "text": text,
                "files": list(files or []),
                "editing_message_id": None,
            })
        else:
            draft.setdefault("text", "")
            draft.setdefault("files", [])
            draft["editing_message_id"] = None
        model = self._current_model or self._default_model
        target_model = dict(model) if model else None
        target_agent = self._current_agent
        self.server.create_session(
            lambda session, error: self._on_replacement_session_created(
                session,
                error,
                draft,
                target_model,
                target_agent,
                delivery,
                text is not None,
            )
        )

    def _on_replacement_session_created(
        self, session, error, draft, target_model, target_agent, delivery, resend
    ):
        if error or not isinstance(session, dict) or not session.get("id"):
            self._show_notice(
                "Impossible de créer une nouvelle session : "
                + (error or "OpenCode n’a pas renvoyé son identifiant.")
            )
            return
        session_id = session["id"]
        self._invalid_sessions.discard(session_id)
        self._sessions[session_id] = session
        self._prompt_drafts[session_id] = draft
        self.refresh_sessions()
        self.show_session(session_id)

        requests = []
        current_model = self._model_ref(session.get("model"))
        if target_model and current_model != target_model:
            requests.append(("model", target_model))
        if target_agent and target_agent != session.get("agent"):
            if self._agent_by_id(target_agent) is None:
                self._show_notice(
                    "La nouvelle session a été créée, mais l’agent demandé "
                    "n’est plus disponible. Le brouillon a été conservé."
                )
                return
            requests.append(("agent", target_agent))
        if not requests:
            if resend:
                self._start_prompt(
                    session_id, draft["text"], delivery, draft["files"], None
                )
            return

        state = {"remaining": len(requests), "error": None}
        for kind, value in requests:
            self._begin_context_switch(session_id)
            if kind == "model":
                self.server.switch_model(
                    session_id,
                    value,
                    lambda _result, request_error, selected=value:
                        self._on_replacement_context_switched(
                            session_id, "model", selected, request_error,
                            state, draft, delivery, resend,
                        ),
                )
            else:
                self.server.switch_agent(
                    session_id,
                    value,
                    lambda _result, request_error, selected=value:
                        self._on_replacement_context_switched(
                            session_id, "agent", selected, request_error,
                            state, draft, delivery, resend,
                        ),
                )

    def _on_replacement_context_switched(
        self, session_id, kind, value, error, state, draft, delivery, resend
    ):
        if error and state["error"] is None:
            state["error"] = error
        elif not error and session_id == self._selected_session:
            if kind == "model":
                self._set_model_ref(value)
            else:
                self._current_agent = value
                self._select_agent(value)
        state["remaining"] -= 1
        self._finish_context_switch(session_id, error)
        if state["remaining"]:
            return
        if state["error"]:
            self._show_notice(
                "La session a été créée, mais le modèle ou l’agent n’a pas pu "
                "être restauré. Le brouillon a été conservé : " + state["error"]
            )
            return
        if resend:
            self._start_prompt(
                session_id, draft["text"], delivery, draft["files"], None
            )

    def _on_messages_loaded(self, messages, error, session_id=None):
        if error:
            if self._is_session_not_found_error(error) and session_id:
                self._mark_session_stale(session_id, error)
                self._schedule_session_refresh()
                return
            if session_id:
                self._show_messages_error(session_id, error)
            else:
                self._show_notice("Impossible de charger les messages : " + error)
            return
        if session_id:
            self._invalid_sessions.discard(session_id)
        journal.log("messages %s : reçu %d" % (
            session_id, len(messages) if isinstance(messages, list) else -1))
        self._last_user_message = self._find_last_user_message(messages)
        while self.message_box.get_first_child():
            self.message_box.remove(self.message_box.get_first_child())
        while self.bookmark_box.get_first_child():
            self.bookmark_box.remove(self.bookmark_box.get_first_child())
        self.bookmark_scroller.set_visible(False)
        self._artifacts = {}
        # Fils de discussion : toujours les plus ANCIENS en haut, les plus
        # RÉCENTS en bas (convention des chats). On trie explicitement par
        # horodatage de création pour être indépendant de l'ordre que renvoie
        # le serveur ou de la pagination, et pour que le défilement vers le
        # bas se termine toujours sur les nouveaux messages.
        ordered = []
        for item in messages if isinstance(messages, list) else []:
            if isinstance(item, dict):
                created = item.get("time", {}).get("created")
                ordered.append(
                    (created if isinstance(created, (int, float)) else 0, item)
                )
        ordered.sort(key=lambda pair: pair[0])
        messages = [item for _t, item in ordered]
        if messages:
            def _short(m):
                for p in (m.get("parts") or m.get("content") or []):
                    if isinstance(p, dict) and p.get("type") == "text" and p.get("text"):
                        return p["text"][:30]
                return "(sans texte)"
            journal.log("ordre 1er=%s | dernier=%s" % (
                _short(messages[0]), _short(messages[-1])
            ))
        rendered_cards = []
        rendered_texts = []
        for item in messages if isinstance(messages, list) else []:
            if not isinstance(item, dict):
                continue
            info = item.get("info")
            role = (info.get("role") if isinstance(info, dict) else None)
            role = role or item.get("type", "assistant")
            content = self._message_content(item)
            self._collect_message_artifacts(item)
            if not content:
                continue
            # Un message d'assistant qui ne contient que raisonnement(+appels
            # d'outils) sans texte final n'est PAS une réponse : opencode ne
            # l'affiche pas. Sauter sa carte évite les cartes vides (auteur +
            # horodatage sans contenu) qui polluent le fil et « cachent »
            # l'historique réel.
            if not any(kind == "text" for kind, _val in content):
                continue
            message_item = Gtk.Box(
                orientation=Gtk.Orientation.VERTICAL, spacing=0
            )
            message_item.set_margin_bottom(12)
            card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            card.set_margin_start(14)
            card.set_margin_end(14)
            if role == "user":
                card.add_css_class("message-user")
            elif role == "assistant":
                card.add_css_class("message-assistant")
            author = Gtk.Label(
                label=self._message_author_label(role, item),
                xalign=0,
            )
            author.add_css_class("message-author")
            author.set_margin_start(18)
            author.set_margin_end(18)
            author.set_margin_top(4)
            author.set_margin_bottom(5)
            message_item.append(author)
            header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            # Marges internes : la date et les actions ne doivent pas coller au
            # bord du cartouche.
            header.set_margin_start(16)
            header.set_margin_end(12)
            header.set_margin_top(10)
            header.set_margin_bottom(2)
            header.set_valign(Gtk.Align.CENTER)
            created = self._message_created(item)
            if created:
                timestamp = Gtk.Label(label=created, xalign=1)
                timestamp.add_css_class("dim-label")
                timestamp.set_hexpand(True)
                timestamp.set_margin_end(4)
                header.append(timestamp)
            message_id = info.get("id") if isinstance(info, dict) else item.get("id")
            if isinstance(message_id, str) and message_id.startswith("msg_") and self._selected_session:
                fork = Gtk.Button.new_from_icon_name("document-new-symbolic")
                fork.set_tooltip_text("Créer une session à partir de ce message")
                fork.add_css_class("flat")
                fork.set_action_name("win.fork-message")
                fork.set_action_target_value(
                    self._fork_target(self._selected_session, message_id)
                )
                header.append(fork)
            # « Réinitialiser ici » : repartir de ce message utilisateur, comme
            # opencode le propose nativement. Ramène la conversation à ce point
            # (supprime les messages suivants) via l'API revert.
            if (
                role == "user"
                and isinstance(message_id, str)
                and message_id.startswith("msg_")
                and self._selected_session
                and not (self._last_user_message and message_id == self._last_user_message["id"])
            ):
                reset = Gtk.Button.new_from_icon_name("edit-undo-symbolic")
                reset.set_tooltip_text("Réinitialiser la conversation ici")
                reset.add_css_class("flat")
                reset.connect("clicked", self._confirm_reset_to_message, message_id)
                header.append(reset)
            if (
                self._last_user_message
                and message_id == self._last_user_message["id"]
                and self._selected_session
            ):
                edit = Gtk.Button.new_from_icon_name("document-edit-symbolic")
                edit.set_tooltip_text("Modifier le dernier message")
                edit.add_css_class("flat")
                edit.connect("clicked", self._edit_last_message)
                header.append(edit)
                regenerate = Gtk.Button.new_from_icon_name("view-refresh-symbolic")
                regenerate.set_tooltip_text("Régénérer la dernière réponse")
                regenerate.add_css_class("flat")
                regenerate.connect("clicked", self._confirm_regenerate_last_message)
                header.append(regenerate)
            if role in ("assistant", "user"):
                copy_button = Gtk.Button.new_from_icon_name("edit-copy-symbolic")
                copy_button.set_tooltip_text(
                    "Copier la réponse" if role == "assistant"
                    else "Copier le message"
                )
                copy_button.add_css_class("flat")
                copy_button.connect(
                    "clicked", self._copy_message, self._message_text(item)
                )
                header.append(copy_button)
            card.append(header)
            card.add_css_class("card")
            body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            body.set_margin_top(12)
            body.set_margin_bottom(14)
            body.set_margin_start(16)
            body.set_margin_end(16)
            for kind, value in content:
                if kind == "text":
                    self._render_markdown(body, value)
                elif kind == "tool":
                    # Les appels d'outils ne sont pas affichés (comme opencode) ;
                    # on appelle quand même render_tool pour collecter les
                    # artefacts (fichiers/images générés) éventuels.
                    self._render_tool(body, value)
            if body.get_first_child():
                card.append(body)
            self._attach_context_menu(card, self._message_text(item))
            message_item.append(card)
            self.message_box.append(message_item)
            rendered_texts.append(self._message_text(item))
            rendered_cards.append((role, message_item))
        total_cards = len(rendered_cards)
        assistant_number = 0
        for card_index, (role, _card) in enumerate(rendered_cards):
            if role != "assistant":
                continue
            assistant_number += 1
            preview = "%d · %s" % (
                assistant_number,
                self._preview_text(rendered_texts[card_index]),
            )
            bookmark = Gtk.Button()
            bookmark.set_halign(Gtk.Align.FILL)
            preview_label = Gtk.Label(
                label=preview,
                xalign=0,
                ellipsize=Pango.EllipsizeMode.END,
                max_width_chars=24,
            )
            bookmark.set_child(preview_label)
            bookmark.add_css_class("flat")
            bookmark.add_css_class("message-preview")
            bookmark.set_tooltip_text(
                "Réponse %d — %s" % (
                    assistant_number,
                    " ".join(rendered_texts[card_index].split())[:400],
                )
            )
            bookmark.connect("clicked", self._jump_to_message, card_index, total_cards)
            self.bookmark_box.append(bookmark)
        self.bookmark_scroller.set_visible(
            self.bookmark_box.get_first_child() is not None
        )
        if not self.message_box.get_first_child():
            self.message_box.append(Adw.StatusPage(
                icon_name="chat-message-new-symbolic",
                title="Aucun message",
                description="Cette session ne contient pas encore de conversation.",
            )
            )
        self.artifacts_button.set_tooltip_text(
            "Afficher ou masquer les artefacts de la session"
        )
        self.refresh_artifacts_panel()
        self._history_cards = [item for _role, item in rendered_cards]
        self._history_texts = rendered_texts
        self._history_reveal = 0
        self._refresh_history_window()
        # Si une recherche est ouverte, relancer sur la nouvelle conversation.
        if getattr(self, "chat_search_bar", None) is not None:
            if self.chat_search_bar.get_search_mode() and self.chat_search_entry.get_text().strip():
                self._on_chat_search_changed(self.chat_search_entry)
        GLib.idle_add(self._scroll_messages_to_end)

    def _ensure_history_bar(self):
        """Bandeau tout en haut du fil pour déplier l'historique ancien."""
        if getattr(self, "_history_bar", None) is not None:
            return self._history_bar
        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        bar.set_margin_bottom(6)
        bar.set_halign(Gtk.Align.CENTER)
        self._history_bar_label = Gtk.Label()
        self._history_bar_label.add_css_class("dim-label")
        reveal = Gtk.Button(label="Générations précédentes")
        reveal.add_css_class("flat")
        reveal.add_css_class("pill")
        reveal.connect("clicked", self._on_history_reveal)
        show_all = Gtk.Button(label="Tout afficher")
        show_all.add_css_class("flat")
        show_all.add_css_class("pill")
        show_all.connect("clicked", self._on_history_show_all)
        self._history_reveal_button = reveal
        self._history_show_all_button = show_all
        bar.append(self._history_bar_label)
        bar.append(reveal)
        bar.append(show_all)
        self.message_box.prepend(bar)
        self._history_bar = bar
        return bar

    def _refresh_history_window(self):
        """Replie les messages anciens au-delà d'une fenêtre de N récents.

        Sélectionné : bouton « replier » + chargement progressif. Les plus
        anciens sont masqués (haut du fil) et s'affichent par paquets.
        """
        cards = self._history_cards
        total = len(cards)
        if total <= self.HISTORY_DEFAULT_KEEP:
            for card in cards:
                card.set_visible(True)
            self._discard_history_bar()
            return
        visible = min(total, self.HISTORY_DEFAULT_KEEP + self._history_reveal)
        hidden = total - visible
        for index, card in enumerate(cards):
            card.set_visible(index >= hidden)
        self._discard_history_bar()
        if hidden <= 0:
            return
        bar = self._ensure_history_bar()
        self._history_bar_label.set_label(
            "%d message(s) plus ancien(s)" % hidden
        )
        self._history_reveal_button.set_visible(hidden > 0)
        self._history_show_all_button.set_visible(hidden > 0)

    def _discard_history_bar(self):
        bar = getattr(self, "_history_bar", None)
        if bar is not None:
            if bar.get_parent() is not None:
                self.message_box.remove(bar)
            self._history_bar = None

    def _on_history_reveal(self, _button):
        self._history_reveal += self.HISTORY_STEP
        self._refresh_history_window()
        GLib.idle_add(self._scroll_messages_to_end)

    def _on_history_show_all(self, _button):
        self._history_reveal = len(self._history_cards)
        self._refresh_history_window()
        GLib.idle_add(self._scroll_messages_to_end)

    def _jump_to_message(self, _button, card_index, total_cards):
        adjustment = self.message_scroller.get_vadjustment()
        max_value = max(
            adjustment.get_lower(),
            adjustment.get_upper() - adjustment.get_page_size(),
        )
        denominator = max(1, total_cards - 1)
        adjustment.set_value(
            adjustment.get_lower() + (max_value - adjustment.get_lower())
            * card_index / denominator
        )

    # --- Recherche dans la conversation (Ctrl+F) -------------------------

    def _toggle_chat_search(self, *_):
        active = self.chat_search_bar.get_search_mode()
        self.chat_search_bar.set_search_mode(not active)
        if not active:
            self.chat_search_entry.grab_focus()

    def _on_chat_search_mode_changed(self, bar, _param):
        if not bar.get_search_mode():
            self.chat_search_status.set_text("")
            self._chat_search_matches = []
            self._clear_search_highlights()

    def _on_chat_search_changed(self, entry):
        query = entry.get_text().strip()
        self._chat_search_matches = []
        self._chat_search_index = 0
        if not query:
            self.chat_search_status.set_text("")
            self._clear_search_highlights()
            return
        needle = query.casefold()
        self._chat_search_matches = [
            index
            for index, text in enumerate(getattr(self, "_history_texts", []))
            if needle in (text or "").casefold()
        ]
        if not self._chat_search_matches:
            self.chat_search_status.set_text("Aucun résultat")
            self._clear_search_highlights()
            return
        self.chat_search_status.set_text(
            "1/%d" % len(self._chat_search_matches)
        )
        self._scroll_to_card_index(self._chat_search_matches[0])
        self._apply_search_highlights(query)
        self._mark_current_search_card(self._chat_search_matches[0])

    def _on_chat_search_next(self, _entry):
        matches = getattr(self, "_chat_search_matches", [])
        if not matches:
            return
        self._chat_search_index = (self._chat_search_index + 1) % len(matches)
        self.chat_search_status.set_text(
            "%d/%d" % (self._chat_search_index + 1, len(matches))
        )
        self._scroll_to_card_index(matches[self._chat_search_index])
        self._apply_search_highlights(self.chat_search_entry.get_text().strip())
        self._mark_current_search_card(matches[self._chat_search_index])

    def _clear_search_highlights(self):
        def walk(widget):
            if isinstance(widget, Gtk.Label):
                widget.remove_css_class("search-hit")
            elif isinstance(widget, Gtk.TextView):
                buffer = widget.get_buffer()
                tag = buffer.get_tag_table().lookup("search-hit")
                if tag is not None:
                    buffer.remove_tag(
                        tag, buffer.get_start_iter(), buffer.get_end_iter()
                    )
            child = widget.get_first_child()
            while child is not None:
                walk(child)
                child = child.get_next_sibling()

        walk(self.message_box)
        for card in getattr(self, "_history_cards", []):
            card.remove_css_class("search-current")

    def _apply_search_highlights(self, query):
        self._clear_search_highlights()
        needle = (query or "").strip().casefold()
        if not needle:
            return

        def walk(widget):
            if isinstance(widget, Gtk.Label):
                if needle in (widget.get_text() or "").casefold():
                    widget.add_css_class("search-hit")
            elif isinstance(widget, Gtk.TextView):
                buffer = widget.get_buffer()
                start, end = buffer.get_bounds()
                text = buffer.get_text(start, end, False)
                if needle in text.casefold():
                    tag = buffer.get_tag_table().lookup("search-hit")
                    if tag is None:
                        tag = buffer.create_tag(
                            "search-hit",
                            background="#f9e26b",
                            foreground="#241f31",
                        )
                    haystack = text.casefold()
                    position = haystack.find(needle)
                    while position >= 0:
                        match_start = buffer.get_iter_at_offset(position)
                        match_end = buffer.get_iter_at_offset(
                            position + len(needle)
                        )
                        buffer.apply_tag(tag, match_start, match_end)
                        position = haystack.find(needle, position + len(needle))
            child = widget.get_first_child()
            while child is not None:
                walk(child)
                child = child.get_next_sibling()

        walk(self.message_box)

    def _mark_current_search_card(self, card_index):
        if 0 <= card_index < len(self._history_cards):
            self._history_cards[card_index].add_css_class("search-current")

    def _scroll_to_card_index(self, index):
        cards = self._history_cards
        if index < 0 or index >= len(cards):
            return
        # Si la carte est repliée dans l'historique ancien, on la révèle.
        total = len(cards)
        if total > self.HISTORY_DEFAULT_KEEP:
            hidden = total - (self.HISTORY_DEFAULT_KEEP + self._history_reveal)
            if index < hidden:
                self._history_reveal += hidden - index
                self._refresh_history_window()
        GLib.idle_add(self._scroll_card_into_view, cards[index])

    def _scroll_card_into_view(self, card):
        if not card.get_mapped():
            GLib.timeout_add(50, self._scroll_card_into_view, card)
            return False
        ok, rect = card.compute_bounds(self.message_box)
        if not ok:
            return False
        adjustment = self.message_scroller.get_vadjustment()
        adjustment.set_value(max(adjustment.get_lower(), rect.get_y() - 12))
        return False

    @staticmethod
    def _preview_text(text, limit=28):
        clean = " ".join((text or "").split())
        if not clean:
            return "(sans texte)"
        if len(clean) > limit:
            clean = clean[: limit - 1].rstrip() + "…"
        return clean

    def _copy_message(self, _button, text):
        if not text:
            self._flash("Rien à copier pour ce message.")
            return
        if self._write_clipboard(text):
            self._flash("Réponse copiée")

    def _copy_text_action(self, _action, parameter):
        if self._write_clipboard(parameter.get_string()):
            self._flash("Copié")

    def _write_clipboard(self, text):
        """Copie du texte dans le presse-papiers, avec retour booléen sûr."""
        journal.log("copie : %d caractères" % len(text or ""))
        if clipboard_util.copy_text(self, text):
            return True
        self._flash("Impossible d’accéder au presse-papiers.")
        return False

    def _flash(self, text):
        """Affiche une notification légère native Adwaita (toast)."""
        try:
            self.toast_overlay.add_toast(Adw.Toast.new(text))
        except Exception:
            pass

    def _open_link_action(self, _action, parameter):
        uri = parameter.get_string()
        if urllib.parse.urlsplit(uri).scheme.lower() not in ("http", "https", "mailto"):
            self._show_notice("Ce type de lien n’est pas autorisé.")
            return
        self._on_link_activated(None, uri)

    def _change_zoom(self, delta, reset=False):
        self._zoom_scale = 1.0 if reset else min(1.6, max(0.8, self._zoom_scale + delta))
        saved = state.load()
        saved["zoom_scale"] = self._zoom_scale
        state.save(saved)
        self._apply_zoom()

    def _apply_zoom(self):
        if not hasattr(self, "_zoom_provider"):
            return
        css = (
            ".perceptron-content { font-size: %d%%; }\n"
            # Thème fixe des deux rôles, indépendant du thème système :
            # opencode (assistant) = cartouche claire Adwaita, l'utilisateur =
            # cartouche sombre. Couleur de texte forcée pour rester lisible dans
            # les deux modes du système.
            ".perceptron-content .message-assistant { "
            "background-color: #ffffff; color: #241f31; "
            "border: 1px solid #d7d4d0; border-radius: 12px; }\n"
            ".perceptron-content .message-user { "
            "background-color: #3d3846; color: #f6f5f4; "
            "border: 1px solid #5e5c64; border-radius: 12px; }\n"
            ".perceptron-content .message-assistant textview { "
            "background-color: transparent; }\n"
            ".perceptron-content .message-assistant textview text { "
            "color: #241f31; caret-color: #241f31; }\n"
            ".perceptron-content .message-user textview { "
            "background-color: transparent; }\n"
            ".perceptron-content .message-user textview text { "
            "color: #f6f5f4; caret-color: #f6f5f4; }\n"
            ".perceptron-content .message-author { "
            "font-size: 0.9em; font-weight: 600; color: @dimmed_fg_color; }\n"
            ".perceptron-content .markdown-color-red { color: #e01b24; }\n"
            ".perceptron-content .markdown-color-orange { color: #ff7800; }\n"
            ".perceptron-content .markdown-color-yellow { color: #e5a50a; }\n"
            ".perceptron-content .markdown-color-green { color: #2ec27e; }\n"
            ".perceptron-content .markdown-color-blue { color: #3584e4; }\n"
            ".perceptron-content .markdown-color-purple { color: #9141ac; }\n"
            ".perceptron-content .markdown-color-pink { color: #e439a0; }\n"
            ".message-preview { font-size: 0.82em; padding: 2px 6px; }\n"
            ".perceptron-content .search-hit { "
            "background-color: #f9e26b; color: #241f31; border-radius: 3px; }\n"
            ".perceptron-content .search-current { "
            "border: 2px solid #3584e4; border-radius: 14px; }\n"
            ".composer-grip { background-color: alpha(@borders, 0.6); "
            "border-radius: 3px; }\n"
            ".perceptron-content .composer-grip { min-height: 5px; }\n"
            ".perceptron-content paned > separator { "
            "min-width: 8px; background-color: alpha(@borders, 0.35); "
            "border-left: 1px solid alpha(@borders, 0.5); "
            "border-right: 1px solid alpha(@borders, 0.5); }\n"
            ".perceptron-content paned > separator:hover { "
            "background-color: @accent_bg_color; min-width: 8px; }\n"
            ".perceptron-content .bookmark-scroller { border:none; }\n"
        ) % round(self._zoom_scale * 100)
        self._zoom_provider.load_from_data(css.encode("ascii"))

    def _message_author_label(self, role, item):
        """Libellé d'auteur d'un cartouche de message.

        - Pour l'utilisateur : « Moi » (l'opérateur), sobre et immédiat.
        - Pour l'assistant : « OpenCode — modèle — fournisseur » afin de
          savoir immédiatement quel LLM a répondu (ex. ``OpenCode — Deepseek
          — Albert``). Les métadonnées viennent du message lui-même si le
          serveur les fournit, sinon on retombe sur le modèle courant.
        """
        if role == "user":
            return "Moi"
        model = item.get("model") if isinstance(item, dict) else None
        if not isinstance(model, dict):
            model = self._current_model
        model_id = (model or {}).get("id") or "OpenCode"
        provider_id = (model or {}).get("providerID") or ""
        # Nom lisible du LLM quand il existe dans la liste connue.
        model_name = model_id
        for candidate in self._models:
            if candidate.get("id") == model_id:
                model_name = candidate.get("name") or model_id
                break
        provider = self._providers.get(provider_id) or provider_id
        if provider:
            return "OpenCode — %s — %s" % (model_name, provider)
        return "OpenCode — %s" % model_name

    @staticmethod
    def _find_last_user_message(messages):
        for item in reversed(messages if isinstance(messages, list) else []):
            if not isinstance(item, dict):
                continue
            info = item.get("info")
            role = (
                info.get("role") or info.get("type") if isinstance(info, dict)
                else item.get("type")
            )
            if role != "user":
                continue
            message_id = info.get("id") if isinstance(info, dict) else item.get("id")
            text = MainWindow._message_text(item)
            if isinstance(message_id, str) and text:
                return {"id": message_id, "text": text}
        return None

    @staticmethod
    def _format_timestamp(value, date_format):
        if isinstance(value, bool) or not isinstance(value, (float, int)):
            return ""
        timestamp = float(value)
        if abs(timestamp) >= 100_000_000_000:
            timestamp /= 1000
        try:
            date_time = GLib.DateTime.new_from_unix_local(int(timestamp))
        except (OverflowError, TypeError, ValueError):
            return ""
        return date_time.format(date_format) if date_time is not None else ""

    @staticmethod
    def _message_created(message):
        return MainWindow._format_timestamp(
            message.get("time", {}).get("created"), "%H:%M"
        )

    @staticmethod
    def _format_session_date(value):
        if isinstance(value, bool) or not isinstance(value, (float, int)):
            return ""
        timestamp = float(value)
        if abs(timestamp) >= 100_000_000_000:
            timestamp /= 1000
        try:
            date_time = GLib.DateTime.new_from_unix_local(int(timestamp))
        except (OverflowError, TypeError, ValueError):
            return ""
        if date_time is None:
            return ""
        weekdays = (
            "lundi", "mardi", "mercredi", "jeudi", "vendredi",
            "samedi", "dimanche",
        )
        months = (
            "janv.", "févr.", "mars", "avr.", "mai", "juin",
            "juill.", "août", "sept.", "oct.", "nov.", "déc.",
        )
        label = "%s %d %s" % (
            weekdays[date_time.get_day_of_week() - 1],
            date_time.get_day_of_month(),
            months[date_time.get_month() - 1],
        )
        current_year = GLib.DateTime.new_now_local().get_year()
        if date_time.get_year() != current_year:
            label += " %d" % date_time.get_year()
        return label

    @staticmethod
    def _fork_target(session_id, message_id):
        return GLib.Variant("(ss)", (session_id, message_id))

    @staticmethod
    def _message_content(message):
        info = message.get("info")
        outer_parts = message.get("parts")
        if isinstance(info, dict):
            message = info
        role = message.get("type")
        if role in ("user", "synthetic", "system", "shell", "skill"):
            text = message.get("text") or message.get("output", {}).get("output")
            return [("text", text)] if text else []

        parts = message.get("content")
        if not isinstance(parts, list):
            parts = outer_parts if isinstance(outer_parts, list) else message.get("parts")
        if not isinstance(parts, list):
            text = message.get("text")
            return [("text", text)] if text else []
        content = []
        for part in parts:
            if not isinstance(part, dict):
                continue
            if part.get("type") == "text" and part.get("text"):
                content.append(("text", part["text"]))
            elif part.get("type") == "tool":
                content.append(("tool", part))
        return content

    @staticmethod
    def _message_text(message):
        return "\n\n".join(
            value if kind == "text" else "Outil : " + str(
                (value.get("state") or {}).get("metadata", {}).get("title")
                or value.get("state", {}).get("title")
                or value.get("name", "outil")
            )
            for kind, value in MainWindow._message_content(message)
        )

    def _render_tool(self, container, part):
        conversation.render_tool(container, part, self)

    @staticmethod
    def _tool_has_content(part):
        """Une carte d'outil n'est affichée que si elle a un résultat réel.

        Les appels d'outils sans sortie ni fichier produit (simple statut
        « completed »/« running ») sont de la pure mécanique interne : les
        afficher en cartes pleine hauteur encombre le fil et donne
        l'impression que « tous les blobs » y apparaissent.
        """
        state = part.get("state")
        state = state if isinstance(state, dict) else {}
        for item in state.get("content", []):
            if isinstance(item, dict) and item.get("type") == "text" and item.get("text"):
                return True
        detail = state.get("metadata", {})
        if isinstance(detail, dict):
            path = detail.get("title")
            if MainWindow._local_artifact_path(path):
                return True
        return False

    def _markdown_content(self, text):
        return self._md_renderer().content(text)

    def _md_renderer(self):
        """Rendu Markdown canonique (markdown.Renderer), câblé à la fenêtre."""
        if self._markdown_renderer is None:
            from markdown import Renderer
            self._markdown_renderer = Renderer(
                on_link=self._on_link_activated,
                on_context=self._attach_context_menu,
            )
        return self._markdown_renderer

    @staticmethod
    def _markdown_blocks(text):
        # Le parseur canonique (markdown.parse_blocks) enrichit les blocs de
        # code d'une langue (3-uplets). L'ancien contrat applicatif utilise des
        # 2-uplets (kind, value) : on normalise ici pour préserver la
        # rétrocompatibilité (rendu inline et tests).
        return [block[:2] for block in markdown.parse_blocks(text)]

    @staticmethod
    def _table_cells(line):
        return markdown._table_cells(line)

    @staticmethod
    def _inline_markup(text):
        return markdown.inline_markup(text)

    def _render_markdown(self, container, text):
        self._md_renderer().render(container, text)

    def _on_link_activated(self, _label, uri):
        if urllib.parse.urlsplit(uri).scheme.lower() not in ("http", "https", "mailto"):
            return True
        try:
            Gio.AppInfo.launch_default_for_uri(uri, None)
        except GLib.Error as error:
            self._show_notice("Impossible d’ouvrir le lien : " + error.message)
        return True

    def _attach_context_menu(self, widget, text):
        menu = Gio.Menu()
        copy = Gio.MenuItem.new("Copier ce texte", None)
        copy.set_action_and_target_value(
            "win.copy-text", GLib.Variant.new_string(text)
        )
        menu.append_item(copy)
        urls = []
        for uri in re.findall(r"(?:https?://|mailto:)[^\s<>()[\]]+", text):
            uri = uri.rstrip(".,;:!?")
            if uri not in urls and urllib.parse.urlsplit(uri).scheme.lower() in (
                "http", "https", "mailto"
            ):
                urls.append(uri)
        for uri in urls[:5]:
            open_item = Gio.MenuItem.new("Ouvrir " + uri[:48], None)
            open_item.set_action_and_target_value(
                "win.open-link", GLib.Variant.new_string(uri)
            )
            menu.append_item(open_item)
            copy_link = Gio.MenuItem.new("Copier le lien", None)
            copy_link.set_action_and_target_value(
                "win.copy-text", GLib.Variant.new_string(uri)
            )
            menu.append_item(copy_link)
        paths = re.findall(r"(?<![\w:])/(?:[^\s,;()<>]+)", text)
        for path in paths[:5]:
            path = path.rstrip(".,:!?")
            local_path = self._local_path(path, allow_directory=True)
            if local_path:
                is_directory = os.path.isdir(local_path)
                item = Gio.MenuItem.new(
                    (
                        "Ouvrir dans Fichiers : " + os.path.basename(local_path)
                        if is_directory
                        else "Ouvrir le dossier de " + os.path.basename(local_path)
                    ),
                    None,
                )
                item.set_action_and_target_value(
                    "win.open-artifact-folder",
                    GLib.Variant.new_string(Gio.File.new_for_path(local_path).get_uri()),
                )
                menu.append_item(item)
        gesture = Gtk.GestureClick()
        gesture.set_button(Gdk.BUTTON_SECONDARY)
        gesture.connect("pressed", self._show_artifact_context_menu, widget, menu)
        widget.add_controller(gesture)

    def _collect_message_artifacts(self, message):
        for file_item in message.get("files", []):
            if not isinstance(file_item, dict):
                continue
            source = file_item.get("source", {})
            uri = source.get("uri") if isinstance(source, dict) else None
            if uri:
                self._collect_artifact(uri, file_item.get("mime", ""), file_item.get("name"))
        info = message.get("info")
        parts = info.get("content", []) if isinstance(info, dict) else message.get("content", [])
        for part in parts if isinstance(parts, list) else []:
            if not isinstance(part, dict) or part.get("type") != "tool":
                continue
            state = part.get("state")
            if not isinstance(state, dict):
                continue
            for item in state.get("content", []):
                if isinstance(item, dict) and item.get("type") == "file":
                    self._collect_artifact(
                        item.get("uri", ""),
                        item.get("mime", ""),
                        item.get("name"),
                    )

    def _collect_artifact(self, uri, mime, name=None):
        path = self._local_artifact_path(uri)
        if path is None:
            return
        key = os.path.realpath(path)
        self._artifacts.setdefault(key, {
            "path": key,
            "uri": Gio.File.new_for_path(key).get_uri(),
            "mime": mime,
            "name": name or os.path.basename(key),
        })

    @staticmethod
    def _local_path(uri, allow_directory=False):
        if not isinstance(uri, str) or not uri:
            return None
        parsed = urllib.parse.urlsplit(uri)
        if parsed.scheme:
            if parsed.scheme != "file" or parsed.netloc not in ("", "localhost"):
                return None
            path = urllib.parse.unquote(parsed.path)
        elif os.path.isabs(uri):
            path = uri
        else:
            return None
        path = os.path.realpath(path)
        if os.path.isfile(path) or (allow_directory and os.path.isdir(path)):
            return path
        return None

    @staticmethod
    def _local_artifact_path(uri):
        return MainWindow._local_path(uri)

    def show_artifacts(self):
        """Ouvre (force) le panneau des artefacts ; bascule s'il est déjà là."""
        if self.artifacts_box.get_visible():
            self.toggle_artifacts()
            return
        self.toggle_artifacts()

    def toggle_artifacts(self):
        visible = self.artifacts_box.get_visible()
        self.artifacts_box.set_visible(not visible)
        self.artifacts_box.set_sensitive(not visible)
        self.artifacts_button.set_icon_name(
            "folder-pictures-symbolic" if visible else "pan-end-symbolic"
        )
        self.artifacts_button.set_tooltip_text(
            "Masquer les artefacts de la session" if visible
            else "Afficher les artefacts de la session"
        )
        if not visible:
            self.load_server_artifacts()
        self.refresh_artifacts_panel()

    def reload_artifacts(self):
        self.load_server_artifacts()
        self.refresh_artifacts_panel()

    def load_server_artifacts(self):
        if not self.server:
            return
        self.server.list_artifacts(
            lambda artifacts, error: self._on_server_artifacts(artifacts, error)
        )

    def _on_server_artifacts(self, artifacts, error):
        # L'API expérimentale est parfois désactivée (HTTP 403) : on garde
        # alors la collecte locale, déjà alimentée par les réponses.
        if error or not isinstance(artifacts, list):
            return
        for item in artifacts:
            if not isinstance(item, dict):
                continue
            uri = item.get("uri") or item.get("path")
            if uri:
                self._collect_artifact(uri, item.get("mime", ""), item.get("name"))
        self.refresh_artifacts_panel()

    def refresh_artifacts_panel(self):
        """Repeuple le panneau des artefacts depuis la collecte locale."""
        if not hasattr(self, "artifacts_list"):
            return
        child = self.artifacts_list.get_first_child()
        while child:
            next_child = child.get_next_sibling()
            self.artifacts_list.remove(child)
            child = next_child
        artifacts = list(self._artifacts.values())
        if not artifacts:
            page = Adw.StatusPage(
                icon_name="folder-documents-symbolic",
                title="Aucun artefact",
                description=(
                    "Les images et fichiers générés par les réponses de cette "
                    "session s’afficheront ici."
                ),
            )
            self.artifacts_list.append(page)
            return
        for artifact in artifacts:
            self.artifacts_list.append(self._artifact_widget(artifact))

    # ------------------------------------------------------------------ #
    # Recherche web                                                        #
    # ------------------------------------------------------------------ #
    def load_websearch_providers(self, on_ready=None):
        """Charge la liste des fournisseurs de recherche depuis le serveur.

        Met la liste en cache (`_websearch_providers`) puis rappelle
        *on_ready* (appelé aussi en cas d'erreur, avec le cache éventuel).
        """
        if not self.server:
            if on_ready:
                on_ready()
            return
        self.server.list_websearch_providers(
            lambda providers, error: self._on_websearch_providers(
                providers, error, on_ready
            )
        )

    def _on_websearch_providers(self, providers, error, on_ready=None):
        self._websearch_providers = []
        self._websearch_provider_map = {}
        if not error and isinstance(providers, list):
            for item in providers:
                if not isinstance(item, dict):
                    continue
                provider_id = item.get("id")
                name = item.get("name") or provider_id
                if provider_id:
                    self._websearch_providers.append((provider_id, name))
                    self._websearch_provider_map[provider_id] = name
        if on_ready:
            on_ready()
        self._refresh_websearch_provider_prefs()

    def _refresh_websearch_provider_prefs(self):
        dropdown = getattr(self, "_websearch_provider_dropdown_prefs", None)
        if dropdown is None:
            return
        model = self._websearch_provider_model_prefs
        for index in range(model.get_n_items() - 1, -1, -1):
            model.remove(index)
        if not self._websearch_providers:
            model.append("Aucun fournisseur configuré")
            dropdown.set_sensitive(False)
            self._websearch_provider_row_prefs.set_subtitle(
                "Aucun fournisseur de recherche détecté sur le serveur."
            )
            return
        for _pid, name in self._websearch_providers:
            model.append(name)
        selected = self._websearch_provider_id()
        dropdown.set_selected(self._provider_index(selected))
        provider_id = self._websearch_providers[dropdown.get_selected()][0]
        self._websearch_provider_row_prefs.set_subtitle(
            "Actuellement : %s" % self._websearch_provider_map.get(
                provider_id, provider_id
            )
        )

    def _on_websearch_provider_pref_changed(self, dropdown, _pspec):
        if not self._websearch_providers:
            return
        index = dropdown.get_selected()
        if index < 0 or index >= len(self._websearch_providers):
            return
        provider_id = self._websearch_providers[index][0]
        saved = state.load()
        saved["websearch_provider_id"] = provider_id
        state.save(saved)
        self._websearch_provider_row_prefs.set_subtitle(
            "Actuellement : %s" % self._websearch_provider_map.get(
                provider_id, provider_id
            )
        )

    # ------------------------------------------------------------------ #
    # Configuration OpenCode (module des Préférences)                      #
    # ------------------------------------------------------------------ #
    def _populate_config_group(self, group, docs, error):
        if error:
            group.add(Adw.ActionRow(
                title="Configuration indisponible", subtitle=error
            ))
            return
        info = None
        for doc in docs if isinstance(docs, list) else []:
            if isinstance(doc, dict) and isinstance(doc.get("info"), dict):
                info = doc["info"]
                break
        if info is None:
            group.add(Adw.ActionRow(
                title="Configuration indisponible",
                subtitle="Le serveur n’a renvoyé aucun document de configuration.",
            ))
            return
        model = info.get("model") or {}
        provider_id = model.get("providerID") or "—"
        model_name = model.get("model") or "—"
        group.add(Adw.ActionRow(
            title="Modèle par défaut",
            subtitle="%s · %s" % (provider_id, model_name),
        ))
        group.add(Adw.ActionRow(
            title="Agent",
            subtitle=str(info.get("agent") or "—"),
        ))
        shell_row = Adw.ActionRow(
            title="Shell (API expérimentale)",
            subtitle="Interpréteur de commandes d’OpenCode (PATCH).",
        )
        shell_entry = Gtk.Entry()
        shell_entry.set_text((info.get("shell") or ""))
        shell_entry.set_placeholder_text("ex. /bin/bash")
        shell_entry.set_valign(Gtk.Align.CENTER)
        shell_entry.connect("activate", self._on_config_shell_changed, shell_entry)
        shell_row.add_suffix(shell_entry)
        group.add(shell_row)

        first_path = next(
            (doc.get("path") for doc in docs if isinstance(docs, list)
             if isinstance(doc, dict) and doc.get("path")),
            None,
        )
        if first_path:
            open_row = Adw.ActionRow(title="Ouvrir le fichier de configuration")
            open_button = Gtk.Button(label="Ouvrir")
            open_button.add_css_class("flat")
            open_button.set_valign(Gtk.Align.CENTER)
            open_button.connect(
                "clicked", lambda *_a, p=first_path: self._open_config_file(p)
            )
            open_row.add_suffix(open_button)
            open_row.set_activatable_widget(open_button)
            group.add(open_row)

    def _on_config_shell_changed(self, _widget, entry):
        value = entry.get_text().strip()
        self.server.patch_config(
            {"shell": value or None},
            lambda _result, error: self._on_config_shell_patched(error, value),
        )

    def _on_config_shell_patched(self, error, value):
        if error:
            self._show_notice("Impossible de mettre à jour la configuration : " + error)
            return
        self._flash("Configuration mise à jour (%s)" % (value or "défaut"))

    def _open_config_file(self, path):
        if not os.path.isfile(path):
            self._show_notice("Le fichier de configuration n’existe pas.")
            return
        try:
            Gio.AppInfo.launch_default_for_uri(
                Gio.File.new_for_path(path).get_uri(), None
            )
        except GLib.Error as error:
            self._show_notice("Impossible d’ouvrir le fichier : " + error.message)

    def _websearch_provider_id(self):
        saved = state.load()
        return saved.get("websearch_provider_id") or (
            self._websearch_providers[0][0]
            if self._websearch_providers else None
        )

    def _show_websearch_dialog(self, _button=None):
        self.load_websearch_providers(
            lambda: self._present_websearch_dialog()
        )

    def _present_websearch_dialog(self):
        dialog = Adw.Dialog()
        dialog.set_title("Recherche web")
        dialog.set_content_width(640)
        dialog.set_content_height(520)
        header = Adw.HeaderBar()
        close_button = Gtk.Button(
            icon_name="window-close-symbolic", tooltip_text="Fermer"
        )
        close_button.connect("clicked", lambda *_: dialog.close())
        header.pack_end(close_button)

        search_row = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL, spacing=8,
            margin_top=8, margin_bottom=8, margin_start=12, margin_end=12,
        )
        self._websearch_entry = Gtk.Entry(placeholder_text="Que chercher sur le web ?")
        self._websearch_entry.set_hexpand(True)
        self._websearch_entry.connect("activate", self._on_websearch_run, dialog)
        search_row.append(self._websearch_entry)

        provider_model = Gtk.StringList()
        self._websearch_provider_dropdown = Gtk.DropDown(model=provider_model)
        if self._websearch_providers:
            for _pid, name in self._websearch_providers:
                provider_model.append(name)
            selected = self._websearch_provider_id()
            self._websearch_provider_dropdown.set_selected(
                max(0, self._provider_index(selected))
            )
        search_row.append(self._websearch_provider_dropdown)

        search_button = Gtk.Button(
            label="Rechercher", icon_name="system-search-symbolic"
        )
        search_button.add_css_class("suggested-action")
        search_button.connect("clicked", self._on_websearch_run, dialog)
        search_row.append(search_button)

        status = Gtk.Label(xalign=0, margin_start=12, margin_bottom=4)
        status.add_css_class("dim-label")
        if not self._websearch_providers:
            status.set_text(
                "Aucun fournisseur de recherche configuré sur le serveur. "
                "Vérifie ta configuration OpenCode, puis choisis-en un dans "
                "les Préférences."
            )

        self._websearch_results = Gtk.ListBox(
            selection_mode=Gtk.SelectionMode.NONE
        )
        self._websearch_results.add_css_class("boxed-list")
        self._websearch_results.set_margin_top(4)
        self._websearch_results.set_margin_bottom(12)
        self._websearch_results.set_margin_start(12)
        self._websearch_results.set_margin_end(12)
        results_scroll = Gtk.ScrolledWindow(vexpand=True)
        results_scroll.set_child(self._websearch_results)

        body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        body.append(search_row)
        body.append(status)
        body.append(results_scroll)
        body.set_hexpand(True)
        body.set_vexpand(True)

        toolbar = Adw.ToolbarView(content=body)
        toolbar.add_top_bar(header)
        dialog.set_child(toolbar)
        dialog.present(self)
        self._websearch_dialog = dialog
        self._websearch_entry.grab_focus()

    def _provider_index(self, provider_id):
        for index, (pid, _name) in enumerate(self._websearch_providers):
            if pid == provider_id:
                return index
        return 0

    def _on_websearch_run(self, _widget, dialog):
        query = self._websearch_entry.get_text().strip()
        if not query:
            return
        if not self._websearch_providers:
            self._show_notice("Aucun fournisseur de recherche configuré.")
            return
        index = self._websearch_provider_dropdown.get_selected()
        provider_id = self._websearch_providers[index][0]
        saved = state.load()
        saved["websearch_provider_id"] = provider_id
        state.save(saved)
        while self._websearch_results.get_first_child():
            self._websearch_results.remove(self._websearch_results.get_first_child())
        self._websearch_provider_dropdown.set_sensitive(False)
        self._websearch_entry.set_sensitive(False)
        self.server.websearch(
            query, provider_id,
            lambda results, error: self._on_websearch_results(
                results, error, dialog
            ),
        )

    def _on_websearch_results(self, results, error, dialog):
        self._websearch_provider_dropdown.set_sensitive(True)
        self._websearch_entry.set_sensitive(True)
        if error:
            self._show_notice("Recherche web impossible : " + error)
            return
        items = results if isinstance(results, list) else []
        if not items:
            self._websearch_results.append(Adw.ActionRow(
                title="Aucun résultat",
                subtitle="Rien trouvé pour cette recherche.",
            ))
            return
        for result in items:
            if not isinstance(result, dict):
                continue
            self._websearch_results.append(
                self._websearch_result_row(result)
            )

    def _websearch_result_row(self, result):
        url = result.get("url") or ""
        title = result.get("title") or url or "Résultat"
        content = (result.get("content") or "").strip()
        row = Adw.ActionRow(title=title, subtitle=content or url)
        row.set_use_markup(True)
        open_button = Gtk.Button.new_from_icon_name("web-browser-symbolic")
        open_button.set_tooltip_text("Ouvrir le lien")
        open_button.add_css_class("flat")
        open_button.connect(
            "clicked", lambda *_a, u=url: self._open_external_url(u)
        )
        copy_button = Gtk.Button.new_from_icon_name("edit-copy-symbolic")
        copy_button.set_tooltip_text("Copier le lien")
        copy_button.add_css_class("flat")
        copy_button.connect(
            "clicked",
            lambda *_a, u=url: self._on_websearch_copy(u),
        )
        row.add_suffix(open_button)
        row.add_suffix(copy_button)
        return row

    def _on_websearch_copy(self, url):
        if self._write_clipboard(url):
            self._flash("Lien copié")

    def _open_external_url(self, uri):
        if not uri:
            return
        try:
            Gio.AppInfo.launch_default_for_uri(uri, None)
        except GLib.Error as error:
            self._show_notice("Impossible d’ouvrir le lien : " + error.message)

    def _artifact_widget(self, artifact):
        return conversation.artifact_widget(artifact, self)

    @staticmethod
    def _artifact_context_menu(uri):
        context_menu = Gio.Menu()
        for label, action in (
            ("Ouvrir le dossier dans Fichiers", "win.open-artifact-folder"),
            ("Télécharger / enregistrer une copie…", "win.save-artifact"),
        ):
            item = Gio.MenuItem.new(label, None)
            item.set_action_and_target_value(
                action, GLib.Variant.new_string(uri)
            )
            context_menu.append_item(item)
        return context_menu

    def _show_artifact_context_menu(self, gesture, _presses, x, y, box, menu):
        popover = Gtk.PopoverMenu.new_from_model(menu)
        popover.set_parent(box)
        popover.set_pointing_to(Gdk.Rectangle(x=int(x), y=int(y), width=1, height=1))
        popover.connect("closed", lambda current: current.unparent())
        popover.popup()

    def _open_artifact_folder(self, _action, parameter):
        path = self._local_path(parameter.get_string(), allow_directory=True)
        if path is None:
            self._show_notice("Le chemin local n’existe plus ou n’est pas accessible.")
            return
        folder = path if os.path.isdir(path) else os.path.dirname(path)
        folder_uri = Gio.File.new_for_path(folder).get_uri()
        try:
            Gio.AppInfo.launch_default_for_uri(folder_uri, None)
        except GLib.Error as error:
            self._show_notice("Impossible d’ouvrir le dossier : " + error.message)

    def _save_artifact(self, _action, parameter):
        source_uri = parameter.get_string()
        path = self._local_artifact_path(source_uri)
        if path is None:
            self._show_notice("Le fichier local n’existe plus ou n’est pas accessible.")
            return
        chooser = Gtk.FileChooserNative.new(
            "Enregistrer une copie",
            self,
            Gtk.FileChooserAction.SAVE,
            "Enregistrer",
            "Annuler",
        )
        chooser.set_current_name(os.path.basename(path))
        chooser.connect("response", self._on_save_artifact_response, path)
        chooser.show()

    def _on_save_artifact_response(self, chooser, response, source_path):
        if response == Gtk.ResponseType.ACCEPT:
            destination = chooser.get_file()
            if destination is not None:
                try:
                    Gio.File.new_for_path(source_path).copy(
                        destination, Gio.FileCopyFlags.NONE, None, None
                    )
                except GLib.Error as error:
                    self._show_notice("Impossible d’enregistrer la copie : " + error.message)
        chooser.destroy()

    def _open_artifact(self, uri):
        if self._local_artifact_path(uri) is None:
            self._show_notice("Le fichier local n’existe plus ou n’est pas accessible.")
            return
        try:
            Gio.AppInfo.launch_default_for_uri(uri, None)
        except GLib.Error as error:
            self._show_notice("Impossible d’ouvrir le fichier : " + error.message)

    def _scroll_messages_to_end(self):
        adjustment = self.message_scroller.get_vadjustment()
        bottom = max(
            adjustment.get_lower(),
            adjustment.get_upper() - adjustment.get_page_size(),
        )
        adjustment.set_value(bottom)
        self._update_scroll_bottom_visibility()
        return GLib.SOURCE_REMOVE

    def _update_scroll_bottom_visibility(self, *_args):
        adjustment = self.message_scroller.get_vadjustment()
        bottom = max(
            adjustment.get_lower(),
            adjustment.get_upper() - adjustment.get_page_size(),
        )
        away_from_bottom = bottom - adjustment.get_value() > 48
        self.scroll_bottom_button.set_visible(
            bool(self._selected_session) and away_from_bottom
        )
        return GLib.SOURCE_REMOVE

    def _show_notice(self, message):
        dialog = Adw.AlertDialog(heading="Perceptron", body=message)
        dialog.add_response("ok", "OK")
        dialog.present(self)

    def new_session(self):
        self.server.create_session(self._on_session_created)

    def _on_session_created(self, session, error):
        if error or not isinstance(session, dict) or not session.get("id"):
            self._show_notice(error or "OpenCode n’a pas renvoyé la nouvelle session.")
            return
        self._sessions[session["id"]] = session
        self.refresh_sessions()
        self.show_session(session["id"])

    def _confirm_delete_session(self, _action, parameter):
        session_id = parameter.get_string()
        session = self._sessions.get(session_id, {})
        title = session.get("title") or "cette session"
        dialog = Adw.AlertDialog(
            heading="Supprimer la session ?",
            body="« %s » et son historique seront supprimés définitivement." % title,
        )
        dialog.add_response("cancel", "Annuler")
        dialog.add_response("delete", "Supprimer")
        dialog.set_response_appearance("delete", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.set_default_response("cancel")
        dialog.connect("response", self._on_delete_confirmation, session_id)
        dialog.present(self)

    def _on_delete_confirmation(self, _dialog, response, session_id):
        if response != "delete":
            return
        self.server.delete_session(
            session_id,
            lambda _result, error: self._on_session_deleted(session_id, error),
        )

    def _on_session_deleted(self, session_id, error):
        if error:
            self._show_notice("Impossible de supprimer la session : " + error)
            return
        pages = [
            self.tab_view.get_nth_page(index)
            for index in range(self.tab_view.get_n_pages())
            if self._page_sessions.get(
                self.tab_view.get_nth_page(index).get_child()
            ) == session_id
        ]
        for page in pages:
            self.tab_view.close_page(page)
        self.refresh_sessions()

    def _toggle_pin_session(self, _action, parameter):
        session_id = parameter.get_string()
        if session_id in self._pinned_sessions:
            self._pinned_sessions.remove(session_id)
        else:
            self._pinned_sessions.add(session_id)
        saved = state.load()
        saved["pinned_sessions"] = sorted(self._pinned_sessions)
        state.save(saved)
        self._refresh_session_rows()

    def _toggle_archive_session(self, _action, parameter):
        session_id = parameter.get_string()
        session = self._sessions.get(session_id, {})
        archived = bool(session.get("time", {}).get("archived"))
        self.server.update_session(
            session_id,
            {"archived": not archived},
            lambda _result, error: self._on_session_archive_updated(error),
        )

    def _toggle_session_background(self, _action, parameter):
        """Passe une session en \"arrière-plan\" (outils bloquants sans
        interruption) via POST /api/session/{id}/background."""
        session_id = parameter.get_string()
        if not session_id or not self.server:
            return
        self.server.background_session(
            session_id,
            lambda _result, error: self._on_session_background_done(
                session_id, error
            ),
        )

    def _on_session_background_done(self, session_id, error):
        if error:
            self._show_notice(
                "Impossible de passer en arrière-plan : " + error
            )
            return
        self._show_notice("Session passée en arrière-plan.")
        session = self._sessions.get(session_id)
        if isinstance(session, dict):
            session["background"] = True
        self._refresh_session_rows()

    # ------------------------------------------------------------------ #
    # Terminal en appui (tiroir en bas, shell bash via PTY)                #
    # ------------------------------------------------------------------ #
    def _toggle_terminal(self, _button=None):
        revealed = self.terminal_revealer.get_child_revealed()
        self.terminal_revealer.set_reveal_child(not revealed)
        self.terminal_button.set_tooltip_text(
            "Masquer le terminal" if not revealed else "Afficher le terminal"
        )
        if not revealed:
            GLib.idle_add(self.terminal_entry.grab_focus)

    def _start_terminal(self):
        if self._term_proc is not None and self._term_proc.poll() is None:
            return
        try:
            master, slave = pty.openpty()
        except OSError as error:
            self._show_notice("Impossible d’ouvrir le terminal : " + str(error))
            return
        try:
            self._term_proc = subprocess.Popen(
                ["bash", "--noprofile", "--norc"],
                stdin=slave, stdout=slave, stderr=slave,
                close_fds=True,
            )
        except OSError as error:
            self._show_notice("Impossible de lancer bash : " + str(error))
            os.close(master)
            os.close(slave)
            return
        os.close(slave)
        self._term_master = master
        self._term_append_text("Terminal prêt — tapez une commande et validez.\n", "prompt")
        self._term_thread = threading.Thread(
            target=self._term_read_loop, daemon=True
        )
        self._term_thread.start()

    def _term_read_loop(self):
        while self._term_proc is not None and self._term_proc.poll() is None:
            try:
                ready, _, _ = select.select([self._term_master], [], [], 0.2)
                if not ready:
                    continue
                data = os.read(self._term_master, 4096)
                if not data:
                    break
                text = self._strip_ansi(data.decode("utf-8", errors="replace"))
                GLib.idle_add(self._term_append_text, text)
            except OSError:
                break
        GLib.idle_add(self._term_append_text, "\n[Shell terminé]\n")

    def _term_append_text(self, text, tag=None):
        if self._term_buffer is None:
            return False
        end = self._term_buffer.get_end_iter()
        if tag:
            self._term_buffer.insert_with_tags(end, text, tag)
        else:
            self._term_buffer.insert(end, text)
        mark = self._term_buffer.create_mark(None, end, False)
        self.terminal_view.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)
        self._term_buffer.delete_mark(mark)
        return False

    def _term_write(self, data):
        if self._term_master is None:
            return
        try:
            os.write(self._term_master, data.encode("utf-8", errors="replace"))
        except OSError:
            pass

    @staticmethod
    def _strip_ansi(text):
        text = re.sub(r"\x1b\[[0-9;?]*[a-zA-Z]", "", text)
        text = re.sub(r"\x1b\].*?\x07", "", text)
        text = re.sub(r"\x1b[()][A-B0-9]", "", text)
        return text

    def _on_terminal_enter(self, _widget):
        self._start_terminal()
        cmd = self.terminal_entry.get_text()
        if not cmd.strip():
            return
        self.terminal_entry.set_text("")
        end = self._term_buffer.get_end_iter()
        self._term_buffer.insert_with_tags(end, "$ " + cmd + "\n", "prompt")
        mark = self._term_buffer.create_mark(None, end, False)
        self.terminal_view.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)
        self._term_buffer.delete_mark(mark)
        self._term_write(cmd + "\n")

    def _on_terminal_stop(self, _widget):
        self._term_write("\x03")

    def _on_terminal_clear(self, _widget):
        if self._term_buffer is not None:
            self._term_buffer.set_text("")

    def _on_terminal_key(self, _controller, keyval, keycode, state):
        if (
            keyval == Gdk.KEY_backquote
            and (state & Gdk.ModifierType.CONTROL_MASK)
        ):
            self._toggle_terminal()
            return True
        return False


    def _on_session_archive_updated(self, error):
        if error:
            self._show_notice("Impossible d’archiver la session : " + error)
            return
        self.refresh_sessions()

    def _rename_session(self, _action, parameter):
        session_id = parameter.get_string()
        session = self._sessions.get(session_id, {})
        dialog = Adw.Dialog()
        dialog.set_title("Renommer la session")
        dialog.set_content_width(460)
        toolbar = Adw.ToolbarView()
        header = Adw.HeaderBar(show_end_title_buttons=False)
        cancel = Gtk.Button(label="Annuler")
        cancel.connect("clicked", lambda *_: dialog.close())
        header.pack_start(cancel)
        save = Gtk.Button(label="Renommer")
        save.add_css_class("suggested-action")
        header.pack_end(save)
        toolbar.add_top_bar(header)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.set_margin_start(18)
        box.set_margin_end(18)
        box.set_margin_top(18)
        box.set_margin_bottom(18)
        box.append(
            Gtk.Label(
                label="Nouveau titre",
                xalign=0,
                css_classes=["dim-label"],
            )
        )
        entry = Gtk.Entry(text=session.get("title") or "")
        entry.set_activates_default(True)
        entry.set_hexpand(True)
        box.append(entry)
        toolbar.set_content(box)
        dialog.set_child(toolbar)
        entry.connect(
            "activate",
            lambda *_: self._apply_session_rename(dialog, session_id, entry),
        )
        save.connect(
            "clicked",
            lambda *_: self._apply_session_rename(dialog, session_id, entry),
        )
        dialog.present(self)
        entry.grab_focus()
        entry.select_region(0, -1)

    def _apply_session_rename(self, dialog, session_id, entry):
        title = entry.get_text().strip()
        if not title:
            self._flash("Le titre ne peut pas être vide.")
            return
        dialog.close()
        self.server.update_session(
            session_id,
            {"title": title},
            lambda _result, error: self._on_session_renamed(
                session_id, title, error
            ),
        )

    def _on_session_renamed(self, session_id, title, error):
        if error:
            self._show_notice("Impossible de renommer la session : " + error)
            return
        session = self._sessions.get(session_id)
        if isinstance(session, dict):
            session["title"] = title
        for index in range(self.tab_view.get_n_pages()):
            page = self.tab_view.get_nth_page(index)
            child = page.get_child() if page is not None else None
            if self._page_sessions.get(child) == session_id:
                page.set_title(title)
        self._refresh_session_rows()
        self.refresh_sessions()
        self._show_notice("Session renommée.")

    def _fork_message(self, _action, parameter):
        session_id, message_id = parameter.unpack()
        self.server.fork_session(
            session_id,
            message_id,
            lambda session, error: self._on_session_forked(session, error),
        )

    def _on_session_forked(self, session, error):
        if error or not isinstance(session, dict) or not session.get("id"):
            self._show_notice(error or "OpenCode n’a pas renvoyé la session issue du fork.")
            return
        self._sessions[session["id"]] = session
        self.refresh_sessions()
        self.show_session(session["id"])

    @staticmethod
    def _should_send_on_key(keyval, modifiers):
        return keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter) and not (
            modifiers & Gdk.ModifierType.SHIFT_MASK
        )

    def _on_prompt_key_pressed(self, _controller, keyval, _keycode, modifiers):
        if self._should_send_on_key(keyval, modifiers):
            self.send_prompt()
            return True
        return False

    def _default_folder(self, category):
        saved = state.load()
        stored = saved.get("folder_" + category)
        return os.path.expanduser(
            stored or self.DEFAULT_FOLDERS.get(category, "~")
        )

    def _choose_prompt_attachments(self, _button=None, category="all"):
        chooser = Gtk.FileChooserNative.new(
            "Ajouter des pièces jointes",
            self,
            Gtk.FileChooserAction.OPEN,
            "Ajouter",
            "Annuler",
        )
        chooser.set_select_multiple(True)
        folder = self._default_folder(category)
        if os.path.isdir(folder):
            try:
                chooser.set_current_folder(Gio.File.new_for_path(folder))
            except Exception:
                pass
        if category == "images":
            filter_images = Gtk.FileFilter()
            filter_images.set_name("Images")
            filter_images.add_mime_type("image/*")
            chooser.add_filter(filter_images)
        elif category == "archives":
            filter_archives = Gtk.FileFilter()
            filter_archives.set_name("Archives / paquets")
            for mime in (
                "application/zip",
                "application/x-tar",
                "application/gzip",
                "application/x-compressed-tar",
                "application/zstd",
                "application/vnd.debian.binary-package",
            ):
                filter_archives.add_mime_type(mime)
            filter_archives.add_pattern("*.zip")
            filter_archives.add_pattern("*.tar*")
            filter_archives.add_pattern("*.zst")
            filter_archives.add_pattern("*.pkg.tar.zst")
            chooser.add_filter(filter_archives)
        chooser.connect("response", self._on_prompt_files_chosen)
        chooser.show()

    def _on_prompt_files_chosen(self, chooser, response):
        if response == Gtk.ResponseType.ACCEPT:
            files = chooser.get_files()
            for index in range(files.get_n_items()):
                file = files.get_item(index)
                self._add_prompt_file(file.get_uri(), file.get_path())
            self._refresh_prompt_attachments()
        chooser.destroy()

    def _add_prompt_file(self, uri, path):
        if not path or not os.path.isfile(path):
            self._show_notice("Les pièces jointes doivent être des fichiers locaux.")
            return
        if not any(item["uri"] == uri for item in self._prompt_files):
            self._prompt_files.append({
                "uri": uri,
                "name": os.path.basename(path),
            })

    def _on_prompt_drop(self, _target, value, _x, _y):
        """Ajoute les fichiers glissés depuis le gestionnaire de fichiers."""
        try:
            for index in range(value.get_n_items()):
                file = value.get_item(index)
                self._add_prompt_file(file.get_uri(), file.get_path())
        except (AttributeError, TypeError):
            return False
        if self._prompt_files:
            self._refresh_prompt_attachments()
        return True

    def _on_prompt_buffer_changed_placeholder(self, _buffer):
        self._update_prompt_placeholder()

    def _update_prompt_placeholder(self):
        placeholder = getattr(self, "prompt_placeholder", None)
        if placeholder is None:
            return
        buffer = self.prompt.get_buffer()
        start, end = buffer.get_bounds()
        empty = not buffer.get_text(start, end, False).strip()
        placeholder.set_visible(empty)

    def _build_composer_handle(self, container):
        """Poignée au-dessus de la zone de saisie pour la redimensionner à la
        souris (hauteur mémorisée entre les sessions)."""
        handle = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, height_request=18)
        handle.set_halign(Gtk.Align.FILL)
        handle.set_hexpand(True)
        handle.set_cursor_from_name("row-resize")
        handle.set_tooltip_text(
            "Glisser vers le haut ou le bas pour agrandir la zone de saisie"
        )
        grip = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            width_request=56,
            height_request=5,
        )
        grip.set_halign(Gtk.Align.CENTER)
        grip.set_valign(Gtk.Align.CENTER)
        grip.add_css_class("composer-grip")
        handle.append(grip)
        gesture = Gtk.GestureDrag()
        gesture.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        gesture.connect("drag-begin", self._on_composer_drag_begin)
        gesture.connect("drag-update", self._on_composer_drag_update)
        gesture.connect("drag-end", self._on_composer_drag_end)
        handle.add_controller(gesture)
        self.prompt_handle = handle
        container.append(handle)
        if self._composer_height:
            self._apply_composer_height(self._composer_height)

    def _apply_composer_height(self, height):
        height = int(min(420, max(52, height)))
        self._composer_height = height
        self.prompt.set_size_request(-1, height)
        if hasattr(self, "prompt_scroll"):
            self.prompt_scroll.set_min_content_height(height)

    def _on_composer_drag_begin(self, gesture, _start_x, start_y):
        self._composer_drag_base = self._composer_height
        self._composer_drag_y = start_y

    def _on_composer_drag_update(self, gesture, _x, y):
        delta = int(y - self._composer_drag_y)
        # Le geste descend = agrandir la zone de saisie.
        self._apply_composer_height(self._composer_drag_base + delta)

    def _on_composer_drag_end(self, _gesture, _x, _y):
        saved = state.load()
        if self._composer_height <= 52:
            saved.pop("composer_height", None)
        else:
            saved["composer_height"] = self._composer_height
        state.save(saved)

    def _refresh_prompt_attachments(self):
        child = self.prompt_attachment_box.get_first_child()
        while child:
            following = child.get_next_sibling()
            self.prompt_attachment_box.remove(child)
            child = following
        for item in self._prompt_files:
            chip = Gtk.Button(label=item["name"])
            chip.add_css_class("pill")
            chip.set_tooltip_text("Retirer la pièce jointe")
            chip.connect("clicked", self._remove_prompt_attachment, item["uri"])
            self.prompt_attachment_box.append(chip)
        self.prompt_attachment_box.set_visible(bool(self._prompt_files))

    def _remove_prompt_attachment(self, _button, uri):
        self._prompt_files = [
            item for item in self._prompt_files if item["uri"] != uri
        ]
        self._refresh_prompt_attachments()

    def _edit_last_message(self, *_):
        if not self._last_user_message:
            return
        self._editing_message_id = self._last_user_message["id"]
        self.prompt.get_buffer().set_text(self._last_user_message["text"])
        self._save_current_draft()
        self.prompt.grab_focus()

    def _confirm_regenerate_last_message(self, *_):
        if not self._last_user_message:
            return
        dialog = Adw.AlertDialog(
            heading="Régénérer la dernière réponse ?",
            body=(
                "La conversation sera ramenée au dernier message utilisateur puis "
                "ce message sera renvoyé. Le brouillon actuel du champ de réponse "
                "sera remplacé."
            ),
        )
        dialog.add_response("cancel", "Annuler")
        dialog.add_response("regenerate", "Régénérer")
        dialog.set_response_appearance("regenerate", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.set_default_response("cancel")
        dialog.connect("response", self._on_regenerate_confirmation)
        dialog.present(self)

    def _on_regenerate_confirmation(self, _dialog, response):
        if response != "regenerate" or not self._last_user_message:
            return
        self._editing_message_id = self._last_user_message["id"]
        self.prompt.get_buffer().set_text(self._last_user_message["text"])
        self.send_prompt()

    def _confirm_reset_to_message(self, _button, message_id):
        if not self._selected_session:
            return
        dialog = Adw.AlertDialog(
            heading="Réinitialiser la conversation ici ?",
            body=(
                "La conversation sera ramenée à ce message utilisateur : tous "
                "les messages suivants seront supprimés. Cette action est "
                "irréversible."
            ),
        )
        dialog.add_response("cancel", "Annuler")
        dialog.add_response("reset", "Réinitialiser")
        dialog.set_response_appearance("reset", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.set_default_response("cancel")
        dialog.connect(
            "response", self._on_reset_confirmation, message_id
        )
        dialog.present(self)

    def _on_reset_confirmation(self, _dialog, response, message_id):
        if response != "reset" or not self._selected_session:
            return
        session_id = self._selected_session
        journal.log("reset : session=%s message=%s" % (session_id, message_id))
        self.server.stage_revert(
            session_id, message_id,
            lambda _stage, error: self._on_reset_staged(
                session_id, message_id, error
            ),
        )

    def _on_reset_staged(self, session_id, message_id, error):
        if error:
            self._show_notice("Impossible de réinitialiser : " + error)
            return
        journal.log("reset : staged ok, commit")
        self.server.commit_revert(
            session_id, lambda _commit, commit_error: self._on_reset_committed(
                session_id, commit_error
            ),
        )

    def _on_reset_committed(self, session_id, error):
        if error:
            self._show_notice("Impossible de réinitialiser : " + error)
            return
        self._show_notice("Conversation réinitialisée.")
        self.refresh_sessions()
        if session_id == self._selected_session:
            self._load_messages(session_id)

    def _insert_markdown(self, _button, prefix, suffix, placeholder):
        buffer = self.prompt.get_buffer()
        if buffer.get_has_selection():
            start, end = buffer.get_selection_bounds()
            selected = buffer.get_text(start, end, False)
            offset = start.get_offset()
            replacement = prefix + selected + suffix
            buffer.delete(start, end)
            buffer.insert(buffer.get_iter_at_offset(offset), replacement)
            buffer.place_cursor(
                buffer.get_iter_at_offset(offset + len(prefix) + len(selected))
            )
            return
        cursor = buffer.get_iter_at_mark(buffer.get_insert())
        text = prefix + placeholder + suffix
        offset = cursor.get_offset()
        buffer.insert(cursor, text)
        placeholder_start = buffer.get_iter_at_offset(offset + len(prefix))
        placeholder_end = buffer.get_iter_at_offset(
            offset + len(prefix) + len(placeholder)
        )
        buffer.select_range(placeholder_end, placeholder_start)

    @staticmethod
    def _add_menu_row(icon_name, label):
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        row.append(Gtk.Image(icon_name=icon_name))
        row.append(Gtk.Label(label=label, xalign=0))
        return row

    def _on_add_category_clicked(self, _button, category):
        self._choose_prompt_attachments(None, category)

    def _insert_color(self, _button, color):
        self._insert_markdown(None, "{{%s:" % color, "}}", "texte")

    def _insert_table(self, _button=None):
        skeleton = (
            "| Colonne 1 | Colonne 2 |\n"
            "|---|---|\n"
            "| valeur | valeur |\n"
        )
        buffer = self.prompt.get_buffer()
        cursor = buffer.get_iter_at_mark(buffer.get_insert())
        buffer.insert(cursor, skeleton)
        self.prompt.grab_focus()

    def send_prompt(self, delivery=None):
        if self._sending_prompt:
            journal.log("envoi : ignoré, _sending_prompt déjà vrai")
            return
        if not self._selected_session:
            journal.log("envoi : ignoré, aucune session sélectionnée")
            self._show_notice("Sélectionne ou crée une session avant d’envoyer un message.")
            return
        buffer = self.prompt.get_buffer()
        start, end = buffer.get_bounds()
        text = buffer.get_text(start, end, False).strip()
        if not text:
            return
        session_id = self._selected_session
        journal.log("envoi : session=%s texte=%d" % (session_id, len(text)))
        sent_files = list(self._prompt_files)
        self._save_current_draft()
        if session_id in self._invalid_sessions:
            self._show_stale_prompt_recovery(
                session_id,
                text,
                sent_files,
                delivery,
                "OpenCode ne connaît plus la session sélectionnée.",
            )
            return
        pending = self._pending_context_switches.get(session_id)
        if pending:
            if self._queued_prompt is None:
                self._queued_prompt = {
                    "session_id": session_id,
                    "text": text,
                    "files": sent_files,
                    "delivery": delivery,
                    "editing_message_id": self._editing_message_id,
                }
                self._show_notice(
                    "Le message sera envoyé après le changement de modèle ou d’agent."
                )
            else:
                self._show_notice(
                    "Un message attend déjà la fin du changement de modèle ou d’agent."
                )
            return
        self._start_prompt(
            session_id, text, delivery, sent_files, self._editing_message_id
        )

    def _start_prompt(self, session_id, text, delivery, sent_files, editing_message_id):
        if self._sending_prompt:
            return
        self._sending_prompt = True
        self._update_send_sensitivity()
        if editing_message_id:
            self.server.stage_revert(
                session_id,
                editing_message_id,
                lambda _result, error: self._on_rewrite_staged(
                    session_id,
                    editing_message_id,
                    text,
                    delivery,
                    sent_files,
                    error,
                ),
            )
            return
        self._dispatch_prompt(session_id, text, delivery, sent_files)

    def _on_rewrite_staged(
        self, session_id, message_id, text, delivery, files, error
    ):
        if error:
            self._sending_prompt = False
            self._update_send_sensitivity()
            self._show_notice("Impossible de préparer la modification : " + error)
            return
        self.server.commit_revert(
            session_id,
            lambda _result, commit_error: self._on_rewrite_committed(
                session_id, message_id, text, delivery, files, commit_error
            ),
        )

    def _on_rewrite_committed(
        self, session_id, message_id, text, delivery, files, error
    ):
        if error:
            self.server.clear_staged_revert(session_id, lambda *_: None)
            self._sending_prompt = False
            self._update_send_sensitivity()
            self._show_notice("Impossible de réécrire la conversation : " + error)
            return
        if self._selected_session == session_id:
            self._editing_message_id = None
        self._dispatch_prompt(session_id, text, delivery, files)

    def _dispatch_prompt(self, session_id, text, delivery, files):
        self.server.send_prompt(
            session_id,
            text,
            lambda result, error: self._on_prompt_sent(
                session_id, text, files, delivery, result, error
            ),
            delivery=delivery,
            files=files,
        )

    def _on_prompt_sent(
        self, session_id, sent_text, sent_files, delivery, _result, error
    ):
        self._sending_prompt = False
        self._update_send_sensitivity()
        if error:
            journal.log("envoi : ERREUR → %s" % error)
            if self._is_session_not_found_error(error):
                self._mark_session_stale(session_id, error)
                self.refresh_sessions()
                self._show_stale_prompt_recovery(
                    session_id, sent_text, sent_files, delivery, error
                )
                return
            self._offer_prompt_retry(
                session_id, sent_text, sent_files, delivery, error
            )
            return
        journal.log("envoi : OK")
        draft = self._prompt_drafts.get(session_id, {})
        current_text = draft.get("text", sent_text)
        current_files = draft.get("files", sent_files)
        if self._selected_session == session_id:
            buffer = self.prompt.get_buffer()
            start, end = buffer.get_bounds()
            current_text = buffer.get_text(start, end, False)
            current_files = self._prompt_files
        sent_uris = {item["uri"] for item in sent_files}
        remaining_files = [
            item for item in current_files if item["uri"] not in sent_uris
        ]
        unchanged = self._should_clear_prompt(current_text, sent_text, error)
        self._prompt_drafts[session_id] = {
            "text": "" if unchanged else current_text,
            "files": remaining_files,
        }
        if self._selected_session == session_id:
            self._prompt_files = remaining_files
            if unchanged:
                buffer.set_text("")
            self._refresh_prompt_attachments()
        if self._selected_session == session_id:
            self._editing_message_id = None
        if self._selected_session == session_id:
            self._load_messages(session_id)

    def _offer_prompt_retry(self, session_id, text, files, delivery, error):
        dialog = Adw.AlertDialog(
            heading="Envoi du message impossible",
            body=(
                error + "\n\nLe brouillon et les pièces jointes sont conservés."
            ),
        )
        dialog.add_response("keep", "Garder le brouillon")
        dialog.add_response("retry", "Réessayer")
        dialog.set_default_response("retry")
        dialog.connect(
            "response", self._on_prompt_retry_response,
            session_id, text, files, delivery,
        )
        dialog.present(self)

    def _on_prompt_retry_response(
        self, _dialog, response, session_id, text, files, delivery
    ):
        if response == "retry":
            self._sending_prompt = True
            self._update_send_sensitivity()
            self._dispatch_prompt(session_id, text, delivery, files)

    @staticmethod
    def _should_clear_prompt(current_text, sent_text, error):
        # Comparaison insensible aux espaces de bord : un tableau inséré se
        # termine par un saut de ligne, et le texte envoyé est « stripé ».
        # Sans cela, le message expédié restait affiché dans le compositeur.
        return error is None and current_text.strip() == sent_text.strip()

    def toggle_sidebar(self):
        # Avec Gtk.Paned, « masquer » la barre latérale revient à rendre le
        # conteneur latéral insensible et invisible (il garde sa largeur).
        visible = self._sidebar_content.get_visible()
        self._sidebar_content.set_visible(not visible)
        self._sidebar_content.set_sensitive(not visible)
        self.sidebar_button.set_icon_name(
            "sidebar-show-symbolic" if visible else "sidebar-hide-symbolic"
        )
        self.sidebar_button.set_tooltip_text(
            "Masquer la liste des sessions" if visible
            else "Afficher la liste des sessions"
        )

    def _on_server_event(self, _server, kind, data):
        # Les événements SSE arrivent en rafale (un par mise à jour de part,
        # donc plusieurs dizaines par seconde pendant une réponse). On
        # regroupe (debounce) les rafraîchissements : sinon chaque événement
        # déclenche une requête "sessions actives" + un rechargement complet
        # des messages, ce qui rend le chargement lent et fait scintiller la
        # barre latérale.
        if kind.startswith("session."):
            if kind in (
                "session.created",
                "session.updated",
                "session.renamed",
                "session.deleted",
            ):
                self._schedule_session_refresh()
            self._schedule_active_refresh()
        elif kind.startswith("message."):
            self._schedule_active_refresh()
            if data.get("sessionID") == self._selected_session:
                self._schedule_message_reload()

    def _schedule_active_refresh(self):
        if self._active_refresh_timeout:
            return
        self._active_refresh_timeout = GLib.timeout_add(
            200, self._run_active_refresh
        )

    def _run_active_refresh(self):
        self._active_refresh_timeout = 0
        self.refresh_active_sessions()
        return GLib.SOURCE_REMOVE

    def _schedule_message_reload(self):
        if self._message_reload_timeout:
            return
        self._message_reload_timeout = GLib.timeout_add(
            150, self._run_message_reload
        )

    def _run_message_reload(self):
        self._message_reload_timeout = 0
        if self._selected_session:
            self._load_messages(self._selected_session)
        return GLib.SOURCE_REMOVE

    def _flush_pending_refreshes(self):
        """Exécute immédiatement les rafraîchissements différés puis nettoie."""
        if self._active_refresh_timeout:
            GLib.source_remove(self._active_refresh_timeout)
            self._active_refresh_timeout = 0
            self.refresh_active_sessions()
        if self._message_reload_timeout:
            GLib.source_remove(self._message_reload_timeout)
            self._message_reload_timeout = 0
            if self._selected_session:
                self._load_messages(self._selected_session)

    def on_fullscreen(self, *_):
        if self.is_fullscreen():
            self.unfullscreen()
        else:
            self.fullscreen()

    def on_shortcuts(self, *_):
        section = Adw.ShortcutsSection(title="Général")
        for accelerator, title in SHORTCUTS:
            section.add(Adw.ShortcutsItem(title=title, accelerator=accelerator))
        dialog = Adw.ShortcutsDialog()
        dialog.add(section)
        dialog.present(self)

    def on_about(self, *_):
        Adw.AboutDialog(
            application_name=APP_NAME,
            application_icon=APP_ID,
            version=VERSION,
            comments="Interface GTK4/libadwaita native pour OpenCode",
            developer_name="ogu",
            website="https://gitlab.com/ogu/opencode-gtk",
            license_type=Gtk.License.MIT_X11,
        ).present(self)

    def _on_stop_on_close_toggled(self, row, _pspec):
        saved = state.load()
        saved["stop_on_close"] = bool(row.get_active())
        state.save(saved)

    def _show_preferences(self, *_):
        owns = opencode.owns_server()
        stop_switch = Adw.SwitchRow(
            title="Arrêter OpenCode en quittant" if owns
            else "Arrêter OpenCode en quittant (serveur partagé)",
            subtitle=(
                "Stoppe uniquement le serveur lancé par Perceptron. "
                "Une instance déjà partagée (terminal, autre client) "
                "reste intacte."
                if owns
                else (
                    "Un serveur OpenCode externe est actuellement utilisé : "
                    "il n'est pas stoppé à la fermeture de Perceptron."
                )
            ),
            active=self._should_stop_on_close(),
        )
        # On ne peut pas arrêter un serveur que l'on n'a pas lancé.
        stop_switch.set_sensitive(owns)
        stop_switch.connect("notify::active", self._on_stop_on_close_toggled)
        group = Adw.PreferencesGroup(title="Fermeture")
        group.add(stop_switch)
        page = Adw.PreferencesPage()
        page.add(group)

        # Dossiers de départ par catégorie du menu « Ajouter » : modifiables
        # via un sélecteur de répertoire (pickeur). Chaque clic ouvre un
        # FileChooserFolder ; le choix est stocké dans l'état.
        folders = Adw.PreferencesGroup(
            title="Dossiers du menu Ajouter",
            description=(
                "Choisis le répertoire de départ affiché par le sélecteur "
                "de fichiers de chaque catégorie."
            ),
        )
        for label, category in (
            ("Images", "images"),
            ("Archives / paquets", "archives"),
            ("Tous les fichiers", "all"),
        ):
            row = Adw.ActionRow(title=label)
            path_label = Gtk.Label(xalign=0, wrap=True)
            path_label.add_css_class("dim-label")
            row.add_suffix(path_label)
            picker = Gtk.Button(label="Choisir…")
            picker.add_css_class("flat")
            picker.set_valign(Gtk.Align.CENTER)
            picker.connect(
                "clicked", self._on_pick_default_folder, category, path_label
            )
            row.add_suffix(picker)
            row.set_activatable_widget(picker)
            self._refresh_folder_row(path_label, category)
            folders.add(row)
        page.add(folders)

        # --- Recherche web : fournisseur utilisé par le bouton du compositeur ---
        websearch_group = Adw.PreferencesGroup(
            title="Recherche web",
            description=(
                "Fournisseur utilisé par le bouton « Rechercher sur le web » "
                "du compositeur."
            ),
        )
        self._websearch_providers = []
        self._websearch_provider_map = {}
        provider_row = Adw.ActionRow(
            title="Fournisseur de recherche",
            subtitle="Chargement…",
        )
        self._websearch_provider_model_prefs = Gtk.StringList()
        self._websearch_provider_dropdown_prefs = Gtk.DropDown(
            model=self._websearch_provider_model_prefs
        )
        self._websearch_provider_dropdown_prefs.set_valign(Gtk.Align.CENTER)
        provider_row.add_suffix(self._websearch_provider_dropdown_prefs)
        self._websearch_provider_row_prefs = provider_row
        self._websearch_provider_dropdown_prefs.connect(
            "notify::selected", self._on_websearch_provider_pref_changed
        )
        websearch_group.add(provider_row)
        page.add(websearch_group)

        # --- Configuration OpenCode : module dédié (lecture / PATCH) ---
        config_group = Adw.PreferencesGroup(
            title="Configuration OpenCode",
            description=(
                "Lit la configuration du serveur et modifie les champs exposés "
                "par l’API expérimentale."
            ),
        )
        self.server.get_config(
            lambda docs, error: self._populate_config_group(
                config_group, docs, error
            )
        )
        page.add(config_group)

        self.load_websearch_providers()

        header = Adw.HeaderBar()
        close_button = Gtk.Button(
            icon_name="window-close-symbolic", tooltip_text="Fermer"
        )
        close_button.connect("clicked", lambda *_: self._preferences_dialog.close())
        header.pack_end(close_button)

        toolbar = Adw.ToolbarView(content=page)
        toolbar.add_top_bar(header)
        self._preferences_dialog = Adw.Dialog()
        self._preferences_dialog.set_title("Préférences")
        self._preferences_dialog.set_content_width(480)
        self._preferences_dialog.set_child(toolbar)
        self._preferences_dialog.present(self)

    def _refresh_folder_row(self, path_label, category):
        folder = self._default_folder(category)
        path_label.set_text(folder)

    def _on_pick_default_folder(self, _button, category, path_label):
        chooser = Gtk.FileChooserNative.new(
            "Dossier de départ — %s" % category,
            self,
            Gtk.FileChooserAction.SELECT_FOLDER,
            "Choisir",
            "Annuler",
        )
        current = self._default_folder(category)
        if os.path.isdir(current):
            try:
                chooser.set_current_folder(Gio.File.new_for_path(current))
            except Exception:
                pass
        chooser.connect("response", self._on_default_folder_picked,
                        category, path_label)
        chooser.show()

    def _on_default_folder_picked(self, chooser, response, category, path_label):
        if response == Gtk.ResponseType.ACCEPT:
            path = chooser.get_file().get_path()
            if path:
                saved = state.load()
                saved["folder_" + category] = path
                state.save(saved)
                self._refresh_folder_row(path_label, category)
        chooser.destroy()

    def _show_memory(self, *_):
        """Édite les instructions globales persistantes d'OpenCode.

        Elles sont stockées dans ``systemPrompt`` du fichier
        ``~/.config/opencode/opencode.json``. Une sauvegarde horodatée est
        créée avant toute écriture.
        """
        path = os.path.expanduser("~/.config/opencode/opencode.json")
        try:
            with open(path, encoding="utf-8") as handle:
                data = json.load(handle)
        except (OSError, ValueError) as exc:
            self._show_notice(
                "Impossible de lire la configuration OpenCode : %s" % exc
            )
            return
        dialog = Adw.Dialog()
        dialog.set_title("Mémoire d’OpenCode")
        dialog.set_content_width(640)
        toolbar = Adw.ToolbarView()
        header = Adw.HeaderBar(show_end_title_buttons=False)
        cancel = Gtk.Button(label="Annuler")
        cancel.connect("clicked", lambda *_: dialog.close())
        header.pack_start(cancel)
        save = Gtk.Button(label="Enregistrer")
        save.add_css_class("suggested-action")
        header.pack_end(save)
        toolbar.add_top_bar(header)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.set_margin_start(18)
        box.set_margin_end(18)
        box.set_margin_top(14)
        box.set_margin_bottom(18)
        box.append(
            Gtk.Label(
                label=(
                    "Instructions permanentes appliquées à toutes les "
                    "sessions OpenCode (systemPrompt global)."
                ),
                xalign=0,
                wrap=True,
                css_classes=["dim-label"],
            )
        )
        text_view = Gtk.TextView(
            wrap_mode=Gtk.WrapMode.WORD_CHAR,
            left_margin=12,
            right_margin=12,
            top_margin=10,
            bottom_margin=10,
        )
        text_view.get_buffer().set_text(data.get("systemPrompt") or "")
        scroller = Gtk.ScrolledWindow(
            min_content_height=360,
            hscrollbar_policy=Gtk.PolicyType.NEVER,
        )
        scroller.set_child(text_view)
        scroller.add_css_class("card")
        box.append(scroller)
        toolbar.set_content(box)
        dialog.set_child(toolbar)

        def _save_memory():
            buffer = text_view.get_buffer()
            start, end = buffer.get_bounds()
            content = buffer.get_text(start, end, False)
            data["systemPrompt"] = content
            try:
                backup = path + ".bak-memoire-" + time.strftime(
                    "%Y%m%d-%H%M%S"
                )
                shutil.copy2(path, backup)
                with open(path, "w", encoding="utf-8") as handle:
                    json.dump(data, handle, indent=2, ensure_ascii=False)
                    handle.write("\n")
            except OSError as exc:
                self._show_notice("Impossible d’enregistrer : %s" % exc)
                return
            dialog.close()
            self._show_notice(
                "Mémoire enregistrée. Redémarre OpenCode pour l’appliquer."
            )

        save.connect("clicked", lambda *_: _save_memory())
        dialog.present(self)

    def on_close_request(self, *_):
        if self._closing:
            return False
        self._save_state()
        # Fermeture directe : pas de dialogue modal. Le comportement est
        # piloté par la préférence « Arrêter OpenCode en quittant ».
        # Si le serveur est un partage (déjà lancé ailleurs), stop_service()
        # est un no-op : l'instance externe (terminal…) n'est jamais touchée.
        self._begin_shutdown(stop=self._should_stop_on_close())
        return True

    @staticmethod
    def _should_stop_on_close():
        return bool(state.load().get("stop_on_close", True))

    def _save_state(self):
        width, height = self.get_default_size()
        saved = state.load()
        saved.update({
            "width": width,
            "height": height,
            "maximized": self.is_maximized(),
            "last_session": getattr(self, "_selected_session", None),
        })
        state.save(saved)

    def _begin_shutdown(self, stop=False):
        if self._closing:
            return
        self._closing = True
        self.notifier.destroy()
        self.server.destroy()
        if stop:
            opencode.stop_service()
        self.get_application().quit()
