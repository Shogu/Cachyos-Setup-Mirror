"""Présentation de la conversation : outils et artefacts.

Module de présentation : construit les widgets GTK/Adwaita des morceaux
de conversation dans des conteneurs fournis par la fenêtre. La fenêtre
garde l'orchestration et délègue ici le rendu de ses blocs (appels
d'outils, fichiers/images générés), qui réutilisent ses helpers éprouvés.

Les actions (ouvrir, copier, menu contextuel…) sont des raccourcis vers
la fenêtre ou des actions de l'application (''win.*'').
"""

from gi.repository import Adw, Gdk, GdkPixbuf, Gio, GLib, Gtk


def render_tool(container, part, window):
    """Dépouille un appel d'outil sans l'afficher.

    Conforme à opencode (URL / terminal) : les appels d'outils
    intermédiaires (shell, glob…) et leur sortie ne sont PAS montrés dans
    le fil — ils restent du bruit visuel ("blobs") qui encombre la
    conversation et alourdit beaucoup le rendu (des centaines de widgets
    par grosse session, d'où l'affichage en retard).

    Par contre, on continue à COLLECTER les fichiers / images générés par
    l'outil : ce sont des artefacts réels que opencode affiche, et qui
    apparaissent via window._artifacts. Le conteneur n'est donc jamais
    rempli ici.
    """
    state = part.get("state")
    state = state if isinstance(state, dict) else {}
    for item in state.get("content", []):
        if isinstance(item, dict) and item.get("type") == "file":
            window._collect_artifact(
                item.get("uri", ""),
                item.get("mime", "application/octet-stream"),
                item.get("name"),
            )


def artifact_widget(artifact, window):
    """Construit la carte d'un artefact (fichier/image généré) dans *window*.

    Délègue à la fenêtre le menu contextuel, l'ouverture et la collecte
    (helpers éprouvés) pour un comportement identique à l'ancien
    `_artifact_widget` de la fenêtre. La présentation vit ici.
    """
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
    box.add_css_class("card")
    box.set_margin_top(8)
    box.set_margin_bottom(8)
    box.set_margin_start(8)
    box.set_margin_end(8)
    title = Adw.ActionRow(
        title=artifact["name"],
        subtitle=artifact["mime"] or "Fichier local",
    )
    box.append(title)
    if artifact["mime"].startswith("image/"):
        try:
            pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                artifact["path"], 480, 300, True
            )
            if pixbuf:
                picture = Gtk.Picture.new_for_pixbuf(pixbuf)
                picture.set_content_fit(Gtk.ContentFit.CONTAIN)
                picture.set_size_request(320, 180)
                box.append(picture)
        except GLib.Error as error:
            preview_error = Adw.ActionRow(
                title="Aperçu de l’image indisponible",
                subtitle=error.message,
            )
            preview_error.add_prefix(Gtk.Image(icon_name="image-missing-symbolic"))
            box.append(preview_error)
    open_button = Gtk.Button(label="Ouvrir avec l’application par défaut")
    open_button.add_css_class("pill")
    open_button.connect(
        "clicked", lambda *_args, uri=artifact["uri"]: window._open_artifact(uri)
    )
    box.append(open_button)
    context_menu = window._artifact_context_menu(artifact["uri"])
    gesture = Gtk.GestureClick()
    gesture.set_button(Gdk.BUTTON_SECONDARY)
    gesture.connect(
        "pressed", window._show_artifact_context_menu, box, context_menu
    )
    box.add_controller(gesture)
    return box


