"""Moteur de rendu Markdown natif (GTK4 / Pango).

Découplé de la fenêtre : ne dépend que de GTK/GLib. Le parseur produit une
liste de blocs typés depuis un texte, le module génère du Pango markup pour
les éléments inline, et ``Renderer`` construit les widgets natifs (Gtk.Label,
Gtk.TextView monospace, Gtk.Grid) dans un conteneur GTK.

Améliorations natives par rapport à l'ancienne version :
- blocs de code avec bouton « copier » et libellé de langue ;
- gestion de la langue dans les triple backticks (```python) ;
- règle horizontale (---) ;
- liens sûrs uniquement (http/https/mailto) ;
- markup Pango construit de façon robuste via des jetons (pas de collision
  entre markup et contenu utilisateur).
"""

import html
import re
import urllib.parse

from gi.repository import GLib, Gtk

SAFE_SCHEMES = ("http", "https", "mailto")

# Couleurs de texte du markdown. On utilise des hexadécimaux plutôt que les
# noms Pango : « green » y vaut un vert très sombre (0,128,0), peu lisible sur
# fond clair. Ces valeurs restent lisibles sur les deux thèmes de cartouche.
MARKDOWN_COLORS = {
    "red": "#e01b24",
    "orange": "#ff7800",
    "yellow": "#e5a50a",
    "green": "#2ec27e",
    "blue": "#3584e4",
    "purple": "#9141ac",
    "pink": "#e439a0",
}


def is_safe_link(uri):
    if not isinstance(uri, str):
        return False
    return urllib.parse.urlsplit(uri).scheme.lower() in SAFE_SCHEMES


def escape(text):
    # ``quote=True`` : les guillemets sont échappés. Sans cela, du contenu
    # utilisateur contenant du HTML (ex. ``<a href="https://…">``) produit un
    # markup Pango invalide : le guillemet brut entre en collision avec
    # l'attribut ``href`` des liens injectés, et Gtk.Label échoue à afficher
    # le message (et inonde le terminal de Gtk-WARNINGs).
    return html.escape(text, quote=True)


# --------------------------------------------------------------------------
# Parser de blocs
# --------------------------------------------------------------------------

def parse_blocks(text):
    """Découpe un texte Markdown en blocs ``(kind, value)``.

    kind : paragraph | list | ordered | heading | quote | code | table | hr
    """
    lines = text.splitlines()
    blocks = []
    paragraph = []
    code = []
    code_language = ""
    in_code = False

    def flush_paragraph():
        if paragraph:
            blocks.append(("paragraph", "\n".join(paragraph)))
            paragraph.clear()

    index = 0
    while index < len(lines):
        line = lines[index]

        # Blocs de code délimités par ```
        if line.strip().startswith("```"):
            flush_paragraph()
            if in_code:
                blocks.append(("code", "\n".join(code), code_language))
                code.clear()
                in_code = False
                code_language = ""
            else:
                in_code = True
                code_language = line.strip()[3:].strip().split()[0] if len(line.strip()) > 3 else ""
            index += 1
            continue
        if in_code:
            code.append(line)
            index += 1
            continue

        # Citations
        if re.match(r"^\s{0,3}>\s?", line):
            flush_paragraph()
            quoted = []
            while index < len(lines):
                quote_match = re.match(r"^\s{0,3}>\s?(.*)$", lines[index])
                if not quote_match:
                    break
                quoted.append(quote_match.group(1))
                index += 1
            blocks.append(("quote", "\n".join(quoted)))
            continue

        # Titres
        heading = re.match(r"^\s{0,3}(#{1,6})\s+(.+)$", line)
        if heading:
            flush_paragraph()
            blocks.append(("heading", heading.group(2)))
            index += 1
            continue

        # Règle horizontale
        if re.match(r"^\s{0,3}(?:-{3,}|\*{3,}|_{3,})\s*$", line):
            flush_paragraph()
            blocks.append(("hr", None))
            index += 1
            continue

        # Tableau
        if (
            "|" in line
            and index + 1 < len(lines)
            and re.match(r"^\s*\|?[\s:|-]+\|[\s:|-]*\|?\s*$", lines[index + 1])
        ):
            flush_paragraph()
            rows = [_table_cells(line)]
            index += 2
            while index < len(lines) and "|" in lines[index]:
                rows.append(_table_cells(lines[index]))
                index += 1
            blocks.append(("table", rows))
            continue

        # Ligne vide -> fin de paragraphe
        if not line.strip():
            flush_paragraph()
            index += 1
            continue

        # Listes
        list_match = re.match(r"^\s*(?:([-*+])|(\d+)[.)])\s+", line)
        if list_match:
            flush_paragraph()
            ordered = list_match.group(2) is not None
            items = []
            while index < len(lines):
                current = re.match(r"^\s*(?:([-*+])|(\d+)[.)])\s+", lines[index])
                if not current or (current.group(2) is not None) != ordered:
                    break
                items.append(re.sub(r"^\s*(?:[-*+]|\d+[.)])\s+", "", lines[index]))
                index += 1
            blocks.append(("ordered" if ordered else "list", items))
            continue

        paragraph.append(line)
        index += 1

    if in_code:
        blocks.append(("code", "\n".join(code), code_language))
    flush_paragraph()
    return blocks


def _table_cells(line):
    return [cell.strip() for cell in line.strip().strip("|").split("|")]


# --------------------------------------------------------------------------
# Markup inline (Pango)
# --------------------------------------------------------------------------

def inline_markup(text):
    """Convertit le markup inline (liens, gras, italique, code, couleurs)."""
    links = []
    styled = []

    def markdown_link(match):
        label, uri = match.group(1), match.group(2).strip()
        if not is_safe_link(uri):
            return match.group(0)
        token = "PERCEPTRONLINK%dTOKEN" % len(links)
        links.append((token, label, uri))
        return token

    def style_token(markup):
        token = "PERCEPTRONSTYLE%dTOKEN" % len(styled)
        styled.append((token, markup))
        return token

    text = re.sub(r"\[([^\]]+)\]\(([^)\s]+)\)", markdown_link, text)

    def bare_link(match):
        uri = match.group(0).rstrip(".,;:!?")
        if not is_safe_link(uri):
            return match.group(0)
        token = "PERCEPTRONLINK%dTOKEN" % len(links)
        links.append((token, uri, uri))
        return token + match.group(0)[len(uri):]

    text = re.sub(r"https?://[^\s<>]+", bare_link, text)
    text = re.sub(
        r"\{\{(red|orange|yellow|green|blue|purple|pink):([^{}]*)\}\}",
        lambda match: style_token(
            '<span foreground="%s">%s</span>' % (
                MARKDOWN_COLORS.get(match.group(1), match.group(1)),
                escape(match.group(2)),
            )
        ),
        text,
    )
    text = re.sub(
        r"~~(.+?)~~",
        lambda match: style_token("<s>%s</s>" % escape(match.group(1))),
        text,
    )
    markup = escape(text)
    # Code inline : ne doit JAMAIS traverser un retour à la ligne, sinon le
    # markup Pango devient invalide (<tt>…</tt> à cheval sur 2 lignes) et
    # Gtk.Label perd le message entier. S'il y a un \n, on laisse les backticks
    # en texte brut plutôt que de fabriquer un markup fautif.
    markup = re.sub(r"`([^`\n]+)`", r"<tt>\1</tt>", markup)
    markup = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", markup)
    markup = re.sub(r"(?<!\*)\*([^*\n]+)\*(?!\*)", r"<i>\1</i>", markup)
    markup = re.sub(r"(?<!\w)_([^_\n]+)_(?!\w)", r"<i>\1</i>", markup)
    for token, rendered in styled:
        markup = markup.replace(token, rendered)
    for token, label, uri in links:
        markup = markup.replace(
            token,
            '<a href="%s">%s</a>' % (escape(uri), escape(label)),
        )
    return markup


_BALANCED_TAG = re.compile(r"</?([a-zA-Z][a-zA-Z0-9]*)(\s[^<>]*)?/?>")


def valid_markup(markup):
    """Vrai si le markup Pango est correctement imbriqué (protection).

    Le contenu utilisateur est toujours échappé, donc tout ``<`` brut vient des
    balises que l'on injecte. On vérifie simplement que chaque balise ouvrante
    est bien refermée, dans le bon ordre. En cas de doute, l'appelant affiche le
    message en texte brut au lieu de perdre le message (cf. ``Renderer._label``).
    """
    stack = []
    for match in _BALANCED_TAG.finditer(markup):
        raw = match.group(0)
        name = match.group(1)
        if raw.startswith("</"):
            if not stack or stack[-1] != name:
                return False
            stack.pop()
        elif raw.endswith("/>") or name in ("br", "img", "hr"):
            continue
        else:
            stack.append(name)
    return not stack


# --------------------------------------------------------------------------
# Rendu widgets
# --------------------------------------------------------------------------

class Renderer:
    """Construit les widgets natifs d'un document Markdown.

    ``on_link(uri)`` : rappel optionnel lors d'un clic sur un lien.
    ``on_context(widget, text)`` : rappel optionnel pour un menu contextuel.
    """

    def __init__(self, on_link=None, on_context=None):
        self.on_link = on_link or (lambda uri: False)
        self.on_context = on_context or (lambda widget, text: None)

    def render(self, container, text):
        for block in parse_blocks(text):
            self._render_block(container, block)

    def content(self, text):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.render(box, text)
        return box

    # -- helpers internes ------------------------------------------------

    def _label(self, content, css_class=None):
        markup = inline_markup(content)
        # Filet de sécurité : si le markup généré est fautif (cas limite non
        # couvert), on affiche le message en texte brut échappé plutôt que de
        # perdre complètement le message (Gtk.Label échoue sans rendu).
        if not valid_markup(markup):
            markup = escape(content)
        label = Gtk.Label(
            use_markup=True,
            label=markup,
            xalign=0,
            wrap=True,
            selectable=True,
            max_width_chars=110,
        )
        if css_class:
            label.add_css_class(css_class)
        label.connect("activate-link", self.on_link)
        self.on_context(label, content if isinstance(content, str) else "")
        return label

    def _render_block(self, container, block):
        kind = block[0]
        if kind in ("paragraph", "list", "ordered", "heading"):
            if kind in ("list", "ordered"):
                prefix = "• " if kind == "list" else ""
                value = "\n".join(
                    (str(index) + ". " if kind == "ordered" else prefix) + item
                    for index, item in enumerate(block[1], 1)
                )
            else:
                value = block[1]
            css_class = "title-3" if kind == "heading" else None
            container.append(self._label(value, css_class))

        elif kind == "quote":
            quote = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            quote.add_css_class("dim-label")
            quote.append(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL))
            label = self._label(block[1])
            label.set_hexpand(True)
            quote.append(label)
            container.append(quote)

        elif kind == "hr":
            separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            separator.set_margin_top(6)
            separator.set_margin_bottom(6)
            container.append(separator)

        elif kind == "code":
            container.append(self._code_block(block[1], block[2] if len(block) > 2 else ""))

        elif kind == "table":
            container.append(self._table(block[1]))

    def _code_block(self, value, language=""):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        box.add_css_class("card")
        # Respiration externe : le bloc ne touche pas les bords de la carte.
        box.set_margin_top(2)
        box.set_margin_bottom(2)
        header = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=6,
            margin_top=4,
            margin_bottom=4,
            margin_start=8,
            margin_end=8,
        )
        if language:
            lang = Gtk.Label(label=language, xalign=0)
            lang.add_css_class("dim-label")
            lang.add_css_class("monospace")
            header.append(lang)
        copy = Gtk.Button.new_from_icon_name("edit-copy-symbolic")
        copy.set_tooltip_text("Copier le bloc")
        copy.add_css_class("flat")
        copy.connect("clicked", self._copy_block, language, value)
        header.append(copy)
        copy_align = Gtk.Box(hexpand=True)
        header.prepend(copy_align)
        box.append(header)

        text_view = Gtk.TextView(
            editable=False,
            monospace=True,
            # WORD_CHAR : un TextView monospace sans retour à la ligne impose une
            # largeur minimale énorme (ligne longue) qui fait gonfler la fenêtre
            # jusqu'à déborder de l'écran. En repliant les lignes, la largeur
            # minimale reste bornée et la fenêtre garde sa taille.
            wrap_mode=Gtk.WrapMode.WORD_CHAR,
            cursor_visible=False,
            # Respiration interne : le code ne colle ni à gauche/droite ni en bas.
            left_margin=12,
            right_margin=12,
            top_margin=10,
            bottom_margin=12,
        )
        text_view.get_buffer().set_text(value)
        scroll = Gtk.ScrolledWindow(
            min_content_height=48,
            max_content_height=240,
            hscrollbar_policy=Gtk.PolicyType.NEVER,
        )
        scroll.set_child(text_view)
        box.append(scroll)
        return box

    @staticmethod
    def _copy_block(button, _language, value):
        import clipboard_util

        if clipboard_util.copy_text(button, value):
            tooltip = "Copié !"
        else:
            tooltip = "Impossible de copier"
        button.set_tooltip_text(tooltip)

    def _table(self, rows):
        grid = Gtk.Grid(row_spacing=6, column_spacing=12)
        grid.add_css_class("view")
        for row_index, cells in enumerate(rows):
            for column_index, cell in enumerate(cells):
                label = self._label(cell)
                label.set_yalign(0)
                label.set_max_width_chars(32)
                label.set_margin_start(10)
                label.set_margin_end(10)
                label.set_margin_top(6)
                label.set_margin_bottom(6)
                if row_index == 0:
                    label.add_css_class("heading")
                grid.attach(label, column_index, row_index, 1, 1)
        scroll = Gtk.ScrolledWindow(
            hscrollbar_policy=Gtk.PolicyType.AUTOMATIC,
            max_content_height=300,
        )
        scroll.set_child(grid)
        frame = Gtk.Frame(child=scroll)
        frame.add_css_class("card")
        frame.set_margin_top(2)
        frame.set_margin_bottom(2)
        return frame
