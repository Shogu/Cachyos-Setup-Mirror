"""Client HTTP/SSE natif pour le service OpenCode."""

import base64
import json
import os
import re
import secrets
import urllib.parse

import gi

gi.require_version("Soup", "3.0")

from gi.repository import Gio, GLib, GObject, Soup

from config import BASE_URL
from journal import log

EVENT_PATH = "/api/event"
RETRY_MIN_SECONDS = 2
RETRY_MAX_SECONDS = 60


def is_cancelled(error):
    return error.matches(Gio.io_error_quark(), Gio.IOErrorEnum.CANCELLED)


def _payload(value):
    return value.get("data", value) if isinstance(value, dict) else value


def basic_auth_header(username, password):
    if not password:
        return None
    credentials = f"{username}:{password}".encode("utf-8")
    token = base64.b64encode(credentials).decode("ascii")
    return "Basic " + token


def prompt_payload(text, delivery=None, files=None):
    payload = {"text": text}
    if delivery in ("steer", "queue"):
        payload["delivery"] = delivery
    if files:
        payload["files"] = files
    return payload


def http_error_message(status, response_body):
    detail = ""
    try:
        decoded = json.loads(response_body)
    except (ValueError, UnicodeDecodeError):
        decoded = None
    if isinstance(decoded, dict):
        detail = decoded.get("message", "")
        if not isinstance(detail, str):
            detail = ""
        kind = decoded.get("kind")
        if isinstance(kind, str) and kind:
            detail = "%s (type : %s)" % (detail, kind)
        field = decoded.get("field")
        if isinstance(field, str) and field:
            detail = "%s (champ : %s)" % (detail, field)
    elif isinstance(response_body, bytes):
        detail = response_body.decode("utf-8", "replace")
    elif isinstance(response_body, str):
        detail = response_body

    detail = re.sub(r"[\x00-\x1f\x7f]+", " ", detail)
    detail = re.sub(r"\s+", " ", detail).strip()
    detail = re.sub(r"(?i)\b(?:bearer|basic)\s+[a-z0-9._~+/-]+=*", "[identifiant masqué]", detail)
    detail = re.sub(r"(?i)(password|token|secret)\s*[:=]\s*\S+", r"\1=[masqué]", detail)
    detail = detail[:400]
    return "Réponse HTTP %d%s" % (status, ": " + detail if detail else "")


class Server(GObject.Object):
    __gsignals__ = {
        "event": (GObject.SignalFlags.RUN_FIRST, None, (str, object)),
    }

    def __init__(self, cookie_file, password_file):
        super().__init__()
        cookie_fd = os.open(cookie_file, os.O_CREAT | os.O_RDWR, 0o600)
        os.close(cookie_fd)
        os.chmod(cookie_file, 0o600)
        self._soup = Soup.Session(timeout=0)
        self._cookie_jar = Soup.CookieJarText.new(cookie_file, False)
        self._cookie_file = cookie_file
        self.username = os.environ.get("OPENCODE_SERVER_USERNAME", "opencode")
        self.password = os.environ.get("OPENCODE_SERVER_PASSWORD") or self._load_password(password_file)
        self._authorization = basic_auth_header(self.username, self.password)
        os.chmod(self._cookie_file, 0o600)
        self._soup.add_feature(self._cookie_jar)
        self._cancellable = Gio.Cancellable()
        self._stream_active = False
        self._retry_id = 0
        self._retry_delay = RETRY_MIN_SECONDS
        self._sessions = {}
        self._waiting = {}

    @staticmethod
    def _load_password(path):
        os.makedirs(os.path.dirname(path), mode=0o700, exist_ok=True)
        os.chmod(os.path.dirname(path), 0o700)
        try:
            with open(path, encoding="utf-8") as handle:
                password = handle.read().strip()
            if password:
                os.chmod(path, 0o600)
                return password
        except FileNotFoundError:
            pass

        password = secrets.token_urlsafe(32)
        descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(password + "\n")
        return password

    def start(self):
        if self._stream_active or self._retry_id:
            return
        self._subscribe()

    def destroy(self):
        if self._retry_id:
            GLib.Source.remove(self._retry_id)
            self._retry_id = 0
        self._cancellable.cancel()
        self._soup.abort()

    def _subscribe(self):
        if self._cancellable.is_cancelled():
            return
        message = self._message(EVENT_PATH + "?cursor=now")
        self._soup.send_async(
            message, GLib.PRIORITY_DEFAULT, self._cancellable,
            self._on_subscribed, message,
        )

    def _retry_later(self):
        if self._retry_id or self._cancellable.is_cancelled():
            return
        log("flux : nouvelle tentative dans %d s" % self._retry_delay)
        self._retry_id = GLib.timeout_add_seconds(self._retry_delay, self._on_retry)
        self._retry_delay = min(self._retry_delay * 2, RETRY_MAX_SECONDS)

    def _on_retry(self):
        self._retry_id = 0
        self._subscribe()
        return GLib.SOURCE_REMOVE

    def _message(self, path, method="GET", body=None):
        message = Soup.Message.new(method, BASE_URL + path)
        self._authorize(message)
        if body is not None:
            message.set_request_body_from_bytes(
                "application/json",
                GLib.Bytes.new(json.dumps(body).encode("utf-8")),
            )
        return message

    def _authorize(self, message):
        if self._authorization:
            message.get_request_headers().replace("Authorization", self._authorization)

    def _on_subscribed(self, soup, result, message):
        try:
            stream = soup.send_finish(result)
        except GLib.Error as error:
            self._stream_active = False
            if not is_cancelled(error):
                log("flux : connexion impossible (%s)" % error.message)
                self._retry_later()
            return
        headers = message.get_response_headers()
        content_type = headers.get_content_type()[0]
        if message.get_status() != Soup.Status.OK or content_type != "text/event-stream":
            self._stream_active = False
            log("flux : réponse inattendue %d %s" % (message.get_status(), content_type))
            stream.close_async(GLib.PRIORITY_DEFAULT, None, None)
            self._retry_later()
            return
        log("flux : abonné à " + EVENT_PATH)
        self._stream_active = True
        self._retry_delay = RETRY_MIN_SECONDS
        self._read_line(Gio.DataInputStream.new(stream), [])

    def _read_line(self, lines, data):
        lines.read_line_async(GLib.PRIORITY_DEFAULT, self._cancellable, self._on_line, data)

    def _on_line(self, lines, result, data):
        try:
            line = lines.read_line_finish_utf8(result)[0]
        except GLib.Error as error:
            self._stream_active = False
            if not is_cancelled(error):
                log("flux : lecture interrompue (%s)" % error.message)
                self._retry_later()
            return
        if line is None:
            self._stream_active = False
            log("flux : fermé par le serveur")
            self._retry_later()
            return
        if line.startswith("data:"):
            data.append(line[6:] if line.startswith("data: ") else line[5:])
        elif not line and data:
            self._dispatch("\n".join(data))
            data.clear()
        self._read_line(lines, data)

    def _dispatch(self, payload):
        try:
            event = json.loads(payload)
        except ValueError:
            log("flux : événement illisible " + payload[:120])
            return
        kind = event.get("type", "")
        data = event.get("data") or {}
        self._update_sessions(kind, data)
        self.emit("event", kind, data)

    def _update_sessions(self, kind, data):
        session_id = data.get("sessionID")
        if kind == "session.created" and session_id:
            self._sessions[session_id] = {
                "id": session_id,
                "parentID": data.get("parentID"),
                "title": data.get("title", ""),
            }
        elif kind == "session.renamed" and session_id in self._sessions:
            self._sessions[session_id]["title"] = data.get("title", "")
        elif kind == "session.deleted" and session_id:
            self._sessions.pop(session_id, None)

    def _request_json(self, method, path, body, callback, unwrap_data=True):
        message = self._message(path, method, body)
        self._soup.send_and_read_async(
            message, GLib.PRIORITY_DEFAULT, self._cancellable,
            self._on_json_response, (message, callback, unwrap_data),
        )

    def _on_json_response(self, soup, result, request):
        message, callback, unwrap_data = request
        try:
            response = soup.send_and_read_finish(result)
        except GLib.Error as error:
            if not is_cancelled(error):
                log("requête %s : %s" % (message.get_uri().to_string(), error.message))
            callback(None, error.message)
            return
        status = message.get_status()
        if status < 200 or status >= 300:
            error = http_error_message(status, response.get_data())
            if status == 401:
                error += " — vérifie OPENCODE_SERVER_PASSWORD et OPENCODE_SERVER_USERNAME"
            log("requête %s : %s" % (message.get_uri().to_string(), error))
            callback(None, error)
            return
        try:
            result_data = json.loads(response.get_data()) if response.get_data() else None
        except (ValueError, UnicodeDecodeError) as error:
            log("réponse JSON invalide (%s)" % error)
            callback(None, "Réponse JSON invalide")
            return
        callback(_payload(result_data) if unwrap_data else result_data, None)

    @staticmethod
    def _escape_id(value):
        return GLib.Uri.escape_string(value, None, False)

    @classmethod
    def session_path(cls, session_id, resource):
        return "/api/session/%s/%s" % (cls._escape_id(session_id), resource)

    def list_sessions(self, callback, archived=None):
        sessions = []
        self._list_sessions_page(archived, None, sessions, set(), callback)

    def _list_sessions_page(self, archived, cursor, sessions, seen, callback):
        query = {}
        if archived is not None:
            query["archived"] = "true" if archived else "false"
        if cursor:
            if cursor in seen:
                callback(None, "OpenCode a renvoyé un curseur de sessions déjà parcouru.")
                return
            seen.add(cursor)
            query["cursor"] = cursor
        path = "/api/session"
        if query:
            path += "?" + urllib.parse.urlencode(query)
        self._request_json(
            "GET",
            path,
            None,
            lambda page, error: self._on_session_page(
                archived, sessions, seen, callback, page, error
            ),
            unwrap_data=False,
        )

    def _on_session_page(self, archived, sessions, seen, callback, page, error):
        if error:
            callback(None, error)
            return
        if not isinstance(page, dict) or not isinstance(page.get("data"), list):
            callback(None, "Réponse de pagination des sessions invalide.")
            return
        sessions.extend(page["data"])
        next_cursor = (page.get("cursor") or {}).get("next")
        if next_cursor:
            self._list_sessions_page(
                archived, next_cursor, sessions, seen, callback
            )
            return
        callback(sessions, None)

    def list_agents(self, callback):
        self._request_json("GET", "/api/agent", None, callback)

    def list_providers(self, callback):
        self._request_json("GET", "/api/provider", None, callback)

    def get_config(self, callback):
        self._request_json("GET", "/api/config", None, callback)

    def patch_config(self, changes, callback):
        self._request_json(
            "PATCH", "/api/experimental/config", changes, callback
        )

    def list_artifacts(self, callback):
        self._request_json(
            "GET", "/api/experimental/artifacts", None, callback
        )

    def list_websearch_providers(self, callback):
        self._request_json("GET", "/api/websearch/provider", None, callback)

    def websearch(self, query, provider_id, callback):
        body = {"query": query}
        if provider_id:
            body["providerID"] = provider_id
        self._request_json("POST", "/api/websearch", body, callback)

    def background_session(self, session_id, callback):
        self._request_json(
            "POST",
            self.session_path(session_id, "background"),
            {},
            callback,
        )

    def list_active_sessions(self, callback):
        self._request_json("GET", "/api/session/active", None, callback)

    def create_session(self, callback):
        self._request_json("POST", "/api/session", {}, callback)

    def update_session(self, session_id, changes, callback):
        self._request_json(
            "PATCH", "/api/session/" + self._escape_id(session_id), changes, callback
        )

    def delete_session(self, session_id, callback):
        self._request_json(
            "DELETE", "/api/session/" + self._escape_id(session_id), None, callback
        )

    def fork_session(self, session_id, message_id, callback):
        body = {"before": message_id}
        self._request_json(
            "POST", self.session_path(session_id, "fork"), body, callback
        )

    def list_models(self, callback):
        self._request_json("GET", "/api/model", None, callback)

    def get_default_model(self, callback):
        self._request_json("GET", "/api/model/default", None, callback)

    def switch_model(self, session_id, model, callback):
        body = {"model": model}
        self._request_json(
            "POST", self.session_path(session_id, "model"), body, callback
        )

    def switch_agent(self, session_id, agent_id, callback):
        self._request_json(
            "POST",
            self.session_path(session_id, "agent"),
            {"agent": agent_id},
            callback,
        )

    def interrupt_session(self, session_id, callback):
        self._request_json(
            "POST", self.session_path(session_id, "interrupt"), {}, callback
        )

    def stage_revert(self, session_id, message_id, callback):
        self._request_json(
            "POST",
            self.session_path(session_id, "revert/stage"),
            {"messageID": message_id},
            callback,
        )

    def commit_revert(self, session_id, callback):
        self._request_json(
            "POST", self.session_path(session_id, "revert/commit"), {}, callback
        )

    def clear_staged_revert(self, session_id, callback):
        self._request_json(
            "DELETE", self.session_path(session_id, "revert"), None, callback
        )

    def get_session(self, session_id, callback, force_refresh=False):
        if not force_refresh and session_id in self._sessions:
            callback(self._sessions[session_id], None)
            return

        waiting = self._waiting.setdefault(session_id, [])
        waiting.append(callback)
        if len(waiting) == 1:
            path = "/api/session/" + self._escape_id(session_id)
            self._request_json(
                "GET", path, None,
                lambda info, error: self._on_session_loaded(session_id, info, error),
            )

    def _on_session_loaded(self, session_id, info, error):
        if info and not error:
            self._sessions[session_id] = info
        elif error and "HTTP 404" in error:
            self._sessions.pop(session_id, None)
        for callback in self._waiting.pop(session_id, []):
            callback(info, error)

    def get_messages(self, session_id, callback, limit=100):
        messages = []
        self._get_messages_page(
            session_id, limit, None, messages, set(), callback
        )

    def _get_messages_page(self, session_id, limit, cursor, messages, seen, callback):
        query = {"limit": str(limit)}
        if cursor:
            if cursor in seen:
                callback(None, "OpenCode a renvoyé un curseur de messages déjà parcouru.")
                return
            seen.add(cursor)
            query["cursor"] = cursor
        path = self.session_path(session_id, "message")
        path += "?" + urllib.parse.urlencode(query)
        self._request_json(
            "GET",
            path,
            None,
            lambda page, error: self._on_message_page(
                session_id, limit, messages, seen, callback, page, error
            ),
            unwrap_data=False,
        )

    def _on_message_page(
        self, session_id, limit, messages, seen, callback, page, error
    ):
        if error:
            callback(None, error)
            return
        if isinstance(page, list):
            messages.extend(page)
            callback(messages, None)
            return
        if not isinstance(page, dict) or not isinstance(page.get("data"), list):
            callback(None, "Réponse de pagination des messages invalide.")
            return
        messages.extend(page["data"])
        next_cursor = (page.get("cursor") or {}).get("next")
        if next_cursor:
            self._get_messages_page(
                session_id, limit, next_cursor, messages, seen, callback
            )
            return
        callback(messages, None)

    def send_prompt(self, session_id, text, callback, delivery=None, files=None):
        path = self.session_path(session_id, "prompt")
        self._request_json(
            "POST", path, prompt_payload(text, delivery, files), callback
        )
