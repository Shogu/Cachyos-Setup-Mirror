import os
from gi.repository import GLib

APP_ID = "io.gitlab.shogu.Perceptron"
APP_NAME = "Perceptron"
VERSION = "1.5.2"
BASE_URL = "http://127.0.0.1:49375"

DATA_DIR = os.path.join(GLib.get_user_data_dir(), "perceptron")
STATE_FILE = os.path.join(DATA_DIR, "window.json")
LOG_FILE = os.path.join(DATA_DIR, "perceptron.log")

# L'installateur d'OpenCode n'ajoute son dossier qu'au PATH du shell (fish_add_path),
# invisible pour une appli lancée depuis GNOME.
OPENCODE_FALLBACKS = (
    "~/.opencode/bin/opencode",
    "~/.local/bin/opencode",
    "~/.bun/bin/opencode",
    "~/.npm-global/bin/opencode",
)


def find_opencode():
    found = GLib.find_program_in_path("opencode")
    if found:
        return found
    for candidate in map(os.path.expanduser, OPENCODE_FALLBACKS):
        if os.access(candidate, os.X_OK):
            return candidate
    return None
