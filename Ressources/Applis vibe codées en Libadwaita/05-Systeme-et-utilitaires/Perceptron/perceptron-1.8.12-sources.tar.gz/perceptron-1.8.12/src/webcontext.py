"""Réglages globaux du moteur WebKit : cache réduit, pas de correcteur orthographique."""

from gi.repository import WebKit


def configure():
    context = WebKit.WebContext.get_default()
    # Une seule page applicative : pas besoin du cache d'un navigateur.
    context.set_cache_model(WebKit.CacheModel.DOCUMENT_VIEWER)
    # Le correcteur passait par enchant dans la boucle de la fenêtre, à chaque frappe.
    context.set_spell_checking_enabled(False)
