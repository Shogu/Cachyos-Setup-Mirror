"""Habillage de l'UI web d'OpenCode : feuille de lisibilité modifiable, couleurs de GNOME (accent, barre de titre)."""

from gi.repository import Adw, Gio, WebKit

from config import OPENCODE_CSS

# Couleurs de la barre de titre Adwaita (libadwaita 1.6+).
# (fond, bordure, texte)
HEADERBAR = {
    False: ("#ffffff", "rgba(0, 0, 6, 0.07)", "rgba(0, 0, 6, 0.8)"),
    True: ("#2e2e32", "rgba(0, 0, 6, 0.36)", "#ffffff"),
}

# Une feuille vide ajoutée puis retirée force WebKit à recalculer tout le style de la page,
# maintenant et une seconde plus tard (l'interface d'OpenCode se construit après le chargement).
RESTYLE_SCRIPT = """
(() => {
  const restyle = () => {
    const sheet = document.createElement("style");
    sheet.textContent = "* {}";
    document.head.append(sheet);
    requestAnimationFrame(() => sheet.remove());
  };
  restyle();
  setTimeout(restyle, 1000);
})();
"""

GNOME_CSS = """
html { accent-color: @ACCENT_BG@; }
::selection { background-color: color-mix(in srgb, @ACCENT_BG@ 35%, transparent); }
a { color: @ACCENT_FG@; }
input, textarea, [contenteditable="true"] { caret-color: @ACCENT_FG@; }
:focus-visible { outline-color: @ACCENT_BG@ !important; }

/* 8. Barre d'onglets et cadre d'OpenCode dans la couleur de la barre de titre
 * GNOME : un seul bandeau. Les onglets restent ceux d'OpenCode. */
:root, [data-color-scheme] { --v2-background-bg-deep: @HEADERBAR_BG@ !important; }
[data-slot="titlebar-v2"], [data-slot="titlebar-v2"] * { border-bottom-color: transparent !important; }
[data-slot="titlebar-v2"] { box-shadow: none !important; border-bottom: 0 !important; }

/* Onglets façon AdwTabBar : barre de 46 px, onglets de 34 px, rayon 9 px,
 * titre en Adwaita Sans 14 px poids normal, fond seulement au survol et sur
 * l'onglet actif (plus marqué), bouton de fermeture rond. Les onglets restent
 * ceux d'OpenCode ; seule leur apparence change. */
[data-slot="titlebar-v2"] {
  height: 46px !important;
  padding-top: 6px !important;
  padding-bottom: 6px !important;
}
/* OpenCode décale la rangée de 8 px vers le bas (pt-[max(0px,calc(8px-…))]) pour ses onglets de 28 px :
 * avec nos 34 px, ils débordaient en bas de la zone défilante, qui ne se recalait qu'au premier clic. */
[data-slot="titlebar-v2"] > div {
  padding-top: 0 !important;
}
[data-slot="titlebar-tabs-scroll"] {
  overflow-y: hidden !important;
}
[data-titlebar-tab]:not([data-orientation="vertical"]),
[data-titlebar-tab-action] {
  height: 34px !important;
  border-radius: 9px !important;
  --tab-base: transparent !important;
}
[data-titlebar-tab]:not([data-orientation="vertical"]) {
  padding-inline: 8px !important;
}
[data-titlebar-tab]:not([data-orientation="vertical"]):hover,
[data-titlebar-tab-action]:hover {
  --tab-overlay: color-mix(in srgb, currentColor 7%, transparent) !important;
}
[data-titlebar-tab]:not([data-orientation="vertical"])[data-active="true"] {
  --tab-overlay: color-mix(in srgb, currentColor 12%, transparent) !important;
}
[data-titlebar-tab]:not([data-orientation="vertical"])[data-active="true"]:hover {
  --tab-overlay: color-mix(in srgb, currentColor 15%, transparent) !important;
}
[data-titlebar-tab]:is([data-state="pressed"], [data-dragging="true"]),
[data-titlebar-tab-action]:active {
  --tab-overlay: color-mix(in srgb, currentColor 18%, transparent) !important;
}
[data-titlebar-tab]:not([data-orientation="vertical"]) [data-slot="tab-link"] {
  font-family: var(--font-family-sans) !important;
  font-size: 14px !important;
  font-weight: 400 !important;
  /* Titre coupé par des points de suspension, comme GTK, au lieu du fondu d'OpenCode ;
   * la place du bouton de fermeture reste réservée à droite. */
  -webkit-mask-image: none !important;
  mask-image: none !important;
  padding-inline-end: 26px !important;
}
[data-titlebar-tab]:not([data-orientation="vertical"]) [data-slot="tab-link"] > * {
  color: @HEADERBAR_FG@ !important;
}
[data-titlebar-tab]:not([data-orientation="vertical"]):not([data-active="true"]) [data-slot="tab-link"] > * {
  opacity: 0.8;
}
[data-titlebar-tab]:not([data-orientation="vertical"]) :is([data-slot="tab-title"], [data-slot="tab-label"]) {
  overflow: hidden !important;
  text-overflow: ellipsis !important;
  white-space: nowrap !important;
}
/* Bouton de fermeture : bouton rond plat de 24 px, visible au survol, icône 16 px. */
[data-titlebar-tab]:not([data-orientation="vertical"]) [data-slot="tab-close"] {
  top: 5px !important;
  inset-inline-end: 5px !important;
  width: 24px !important;
  height: 24px !important;
  /* OpenCode y repeint le fond de l'onglet pour masquer le titre : en double, ça fait un carré gris. */
  background: none !important;
}
[data-titlebar-tab]:not([data-orientation="vertical"]) [data-slot="tab-close"] > button {
  width: 24px !important;
  height: 24px !important;
  min-width: 0 !important;
  padding: 0 !important;
  border: 0 !important;
  border-radius: 50% !important;
  background: transparent !important;
  background-image: none !important;
  box-shadow: none !important;
  outline: none !important;
  /* Sans ça, WebKitGTK dessine un bouton natif (carré bordé) : nos règles « utilisateur »
   * ne comptent pas pour lui comme un style de page qui remplace l'apparence native. */
  -webkit-appearance: none !important;
  appearance: none !important;
  color: @HEADERBAR_FG@ !important;
}
[data-titlebar-tab]:not([data-orientation="vertical"]) [data-slot="tab-close"] > button:is(:hover, :focus-visible) {
  background: color-mix(in srgb, currentColor 10%, transparent) !important;
}
[data-titlebar-tab]:not([data-orientation="vertical"]) [data-slot="tab-close"] > button:active {
  background: color-mix(in srgb, currentColor 20%, transparent) !important;
}
[data-titlebar-tab]:not([data-orientation="vertical"]) [data-slot="tab-close"] > button svg {
  width: 16px !important;
  height: 16px !important;
}
/* Indicateur de travail : spinner Adwaita (anneau qui tourne) à la place de la grille de points. */
[data-titlebar-tab]:not([data-orientation="vertical"]) [data-slot="tab-status"] {
  width: 24px !important;
  height: 24px !important;
}
[data-titlebar-tab] [data-mark="busy"] {
  width: 16px !important;
  height: 16px !important;
  box-sizing: border-box;
  border-radius: 50%;
  border: 2px solid color-mix(in srgb, @HEADERBAR_FG@ 18%, transparent);
  border-top-color: @HEADERBAR_FG@;
  animation: perceptron-spin 0.9s linear infinite;
  /* OpenCode dessine ses points avec un masque (et des SVG dans les versions plus anciennes) : on les retire. */
  -webkit-mask-image: none !important;
  mask-image: none !important;
}
[data-titlebar-tab] [data-mark="busy"]::before,
[data-titlebar-tab] [data-mark="busy"] > svg {
  display: none !important;
}
@keyframes perceptron-spin {
  to { transform: rotate(360deg); }
}
/* Pastilles d'état : 8 px, couleurs Adwaita (accent, orange, rouge). */
[data-titlebar-tab] [data-slot="tab-status-dot"] {
  width: 8px !important;
  height: 8px !important;
  background: @ACCENT_BG@ !important;
}
[data-titlebar-tab] [data-mark="attention"] { background: #e5a50a !important; }
[data-titlebar-tab] [data-mark="failed"] { background: #e01b24 !important; }
/* Séparateurs entre onglets recentrés sur la nouvelle hauteur. */
[data-titlebar-tab-slot]::before {
  top: 11px !important;
}
/* Accueil, Loupe, + : boutons plats de barre de titre GNOME (34 px, rayon 9 px, icône 16 px). */
[data-slot="titlebar-v2"] [data-component="icon-button-v2"]:not([data-titlebar-tab] *) {
  -webkit-appearance: none !important;
  appearance: none !important;
  width: 34px !important;
  height: 34px !important;
  border-radius: 9px !important;
}
[data-slot="titlebar-v2"] [data-component="icon-button-v2"]:not([data-titlebar-tab] *) [data-slot="icon-svg"] {
  width: 16px !important;
  height: 16px !important;
}

/* 12. Le modèle (2e info sous chaque réponse, après l'agent) teinté d'accent. */
[data-slot="text-part-meta-item"]:first-child + [data-slot="text-part-meta-separator"] + [data-slot="text-part-meta-item"] {
  background: color-mix(in srgb, @ACCENT_BG@ 24%, transparent) !important;
}

/* 1. Tes messages : bulles teintées à la couleur d'accent. */
[data-slot="user-message-text"] {
  background: color-mix(in srgb, @ACCENT_BG@ 22%, transparent) !important;
}

/* 2. Zone de saisie en carte Adwaita, contour d'accent quand on y tape. */
[data-component="composer"] {
  border-radius: 14px !important;
  box-shadow: 0 0 0 1px color-mix(in srgb, currentColor 10%, transparent) !important;
  transition: box-shadow 150ms ease;
}
[data-component="composer"]:focus-within {
  box-shadow: 0 0 0 2px @ACCENT_BG@ !important;
}

/* 6. Citations : trait d'accent et fond très léger. */
[data-component="markdown"] blockquote {
  border-inline-start: 3px solid @ACCENT_BG@ !important;
  background: color-mix(in srgb, @ACCENT_BG@ 8%, transparent);
  border-radius: 0 8px 8px 0;
  padding: 6px 12px !important;
  color: inherit !important;
}

/* Bouton Envoyer : action principale, en couleur d'accent comme un « suggested-action » GNOME.
 * OpenCode le peint avec un dégradé (background-image) qui recouvrirait la couleur, et lui ajoute un
 * relief (box-shadow) et une ombre sur la flèche : un bouton Adwaita est plat, on retire les trois. */
[data-action="composer-submit"]:not(:disabled):not([aria-disabled="true"]) {
  background-image: none !important;
  box-shadow: none !important;
  text-shadow: none !important;
  background-color: @ACCENT_BG@ !important;
  color: #ffffff !important;
}
[data-action="composer-submit"]:not(:disabled):not([aria-disabled="true"]) svg {
  color: #ffffff !important;
}
[data-action="composer-submit"]:not(:disabled):not([aria-disabled="true"]):hover {
  background-color: color-mix(in srgb, @ACCENT_BG@ 88%, white) !important;
}
[data-action="composer-submit"]:not(:disabled):not([aria-disabled="true"]):active {
  background-color: color-mix(in srgb, @ACCENT_BG@ 85%, black) !important;
}

/* Pastilles de projets sans couleur choisie (gris par défaut) : couleur
 * d'accent et initiale blanche, comme les avatars Adwaita. Une couleur
 * choisie dans les réglages du projet dans OpenCode reste prioritaire. */
[data-slot="project-avatar-surface"][data-variant="gray"]:not([data-has-image]) {
  --project-avatar-bg: @ACCENT_BG@ !important;
  --project-avatar-border: transparent !important;
  color: #ffffff !important;
}
[data-slot="project-avatar-surface"][data-variant="gray"] [data-slot="project-avatar-initial"] {
  color: #ffffff !important;
}
"""


class GnomeLook:
    def __init__(self, webview):
        self._webview = webview
        self._manager = webview.get_user_content_manager()
        self._style = Adw.StyleManager.get_default()
        self._style.connect("notify::accent-color", self._apply)
        self._style.connect("notify::dark", self._apply)
        # Retoucher opencode.css s'applique sans relancer Perceptron.
        self._monitor = Gio.File.new_for_path(OPENCODE_CSS).monitor_file(Gio.FileMonitorFlags.NONE, None)
        self._monitor.connect("changed", self._on_css_changed)
        self._apply()

    def _on_css_changed(self, _monitor, _file, _other, event):
        if event == Gio.FileMonitorEvent.CHANGES_DONE_HINT:
            self._apply()

    def _apply(self, *_):
        dark = self._style.get_dark()
        accent = self._style.get_accent_color()
        headerbar_bg, headerbar_border, headerbar_fg = HEADERBAR[dark]
        source = self._readability() + (GNOME_CSS
            .replace("@ACCENT_BG@", Adw.AccentColor.to_rgba(accent).to_string())
            .replace("@ACCENT_FG@", Adw.AccentColor.to_standalone_rgba(accent, dark).to_string())
            .replace("@HEADERBAR_BG@", headerbar_bg)
            .replace("@HEADERBAR_BORDER@", headerbar_border)
            .replace("@HEADERBAR_FG@", headerbar_fg))
        self._manager.remove_all_style_sheets()
        self._manager.add_style_sheet(WebKit.UserStyleSheet.new(
            source, WebKit.UserContentInjectedFrames.ALL_FRAMES, WebKit.UserStyleLevel.USER, None, None,
        ))
        self.restyle()

    def restyle(self):
        self._webview.evaluate_javascript(RESTYLE_SCRIPT, -1, None, None, None, None, None)

    @staticmethod
    def _readability():
        try:
            with open(OPENCODE_CSS, encoding="utf-8") as handle:
                return handle.read()
        except OSError:
            return ""
