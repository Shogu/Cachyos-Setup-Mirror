"""Page d'accueil au lancement : reprendre la session précédente, en ouvrir une nouvelle, ou aller à l'accueil d'OpenCode.

Adw.StatusPage est un type final : la page est composée, pas héritée.
"""

from gi.repository import Adw, Gtk

from config import APP_ID

BUTTON_WIDTH = 300


class Welcome:
    def __init__(self, on_resume, on_new, on_home):
        self.resume = self._button("Reprendre la session précédente", on_resume, "pill", "suggested-action")
        buttons = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, halign=Gtk.Align.CENTER)
        buttons.append(self.resume)
        buttons.append(self._button("Nouvelle session", on_new, "pill"))
        buttons.append(self._button("Accueil d’OpenCode", on_home, "flat"))
        self.page = Adw.StatusPage(
            icon_name=APP_ID, title="Bon retour", description="Où veux-tu reprendre ?", child=buttons,
        )

    @staticmethod
    def _button(label, callback, *css_classes):
        button = Gtk.Button(label=label, width_request=BUTTON_WIDTH, css_classes=list(css_classes))
        button.connect("clicked", lambda *_: callback())
        return button

    def show_session(self, info):
        """info : Session.Info d'OpenCode, ou None si la session n'existe plus."""
        if info is None:
            self.resume.set_visible(False)
            self.page.set_description("Session précédente introuvable.")
            return
        title = info.get("title") or "Session sans titre"
        self.page.set_description("Dernière session : « %s »" % title)

    def focus(self):
        target = self.resume if self.resume.get_visible() else None
        if target:
            target.grab_focus()
