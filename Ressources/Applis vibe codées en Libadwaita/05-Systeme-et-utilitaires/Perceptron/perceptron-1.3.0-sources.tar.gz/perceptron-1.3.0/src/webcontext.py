"""Réglages globaux du moteur WebKit : cache réduit et correcteur orthographique français."""

from gi.repository import WebKit

SPELL_LANGUAGES = ["fr_FR"]


def configure():
    context = WebKit.WebContext.get_default()
    # Une seule page applicative : pas besoin du cache d'un navigateur.
    context.set_cache_model(WebKit.CacheModel.DOCUMENT_VIEWER)
    context.set_spell_checking_enabled(True)
    context.set_spell_checking_languages(SPELL_LANGUAGES)
