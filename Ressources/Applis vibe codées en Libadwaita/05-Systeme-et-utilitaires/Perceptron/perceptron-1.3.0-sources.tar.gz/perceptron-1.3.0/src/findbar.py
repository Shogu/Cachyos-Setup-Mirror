"""Recherche dans la page (Ctrl+F) avec le FindController de WebKit."""

from gi.repository import Gtk, WebKit

FIND_OPTIONS = WebKit.FindOptions.CASE_INSENSITIVE | WebKit.FindOptions.WRAP_AROUND
MAX_MATCHES = 1000


class FindBar(Gtk.SearchBar):
    def __init__(self, webview):
        super().__init__(show_close_button=True)
        self._finder = webview.get_find_controller()
        self._finder.connect("found-text", self._on_found)
        self._finder.connect("failed-to-find-text", self._on_failed)

        self._entry = Gtk.SearchEntry(placeholder_text="Rechercher dans la page", width_request=320)
        self._entry.connect("search-changed", self._on_search_changed)
        self._entry.connect("activate", lambda *_: self._finder.search_next())
        self._entry.connect("next-match", lambda *_: self._finder.search_next())
        self._entry.connect("previous-match", lambda *_: self._finder.search_previous())
        self.connect_entry(self._entry)

        self._count = Gtk.Label(css_classes=["dim-label", "numeric"])
        previous = Gtk.Button(icon_name="go-up-symbolic", tooltip_text="Précédent (Maj+Ctrl+G)")
        previous.connect("clicked", lambda *_: self._finder.search_previous())
        following = Gtk.Button(icon_name="go-down-symbolic", tooltip_text="Suivant (Ctrl+G)")
        following.connect("clicked", lambda *_: self._finder.search_next())
        arrows = Gtk.Box(css_classes=["linked"])
        arrows.append(previous)
        arrows.append(following)

        box = Gtk.Box(spacing=6)
        box.append(self._entry)
        box.append(self._count)
        box.append(arrows)
        self.set_child(box)
        self.connect("notify::search-mode-enabled", self._on_mode_changed)

    def open(self):
        self.set_search_mode(True)
        self._entry.grab_focus()
        self._entry.select_region(0, -1)

    def _on_search_changed(self, entry):
        text = entry.get_text()
        if text:
            self._finder.search(text, FIND_OPTIONS, MAX_MATCHES)
        else:
            self._finder.search_finish()
            self._show_result(None)

    def _on_found(self, _finder, match_count):
        self._show_result(match_count)

    def _on_failed(self, _finder):
        self._show_result(0)

    def _show_result(self, match_count):
        if match_count is None:
            self._count.set_label("")
            self._entry.remove_css_class("error")
            return
        self._count.set_label("%d résultat%s" % (match_count, "s" if match_count > 1 else ""))
        if match_count:
            self._entry.remove_css_class("error")
        else:
            self._entry.add_css_class("error")

    def _on_mode_changed(self, *_):
        if not self.get_search_mode():
            self._finder.search_finish()
