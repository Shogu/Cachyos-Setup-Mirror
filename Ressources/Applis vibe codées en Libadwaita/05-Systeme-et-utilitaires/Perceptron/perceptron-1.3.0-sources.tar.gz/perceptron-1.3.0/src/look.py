"""Habillage GNOME de l'UI web d'OpenCode : polices Adwaita et couleur d'accent du système."""

from gi.repository import Adw, WebKit

CSS = """
html, body, input, textarea { font-family: "Adwaita Sans", "Cantarell", sans-serif !important; }
code, pre, kbd, samp { font-family: "Adwaita Mono", "Source Code Pro", monospace !important; }
html { accent-color: @ACCENT_BG@; }
::selection { background-color: color-mix(in srgb, @ACCENT_BG@ 35%, transparent); }
a { color: @ACCENT_FG@; }
input, textarea, [contenteditable="true"] { caret-color: @ACCENT_FG@; }
:focus-visible { outline-color: @ACCENT_BG@ !important; }
"""


class GnomeLook:
    def __init__(self, content_manager):
        self._manager = content_manager
        self._style = Adw.StyleManager.get_default()
        self._style.connect("notify::accent-color", self._apply)
        self._style.connect("notify::dark", self._apply)
        self._apply()

    def _apply(self, *_):
        accent = self._style.get_accent_color()
        source = (CSS
                  .replace("@ACCENT_BG@", Adw.AccentColor.to_rgba(accent).to_string())
                  .replace("@ACCENT_FG@", Adw.AccentColor.to_standalone_rgba(accent, self._style.get_dark()).to_string()))
        self._manager.remove_all_style_sheets()
        self._manager.add_style_sheet(WebKit.UserStyleSheet.new(
            source, WebKit.UserContentInjectedFrames.ALL_FRAMES, WebKit.UserStyleLevel.USER, None, None,
        ))
