"""Progression des transferts annoncée à Focus & Boutons (anneau de la barre du haut).

L'application exporte, sur sa propre connexion D-Bus (nom = identifiant de
l'application), l'objet /io/github/ogu/TransferProgress avec l'interface
io.github.ogu.TransferProgress. L'extension surveille le nom de l'application :
quand elle se ferme, l'anneau disparaît de lui-même.
"""
from gi.repository import Gio, GLib

OBJECT_PATH = '/io/github/ogu/TransferProgress'
INTERFACE = 'io.github.ogu.TransferProgress'
XML = f'''<node>
  <interface name="{INTERFACE}">
    <property name="Active" type="b" access="read"/>
    <property name="Progress" type="d" access="read"/>
    <property name="Title" type="s" access="read"/>
    <property name="Detail" type="s" access="read"/>
  </interface>
</node>'''
TYPES = {'Active': 'b', 'Progress': 'd', 'Title': 's', 'Detail': 's'}


class TransferProgress:
    def __init__(self):
        self._values = {'Active': False, 'Progress': 0.0, 'Title': '', 'Detail': ''}
        self._connection = None
        self._registration = 0

    def register(self, connection):
        """À appeler depuis Application.do_dbus_register."""
        info = Gio.DBusNodeInfo.new_for_xml(XML).interfaces[0]
        self._connection = connection
        self._registration = connection.register_object(OBJECT_PATH, info, None, self._get, None)

    def unregister(self):
        if self._registration:
            self._connection.unregister_object(self._registration)
        self._registration = 0
        self._connection = None

    def _get(self, _connection, _sender, _path, _interface, name):
        return GLib.Variant(TYPES[name], self._values[name])

    def update(self, active, progress=0.0, title='', detail=''):
        """N'émet un signal que si quelque chose a changé (appelable à chaque rafraîchissement)."""
        values = {'Active': bool(active), 'Progress': round(min(1.0, max(0.0, progress)), 2),
                  'Title': title, 'Detail': detail}
        if not values['Active']:
            values.update(Progress=0.0, Title='', Detail='')
        changed = {k: v for k, v in values.items() if v != self._values[k]}
        if not changed:
            return
        self._values.update(changed)
        if not self._connection:
            return
        props = {k: GLib.Variant(TYPES[k], v) for k, v in changed.items()}
        self._connection.emit_signal(None, OBJECT_PATH, 'org.freedesktop.DBus.Properties', 'PropertiesChanged',
                                     GLib.Variant('(sa{sv}as)', (INTERFACE, props, [])))
