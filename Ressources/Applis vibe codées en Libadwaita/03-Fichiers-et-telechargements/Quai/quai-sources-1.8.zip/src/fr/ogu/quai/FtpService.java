package fr.ogu.quai;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;

/**
 * Service au premier plan qui fait tourner le serveur. Android ne le tue pas,
 * et sa notification rappelle l'adresse à taper dans Fret.
 */
public final class FtpService extends Service implements FtpServer.Listener {
    static final String ACTION_STOP = "fr.ogu.quai.STOP";
    private static final String CHANNEL = "serveur";
    private static final int NOTIFICATION_ID = 1;
    private static final int IMPORTANCE_LOW = 2; // NotificationManager.IMPORTANCE_LOW (Android 7)

    static volatile boolean running;
    static volatile String error;

    private FtpServer server;
    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLock;

    static void start(Context context) {
        Intent intent = new Intent(context, FtpService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            // Context.startForegroundService (Android 8) : compilé contre l'API 23.
            try {
                Context.class.getMethod("startForegroundService", Intent.class).invoke(context, intent);
                return;
            } catch (ReflectiveOperationException ignored) {
                // Repli ci-dessous.
            }
        }
        context.startService(intent);
    }

    static void stop(Context context) {
        context.stopService(new Intent(context, FtpService.class));
    }

    /** « ftp://192.168.1.23:2121 », ou null sans réseau. */
    static String address(int port) {
        try {
            for (NetworkInterface iface : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!iface.isUp() || iface.isLoopback())
                    continue;
                for (InetAddress address : Collections.list(iface.getInetAddresses())) {
                    if (address instanceof Inet4Address && address.isSiteLocalAddress())
                        return "ftp://" + address.getHostAddress() + ":" + port;
                }
            }
        } catch (IOException ignored) {
            // Pas de réseau.
        }
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Watchdog.schedule(this);
        PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "quai:transfert");
        wakeLock.setReferenceCounted(false);
        WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        wifiLock = wifi == null ? null : wifi.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "quai:transfert");
        if (wifiLock != null)
            wifiLock.setReferenceCounted(false);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            new Settings(this).setUserStopped(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        Settings settings = new Settings(this);
        startForeground(NOTIFICATION_ID, notification(settings.port()));
        if (server == null) {
            try {
                server = new FtpServer(settings.port(), settings.password(), settings.storage(this), this);
                server.start();
                running = true;
                error = null;
            } catch (IOException failure) {
                server = null;
                error = failure.getMessage();
                stopSelf();
            }
        }
        return START_STICKY;
    }

    // La TV reste éveillée et le Wi-Fi à pleine vitesse seulement pendant qu'un client est connecté.
    @Override
    public void clientsChanged(int count) {
        if (count > 0) {
            wakeLock.acquire();
            if (wifiLock != null)
                wifiLock.acquire();
        } else {
            wakeLock.release();
            if (wifiLock != null)
                wifiLock.release();
        }
    }

    private Notification notification(int port) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder builder = builder(manager);
        String address = address(port);
        Intent stop = new Intent(this, FtpService.class).setAction(ACTION_STOP);
        Intent open = new Intent(this, MainActivity.class);
        return builder
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Serveur FTP en marche")
            .setContentText(address == null ? "En attente du réseau" : address)
            .setContentIntent(PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE))
            .addAction(new Notification.Action.Builder(null, "Arrêter",
                PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE)).build())
            .setOngoing(true)
            .build();
    }

    // Canaux de notification (Android 8) créés par réflexion : compilé contre l'API 23.
    private Notification.Builder builder(NotificationManager manager) {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                Class<?> channelClass = Class.forName("android.app.NotificationChannel");
                Object channel = channelClass.getConstructor(String.class, CharSequence.class, int.class)
                    .newInstance(CHANNEL, "Serveur FTP", IMPORTANCE_LOW);
                NotificationManager.class.getMethod("createNotificationChannel", channelClass).invoke(manager, channel);
                Constructor<Notification.Builder> constructor =
                    Notification.Builder.class.getConstructor(Context.class, String.class);
                return constructor.newInstance(this, CHANNEL);
            } catch (ReflectiveOperationException ignored) {
                // Repli ci-dessous.
            }
        }
        return new Notification.Builder(this);
    }

    @Override
    public void onDestroy() {
        if (server != null)
            server.stop();
        server = null;
        running = false;
        wakeLock.release();
        if (wifiLock != null)
            wifiLock.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
