package fr.ogu.quai;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** Une connexion de contrôle FTP (RFC 959, mode passif seulement). */
final class FtpSession implements Runnable {
    private static final int BUFFER = 256 * 1024;
    private static final int DATA_TIMEOUT_MS = 30000;
    private static final int IDLE_TIMEOUT_MS = 15 * 60 * 1000;
    private static final long SIX_MONTHS_MS = 182L * 24 * 3600 * 1000;

    private final Socket control;
    private final String password;
    private final Storage storage;
    private final FtpServer server;
    private Writer out;
    private boolean authenticated;
    private String cwd = "/";
    private ServerSocket passive;
    private long restart;
    private String renameFrom;

    FtpSession(Socket control, String password, Storage storage, FtpServer server) {
        this.control = control;
        this.password = password;
        this.storage = storage;
        this.server = server;
    }

    @Override
    public void run() {
        try {
            control.setSoTimeout(IDLE_TIMEOUT_MS);
            BufferedReader in = new BufferedReader(new InputStreamReader(control.getInputStream(), StandardCharsets.UTF_8));
            out = new BufferedWriter(new OutputStreamWriter(control.getOutputStream(), StandardCharsets.UTF_8));
            reply(220, "Quai prêt");
            for (String line = in.readLine(); line != null; line = in.readLine()) {
                int space = line.indexOf(' ');
                String command = (space < 0 ? line : line.substring(0, space)).toUpperCase(Locale.ROOT);
                String argument = space < 0 ? "" : line.substring(space + 1);
                if (!handle(command, argument))
                    break;
            }
        } catch (IOException ignored) {
            // Client parti.
        } finally {
            close();
            server.sessionEnded(this);
        }
    }

    void close() {
        closePassive();
        try {
            control.close();
        } catch (IOException ignored) {
            // Déjà fermé.
        }
    }

    private void reply(int code, String text) throws IOException {
        out.write(code + " " + text + "\r\n");
        out.flush();
    }

    private String path(String argument) {
        return Paths.resolve(cwd, argument);
    }

    /** false pour terminer la session. */
    private boolean handle(String command, String argument) throws IOException {
        switch (command) {
        case "USER":
            reply(331, "Mot de passe demandé");
            return true;
        case "PASS":
            authenticated = password.equals(argument);
            reply(authenticated ? 230 : 530, authenticated ? "Connecté" : "Mot de passe incorrect");
            return true;
        case "QUIT":
            reply(221, "Au revoir");
            return false;
        case "SYST":
            reply(215, "UNIX Type: L8");
            return true;
        case "FEAT":
            out.write("211-Extensions :\r\n UTF8\r\n SIZE\r\n MDTM\r\n REST STREAM\r\n EPSV\r\n PASV\r\n");
            reply(211, "Fin");
            return true;
        case "OPTS":
        case "NOOP":
            reply(200, "OK");
            return true;
        case "AUTH":
            reply(502, "Pas de TLS");
            return true;
        default:
            break;
        }
        if (!authenticated) {
            reply(530, "Connectez-vous d'abord");
            return true;
        }
        try {
            transferCommand(command, argument);
        } catch (IOException error) {
            reply(550, error.getMessage() == null ? "Échec" : error.getMessage());
        }
        return true;
    }

    private void transferCommand(String command, String argument) throws IOException {
        switch (command) {
        case "PWD":
        case "XPWD":
            reply(257, "\"" + cwd.replace("\"", "\"\"") + "\"");
            break;
        case "CWD":
        case "XCWD":
            changeDirectory(path(argument));
            break;
        case "CDUP":
        case "XCUP":
            changeDirectory(Paths.parent(cwd));
            break;
        case "TYPE":
        case "MODE":
        case "STRU":
            reply(200, "OK");
            break;
        case "PASV":
            openPassive();
            byte[] address = control.getLocalAddress().getAddress();
            int port = passive.getLocalPort();
            reply(227, String.format(Locale.ROOT, "Mode passif (%d,%d,%d,%d,%d,%d)", address[0] & 0xff, address[1] & 0xff,
                address[2] & 0xff, address[3] & 0xff, port >> 8, port & 0xff));
            break;
        case "EPSV":
            openPassive();
            reply(229, "Mode passif étendu (|||" + passive.getLocalPort() + "|)");
            break;
        case "PORT":
        case "EPRT":
            reply(502, "Utilisez le mode passif");
            break;
        case "LIST":
        case "NLST":
            list(command.equals("NLST"), argument);
            break;
        case "RETR":
            retrieve(path(argument));
            break;
        case "STOR":
        case "APPE":
            store(path(argument), command.equals("APPE"));
            break;
        case "REST":
            restart = Long.parseLong(argument.trim());
            reply(350, "Reprise à " + restart);
            break;
        case "SIZE":
            reply(213, Long.toString(existing(path(argument)).size));
            break;
        case "MDTM":
            reply(213, mdtm(existing(path(argument)).modified));
            break;
        case "MKD":
        case "XMKD":
            storage.mkdir(path(argument));
            reply(257, "\"" + path(argument) + "\" créé");
            break;
        case "RMD":
        case "XRMD":
        case "DELE":
            storage.delete(path(argument));
            reply(250, "Supprimé");
            break;
        case "RNFR":
            existing(path(argument));
            renameFrom = path(argument);
            reply(350, "Nouveau nom ?");
            break;
        case "RNTO":
            if (renameFrom == null) {
                reply(503, "RNFR d'abord");
                break;
            }
            storage.rename(renameFrom, path(argument));
            renameFrom = null;
            reply(250, "Renommé");
            break;
        case "ABOR":
            closePassive();
            reply(226, "Interrompu");
            break;
        default:
            reply(502, "Commande inconnue");
        }
    }

    private Storage.Entry existing(String path) throws IOException {
        Storage.Entry entry = storage.stat(path);
        if (entry == null)
            throw new IOException("Introuvable");
        return entry;
    }

    private void changeDirectory(String path) throws IOException {
        Storage.Entry entry = storage.stat(path);
        if (entry == null || !entry.directory) {
            reply(550, "Dossier introuvable");
            return;
        }
        cwd = path;
        reply(250, "OK");
    }

    private void openPassive() throws IOException {
        closePassive();
        passive = new ServerSocket(0, 1, control.getLocalAddress());
        passive.setSoTimeout(DATA_TIMEOUT_MS);
    }

    private void closePassive() {
        if (passive == null)
            return;
        try {
            passive.close();
        } catch (IOException ignored) {
            // Déjà fermé.
        }
        passive = null;
    }

    private Socket acceptData() throws IOException {
        if (passive == null)
            throw new IOException("PASV ou EPSV d'abord");
        try {
            Socket data = passive.accept();
            data.setSendBufferSize(BUFFER);
            data.setReceiveBufferSize(BUFFER);
            return data;
        } catch (SocketTimeoutException error) {
            throw new IOException("Pas de connexion de données");
        } finally {
            closePassive();
        }
    }

    private void list(boolean namesOnly, String argument) throws IOException {
        // Les options « -a », « -l »… sont ignorées.
        String target = argument.startsWith("-") ? argument.replaceFirst("^-\\S*\\s*", "") : argument;
        String path = path(target);
        Storage.Entry entry = existing(path);
        List<Storage.Entry> entries = entry.directory ? storage.list(path) : Collections.singletonList(entry);
        reply(150, "Liste");
        try (Socket data = acceptData();
             Writer writer = new BufferedWriter(new OutputStreamWriter(data.getOutputStream(), StandardCharsets.UTF_8))) {
            long now = System.currentTimeMillis();
            for (Storage.Entry child : entries)
                writer.write((namesOnly ? child.name : listLine(child, now)) + "\r\n");
        }
        reply(226, "Fin de la liste");
    }

    private static String listLine(Storage.Entry entry, long now) {
        String pattern = Math.abs(now - entry.modified) > SIX_MONTHS_MS ? "MMM dd  yyyy" : "MMM dd HH:mm";
        SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.US);
        return String.format(Locale.ROOT, "%s 1 tv tv %13d %s %s", entry.directory ? "drwxr-xr-x" : "-rw-r--r--",
            entry.directory ? 0 : entry.size, format.format(new Date(entry.modified)), entry.name);
    }

    private static String mdtm(long modified) {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss", Locale.ROOT);
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        return format.format(new Date(modified));
    }

    private void retrieve(String path) throws IOException {
        long offset = restart;
        restart = 0;
        if (existing(path).directory)
            throw new IOException("C'est un dossier");
        try (InputStream input = storage.openRead(path, offset)) {
            reply(150, "Envoi");
            try (Socket data = acceptData(); OutputStream output = data.getOutputStream()) {
                copy(input, output);
            }
        }
        reply(226, "Envoyé");
    }

    private void store(String path, boolean append) throws IOException {
        boolean resume = append || restart > 0;
        restart = 0;
        try (OutputStream output = storage.openWrite(path, resume)) {
            reply(150, "Réception");
            try (Socket data = acceptData(); InputStream input = data.getInputStream()) {
                copy(input, output);
            }
        }
        reply(226, "Reçu");
    }

    private static void copy(InputStream input, OutputStream output) throws IOException {
        byte[] buffer = new byte[BUFFER];
        for (int read = input.read(buffer); read >= 0; read = input.read(buffer))
            output.write(buffer, 0, read);
        output.flush();
    }
}
