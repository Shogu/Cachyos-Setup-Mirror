package fr.ogu.quai;

import android.content.Context;
import android.content.Intent;
import android.os.storage.StorageManager;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Disques branchés sur la TV (clé ou disque USB, carte SD), sans le sélecteur d'Android. */
final class Volumes {
    private Volumes() {
    }

    /** Racines des disques amovibles, par exemple /storage/1A2B-3C4D. */
    static List<File> removable(Context context) {
        List<File> roots = new ArrayList<>();
        File[] dirs = context.getExternalFilesDirs(null);
        // Le premier est le stockage interne ; les autres sont dans <disque>/Android/data/…
        for (int i = 1; i < dirs.length; i++) {
            if (dirs[i] == null)
                continue;
            String path = dirs[i].getAbsolutePath();
            int android = path.indexOf("/Android/data/");
            if (android > 0)
                roots.add(new File(path.substring(0, android)));
        }
        return roots;
    }

    /** Vrai si Quai peut écrire directement à la racine du disque. */
    static boolean writable(File root) {
        File probe = new File(root, ".quai-test");
        try {
            boolean created = probe.createNewFile() || probe.exists();
            return created && probe.delete();
        } catch (java.io.IOException | SecurityException error) {
            return false;
        }
    }

    /**
     * Demande d'accès au disque entier sans sélecteur de dossiers :
     * StorageVolume.createAccessIntent (Android 7 à 9), puis
     * createOpenDocumentTreeIntent (Android 10 et plus), appelés par réflexion.
     * null si la TV ne propose ni l'un ni l'autre.
     */
    static Intent accessIntent(Context context, File root) {
        Object volume;
        try {
            StorageManager manager = (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
            volume = StorageManager.class.getMethod("getStorageVolume", File.class).invoke(manager, root);
        } catch (ReflectiveOperationException error) {
            return null;
        }
        if (volume == null)
            return null;
        Intent intent = volumeIntent(volume, "createAccessIntent", true);
        if (intent == null || intent.resolveActivity(context.getPackageManager()) == null)
            intent = volumeIntent(volume, "createOpenDocumentTreeIntent", false);
        return intent != null && intent.resolveActivity(context.getPackageManager()) != null ? intent : null;
    }

    private static Intent volumeIntent(Object volume, String name, boolean wholeVolume) {
        try {
            if (wholeVolume)
                return (Intent) volume.getClass().getMethod(name, String.class).invoke(volume, (Object) null);
            return (Intent) volume.getClass().getMethod(name).invoke(volume);
        } catch (ReflectiveOperationException error) {
            return null;
        }
    }
}
