package fr.ogu.quai;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/** Serveur FTP minimal : un fil par client, mot de passe unique, identifiant libre. */
final class FtpServer {
    interface Listener {
        void clientsChanged(int count);
    }

    private final int port;
    private final String password;
    private final Storage storage;
    private final Listener listener;
    private final Set<FtpSession> sessions = Collections.synchronizedSet(new HashSet<FtpSession>());
    private ServerSocket socket;

    FtpServer(int port, String password, Storage storage, Listener listener) {
        this.port = port;
        this.password = password;
        this.storage = storage;
        this.listener = listener;
    }

    void start() throws IOException {
        socket = new ServerSocket(port);
        Thread acceptor = new Thread(new Runnable() {
            @Override
            public void run() {
                acceptLoop();
            }
        }, "quai-accept");
        acceptor.setDaemon(true);
        acceptor.start();
    }

    private void acceptLoop() {
        while (!socket.isClosed()) {
            try {
                Socket client = socket.accept();
                FtpSession session = new FtpSession(client, password, storage, this);
                sessions.add(session);
                listener.clientsChanged(sessions.size());
                Thread thread = new Thread(session, "quai-session");
                thread.setDaemon(true);
                thread.start();
            } catch (IOException error) {
                return;
            }
        }
    }

    void sessionEnded(FtpSession session) {
        sessions.remove(session);
        listener.clientsChanged(sessions.size());
    }

    void stop() {
        try {
            socket.close();
        } catch (IOException ignored) {
            // Déjà fermé.
        }
        synchronized (sessions) {
            for (FtpSession session : sessions)
                session.close();
        }
    }
}
