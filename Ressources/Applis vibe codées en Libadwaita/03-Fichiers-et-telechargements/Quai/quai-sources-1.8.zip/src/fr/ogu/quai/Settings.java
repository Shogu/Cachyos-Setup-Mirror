package fr.ogu.quai;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Environment;

import java.io.File;
import java.security.SecureRandom;

/** Réglages de Quai (mot de passe, port, dossier partagé, démarrage avec la TV). */
final class Settings {
    static final int DEFAULT_PORT = 2121;
    private static final String ALPHABET = "abcdefghijkmnpqrstuvwxyz23456789";

    private final SharedPreferences prefs;

    Settings(Context context) {
        prefs = context.getSharedPreferences("quai", Context.MODE_PRIVATE);
        if (!prefs.contains("password"))
            prefs.edit().putString("password", randomPassword()).apply();
    }

    private static String randomPassword() {
        SecureRandom random = new SecureRandom();
        StringBuilder password = new StringBuilder();
        for (int i = 0; i < 8; i++)
            password.append(ALPHABET.charAt(random.nextInt(ALPHABET.length())));
        return password.toString();
    }

    String password() {
        return prefs.getString("password", "");
    }

    void setPassword(String password) {
        prefs.edit().putString("password", password).apply();
    }

    int port() {
        return prefs.getInt("port", DEFAULT_PORT);
    }

    void setPort(int port) {
        prefs.edit().putInt("port", port).apply();
    }

    boolean autostart() {
        return prefs.getBoolean("autostart", true);
    }

    void setAutostart(boolean autostart) {
        prefs.edit().putBoolean("autostart", autostart).apply();
    }

    /** Vrai si le serveur a été arrêté exprès (interrupteur, bouton, notification) : on ne le relance pas tout seul. */
    boolean userStopped() {
        return prefs.getBoolean("user-stopped", false);
    }

    void setUserStopped(boolean stopped) {
        prefs.edit().putBoolean("user-stopped", stopped).apply();
    }

    void noteAutostart(String reason) {
        prefs.edit().putLong("autostart-time", System.currentTimeMillis()).putString("autostart-reason", reason).apply();
    }

    /** « 9 nov. 18:31 (démarrage de la TV) », ou null si le serveur n'a jamais démarré seul. */
    String lastAutostart() {
        long time = prefs.getLong("autostart-time", 0);
        if (time == 0)
            return null;
        String when = new java.text.SimpleDateFormat("d MMM HH:mm", java.util.Locale.FRANCE).format(new java.util.Date(time));
        return when + " (" + prefs.getString("autostart-reason", "") + ")";
    }

    /** Dossier choisi dans le sélecteur d'Android, ou null pour le stockage interne. */
    Uri tree() {
        String tree = prefs.getString("tree", null);
        return tree == null ? null : Uri.parse(tree);
    }

    void setTree(Uri tree) {
        prefs.edit().putString("tree", tree.toString()).remove("volume").apply();
    }

    /** Racine d'un disque choisi parmi ceux que Quai a détectés, ou null. */
    String volume() {
        return prefs.getString("volume", null);
    }

    void setVolume(String volume) {
        prefs.edit().putString("volume", volume).remove("tree").apply();
    }

    /** Stockage interne : ni disque, ni dossier du sélecteur. */
    void useInternal() {
        prefs.edit().remove("tree").remove("volume").apply();
    }

    Storage storage(Context context) {
        Uri tree = tree();
        if (tree != null)
            return new SafStorage(context.getContentResolver(), tree);
        String volume = volume();
        if (volume != null)
            return new FileStorage(new File(volume));
        return new FileStorage(Environment.getExternalStorageDirectory());
    }
}
