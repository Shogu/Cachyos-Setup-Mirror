package fr.ogu.quai;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.DocumentsContract.Document;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Dossier choisi dans le sélecteur d'Android (disque USB, carte SD) : seul
 * moyen d'y écrire pour une appli. Les chemins sont résolus nom par nom.
 */
final class SafStorage implements Storage {
    private static final String[] COLUMNS = {
        Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE,
        Document.COLUMN_SIZE, Document.COLUMN_LAST_MODIFIED,
    };

    private final ContentResolver resolver;
    private final Uri tree;
    private final String rootId;

    SafStorage(ContentResolver resolver, Uri tree) {
        this.resolver = resolver;
        this.tree = tree;
        this.rootId = DocumentsContract.getTreeDocumentId(tree);
    }

    private static final class Row {
        final String id;
        final Entry entry;

        Row(String id, Entry entry) {
            this.id = id;
            this.entry = entry;
        }
    }

    private List<Row> children(String parentId) throws IOException {
        Uri uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId);
        List<Row> rows = new ArrayList<>();
        try (Cursor cursor = resolver.query(uri, COLUMNS, null, null, null)) {
            if (cursor == null)
                throw new IOException("Dossier illisible");
            while (cursor.moveToNext()) {
                boolean directory = Document.MIME_TYPE_DIR.equals(cursor.getString(2));
                rows.add(new Row(cursor.getString(0),
                    new Entry(cursor.getString(1), directory, cursor.getLong(3), cursor.getLong(4))));
            }
        } catch (SecurityException | IllegalArgumentException error) {
            throw new IOException(error.getMessage());
        }
        return rows;
    }

    private Row child(String parentId, String name) throws IOException {
        for (Row row : children(parentId)) {
            if (row.entry.name.equals(name))
                return row;
        }
        return null;
    }

    /** Identifiant du document, ou null s'il n'existe pas. */
    private String resolve(String path) throws IOException {
        String id = rootId;
        for (String name : Paths.segments(path)) {
            Row row = child(id, name);
            if (row == null)
                return null;
            id = row.id;
        }
        return id;
    }

    private String require(String path) throws IOException {
        String id = resolve(path);
        if (id == null)
            throw new FileNotFoundException(path);
        return id;
    }

    private Uri uri(String id) {
        return DocumentsContract.buildDocumentUriUsingTree(tree, id);
    }

    @Override
    public Entry stat(String path) {
        if (path.equals("/"))
            return new Entry("/", true, 0, 0);
        try {
            String parentId = resolve(Paths.parent(path));
            Row row = parentId == null ? null : child(parentId, Paths.name(path));
            return row == null ? null : row.entry;
        } catch (IOException error) {
            return null;
        }
    }

    @Override
    public List<Entry> list(String path) throws IOException {
        List<Entry> entries = new ArrayList<>();
        for (Row row : children(require(path)))
            entries.add(row.entry);
        return entries;
    }

    @Override
    public InputStream openRead(String path, long offset) throws IOException {
        InputStream input = resolver.openInputStream(uri(require(path)));
        if (input == null)
            throw new FileNotFoundException(path);
        long skipped = 0;
        while (skipped < offset) {
            long step = input.skip(offset - skipped);
            if (step <= 0)
                break;
            skipped += step;
        }
        return input;
    }

    @Override
    public OutputStream openWrite(String path, boolean append) throws IOException {
        String id = resolve(path);
        if (id == null) {
            Uri created = create(Paths.parent(path), "application/octet-stream", Paths.name(path));
            return resolver.openOutputStream(created, "w");
        }
        return resolver.openOutputStream(uri(id), append ? "wa" : "wt");
    }

    private Uri create(String parentPath, String mime, String name) throws IOException {
        Uri created = DocumentsContract.createDocument(resolver, uri(require(parentPath)), mime, name);
        if (created == null)
            throw new IOException("Création impossible");
        return created;
    }

    @Override
    public void mkdir(String path) throws IOException {
        create(Paths.parent(path), Document.MIME_TYPE_DIR, Paths.name(path));
    }

    @Override
    public void delete(String path) throws IOException {
        if (!DocumentsContract.deleteDocument(resolver, uri(require(path))))
            throw new IOException("Suppression impossible");
    }

    @Override
    public void rename(String from, String to) throws IOException {
        Uri document = uri(require(from));
        String fromParent = Paths.parent(from);
        String toParent = Paths.parent(to);
        if (!fromParent.equals(toParent))
            document = move(document, uri(require(fromParent)), uri(require(toParent)));
        if (!Paths.name(from).equals(Paths.name(to))
                && DocumentsContract.renameDocument(resolver, document, Paths.name(to)) == null)
            throw new IOException("Renommage impossible");
    }

    // DocumentsContract.moveDocument (Android 7) : appelé par réflexion, l'appli
    // est compilée contre l'API 23.
    private Uri move(Uri document, Uri source, Uri target) throws IOException {
        try {
            Method method = DocumentsContract.class.getMethod("moveDocument",
                ContentResolver.class, Uri.class, Uri.class, Uri.class);
            Uri moved = (Uri) method.invoke(null, resolver, document, source, target);
            if (moved == null)
                throw new IOException("Déplacement impossible");
            return moved;
        } catch (ReflectiveOperationException error) {
            throw new IOException("Déplacement impossible");
        }
    }
}
