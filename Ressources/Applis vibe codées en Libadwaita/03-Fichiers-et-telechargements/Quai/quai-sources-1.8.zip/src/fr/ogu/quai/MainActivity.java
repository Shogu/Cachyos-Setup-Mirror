package fr.ogu.quai;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.List;

/** Un seul écran, utilisable à la télécommande. */
public final class MainActivity extends Activity {
    private static final int PICK_TREE = 1;
    private static final int REFRESH_MS = 1000;

    private final Handler handler = new Handler();
    private final Runnable refresher = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, REFRESH_MS);
        }
    };

    private Settings settings;
    private TextView status;
    private TextView connection;
    private Button toggle;
    private EditText password;
    private EditText port;
    private TextView folder;
    private TextView lastStart;
    private LinearLayout folderButtons;
    private String disks = "";
    private final java.util.Map<String, Boolean> writable = new java.util.HashMap<>();

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        settings = new Settings(this);

        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        int margin = dp(48);
        column.setPadding(margin, dp(27), margin, dp(27));

        column.addView(text("Quai", 34, true));
        status = text("", 24, true);
        column.addView(status);
        connection = text("", 18, false);
        column.addView(connection);
        toggle = button("", new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (FtpService.running) {
                    settings.setUserStopped(true);
                    FtpService.stop(MainActivity.this);
                } else {
                    settings.setUserStopped(false);
                    FtpService.start(MainActivity.this);
                }
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        refresh();
                    }
                }, 300);
            }
        });
        column.addView(toggle);

        column.addView(heading("Mot de passe et port"));
        password = field(settings.password(), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        column.addView(password);
        port = field(Integer.toString(settings.port()), InputType.TYPE_CLASS_NUMBER);
        column.addView(port);
        column.addView(button("Enregistrer", new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveCredentials();
            }
        }));

        column.addView(heading("Dossier partagé"));
        folder = text("", 18, false);
        column.addView(folder);
        folderButtons = new LinearLayout(this);
        column.addView(folderButtons);

        column.addView(heading("Démarrage"));
        CheckBox autostart = new CheckBox(this);
        autostart.setText("Démarrer le serveur avec la TV");
        autostart.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        autostart.setChecked(settings.autostart());
        autostart.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton button, boolean checked) {
                settings.setAutostart(checked);
            }
        });
        column.addView(autostart);
        lastStart = text("", 16, false);
        column.addView(lastStart);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(column);
        setContentView(scroll);
        toggle.requestFocus();
        requestStorage();
        Watchdog.schedule(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(refresher);
    }

    // Un bouton par disque branché ; reconstruit quand on branche ou débranche un disque.
    private void fillFolderButtons() {
        List<File> roots = Volumes.removable(this);
        String key = roots.toString();
        if (key.equals(disks) && folderButtons.getChildCount() > 0)
            return;
        disks = key;
        writable.clear();
        folderButtons.removeAllViews();
        folderButtons.addView(button("Stockage interne", new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                settings.useInternal();
                requestStorage();
                restartIfRunning();
            }
        }));
        for (final File root : roots) {
            folderButtons.addView(button("Disque " + root.getName(), new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    chooseDisk(root);
                }
            }));
        }
        if (new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).resolveActivity(getPackageManager()) != null) {
            folderButtons.addView(button("Autre dossier…", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    pickTree();
                }
            }));
        }
    }

    private boolean isWritable(File root) {
        String path = root.getAbsolutePath();
        if (!writable.containsKey(path))
            writable.put(path, Volumes.writable(root));
        return writable.get(path);
    }

    // Écriture directe si la TV le permet ; sinon demande d'accès au disque entier ;
    // sinon le disque est partagé en lecture seule.
    private void chooseDisk(File root) {
        if (!isWritable(root)) {
            Intent access = Volumes.accessIntent(this, root);
            if (access != null) {
                startActivityForResult(access, PICK_TREE);
                return;
            }
            Toast.makeText(this, "Cette TV ne laisse pas les applis écrire sur ce disque : il sera en lecture seule.",
                Toast.LENGTH_LONG).show();
        }
        settings.setVolume(root.getAbsolutePath());
        restartIfRunning();
        refresh();
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(refresher);
        super.onPause();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private TextView text(String value, int size, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        if (bold)
            view.setTypeface(view.getTypeface(), android.graphics.Typeface.BOLD);
        view.setPadding(0, dp(4), 0, dp(4));
        return view;
    }

    private TextView heading(String value) {
        TextView view = text(value, 20, true);
        view.setPadding(0, dp(24), 0, dp(4));
        return view;
    }

    private Button button(String label, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        button.setOnClickListener(listener);
        button.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT));
        return button;
    }

    private EditText field(String value, int type) {
        EditText field = new EditText(this);
        field.setText(value);
        field.setInputType(type);
        field.setSingleLine(true);
        field.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        field.setGravity(Gravity.START);
        field.setLayoutParams(new LinearLayout.LayoutParams(dp(360), ViewGroup.LayoutParams.WRAP_CONTENT));
        return field;
    }

    private void refresh() {
        boolean running = FtpService.running;
        status.setText(running ? "Serveur en marche" : "Serveur arrêté");
        toggle.setText(running ? "Arrêter le serveur" : "Démarrer le serveur");
        String address = FtpService.address(settings.port());
        if (FtpService.error != null && !running)
            connection.setText("Démarrage impossible : " + FtpService.error);
        else if (address == null)
            connection.setText("La TV n'est pas connectée au réseau.");
        else
            connection.setText("Dans Fret : " + address + "\nIdentifiant : au choix · mot de passe : " + settings.password());
        fillFolderButtons();
        String last = settings.lastAutostart();
        lastStart.setText("Dernier démarrage automatique : " + (last == null ? "jamais" : last));
        Uri tree = settings.tree();
        String volume = settings.volume();
        if (tree != null)
            folder.setText(Uri.decode(tree.getLastPathSegment()) + " — lecture et écriture");
        else if (volume != null)
            folder.setText("Disque " + new File(volume).getName()
                + (isWritable(new File(volume)) ? " — lecture et écriture" : " — lecture seule sur cette TV"));
        else
            folder.setText("Stockage interne de la TV");
    }

    private void saveCredentials() {
        String newPassword = password.getText().toString().trim();
        int newPort;
        try {
            newPort = Integer.parseInt(port.getText().toString().trim());
        } catch (NumberFormatException error) {
            newPort = -1;
        }
        if (newPassword.isEmpty() || newPort < 1024 || newPort > 65535) {
            Toast.makeText(this, "Mot de passe vide ou port hors de 1024–65535", Toast.LENGTH_LONG).show();
            return;
        }
        settings.setPassword(newPassword);
        settings.setPort(newPort);
        restartIfRunning();
        Toast.makeText(this, "Enregistré", Toast.LENGTH_SHORT).show();
    }

    private void restartIfRunning() {
        if (!FtpService.running)
            return;
        FtpService.stop(this);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                FtpService.start(MainActivity.this);
            }
        }, 500);
    }

    private void requestStorage() {
        if (settings.tree() == null && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);
    }

    private void pickTree() {
        try {
            startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), PICK_TREE);
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "Cette TV n'a pas de sélecteur de dossiers.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        if (request != PICK_TREE || result != RESULT_OK || data == null || data.getData() == null)
            return;
        Uri tree = data.getData();
        getContentResolver().takePersistableUriPermission(tree,
            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        settings.setTree(tree);
        restartIfRunning();
        refresh();
    }
}
