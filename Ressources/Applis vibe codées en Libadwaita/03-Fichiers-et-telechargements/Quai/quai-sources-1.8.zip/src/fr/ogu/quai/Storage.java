package fr.ogu.quai;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

/** Arborescence partagée, adressée par des chemins virtuels « /a/b ». */
interface Storage {
    final class Entry {
        final String name;
        final boolean directory;
        final long size;
        final long modified;

        Entry(String name, boolean directory, long size, long modified) {
            this.name = name;
            this.directory = directory;
            this.size = size;
            this.modified = modified;
        }
    }

    /** null si le chemin n'existe pas. */
    Entry stat(String path);

    List<Entry> list(String path) throws IOException;

    InputStream openRead(String path, long offset) throws IOException;

    OutputStream openWrite(String path, boolean append) throws IOException;

    void mkdir(String path) throws IOException;

    void delete(String path) throws IOException;

    void rename(String from, String to) throws IOException;
}
