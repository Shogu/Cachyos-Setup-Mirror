package fr.ogu.quai;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;

/**
 * Interrupteur sans écran : démarre le serveur s'il est arrêté, l'arrête sinon, et le dit dans un
 * message. Utile quand la TV ne le lance pas toute seule.
 */
public final class ToggleActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Settings settings = new Settings(this);
        if (FtpService.running) {
            settings.setUserStopped(true);
            FtpService.stop(this);
            Toast.makeText(this, "Quai : serveur FTP arrêté", Toast.LENGTH_LONG).show();
        } else {
            settings.setUserStopped(false);
            settings.noteAutostart("interrupteur");
            FtpService.start(this);
            String address = FtpService.address(settings.port());
            Toast.makeText(this, "Quai : serveur FTP démarré" + (address == null ? "" : "\n" + address),
                Toast.LENGTH_LONG).show();
        }
        finish();
    }
}
