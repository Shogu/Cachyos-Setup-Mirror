package fr.ogu.quai;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/** Dossier ordinaire (stockage interne de la TV). */
final class FileStorage implements Storage {
    private final File root;

    FileStorage(File root) {
        this.root = root;
    }

    private File file(String path) {
        return path.equals("/") ? root : new File(root, path.substring(1));
    }

    private static Entry entry(File file, String name) {
        return new Entry(name, file.isDirectory(), file.length(), file.lastModified());
    }

    @Override
    public Entry stat(String path) {
        File file = file(path);
        return file.exists() ? entry(file, file.getName()) : null;
    }

    @Override
    public List<Entry> list(String path) throws IOException {
        File[] files = file(path).listFiles();
        if (files == null)
            throw new IOException("Dossier illisible");
        List<Entry> entries = new ArrayList<>();
        for (File child : files)
            entries.add(entry(child, child.getName()));
        return entries;
    }

    @Override
    public InputStream openRead(String path, long offset) throws IOException {
        FileInputStream input = new FileInputStream(file(path));
        if (offset > 0)
            input.getChannel().position(offset);
        return input;
    }

    @Override
    public OutputStream openWrite(String path, boolean append) throws FileNotFoundException {
        return new FileOutputStream(file(path), append);
    }

    @Override
    public void mkdir(String path) throws IOException {
        if (!file(path).mkdir())
            throw new IOException("Création impossible");
    }

    @Override
    public void delete(String path) throws IOException {
        if (!file(path).delete())
            throw new IOException("Suppression impossible");
    }

    @Override
    public void rename(String from, String to) throws IOException {
        if (!file(from).renameTo(file(to)))
            throw new IOException("Renommage impossible");
    }
}
