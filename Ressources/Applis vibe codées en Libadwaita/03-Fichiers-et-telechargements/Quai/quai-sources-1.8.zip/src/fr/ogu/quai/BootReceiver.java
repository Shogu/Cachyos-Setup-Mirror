package fr.ogu.quai;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;

/** Démarre le serveur avec la TV, après une mise à jour de Quai ou quand un disque est branché. */
public final class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Watchdog.schedule(context);
        Settings settings = new Settings(context);
        String action = intent.getAction();
        if (FtpService.running && Intent.ACTION_MEDIA_MOUNTED.equals(action)) {
            restartForDisk(context, settings);
            return;
        }
        if (!settings.autostart() || settings.userStopped() || FtpService.running)
            return;
        String reason;
        if (Intent.ACTION_MEDIA_MOUNTED.equals(action))
            reason = "disque branché";
        else if (Intent.ACTION_MY_PACKAGE_REPLACED.equals(action))
            reason = "mise à jour de Quai";
        else
            reason = "démarrage de la TV";
        settings.noteAutostart(reason);
        FtpService.start(context);
    }

    // TCL monte le disque externe longtemps après le démarrage : le serveur, déjà lancé sur un dossier
    // encore absent, repart une fois le disque là pour le voir.
    private void restartForDisk(final Context context, Settings settings) {
        if (settings.volume() == null && settings.tree() == null)
            return;
        final PendingResult pending = goAsync();
        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                FtpService.stop(context);
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        FtpService.start(context);
                        pending.finish();
                    }
                }, 1000);
            }
        }, 3000);
    }
}
