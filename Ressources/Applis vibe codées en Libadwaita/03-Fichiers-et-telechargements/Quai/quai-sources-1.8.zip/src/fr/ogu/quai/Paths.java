package fr.ogu.quai;

import java.util.ArrayList;
import java.util.List;

/** Chemins virtuels du serveur : toujours absolus, sans « . » ni « .. ». */
final class Paths {
    private Paths() {
    }

    static String resolve(String cwd, String argument) {
        String joined = argument.startsWith("/") ? argument : cwd + "/" + argument;
        List<String> parts = new ArrayList<>();
        for (String part : joined.split("/")) {
            if (part.isEmpty() || part.equals("."))
                continue;
            if (part.equals("..")) {
                if (!parts.isEmpty())
                    parts.remove(parts.size() - 1);
            } else {
                parts.add(part);
            }
        }
        StringBuilder path = new StringBuilder();
        for (String part : parts)
            path.append('/').append(part);
        return path.length() == 0 ? "/" : path.toString();
    }

    static List<String> segments(String path) {
        List<String> parts = new ArrayList<>();
        for (String part : path.split("/")) {
            if (!part.isEmpty())
                parts.add(part);
        }
        return parts;
    }

    static String parent(String path) {
        int slash = path.lastIndexOf('/');
        return slash <= 0 ? "/" : path.substring(0, slash);
    }

    static String name(String path) {
        return path.substring(path.lastIndexOf('/') + 1);
    }
}
