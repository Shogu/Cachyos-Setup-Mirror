package fr.ogu.quai;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;

/**
 * Relance le serveur s'il ne tourne plus. Rallumer la TV à la télécommande la
 * sort de veille sans signal de démarrage, et la veille ferme souvent les
 * applis. Cette tâche, gardée par Android même quand Quai est fermé, se
 * reprogramme chaque minute ; en veille, Android la met en attente et
 * l'exécute dès le réveil, quand le réseau revient.
 */
public final class Watchdog extends JobService {
    private static final int OLD_PERIODIC_JOB_ID = 1;
    private static final int JOB_ID = 2;
    private static final long DELAY_MS = 60 * 1000;

    /** Programme la tâche si elle ne l'est pas déjà. */
    static void schedule(Context context) {
        JobScheduler scheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        scheduler.cancel(OLD_PERIODIC_JOB_ID);
        for (JobInfo job : scheduler.getAllPendingJobs()) {
            if (job.getId() == JOB_ID)
                return;
        }
        scheduleNext(scheduler, context);
    }

    private static void scheduleNext(JobScheduler scheduler, Context context) {
        scheduler.schedule(new JobInfo.Builder(JOB_ID, new ComponentName(context, Watchdog.class))
            .setMinimumLatency(DELAY_MS)
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            .setPersisted(true)
            .build());
    }

    @Override
    public boolean onStartJob(JobParameters params) {
        Settings settings = new Settings(this);
        if (settings.autostart() && !settings.userStopped() && !FtpService.running) {
            settings.noteAutostart("réveil de la TV");
            FtpService.start(this);
        }
        scheduleNext((JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE), this);
        return false;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return false;
    }
}
