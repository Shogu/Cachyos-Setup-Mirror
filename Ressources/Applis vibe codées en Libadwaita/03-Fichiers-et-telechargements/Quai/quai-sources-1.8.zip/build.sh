#!/bin/sh
# Construit Quai-<version>.apk (paquets Ubuntu : android-sdk-platform-23 aapt dalvik-exchange zipalign apksigner).
set -e
: "${QUAI_KS_PASS:?Définis QUAI_KS_PASS (mot de passe du trousseau quai.keystore)}"
cd "$(dirname "$0")"
AJ=/usr/lib/android-sdk/platforms/android-23/android.jar
VERSION=$(sed -n 's/.*android:versionName="\([^"]*\)".*/\1/p' AndroidManifest.xml)
rm -rf build && mkdir -p build/gen build/classes
aapt package -f -m -J build/gen -M AndroidManifest.xml -S res -I "$AJ" -F build/quai.apk
javac -source 8 -target 8 -encoding UTF-8 -Xlint:-options -bootclasspath "$AJ" -d build/classes build/gen/fr/ogu/quai/R.java src/fr/ogu/quai/*.java
dalvik-exchange --dex --min-sdk-version=23 --output=build/classes.dex build/classes
(cd build && aapt add quai.apk classes.dex >/dev/null && zipalign -f 4 quai.apk quai-aligned.apk)
apksigner sign --ks quai.keystore --ks-pass env:QUAI_KS_PASS --ks-key-alias quai --out "Quai-$VERSION.apk" build/quai-aligned.apk
echo "Quai-$VERSION.apk"
