# Generated with AI for personal use.
import ctypes
import sys

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("Gdk", "4.0")
gi.require_version("GdkPixbuf", "2.0")

from gi.repository import GLib  # noqa: E402

from valise.application import APP_ID, ValiseApplication  # noqa: E402

PR_SET_NAME = 15


def main() -> int:
    ctypes.CDLL(None).prctl(PR_SET_NAME, b"valise", 0, 0, 0)
    GLib.set_prgname(APP_ID)
    GLib.set_application_name("Valise")
    return ValiseApplication().run(sys.argv)


if __name__ == "__main__":
    sys.exit(main())
