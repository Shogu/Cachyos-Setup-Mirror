from gi.repository import Adw, Gdk, GLib, Gio, Gtk

from valise.item import ValiseItem
from valise.row import ValiseRow
from valise.store import load_items, save_items
from valise.transfer import files_provider, zip_files_async

EMPTY_DESCRIPTION = "Glissez des fichiers ici, collez-les avec Ctrl+V ou ajoutez-les avec le bouton +"


class ValiseWindow(Adw.ApplicationWindow):
    __gtype_name__ = "ValiseWindow"

    def __init__(self, **kwargs):
        super().__init__(title="Valise", default_width=360, default_height=480, **kwargs)

        self.store = Gio.ListStore(item_type=ValiseItem)
        self.store.splice(0, 0, load_items())
        self.store.connect("items-changed", lambda *_: self._on_items_changed())

        self._toasts = Adw.ToastOverlay()
        toolbar = Adw.ToolbarView()
        toolbar.add_top_bar(self._build_header())
        toolbar.set_content(self._build_content())
        toolbar.add_bottom_bar(self._build_action_bar())
        self._toasts.set_child(toolbar)
        self.set_content(self._toasts)

        drop = Gtk.DropTarget.new(Gdk.FileList, Gdk.DragAction.COPY)
        drop.connect("drop", self._on_drop)
        self._toasts.add_controller(drop)

        self._install_actions()
        self.connect("notify::is-active", self._on_active_changed)
        self._on_items_changed(save=False)

    def _build_header(self) -> Adw.HeaderBar:
        header = Adw.HeaderBar()
        add = Gtk.Button(icon_name="list-add-symbolic", tooltip_text="Ajouter des fichiers")
        add.connect("clicked", self._on_add_clicked)
        header.pack_start(add)

        menu = Gio.Menu()
        selection = Gio.Menu()
        selection.append("Tout sélectionner", "win.select-all")
        selection.append("Tout désélectionner", "win.select-none")
        menu.append_section(None, selection)
        content = Gio.Menu()
        content.append("Vider la valise", "win.clear")
        menu.append_section(None, content)
        about = Gio.Menu()
        about.append("À propos de Valise", "app.about")
        menu.append_section(None, about)
        header.pack_end(Gtk.MenuButton(icon_name="open-menu-symbolic", menu_model=menu, tooltip_text="Menu principal"))
        return header

    def _build_content(self) -> Gtk.Stack:
        self._stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, hexpand=True, vexpand=True)

        empty = Adw.StatusPage(icon_name="io.gitlab.shogu.Valise-symbolic", title="Valise vide", description=EMPTY_DESCRIPTION)
        self._stack.add_named(empty, "empty")

        self._list = Gtk.ListBox(
            selection_mode=Gtk.SelectionMode.NONE,
            valign=Gtk.Align.START,
            hexpand=True,
            margin_top=12,
            margin_bottom=12,
            margin_start=12,
            margin_end=12,
        )
        self._list.add_css_class("boxed-list")
        self._list.bind_model(self.store, lambda item: ValiseRow(item, self))
        self._stack.add_named(Gtk.ScrolledWindow(child=self._list, hscrollbar_policy=Gtk.PolicyType.NEVER), "list")
        return self._stack

    def _build_action_bar(self) -> Gtk.ActionBar:
        bar = Gtk.ActionBar()
        self._count = Gtk.Label()
        self._count.add_css_class("dim-label")
        bar.pack_start(self._count)
        for icon, action, tooltip in (
            ("edit-copy-symbolic", "win.copy", "Copier (Ctrl+C)"),
            ("edit-cut-symbolic", "win.cut", "Couper (Ctrl+X)"),
            ("package-x-generic-symbolic", "win.zip", "Créer une archive zip"),
            ("list-remove-symbolic", "win.remove", "Retirer de la valise (Suppr)"),
        ):
            bar.pack_end(Gtk.Button(icon_name=icon, action_name=action, tooltip_text=tooltip))
        self._bar = bar
        return bar

    def _install_actions(self):
        self._selection_actions = []
        for name, callback, needs_selection in (
            ("paste", self._paste_from_clipboard, False),
            ("copy", lambda: self._to_clipboard(cut=False), True),
            ("cut", lambda: self._to_clipboard(cut=True), True),
            ("zip", self._zip_selected, True),
            ("remove", lambda: self.remove_items(self.selected_items()), True),
            ("select-all", lambda: self._select_all(True), False),
            ("select-none", lambda: self._select_all(False), False),
            ("clear", lambda: self.remove_items(self.items()), False),
        ):
            action = Gio.SimpleAction.new(name, None)
            action.connect("activate", lambda _a, _p, cb=callback: cb())
            self.add_action(action)
            if needs_selection:
                self._selection_actions.append(action)

    def items(self) -> list[ValiseItem]:
        return list(self.store)

    def selected_items(self) -> list[ValiseItem]:
        return [item for item in self.store if item.selected and item.exists]

    def add_files(self, files: list[Gio.File]):
        known = {item.uri for item in self.store}
        new = []
        for file in files:
            uri = file.get_uri()
            if uri not in known:
                known.add(uri)
                new.append(ValiseItem(file))
        if new:
            self.store.splice(self.store.get_n_items(), 0, new)

    def remove_items(self, items: list[ValiseItem]):
        doomed = {item.uri for item in items}
        kept = [item for item in self.store if item.uri not in doomed]
        self.store.splice(0, self.store.get_n_items(), kept)

    def drag_files_for(self, item: ValiseItem) -> list[Gio.File]:
        """Dragging a selected row carries the whole selection; an unselected row travels alone."""
        if item.selected:
            return [selected.file for selected in self.selected_items()]
        return [item.file] if item.exists else []

    def files_content(self, files: list[Gio.File]) -> Gdk.ContentProvider:
        return files_provider(files)

    def on_selection_changed(self):
        save_items(self.items())
        self._update_selection_state()

    def _on_items_changed(self, save: bool = True):
        if save:
            save_items(self.items())
        self._stack.set_visible_child_name("list" if self.store.get_n_items() else "empty")
        self._bar.set_revealed(self.store.get_n_items() > 0)
        self.lookup_action("clear").set_enabled(self.store.get_n_items() > 0)
        self._update_selection_state()

    def _update_selection_state(self):
        selected = len(self.selected_items())
        total = self.store.get_n_items()
        for action in self._selection_actions:
            action.set_enabled(selected > 0)
        self._count.set_label(f"{selected} sur {total}" if total else "")

    def _select_all(self, selected: bool):
        for item in self.store:
            item.selected = selected
        self.on_selection_changed()

    def _on_active_changed(self, *_):
        if not self.is_active():
            return
        changed = False
        for item in self.store:
            existed = item.exists
            item.refresh()
            changed |= existed != item.exists
        if changed:
            n = self.store.get_n_items()
            self.store.items_changed(0, n, n)

    def _on_drop(self, _target, value: Gdk.FileList, _x, _y) -> bool:
        self.add_files(value.get_files())
        return True

    def _on_add_clicked(self, *_):
        Gtk.FileDialog(title="Ajouter à la valise", modal=True).open_multiple(self, None, self._on_add_finished)

    def _on_add_finished(self, dialog: Gtk.FileDialog, result):
        try:
            files = dialog.open_multiple_finish(result)
        except GLib.Error:
            return
        self.add_files(list(files))

    def _paste_from_clipboard(self):
        self.get_clipboard().read_value_async(Gdk.FileList, GLib.PRIORITY_DEFAULT, None, self._on_paste_finished)

    def _on_paste_finished(self, clipboard: Gdk.Clipboard, result):
        try:
            files = clipboard.read_value_finish(result).get_files()
        except GLib.Error:
            self._toast("Le presse-papier ne contient pas de fichiers")
            return
        self.add_files(files)

    def _to_clipboard(self, cut: bool):
        files = [item.file for item in self.selected_items()]
        self.get_clipboard().set_content(files_provider(files, cut=cut))
        verb = "coupé" if cut else "copié"
        self._toast(f"{len(files)} élément{'s' if len(files) > 1 else ''} {verb}{'s' if len(files) > 1 else ''}")

    def _zip_selected(self):
        items = self.selected_items()
        parent = items[0].file.get_parent()
        dialog = Gtk.FileDialog(title="Enregistrer l'archive", modal=True)
        dialog.set_initial_name(f"valise-{GLib.DateTime.new_now_local().format('%Y-%m-%d')}.zip")
        if parent:
            dialog.set_initial_folder(parent)
        dialog.save(self, None, self._on_zip_destination, [item.file.get_path() for item in items if item.file.get_path()])

    def _on_zip_destination(self, dialog: Gtk.FileDialog, result, sources: list[str]):
        try:
            destination = dialog.save_finish(result)
        except GLib.Error:
            return
        path = destination.get_path()
        self._toast("Création de l'archive…")
        zip_files_async(path, sources, lambda error: self._on_zip_done(path, error))

    def _on_zip_done(self, path: str, error: str | None):
        if error:
            self._toast(f"Archive impossible : {error}")
        else:
            toast = Adw.Toast(title=f"Archive créée : {GLib.path_get_basename(path)}", button_label="Afficher")
            toast.connect(
                "button-clicked", lambda *_: Gtk.FileLauncher.new(Gio.File.new_for_path(path)).open_containing_folder(self, None, None)
            )
            self._toasts.add_toast(toast)
        return GLib.SOURCE_REMOVE

    def _toast(self, title: str):
        self._toasts.add_toast(Adw.Toast(title=title, timeout=2))
