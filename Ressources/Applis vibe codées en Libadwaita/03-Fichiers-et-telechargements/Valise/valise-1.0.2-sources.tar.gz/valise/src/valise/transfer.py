import os
import threading
import zipfile

from gi.repository import Gdk, GLib, Gio


def files_provider(files: list[Gio.File], cut: bool = False) -> Gdk.ContentProvider:
    """Clipboard/drag content understood by Files (copy or cut), browsers and text fields."""
    uris = [file.get_uri() for file in files]
    gnome = ("cut" if cut else "copy") + "\n" + "\n".join(uris)
    paths = "\n".join(file.get_path() or file.get_uri() for file in files)
    return Gdk.ContentProvider.new_union(
        [
            Gdk.ContentProvider.new_for_value(Gdk.FileList.new_from_list(files)),
            Gdk.ContentProvider.new_for_bytes("x-special/gnome-copied-files", GLib.Bytes.new(gnome.encode())),
            Gdk.ContentProvider.new_for_bytes("text/plain;charset=utf-8", GLib.Bytes.new(paths.encode())),
        ]
    )


def _write_zip(destination: str, sources: list[str]):
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
        for source in sources:
            base = os.path.dirname(source.rstrip("/"))
            if os.path.isdir(source):
                for root, _dirs, names in os.walk(source):
                    archive.write(root, os.path.relpath(root, base))
                    for name in names:
                        path = os.path.join(root, name)
                        archive.write(path, os.path.relpath(path, base))
            else:
                archive.write(source, os.path.basename(source))


def zip_files_async(destination: str, sources: list[str], on_done):
    """Builds the archive in a worker thread; on_done(error_message or None) runs in the main loop."""

    def work():
        try:
            _write_zip(destination, sources)
            error = None
        except OSError as exc:
            error = exc.strerror or str(exc)
        GLib.idle_add(on_done, error)

    threading.Thread(target=work, daemon=True).start()
