import json
import os

from gi.repository import GLib, Gio

from valise.item import ValiseItem

STATE_DIR = os.path.join(GLib.get_user_state_dir(), "valise")
STATE_FILE = os.path.join(STATE_DIR, "items.json")


def load_items() -> list[ValiseItem]:
    try:
        with open(STATE_FILE, encoding="utf-8") as stream:
            data = json.load(stream)
    except (OSError, ValueError):
        return []
    return [ValiseItem(Gio.File.new_for_uri(entry["uri"]), entry.get("selected", True)) for entry in data if "uri" in entry]


def save_items(items: list[ValiseItem]):
    os.makedirs(STATE_DIR, exist_ok=True)
    data = [{"uri": item.uri, "selected": item.selected} for item in items]
    GLib.file_set_contents(STATE_FILE, json.dumps(data, ensure_ascii=False, indent=1).encode())
