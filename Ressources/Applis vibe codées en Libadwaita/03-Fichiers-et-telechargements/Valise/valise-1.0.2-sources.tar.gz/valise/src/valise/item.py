from gi.repository import GLib, GObject, Gio

INFO_ATTRIBUTES = ",".join(
    (
        Gio.FILE_ATTRIBUTE_STANDARD_DISPLAY_NAME,
        Gio.FILE_ATTRIBUTE_STANDARD_ICON,
        Gio.FILE_ATTRIBUTE_STANDARD_CONTENT_TYPE,
        Gio.FILE_ATTRIBUTE_STANDARD_SIZE,
        Gio.FILE_ATTRIBUTE_STANDARD_TYPE,
        Gio.FILE_ATTRIBUTE_THUMBNAIL_PATH,
        "thumbnail::path-large",
        "thumbnail::path-xlarge",
    )
)


def short_path(path: str) -> str:
    home = GLib.get_home_dir()
    return "~" + path[len(home) :] if path == home or path.startswith(home + "/") else path


class ValiseItem(GObject.Object):
    """A reference to a file kept in the suitcase; the file itself is never copied."""

    __gtype_name__ = "ValiseItem"

    selected = GObject.Property(type=bool, default=True)

    def __init__(self, file: Gio.File, selected: bool = True):
        super().__init__(selected=selected)
        self.file = file
        self.info: Gio.FileInfo | None = None
        self.refresh()

    @property
    def uri(self) -> str:
        return self.file.get_uri()

    @property
    def exists(self) -> bool:
        return self.info is not None

    @property
    def name(self) -> str:
        return self.info.get_display_name() if self.info else self.file.get_basename() or self.uri

    @property
    def folder(self) -> str:
        parent = self.file.get_parent()
        return short_path(parent.get_path() or parent.get_uri()) if parent else ""

    @property
    def is_directory(self) -> bool:
        return self.info is not None and self.info.get_file_type() == Gio.FileType.DIRECTORY

    @property
    def content_type(self) -> str:
        return (self.info.get_content_type() if self.info else None) or ""

    @property
    def icon(self) -> Gio.Icon:
        return self.info.get_icon() if self.info else Gio.ThemedIcon.new("dialog-question-symbolic")

    @property
    def thumbnail_path(self) -> str | None:
        if not self.info:
            return None
        for attribute in ("thumbnail::path-xlarge", "thumbnail::path-large", Gio.FILE_ATTRIBUTE_THUMBNAIL_PATH):
            path = self.info.get_attribute_byte_string(attribute)
            if path:
                return path
        return None

    @property
    def size_text(self) -> str:
        if not self.info:
            return "Introuvable"
        if self.is_directory:
            return "Dossier"
        return GLib.format_size(self.info.get_size())

    def refresh(self):
        try:
            self.info = self.file.query_info(INFO_ATTRIBUTES, Gio.FileQueryInfoFlags.NONE, None)
        except GLib.Error:
            self.info = None
