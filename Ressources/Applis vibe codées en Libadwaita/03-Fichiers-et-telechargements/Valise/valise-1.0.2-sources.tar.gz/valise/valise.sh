#!/bin/sh
exec python3 /usr/lib/valise/main.py "$@"
