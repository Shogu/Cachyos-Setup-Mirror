from gi.repository import Adw, Gdk, GdkPixbuf, GLib, GObject, Gio, Gtk, Pango

from valise.item import ValiseItem

PREVIEW_WIDTH = 240
PREVIEW_HEIGHT = 180
TEXT_PREVIEW_BYTES = 2048
TEXT_PREVIEW_LINES = 12


def _text_excerpt(item: ValiseItem) -> str | None:
    if not Gio.content_type_is_a(item.content_type, "text/plain"):
        return None
    try:
        with open(item.file.get_path() or "", "rb") as stream:
            data = stream.read(TEXT_PREVIEW_BYTES)
    except OSError:
        return None
    lines = data.decode("utf-8", errors="replace").splitlines()[:TEXT_PREVIEW_LINES]
    return "\n".join(lines)


def _scaled_texture(path: str) -> Gdk.Texture | None:
    try:
        pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, PREVIEW_WIDTH, PREVIEW_HEIGHT, True)
    except GLib.Error:
        return None
    memory_format = Gdk.MemoryFormat.R8G8B8A8 if pixbuf.get_has_alpha() else Gdk.MemoryFormat.R8G8B8
    return Gdk.MemoryTexture.new(pixbuf.get_width(), pixbuf.get_height(), memory_format, pixbuf.read_pixel_bytes(), pixbuf.get_rowstride())


def _preview_widget(item: ValiseItem) -> Gtk.Widget:
    path = item.thumbnail_path or (item.file.get_path() if Gio.content_type_is_a(item.content_type, "image/*") else None)
    texture = _scaled_texture(path) if path else None
    if texture:
        picture = Gtk.Picture.new_for_paintable(texture)
        picture.set_content_fit(Gtk.ContentFit.CONTAIN)
        picture.set_size_request(min(texture.get_width(), PREVIEW_WIDTH), min(texture.get_height(), PREVIEW_HEIGHT))
        return picture

    excerpt = _text_excerpt(item)
    if excerpt:
        label = Gtk.Label(label=excerpt, xalign=0, max_width_chars=40, ellipsize=Pango.EllipsizeMode.END)
        label.add_css_class("monospace")
        return label

    image = Gtk.Image.new_from_gicon(item.icon)
    image.set_pixel_size(96)
    return image


class ValiseRow(Adw.ActionRow):
    """One file of the suitcase: selection check, icon, name, size; preview and origin folder on hover."""

    __gtype_name__ = "ValiseRow"

    def __init__(self, item: ValiseItem, window):
        super().__init__(title=item.name, subtitle=item.size_text, title_lines=1, subtitle_lines=1)
        self.item = item
        self._window = window
        self.set_title_selectable(False)
        self.set_use_markup(False)

        self._icon = Gtk.Image(pixel_size=32)
        if item.thumbnail_path:
            self._icon.set_from_file(item.thumbnail_path)
        else:
            self._icon.set_from_gicon(item.icon)
        self.add_prefix(self._icon)

        check = Gtk.CheckButton(valign=Gtk.Align.CENTER, tooltip_text="Sélectionner")
        check.add_css_class("selection-mode")
        item.bind_property("selected", check, "active", GObject.BindingFlags.BIDIRECTIONAL | GObject.BindingFlags.SYNC_CREATE)
        check.connect("toggled", lambda *_: window.on_selection_changed())
        self.add_prefix(check)
        self.set_activatable_widget(check)

        remove = Gtk.Button(icon_name="window-close-symbolic", valign=Gtk.Align.CENTER, tooltip_text="Retirer de la valise")
        remove.add_css_class("flat")
        remove.connect("clicked", lambda *_: window.remove_items([item]))
        self.add_suffix(remove)

        if not item.exists:
            self.add_css_class("dim-label")

        self.set_has_tooltip(True)
        self.connect("query-tooltip", self._on_query_tooltip)

        drag = Gtk.DragSource(actions=Gdk.DragAction.COPY)
        drag.connect("prepare", self._on_drag_prepare)
        drag.connect("drag-begin", self._on_drag_begin)
        self.add_controller(drag)

        self._setup_context_menu()

    def _on_query_tooltip(self, _widget, _x, _y, _keyboard, tooltip):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        if self.item.exists:
            box.append(_preview_widget(self.item))
        folder = Gtk.Label(label=self.item.folder, xalign=0, wrap=True, max_width_chars=40)
        folder.add_css_class("caption")
        box.append(folder)
        tooltip.set_custom(box)
        return True

    def _on_drag_prepare(self, _source, _x, _y):
        files = self._window.drag_files_for(self.item)
        return self._window.files_content(files) if files else None

    def _on_drag_begin(self, source, _drag):
        source.set_icon(Gtk.WidgetPaintable.new(self._icon), 0, 0)

    def _setup_context_menu(self):
        group = Gio.SimpleActionGroup()

        open_folder = Gio.SimpleAction.new("open-folder", None)
        open_folder.connect("activate", lambda *_: Gtk.FileLauncher.new(self.item.file).open_containing_folder(self.get_root(), None, None))
        open_folder.set_enabled(self.item.exists)
        group.add_action(open_folder)

        remove = Gio.SimpleAction.new("remove", None)
        remove.connect("activate", lambda *_: self._window.remove_items([self.item]))
        group.add_action(remove)

        self.insert_action_group("row", group)

        self._menu = Gio.Menu()
        self._menu.append("Ouvrir le dossier d'origine", "row.open-folder")
        self._menu.append("Retirer de la valise", "row.remove")

        click = Gtk.GestureClick(button=Gdk.BUTTON_SECONDARY)
        click.connect("pressed", self._on_secondary_click)
        self.add_controller(click)

    def _on_secondary_click(self, _gesture, _n_press, x, y):
        popover = Gtk.PopoverMenu.new_from_model(self._menu)
        popover.set_parent(self)
        popover.set_has_arrow(False)
        rect = Gdk.Rectangle()
        rect.x, rect.y, rect.width, rect.height = int(x), int(y), 1, 1
        popover.set_pointing_to(rect)
        popover.connect("closed", lambda p: GLib.idle_add(p.unparent))
        popover.popup()
