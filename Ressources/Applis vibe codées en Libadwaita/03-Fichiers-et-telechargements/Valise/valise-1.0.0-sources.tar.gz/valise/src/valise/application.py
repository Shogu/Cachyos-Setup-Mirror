from gi.repository import Adw, Gio

from valise.window import ValiseWindow

APP_ID = "io.gitlab.shogu.Valise"
VERSION = "1.0.0"

ACCELS = {
    "win.paste": ["<Control>v"],
    "win.copy": ["<Control>c"],
    "win.cut": ["<Control>x"],
    "win.remove": ["Delete"],
    "win.select-all": ["<Control>a"],
    "win.select-none": ["<Control><Shift>a"],
    "app.quit": ["<Control>q"],
}


class ValiseApplication(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.HANDLES_OPEN)

        quit_action = Gio.SimpleAction.new("quit", None)
        quit_action.connect("activate", lambda *_: self.quit())
        self.add_action(quit_action)

        about_action = Gio.SimpleAction.new("about", None)
        about_action.connect("activate", self._on_about)
        self.add_action(about_action)

        for action, accels in ACCELS.items():
            self.set_accels_for_action(action, accels)

    def _window(self) -> ValiseWindow:
        return self.get_active_window() or ValiseWindow(application=self)

    def do_activate(self):
        self._window().present()

    def do_open(self, files, _n_files, _hint):
        window = self._window()
        window.add_files(files)
        window.present()

    def _on_about(self, *_):
        about = Adw.AboutDialog(
            application_name="Valise",
            application_icon=APP_ID,
            version=VERSION,
            developer_name="Shogu",
            comments="Rassemblez des fichiers pour les déposer, copier, déplacer ou zipper ensuite.",
        )
        about.present(self.get_active_window())
