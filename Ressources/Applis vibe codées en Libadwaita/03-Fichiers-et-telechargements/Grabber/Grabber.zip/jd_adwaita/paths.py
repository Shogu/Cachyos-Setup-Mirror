"""Where finished videos go, resolved exactly as Fret's video import resolves it."""

from __future__ import annotations

from pathlib import Path

from gi.repository import GLib

VIDEO_EXTENSIONS = frozenset(
    {".mp4", ".mkv", ".avi", ".mov", ".flv", ".wmv", ".mpeg", ".mpg", ".webm", ".m4v", ".ogv"}
)


def video_destination() -> Path:
    """The user's real video folder (~/Vidéos on a French system), plus Fret's .DEV."""
    configured = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_VIDEOS)
    return (Path(configured) if configured else Path.home() / "Videos") / ".DEV"
