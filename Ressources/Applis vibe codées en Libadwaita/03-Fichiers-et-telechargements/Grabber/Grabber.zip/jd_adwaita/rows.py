"""List rows built once per link and refreshed in place at every poll.

Rebuilding every row every 2.5 s is what used to close the menu under the
pointer, grey a button just as it was clicked, and leak a popover per refresh.
Keeping the widgets alive and only writing their values fixes all three.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable

import gi

gi.require_version("Adw", "1")
gi.require_version("Gdk", "4.0")
gi.require_version("Gtk", "4.0")
from gi.repository import Adw, Gdk, Gio, Gtk

from .formatting import (
    as_number,
    estimate_eta_seconds,
    format_bytes,
    format_duration_seconds,
    format_speed,
    host_name,
    progress_for,
    progress_percent,
    source_host_name,
    status_text,
)
from .ui import icon_button

if TYPE_CHECKING:
    from .app import MainWindow


def link_id(item: dict[str, Any]) -> int | None:
    try:
        return int(item["uuid"])
    except (KeyError, TypeError, ValueError):
        return None


def is_finished(item: dict[str, Any]) -> bool:
    return bool(item.get("finished")) or status_text(item) == "Terminé"


class _BaseRow(Adw.ActionRow):
    """Position number, selection check and host tile: common to both lists."""

    def __init__(self, window: MainWindow, uuid: int, on_toggled: Callable[..., None], check_tooltip: str) -> None:
        # use_markup=False: a file called "S01 & bonus <VF>.mp4" would otherwise
        # be read as Pango markup and lose its whole title.
        super().__init__(activatable=False, use_markup=False)
        self.window = window
        self.uuid = uuid
        self._host: str | None = None
        self._badge: Gtk.Widget | None = None

        self.number = Gtk.Label(xalign=1, valign=Gtk.Align.CENTER)
        self.number.add_css_class("numeric")
        self.number.add_css_class("dim-label")
        self.number.set_size_request(24, -1)
        self.number.set_tooltip_text("Position dans la liste")
        self.add_prefix(self.number)

        self.check = Gtk.CheckButton(valign=Gtk.Align.CENTER, tooltip_text=check_tooltip)
        self.check.connect("toggled", on_toggled, uuid)
        self.add_prefix(self.check)

    def set_position(self, position: int) -> None:
        text = str(position)
        if self.number.get_label() != text:
            self.number.set_label(text)

    def set_host(self, host: str) -> None:
        if host == self._host:
            return
        self._host = host
        if self._badge is not None:
            self.remove(self._badge)
            self._badge = None
        if host:
            self._badge = self.window._host_badge(host)
            self.add_prefix(self._badge)

    def set_selected(self, selected: bool) -> None:
        if self.check.get_active() != selected:
            self.check.set_active(selected)


class DownloadRow(_BaseRow):
    def __init__(self, window: MainWindow, uuid: int) -> None:
        super().__init__(window, uuid, window._on_download_check_toggled, "Sélectionner ce téléchargement")
        self.set_tooltip_text("Utiliser les boutons d’action pour ouvrir le fichier ou son dossier")

        self.done_icon = Gtk.Image.new_from_icon_name("object-select-symbolic")
        self.done_icon.set_tooltip_text("Téléchargement terminé")
        self.done_icon.set_pixel_size(18)
        self.done_icon.set_valign(Gtk.Align.CENTER)
        self.done_icon.add_css_class("success")
        self.add_suffix(self.done_icon)

        self.progress = Gtk.ProgressBar(valign=Gtk.Align.CENTER)
        self.progress.set_size_request(150, -1)
        self.add_suffix(self.progress)
        self.meta = Gtk.Label(xalign=1)
        self.meta.add_css_class("numeric")
        self.add_suffix(self.meta)

        self.open_file = icon_button("document-open-symbolic")
        self.open_file.add_css_class("flat")
        self.open_file.set_tooltip_text("Ouvrir le fichier")
        self.open_file.connect("clicked", lambda _b: self._with_item(window._open_download_file))
        self.add_suffix(self.open_file)

        self.open_folder = icon_button("folder-symbolic")
        self.open_folder.add_css_class("flat")
        self.open_folder.set_tooltip_text("Ouvrir le dossier contenant le fichier")
        self.open_folder.connect("clicked", lambda _b: self._with_item(window._open_download_folder))
        self.add_suffix(self.open_folder)

        actions = Gio.SimpleActionGroup()
        menu = Gio.Menu()
        for name, label, callback in (
            ("reset", "Réinitialiser le téléchargement", window._ask_reset_download),
            ("ytdlp", "Télécharger avec yt-dlp (cookies du navigateur)", window._download_with_ytdlp),
            ("forget", "Retirer de la liste, garder le fichier", window._remove_download_from_list),
            ("delete", "Supprimer le fichier et le téléchargement…", window._ask_delete_download_file),
        ):
            action = Gio.SimpleAction.new(name, None)
            action.connect("activate", lambda _a, _p, cb=callback: self._with_item(cb))
            actions.add_action(action)
            menu.append(label, f"download.{name}")
        self.insert_action_group("download", actions)
        self._ytdlp_action = actions.lookup_action("ytdlp")
        self.menu_button = Gtk.MenuButton(icon_name="view-more-symbolic", menu_model=menu, valign=Gtk.Align.CENTER)
        self.menu_button.add_css_class("flat")
        self.menu_button.set_tooltip_text("Autres actions : réinitialiser, yt-dlp, retirer ou supprimer")
        self.add_suffix(self.menu_button)

    def _with_item(self, callback: Callable[[dict[str, Any]], None]) -> None:
        item = self.window._download_item(self.uuid)
        if item is not None:
            callback(item)

    def update(self, item: dict[str, Any], position: int) -> None:
        window = self.window
        self.set_position(position)
        self.set_title(str(item.get("name") or item.get("url") or "Lien sans nom"))
        self.set_host(host_name(item))
        loaded = item.get("bytesLoaded", 0)
        total = item.get("bytesTotal", 0)
        finished = is_finished(item)
        if finished:
            downloaded = format_bytes(loaded)
            self.set_subtitle(f"{downloaded} / {format_bytes(total)}" if total else downloaded)
        else:
            self.set_subtitle(f"{status_text(item)}  •  {format_bytes(loaded)} / {format_bytes(total)}")
            self.progress.set_fraction(progress_for(item))
            eta = estimate_eta_seconds(item, window._observed_download_speed(item))
            percent = progress_percent(item)
            percent_label = "— %" if percent is None else f"{percent} %"
            self.meta.set_label(
                f"{format_speed(item.get('speed', 0))}\n{percent_label} • ETA {format_duration_seconds(eta)}"
            )
        self.done_icon.set_visible(finished)
        self.progress.set_visible(not finished)
        self.meta.set_visible(not finished)
        path = window._download_file_path(item, deep=False)
        self.open_file.set_sensitive(path is not None and path.is_file())
        self.open_folder.set_sensitive(path is not None)
        self._ytdlp_action.set_enabled(bool(window._link_url(item)))
        self.set_selected(self.uuid in window._selected_download_ids)


class GrabberRow(_BaseRow):
    def __init__(self, window: MainWindow, uuid: int) -> None:
        super().__init__(window, uuid, window._on_grabber_check_toggled, "Sélectionner ce fichier")
        self._domain = ""
        actions = Gio.SimpleActionGroup()
        self._whitelist = Gio.SimpleAction.new("add-domain", None)
        self._whitelist.connect("activate", lambda *_a: self._with_item(window._add_grabber_domain_to_whitelist))
        actions.add_action(self._whitelist)
        remove = Gio.SimpleAction.new("remove", None)
        remove.connect("activate", lambda *_a: self._with_item(window._ask_remove_grabber_link))
        actions.add_action(remove)
        self.insert_action_group("grabber", actions)

        self._menu = Gio.Menu()
        self.popover = Gtk.PopoverMenu(menu_model=self._menu, has_arrow=True, position=Gtk.PositionType.BOTTOM)
        self.popover.set_parent(self)
        gesture = Gtk.GestureClick(button=Gdk.BUTTON_SECONDARY)
        gesture.connect("pressed", self._on_right_click)
        self.add_controller(gesture)

    def _with_item(self, callback: Callable[[dict[str, Any]], None]) -> None:
        item = self.window._grabber_item(self.uuid)
        if item is not None:
            callback(item)

    def _on_right_click(self, gesture: Gtk.GestureClick, _n_press: int, x: float, y: float) -> None:
        gesture.set_state(Gtk.EventSequenceState.CLAIMED)
        self._menu.remove_all()
        self._whitelist.set_enabled(bool(self._domain))
        self._menu.append(
            f"Ajouter « {self._domain} » à la whitelist" if self._domain else "Domaine d’origine indisponible",
            "grabber.add-domain",
        )
        self._menu.append("Retirer ce lien de la liste…", "grabber.remove")
        rectangle = Gdk.Rectangle()
        rectangle.x, rectangle.y, rectangle.width, rectangle.height = int(x), int(y), 1, 1
        self.popover.set_pointing_to(rectangle)
        self.popover.popup()

    def update(self, item: dict[str, Any], position: int) -> None:
        self.set_position(position)
        self.set_title(str(item.get("name") or item.get("url") or "Lien sans nom"))
        self.set_host(host_name(item))
        domain = source_host_name(item)
        self._domain = domain if domain and ("." in domain or domain == "localhost") else ""
        availability = str(item.get("availability") or "")
        total = as_number(item.get("bytesTotal"), -1)
        size = f"Taille : {format_bytes(total)}" if total > 0 else "Taille inconnue"
        self.set_subtitle("  •  ".join(part for part in (availability, size) if part) or "En attente d'analyse")
        self.set_selected(self.uuid in self.window._selected_grabber_ids)


def sync_rows(
    list_box: Gtk.ListBox,
    rows: dict[int, _BaseRow],
    order: list[int],
    items: list[dict[str, Any]],
    factory: Callable[[int], _BaseRow],
) -> list[int]:
    """Match the list box to ``items`` while keeping the surviving rows alive."""

    wanted = [(uuid, item) for item in items if (uuid := link_id(item)) is not None]
    wanted_ids = [uuid for uuid, _item in wanted]
    for uuid in set(rows) - set(wanted_ids):
        row = rows.pop(uuid)
        popover = getattr(row, "popover", None)
        if popover is not None:
            popover.unparent()
        list_box.remove(row)
    if wanted_ids != order:
        for row in rows.values():
            list_box.remove(row)
        for uuid in wanted_ids:
            row = rows.get(uuid) or factory(uuid)
            rows[uuid] = row
            list_box.append(row)
    for position, (uuid, item) in enumerate(wanted, start=1):
        rows[uuid].update(item, position)
    return wanted_ids
