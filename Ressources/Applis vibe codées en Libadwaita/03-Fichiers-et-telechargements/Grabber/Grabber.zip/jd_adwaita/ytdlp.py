from __future__ import annotations

import hashlib
import os
import re
import shutil
import subprocess
import threading
from pathlib import Path
from urllib.parse import urlsplit
from typing import Callable, Iterable

from .domains import domain_matches

# Sites JDownloader cannot fetch on its own; they are handed to yt-dlp, which
# reads the browser's cookies itself.  The list of such sites belongs to the
# user: it comes from the configuration file, is empty out of the box, and is
# therefore absent from the sources shipped in a release.

_SIZE_UNITS = {"B": 1, "KIB": 1024, "MIB": 1024 ** 2, "GIB": 1024 ** 3, "TIB": 1024 ** 4}
_PROGRESS_RE = re.compile(
    r"\[download\]\s+(?P<percent>\d+(?:[.,]\d+)?)%\s+of\s+~?\s*(?P<size>\d+(?:\.\d+)?)\s*(?P<unit>[KMGT]?i?B)"
    r"(?:.*?\bat\s+(?P<speed>\d+(?:\.\d+)?)\s*(?P<speed_unit>[KMGT]?i?B)/s)?",
    re.IGNORECASE,
)
_DESTINATION_RE = re.compile(r"^\[download\]\s+Destination:\s+(?P<path>.+)$")
_MERGED_RE = re.compile(r'^\[Merger\]\s+Merging formats into\s+"(?P<path>.+)"$')
_ALREADY_RE = re.compile(r"^\[download\]\s+(?P<path>.+?)\s+has already been downloaded$")
# What yt-dlp writes before merging (title.f399.mp4) or while downloading.
INTERMEDIATE_RE = re.compile(r"\.f\d+\.[A-Za-z0-9]+$|\.(?:part|ytdl|temp)$|\.part-Frag\d+")
# A very long title can exceed the filesystem's limit and fail the write.
MAX_FILENAME_BYTES = 180

_running: set[subprocess.Popen] = set()
_running_lock = threading.Lock()

# Browsers yt-dlp can read cookies from (--cookies-from-browser).
BROWSERS = ("vivaldi", "firefox", "chromium", "chrome", "brave", "edge", "opera")
BROWSER_ENV = "JD_ADWAITA_YTDLP_BROWSER"
PATH_ENV = "JD_ADWAITA_YTDLP_PATH"
DEFAULT_BROWSER = "vivaldi"


def stable_path() -> Path:
    base = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")
    return base / "jd-adwaita" / "bin" / "yt-dlp"


def find_ytdlp() -> str | None:
    for candidate in (os.environ.get(PATH_ENV), str(stable_path())):
        if candidate and Path(candidate).is_file() and os.access(candidate, os.X_OK):
            return candidate
    return shutil.which("yt-dlp")


def browser_name() -> str:
    return os.environ.get(BROWSER_ENV) or DEFAULT_BROWSER


def default_log_path() -> Path:
    base = Path(os.environ.get("XDG_CACHE_HOME") or Path.home() / ".cache")
    return base / "jd-adwaita" / "ytdlp.log"


def write_note(message: str) -> None:
    """Leave a trace in the yt-dlp log when the action cannot even start."""
    path = default_log_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(message + "\n", encoding="utf-8")


def handles(url: str, domains: Iterable[str] | None = None) -> bool:
    """True when this link belongs to a site JDownloader cannot download.

    ``domains`` is the user's configured list.  An empty or missing list means
    no handoff at all — never a built-in one, so no site is named in the code.
    """
    host = urlsplit(str(url or "")).hostname
    if not host:
        return False
    return any(domain_matches(host, pattern) for pattern in (domains or ()))


def is_running() -> bool:
    with _running_lock:
        return bool(_running)


def terminate_all() -> None:
    """Stop every yt-dlp still running; its .part file lets the next run resume."""
    with _running_lock:
        processes = list(_running)
    for process in processes:
        process.terminate()
    for process in processes:
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()


def parse_progress(line: str) -> tuple[int, int, int] | None:
    """Read (loaded, total, bytes per second) out of a yt-dlp progress line."""
    match = _PROGRESS_RE.search(str(line or ""))
    if match is None:
        return None
    total = int(float(match.group("size")) * _SIZE_UNITS.get(match.group("unit").upper(), 1))
    percent = float(match.group("percent").replace(",", "."))
    speed = 0
    if match.group("speed"):
        speed = int(float(match.group("speed")) * _SIZE_UNITS.get(match.group("speed_unit").upper(), 1))
    return int(total * percent / 100), total, speed


def parse_destination(line: str) -> str | None:
    """Return the file yt-dlp is writing; the merged file wins over its parts."""
    text = str(line or "").strip()
    for pattern in (_MERGED_RE, _ALREADY_RE, _DESTINATION_RE):
        match = pattern.match(text)
        if match:
            return match.group("path").strip()
    return None


def is_final_destination(line: str) -> bool:
    """True for the line naming the finished file, not one of its parts."""
    text = str(line or "").strip()
    return bool(_MERGED_RE.match(text) or _ALREADY_RE.match(text))


def log_directory() -> Path:
    return default_log_path().parent


def job_log_path(url: str) -> Path:
    """One log per link, named after a digest of that link.

    Not after the link's own tail: that would write the identifier of the
    download into a directory listing, which is the place people forget to
    look.  Same link, same name; two different links never collide.
    """
    digest = hashlib.sha256(str(url or "").encode("utf-8")).hexdigest()[:12]
    return default_log_path().with_name(f"ytdlp-{digest}.log")


def build_command(url: str, output_dir: Path, browser: str | None) -> list[str]:
    binary = find_ytdlp()
    if binary is None:
        raise FileNotFoundError("yt-dlp est introuvable.")
    command = [binary]
    if browser:
        command += ["--cookies-from-browser", browser]
    command += [
        "--no-playlist",
        "--newline",
        # Keep the download date, not the upload date, and never write a name
        # longer than the filesystem accepts.
        "--no-mtime",
        "--trim-filenames",
        str(MAX_FILENAME_BYTES),
        "--output",
        str(Path(output_dir) / "%(title)s.%(ext)s"),
        url,
    ]
    return command


def download(
    url: str,
    output_dir: Path,
    browser: str | None = None,
    log_path: Path | None = None,
    on_line: Callable[[str], None] | None = None,
) -> tuple[bool, str]:
    """Run the bundled yt-dlp and report its last line; full output goes to a log."""
    directory = Path(output_dir)
    directory.mkdir(parents=True, exist_ok=True)
    command = build_command(url, directory, browser or browser_name())
    destination = Path(log_path) if log_path else default_log_path()
    destination.parent.mkdir(parents=True, exist_ok=True)
    last = ""
    with destination.open("w", encoding="utf-8") as log:
        log.write(" ".join(command) + "\n")
        log.flush()
        process = subprocess.Popen(
            command,
            cwd=str(directory),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
        )
        with _running_lock:
            _running.add(process)
        try:
            for line in process.stdout:
                log.write(line)
                log.flush()
                stripped = line.rstrip("\n")
                if stripped:
                    last = stripped
                    if on_line is not None:
                        on_line(stripped)
            code = process.wait()
        finally:
            with _running_lock:
                _running.discard(process)
    if code == 0:
        return True, last or "Terminé"
    return False, last or f"Échec (code {code})"


def version() -> str:
    """The version string of the yt-dlp copy Grabber actually runs."""
    executable = find_ytdlp()
    if executable is None:
        return ""
    result = subprocess.run([executable, "--version"], capture_output=True, text=True, timeout=30)
    return result.stdout.strip()


def update() -> str:
    """Self-update the writable copy of yt-dlp and report what happened."""
    executable = find_ytdlp()
    if executable is None:
        raise RuntimeError("yt-dlp est introuvable.")
    before = version()
    result = subprocess.run(
        [executable, "--update-to", "stable"], capture_output=True, text=True, timeout=300
    )
    after = version()
    if after and after != before:
        return f"yt-dlp mis à jour : {before} → {after}"
    if result.returncode != 0:
        message = (result.stderr or result.stdout).strip().splitlines()
        raise RuntimeError(message[-1] if message else "La mise à jour de yt-dlp a échoué.")
    return f"yt-dlp est déjà à jour ({after})." if after else "yt-dlp est déjà à jour."
