"""Moves finished videos from the download folder to Fret's video folder (~/Vidéos/.DEV by default)."""

from __future__ import annotations

import os
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from gi.repository import Gio, GLib

from .config import parse_extensions
from .ytdlp import INTERMEDIATE_RE


class VideoImportError(Exception):
    pass


@dataclass
class ImportResult:
    mode: str
    destination: str
    done: int = 0
    renamed: list[str] = field(default_factory=list)
    failed: list[str] = field(default_factory=list)
    cancelled: bool = False
    error: str = ""


def _local_path(value: str) -> Path:
    text = (value or "").strip()
    if not text or "://" in text:
        raise VideoImportError("L’import vidéo utilise des chemins locaux.")
    return Path(os.path.abspath(os.path.expanduser(text)))


def _unique_target(target: Path) -> Path:
    index = 1
    while True:
        candidate = target.with_name(f"{target.stem} ({index}){target.suffix}")
        if not candidate.exists():
            return candidate
        index += 1


class VideoImport:
    """One import run. ``ask_conflict(name, reply)`` is called on the main loop; reply(choice, apply_all)."""

    def __init__(
        self,
        source: str,
        settings: dict[str, Any],
        ask_conflict: Callable[[str, Callable[[str, bool], None]], None],
        finished: Callable[[ImportResult], None],
    ) -> None:
        self._ask_conflict = ask_conflict
        self._finished = finished
        self._settings = settings
        self._source_text = source
        self._policy: str | None = None
        self._cancellable = Gio.Cancellable()

    def start(self) -> None:
        threading.Thread(target=self._run, name="grabber-video-import", daemon=True).start()

    def cancel(self) -> None:
        self._cancellable.cancel()

    def _run(self) -> None:
        settings = self._settings
        result = ImportResult(mode=settings["mode"], destination=settings["destination"])
        try:
            source = _local_path(self._source_text)
            destination = _local_path(settings["destination"])
            extensions = parse_extensions(settings["extensions"])
            if not extensions:
                raise VideoImportError("Indique au moins une extension de fichier.")
            if destination == source or destination.is_relative_to(source):
                raise VideoImportError("La destination ne peut pas être le dossier de téléchargement ou l’un de ses sous-dossiers.")
            if not source.is_dir():
                raise VideoImportError(f"Le dossier de téléchargement n’existe pas : {source}")
            preserve = source / "VDH" if settings["preserve_vdh"] else None
            videos = self._scan(source, set(extensions), bool(settings["recursive"]), preserve)
            if not videos:
                raise VideoImportError(f"Aucune vidéo trouvée dans {source}.")
            destination.mkdir(parents=True, exist_ok=True)
            for video in videos:
                if self._cancellable.is_cancelled():
                    result.cancelled = True
                    break
                self._transfer(video, destination, result)
            if result.mode == "move" and settings["cleanup_empty_dirs"]:
                self._cleanup(source, {video.parent for video in videos}, preserve)
        except (VideoImportError, OSError) as error:
            result.error = str(error)
        GLib.idle_add(self._finished, result)

    @staticmethod
    def _scan(source: Path, extensions: set[str], recursive: bool, preserve: Path | None) -> list[Path]:
        def wanted(path: Path) -> bool:
            if path.suffix.casefold() not in extensions or path.is_symlink() or not path.is_file():
                return False
            # A video yt-dlp is still writing or about to merge stays where it is.
            if INTERMEDIATE_RE.search(path.name):
                return False
            return not any(path.with_name(path.name + s).exists() for s in (".part", ".ytdl"))

        if not recursive:
            return sorted((path for path in source.iterdir() if wanted(path)), key=lambda path: path.name.casefold())
        videos: list[Path] = []
        for root, directories, names in os.walk(source, followlinks=False):
            directories[:] = sorted(name for name in directories if not os.path.islink(os.path.join(root, name)))
            videos.extend(path for name in names if wanted(path := Path(root) / name))
        return sorted(videos, key=lambda path: str(path).casefold())

    def _resolve_conflict(self, target: Path) -> str:
        if self._policy is not None:
            return self._policy
        event = threading.Event()
        answer = {"choice": "cancel", "apply_all": False}

        def reply(choice: str, apply_all: bool) -> None:
            answer.update(choice=choice, apply_all=apply_all)
            event.set()

        GLib.idle_add(self._ask_conflict, target.name, reply)
        event.wait()
        if answer["apply_all"] and answer["choice"] != "cancel":
            self._policy = answer["choice"]
        return answer["choice"]

    def _transfer(self, video: Path, destination: Path, result: ImportResult) -> None:
        target = destination / video.name
        flags = Gio.FileCopyFlags.NOFOLLOW_SYMLINKS | Gio.FileCopyFlags.ALL_METADATA
        if target.exists():
            choice = self._resolve_conflict(target)
            if choice == "cancel":
                self._cancellable.cancel()
                result.cancelled = True
                return
            if choice == "rename":
                target = _unique_target(target)
                result.renamed.append(f"{video.name} → {target.name}")
            else:
                flags |= Gio.FileCopyFlags.OVERWRITE
        source_file = Gio.File.new_for_path(str(video))
        target_file = Gio.File.new_for_path(str(target))
        try:
            if result.mode == "move":
                source_file.move(target_file, flags, self._cancellable, None, None)
            else:
                source_file.copy(target_file, flags, self._cancellable, None, None)
        except GLib.Error as error:
            if error.matches(Gio.io_error_quark(), Gio.IOErrorEnum.CANCELLED):
                result.cancelled = True
                return
            result.failed.append(f"{video.name} : {error.message}")
            return
        result.done += 1

    @staticmethod
    def _cleanup(root: Path, directories: set[Path], preserve: Path | None) -> None:
        """Remove the folders emptied by the move, never the download folder itself nor VDH."""

        for start in sorted(directories, key=lambda path: len(path.parts), reverse=True):
            current = start
            while current != root and current.is_relative_to(root):
                if preserve is not None and current == preserve:
                    break
                try:
                    current.rmdir()
                except OSError:
                    break
                current = current.parent
