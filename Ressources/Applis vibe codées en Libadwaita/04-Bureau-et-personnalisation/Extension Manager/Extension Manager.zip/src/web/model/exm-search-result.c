/*
 * exm-search-result.c
 *
 * Copyright 2022-2025 Matthew Jakeman <mjakeman26@outlook.co.nz>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#include "exm-search-result.h"

#include <json-glib/json-glib.h>

struct _ExmSearchResult
{
    GObject parent_instance;

    guint id;
    gchar *uuid;
    gchar *name;
    gchar *creator;
    gchar *creator_username;
    guint creator_id;
    gchar *description;
    gchar *created;
    gchar *updated;
    guint downloads;
    gint popularity;
    gchar *screenshot;
    gchar *icon;
    gdouble rating;
    gint rated;
    gchar *url;
    gchar **donation_urls;
    gchar *link;

    gchar *unsupported_shell_version;
};

static JsonSerializableIface *serializable_iface = NULL;

static void json_serializable_iface_init (JsonSerializableIface *iface);

G_DEFINE_FINAL_TYPE_WITH_CODE (ExmSearchResult, exm_search_result, G_TYPE_OBJECT,
                               G_IMPLEMENT_INTERFACE (JSON_TYPE_SERIALIZABLE,
                                                      json_serializable_iface_init))

enum {
    PROP_0,
    PROP_ID,
    PROP_UUID,
    PROP_NAME,
    PROP_CREATOR,
    PROP_CREATOR_USERNAME,
    PROP_CREATOR_ID,
    PROP_DESCRIPTION,
    PROP_CREATED,
    PROP_UPDATED,
    PROP_DOWNLOADS,
    PROP_POPULARITY,
    PROP_SCREENSHOT,
    PROP_ICON,
    PROP_RATING,
    PROP_RATED,
    PROP_URL,
    PROP_DONATION_URLS,
    PROP_LINK,
    PROP_UNSUPPORTED_SHELL_VERSION,
    N_PROPS
};

static GParamSpec *properties [N_PROPS];

ExmSearchResult *
exm_search_result_new (void)
{
    return g_object_new (EXM_TYPE_SEARCH_RESULT, NULL);
}

static void
exm_search_result_get_property (GObject    *object,
                                guint       prop_id,
                                GValue     *value,
                                GParamSpec *pspec)
{
    ExmSearchResult *self = EXM_SEARCH_RESULT (object);

    switch (prop_id)
    {
    case PROP_ID:
        g_value_set_uint (value, self->id);
        break;
    case PROP_UUID:
        g_value_set_string (value, self->uuid);
        break;
    case PROP_NAME:
        g_value_set_string (value, self->name);
        break;
    case PROP_CREATOR:
        g_value_set_string (value, self->creator);
        break;
    case PROP_CREATOR_USERNAME:
        g_value_set_string (value, self->creator_username);
        break;
    case PROP_CREATOR_ID:
        g_value_set_uint (value, self->creator_id);
        break;
    case PROP_DESCRIPTION:
        g_value_set_string (value, self->description);
        break;
    case PROP_CREATED:
        g_value_set_string (value, self->created);
        break;
    case PROP_UPDATED:
        g_value_set_string (value, self->updated);
        break;
    case PROP_DOWNLOADS:
        g_value_set_uint (value, self->downloads);
        break;
    case PROP_POPULARITY:
        g_value_set_int (value, self->popularity);
        break;
    case PROP_SCREENSHOT:
        g_value_set_string (value, self->screenshot);
        break;
    case PROP_ICON:
        g_value_set_string (value, self->icon);
        break;
    case PROP_RATING:
        g_value_set_double (value, self->rating);
        break;
    case PROP_RATED:
        g_value_set_int (value, self->rated);
        break;
    case PROP_URL:
        g_value_set_string (value, self->url);
        break;
    case PROP_DONATION_URLS:
        g_value_set_boxed (value, self->donation_urls);
        break;
    case PROP_LINK:
        g_value_set_string (value, self->link);
        break;
    case PROP_UNSUPPORTED_SHELL_VERSION:
        g_value_set_string (value, self->unsupported_shell_version);
        break;
    default:
        G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
    }
}

static void
exm_search_result_set_property (GObject      *object,
                                guint         prop_id,
                                const GValue *value,
                                GParamSpec   *pspec)
{
    ExmSearchResult *self = EXM_SEARCH_RESULT (object);

    switch (prop_id)
    {
    case PROP_ID:
        self->id = g_value_get_uint (value);
        break;
    case PROP_UUID:
        self->uuid = g_value_dup_string (value);
        break;
    case PROP_NAME:
        self->name = g_value_dup_string (value);
        break;
    case PROP_CREATOR:
        self->creator = g_value_dup_string (value);
        break;
    case PROP_DESCRIPTION:
        self->description = g_value_dup_string (value);
        break;
    case PROP_CREATED:
        self->created = g_value_dup_string (value);
        break;
    case PROP_UPDATED:
        self->updated = g_value_dup_string (value);
        break;
    case PROP_DOWNLOADS:
        self->downloads = g_value_get_uint (value);
        break;
    case PROP_POPULARITY:
        self->popularity = g_value_get_int (value);
        break;
    case PROP_SCREENSHOT:
        self->screenshot = g_value_dup_string (value);
        break;
    case PROP_ICON:
        self->icon = g_value_dup_string (value);
        break;
    case PROP_RATING:
        self->rating = g_value_get_double (value);
        break;
    case PROP_RATED:
        self->rated = g_value_get_int (value);
        break;
    case PROP_URL:
        self->url = g_value_dup_string (value);
        break;
    case PROP_DONATION_URLS:
        self->donation_urls = g_value_dup_boxed (value);
        break;
    case PROP_LINK:
        self->link = g_value_dup_string (value);
        break;
    case PROP_UNSUPPORTED_SHELL_VERSION:
        if (g_strcmp0 (self->unsupported_shell_version, g_value_get_string (value)) != 0)
        {
            g_free (self->unsupported_shell_version);
            self->unsupported_shell_version = g_value_dup_string (value);
            g_object_notify_by_pspec (object, pspec);
        }
        break;
    default:
        G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
    }
}

gboolean
exm_search_result_supports_shell_version (ExmSearchResult *self,
                                          const gchar     *shell_version)
{
    g_return_val_if_fail (shell_version, FALSE);

    return g_strcmp0 (self->unsupported_shell_version, shell_version) != 0;
}

void
exm_search_result_set_unsupported (ExmSearchResult *self,
                                   const gchar     *shell_version)
{
    g_object_set (self, "unsupported-shell-version", shell_version, NULL);
}

static void
exm_search_result_finalize (GObject *object)
{
    ExmSearchResult *self = EXM_SEARCH_RESULT (object);

    g_clear_pointer (&self->unsupported_shell_version, g_free);

    G_OBJECT_CLASS (exm_search_result_parent_class)->finalize (object);
}

static void
exm_search_result_class_init (ExmSearchResultClass *klass)
{
    GObjectClass *object_class = G_OBJECT_CLASS (klass);

    object_class->finalize = exm_search_result_finalize;
    object_class->get_property = exm_search_result_get_property;
    object_class->set_property = exm_search_result_set_property;

    properties [PROP_ID] =
        g_param_spec_uint ("id",
                           "ID",
                           "ID",
                           0, G_MAXUINT, 0,
                           G_PARAM_READWRITE|G_PARAM_CONSTRUCT_ONLY);

    properties [PROP_UUID] =
        g_param_spec_string ("uuid",
                             "UUID",
                             "UUID",
                             NULL,
                             G_PARAM_READWRITE|G_PARAM_CONSTRUCT_ONLY);

    properties [PROP_NAME] =
        g_param_spec_string ("name",
                             "Name",
                             "Name",
                             NULL,
                             G_PARAM_READWRITE|G_PARAM_CONSTRUCT_ONLY);

    properties [PROP_CREATOR] =
        g_param_spec_string ("creator",
                             "Creator",
                             "Creator",
                             NULL,
                             G_PARAM_READWRITE);

    properties [PROP_CREATOR_USERNAME] =
        g_param_spec_string ("creator-username",
                             "Creator Username",
                             "Creator Username",
                             NULL,
                             G_PARAM_READABLE);

    properties [PROP_CREATOR_ID] =
        g_param_spec_uint ("creator-id",
                           "Creator ID",
                           "Creator ID",
                           0, G_MAXUINT, 0,
                           G_PARAM_READABLE);

    properties [PROP_DESCRIPTION] =
        g_param_spec_string ("description",
                             "Description",
                             "Description",
                             NULL,
                             G_PARAM_READWRITE|G_PARAM_CONSTRUCT_ONLY);

    properties [PROP_CREATED] =
        g_param_spec_string ("created",
                             "Created",
                             "Created",
                             NULL,
                             G_PARAM_READWRITE|G_PARAM_CONSTRUCT_ONLY);

    properties [PROP_UPDATED] =
        g_param_spec_string ("updated",
                             "Updated",
                             "Updated",
                             NULL,
                             G_PARAM_READWRITE|G_PARAM_CONSTRUCT_ONLY);

    properties [PROP_DOWNLOADS] =
        g_param_spec_uint ("downloads",
                           "Downloads",
                           "Downloads",
                           0, G_MAXUINT, 0,
                           G_PARAM_READWRITE|G_PARAM_CONSTRUCT_ONLY);

    properties [PROP_POPULARITY] =
        g_param_spec_int ("popularity",
                          "Popularity",
                          "Popularity",
                          G_MININT, G_MAXINT, 0,
                          G_PARAM_READWRITE|G_PARAM_CONSTRUCT_ONLY);

    properties [PROP_ICON] =
        g_param_spec_string ("icon",
                             "Icon",
                             "Icon",
                             NULL,
                             G_PARAM_READWRITE|G_PARAM_CONSTRUCT_ONLY);

    properties [PROP_SCREENSHOT] =
        g_param_spec_string ("screenshot",
                             "Screenshot",
                             "Screenshot",
                             NULL,
                             G_PARAM_READWRITE|G_PARAM_CONSTRUCT_ONLY);

    properties [PROP_RATING] =
        g_param_spec_double ("rating",
                             "Rating",
                             "Rating",
                             0.0, G_MAXDOUBLE, 0.0,
                             G_PARAM_READWRITE|G_PARAM_CONSTRUCT_ONLY);

    properties [PROP_RATED] =
        g_param_spec_int ("rated",
                          "Rated",
                          "Rated",
                          G_MININT, G_MAXINT, 0,
                          G_PARAM_READWRITE|G_PARAM_CONSTRUCT_ONLY);

    properties [PROP_URL] =
        g_param_spec_string ("url",
                             "Url",
                             "Url",
                             NULL,
                             G_PARAM_READWRITE|G_PARAM_CONSTRUCT_ONLY);

    properties[PROP_DONATION_URLS] =
        g_param_spec_boxed ("donation_urls",
                            "Donation URLs",
                            "Donation URLs",
                            G_TYPE_STRV,
                            G_PARAM_READWRITE|G_PARAM_CONSTRUCT_ONLY);

    properties [PROP_LINK] =
        g_param_spec_string ("link",
                             "Link",
                             "Link",
                             NULL,
                             G_PARAM_READWRITE|G_PARAM_CONSTRUCT_ONLY);

    properties [PROP_UNSUPPORTED_SHELL_VERSION] =
        g_param_spec_string ("unsupported-shell-version",
                             "Unsupported Shell Version",
                             "Shell version the extension is known not to support",
                             NULL,
                             G_PARAM_READWRITE|G_PARAM_EXPLICIT_NOTIFY);

    g_object_class_install_properties (object_class, N_PROPS, properties);
}

static void
exm_search_result_init (ExmSearchResult *self G_GNUC_UNUSED)
{
}

static gboolean
exm_search_result_deserialize_property (JsonSerializable *serializable,
                                        const gchar      *property_name,
                                        GValue           *value,
                                        GParamSpec       *pspec,
                                        JsonNode         *property_node)
{
    if (g_strcmp0 (property_name, "creator") == 0)
    {
        ExmSearchResult *self = EXM_SEARCH_RESULT (serializable);
        JsonObject *obj;
        const gchar *creator;

        obj = json_node_get_object (property_node);
        creator = json_object_get_string_member_with_default (obj, "display_name", NULL);

        if (creator == NULL)
            creator = json_object_get_string_member (obj, "username");

        g_value_set_string (value, creator);

        g_free (self->creator_username);
        self->creator_username = g_strdup (json_object_get_string_member (obj, "username"));
        self->creator_id = json_object_get_int_member_with_default (obj, "id", 0);

        return TRUE;
    }

    return serializable_iface->deserialize_property (serializable,
                                                     property_name,
                                                     value,
                                                     pspec,
                                                     property_node);
}

static void
json_serializable_iface_init (JsonSerializableIface *iface)
{
    serializable_iface = g_type_default_interface_peek (JSON_TYPE_SERIALIZABLE);

    iface->deserialize_property = exm_search_result_deserialize_property;
}
