# SPDX-License-Identifier: GPL-3.0-or-later
import os
import unicodedata

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gio, GLib, GObject, Graphene, Gtk, Pango  # noqa: E402

from .folder_icons import (DISABLED, HIDDEN, ICONS_DIR, VISIBLE, FolderPlan, absolute, read_custom_icon, relative,
                           set_hidden, special_folders, write_custom_icon)

ICON_SUFFIXES = (".svg", ".png")


def data_path(item):
    kind, data = item
    return data["name"] if kind == "special" else data["chemin"]


def folder_image(path, size):
    icon = read_custom_icon(path) if path and os.path.isdir(path) else None
    image = Gtk.Image.new_from_file(icon) if icon and os.path.isfile(icon) else Gtk.Image.new_from_icon_name("folder")
    image.set_pixel_size(size)
    return image


def normalize(text):
    return "".join(char for char in unicodedata.normalize("NFD", text.casefold()) if not unicodedata.combining(char))


def same_icon(first, second):
    return bool(second) and os.path.exists(second) and os.path.samefile(first, second)


class FoldersPage(Adw.Bin):
    def __init__(self, app, title_widget, menu_button, **kwargs):
        super().__init__(**kwargs)
        self._app = app
        self._window = app.get_application_window()
        self._plan = FolderPlan()
        self._selected = None
        self._adopted = False
        self._config = app.get_config_manager()
        self._query = ""
        self._save_width_source = 0
        image_filter = Gtk.FileFilter(name=_("Images"))
        image_filter.add_mime_type("image/svg+xml")
        image_filter.add_mime_type("image/png")
        self._image_filters = Gio.ListStore.new(Gtk.FileFilter)
        self._image_filters.append(image_filter)

        add_button = Gtk.Button(icon_name="list-add-symbolic", tooltip_text=_("Add a folder"))
        add_button.connect("clicked", self._on_add_clicked)
        self._search_button = Gtk.ToggleButton(icon_name="system-search-symbolic", tooltip_text=_("Search folders"))
        sidebar_header = Adw.HeaderBar(show_title=False, show_end_title_buttons=False)
        sidebar_header.pack_start(add_button)
        sidebar_header.pack_start(self._search_button)
        sidebar_header.pack_end(menu_button)
        self._search_entry = Gtk.SearchEntry(placeholder_text=_("Search folders"), hexpand=True)
        self._search_entry.connect("search-changed", self._on_search_changed)
        self._search_entry.connect("activate", self._on_search_activate)
        self._search_bar = Gtk.SearchBar(child=self._search_entry, show_close_button=False)
        self._search_bar.connect_entry(self._search_entry)
        self._search_bar.bind_property("search-mode-enabled", self._search_button, "active",
                                       GObject.BindingFlags.BIDIRECTIONAL | GObject.BindingFlags.SYNC_CREATE)
        self._search_bar.connect("notify::search-mode-enabled", self._on_search_mode_changed)
        self._list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE)
        self._list.add_css_class("navigation-sidebar")
        self._list.set_header_func(self._list_header)
        self._list.set_filter_func(self._list_filter)
        self._list_stack = Gtk.Stack(vexpand=True)
        self._list_stack.add_named(Gtk.ScrolledWindow(child=self._list), "list")
        no_match = Adw.StatusPage(icon_name="system-search-symbolic", title=_("No matching folder"))
        no_match.add_css_class("compact")
        self._list_stack.add_named(no_match, "empty")
        self._list.connect("row-selected", self._on_row_selected)
        self._context_item = None
        self._context_actions = Gio.SimpleActionGroup()
        for name, callback in (("open", self._on_context_open), ("reset", self._on_context_reset),
                               ("remove", self._on_context_remove), ("trash", self._on_context_trash)):
            action = Gio.SimpleAction(name=name)
            action.connect("activate", callback)
            self._context_actions.add_action(action)
        self._list.insert_action_group("row", self._context_actions)
        self._context_menu = None
        right_click = Gtk.GestureClick(button=Gdk.BUTTON_SECONDARY)
        right_click.connect("pressed", self._on_right_click)
        self._list.add_controller(right_click)
        long_press = Gtk.GestureLongPress()
        long_press.connect("pressed", lambda gesture, x, y: self._show_context_menu(x, y))
        self._list.add_controller(long_press)
        delete_key = Gtk.EventControllerKey()
        delete_key.connect("key-pressed", self._on_list_key_pressed)
        self._list.add_controller(delete_key)
        reapply = Gtk.Button(child=Adw.ButtonContent(icon_name="view-refresh-symbolic", label=_("Reapply everything")),
                             tooltip_text=_("Recreates missing folders, sets their icons again and hides the folders "
                                            "chosen as hidden"), margin_start=6, margin_end=6, margin_bottom=6)
        reapply.add_css_class("flat")
        reapply.connect("clicked", lambda *_args: self._run(self._plan.apply_all))
        sidebar_view = Adw.ToolbarView(content=self._list_stack)
        sidebar_view.add_top_bar(sidebar_header)
        sidebar_view.add_top_bar(self._search_bar)
        sidebar_view.add_bottom_bar(reapply)

        content_header = Adw.HeaderBar(title_widget=title_widget, show_start_title_buttons=False)
        self._detail = Gtk.Stack()
        self._detail.add_named(Adw.StatusPage(icon_name="folder-symbolic", title=_("Choose a folder")), "empty")
        content_view = Adw.ToolbarView(content=self._detail)
        content_view.add_top_bar(content_header)

        sidebar_view.set_size_request(240, -1)
        content_view.set_size_request(360, -1)
        self._paned = Gtk.Paned(start_child=sidebar_view, end_child=content_view, resize_start_child=False,
                                shrink_start_child=False, shrink_end_child=False, wide_handle=False,
                                position=self._config.get("folders.sidebar-width"))
        self._paned.connect("notify::position", self._on_paned_position)
        self.set_child(self._paned)
        self.reload()

    def reload(self):
        if self._context_menu:
            self._context_menu.unparent()
            self._context_menu = None
        self._plan = FolderPlan()
        if not self._adopted:
            self._adopted = True
            adopted = self._plan.adopt_existing()
            if adopted:
                self._plan.save()
                self._app.mark_unexported()
                self._app.notify(_("Folder icons found and added: %s") % ", ".join(adopted))
        self._list.remove_all()
        special_names = set()
        for folder in special_folders():
            special_names.add(folder["name"])
            path = absolute(folder["name"]) if folder["state"] == VISIBLE else None
            self._list.append(self._make_row(("special", folder), folder["name"], self._special_subtitle(folder), path))
        for folder in self._plan.folders:
            if folder["chemin"] in special_names:
                continue
            path = absolute(folder["chemin"])
            parent = os.path.dirname(folder["chemin"])
            subtitle = f"~/{parent}" if parent else "~"
            if not os.path.isdir(path):
                subtitle += f" — {_('missing')}"
            self._list.append(self._make_row(("plan", folder), os.path.basename(folder["chemin"]), subtitle, path))
        self._update_list_page()
        self._reselect()

    def _special_subtitle(self, folder):
        return {VISIBLE: _("Special folder"), HIDDEN: _("Hidden"),
                DISABLED: _("Disabled: points to your home folder")}[folder["state"]]

    def _make_row(self, item, title, subtitle, path):
        box = Gtk.Box(spacing=12, margin_top=6, margin_bottom=6)
        box.append(folder_image(path, 32))
        labels = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
        labels.append(Gtk.Label(label=title, xalign=0, ellipsize=Pango.EllipsizeMode.END))
        caption = Gtk.Label(label=subtitle, xalign=0, ellipsize=Pango.EllipsizeMode.END)
        caption.add_css_class("caption")
        caption.add_css_class("dim-label")
        labels.append(caption)
        box.append(labels)
        row = Gtk.ListBoxRow(child=box, tooltip_text=f"{title}\n{subtitle}")
        row.item = item
        row.search_text = normalize(f"{title} {data_path(item)}")
        return row

    def _list_filter(self, row):
        return all(word in row.search_text for word in self._query.split())

    def _on_search_changed(self, entry):
        self._query = normalize(entry.get_text())
        self._list.invalidate_filter()
        self._list.invalidate_headers()
        self._update_list_page()

    def _update_list_page(self):
        row = next((row for row in self._rows() if self._list_filter(row)), None)
        self._list_stack.set_visible_child_name("list" if row else "empty")

    def _on_search_activate(self, entry):
        row = next((row for row in self._rows() if self._list_filter(row)), None)
        if row:
            self._list.select_row(row)
            row.grab_focus()

    def _on_search_mode_changed(self, bar, pspec):
        if not bar.get_search_mode():
            self._search_entry.set_text("")

    def toggle_search(self):
        if self._search_bar.get_search_mode() and not self._search_entry.has_focus() and self._query:
            self._search_entry.grab_focus()
            return
        self._search_bar.set_search_mode(not self._search_bar.get_search_mode())
        if self._search_bar.get_search_mode():
            self._search_entry.grab_focus()

    def _on_paned_position(self, paned, pspec):
        if self._save_width_source:
            GLib.source_remove(self._save_width_source)
        self._save_width_source = GLib.timeout_add(400, self._save_width)

    def _save_width(self):
        self._save_width_source = 0
        self._config.set("folders.sidebar-width", self._paned.get_position())
        self._config.save()
        return GLib.SOURCE_REMOVE

    def _list_header(self, row, before):
        if before is not None and before.item[0] == row.item[0]:
            row.set_header(None)
            return
        title = _("Special folders") if row.item[0] == "special" else _("My folders")
        label = Gtk.Label(label=title, xalign=0, margin_start=12, margin_top=18 if before else 6, margin_bottom=6)
        label.add_css_class("heading")
        row.set_header(label)

    @staticmethod
    def _key(item):
        kind, data = item
        return kind, data["key"] if kind == "special" else data["chemin"]

    def _rows(self):
        index = 0
        while row := self._list.get_row_at_index(index):
            yield row
            index += 1

    def _reselect(self):
        for row in self._rows():
            if self._selected and self._key(row.item) == self._selected:
                self._list.select_row(row)
                return
        self._detail.set_visible_child_name("empty")

    def _on_row_selected(self, listbox, row):
        if row is None:
            return
        self._selected = self._key(row.item)
        self._show_detail(row.item)

    def _show_detail(self, item):
        kind, data = item
        if kind == "special":
            name = data["name"]
            path = absolute(name) if data["state"] == VISIBLE else None
            subtitle = self._special_subtitle(data)
        else:
            path = absolute(data["chemin"])
            name = os.path.basename(data["chemin"])
            subtitle = f"~/{data['chemin']}"
        header = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin_bottom=12)
        header.append(folder_image(path, 96))
        title = Gtk.Label(label=name, wrap=True, wrap_mode=Pango.WrapMode.WORD_CHAR, justify=Gtk.Justification.CENTER,
                          max_width_chars=40)
        title.add_css_class("title-2")
        header.append(title)
        caption = Gtk.Label(label=subtitle, ellipsize=Pango.EllipsizeMode.MIDDLE, max_width_chars=60,
                            tooltip_text=subtitle)
        caption.add_css_class("dim-label")
        header.append(caption)
        top = Adw.PreferencesGroup()
        top.add(header)
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=24, margin_top=24, margin_bottom=24,
                       margin_start=12, margin_end=12)

        def clamped(widget, size):
            clamp = Adw.Clamp(maximum_size=size, tightening_threshold=size, child=widget)
            page.append(clamp)

        clamped(top, 600)
        if path and os.path.isdir(path):
            clamped(self._icon_group(path), 1100)
        settings = Adw.PreferencesGroup()
        if kind == "special":
            hide = Adw.SwitchRow(title=_("Hidden"), active=data["state"] != VISIBLE,
                                 subtitle=_("Renamed with a leading dot: your applications keep using it"))
            hide.connect("notify::active", self._on_hide_toggled, data)
            settings.add(hide)
        else:
            create = Adw.SwitchRow(title=_("Recreate if missing"), active=data["creer"],
                                   subtitle=_("When restoring a backup or reapplying everything"))
            create.connect("notify::active", self._on_create_toggled, path)
            settings.add(create)
            remove = Adw.ButtonRow(title=_("Remove from the list"))
            remove.add_css_class("destructive-action")
            remove.connect("activated", lambda *_args: self._remove(path))
            settings.add(remove)
        clamped(settings, 600)
        page = Gtk.ScrolledWindow(child=page, hscrollbar_policy=Gtk.PolicyType.NEVER)
        old = self._detail.get_child_by_name("folder")
        if old:
            self._detail.remove(old)
        self._detail.add_named(page, "folder")
        self._detail.set_visible_child_name("folder")

    def _icon_group(self, path):
        current = read_custom_icon(path)
        group = Adw.PreferencesGroup(title=_("Icon"))
        other = Gtk.Button(icon_name="document-open-symbolic", tooltip_text=_("Another image…"), valign=Gtk.Align.CENTER)
        other.add_css_class("flat")
        other.connect("clicked", lambda *_args: self._choose_file(path))
        reset = Gtk.Button(icon_name="edit-undo-symbolic", tooltip_text=_("Back to the default icon"),
                           valign=Gtk.Align.CENTER, sensitive=current is not None)
        reset.add_css_class("flat")
        reset.connect("clicked", lambda *_args: self._run(self._reset_icon, path, record=path))
        suffix = Gtk.Box(spacing=6)
        suffix.append(other)
        suffix.append(reset)
        group.set_header_suffix(suffix)
        icons = sorted(name for name in os.listdir(ICONS_DIR) if name.endswith(ICON_SUFFIXES)) \
            if os.path.isdir(ICONS_DIR) else []
        if not icons:
            group.set_description(_("No folder icon in your collection yet: use the open button to add one"))
            return group
        search = Gtk.SearchEntry(placeholder_text=_("Search an icon by name"), margin_bottom=6)
        flow = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, homogeneous=True, min_children_per_line=2,
                           max_children_per_line=10, column_spacing=6, row_spacing=6)
        for name in icons:
            icon = os.path.join(ICONS_DIR, name)
            label_text = os.path.splitext(name)[0]
            image = Gtk.Image.new_from_file(icon)
            image.set_pixel_size(80)
            label = Gtk.Label(label=label_text, ellipsize=Pango.EllipsizeMode.MIDDLE, max_width_chars=14)
            label.add_css_class("caption")
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            box.append(image)
            box.append(label)
            button = Gtk.ToggleButton(child=box, active=same_icon(icon, current), tooltip_text=label_text)
            button.add_css_class("flat")
            button.connect("clicked", lambda _button, icon=icon: self._set_icon(path, icon))
            child = Gtk.FlowBoxChild(child=button)
            child.search_name = normalize(label_text)
            flow.append(child)
        flow.set_filter_func(lambda child: normalize(search.get_text()) in child.search_name)
        search.connect("search-changed", lambda _entry: flow.invalidate_filter())
        group.add(search)
        group.add(flow)
        return group

    def _set_icon(self, path, icon):
        if self._run(self._plan.set_icon, path, icon, record=path):
            self._app.notify_undoable(_("Folder icon changed"))

    def _on_right_click(self, gesture, n_press, x, y):
        self._show_context_menu(x, y)

    def _show_context_menu(self, x, y):
        row = self._list.get_row_at_y(int(y))
        if row is None:
            return
        self._list.select_row(row)
        self._context_item = row.item
        kind, data = row.item
        path = self._item_path(row.item)
        menu = Gio.Menu()
        if path and os.path.isdir(path):
            menu.append(_("Open in Files"), "row.open")
        if path and read_custom_icon(path):
            menu.append(_("Back to the default icon"), "row.reset")
        if kind == "plan":
            section = Gio.Menu()
            section.append(_("Remove from the list"), "row.remove")
            if os.path.isdir(path):
                section.append(_("Move folder to trash…"), "row.trash")
            menu.append_section(None, section)
        if menu.get_n_items() == 0:
            return
        ok, point = self._list.compute_point(row, Graphene.Point().init(x, y))
        rectangle = Gdk.Rectangle()
        rectangle.x, rectangle.y, rectangle.width, rectangle.height = int(point.x), int(point.y), 1, 1
        if self._context_menu:
            self._context_menu.unparent()
        self._context_menu = Gtk.PopoverMenu(menu_model=menu, has_arrow=False, halign=Gtk.Align.START,
                                             pointing_to=rectangle)
        self._context_menu.set_parent(row)
        self._context_menu.popup()

    def _on_list_key_pressed(self, controller, keyval, keycode, state):
        row = self._list.get_selected_row()
        if keyval != Gdk.KEY_Delete or row is None or row.item[0] != "plan":
            return False
        self._context_item = row.item
        if state & Gdk.ModifierType.SHIFT_MASK:
            self._on_context_trash()
        else:
            self._on_context_remove()
        return True

    @staticmethod
    def _item_path(item):
        kind, data = item
        if kind == "special":
            return absolute(data["name"]) if data["state"] == VISIBLE else None
        return absolute(data["chemin"])

    def _on_context_open(self, *args):
        file = Gio.File.new_for_path(self._item_path(self._context_item))
        Gtk.FileLauncher.new(file).launch(self._window, None, None)

    def _on_context_reset(self, *args):
        path = self._item_path(self._context_item)
        self._run(self._reset_icon, path, record=path)

    def _on_context_remove(self, *args):
        self._remove(self._item_path(self._context_item))

    def _on_context_trash(self, *args):
        path = self._item_path(self._context_item)
        if not os.path.isdir(path):
            return
        count = sum(len(files) for _root, _dirs, files in os.walk(path))
        dialog = Adw.AlertDialog(
            heading=_("Move “%s” to the trash?") % os.path.basename(path),
            body=(_("The folder and the %d files it contains go to the trash of Files, where you can restore them.")
                  % count if count else _("The folder is empty. It goes to the trash of Files.")))
        dialog.add_response("cancel", _("Cancel"))
        dialog.add_response("trash", _("Move to trash"))
        dialog.set_response_appearance("trash", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.set_close_response("cancel")
        dialog.connect("response", self._on_trash_response, path)
        dialog.present(self._window)

    def _on_trash_response(self, dialog, response, path):
        if response != "trash":
            return
        self._selected = None
        if self._run(self._trash, path, record=path):
            self._app.notify(_("“%s” moved to the trash") % os.path.basename(path))

    def _trash(self, path):
        Gio.File.new_for_path(path).trash(None)
        self._plan.remove(path)

    def _reset_icon(self, path):
        if self._plan.entry(path):
            self._plan.reset_icon(path)
        else:
            write_custom_icon(path, None)

    def _choose_file(self, path):
        dialog = Gtk.FileDialog(modal=True, title=_("Choose an icon"), filters=self._image_filters)
        dialog.open(self._window, None, self._on_file_chosen, path)

    def _on_file_chosen(self, dialog, result, path):
        try:
            icon = dialog.open_finish(result).get_path()
        except GLib.GError:
            return
        self._set_icon(path, icon)

    def _on_hide_toggled(self, row, pspec, folder):
        if row.get_active() == (folder["state"] != VISIBLE):
            return
        hidden = set(self._plan.hidden)
        if row.get_active():
            hidden.add(folder["name"])
        else:
            hidden.discard(folder["name"])
        self._plan.hidden = sorted(hidden)
        self._run(set_hidden, folder, row.get_active())

    def _on_create_toggled(self, row, pspec, path):
        if row.get_active() != self._plan.entry(path)["creer"]:
            self._run(self._plan.set_create, path, row.get_active(), record=path)

    def _remove(self, path):
        self._selected = None
        self._run(self._plan.remove, path, record=path)

    def _on_add_clicked(self, button):
        entry = Adw.EntryRow(title=_("Path from your home folder"), activates_default=True)
        entry.set_tooltip_text(_("For example Téléchargements/Archives or Projets"))
        group = Adw.PreferencesGroup()
        group.add(entry)
        dialog = Adw.AlertDialog(heading=_("Add a folder"), body=_("It is created right away if it does not exist yet"),
                                 extra_child=group)
        dialog.add_response("cancel", _("Cancel"))
        dialog.add_response("browse", _("Existing folder…"))
        dialog.add_response("add", _("Add"))
        dialog.set_response_appearance("add", Adw.ResponseAppearance.SUGGESTED)
        dialog.set_response_enabled("add", False)
        dialog.set_default_response("add")
        dialog.set_close_response("cancel")
        entry.connect("changed", lambda row: dialog.set_response_enabled("add", bool(row.get_text().strip(" /"))))
        dialog.connect("response", self._on_add_response, entry)
        dialog.present(self._window)

    def _on_add_response(self, dialog, response, entry):
        if response == "browse":
            chooser = Gtk.FileDialog(modal=True, title=_("Choose a folder"),
                                     initial_folder=Gio.File.new_for_path(GLib.get_home_dir()))
            chooser.select_folder(self._window, None, self._on_folder_chosen)
        elif response == "add":
            self._add(absolute(os.path.normpath(entry.get_text().strip(" /"))))

    def _on_folder_chosen(self, dialog, result):
        try:
            path = dialog.select_folder_finish(result).get_path()
        except GLib.GError:
            return
        self._add(path)

    def _add(self, path):
        self._selected = ("plan", relative(path))
        self._run(self._plan.add, path, record=path)

    def _run(self, function, *args, record=None):
        if record:
            self._app.record(os.path.basename(record), folders=[record])
        try:
            result = function(*args)
        except (OSError, GLib.GError) as error:
            self._app.notify(str(error), error=error)
            self.reload()
            return False
        self._plan.save()
        self._app.mark_unexported()
        if isinstance(result, list) and result:
            self._app.notify(_("Left as is: %s") % ", ".join(result))
        self.reload()
        return True
