#!/bin/bash
set -euo pipefail
NAME=iconostase VER=0.2.2 REL=1 ID=io.gitlab.shogu.Iconostase
ROOT=$(mktemp -d)
L=$ROOT/usr/lib/$NAME
install -d $L $ROOT/usr/bin $ROOT/usr/share/applications $ROOT/usr/share/licenses/$NAME \
  $ROOT/usr/share/icons/hicolor/scalable/apps $ROOT/usr/share/icons/hicolor/symbolic/apps
cd app
git ls-files main.py style.css defaults icons iconostase locale | while read -r f; do install -Dm644 "$f" "$L/$f"; done
install -Dm644 COPYING $ROOT/usr/share/licenses/$NAME/COPYING
cd ..
install -Dm644 $ID.svg $ROOT/usr/share/icons/hicolor/scalable/apps/$ID.svg
install -Dm644 $ID-symbolic.svg $ROOT/usr/share/icons/hicolor/symbolic/apps/$ID-symbolic.svg
printf '#!/bin/sh\nexec python3 /usr/lib/%s/main.py "$@"\n' $NAME > $ROOT/usr/bin/$NAME; chmod 755 $ROOT/usr/bin/$NAME
cat > $ROOT/usr/share/applications/$ID.desktop <<DESK
[Desktop Entry]
Type=Application
Name=Iconostase
Comment=Icônes des applications et des dossiers, lanceurs du menu
Keywords=icône;icone;symbolique;lanceur;menu;dossier;desktop;
Exec=$NAME %F
Icon=$ID
Categories=GNOME;GTK;Settings;DesktopSettings;
StartupNotify=true
DBusActivatable=false
MimeType=application/x-desktop;
DESK
SIZE=$(du -sb --exclude=.PKGINFO $ROOT | cut -f1)
cat > $ROOT/.PKGINFO <<PKG
pkgname = $NAME
pkgbase = $NAME
pkgver = $VER-$REL
pkgdesc = Icônes des applications (couleur et symbolique), des dossiers et lanceurs du menu — d'après Libre Menu Editor
url = https://gitlab.com/shogu
builddate = $(date +%s)
packager = Ogu
size = $SIZE
arch = any
license = GPL-3.0-or-later
depend = python
depend = python-gobject
depend = gtk4
depend = libadwaita
depend = gdk-pixbuf2
depend = librsvg
PKG
cd $ROOT
LANG=C bsdtar -czf .MTREE --format=mtree --options='!all,use-set,type,uid,gid,mode,time,size,md5,sha256,link' .PKGINFO usr
LANG=C bsdtar -cf - .MTREE .PKGINFO usr | zstd -q -19 -T0 -o /root/iconostase/$NAME-$VER-$REL-any.pkg.tar.zst -f
cd /; echo "$ROOT"
