#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
import ctypes
import gettext
import os
import sys

from gi.repository import Gio

PROJECT_DIR = os.path.dirname(os.path.realpath(__file__))
PR_SET_NAME = 15
ctypes.CDLL(None).prctl(PR_SET_NAME, b"iconostase", 0, 0, 0)
gettext.install("iconostase", os.path.join(PROJECT_DIR, "locale"))

from iconostase import APP_ID  # noqa: E402
from iconostase.application import Application  # noqa: E402

sys.exit(Application(PROJECT_DIR, application_id=APP_ID, flags=Gio.ApplicationFlags.HANDLES_OPEN).run(sys.argv))
