# SPDX-License-Identifier: GPL-3.0-or-later
# D'après libre-menu-editor (© 2022 Free Software Foundation).

from .core.events import EventManager


class KeywordsFilter():
    def __init__(self, app):
        self._events = EventManager()
        self._events.add("text-changed", object, str)
        self._flow_row = None
        self._flow_row_connection_id = None
        self._current_default_text = ""
        self._delimiter = ";"

    def _on_flow_row_text_changed(self, event, child, text):
        self._events.trigger("text-changed", self, self._get_unfiltered_text(text))

    def _get_unfiltered_text(self, text):
        if (
            not sorted(filter(None, text.split(self._delimiter)))
            == sorted(filter(None, self._current_default_text.split(self._delimiter)))
        ):
            return text
        else:
            return self._current_default_text

    def get_flow_row(self):
        return self._flow_row

    def set_flow_row(self, widget):
        if self._flow_row_connection_id:
            self._flow_row.disconnect(self._flow_row_connection_id)
        self._flow_row = widget
        self._flow_row_connection_id = self._flow_row.hook("text-changed", self._on_flow_row_text_changed)

    def get_text(self):
        text = self._get_unfiltered_text(self._flow_row.get_text())
        if not text == self._delimiter:
            return text
        else:
            return ""

    def set_text(self, text):
        self._current_default_text = text
        self._flow_row.set_text(text)

    def hook(self, event, callback):
        return self._events.hook(event, callback)

    def release(self, id):
        self._events.release(id)

    def reset(self):
        self._current_default_text = ""
        self._flow_row.reset()


class ComboFilter():
    def __init__(self, app):
        self._events = EventManager()
        self._events.add("text-changed", object, str)
        self._icon_finder = app.get_icon_finder()
        self._unknown_values_history = set()
        self._show_unknown_values = False
        self._ends_with_delimiter = None
        self._combo_row = None
        self._flow_row = None
        self._combo_row_connection_id = None
        self._flow_row_connection_id = None
        self._current_default_text = ""
        self._delimiter = ";"
        self._options_dict = {}

    def _on_combo_row_item_selected(self, event, name, label):
        self._flow_row.add_tags(label, allow_duplicates=False, warning_timeout=1)

    def _on_flow_row_text_changed(self, event, child, text):
        self._events.trigger("text-changed", self, self._filtered_to_default(text))

    def _join_text(self, strings):
        joined_text = self._delimiter.join(strings)
        if len(strings) and self._ends_with_delimiter:
            joined_text += self._delimiter
        return joined_text

    def _split_text(self, text):
        return list(filter(None, text.split(self._delimiter)))

    def _default_to_filtered(self, text, join_text=True):
        labels = []
        for item in self._split_text(text):
            if item in self._options_dict:
                label = self._options_dict[item]["label"]
                if not label in labels:
                    labels.append(label)
            elif self._show_unknown_values:
                labels.append(item)
        if join_text:
            return self._join_text(labels)
        else:
            return labels

    def _filtered_to_default(self, text):
        old_items = self._split_text(self._current_default_text)
        old_labels = self._default_to_filtered(self._current_default_text, join_text=False)
        new_labels = self._split_text(text)
        if sorted(old_labels) == sorted(new_labels):
            return self._current_default_text
        else:
            if not self._show_unknown_values:
                old_unknown_items = [item for item in old_items if not item in self._options_dict]
            else:
                old_unknown_items = []
            new_items = []
            for label in new_labels:
                label_found = False
                for item in self._options_dict:
                    if self._options_dict[item]["label"] == label:
                        new_items.append(item)
                        label_found = True
                else:
                    if not label_found and self._show_unknown_values:
                        new_items.append(label)
            return self._join_text(sorted(new_items + old_unknown_items))

    def _update_combo_row_buttons(self):
        if self._show_unknown_values:
            history = self._unknown_values_history
            current_names = self._split_text(self._current_default_text)
            buttons = self._combo_row.get_buttons()
            for name in current_names:
                if not name in self._options_dict:
                    if not name in history:
                        history.add(name)
            for name in buttons:
                if not name in self._options_dict and not name in history:
                    self._combo_row.remove_button(name, section="unknown")
            for name in history:
                if not name in buttons:
                    self._combo_row.add_button(name, name, self._fallback_icon_name, section="unknown")

    def get_combo_row(self):
        return self._combo_row

    def set_combo_row(self, widget):
        if self._combo_row_connection_id:
            for name in self._combo_row.get_buttons():
                self._combo_row.remove_button(name)
            self._combo_row.disconnect(self._combo_row_connection_id)
        self._combo_row = widget
        added_labels = set()
        for name in self._options_dict:
            label = self._options_dict[name]["label"]
            if not label in added_labels:
                added_labels.add(label)
                self._combo_row.add_button(name, label, self._options_dict[name]["icon-name"])
        self._combo_row_connection_id = self._combo_row.hook("item-selected", self._on_combo_row_item_selected)
        self._update_combo_row_buttons()

    def get_fallback_icon_name(self):
        return self._fallback_icon_name

    def set_fallback_icon_name(self, icon_name):
        self._fallback_icon_name = icon_name
        if self._combo_row:
            self._update_combo_row_buttons()

    def get_default_options(self):
        return self._options_dict

    def add_default_option(self, name, data):
        self._options_dict[name] = data

    def get_show_unknown_values(self):
        return self._show_unknown_values

    def set_show_unknown_values(self, value):
        self._show_unknown_values = value

    def get_flow_row(self):
        return self._flow_row

    def set_flow_row(self, widget):
        if self._flow_row_connection_id:
            self._flow_row.disconnect(self._flow_row_connection_id)
        self._flow_row = widget
        self._flow_row_connection_id = self._flow_row.hook("text-changed", self._on_flow_row_text_changed)

    def get_text(self):
        text = self._filtered_to_default(self._flow_row.get_text())
        if not text == self._delimiter:
            return text
        else:
            return ""

    def set_text(self, text):
        self._current_default_text = text
        self._ends_with_delimiter = text.endswith(self._delimiter)
        self._flow_row.set_text(self._default_to_filtered(text))
        self._update_combo_row_buttons()

    def get_unknown_values_history(self):
        return self._unknown_values_history

    def set_unknown_values_history(self, history):
        self._unknown_values_history = history

    def hook(self, event, callback):
        return self._events.hook(event, callback)

    def release(self, id):
        self._events.release(id)

    def reset(self):
        self._current_default_text = ""
        self._flow_row.reset()


class CategoriesFilter(ComboFilter):
    def __init__(self, app):
        super().__init__(app)
        self._options_dict = {
            "AudioVideo": {
                "label": _("Multimedia"),
                "icon-name": "applications-multimedia"
            },
            "Development": {
                "label": _("Development"),
                "icon-name": "applications-development"
            },
            "Education":  {
                "label": _("Education"),
                "icon-name": "applications-education"
            },
            "Game": {
                "label": _("Games"),
                "icon-name": "applications-games"
            },
            "Graphics": {
                "label": _("Graphics"),
                "icon-name": "applications-graphics"
            },
            "Network": {
                "label": _("Internet"),
                "icon-name": "applications-network"
            },
            "Office": {
                "label": _("Office"),
                "icon-name": "applications-office"
            },
            "Science": {
                "label": _("Science"),
                "icon-name": "applications-science"
            },
            "Settings": {
                "label": _("Settings"),
                "icon-name": "applications-settings"
            },
            "System": {
                "label": _("System"),
                "icon-name": "applications-system"
            },
            "Utility": {
                "label": _("Accessories"),
                "icon-name": "applications-utilities"
            }
        }


class ShowInFilter(ComboFilter):
    def __init__(self, app):
        super().__init__(app)
        self.set_show_unknown_values(True)
        self.set_fallback_icon_name("desktop-environment-nologo")
        for name in ["Budgie"]:
            self.add_default_option(name, {
                "label": "Budgie",
                "icon-name": "desktop-environment-budgie"
            })
        for name in ["X-Cinnamon"]:
            self.add_default_option(name, {
                "label": "Cinnamon",
                "icon-name": "desktop-environment-cinnamon"
            })
        for name in ["COSMIC"]:
            self.add_default_option(name, {
                "label": "COSMIC",
                "icon-name": "desktop-environment-cosmic"
            })
        for name in ["Cutefish"]:
            self.add_default_option(name, {
                "label": "Cutefish",
                "icon-name": "desktop-environment-cutefish"
            })
        for name in ["DDE"]:
            self.add_default_option(name, {
                "label": "Deepin",
                "icon-name": "desktop-environment-deepin"
            })
        for name in ["Endless"]:
            self.add_default_option(name, {
                "label": "Endless",
                "icon-name": "desktop-environment-endless"
            })
        for name in ["GNOME"]:
            self.add_default_option(name, {
                "label": "GNOME",
                "icon-name": "desktop-environment-gnome"
            })
        for name in ["KDE"]:
            self.add_default_option(name, {
                "label": "KDE",
                "icon-name": "desktop-environment-kde"
            })
        for name in ["LXDE"]:
            self.add_default_option(name, {
                "label": "LXDE",
                "icon-name": "desktop-environment-lxde"
            })
        for name in ["LXQt"]:
            self.add_default_option(name, {
                "label": "LXQt",
                "icon-name": "desktop-environment-lxqt"
            })
        for name in ["MATE"]:
            self.add_default_option(name, {
                "label": "MATE",
                "icon-name": "desktop-environment-mate"
            })
        for name in ["Pantheon"]:
            self.add_default_option(name, {
                "label": "Pantheon",
                "icon-name": "desktop-environment-pantheon"
            })
        for name in ["TDE"]:
            self.add_default_option(name, {
                "label": "Trinity",
                "icon-name": "desktop-environment-tde"
            })
        for name in ["Unity"]:
            self.add_default_option(name, {
                "label": "Unity",
                "icon-name": "desktop-environment-unity"
            })
        for name in ["XFCE"]:
            self.add_default_option(name, {
                "label": "XFCE",
                "icon-name": "desktop-environment-xfce"
            })
