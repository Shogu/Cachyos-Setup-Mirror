# SPDX-License-Identifier: GPL-3.0-or-later
import os
import tempfile
import zipfile

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk  # noqa: E402

from .icon_store import IconState

STATE_LABELS = {
    IconState.OK: _("complete"),
    IconState.NO_SYMBOLIC: _("no symbolic icon"),
    IconState.BY_PATH: _("set by path"),
    IconState.MISSING: _("not found"),
}


def icon_file(icon_theme, icon):
    if not icon:
        return None
    if os.path.sep in icon:
        return icon if os.path.isfile(icon) else None
    if not icon_theme.has_icon(icon):
        return None
    paintable = icon_theme.lookup_icon(icon, None, 256, 1, Gtk.TextDirection.NONE, Gtk.IconLookupFlags.FORCE_REGULAR)
    return paintable.get_file().get_path()


def export_icons(path, items, icon_store, icon_theme):
    lines = ["\t".join((_("identifier"), _("name"), _("state"), _("source file")))]
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, display_name, icon in items:
            source = icon_file(icon_theme, icon)
            if source:
                archive.write(source, f"{name}{os.path.splitext(source)[1].lower()}")
            if icon_store.has_symbolic(icon):
                symbolic = icon_theme.lookup_icon(f"{icon}-symbolic", None, 16, 1, Gtk.TextDirection.NONE, Gtk.IconLookupFlags(0))
                archive.write(symbolic.get_file().get_path(), f"{name}-symbolic.svg")
            lines.append(f"{name}\t{display_name}\t{STATE_LABELS[icon_store.state(icon)]}\t{source or ''}")
        archive.writestr("inventaire.tsv", "\n".join(lines) + "\n")


def import_icons(path, icon_store):
    names = set()
    with tempfile.TemporaryDirectory() as temp:
        with zipfile.ZipFile(path) as archive:
            members = [member for member in archive.namelist()
                       if member.lower().endswith((".svg", ".png")) and not member.endswith("/")]
            for member in members:
                target = os.path.join(temp, os.path.basename(member))
                with archive.open(member) as source, open(target, "wb") as file:
                    file.write(source.read())
        for filename in sorted(os.listdir(temp)):
            stem = os.path.splitext(filename)[0]
            source = os.path.join(temp, filename)
            if stem.endswith("-symbolic"):
                stem = stem[:-len("-symbolic")]
                icon_store.install_symbolic(stem, source)
            else:
                icon_store.install_color(stem, source)
            names.add(stem)
    icon_store.refresh()
    return sorted(names)


def names_in(path):
    with zipfile.ZipFile(path) as archive:
        stems = {os.path.splitext(os.path.basename(member))[0] for member in archive.namelist()
                 if member.lower().endswith((".svg", ".png"))}
    return sorted({stem[:-len("-symbolic")] if stem.endswith("-symbolic") else stem for stem in stems})
