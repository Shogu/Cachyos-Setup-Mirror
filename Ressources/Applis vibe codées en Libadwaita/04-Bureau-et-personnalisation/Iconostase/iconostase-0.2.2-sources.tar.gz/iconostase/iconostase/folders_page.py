# SPDX-License-Identifier: GPL-3.0-or-later
import os

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gio, GLib, Gtk, Pango  # noqa: E402

from .folder_icons import (DISABLED, HIDDEN, ICONS_DIR, VISIBLE, FolderPlan, absolute, read_custom_icon, relative,
                           set_hidden, special_folders, write_custom_icon)

ICON_SUFFIXES = (".svg", ".png")


def folder_image(path, size):
    icon = read_custom_icon(path) if path and os.path.isdir(path) else None
    image = Gtk.Image.new_from_file(icon) if icon and os.path.isfile(icon) else Gtk.Image.new_from_icon_name("folder")
    image.set_pixel_size(size)
    return image


def same_icon(first, second):
    return bool(second) and os.path.exists(second) and os.path.samefile(first, second)


class FoldersPage(Adw.Bin):
    def __init__(self, app, title_widget, menu_button, **kwargs):
        super().__init__(**kwargs)
        self._app = app
        self._window = app.get_application_window()
        self._plan = FolderPlan()
        self._selected = None
        self._adopted = False
        image_filter = Gtk.FileFilter(name=_("Images"))
        image_filter.add_mime_type("image/svg+xml")
        image_filter.add_mime_type("image/png")
        self._image_filters = Gio.ListStore.new(Gtk.FileFilter)
        self._image_filters.append(image_filter)

        add_button = Gtk.Button(icon_name="list-add-symbolic", tooltip_text=_("Add a folder"))
        add_button.connect("clicked", self._on_add_clicked)
        sidebar_header = Adw.HeaderBar(show_title=False)
        sidebar_header.pack_start(add_button)
        sidebar_header.pack_end(menu_button)
        self._list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE)
        self._list.add_css_class("navigation-sidebar")
        self._list.set_header_func(self._list_header)
        self._list.connect("row-selected", self._on_row_selected)
        reapply = Gtk.Button(child=Adw.ButtonContent(icon_name="view-refresh-symbolic", label=_("Reapply everything")),
                             tooltip_text=_("Recreates missing folders, sets their icons again and hides the folders "
                                            "chosen as hidden"), margin_start=6, margin_end=6, margin_bottom=6)
        reapply.add_css_class("flat")
        reapply.connect("clicked", lambda *_args: self._run(self._plan.apply_all))
        sidebar_view = Adw.ToolbarView(content=Gtk.ScrolledWindow(child=self._list, vexpand=True))
        sidebar_view.add_top_bar(sidebar_header)
        sidebar_view.add_bottom_bar(reapply)

        content_header = Adw.HeaderBar(title_widget=title_widget)
        self._detail = Gtk.Stack()
        self._detail.add_named(Adw.StatusPage(icon_name="folder-symbolic", title=_("Choose a folder")), "empty")
        content_view = Adw.ToolbarView(content=self._detail)
        content_view.add_top_bar(content_header)

        self._split = Adw.NavigationSplitView(
            sidebar=Adw.NavigationPage(title=_("Folders"), child=sidebar_view),
            content=Adw.NavigationPage(title=_("Folder"), child=content_view),
            min_sidebar_width=260, max_sidebar_width=340)
        self.set_child(self._split)
        self.reload()

    def reload(self):
        self._plan = FolderPlan()
        if not self._adopted:
            self._adopted = True
            adopted = self._plan.adopt_existing()
            if adopted:
                self._plan.save()
                self._app.mark_unexported()
                self._app.notify(_("Folder icons found and added: %s") % ", ".join(adopted))
        self._list.remove_all()
        special_names = set()
        for folder in special_folders():
            special_names.add(folder["name"])
            path = absolute(folder["name"]) if folder["state"] == VISIBLE else None
            self._list.append(self._make_row(("special", folder), folder["name"], self._special_subtitle(folder), path))
        for folder in self._plan.folders:
            if folder["chemin"] in special_names:
                continue
            path = absolute(folder["chemin"])
            parent = os.path.dirname(folder["chemin"])
            subtitle = f"~/{parent}" if parent else "~"
            if not os.path.isdir(path):
                subtitle += f" — {_('missing')}"
            self._list.append(self._make_row(("plan", folder), os.path.basename(folder["chemin"]), subtitle, path))
        self._reselect()

    def _special_subtitle(self, folder):
        return {VISIBLE: _("Special folder"), HIDDEN: _("Hidden"),
                DISABLED: _("Disabled: points to your home folder")}[folder["state"]]

    def _make_row(self, item, title, subtitle, path):
        box = Gtk.Box(spacing=12, margin_top=6, margin_bottom=6)
        box.append(folder_image(path, 32))
        labels = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
        labels.append(Gtk.Label(label=title, xalign=0, ellipsize=Pango.EllipsizeMode.END))
        caption = Gtk.Label(label=subtitle, xalign=0, ellipsize=Pango.EllipsizeMode.END)
        caption.add_css_class("caption")
        caption.add_css_class("dim-label")
        labels.append(caption)
        box.append(labels)
        row = Gtk.ListBoxRow(child=box)
        row.item = item
        return row

    def _list_header(self, row, before):
        if before is not None and before.item[0] == row.item[0]:
            row.set_header(None)
            return
        title = _("Special folders") if row.item[0] == "special" else _("My folders")
        label = Gtk.Label(label=title, xalign=0, margin_start=12, margin_top=18 if before else 6, margin_bottom=6)
        label.add_css_class("heading")
        row.set_header(label)

    @staticmethod
    def _key(item):
        kind, data = item
        return kind, data["key"] if kind == "special" else data["chemin"]

    def _reselect(self):
        row = self._list.get_first_child()
        while row:
            if self._selected and self._key(row.item) == self._selected:
                self._list.select_row(row)
                return
            row = row.get_next_sibling()
        self._detail.set_visible_child_name("empty")

    def _on_row_selected(self, listbox, row):
        if row is None:
            return
        self._selected = self._key(row.item)
        self._show_detail(row.item)
        self._split.set_show_content(True)

    def _show_detail(self, item):
        kind, data = item
        if kind == "special":
            name = data["name"]
            path = absolute(name) if data["state"] == VISIBLE else None
            subtitle = self._special_subtitle(data)
        else:
            path = absolute(data["chemin"])
            name = os.path.basename(data["chemin"])
            subtitle = f"~/{data['chemin']}"
        header = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, halign=Gtk.Align.CENTER, margin_bottom=12)
        header.append(folder_image(path, 96))
        title = Gtk.Label(label=name)
        title.add_css_class("title-2")
        header.append(title)
        caption = Gtk.Label(label=subtitle)
        caption.add_css_class("dim-label")
        header.append(caption)
        top = Adw.PreferencesGroup()
        top.add(header)
        page = Adw.PreferencesPage()
        page.add(top)
        if path and os.path.isdir(path):
            page.add(self._icon_group(path))
        settings = Adw.PreferencesGroup()
        if kind == "special":
            hide = Adw.SwitchRow(title=_("Hidden"), active=data["state"] != VISIBLE,
                                 subtitle=_("Renamed with a leading dot: your applications keep using it"))
            hide.connect("notify::active", self._on_hide_toggled, data)
            settings.add(hide)
        else:
            create = Adw.SwitchRow(title=_("Recreate if missing"), active=data["creer"],
                                   subtitle=_("When restoring a backup or reapplying everything"))
            create.connect("notify::active", self._on_create_toggled, path)
            settings.add(create)
            remove = Adw.ButtonRow(title=_("Remove from the list"))
            remove.add_css_class("destructive-action")
            remove.connect("activated", lambda *_args: self._remove(path))
            settings.add(remove)
        page.add(settings)
        old = self._detail.get_child_by_name("folder")
        if old:
            self._detail.remove(old)
        self._detail.add_named(page, "folder")
        self._detail.set_visible_child_name("folder")

    def _icon_group(self, path):
        current = read_custom_icon(path)
        group = Adw.PreferencesGroup(title=_("Icon"))
        other = Gtk.Button(icon_name="document-open-symbolic", tooltip_text=_("Another image…"), valign=Gtk.Align.CENTER)
        other.add_css_class("flat")
        other.connect("clicked", lambda *_args: self._choose_file(path))
        reset = Gtk.Button(icon_name="edit-undo-symbolic", tooltip_text=_("Back to the default icon"),
                           valign=Gtk.Align.CENTER, sensitive=current is not None)
        reset.add_css_class("flat")
        reset.connect("clicked", lambda *_args: self._run(self._reset_icon, path, record=path))
        suffix = Gtk.Box(spacing=6)
        suffix.append(other)
        suffix.append(reset)
        group.set_header_suffix(suffix)
        icons = sorted(name for name in os.listdir(ICONS_DIR) if name.endswith(ICON_SUFFIXES)) \
            if os.path.isdir(ICONS_DIR) else []
        if not icons:
            group.set_description(_("No folder icon in your collection yet: use the open button to add one"))
            return group
        flow = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, homogeneous=True, max_children_per_line=8,
                           column_spacing=6, row_spacing=6)
        for name in icons:
            icon = os.path.join(ICONS_DIR, name)
            image = Gtk.Image.new_from_file(icon)
            image.set_pixel_size(48)
            button = Gtk.ToggleButton(child=image, active=same_icon(icon, current),
                                      tooltip_text=os.path.splitext(name)[0])
            button.add_css_class("flat")
            button.connect("clicked", lambda _button, icon=icon: self._set_icon(path, icon))
            flow.append(button)
        group.add(flow)
        return group

    def _set_icon(self, path, icon):
        if self._run(self._plan.set_icon, path, icon, record=path):
            self._app.notify_undoable(_("Folder icon changed"))

    def _reset_icon(self, path):
        if self._plan.entry(path):
            self._plan.reset_icon(path)
        else:
            write_custom_icon(path, None)

    def _choose_file(self, path):
        dialog = Gtk.FileDialog(modal=True, title=_("Choose an icon"), filters=self._image_filters)
        dialog.open(self._window, None, self._on_file_chosen, path)

    def _on_file_chosen(self, dialog, result, path):
        try:
            icon = dialog.open_finish(result).get_path()
        except GLib.GError:
            return
        self._set_icon(path, icon)

    def _on_hide_toggled(self, row, pspec, folder):
        if row.get_active() == (folder["state"] != VISIBLE):
            return
        hidden = set(self._plan.hidden)
        if row.get_active():
            hidden.add(folder["name"])
        else:
            hidden.discard(folder["name"])
        self._plan.hidden = sorted(hidden)
        self._run(set_hidden, folder, row.get_active())

    def _on_create_toggled(self, row, pspec, path):
        if row.get_active() != self._plan.entry(path)["creer"]:
            self._run(self._plan.set_create, path, row.get_active(), record=path)

    def _remove(self, path):
        self._selected = None
        self._run(self._plan.remove, path, record=path)

    def _on_add_clicked(self, button):
        entry = Adw.EntryRow(title=_("Path from your home folder"), activates_default=True)
        entry.set_tooltip_text(_("For example Téléchargements/Archives or Projets"))
        group = Adw.PreferencesGroup()
        group.add(entry)
        dialog = Adw.AlertDialog(heading=_("Add a folder"), body=_("It is created right away if it does not exist yet"),
                                 extra_child=group)
        dialog.add_response("cancel", _("Cancel"))
        dialog.add_response("browse", _("Existing folder…"))
        dialog.add_response("add", _("Add"))
        dialog.set_response_appearance("add", Adw.ResponseAppearance.SUGGESTED)
        dialog.set_response_enabled("add", False)
        dialog.set_default_response("add")
        dialog.set_close_response("cancel")
        entry.connect("changed", lambda row: dialog.set_response_enabled("add", bool(row.get_text().strip(" /"))))
        dialog.connect("response", self._on_add_response, entry)
        dialog.present(self._window)

    def _on_add_response(self, dialog, response, entry):
        if response == "browse":
            chooser = Gtk.FileDialog(modal=True, title=_("Choose a folder"),
                                     initial_folder=Gio.File.new_for_path(GLib.get_home_dir()))
            chooser.select_folder(self._window, None, self._on_folder_chosen)
        elif response == "add":
            self._add(absolute(os.path.normpath(entry.get_text().strip(" /"))))

    def _on_folder_chosen(self, dialog, result):
        try:
            path = dialog.select_folder_finish(result).get_path()
        except GLib.GError:
            return
        self._add(path)

    def _add(self, path):
        self._selected = ("plan", relative(path))
        self._run(self._plan.add, path, record=path)

    def _run(self, function, *args, record=None):
        if record:
            self._app.record(os.path.basename(record), folders=[record])
        try:
            result = function(*args)
        except (OSError, GLib.GError) as error:
            self._app.notify(str(error), error=error)
            self.reload()
            return False
        self._plan.save()
        self._app.mark_unexported()
        if isinstance(result, list) and result:
            self._app.notify(_("Left as is: %s") % ", ".join(result))
        self.reload()
        return True
