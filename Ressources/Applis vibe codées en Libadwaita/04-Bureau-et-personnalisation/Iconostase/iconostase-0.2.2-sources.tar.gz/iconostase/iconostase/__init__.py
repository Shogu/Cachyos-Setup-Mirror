APP_ID = "io.gitlab.shogu.Iconostase"
VERSION = "0.2.2"
