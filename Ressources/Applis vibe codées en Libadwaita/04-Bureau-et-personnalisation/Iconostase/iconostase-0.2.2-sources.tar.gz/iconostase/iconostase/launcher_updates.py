# SPDX-License-Identifier: GPL-3.0-or-later
import os
import shutil
from configparser import ConfigParser

from gi.repository import GLib

ORIGINS_DIR = os.path.join(GLib.get_user_data_dir(), "iconostase", "origines")


def origin_path(name):
    return os.path.join(ORIGINS_DIR, f"{name}.desktop")


def _read(path):
    parser = ConfigParser(interpolation=None, strict=False)
    parser.optionxform = str
    with open(path, encoding="utf-8") as file:
        parser.read_file(file)
    return parser


def _values(parser):
    return {(section, key): value for section in parser.sections() for key, value in parser.items(section)}


def _same(first, second):
    with open(first, "rb") as one, open(second, "rb") as other:
        return one.read() == other.read()


def remember_origin(name, system_path):
    if not os.path.isfile(origin_path(name)):
        os.makedirs(ORIGINS_DIR, exist_ok=True)
        shutil.copyfile(system_path, origin_path(name))


def is_outdated(name, system_path, override_path):
    if not (os.path.isfile(system_path) and os.path.isfile(override_path)):
        return False
    remember_origin(name, system_path)
    return not _same(origin_path(name), system_path)


def package_changes(name, system_path, override_path):
    origin, new, mine = (_values(_read(path)) for path in (origin_path(name), system_path, override_path))
    changes = []
    for item in sorted(set(origin) | set(new)):
        if origin.get(item) != new.get(item):
            kept = mine.get(item) != origin.get(item)
            changes.append((item, origin.get(item), new.get(item), kept))
    return changes


def merge(name, system_path, override_path):
    origin, mine = _values(_read(origin_path(name))), _values(_read(override_path))
    result = _read(system_path)
    for section, key in set(origin) | set(mine):
        if origin.get((section, key)) == mine.get((section, key)):
            continue
        if (section, key) in mine:
            if not result.has_section(section):
                result.add_section(section)
            result.set(section, key, mine[(section, key)])
        elif result.has_option(section, key):
            result.remove_option(section, key)
    with open(override_path, "w", encoding="utf-8") as file:
        result.write(file, space_around_delimiters=False)
    shutil.copyfile(system_path, origin_path(name))


def accept(name, system_path):
    shutil.copyfile(system_path, origin_path(name))
