# SPDX-License-Identifier: GPL-3.0-or-later
# D'après libre-menu-editor (© 2022 Free Software Foundation).
import os

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import GLib, Adw, Gtk  # noqa: E402

from .core.config import ConfigManager
from .core.exec_escape import DesktopEntryCommandArgEscaper
from .icon_store import IconStore
from .widgets.icons import IconFinder


class BaseApplication(Adw.Application):
    def __init__(self, project_dir, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._application_window = Adw.ApplicationWindow()
        self._project_dir = os.path.abspath(os.path.realpath(project_dir))
        self._app_name = "iconostase"
        self._config_dir = os.path.join(GLib.get_user_data_dir(), self._app_name)
        self._cache_dir = os.path.join(GLib.get_user_cache_dir(), self._app_name)
        self._command_arg_escaper = DesktopEntryCommandArgEscaper()
        self._config_manager = ConfigManager(
            os.path.join(self._project_dir, "defaults", "config.json"),
            os.path.join(self._config_dir, "config.json")
        )
        self._icon_finder = IconFinder(self)
        self._icon_store = IconStore(self._icon_finder.get_theme())
        self._css_provider = Gtk.CssProvider()
        self._css_provider.load_from_path(os.path.join(self._project_dir, "style.css"))
        Gtk.StyleContext.add_provider_for_display(
            self._application_window.get_display(), self._css_provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        self._style_manager = Adw.StyleManager.get_default()
        self._style_manager.set_color_scheme(Adw.ColorScheme.DEFAULT)
        self._system_data_dirs = [
            os.path.join(GLib.get_user_data_dir(), "flatpak", "exports", "share"),
            os.path.join(os.path.sep, "var", "lib", "flatpak", "exports", "share"),
            *GLib.get_system_data_dirs(),
        ]
        self._icon_search_dirs = [
            os.path.join(GLib.get_user_data_dir(), "icons"),
            os.path.join(GLib.get_user_data_dir(), "pixmaps"),
            os.path.join(GLib.get_home_dir(), ".icons"),
        ]
        for path in self._system_data_dirs:
            self._icon_search_dirs.append(os.path.join(path, "icons"))
            self._icon_search_dirs.append(os.path.join(path, "pixmaps"))
        self._icon_search_dirs.append(os.path.join(self.get_project_dir(), "icons"))
        self._icon_finder.add_search_paths(*self._icon_search_dirs)
        self._command_lookup_cwd = GLib.get_home_dir()
        self._command_dirs = list(dict.fromkeys(filter(None, os.getenv("PATH", "").split(":"))))
        self.connect("activate", self._on_activate)
        self.connect("shutdown", self._on_shutdown)

    def _on_activate(self, app):
        GLib.set_prgname(self._app_name)
        self._application_window.set_default_size(
            self._config_manager.get("window.width"),
            self._config_manager.get("window.height")
        )
        if self._config_manager.get("window.maximized"):
            self._application_window.maximize()
        self._application_window.set_application(self)
        self._application_window.show()

    def _on_shutdown(self, app):
        self._config_manager.set("window.width", self._application_window.get_default_size()[0])
        self._config_manager.set("window.height", self._application_window.get_default_size()[1])
        self._config_manager.set("window.maximized", self._application_window.is_maximized())
        self._config_manager.save()

    def _join_path_prefix(self, *paths):
        names = [""]
        for path in paths:
            names.append(os.path.sep.join(list(filter(None, path.split(os.path.sep)))))
        return os.path.sep.join(names)

    def get_application_window(self):
        return self._application_window

    def get_project_dir(self):
        return self._project_dir

    def get_app_name(self):
        return self._app_name

    def get_config_dir(self):
        return self._config_dir

    def get_cache_dir(self):
        return self._cache_dir

    def get_config_manager(self):
        return self._config_manager

    def get_icon_finder(self):
        return self._icon_finder

    def get_icon_store(self):
        return self._icon_store

    def get_command_exists(self, text, desktop_entry=False, skip_empty_path=False, include_lookup_cwd=False):
        if len(text):
            first_arg = self._command_arg_escaper.get_first_arg_from_command(text)
            if desktop_entry:
                if (self._command_arg_escaper.get_has_quotes(first_arg)
                    and self._command_arg_escaper.get_has_escaped_chars(first_arg)
                ):
                    executable = self._command_arg_escaper.get_unescaped_arg(first_arg)
                else:
                    executable = first_arg
            else:
                executable = first_arg
            if os.path.sep in executable:
                if not executable.startswith(os.path.sep) and include_lookup_cwd:
                    executable = os.path.join(self._command_lookup_cwd, executable)
                if os.access(executable, os.X_OK) and os.path.isfile(executable):
                    return executable
            elif skip_empty_path and not len(self._command_dirs):
                return True
            elif len(executable):
                command_dirs = [*self._command_dirs, self._command_lookup_cwd] if include_lookup_cwd else self._command_dirs
                for command_dir in command_dirs:
                    path = self._join_path_prefix(command_dir, executable)
                    if os.access(path, os.X_OK) and os.path.isfile(path):
                        return path
