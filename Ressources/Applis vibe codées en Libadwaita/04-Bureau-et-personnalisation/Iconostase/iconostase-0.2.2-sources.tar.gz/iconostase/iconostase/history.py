# SPDX-License-Identifier: GPL-3.0-or-later
import datetime
import glob
import json
import os
import shutil

from .folder_icons import DATA_DIR, PLAN_PATH, FolderPlan, write_custom_icon
from .icon_store import COLLECTION, PNG_SIZES, USER_THEME

HISTORY_DIR = os.path.join(DATA_DIR, "historique")
MANIFEST = "manifeste.json"
KEPT = 20


def icon_files(name):
    candidates = [
        os.path.join(USER_THEME, "scalable", "apps", f"{name}.svg"),
        os.path.join(USER_THEME, "symbolic", "apps", f"{name}-symbolic.svg"),
        *(os.path.join(USER_THEME, f"{size}x{size}", "apps", f"{name}.png") for size in PNG_SIZES),
        *glob.glob(os.path.join(glob.escape(USER_THEME), "*", "apps", f"{glob.escape(name)}.png")),
        *(os.path.join(COLLECTION, f"{name}{suffix}") for suffix in (".svg", ".png", "-symbolic.svg")),
    ]
    return list(dict.fromkeys(candidates))


class History:
    def record(self, label, files=(), folders=()):
        snapshot = os.path.join(HISTORY_DIR, datetime.datetime.now().strftime("%Y%m%d-%H%M%S-%f"))
        os.makedirs(os.path.join(snapshot, "fichiers"))
        entries = []
        for index, path in enumerate(files):
            saved = None
            if os.path.isfile(path):
                saved = str(index)
                shutil.copy2(path, os.path.join(snapshot, "fichiers", saved))
            entries.append({"chemin": path, "copie": saved})
        if folders and os.path.isfile(PLAN_PATH):
            shutil.copy2(PLAN_PATH, os.path.join(snapshot, "dossiers.json"))
        manifest = {"libelle": label, "fichiers": entries, "dossiers": list(folders),
                    "plan": bool(folders) and os.path.isfile(PLAN_PATH)}
        with open(os.path.join(snapshot, MANIFEST), "w", encoding="utf-8") as file:
            json.dump(manifest, file, ensure_ascii=False, indent=1)
        for old in self._snapshots()[:-KEPT]:
            shutil.rmtree(old)

    def last_label(self):
        snapshots = self._snapshots()
        return self._manifest(snapshots[-1])["libelle"] if snapshots else None

    def undo(self):
        snapshot = self._snapshots()[-1]
        manifest = self._manifest(snapshot)
        for entry in manifest["fichiers"]:
            if entry["copie"] is not None:
                os.makedirs(os.path.dirname(entry["chemin"]), exist_ok=True)
                shutil.copy2(os.path.join(snapshot, "fichiers", entry["copie"]), entry["chemin"])
            elif os.path.isfile(entry["chemin"]):
                os.remove(entry["chemin"])
        if manifest["dossiers"]:
            if manifest["plan"]:
                shutil.copy2(os.path.join(snapshot, "dossiers.json"), PLAN_PATH)
            elif os.path.isfile(PLAN_PATH):
                os.remove(PLAN_PATH)
            plan = FolderPlan()
            for path in manifest["dossiers"]:
                folder = plan.entry(path)
                if os.path.isdir(path):
                    write_custom_icon(path, plan.icon_path(folder) if folder else None)
        shutil.rmtree(snapshot)
        return manifest["libelle"]

    @staticmethod
    def _snapshots():
        if not os.path.isdir(HISTORY_DIR):
            return []
        return [os.path.join(HISTORY_DIR, name) for name in sorted(os.listdir(HISTORY_DIR))]

    @staticmethod
    def _manifest(snapshot):
        with open(os.path.join(snapshot, MANIFEST), encoding="utf-8") as file:
            return json.load(file)

