# SPDX-License-Identifier: GPL-3.0-or-later
# D'après libre-menu-editor (© 2022 Free Software Foundation).
import configparser
from configparser import ConfigParser
import os
import shutil
import datetime
import zipfile

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import GLib, Gio, Gdk, Gtk, Adw  # noqa: E402

from . import APP_ID, VERSION, backup, icon_batch, launcher_updates
from .base_application import BaseApplication
from .folders_page import FoldersPage
from .history import History, icon_files
from .icons_export_dialog import IconsExportDialog
from .orphans_dialog import OrphansDialog
from .debug_log import DebugLog
from .desktop_entry import DesktopParser, NoAccessError
from .settings_page import SettingsPage
from .text_editor import DefaultTextEditor
from .widgets.constants import Keyval, Margin, Timeout
from .widgets.errors import ItemNotFoundError
from .widgets.layout import FlowingToolbar
from .widgets.menu import Menu
from .widgets.search_list import SearchList


class StarterAlreadyExistingError(Exception):
    pass


class StarterNotFoundError(Exception):
    pass


class StarterNotExternalError(Exception):
    pass


class Application(BaseApplication):
    def __init__(self, *args, **kwargs):
        self._debug_log = DebugLog(self)
        super().__init__(*args, **kwargs)
        self.connect("open", self._on_open)
        self._application_window.install_action("toast.details", None, self._on_toast_details_button_clicked)
        self._current_desktop_launcher_name = None
        self._desktop_launcher_parsers = {}
        self._unsaved_custom_launchers = {}
        self._ignore_show_hidden_switch_changes = False
        self._previous_discard_dialog = None
        self._back_button_fade_timeout_id = None
        self._back_button_fade_duration = 45
        xdg_current_desktop = os.getenv("XDG_CURRENT_DESKTOP")
        if isinstance(xdg_current_desktop, str):
            self._xdg_current_desktop_values = set(filter(None, xdg_current_desktop.split(":")))
        else:
            self._xdg_current_desktop_values = set()
        self._newly_created_launchers = []
        self._latest_launcher_mtimes = None
        self._latest_launcher_override_mtimes = {}
        self._custom_launcher_backups_dir = os.path.join(self.get_config_dir(), "backups")
        self._desktop_launcher_custom_create_name = "custom-launcher"
        self._desktop_launcher_template_path = os.path.join(self.get_project_dir(), "defaults", "launcher.desktop")
        self._desktop_launcher_override_dir = os.path.join(GLib.get_user_data_dir(), "applications")
        self._mimeapps_list_path = os.path.join(GLib.get_user_config_dir(), "mimeapps.list")
        self._start_page = Adw.StatusPage()
        self._start_page.set_margin_start(20)
        self._start_page.set_margin_end(20)
        self._start_page.set_title(_("Customize the menu"))
        self._start_page.set_description(_("Create a new application launcher or select an existing one from the sidebar"))
        self._start_page.set_icon_name(self._icon_finder.get_name("edit-find-replace-symbolic"))
        self._settings_page = SettingsPage(self)
        self._settings_page.hook("changed-changed", self._on_settings_page_changed_changed)
        self._settings_page.get_edit_file_action_row().connect("activated", self._on_edit_file_button_clicked)
        self._search_list = SearchList(self)
        self._search_list.hook("item-activated", self._on_search_list_item_activated)
        self._save_settings_button = self._settings_page.get_save_button()
        self._save_settings_button.set_label(_("Save"))
        self._save_settings_button.set_focus_on_click(False)
        self._save_settings_button.connect("clicked", self._on_save_settings_button_clicked)
        self._discard_settings_button = self._settings_page.get_reload_button()
        self._discard_settings_button.set_label(_("Discard"))
        self._discard_settings_button.set_focus_on_click(False)
        self._discard_settings_button.connect("clicked", self._on_discard_settings_button_clicked)
        self._reset_launcher_button = Gtk.Button()
        self._reset_launcher_button.set_label(_("Reset"))
        self._reset_launcher_button.set_focus_on_click(False)
        self._reset_launcher_button.connect("clicked", self._on_reset_launcher_button_clicked)
        self._delete_launcher_button_label = _("Delete launcher")
        self._delete_launcher_button = Adw.ButtonRow()
        self._delete_launcher_button.set_title(self._delete_launcher_button_label)
        self._delete_launcher_button.add_css_class("destructive-action")
        self._delete_launcher_button_preferences_group = Adw.PreferencesGroup()
        self._delete_launcher_button_preferences_group.add(self._delete_launcher_button)
        self._delete_launcher_button.connect("activated", self._on_delete_launcher_button_clicked)
        self._settings_page.get_bottom_area().append(self._delete_launcher_button_preferences_group)
        self._delete_launcher_button_preferences_group.set_hexpand(True)
        self._save_settings_button.set_can_shrink(True)
        self._reset_launcher_button.set_can_shrink(True)
        self._search_button = self._search_list.get_search_button()
        self._view_menu_section = Menu(self)
        self._view_menu_section.add_switch("show_hidden", _("Show hidden"))
        self._view_menu_section.set_switch_state("show_hidden", self._config_manager.get("show.hidden"))
        self._view_menu_section.hook("show_hidden", self._on_show_hidden_switch_changed)
        self._add_menu_section = Menu(self)
        self._add_menu_section.add_button("new_launcher", _("New launcher"))
        self._add_menu_section.hook("new_launcher", self._on_new_launcher_button_clicked)
        self._add_menu_section.add_button("open_file", _("Open launcher"))
        self._add_menu_section.hook("open_file", self._on_open_file_button_clicked)
        self._history = History()
        self._backup_menu_section = Menu(self)
        self._backup_menu_section.add_button("undo", _("Undo last change"))
        self._backup_menu_section.hook("undo", self._on_undo_clicked)
        self._backup_menu_section.set_enabled("undo", self._history.last_label() is not None)
        self._tools_menu_section = Menu(self)
        self._tools_menu_section.add_button("export_icons", _("Export icons to redesign…"))
        self._tools_menu_section.hook("export_icons", self._on_export_icons_clicked)
        self._tools_menu_section.add_button("import_icons", _("Import redesigned icons…"))
        self._tools_menu_section.hook("import_icons", self._on_import_icons_clicked)
        self._tools_menu_section.add_button("orphans", _("Orphan launchers…"))
        self._tools_menu_section.hook("orphans", self._on_orphans_clicked)
        self._backup_menu_section.add_button("export_backup", _("Export backup…"))
        self._backup_menu_section.hook("export_backup", self._on_export_backup_clicked)
        self._backup_menu_section.add_button("import_backup", _("Import backup…"))
        self._backup_menu_section.hook("import_backup", self._on_import_backup_clicked)
        self._help_menu_section = Menu(self)
        self._help_menu_section.add_button("show_shortcuts",
            _("Keyboard shortcuts"))
        self._help_menu_section.hook("show_shortcuts", self._on_show_shortcuts_button_clicked)
        self._help_menu_section.add_button("show_about", _("About this app"))
        self._help_menu_section.hook("show_about", self._on_show_about_button_clicked)
        self._menu_button_menu = Menu(self)
        self._menu_button_menu.append_section(None, self._view_menu_section)
        self._menu_button_menu.append_section(None, self._add_menu_section)
        self._menu_button_menu.append_section(None, self._tools_menu_section)
        self._menu_button_menu.append_section(None, self._backup_menu_section)
        self._menu_button_menu.append_section(None, self._help_menu_section)
        self._left_menu_button = Gtk.MenuButton()
        self._left_menu_button.set_icon_name(self._icon_finder.get_name("open-menu-symbolic"))
        self._left_menu_button.set_menu_model(self._menu_button_menu)
        self._left_menu_button.set_primary(True)
        self._more_options_menu_button_menu = Menu(self)
        self._more_options_menu_button_menu.add_button("duplicate-launcher",
            _("Duplicate launcher"))
        self._more_options_menu_button_menu.hook("duplicate-launcher", self._on_duplicate_launcher_button_clicked)
        self._more_options_menu_button_menu.add_button("export-icon", _("Export icon…"))
        self._more_options_menu_button_menu.hook("export-icon", self._on_export_current_icon_clicked)
        self._more_options_menu_button_menu.add_button("export-launcher",
            _("Export launcher"))
        self._more_options_menu_button_menu.hook("export-launcher", self._on_export_launcher_button_clicked)
        self._more_options_menu_button_menu.add_button("open-location",
            _("Open location"))
        self._more_options_menu_button_menu.hook("open-location", self._on_open_location_button_clicked)
        self._more_options_menu_button_menu.add_button("delete-launcher",
            _("Delete launcher"))
        self._more_options_menu_button_menu.hook("delete-launcher", self._on_delete_launcher_button_clicked)
        self._more_options_menu_button = Gtk.MenuButton()
        self._more_options_menu_button.set_icon_name(self._icon_finder.get_name("view-more-symbolic"))
        self._more_options_menu_button.set_menu_model(self._more_options_menu_button_menu)
        self._left_event_controller_key = Gtk.EventControllerKey()
        self._left_event_controller_key.connect("key-pressed", self._on_left_event_controller_key_pressed)
        self._left_header_bar_label = Gtk.Label()
        self._left_header_bar = Adw.HeaderBar()
        self._left_header_bar.set_title_widget(self._left_header_bar_label)
        self._left_header_bar.add_controller(self._left_event_controller_key)
        self._left_header_bar.pack_start(self._search_button)
        self._export_dots = []
        self._left_header_bar.pack_end(self._menu_button_with_dot(self._left_menu_button))
        self._right_event_controller_key = Gtk.EventControllerKey()
        self._right_event_controller_key.connect("key-pressed", self._on_right_event_controller_key_pressed)
        self._view_stack = Adw.ViewStack()
        self._right_header_bar_label = Adw.ViewSwitcher(stack=self._view_stack, policy=Adw.ViewSwitcherPolicy.WIDE)
        self._right_header_bar = Adw.HeaderBar()
        self._right_header_bar.set_title_widget(self._right_header_bar_label)
        self._right_header_bar.add_controller(self._right_event_controller_key)
        self._right_header_bar.pack_end(self._more_options_menu_button)
        self._header_bar_size_group = Gtk.SizeGroup()
        self._header_bar_size_group.add_widget(self._left_header_bar)
        self._header_bar_size_group.add_widget(self._right_header_bar)
        self._header_bar_size_group.set_mode(Gtk.SizeGroupMode.VERTICAL)
        self._start_page.set_margin_bottom(self._right_header_bar.get_preferred_size()[1].height)
        self._main_stack = Gtk.Stack()
        self._main_stack.add_child(self._start_page)
        self._main_stack.add_child(self._settings_page)
        self._search_bar = self._search_list.get_search_bar()
        self._search_bar.unparent()
        toolbar_view_top_box = Gtk.Box()
        toolbar_view_top_box.set_orientation(Gtk.Orientation.VERTICAL)
        toolbar_view_top_box.append(self._left_header_bar)
        toolbar_view_top_box.append(self._search_bar)
        self._left_area_box = Adw.ToolbarView()
        self._left_area_box.set_size_request(180, 200)
        self._left_area_box.add_top_bar(toolbar_view_top_box)
        self._left_area_box.set_content(self._search_list)
        self._right_area_bottom_toolbar_start = Gtk.Box()
        self._right_area_bottom_toolbar_end = Gtk.Box()
        self._right_area_bottom_toolbar = FlowingToolbar()
        self._right_area_bottom_toolbar.set_margin_top(Margin.DEFAULT)
        self._right_area_bottom_toolbar.set_margin_bottom(Margin.DEFAULT)
        self._right_area_bottom_toolbar.set_margin_start(Margin.DEFAULT)
        self._right_area_bottom_toolbar.set_margin_end(Margin.DEFAULT)
        self._right_area_bottom_toolbar.set_max_child_width(tuple(sorted((
            self._save_settings_button.get_preferred_size()[1].width,
            self._reset_launcher_button.get_preferred_size()[1].width,
        )))[-1])
        self._right_area_bottom_toolbar.set_start_widget(self._right_area_bottom_toolbar_start)
        self._right_area_bottom_toolbar.set_end_widget(self._right_area_bottom_toolbar_end)
        self._right_area_box = Adw.ToolbarView()
        self._right_area_box.set_size_request(300, 200)
        self._right_area_box.add_top_bar(self._right_header_bar)
        self._update_banner = Adw.Banner(title=_("The package updated this launcher since you customized it"),
                                         button_label=_("Review…"))
        self._update_banner.connect("button-clicked", self._on_update_banner_clicked)
        self._right_area_box.add_top_bar(self._update_banner)
        self._right_area_box.set_content(self._main_stack)
        self._right_area_box.add_bottom_bar(self._right_area_bottom_toolbar)
        self._right_area_box.set_reveal_bottom_bars(False)
        self._split_view_sidebar = Adw.NavigationPage(title=_("Applications"))
        self._split_view_sidebar.set_child(self._left_area_box)
        self._split_view_content = Adw.NavigationPage(title=_("Launcher"))
        self._split_view_content.set_child(self._right_area_box)
        self._main_split_layout = Adw.NavigationSplitView()
        self._main_split_layout.set_sidebar_width_fraction(1 / 4)
        self._main_split_layout.set_min_sidebar_width(self._left_area_box.get_property("width-request") * 9 / 8)
        self._main_split_layout.set_max_sidebar_width(self._left_area_box.get_property("width-request") * 5 / 3)
        self._main_split_layout.set_sidebar(self._split_view_sidebar)
        self._main_split_layout.set_content(self._split_view_content)
        self._main_split_layout.connect("notify::collapsed", self._on_main_split_layout_collapsed_changed)
        self._main_split_layout.connect("notify::show-content", self._on_main_split_layout_show_content_changed)
        window_breakpoint_limit = self._left_area_box.get_property("width-request") + (
            self._right_area_box.get_property("width-request") * 4 / 3)
        self._window_breakpoint = Adw.Breakpoint()
        self._window_breakpoint.add_setter(self._main_split_layout, "collapsed", True)
        self._window_breakpoint.set_condition(
            Adw.BreakpointCondition.parse(f"max-width: {window_breakpoint_limit}sp"))
        self._application_window.add_breakpoint(self._window_breakpoint)
        self._application_window.set_size_request(360, 300)
        self._main_stack.connect("notify::visible-child", self._on_main_stack_visible_child_changed)
        self._icon_browser_toolbar = self._settings_page.get_icon_browser().get_toolbar()
        self._icon_browser_toolbar.set_expand_condition(self._get_navigation_split_view_sidebar_expanded)
        self._navigation_split_view_sidebar_collapsed = self._main_split_layout.get_collapsed()
        self._toast_overlay = Adw.ToastOverlay()
        self._toast_overlay.set_vexpand(True)
        folders_menu_button = Gtk.MenuButton(icon_name="open-menu-symbolic", menu_model=self._menu_button_menu,
                                             primary=True)
        self._folders_page = FoldersPage(
            self, Adw.ViewSwitcher(stack=self._view_stack, policy=Adw.ViewSwitcherPolicy.WIDE),
            self._menu_button_with_dot(folders_menu_button))
        self._view_stack.add_titled_with_icon(
            self._main_split_layout, "applications", _("Applications"), "view-app-grid-symbolic")
        self._view_stack.add_titled_with_icon(self._folders_page, "folders", _("Folders"), "folder-symbolic")
        self._toast_overlay.set_child(self._view_stack)
        self._about_dialog = Adw.AboutDialog(
            application_icon=APP_ID,
            application_name=_("Main Menu"),
            developer_name="Ogu, d'après libre-menu-editor",
            version=VERSION,
            copyright="© 2022 Free Software Foundation",
            license_type=Gtk.License.GPL_3_0,
        )
        self._application_window_event_controller_key = Gtk.EventControllerKey()
        self._application_window_event_controller_key.connect("key-pressed",
            self._on_application_window_event_controller_key_pressed)
        self._application_window.set_icon_name(self._icon_finder.get_name(
            APP_ID))
        self._application_window.set_title(_("Main Menu"))
        self._application_window.add_controller(self._application_window_event_controller_key)
        self._application_window.connect("close-request", self._on_application_window_close_request)
        self._application_window.set_content(self._toast_overlay)
        self._text_editor = DefaultTextEditor(self)
        self._text_editor.hook("update", self._on_text_editor_update)
        open_filter = Gtk.FileFilter()
        open_filter.add_mime_type("application/x-desktop")
        open_filters = Gio.ListStore.new(Gtk.FileFilter)
        open_filters.append(open_filter)
        self._open_file_dialog = Gtk.FileDialog(modal=True, filters=open_filters,
            title=_("Choose launcher"),
            initial_folder=Gio.File.new_for_path(GLib.get_home_dir()))
        self._application_window_drop_target = Gtk.DropTarget.new(Gdk.FileList, Gdk.DragAction.COPY)
        self._application_window_drop_target.set_gtypes([Gdk.FileList])
        self._application_window_drop_target.connect("drop", self._on_application_window_drop_target_drop)
        self._application_window.add_controller(self._application_window_drop_target)
        self.connect("shutdown", self._on_application_shutdown)
        self._update_button_layout()
        self._load_desktop_launcher_dirs()
        self._check_desktop_launcher_mtimes()
        GLib.timeout_add_seconds(3, self._check_desktop_launcher_mtimes)

    def _on_application_window_drop_target_drop(self, drop_target, value, x, y):
        self._load_external_launchers(*[file.get_path() for file in value.get_files()])

    def _on_open(self, app, files, n_files, hint):
        self.activate()
        self._load_external_launchers(*[file.get_path() for file in files])

    def _on_text_editor_update(self, event, name):
        if name == self._current_desktop_launcher_name:
            self._check_unsaved_data(self._after_text_editor_update, name)
        else:
            self._after_text_editor_update(name)

    def _after_text_editor_update(self, name):
        try:
            self._text_editor.save(name)
            parser = self._text_editor.get_parser(name)
        except Exception as error:
            self.log(error, error=error)
            self.notify(_("Failed to save configurations"), error=error)
        else:
            text = parser.get_name()
            if not len(text):
                text = _("Unnamed Application")
            self.notify(_("Configurations for '%s' have been saved") % text)
            if name in self._unsaved_custom_launchers and not self._unsaved_custom_launchers[name]["external"]:
                del self._unsaved_custom_launchers[name]
            if name in self._desktop_launcher_parsers:
                parser = self._desktop_launcher_parsers[name]
                self._update_search_list_item(name)
                if name == self._current_desktop_launcher_name:
                    self._load_settings_page(name)
            if not name in self._unsaved_custom_launchers or not self._unsaved_custom_launchers[name]["external"]:
                try:
                    self._update_mime_data(parser)
                except Exception as error:
                    self.log(error, error=error)

    def _on_application_shutdown(self, app):
        self._create_custom_launcher_backups(*self._newly_created_launchers, replace_existing=True)

    def _on_application_window_close_request(self, window):
        self._settings_page.save_icon_brwser_configs()
        if self._settings_page.get_changed():
            self._check_unsaved_data(GLib.idle_add, self._application_window.destroy)
            return True

    def _on_application_window_event_controller_key_pressed(self, window, keyval, keycode, state):
        control_modifier_pressed = state == state | Gdk.ModifierType.CONTROL_MASK
        if (
            not self._main_split_layout.get_collapsed()
            or not self._main_split_layout.get_show_content()
        ):
            if (
                control_modifier_pressed and keyval == 102 # CTRL+F
            ):
                if (
                    self._search_list.get_search_mode()
                    and (not len(self._search_list.get_search_entry().get_text())
                    or not self._search_list.get_search_entry().get_focus_child() == None)
                ):
                    self._search_list.set_search_mode(False)
                else:
                    self._search_list.grab_focus()
                return True
            elif (
                control_modifier_pressed and keyval == 104 # CTRL+H
            ):
                state = self._view_menu_section.get_switch_state("show_hidden")
                self._view_menu_section.set_switch_state("show_hidden", state == False)
                return True
        if (
            control_modifier_pressed and keyval == 110 # CTRL+N
            and self._add_menu_section.get_enabled("new_launcher")
        ):
            self._on_new_launcher_button_clicked(None)
            return True
        elif (
            control_modifier_pressed and keyval == 111 # CTRL+O
        ):
            self._on_open_file_button_clicked(None)
            return True
        if (
            not self._main_split_layout.get_collapsed()
            or self._main_split_layout.get_show_content()
        ):
            if (
                (self._current_desktop_launcher_name in self._unsaved_custom_launchers
                and (control_modifier_pressed and (keyval == 114 or keyval == 100))) # CTRL+R, CTRL+D
                or (self._main_stack.get_visible_child() == self._settings_page
                and self._discard_settings_button.get_sensitive() and self._discard_settings_button.get_visible()
                and control_modifier_pressed and keyval == 65307) # CTRL+ESC
            ):
                self._on_discard_settings_button_clicked(None)
                return True
            elif (
                control_modifier_pressed and keyval == 115 # CTRL+S
                and self._main_stack.get_visible_child() == self._settings_page
                and self._save_settings_button.get_sensitive() and self._save_settings_button.get_visible()
            ):
                self._on_save_settings_button_clicked(None)
                return True
            elif (
                control_modifier_pressed and keyval == 101 # CTRL+E
                and self._main_stack.get_visible_child() == self._settings_page
            ):
                self._on_edit_file_button_clicked(None)
                return True
            elif (
                control_modifier_pressed and keyval == 114 # CTRL+R
                and self._main_stack.get_visible_child() == self._settings_page
                and self._reset_launcher_button.get_sensitive()
            ):
                self._on_reset_launcher_button_clicked(None)
                return True
            elif (
                control_modifier_pressed and keyval == 100 # CTRL+D
                and self._main_stack.get_visible_child() == self._settings_page
                and self._delete_launcher_button.get_sensitive()
            ):
                self._on_delete_launcher_button_clicked(None)
                return True
        if control_modifier_pressed and keyval == 223: # CTRL+?
            self._on_show_shortcuts_button_clicked(None)
        elif control_modifier_pressed and keyval == 113: # CTRL+Q
            self._application_window.close()
        elif control_modifier_pressed and keyval == 119: # CTRL+W
            self._application_window.close()

    def _on_toast_details_button_clicked(self, widget, action_name, parameter):
        self._on_show_about_button_clicked(None)

    def _on_open_file_dialog_finished(self, dialog, result):
        try:
            files = dialog.open_multiple_finish(result)
        except GLib.GError:
            return
        self._load_external_launchers(*[file.get_path() for file in files], skip_discard_dialog=True)

    def _on_install_dialog_response(self, dialog, response, callback, args, kwargs):
        if response == "save":
            self._save_settings_page(skip_dialog=True)
        elif response == "install":
            self._unsaved_custom_launchers[self._current_desktop_launcher_name]["external"] = False
            callback(*args, **kwargs)
            if self._save_settings_page(skip_dialog=True):
                self._unsaved_custom_launchers[self._current_desktop_launcher_name]["external"] = True

    def _on_discard_dialog_response(self, dialog, response, callback, args, kwargs):
        self._previous_discard_dialog = None
        if response == "save":
            if not self._save_settings_page():
                callback(*args, **kwargs)
        elif response == "discard":
            callback(*args, **kwargs)
        else:
            self._update_search_list_selection()

    def _on_confirm_dialog_response(self, dialog, response, callback, args, kwargs):
        if response == "continue":
            callback(*args, **kwargs)

    def _on_export_dialog_finished(self, dialog, result):
        try:
            file = dialog.save_finish(result)
        except GLib.GError:
            return
        parser = self._desktop_launcher_parsers[self._current_desktop_launcher_name]
        parser.save(path=file.get_path(), no_callback=True)
        text = parser.get_name() or _("Unnamed Application")
        self.notify(_("Configurations for '%s' have been saved") % text)

    def _on_main_split_layout_collapsed_changed(self, widget, gparam):
        GLib.idle_add(setattr, self, "_navigation_split_view_sidebar_collapsed", widget.get_collapsed(),
            priority=GLib.PRIORITY_LOW)
        self._update_button_layout()

    def _on_main_split_layout_show_content_changed(self, widget, gparam):
        self._settings_page.get_icon_chooser_row().set_search_mode(False)

    def _on_settings_page_changed_changed(self, event, previous_value, current_value):
        if self._back_button_fade_timeout_id:
            GLib.source_remove(self._back_button_fade_timeout_id)
            self._back_button_fade_timeout_id = None
        if current_value:
            if os.getenv("HIDE_NAVIGATION_PAGE_BACK_BUTTON") == "true":
                self._split_view_content.set_can_pop(False)
        else:
            self._back_button_fade_timeout_id = GLib.timeout_add(self._back_button_fade_duration,
                self._after_settings_page_changed_changed)
    def _after_settings_page_changed_changed(self):
        self._split_view_content.set_can_pop(True)
        self._back_button_fade_timeout_id = None
        return GLib.SOURCE_REMOVE
    def _on_main_stack_visible_child_changed(self, stack, gparam):
        if not self._main_stack.get_visible_child() == self._settings_page:
            self._main_split_layout.set_show_content(False)
            self._current_desktop_launcher_name = None
            if self._settings_page.get_changed():
                self._settings_page.reset(reset_data=False)
        self._update_button_layout()

    def _on_left_event_controller_key_pressed(self, controller, keyval, keycode, state):
        if keyval == Keyval.DOWN or keyval == Keyval.PAGEDOWN:
            self._search_list.grab_focus()
            return True

    def _on_right_event_controller_key_pressed(self, controller, keyval, keycode, state):
        if keyval == Keyval.DOWN or keyval == Keyval.PAGEDOWN:
            self._main_stack.get_visible_child().grab_focus()
            return True

    def _on_show_hidden_switch_changed(self, name):
        if not self._ignore_show_hidden_switch_changes:
            state = self._view_menu_section.get_switch_state(name)
            if not self._config_manager.get("show.hidden") == state:
                if self._current_desktop_launcher_name:
                    parser = self._desktop_launcher_parsers[self._current_desktop_launcher_name]
                    if not state and parser.get_hidden():
                        self._set_show_hidden_switch_state_without_triggering(state == False)
                        self._check_unsaved_data(self._after_show_hidden_switch_changed, state)
                    else:
                        self._after_show_hidden_switch_changed(state)
                else:
                    self._after_show_hidden_switch_changed(state)

    def _after_show_hidden_switch_changed(self, state):
        self._set_show_hidden_switch_state_without_triggering(state)
        self._config_manager.set("show.hidden", state)
        self._reload_search_list_items()

    def _on_duplicate_launcher_button_clicked(self, event):
        name = self._current_desktop_launcher_name
        self._check_unsaved_data(self._duplicate_desktop_launcher, name)

    def _on_export_launcher_button_clicked(self, event):
        Gtk.FileDialog(modal=True, initial_name=f"{self._current_desktop_launcher_name}.desktop").save(
            self._application_window, None, self._on_export_dialog_finished)

    def _on_open_location_button_clicked(self, event):
        name = self._current_desktop_launcher_name
        if self._get_desktop_launcher_has_override(name):
            location = self._desktop_launcher_override_dir
        else:
            location = os.path.dirname(self._desktop_launcher_parsers[name].get_load_path())
        Gtk.FileLauncher.new(Gio.File.new_for_path(location)).launch(self._application_window, None, None)

    def _on_reset_launcher_button_clicked(self, event):
        self._show_reset_dialog(self._reset_desktop_launcher, self._current_desktop_launcher_name)

    def _on_delete_launcher_button_clicked(self, event):
        if self._current_desktop_launcher_name in self._unsaved_custom_launchers:
            if self._settings_page.get_changed():
                self._show_discard_dialog(self._remove_desktop_launcher, self._current_desktop_launcher_name,
                    notify_user=True)
            else:
                self._remove_desktop_launcher(self._current_desktop_launcher_name, notify_user=True)

        else:
            self._show_delete_dialog(self._delete_desktop_launcher, self._current_desktop_launcher_name)

    def _on_edit_file_button_clicked(self, event):
        if self._settings_page.get_changed():
            self._check_unsaved_data(self._after_edit_file_button_clicked)
        else:
            self._edit_desktop_launcher(self._current_desktop_launcher_name)

    def _after_edit_file_button_clicked(self):
        name = self._current_desktop_launcher_name
        self._load_settings_page(name)
        self._edit_desktop_launcher(name)

    def _on_open_file_button_clicked(self, event):
        self._check_unsaved_data(self._after_open_file_button_clicked)

    def _after_open_file_button_clicked(self):
        if self._current_desktop_launcher_name:
            self._load_settings_page(self._current_desktop_launcher_name)
        self._open_file_dialog.open_multiple(self._application_window, None, self._on_open_file_dialog_finished)

    def _on_show_shortcuts_button_clicked(self, event):
        self._show_shortcuts_dialog()

    def _on_show_about_button_clicked(self, event):
        self._about_dialog.set_debug_info(self._debug_log.get())
        self._about_dialog.present(self._application_window)

    def _on_new_launcher_button_clicked(self, button):
        if (
            not self._current_desktop_launcher_name in self._unsaved_custom_launchers
            or self._unsaved_custom_launchers[self._current_desktop_launcher_name]["external"]
        ):
            self._check_unsaved_data(self._create_desktop_launcher)
        else:
            self._create_desktop_launcher()

    def _on_save_settings_button_clicked(self, button):
        self._save_settings_page()

    def _on_discard_settings_button_clicked(self, button):
        if self._current_desktop_launcher_name in self._unsaved_custom_launchers:
            self._remove_desktop_launcher(self._current_desktop_launcher_name)
        else:
            self._load_settings_page(self._current_desktop_launcher_name)

    def _on_search_list_item_activated(self, event, name):
        self._check_unsaved_data(self._load_settings_page, name, ignore_name=name)
        return True

    def _on_parser_saved(self, data):
        name, parser = data
        if self._desktop_launcher_parsers[name] == parser:
            save_path = parser.get_save_path()
            self._latest_launcher_mtimes[name] = os.path.getmtime(save_path)
            default_path = self._get_desktop_launcher_default_path(name)
            if os.path.isfile(default_path):
                launcher_updates.remember_origin(name, default_path)
        self.mark_unexported()

    def _get_desktop_launcher_has_system_default(self, name):
        return os.path.exists(self._get_desktop_launcher_default_path(name))

    def _get_desktop_launcher_has_override(self, name):
        return os.path.exists(self._get_desktop_launcher_override_path(name))

    def _get_desktop_launcher_has_backup_copy(self, name):
        return os.path.exists(os.path.join(self._custom_launcher_backups_dir, f"{name}.desktop"))

    def _get_desktop_launcher_can_reset(self, name):
        if name in self._desktop_launcher_parsers:
            self._remove_orphaned_launcher_backups(name)
            if (
                self._get_desktop_launcher_has_system_default(name)
                and self._get_desktop_launcher_has_override(name)
            ):
                return True
            elif self._get_desktop_launcher_has_backup_copy(name):
                backup_path = os.path.join(self._custom_launcher_backups_dir, f"{name}.desktop")
                override_path = self._get_desktop_launcher_override_path(name)
                override_mtime = os.path.getmtime(override_path)
                if (
                    not name in self._latest_launcher_override_mtimes
                    or not self._latest_launcher_override_mtimes[name]["mtime"] == override_mtime
                ):
                    with open(backup_path, "r", encoding="utf-8") as backup_file:
                        with open(override_path, "r", encoding="utf-8") as override_file:
                            changed = not backup_file.read() == override_file.read()
                            self._latest_launcher_override_mtimes[name] = {
                                "mtime": override_mtime,
                                "changed": changed
                                }
                            return changed
                else:
                    return self._latest_launcher_override_mtimes[name]["changed"]

    def _get_desktop_launcher_default_path(self, name):
        for directory in self._system_data_dirs:
            path = os.path.join(directory, "applications", "%s.desktop" % name)
            if os.path.exists(path):
                return path
        else:
            return os.path.join(self._system_data_dirs[0], "applications", "%s.desktop" % name)

    def _get_desktop_launcher_override_path(self, name):
        return os.path.join(self._desktop_launcher_override_dir, f"{name}.desktop")

    def _get_desktop_launcher_names(self):
        directories = []
        for directory in self._system_data_dirs:
            directories.append(os.path.join(directory, "applications"))
        else:
            directories.append(self._desktop_launcher_override_dir)
        names = {}
        for directory in directories:
            if os.path.exists(directory):
                for dirpath, dirnames, filenames in os.walk(directory):
                    for filename in filenames:
                        if filename.endswith(".desktop"):
                            full_path = os.path.join(dirpath, filename)
                            relative_path = os.path.relpath(full_path, directory)
                            name = relative_path[:-len(".desktop")].strip(os.path.sep)
                            names[name] = full_path
        else:
            return names

    def _get_can_save_external_launcher(self, name):
        if name in self._desktop_launcher_parsers:
            parser = self._desktop_launcher_parsers[name]
            if name in self._unsaved_custom_launchers and self._unsaved_custom_launchers[name]["external"]:
                return (
                    self._unsaved_custom_launchers[name]["save-path"] and parser.get_save_path()
                    and os.access(parser.get_save_path(), os.W_OK)
                )
            else:
                raise StarterNotExternalError(name)
        else:
            raise StarterNotFoundError(name)

    def _get_navigation_split_view_sidebar_expanded(self):
        return not self._navigation_split_view_sidebar_collapsed

    def _set_show_hidden_switch_state_without_triggering(self, state):
        self._ignore_show_hidden_switch_changes = True
        self._view_menu_section.set_switch_state("show_hidden", state)
        self._ignore_show_hidden_switch_changes = False

    def _remove_orphaned_launcher_backups(self, *names):
        if not len(names):
            if os.path.exists(self._custom_launcher_backups_dir):
                names = []
                for root, dirs, files in os.walk(self._custom_launcher_backups_dir):
                    for basename in files:
                        full_path = os.path.join(root, basename)
                        name = os.path.relpath(full_path, start=self._custom_launcher_backups_dir)
                        if name.endswith(".desktop"):
                            name = name[:-len(".desktop")]
                        else:
                            # rename backups that predate issue 70 fix
                            if not os.path.exists(f"{full_path}.desktop"):
                                os.rename(full_path, f"{full_path}.desktop")
                            else:
                                os.remove(full_path)
                                continue
                        names.append(name)
                    for directory in dirs:
                        dir_path = os.path.join(root, directory)
                        if not len(os.listdir(dir_path)):
                            os.rmdir(dir_path)
            else:
                return
        for name in names:
            if name in self._unsaved_custom_launchers:
                continue
            backup_path = os.path.join(self._custom_launcher_backups_dir, f"{name}.desktop")
            override_path = self._get_desktop_launcher_override_path(name)
            if (
                os.path.exists(backup_path) and (self._get_desktop_launcher_has_system_default(name)
                or not os.path.exists(override_path))
            ):
                os.remove(backup_path)

    def _create_custom_launcher_backups(self, *names, replace_existing=False):
        self._remove_orphaned_launcher_backups(*names)
        for name in names:
            if not self._get_desktop_launcher_has_system_default(name):
                backup_path = os.path.join(self._custom_launcher_backups_dir, f"{name}.desktop")
                override_path = self._get_desktop_launcher_override_path(name)
                if os.path.exists(override_path):
                    if not os.path.exists(backup_path) or replace_existing:
                        if os.path.exists(backup_path):
                            os.remove(backup_path)
                        os.makedirs(os.path.dirname(backup_path), exist_ok=True)
                        shutil.copy(override_path, backup_path)

    def _restore_custom_launcher_backups(self, *names):
        self._remove_orphaned_launcher_backups(*names)
        for name in names:
            if not self._get_desktop_launcher_has_system_default(name):
                backup_path = os.path.join(self._custom_launcher_backups_dir, f"{name}.desktop")
                if os.path.exists(backup_path):
                    override_path = self._get_desktop_launcher_override_path(name)
                    if os.path.exists(override_path):
                        os.remove(override_path)
                    shutil.copy(backup_path, override_path)

    def _load_desktop_launcher_dirs(self):
        for name in reversed(sorted(self._get_desktop_launcher_names())):
            try:
                self._add_desktop_launcher(name)
            except Exception as error:
                self.log(error, error=error)
        else:
            self._remove_orphaned_launcher_backups()

    def _focus_settings_page(self):
        self._main_split_layout.set_show_content(True)
    def _check_unsaved_data(self, *callback_args, **callback_kwargs):
        if "ignore_name" in callback_kwargs:
            ignore_name = callback_kwargs.pop("ignore_name")
        else:
            ignore_name = None
        if (ignore_name and not ignore_name == self._current_desktop_launcher_name) or not ignore_name:
            if self._settings_page.get_changed():
                if self._previous_discard_dialog:
                    self._previous_discard_dialog.force_close()
                self._previous_discard_dialog = self._show_discard_dialog(*callback_args, **callback_kwargs)
                return True
            else:
                if len(callback_args) > 1:
                    callback_args[0](*callback_args[1:], **callback_kwargs)
                else:
                    callback_args[0](**callback_kwargs)
        else:
            self._focus_settings_page()

    def _show_shortcuts_dialog(self):
        builder = Gtk.Builder.new_from_string("""
            <?xml version="1.0" encoding="UTF-8"?>
            <interface><object class="GtkShortcutsWindow" id="shortcuts-window">
            <property name="modal">1</property>
                <child><object class="GtkShortcutsSection">
                <property name="max-height">10</property>
                    <child><object class="GtkShortcutsGroup">
                    <property name="title">{}</property>
                        <child><object class="GtkShortcutsShortcut">
                        <property name="accelerator">{}</property>
                        <property name="title">{}</property>
                        </object></child>
                        <child><object class="GtkShortcutsShortcut">
                        <property name="accelerator">{}</property>
                        <property name="title">{}</property>
                        </object></child>
                        <child><object class="GtkShortcutsShortcut">
                        <property name="accelerator">{}</property>
                        <property name="title">{}</property>
                        </object></child>
                        <child><object class="GtkShortcutsShortcut">
                        <property name="accelerator">{}</property>
                        <property name="title">{}</property>
                        </object></child>
                        <child><object class="GtkShortcutsShortcut">
                        <property name="accelerator">{}</property>
                        <property name="title">{}</property>
                        </object></child>
                        <child><object class="GtkShortcutsShortcut">
                        <property name="accelerator">{}</property>
                        <property name="title">{}</property>
                        </object></child>
                        <child><object class="GtkShortcutsShortcut">
                        <property name="accelerator">{}</property>
                        <property name="title">{}</property>
                        </object></child>
                    </object></child>
                    <child><object class="GtkShortcutsGroup">
                    <property name="title">{}</property>
                        <child><object class="GtkShortcutsShortcut">
                        <property name="accelerator">{}</property>
                        <property name="title">{}</property>
                        </object></child>
                        <child><object class="GtkShortcutsShortcut">
                        <property name="accelerator">{}</property>
                        <property name="title">{}</property>
                        </object></child>
                    </object></child>
                    <child><object class="GtkShortcutsGroup">
                    <property name="title">{}</property>
                        <child><object class="GtkShortcutsShortcut">
                        <property name="accelerator">{}</property>
                        <property name="title">{}</property>
                        </object></child>
                        <child><object class="GtkShortcutsShortcut">
                        <property name="accelerator">{}</property>
                        <property name="title">{}</property>
                        </object></child>
                        <child><object class="GtkShortcutsShortcut">
                        <property name="accelerator">{}</property>
                        <property name="title">{}</property>
                        </object></child>
                    </object></child>
                </object></child>
            </object></interface>
            """.format(
            _("Edit"),
            "&lt;ctrl&gt;o", _("Open launcher"),
            "&lt;ctrl&gt;n", _("New launcher"),
            "&lt;ctrl&gt;e", _("Edit document"),
            "&lt;ctrl&gt;s", _("Save"),
            "&lt;ctrl&gt;r", _("Reset"),
            "&lt;ctrl&gt;d", _("Delete launcher"),
            "&lt;ctrl&gt;Escape", _("Discard"),
            _("Find"),
            "&lt;ctrl&gt;f", _("Search launchers"),
            "&lt;ctrl&gt;h", _("Show hidden"),
            _("General"),
            "&lt;ctrl&gt;q", _("Quit application"),
            "&lt;ctrl&gt;question", _("Show shortcuts"),
            "F10", _("Open menu")
        ), -1)
        window = builder.get_object("shortcuts-window")
        window.set_transient_for(self._application_window)
        window.set_modal(True)
        window.set_hide_on_close(False)
        window.set_visible(True)

    def _show_alert(self, heading, body, responses, appearance, handler, callback, callback_args, callback_kwargs):
        dialog = Adw.AlertDialog(heading=heading, body=body)
        for response, label in responses.items():
            dialog.add_response(response, label)
        dialog.set_close_response("back")
        dialog.set_response_appearance(response, appearance)
        dialog.connect("response", handler, callback, callback_args, callback_kwargs)
        dialog.present(self._application_window)
        return dialog

    def _show_install_dialog(self, callback, *callback_args, save_button_enabled=True, **callback_kwargs):
        dialog = self._show_alert(
            _("Installation"), _("Do you want to add this application to the main menu?"), {
                "back": _("Back"),
                "save": _("Save"),
                "install": _("Install"),
            }, Adw.ResponseAppearance.SUGGESTED, self._on_install_dialog_response, callback, callback_args, callback_kwargs)
        dialog.set_response_enabled("save", save_button_enabled)

    def _show_discard_dialog(self, callback, *callback_args, **callback_kwargs):
        return self._show_alert(
            _("Unsaved changes"), _("Do you want to discard the changes?"), {
                "back": _("Back"),
                "save": _("Save"),
                "discard": _("Discard"),
            }, Adw.ResponseAppearance.DESTRUCTIVE, self._on_discard_dialog_response, callback, callback_args, callback_kwargs)

    def _show_reset_dialog(self, callback, *callback_args, **callback_kwargs):
        self._show_alert(
            _("Reset"), _("Do you want to reset this application? This action can not be undone"), {
                "back": _("Back"),
                "continue": _("Continue"),
            }, Adw.ResponseAppearance.DESTRUCTIVE, self._on_confirm_dialog_response, callback, callback_args, callback_kwargs)

    def _show_delete_dialog(self, callback, *callback_args, **callback_kwargs):
        self._show_alert(
            _("Delete"), _("Do you want to delete this application? This action can not be undone"), {
                "back": _("Back"),
                "continue": _("Continue"),
            }, Adw.ResponseAppearance.DESTRUCTIVE, self._on_confirm_dialog_response, callback, callback_args, callback_kwargs)

    def _update_buttons_sensitive(self):
        reset_launcher_button_sensitive = False
        delete_launcher_button_sensitive = False
        settings_page_never_hide_reload_button = False
        if not self._current_desktop_launcher_name is None:
            if self._get_desktop_launcher_can_reset(self._current_desktop_launcher_name):
                reset_launcher_button_sensitive = True
            if not self._get_desktop_launcher_has_system_default(self._current_desktop_launcher_name):
                if not self._current_desktop_launcher_name in self._unsaved_custom_launchers:
                    delete_launcher_button_sensitive = True
                else:
                    settings_page_never_hide_reload_button = True
        self._reset_launcher_button.set_sensitive(reset_launcher_button_sensitive)
        self._delete_launcher_button.set_sensitive(delete_launcher_button_sensitive)
        self._more_options_menu_button_menu.set_enabled("delete-launcher",
            delete_launcher_button_sensitive)
        if delete_launcher_button_sensitive:
            self._delete_launcher_button.add_css_class("destructive-action")
        else:
            self._delete_launcher_button.remove_css_class("destructive-action")
        self._settings_page.set_never_hide_reload_button(settings_page_never_hide_reload_button)

    def _update_button_layout(self):
        self._discard_settings_button.unparent()
        if self._main_split_layout.get_collapsed():
            self._right_area_box.set_reveal_bottom_bars(True)
            self._reset_launcher_button.set_hexpand(True)
            self._save_settings_button.set_hexpand(True)
            self._reset_launcher_button.unparent()
            self._save_settings_button.unparent()
            self._right_area_bottom_toolbar_start.append(self._reset_launcher_button)
            self._right_area_bottom_toolbar_end.append(self._save_settings_button)
            self._right_header_bar.pack_end(self._discard_settings_button)
            self._more_options_menu_button.set_visible(True)
        else:
            try:
                self._right_area_box.set_reveal_bottom_bars(False)
            except AttributeError:
                pass
            self._save_settings_button.set_hexpand(False)
            self._reset_launcher_button.set_hexpand(False)
            self._save_settings_button.unparent()
            self._reset_launcher_button.unparent()
            if self._main_stack.get_visible_child() == self._settings_page:
                if not self._save_settings_button.get_parent():
                    self._right_header_bar.pack_end(self._save_settings_button)
                if not self._reset_launcher_button.get_parent():
                    self._right_header_bar.pack_end(self._reset_launcher_button)
                self._more_options_menu_button.set_visible(True)
            else:
                self._more_options_menu_button.set_visible(False)
        if self._main_stack.get_visible_child() == self._settings_page:
            if not self._discard_settings_button.get_parent():
                self._right_header_bar.pack_start(self._discard_settings_button)
        self._update_buttons_sensitive()

    def _update_search_list_selection(self, name=None):
        if name is None:
            name = self._current_desktop_launcher_name
        if not self._search_list.get_active_item() == name:
            self._search_list.set_active_item(name)

    def _update_mime_data(self, parser, delete=False):
        operations = [{
            "section": "Added Associations",
            "path": self._mimeapps_list_path,
            "desktop-id": os.path.relpath(parser.get_save_path(),
                self._desktop_launcher_override_dir).strip(os.path.sep).replace(os.path.sep, "-")
        }]
        if os.path.abspath(parser.get_save_path()).startswith(os.path.abspath(self._desktop_launcher_override_dir)):
            operations.append({
                "section": "MIME Cache",
                "path": os.path.join(os.path.dirname(parser.get_save_path()), "mimeinfo.cache"),
                "desktop-id": os.path.basename(parser.get_save_path())
            })
        for operation in operations:
            section = operation["section"]
            path = operation["path"]
            desktop_id = operation["desktop-id"]
            mime_parser = ConfigParser(interpolation=None, strict=False)
            mime_parser.optionxform = str
            if not mime_parser.has_section(section):
                mime_parser.add_section(section)
            mimeinfo_changed = False
            if os.path.exists(path) and os.path.isdir(path) and not len(os.listdir(path)):
                os.rmdir(path)
            if not os.path.exists(path):
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, "w", encoding="utf-8") as file:
                    pass
            if os.access(path, os.R_OK):
                with open(path, "r", encoding="utf-8") as file:
                    mime_parser.read_file(file)
                app_mimetypes = parser.get_mimetypes()
                mime_data_dict = dict(mime_parser.items(section))
                for mime_data_mimetype in mime_data_dict:
                    mime_data_names = list(filter(None, mime_data_dict[mime_data_mimetype].split(";")))
                    if desktop_id in mime_data_names and (not mime_data_mimetype in app_mimetypes or delete):
                        mime_data_names.remove(desktop_id)
                        if len(mime_data_names):
                            mime_parser.set(section, mime_data_mimetype, f"{';'.join(mime_data_names)};")
                        else:
                            mime_parser.remove_option(section, mime_data_mimetype)
                        mimeinfo_changed = True
                if not delete:
                    for app_mimetype in app_mimetypes:
                        if not app_mimetype in mime_data_dict:
                            mime_parser.set(section, app_mimetype, f"{desktop_id};")
                            mimeinfo_changed = True
                        elif not desktop_id in mime_data_dict[app_mimetype]:
                            mime_data_names = list(filter(None, mime_data_dict[app_mimetype].split(";")))
                            mime_data_names.append(desktop_id)
                            mime_parser.set(section, app_mimetype, f"{';'.join(mime_data_names)};")
                            mimeinfo_changed = True
                if mimeinfo_changed:
                    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
                    if os.path.exists(path) and not os.access(path, os.W_OK) and os.access(os.path.dirname(path), os.W_OK):
                        os.remove(path)
                    with open(path, "w", encoding="utf-8") as file:
                        mime_parser.write(file, space_around_delimiters=False)
            else:
                raise PermissionError(f"path not readable: {path}")

    def _load_settings_page(self, name):
        self._focus_settings_page()
        if name in self._unsaved_custom_launchers and self._unsaved_custom_launchers[name]["external"]:
            self._settings_page.set_always_show_save_button(True)
        else:
            self._settings_page.set_always_show_save_button(False)
        self._current_desktop_launcher_name = name
        parser = self._desktop_launcher_parsers[name]
        try:
            if not self._get_can_save_external_launcher(name):
                self.notify(_("Editing this launcher requires elevated permissions"))
        except StarterNotExternalError:
            pass
        self._settings_page.load_desktop_launcher(name, parser)
        if not self._main_stack.get_visible_child() == self._settings_page:
            self._main_stack.set_visible_child(self._settings_page)
        else:
            self._update_button_layout()
        self._update_search_list_selection()
        if not self._settings_page.get_vadjustment().get_value():
            self._settings_page.grab_focus()
        self._create_custom_launcher_backups(name)
        self._update_update_banner()

    def _save_settings_page(self, skip_dialog=False):
        parser = self._desktop_launcher_parsers[self._current_desktop_launcher_name]
        if (
            self._current_desktop_launcher_name in self._unsaved_custom_launchers
            and self._unsaved_custom_launchers[self._current_desktop_launcher_name]["external"]
            and not skip_dialog
        ):
            name = self._current_desktop_launcher_name
            try:
                dialog_save_button_enabled = (
                    not (name == self._current_desktop_launcher_name and not self._settings_page.get_changed())
                    and self._get_can_save_external_launcher(name)
                )
            except StarterNotExternalError:
                dialog_save_button_enabled = True
            self._show_install_dialog(self._install_external_launcher, self._current_desktop_launcher_name,
                save_button_enabled=dialog_save_button_enabled)
            return True
        else:
            try:
                parser.check_write()
                self.record(parser.get_name() or self._current_desktop_launcher_name, [parser.get_save_path()])
                self._settings_page.save_desktop_launcher()
                if (
                    not self._current_desktop_launcher_name in self._unsaved_custom_launchers
                    or not self._unsaved_custom_launchers[self._current_desktop_launcher_name]["external"]
                ):
                    self._settings_page.set_always_show_save_button(False)
                    try:
                        self._update_mime_data(parser)
                    except Exception as error:
                        self.log(error, error=error)
                if self._current_desktop_launcher_name in self._text_editor.get_names():
                    parser.save(path=self._text_editor.get_path(self._current_desktop_launcher_name))
            except Exception as error:
                self.log(error, error=error)
                self.notify(_("Failed to save configurations"), error=error)
                return True
            else:
                self._create_custom_launcher_backups(self._current_desktop_launcher_name)
                if (
                    self._current_desktop_launcher_name in self._unsaved_custom_launchers
                    and not self._unsaved_custom_launchers[self._current_desktop_launcher_name]["external"]
                ):
                    self._newly_created_launchers.append(self._current_desktop_launcher_name)
                    del self._unsaved_custom_launchers[self._current_desktop_launcher_name]
                text = parser.get_name()
                if not len(text):
                    text = _("Unnamed Application")
                self.notify_undoable(_("Configurations for '%s' have been saved") % text)
                self._update_search_list_item(self._current_desktop_launcher_name)
                self._update_button_layout()

    def _get_random_unused_desktop_launcher_name(self):
        while True:
            now = datetime.datetime.now()
            timestamp = f"{now.year}{now.month}{now.day}{now.hour}{now.minute}{now.second}{now.microsecond}"
            name = "%s.%s" % (self._desktop_launcher_custom_create_name, timestamp)
            if not name in self._get_desktop_launcher_names() and not name in self._unsaved_custom_launchers:
                return name

    def _install_external_launcher(self, name):
        parser = self._desktop_launcher_parsers[name]
        save_path = self._get_desktop_launcher_override_path(name)
        parser.set_save_path(save_path)

    def _load_external_launchers(self, *paths, skip_discard_dialog=False):
        exceptions = {}
        filtered_paths = []
        duplicate_names = []
        accepted_names = []
        for path in paths:
            path = os.path.abspath(path)
            if not path in filtered_paths:
                filtered_paths.append(path)
        else:
            paths = filtered_paths
        for name, data in self._unsaved_custom_launchers.items():
            if data["external"] and data["load-path"] in paths:
                paths.remove(data["load-path"])
                duplicate_names.append(name)
        else:
            if not len(paths):
                if len(duplicate_names):
                    name = duplicate_names[0]
                    if not skip_discard_dialog:
                        self._check_unsaved_data(self._load_settings_page, name, ignore_name=name)
                    else:
                        self._load_settings_page(name)
            else:
                for path in reversed(paths):
                    if os.path.exists(path) and os.path.isfile(path) and os.access(path, os.R_OK):
                        name = self._get_random_unused_desktop_launcher_name()
                        self._unsaved_custom_launchers[name] = {
                            "load-path": path,
                            "save-path": path,
                            "external": True
                        }
                        try:
                            self._add_desktop_launcher(name)
                            accepted_names.append(name)
                        except Exception as error:
                            exceptions[path] = (name, error, path)
                    else:
                        exceptions[path] = None, None, path
                else:
                    if len(exceptions):
                        for name, error, path in exceptions.values():
                            if not name is None:
                                self.log(error, error=error)
                                del self._unsaved_custom_launchers[name]
                            else:
                                self.log(f"not readable file: {path}")
                        if len(exceptions) == 1:
                            self.notify(
                                _("Failed to load file '%s'")
                                    % os.path.basename(list(exceptions.keys())[0]),
                                error=True
                            )
                        else:
                            self.notify(
                                _("Failed to load %s files") % str(len(exceptions)),
                                error=True
                            )
                if len(accepted_names):
                    name = accepted_names[0]
                    if not skip_discard_dialog:
                        self._check_unsaved_data(self._load_settings_page, name, ignore_name=name)
                    else:
                        self._load_settings_page(name)

    def _duplicate_desktop_launcher(self, old_name):
        old_parser = self._desktop_launcher_parsers[old_name]
        old_load_path = old_parser.get_load_path()
        name = self._get_random_unused_desktop_launcher_name()
        self._unsaved_custom_launchers[name] = {
            "load-path": old_load_path,
            "save-path": self._get_desktop_launcher_override_path(name),
            "external": False
        }
        parser = self._add_desktop_launcher(name)
        app_name = parser.get_name()
        if app_name.endswith(")"):
            try:
                text_before_bracket, text_after_bracket = app_name.split("(")
                int(text_after_bracket[:-1])
            except (TypeError, ValueError):
                base_app_name = app_name
            else:
                base_app_name = text_before_bracket.rstrip()
        else:
            base_app_name = app_name
        app_names = [parser.get_name() for parser in self._desktop_launcher_parsers.values()]
        suffix_num = 1
        while True:
            new_app_name = f"{base_app_name} ({suffix_num})"
            if not new_app_name in app_names:
                parser.set_name(new_app_name)
                self._update_search_list_item(name)
                break
            else:
                suffix_num += 1
        parser.save()
        parser.set_load_path(parser.get_save_path())
        del self._unsaved_custom_launchers[name]
        text = parser.get_name()
        if not len(text):
            text = _("Unnamed Application")
        self.notify(_("Launcher for '%s' has been created") % text)
        self._search_list.set_active_item(self._current_desktop_launcher_name, activate=False)
        self._load_settings_page(name)
        return name

    def _create_desktop_launcher(self):
        if (
            self._current_desktop_launcher_name in self._unsaved_custom_launchers
            and not self._unsaved_custom_launchers[self._current_desktop_launcher_name]["external"]
        ):
            self._search_list.set_active_item(self._current_desktop_launcher_name, activate=False)
            self._focus_settings_page()
        else:
            for name in self._unsaved_custom_launchers:
                if not self._unsaved_custom_launchers[name]["external"]:
                    self._search_list.set_active_item(name, activate=False)
                    self._load_settings_page(name)
                    break
            else:
                name = self._get_random_unused_desktop_launcher_name()
                self._unsaved_custom_launchers[name] = {
                    "load-path": self._desktop_launcher_template_path,
                    "save-path": self._get_desktop_launcher_override_path(name),
                    "external": False
                }
                self._add_desktop_launcher(name)
                parser = self._desktop_launcher_parsers[name]
                text = parser.get_name()
                if not len(text):
                    text = _("Unnamed Application")
                self.notify(_("Launcher for '%s' has been created") % text)
                self._search_list.set_active_item(self._current_desktop_launcher_name, activate=False)
                self._load_settings_page(name)

    def _reset_desktop_launcher(self, name):
        path = self._get_desktop_launcher_override_path(name)
        parser = self._desktop_launcher_parsers[name]
        reset_failed = False
        if self._get_desktop_launcher_has_system_default(name):
            try:
                os.remove(path)
            except Exception as error:
                self.log(error, error=error)
                self.notify(_("Failed to reset launcher"), error=error)
                reset_failed = True
        else:
            try:
                self._restore_custom_launcher_backups(name)
            except Exception as error:
                self.log(error, error=error)
                self.notify(_("Failed to reset launcher"), error=error)
                reset_failed = True
        if not reset_failed:
            text = parser.get_name()
            if not len(text):
                text = _("Unnamed Application")
            self.notify(_("Launcher for '%s' has been reset") % text)
            self._update_desktop_launcher(name, skip_settings_page=True)
            try:
                self._update_mime_data(parser)
            except Exception as error:
                self.log(error, error=error)
            if name == self._current_desktop_launcher_name:
                self._load_settings_page(name)

    def _delete_desktop_launcher(self, name):
        path = self._desktop_launcher_parsers[name].get_save_path()
        parser = self._desktop_launcher_parsers[name]
        try:
            os.remove(path)
        except Exception as error:
            self.log(error, error=error)
            self.notify(_("Failed to delete launcher"), error=error)
        else:
            text = parser.get_name()
            if not len(text):
                text = _("Unnamed Application")
            self.notify(_("Launcher for '%s' has been deleted") % text)
            del self._latest_launcher_mtimes[name]
            self._remove_orphaned_launcher_backups(name)
            self._remove_desktop_launcher(name)
            try:
                self._update_mime_data(parser, delete=True)
            except Exception as error:
                self.log(error, error=error)

    def _edit_desktop_launcher(self, name):
        parser = self._desktop_launcher_parsers[name]
        try:
            self._text_editor.launch(name, parser)
        except Exception as error:
            self.log(error, error=error)
            self.notify(_("Failed to open configurations"), error=error)

    def _get_parser_should_be_shown(self, parser):
        if not self._config_manager.get("show.hidden"):
            if not parser.get_visible():
                return
            else:
                only_show_in_values = set(filter(None, parser.get_only_show_in().split(";")))
                not_show_in_values = set(filter(None, parser.get_not_show_in().split(";")))
                if only_show_in_values and not only_show_in_values.intersection(self._xdg_current_desktop_values):
                    return
                elif not_show_in_values and not_show_in_values.intersection(self._xdg_current_desktop_values):
                    return
                else:
                    return True
        else:
            return True

    def _add_search_list_item(self, name):
        if not self._get_parser_should_be_shown(self._desktop_launcher_parsers[name]):
            return True
        text = self._desktop_launcher_parsers[name].get_name()
        icon = self._desktop_launcher_parsers[name].get_icon()
        search_data = self._desktop_launcher_parsers[name].get_search_data()
        if not len(text):
            text = _("Unnamed Application")
            search_data.append(text)
        self._search_list.add(name, text, icon, search_data)

    def _remove_search_list_item(self, name):
        try:
            self._search_list.remove(name)
        except ItemNotFoundError:
            pass
        if name == self._current_desktop_launcher_name:
            self._main_stack.set_visible_child(self._start_page)
            self._search_list.set_active_item(self._current_desktop_launcher_name, activate=False)

    def _update_search_list_item(self, name):
        parser = self._desktop_launcher_parsers[name]
        if not self._get_parser_should_be_shown(parser):
            self._remove_search_list_item(name)
        else:
            text = parser.get_name()
            icon = parser.get_icon()
            search_data = parser.get_search_data()
            if not len(text):
                text = _("Unnamed Application")
                search_data.append(text)
            try:
                self._search_list.update(name, text, icon, search_data)
            except ItemNotFoundError:
                self._search_list.add(name, text, icon, search_data)

    def _reload_search_list_items(self):
        self._search_list.clear()
        for name in self._desktop_launcher_parsers:
            self._add_search_list_item(name)
        if not self._current_desktop_launcher_name in self._search_list.list():
            self._main_stack.set_visible_child(self._start_page)
            self._search_list.set_active_item(self._current_desktop_launcher_name, activate=False)
        else:
            self._search_list.set_active_item(self._current_desktop_launcher_name, activate=False)

    def _check_desktop_launcher_mtimes(self):
        mtimes = {}
        names = self._get_desktop_launcher_names()
        for name in names:
            full_path = names[name]
            try:
                mtimes[name] = os.path.getmtime(full_path)
            except FileNotFoundError:
                pass
        if not self._latest_launcher_mtimes is None:
            all_names = mtimes.keys() | self._latest_launcher_mtimes.keys()
            for name in all_names:
                try:
                    old_mtime = self._latest_launcher_mtimes[name]
                except KeyError:
                    self.log(f"created externally: {name}")
                    if not name in self._desktop_launcher_parsers:
                        self._add_desktop_launcher(name)
                    elif name in self._unsaved_custom_launchers:
                        del self._unsaved_custom_launchers[name]
                        self._update_desktop_launcher(name)
                    continue
                try:
                    new_mtime = mtimes[name]
                except KeyError:
                    self.log(f"deleted externally: {name}")
                    if not name == self._current_desktop_launcher_name:
                        if name in self._desktop_launcher_parsers:
                            self._remove_desktop_launcher(name)
                    elif not name in self._unsaved_custom_launchers:
                        self._unsaved_custom_launchers[name] = {
                            "load-path": self._desktop_launcher_template_path,
                            "save-path": self._get_desktop_launcher_override_path(name),
                            "external": False
                            }
                        self._update_desktop_launcher(name)
                    continue
                if not old_mtime == new_mtime:
                    self.log(f"changed externally: {name}")
                    self._update_desktop_launcher(name)
        self._update_buttons_sensitive()
        self._latest_launcher_mtimes = mtimes
        return True

    def _update_desktop_launcher(self, name, skip_settings_page=False):
        if name in self._desktop_launcher_parsers:
            parser = self._parse_desktop_launcher(name)
            self._desktop_launcher_parsers[name] = parser
            self._update_search_list_item(name)
            save_path = parser.get_save_path()
            load_path = parser.get_load_path()
            if os.path.exists(save_path):
                self._latest_launcher_mtimes[name] = os.path.getmtime(save_path)
            else:
                self._latest_launcher_mtimes[name] = os.path.getmtime(load_path)
            if name == self._current_desktop_launcher_name and not skip_settings_page:
                self._settings_page.load_desktop_launcher(name, parser, update_widgets=False)
        else:
            raise StarterNotFoundError(name)

    def _add_desktop_launcher(self, name):
        if not name in self._desktop_launcher_parsers:
            parser = self._parse_desktop_launcher(name)
            self._desktop_launcher_parsers[name] = parser
            self._add_search_list_item(name)
            return parser
        else:
            raise StarterAlreadyExistingError(name)

    def _remove_desktop_launcher(self, name, notify_user=False):
        text = self._desktop_launcher_parsers[name].get_name()
        if name is self._current_desktop_launcher_name:
            self._settings_page.reset()
        if name in self._unsaved_custom_launchers:
            del self._unsaved_custom_launchers[name]
        if name in self._desktop_launcher_parsers:
            del self._desktop_launcher_parsers[name]
            if self._search_list.get_search_mode():
                items = self._search_list.get_visible_items()
                try:
                    next_index = items.index(name) + 1
                    if not next_index < len(items):
                        next_index = items.index(name) - 1
                except ValueError:
                    next_index = - 1
                try:
                    next_item = items[next_index]
                except IndexError:
                    pass
                else:
                    if not next_item == name:
                        self._load_settings_page(next_item)
                    elif self._search_list.get_search_mode():
                        self._search_list.set_search_mode(False)
            self._remove_search_list_item(name)
        else:
            raise StarterNotFoundError(name)
        if notify_user:
            if not len(text):
                text = _("Unnamed Application")
            self.notify(_("Launcher for '%s' has been removed") % text)

    def _parse_desktop_launcher(self, name):
        if name in self._unsaved_custom_launchers:
            load_path = self._unsaved_custom_launchers[name]["load-path"]
        else:
            load_path = self._get_desktop_launcher_override_path(name)
        if name in self._unsaved_custom_launchers:
            save_path = self._unsaved_custom_launchers[name]["save-path"]
        else:
            save_path = self._get_desktop_launcher_override_path(name)
        if not os.path.exists(load_path):
            default_path = self._get_desktop_launcher_default_path(name)
            if os.path.exists(default_path):
                load_path = default_path
            else:
                raise StarterNotFoundError(name)
        parser = DesktopParser(self, load_path, save_path)
        parser.set_save_callback(self._on_parser_saved, (name, parser))
        return parser

    def record(self, label, files=(), folders=()):
        self._history.record(label, files, folders)
        self._backup_menu_section.set_enabled("undo", True)

    def notify_undoable(self, text):
        toast = Adw.Toast(title=text, button_label=_("Undo"), timeout=Timeout.DEFAULT, use_markup=False)
        toast.connect("button-clicked", self._on_undo_clicked)
        self._toast_overlay.add_toast(toast)

    def _on_undo_clicked(self, *args):
        try:
            label = self._history.undo()
        except (OSError, GLib.GError) as error:
            self.notify(str(error), error=error)
            return
        self._icon_store.refresh()
        self._folders_page.reload()
        self._check_desktop_launcher_mtimes()
        if self._current_desktop_launcher_name in self._desktop_launcher_parsers:
            self._update_desktop_launcher(self._current_desktop_launcher_name)
            self._settings_page.load_desktop_launcher(
                self._current_desktop_launcher_name, self._desktop_launcher_parsers[self._current_desktop_launcher_name])
        self._backup_menu_section.set_enabled("undo", self._history.last_label() is not None)
        self.mark_unexported()
        self.notify(_("Undone: %s") % label)

    def launcher_outdated(self, name):
        return launcher_updates.is_outdated(
            name, self._get_desktop_launcher_default_path(name), self._get_desktop_launcher_override_path(name))

    def _update_update_banner(self):
        name = self._current_desktop_launcher_name
        self._update_banner.set_revealed(name in self._desktop_launcher_parsers and self.launcher_outdated(name))

    def _on_update_banner_clicked(self, banner):
        name = self._current_desktop_launcher_name
        changes = launcher_updates.package_changes(
            name, self._get_desktop_launcher_default_path(name), self._get_desktop_launcher_override_path(name))
        lines = []
        for (section, key), old, new, kept in changes:
            label = key if section == "Desktop Entry" else f"{section.removeprefix('Desktop Action ')} › {key}"
            line = f"• {label} : {old or '∅'} → {new or '∅'}"
            lines.append(line + (f" ({_('your value is kept')})" if kept else ""))
        dialog = Adw.AlertDialog(heading=_("Changes made by the package"), body="\n".join(lines))
        dialog.add_response("cancel", _("Cancel"))
        dialog.add_response("ignore", _("Keep my version"))
        dialog.add_response("merge", _("Take the update"))
        dialog.set_response_appearance("merge", Adw.ResponseAppearance.SUGGESTED)
        dialog.set_close_response("cancel")
        dialog.connect("response", self._on_update_response, name)
        dialog.present(self._application_window)

    def _on_update_response(self, dialog, response, name):
        if response == "cancel":
            return
        default_path = self._get_desktop_launcher_default_path(name)
        override_path = self._get_desktop_launcher_override_path(name)
        self.record(self._desktop_launcher_parsers[name].get_name() or name,
                    [override_path, launcher_updates.origin_path(name)])
        try:
            if response == "merge":
                launcher_updates.merge(name, default_path, override_path)
            else:
                launcher_updates.accept(name, default_path)
        except (OSError, configparser.Error) as error:
            self.notify(str(error), error=error)
            return
        self._update_desktop_launcher(name)
        self._update_search_list_item(name)
        self._update_update_banner()
        self.mark_unexported()
        self.notify_undoable(_("Launcher updated") if response == "merge" else _("Your version is kept"))

    def _launcher_items(self):
        return sorted(((name, self._desktop_launcher_parsers[name].get_name() or name,
                        self._desktop_launcher_parsers[name].get_icon()) for name in self._search_list.list()),
                      key=lambda item: item[1].lower())

    def _on_export_icons_clicked(self, event):
        IconsExportDialog(self, self._launcher_items()).present(self._application_window)

    def _on_export_current_icon_clicked(self, event):
        IconsExportDialog(self, self._launcher_items(), only=self._current_desktop_launcher_name).present(
            self._application_window)

    def _on_import_icons_clicked(self, event):
        zip_filter = Gtk.FileFilter(name=_("ZIP archives"))
        zip_filter.add_pattern("*.zip")
        filters = Gio.ListStore.new(Gtk.FileFilter)
        filters.append(zip_filter)
        Gtk.FileDialog(modal=True, filters=filters).open(self._application_window, None, self._on_import_icons_chosen)

    def _on_import_icons_chosen(self, dialog, result):
        try:
            path = dialog.open_finish(result).get_path()
        except GLib.GError:
            return
        try:
            names = icon_batch.names_in(path)
        except zipfile.BadZipFile:
            self.notify(_("This file is not a ZIP archive"))
            return
        launchers = [name for name in names if name in self._desktop_launcher_parsers
                     and self._desktop_launcher_parsers[name].get_icon() != name]
        files = [file for name in names for file in icon_files(name)]
        files += [self._desktop_launcher_parsers[name].get_save_path() for name in launchers]
        self.record(_("import of %d icons") % len(names), files)
        try:
            icon_batch.import_icons(path, self._icon_store)
            for name in launchers:
                parser = self._desktop_launcher_parsers[name]
                parser.set_icon(name)
                parser.save()
                self._update_desktop_launcher(name)
        except (OSError, GLib.GError) as error:
            self.notify(str(error), error=error)
            return
        self.mark_unexported()
        self.notify_undoable(_("%d icons imported") % len(names))

    def _on_orphans_clicked(self, event):
        orphans = [name for name, parser in self._desktop_launcher_parsers.items()
                   if name not in self._unsaved_custom_launchers and not parser.get_hidden() and parser.get_command()
                   and not self.get_command_exists(parser.get_command(), desktop_entry=True, include_lookup_cwd=True)]
        OrphansDialog(self, orphans).present(self._application_window)

    def hide_launcher(self, name):
        parser = self._desktop_launcher_parsers[name]
        self.record(parser.get_name() or name, [parser.get_save_path()])
        parser.set_hidden(True)
        parser.save()
        self._update_desktop_launcher(name)
        self.mark_unexported()

    def delete_launcher(self, name):
        self.record(self._desktop_launcher_parsers[name].get_name() or name,
                    [self._desktop_launcher_parsers[name].get_save_path()])
        self._delete_desktop_launcher(name)
        self.mark_unexported()

    def launcher_has_system_default(self, name):
        return self._get_desktop_launcher_has_system_default(name)

    def get_launcher_parser(self, name):
        return self._desktop_launcher_parsers[name]

    def _menu_button_with_dot(self, button):
        dot = Gtk.Box(halign=Gtk.Align.END, valign=Gtk.Align.START, can_target=False,
                      visible=self._config_manager.get("export.pending"), tooltip_text=_("Changes not exported yet"))
        dot.add_css_class("export-dot")
        self._export_dots.append(dot)
        overlay = Gtk.Overlay(child=button)
        overlay.add_overlay(dot)
        return overlay

    def _set_export_pending(self, pending):
        self._config_manager.set("export.pending", pending)
        self._config_manager.save()
        for dot in self._export_dots:
            dot.set_visible(pending)

    def mark_unexported(self):
        self._set_export_pending(True)

    def _on_export_backup_clicked(self, event):
        name = f"iconostase-{datetime.date.today().isoformat()}.tar.gz"
        Gtk.FileDialog(modal=True, initial_name=name).save(self._application_window, None, self._on_export_backup_chosen)

    def _on_export_backup_chosen(self, dialog, result):
        try:
            path = dialog.save_finish(result).get_path()
        except GLib.GError:
            return
        try:
            manifest = backup.export(path)
        except OSError as error:
            self.notify(str(error), error=error)
            return
        self._set_export_pending(False)
        self.notify(_("Backup exported: %(icons)d icons, %(launchers)d launchers, %(folders)d folders") % {
            "icons": manifest["icones"], "launchers": manifest["lanceurs"], "folders": manifest["dossiers"]})

    def _on_import_backup_clicked(self, event):
        archive_filter = Gtk.FileFilter(name=_("Iconostase backups"))
        archive_filter.add_pattern("*.tar.gz")
        filters = Gio.ListStore.new(Gtk.FileFilter)
        filters.append(archive_filter)
        Gtk.FileDialog(modal=True, filters=filters).open(self._application_window, None, self._on_import_backup_chosen)

    def _on_import_backup_chosen(self, dialog, result):
        try:
            path = dialog.open_finish(result).get_path()
        except GLib.GError:
            return
        try:
            manifest = backup.read_manifest(path)
        except backup.InvalidBackupError:
            self.notify(_("This file is not an Iconostase backup"))
            return
        body = _("%(icons)d icons, %(launchers)d launchers and %(folders)d folder icons from %(date)s. "
                 "Files with the same name will be replaced.") % {
            "icons": manifest["icones"], "launchers": manifest["lanceurs"],
            "folders": manifest["dossiers"], "date": manifest["date"][:10]}
        if manifest["masques"]:
            body += "\n" + _("Hidden folders: %s") % ", ".join(manifest["masques"])
        alert = Adw.AlertDialog(heading=_("Restore this backup?"), body=body)
        alert.add_response("back", _("Cancel"))
        alert.add_response("restore", _("Restore"))
        alert.set_response_appearance("restore", Adw.ResponseAppearance.SUGGESTED)
        alert.set_close_response("back")
        alert.connect("response", self._on_restore_response, path)
        alert.present(self._application_window)

    def _on_restore_response(self, alert, response, path):
        if response != "restore":
            return
        try:
            missing = backup.restore(path, self._icon_store)
        except (OSError, GLib.GError) as error:
            self.notify(str(error), error=error)
            return
        self._folders_page.reload()
        self._check_desktop_launcher_mtimes()
        self._reload_search_list_items()
        self._set_export_pending(False)
        if missing:
            self.notify(_("Restored. Left as is: %s") % ", ".join(missing))
        else:
            self.notify(_("Backup restored"))

    def notify(self, text, error=False):
        toast = Adw.Toast.new(text)
        toast.set_use_markup(False)
        if not error:
            toast.set_timeout(Timeout.DEFAULT)
        else:
            if isinstance(error, NoAccessError):
                toast.set_title(_("Editing this launcher requires elevated permissions"))
            toast.set_timeout(0)
            toast.set_action_name("toast.details")
            toast.set_button_label(_("Help"))
        self._toast_overlay.add_toast(toast)

    def log(self, text, error=None):
        self._debug_log.add(text, error=error)
