# SPDX-License-Identifier: GPL-3.0-or-later
# D'après libre-menu-editor (© 2022 Free Software Foundation).
import os
import shutil

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import GLib, Gio, Gtk  # noqa: E402

from .core.events import EventManager
from .core.path_inspector import PathInspector


class DefaultTextEditor():
    def __init__(self, app):
        self._application = app
        app.connect("shutdown", self._on_application_shutdown)
        self._events = EventManager()
        self._events.add("update", str)
        self._parsers = {}
        self._edit_dir = os.path.join(app.get_cache_dir(), "text-editor-links")
        self._path_inspector = PathInspector()
        self._path_inspector.hook("changed", self._on_path_inspector_changed)
        self._path_inspector.hook("created", self._on_path_inspector_created)
        self._path_inspector.hook("deleted", self._on_path_inspector_deleted)

    def _on_application_shutdown(self, app):
        self.exit()

    def _on_path_inspector_changed(self, event, edit_path, timestamp):
        name = self._get_name_from_edit_path(edit_path)
        GLib.idle_add(self._trigger_update_event, name)

    def _on_path_inspector_created(self, event, edit_path, timestamp):
        name = self._get_name_from_edit_path(edit_path)
        GLib.idle_add(self._trigger_update_event, name)

    def _on_path_inspector_deleted(self, event, edit_path, timestamp):
        GLib.idle_add(self._path_inspector.remove, edit_path)
        name = self._get_name_from_edit_path(edit_path)
        del self._original_paths[name]

    def _get_name_from_edit_path(self, edit_path):
        return os.path.relpath(edit_path, self._edit_dir)[:-len(".ini")].strip(os.path.sep)

    def _get_files_identical(self, first, second):
        if os.path.exists(first) and os.path.exists(second):
            with open(first, "r", encoding="utf-8") as first_file:
                with open(second, "r", encoding="utf-8") as second_file:
                    if first_file.read().replace("\n\n", "\n") == second_file.read().replace("\n\n", "\n"):
                        return True

    def _get_copy_source_path(self, parser):
        if os.path.exists(parser.get_save_path()):
            return parser.get_save_path()
        else:
            return parser.get_load_path()

    def _trigger_update_event(self, name):
        parser = self._parsers[name]["parser"]
        edit_path = self._parsers[name]["edit-path"]
        if not self._get_files_identical(parser.get_save_path(), edit_path):
            self._events.trigger("update", name)

    def get_path(self, name):
        return self._parsers[name]["edit-path"]

    def get_names(self):
        return list(self._parsers.keys())

    def get_parser(self, name):
        return self._parsers[name]["parser"]

    def launch(self, name, parser):
        full_path = os.path.join(self._edit_dir, name)
        if not os.path.exists(os.path.dirname(full_path)):
            os.makedirs(os.path.dirname(full_path), exist_ok=True)
        edit_path = os.path.join(f"{full_path}.ini")
        self._parsers[name] = {
            "parser": parser,
            "edit-path": edit_path
        }
        source_path = self._get_copy_source_path(parser)
        if not self._get_files_identical(source_path, edit_path):
            if os.path.exists(edit_path):
                os.remove(edit_path)
            shutil.copy(source_path, edit_path)
        if not edit_path in self._path_inspector.get_paths():
            self._path_inspector.add(edit_path)
        Gtk.FileLauncher.new(Gio.File.new_for_path(edit_path)).launch(
            self._application.get_application_window(), None, None)

    def save(self, name):
        parser = self._parsers[name]["parser"]
        edit_path = self._parsers[name]["edit-path"]
        parser.check_write()
        parser.load(path=edit_path)
        parser.save()

    def exit(self):
        for path in self._path_inspector.get_paths():
            self._path_inspector.remove(path)
        self._path_inspector.set_active(False)
        for name in self._parsers:
            edit_path = self._parsers[name]["edit-path"]
            if os.path.abspath(edit_path).startswith(os.path.abspath(self._edit_dir)):
                os.remove(os.path.join(edit_path))
        else:
            for dirpath, dirnames, filenames in os.walk(self._edit_dir, topdown=False):
                for dirname in dirnames:
                    try:
                        os.rmdir(os.path.join(dirpath, dirname))
                    except OSError as error:
                        self._application.log(error, error=error)
            else:
                if os.path.exists(self._edit_dir) and not len(os.listdir(self._edit_dir)):
                    os.rmdir(self._edit_dir)

    def hook(self, event, callback):
        return self._events.hook(event, callback)

    def release(self, id):
        self._events.release(id)
