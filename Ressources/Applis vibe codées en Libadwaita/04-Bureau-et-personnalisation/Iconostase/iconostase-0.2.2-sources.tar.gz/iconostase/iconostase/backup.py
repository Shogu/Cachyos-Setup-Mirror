# SPDX-License-Identifier: GPL-3.0-or-later
import datetime
import io
import json
import os
import shutil
import tarfile
import tempfile

from gi.repository import GLib

from . import VERSION
from .folder_icons import ICONS_DIR, PLAN_PATH, FolderPlan
from .icon_store import COLLECTION

LAUNCHERS_DIR = os.path.join(GLib.get_user_data_dir(), "applications")
MANIFEST = "manifeste.json"
HOME_PREFIX = "maison"
IMAGE_SUFFIXES = (".svg", ".svgz", ".png", ".xpm", ".ico")
ICON_TREES = (
    os.path.join(GLib.get_user_data_dir(), "icons"),
    os.path.join(GLib.get_user_data_dir(), "pixmaps"),
    os.path.join(GLib.get_home_dir(), ".icons"),
    COLLECTION,
)


class InvalidBackupError(Exception):
    pass


def _files(directory, suffixes):
    if not os.path.isdir(directory):
        return []
    return sorted(name for name in os.listdir(directory)
                  if name.endswith(suffixes) and os.path.isfile(os.path.join(directory, name)))


def _launcher_icon_paths():
    home = GLib.get_home_dir()
    for name in _files(LAUNCHERS_DIR, (".desktop",)):
        with open(os.path.join(LAUNCHERS_DIR, name), encoding="utf-8", errors="replace") as file:
            for line in file:
                if line.startswith("Icon="):
                    icon = os.path.expanduser(line[len("Icon="):].strip())
                    if icon.startswith(home + os.sep) and os.path.isfile(icon):
                        yield icon


def home_icons():
    home = GLib.get_home_dir()
    files = {}
    for tree in ICON_TREES:
        if not os.path.isdir(tree) or os.path.islink(tree):
            continue
        for root, dirs, names in os.walk(tree):
            dirs[:] = [name for name in dirs if not os.path.islink(os.path.join(root, name))]
            for name in names:
                if name.lower().endswith(IMAGE_SUFFIXES) or name == "index.theme":
                    path = os.path.join(root, name)
                    files[os.path.relpath(path, home)] = os.path.realpath(path)
    for icon in _launcher_icon_paths():
        files.setdefault(os.path.relpath(icon, home), icon)
    return dict(sorted(files.items()))


def export(path):
    icons = home_icons()
    launchers = _files(LAUNCHERS_DIR, (".desktop",))
    folder_icons = _files(ICONS_DIR, (".svg", ".png"))
    plan = FolderPlan()
    manifest = {
        "version": VERSION,
        "date": datetime.datetime.now().isoformat(timespec="seconds"),
        "icones": len([name for name in icons if name.lower().endswith(IMAGE_SUFFIXES)]),
        "lanceurs": len(launchers),
        "dossiers": len([folder for folder in plan.folders if folder["icone"]]),
        "masques": plan.hidden,
    }
    with tarfile.open(path, "w:gz") as archive:
        data = json.dumps(manifest, ensure_ascii=False, indent=1).encode()
        info = tarfile.TarInfo(MANIFEST)
        info.size = len(data)
        archive.addfile(info, io.BytesIO(data))
        for relative_path, source in icons.items():
            archive.add(source, f"{HOME_PREFIX}/{relative_path}")
        for name in launchers:
            archive.add(os.path.join(LAUNCHERS_DIR, name), f"lanceurs/{name}")
        for name in folder_icons:
            archive.add(os.path.join(ICONS_DIR, name), f"dossiers/{name}")
        if os.path.isfile(PLAN_PATH):
            archive.add(PLAN_PATH, "dossiers.json")
    return manifest


def read_manifest(path):
    try:
        with tarfile.open(path, "r:gz") as archive:
            return json.load(archive.extractfile(MANIFEST))
    except (tarfile.TarError, KeyError, ValueError) as error:
        raise InvalidBackupError(path) from error


def restore(path, icon_store):
    with tempfile.TemporaryDirectory() as temp, tarfile.open(path, "r:gz") as archive:
        archive.extractall(temp, filter="data")
        saved_home = os.path.join(temp, HOME_PREFIX)
        for root, dirs, names in os.walk(saved_home):
            for name in names:
                target = os.path.join(GLib.get_home_dir(), os.path.relpath(os.path.join(root, name), saved_home))
                os.makedirs(os.path.dirname(target), exist_ok=True)
                shutil.copyfile(os.path.join(root, name), target)
        for name in _files(os.path.join(temp, "icones"), (".svg", ".png")):
            source = os.path.join(temp, "icones", name)
            stem = os.path.splitext(name)[0]
            if stem.endswith("-symbolic"):
                icon_store.install_symbolic(stem[:-len("-symbolic")], source)
            else:
                icon_store.install_color(stem, source)
        icon_store.refresh()
        os.makedirs(LAUNCHERS_DIR, exist_ok=True)
        for name in _files(os.path.join(temp, "lanceurs"), (".desktop",)):
            shutil.copyfile(os.path.join(temp, "lanceurs", name), os.path.join(LAUNCHERS_DIR, name))
        os.makedirs(ICONS_DIR, exist_ok=True)
        for name in _files(os.path.join(temp, "dossiers"), (".svg", ".png")):
            shutil.copyfile(os.path.join(temp, "dossiers", name), os.path.join(ICONS_DIR, name))
        if os.path.isfile(os.path.join(temp, "dossiers.json")):
            shutil.copyfile(os.path.join(temp, "dossiers.json"), PLAN_PATH)
    return FolderPlan().apply_all()
