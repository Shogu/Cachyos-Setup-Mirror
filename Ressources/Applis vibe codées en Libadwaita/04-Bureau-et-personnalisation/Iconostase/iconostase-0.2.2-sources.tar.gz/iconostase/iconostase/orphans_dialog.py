# SPDX-License-Identifier: GPL-3.0-or-later
import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, GLib, Gtk  # noqa: E402


class OrphansDialog(Adw.Dialog):
    def __init__(self, app, names, **kwargs):
        super().__init__(title=_("Orphan launchers"), content_width=520, content_height=480, **kwargs)
        self._app = app
        self._rows = {}
        self._group = group = Adw.PreferencesGroup(
            description=_("Their command no longer exists, usually because the application was uninstalled"))
        for name in sorted(names, key=lambda item: (app.get_launcher_parser(item).get_name() or item).lower()):
            parser = app.get_launcher_parser(name)
            row = Adw.ActionRow(title=GLib.markup_escape_text(parser.get_name() or name),
                                subtitle=GLib.markup_escape_text(parser.get_command()))
            icon = parser.get_icon() or "application-x-executable"
            image = Gtk.Image.new_from_file(icon) if "/" in icon else Gtk.Image.new_from_icon_name(icon)
            image.set_pixel_size(32)
            row.add_prefix(image)
            hide = Gtk.Button(label=_("Hide"), valign=Gtk.Align.CENTER)
            hide.connect("clicked", self._on_hide_clicked, name)
            row.add_suffix(hide)
            if not app.launcher_has_system_default(name):
                delete = Gtk.Button(icon_name="user-trash-symbolic", valign=Gtk.Align.CENTER,
                                    tooltip_text=_("Delete this launcher"))
                delete.add_css_class("flat")
                delete.connect("clicked", self._on_delete_clicked, name)
                row.add_suffix(delete)
            self._rows[name] = row
            group.add(row)
        page = Adw.PreferencesPage()
        page.add(group)
        self._status = Adw.StatusPage(icon_name="emblem-ok-symbolic", title=_("No orphan launcher"))
        self._stack = Gtk.Stack()
        self._stack.add_named(page, "list")
        self._stack.add_named(self._status, "empty")
        self._stack.set_visible_child_name("list" if names else "empty")
        view = Adw.ToolbarView(content=self._stack)
        view.add_top_bar(Adw.HeaderBar())
        self.set_child(view)

    def _forget(self, name):
        row = self._rows.pop(name)
        self._group.remove(row)
        if not self._rows:
            self._stack.set_visible_child_name("empty")

    def _on_hide_clicked(self, button, name):
        self._app.hide_launcher(name)
        self._forget(name)

    def _on_delete_clicked(self, button, name):
        self._app.delete_launcher(name)
        self._forget(name)
