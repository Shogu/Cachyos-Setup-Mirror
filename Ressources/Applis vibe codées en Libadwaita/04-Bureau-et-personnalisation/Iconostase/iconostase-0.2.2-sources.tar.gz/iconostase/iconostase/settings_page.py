# SPDX-License-Identifier: GPL-3.0-or-later
# D'après libre-menu-editor (© 2022 Free Software Foundation).
import os
import random
import string

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import GLib, Gtk, Adw  # noqa: E402

from .core.events import EventManager
from .filters import CategoriesFilter, KeywordsFilter, ShowInFilter
from .widgets.constants import Keyval, Margin, Spacing
from .widgets.errors import IconSizeNotSupportedError
from .widgets.rows import ComboRow, CommandChooserRow, DeleteRow, DirectoryChooserRow, EntryRow, IconChooserRow, LinkConverterRow, SwitchRow
from .widgets.tagged import TaggedFlowRow
from .history import icon_files
from .icon_store import icon_name_for
from .widgets.symbolic_row import SymbolicIconRow


class DesktopActionGroup(Adw.PreferencesGroup):
    def __init__(self, app, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._application_window = app.get_application_window()
        self._events = EventManager()
        self._events.add("data-changed", object, tuple)
        self._events.add("row-deleted", object)
        self._children = []
        self._delete_mode_enabled = False
        self._delete_row_placeholder_text = _("Unnamed Action")
        self._entry_row = EntryRow(app)
        self._entry_row.set_title(_("Action name"))
        self._entry_row.hook("text-changed", self._on_child_row_text_changed)
        self._command_chooser_row = CommandChooserRow(app)
        self._command_chooser_row.set_title(_("Command"))
        self._command_chooser_row.set_dialog_title(_("Choose executable file"))
        self._command_chooser_row.set_dialog_accept_button_label(
            _("Open"))
        self._command_chooser_row.hook("text-changed", self._on_child_row_text_changed)
        self._link_converter_row = LinkConverterRow(app)
        self._link_converter_row.set_entry(self._command_chooser_row)
        self._link_converter_row.set_label(_("Convert link to command"))
        self._delete_row = DeleteRow(app)
        self._delete_row.connect("activated", self._on_delete_row_activated)
        self.add(self._entry_row)
        self.add(self._command_chooser_row)
        self.add(self._link_converter_row)

    def _on_delete_row_activated(self, action_row):
        self._events.trigger("row-deleted", self)

    def _on_child_row_text_changed(self, event, child, text):
        data = self._entry_row.get_text(), self._command_chooser_row.get_text()
        self._events.trigger("data-changed", self, data)

    def get_name(self):
        return self._entry_row.get_text()

    def set_name(self, name):
        self._entry_row.set_text(name)

    def get_command(self):
        return self._command_chooser_row.get_text()

    def set_command(self, command):
        self._command_chooser_row.set_text(command)

    def get_delete_mode_enabled(self):
        return self._delete_mode_enabled

    def set_delete_mode_enabled(self, value):
        if value and not self._delete_mode_enabled:
            self.remove(self._entry_row)
            self.remove(self._command_chooser_row)
            self.remove(self._link_converter_row)
            name_text = self._entry_row.get_text()
            if not len(name_text):
                name_text = self._delete_row_placeholder_text
            self._delete_row.set_title(name_text)
            self._delete_row.set_text(self._command_chooser_row.get_text())
            self.add(self._delete_row)
        elif not value and self._delete_mode_enabled:
            self.remove(self._delete_row)
            self.add(self._entry_row)
            self.add(self._command_chooser_row)
            self.add(self._link_converter_row)
        self._delete_mode_enabled = value

    def add(self, child):
        self._children.append(child)
        Adw.PreferencesGroup.add(self, child)

    def remove(self, child):
        self._children.remove(child)
        Adw.PreferencesGroup.remove(self, child)

    def hook(self, event, callback, *args):
        self._events.hook(event, callback, *args)

    def release(self, id):
        self._events.release(id)

    def grab_focus(self):
        if not self._delete_mode_enabled:
            self._entry_row.grab_focus()
        else:
            self._delete_row.grab_focus()

    def reset(self):
        for hook in list(self._events.get_hooks()):
            self._events.release(hook)
        self.set_name("")
        self.set_command("")
        self.set_sensitive(True)
        self.set_delete_mode_enabled(False)
        self.set_header_suffix(None)
        self.set_title("")


class SettingsPage(Gtk.Box):
    def __init__(self, app, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._events = EventManager()
        self._events.add("changed-changed", bool, bool)
        self._config_manager = app.get_config_manager()
        self._icon_finder = app.get_icon_finder()
        self._application = app
        self._clamp_limit = 1200
        self._clamp_threshold = 240
        self._never_hide_reload_button = False
        self._reload_button_fade_duration = 45
        self._reload_button_fade_timeout_id = None
        self._loading_desktop_launcher = False
        self._changed = False
        self._current_name = None
        self._current_parser = None
        self._delete_mode_enabled = False
        self._always_show_save_button = False
        self._desktop_action_groups_cache = []
        self._current_desktop_actions = []
        self._current_desktop_action_groups = {}
        self._input_children_changes = {}
        self._show_in_filter_histories = {}
        self._save_button = Gtk.Button()
        self._reload_button = Gtk.Button()
        self._banner_event_controller_key = Gtk.EventControllerKey()
        self._banner_event_controller_key.connect("key-pressed", self._on_banner_event_controller_key_pressed)
        self._banner = Adw.Banner()
        self._banner.set_title(_("Please select the actions you want to delete"))
        self._banner.set_button_label(_("Done"))
        self._banner.connect("button-clicked", self._on_banner_button_clicked)
        self._banner.add_controller(self._banner_event_controller_key)
        self.append(self._banner)
        self._icon_chooser_row = IconChooserRow(app)
        self._icon_chooser_row.set_default_entry_title(_("Icon"))
        self._icon_chooser_row.set_search_entry_title(_("Keywords"))
        self._icon_chooser_row.set_dialog_title(_("Choose icon"))
        self._icon_chooser_row.set_dialog_accept_button_label(
            _("Open"))
        self._icon_chooser_row.hook("text-changed", self._on_input_child_data_changed)
        self._icon_chooser_row.hook("text-changed", self._on_icon_text_changed)
        self._icon_chooser_row.hook("file-chosen", self._on_color_file_chosen)
        self._icon_store = app.get_icon_store()
        self._symbolic_row = SymbolicIconRow(app)
        self._symbolic_row.hook("file-chosen", self._on_symbolic_file_chosen)
        self._symbolic_row.hook("convert-requested", self._on_convert_requested)
        self._icon_browser_row = self._icon_chooser_row.get_icon_browser_row()
        self._icon_browser = self._icon_browser_row.get_icon_browser()
        self._icon_browser.set_show_names_toggle_label(
            _("Show icon names"))
        self._icon_view_row = self._icon_chooser_row.get_icon_view_row()
        self._icon_browser_help_status_page = self._icon_chooser_row.get_help_status_page()
        self._icon_browser_help_status_page.add_css_class("compact")
        self._icon_browser_help_status_page.set_title(
            _("Icon search"))
        self._icon_browser_help_status_page.set_description(
            _("Enter keywords to receive suggestions"))
        self._icon_browser_none_status_page = self._icon_chooser_row.get_none_status_page()
        self._icon_browser_none_status_page.add_css_class("compact")
        self._icon_browser_none_status_page.set_title(
            _("No Results"))
        self._icon_browser_none_status_page.set_description(
            _("No search results were found for this input"))
        self._appearance_preferences_group = Adw.PreferencesGroup()
        self._appearance_preferences_group.set_title(_("Appearance"))
        self._appearance_preferences_group.add(self._icon_view_row)
        self._appearance_preferences_group.add(self._icon_chooser_row)
        self._appearance_preferences_group.add(self._icon_browser_row)
        self._appearance_preferences_group.add(self._symbolic_row)
        self._name_entry_row = EntryRow(app)
        self._name_entry_row.set_title(_("Name"))
        self._name_entry_row.hook("text-changed", self._on_input_child_data_changed)
        self._comment_entry_row = EntryRow(app)
        self._comment_entry_row.set_title(_("Comment"))
        self._comment_entry_row.hook("text-changed", self._on_input_child_data_changed)
        self._description_preferences_group = Adw.PreferencesGroup()
        self._description_preferences_group.set_title(_("Description"))
        self._description_preferences_group.add(self._name_entry_row)
        self._description_preferences_group.add(self._comment_entry_row)
        self._keywords_entry_row = EntryRow(app)
        self._keywords_entry_row.set_title(_("Add keywords"))
        self._keywords_flow_row = TaggedFlowRow(app)
        self._keywords_flow_row.hook("text-changed", self._on_input_child_data_changed)
        self._keywords_flow_row.set_entry_row(self._keywords_entry_row)
        self._keywords_filter = KeywordsFilter(app)
        self._keywords_filter.set_flow_row(self._keywords_flow_row)
        self._keywords_filter.hook("text-changed", self._on_input_child_data_changed)
        self._keywords_preferences_group = Adw.PreferencesGroup()
        self._keywords_preferences_group.set_title(_("Search"))
        self._keywords_preferences_group.add(self._keywords_entry_row)
        self._keywords_preferences_group.add(self._keywords_flow_row)
        self._command_chooser_row = CommandChooserRow(self._application)
        self._command_chooser_row.set_title(_("Default command"))
        self._command_chooser_row.set_dialog_title(_("Choose executable file"))
        self._command_chooser_row.set_dialog_accept_button_label(
            _("Open"))
        self._command_chooser_row.hook("text-changed", self._on_input_child_data_changed)
        self._workdir_chooser_row = DirectoryChooserRow(app)
        self._workdir_chooser_row.set_dialog_accept_button_label(
            _("Open"))
        self._workdir_chooser_row.set_fallback_path(GLib.get_home_dir())
        self._workdir_chooser_row.set_title(
            _("Working directory"))
        self._workdir_chooser_row.hook("text-changed", self._on_input_child_data_changed)
        self._link_converter_row = LinkConverterRow(self._application)
        self._link_converter_row.set_entry(self._command_chooser_row)
        self._link_converter_row.set_label(_("Convert link to command"))
        self._primary_event_controller_key = Gtk.EventControllerKey()
        self._primary_action_create_button = Gtk.Button()
        self._primary_action_create_button.set_icon_name(self._icon_finder.get_name("list-add-symbolic"))
        self._primary_action_create_button.add_css_class("flat")
        self._primary_action_create_button.connect("clicked", self._on_action_create_button_clicked)
        self._primary_action_delete_button = Gtk.Button()
        self._primary_action_delete_button.set_icon_name(self._icon_finder.get_name("list-remove-symbolic"))
        self._primary_action_delete_button.add_css_class("flat")
        self._primary_action_delete_button.connect("clicked", self._on_action_delete_button_clicked)
        self._primary_header_suffix_box = Gtk.Box()
        self._primary_header_suffix_box.set_spacing(Spacing.DEFAULT)
        self._primary_header_suffix_box.append(self._primary_action_create_button)
        self._primary_header_suffix_box.append(self._primary_action_delete_button)
        self._primary_header_suffix_box.add_controller(self._primary_event_controller_key)
        self._execution_preferences_group = Adw.PreferencesGroup()
        self._execution_preferences_group.set_title(_("Execution"))
        self._execution_preferences_group.add(self._command_chooser_row)
        self._execution_preferences_group.add(self._workdir_chooser_row)
        self._execution_preferences_group.add(self._link_converter_row)
        self._execution_preferences_group.set_header_suffix(self._primary_header_suffix_box)
        self._categories_flow_row = TaggedFlowRow(app)
        self._categories_combo_row = ComboRow(app)
        self._categories_combo_row.set_title(_("Traditional menu categories of the application"))
        self._categories_combo_row.set_flow_row(self._categories_flow_row)
        self._categories_filter = CategoriesFilter(app)
        self._categories_filter.set_flow_row(self._categories_flow_row)
        self._categories_filter.set_combo_row(self._categories_combo_row)
        self._categories_filter.hook("text-changed", self._on_input_child_data_changed)
        self._categories_preferences_group = Adw.PreferencesGroup()
        self._categories_preferences_group.set_title(_("Menu"))
        self._categories_preferences_group.add(self._categories_combo_row)
        self._categories_preferences_group.add(self._categories_flow_row)
        self._terminal_switch_row = SwitchRow()
        self._terminal_switch_row.set_title(_("Show a terminal window during execution"))
        self._terminal_switch_row.hook("value-changed", self._on_input_child_data_changed)
        self._notify_switch_row = SwitchRow()
        self._notify_switch_row.set_title(_("Show an animation until the application is visible"))
        self._notify_switch_row.hook("value-changed", self._on_input_child_data_changed)
        self._window_preferences_group = Adw.PreferencesGroup()
        self._window_preferences_group.set_title(_("Window"))
        self._window_preferences_group.add(self._terminal_switch_row)
        self._window_preferences_group.add(self._notify_switch_row)
        self._visible_switch_row = SwitchRow()
        self._visible_switch_row.set_title(_("Show this application in the main menu"))
        self._visible_switch_row.hook("value-changed", self._on_input_child_data_changed)
        self._visible_switch_row.hook("value-changed", self._on_visibility_widgets_changed)
        self._only_show_in_flow_row = TaggedFlowRow(app)
        self._only_show_in_combo_row = ComboRow(app)
        self._only_show_in_combo_row.set_title(_("Show this application only in certain environments"))
        self._only_show_in_combo_row.set_flow_row(self._only_show_in_flow_row)
        self._only_show_in_filter = ShowInFilter(app)
        self._only_show_in_filter.set_flow_row(self._only_show_in_flow_row)
        self._only_show_in_filter.set_combo_row(self._only_show_in_combo_row)
        self._only_show_in_filter.hook("text-changed", self._on_input_child_data_changed)
        self._only_show_in_filter.hook("text-changed", self._on_visibility_widgets_changed)
        self._not_show_in_flow_row = TaggedFlowRow(app)
        self._not_show_in_combo_row = ComboRow(app)
        self._not_show_in_combo_row.set_title(_("Hide this application in certain environments"))
        self._not_show_in_combo_row.set_flow_row(self._not_show_in_flow_row)
        self._not_show_in_filter = ShowInFilter(app)
        self._not_show_in_filter.set_flow_row(self._not_show_in_flow_row)
        self._not_show_in_filter.set_combo_row(self._not_show_in_combo_row)
        self._not_show_in_filter.hook("text-changed", self._on_input_child_data_changed)
        self._not_show_in_filter.hook("text-changed", self._on_visibility_widgets_changed)
        self._visible_preferences_group = Adw.PreferencesGroup()
        self._visible_preferences_group.set_title(_("Visibility"))
        self._visible_preferences_group.add(self._visible_switch_row)
        self._visible_preferences_group.add(self._only_show_in_combo_row)
        self._visible_preferences_group.add(self._only_show_in_flow_row)
        self._visible_preferences_group.add(self._not_show_in_combo_row)
        self._visible_preferences_group.add(self._not_show_in_flow_row)
        self._dgpu_switch_row = SwitchRow()
        self._dgpu_switch_row.set_title(_("Prefer a more powerful GPU to run this application"))
        self._dgpu_switch_row.hook("value-changed", self._on_input_child_data_changed)
        self._edit_file_action_row_image = self._icon_finder.get_image("adw-external-link-symbolic")
        self._edit_file_action_row_button = Gtk.Button()
        self._edit_file_action_row_button.add_css_class("flat")
        self._edit_file_action_row_button.set_valign(Gtk.Align.CENTER)
        self._edit_file_action_row_button.set_child(self._edit_file_action_row_image)
        self._edit_file_action_row_button.set_can_focus(False)
        self._edit_file_action_row_button.set_can_target(False)
        self._edit_file_action_row = Adw.ActionRow()
        self._edit_file_action_row.set_activatable(True)
        self._edit_file_action_row.set_title(_("Open settings in text editor"))
        self._edit_file_action_row.add_suffix(self._edit_file_action_row_button)
        self._advanced_preferences_group = Adw.PreferencesGroup()
        self._advanced_preferences_group.set_title(_("Advanced"))
        self._advanced_preferences_group.add(self._dgpu_switch_row)
        self._advanced_preferences_group.add(self._edit_file_action_row)
        self._page_event_controller_key = Gtk.EventControllerKey()
        self._page_event_controller_key.connect("key-pressed", self._on_page_controller_key_pressed)
        self._top_box = Gtk.Box()
        self._top_box.set_spacing(Spacing.LARGER)
        self._top_box.set_orientation(Gtk.Orientation.VERTICAL)
        self._top_box.append(self._appearance_preferences_group)
        self._top_box.append(self._description_preferences_group)
        self._top_box.append(self._execution_preferences_group)
        self._action_box = Gtk.Box()
        self._action_box.set_spacing(Spacing.LARGER)
        self._action_box.set_orientation(Gtk.Orientation.VERTICAL)
        self._bottom_box = Gtk.Box()
        self._bottom_box.set_spacing(Spacing.LARGER)
        self._bottom_box.set_orientation(Gtk.Orientation.VERTICAL)
        self._bottom_box.append(self._keywords_preferences_group)
        self._bottom_box.append(self._window_preferences_group)
        self._bottom_box.append(self._visible_preferences_group)
        self._bottom_box.append(self._categories_preferences_group)
        self._bottom_box.append(self._advanced_preferences_group)
        self._bottom_area = Gtk.Box()
        self._main_box = Gtk.Box()
        self._main_box.set_spacing(Spacing.LARGER)
        self._main_box.set_orientation(Gtk.Orientation.VERTICAL)
        self._main_box.append(self._top_box)
        self._main_box.append(self._action_box)
        self._main_box.append(self._bottom_box)
        self._main_box.append(self._bottom_area)
        self._clamp = Adw.Clamp(maximum_size=self._clamp_limit, tightening_threshold=self._clamp_threshold)
        self._clamp.set_margin_top(Margin.LARGER)
        self._clamp.set_margin_bottom(Margin.LARGER)
        self._clamp.set_margin_start(Margin.LARGER)
        self._clamp.set_margin_end(Margin.LARGER)
        self._clamp.set_child(self._main_box)
        self._scrolled_window = Gtk.ScrolledWindow()
        self._scrolled_window.set_child(self._clamp)
        self._scrolled_window.set_vexpand(True)
        self.set_orientation(Gtk.Orientation.VERTICAL)
        self.append(self._scrolled_window)
        self._update_action_children_sensitive(False)
        self._update_top_desktop_action_group_header()
        self.load_icon_browser_configs()

    def _on_visibility_widgets_changed(self, event, child, data):
        self._update_visibility_widgets()

    def _on_page_controller_key_pressed(self, controller, keyval, keycode, state):
        if keyval == Keyval.ESCAPE:
            if self._delete_mode_enabled:
                self.set_delete_mode_enabled(False)
                return True

    def _on_banner_button_clicked(self, banner):
        self.set_delete_mode_enabled(False)

    def _on_action_create_button_clicked(self, button):
        while True:
            action = ''.join(random.choices(string.digits, k=6))
            if not action in self._current_desktop_actions:
                self._add_desktop_action(action, set_focus=True)
                break

    def _on_action_delete_button_clicked(self, button):
        self.set_delete_mode_enabled(True)

    def _on_banner_event_controller_key_pressed(self, controller, keyval, keycode, state):
        if keyval == Keyval.DOWN or keyval == Keyval.PAGEDOWN:
            self._current_desktop_action_groups[self._current_desktop_actions[0]].grab_focus()
            return True
        elif keyval == Keyval.ESCAPE:
            self.set_delete_mode_enabled(False)

    def _on_desktop_action_group_row_deleted(self, event, desktop_action_group):
        index = list(self._current_desktop_action_groups.values()).index(desktop_action_group)
        action = self._current_desktop_actions[index]
        self._remove_desktop_action(action, set_focus=True)

    def _on_icon_text_changed(self, event, child, text):
        self._symbolic_row.update(text)

    def _icon_target_name(self):
        return icon_name_for(self._current_name, self._icon_chooser_row.get_text())

    def _install_color(self, path):
        name = self._icon_target_name()
        self._application.record(_("color icon of %s") % name, icon_files(name))
        self._icon_store.install_color(name, path)
        self._icon_store.refresh()
        self._application.mark_unexported()
        self._icon_chooser_row.set_text(name)
        self._symbolic_row.update(name)

    def _on_color_file_chosen(self, event, child, path):
        self._install_color(path)

    def _on_convert_requested(self, event, child):
        self._install_color(self._icon_chooser_row.get_text())

    def _on_symbolic_file_chosen(self, event, child, path):
        current = self._icon_chooser_row.get_text()
        if os.path.isfile(current):
            self._install_color(current)
        name = self._icon_target_name()
        self._application.record(_("symbolic icon of %s") % name, icon_files(name))
        self._icon_store.install_symbolic(name, path)
        self._icon_store.refresh()
        self._application.mark_unexported()
        self._application.notify_undoable(_("Symbolic icon installed"))
        self._symbolic_row.update(name)

    def _on_input_child_data_changed(self, event, child, data):
        if not isinstance(child, DesktopActionGroup):
            if child == self._icon_chooser_row:
                self._input_children_changes[child] = data == self._current_parser.get_icon()
            elif child == self._name_entry_row:
                self._input_children_changes[child] = data == self._current_parser.get_name()
            elif child == self._comment_entry_row:
                self._input_children_changes[child] = data == self._current_parser.get_comment()
            elif child == self._keywords_filter:
                self._input_children_changes[child] = data == self._current_parser.get_keywords()
            elif child == self._categories_filter:
                self._input_children_changes[child] = data == self._current_parser.get_categories()
            elif child == self._only_show_in_filter:
                self._input_children_changes[child] = data == self._current_parser.get_only_show_in()
            elif child == self._not_show_in_filter:
                self._input_children_changes[child] = data == self._current_parser.get_not_show_in()
            elif child == self._command_chooser_row:
                self._input_children_changes[child] = data == self._current_parser.get_command()
            elif child == self._workdir_chooser_row:
                self._input_children_changes[child] = data == self._current_parser.get_working_directory()
            elif child == self._dgpu_switch_row:
                self._input_children_changes[child] = data == self._current_parser.get_prefers_dgpu()
            elif child == self._visible_switch_row:
                self._input_children_changes[child] = data == self._current_parser.get_visible()
            elif child == self._notify_switch_row:
                self._input_children_changes[child] = data == self._current_parser.get_notify()
            elif child == self._terminal_switch_row:
                self._input_children_changes[child] = data == self._current_parser.get_terminal()
        self._update_action_children_sensitive()

    def _get_input_children_changed(self, rescan_all=False):
        if rescan_all:
            self._scan_input_children_data_changed()
        if False in self._input_children_changes.values():
            value = True
        else:
            value = self._get_desktop_action_groups_changed()
        if not value == self._changed:
            self._events.trigger("changed-changed", self._changed, bool(value))
        self._changed = bool(value)
        return value

    def _get_desktop_action_groups_changed(self):
        try:
            parser_actions = self._current_parser.get_actions()
        except AttributeError:
            return False
        if not self._current_desktop_actions == parser_actions:
            parser_actions_count = len(parser_actions)
            if len(self._current_desktop_actions) > parser_actions_count:
                for n, current_action in enumerate(self._current_desktop_actions[:parser_actions_count]):
                    current_name = self._current_desktop_action_groups[current_action].get_name()
                    parser_name = self._current_parser.get_action_name(parser_actions[n])
                    if not current_name == parser_name:
                        return True
                    current_command = self._current_desktop_action_groups[current_action].get_command()
                    parser_command = self._current_parser.get_action_command(parser_actions[n])
                    if not current_command == parser_command:
                        return True
                else:
                    for action in self._current_desktop_actions[parser_actions_count:]:
                        desktop_action_group = self._current_desktop_action_groups[action]
                        if len(desktop_action_group.get_name()) or len(desktop_action_group.get_command()):
                            return True
            else:
                return True
        else:
            for action in self._current_desktop_actions:
                name = self._current_desktop_action_groups[action].get_name()
                if not name == self._current_parser.get_action_name(action):
                    return True
                command = self._current_desktop_action_groups[action].get_command()
                if not command == self._current_parser.get_action_command(action):
                    return True

    def _scan_input_children_data_changed(self):
        for child, method, default in [
            (self._icon_chooser_row, self._icon_chooser_row.get_text(), self._current_parser.get_icon()),
            (self._name_entry_row, self._name_entry_row.get_text(), self._current_parser.get_name()),
            (self._comment_entry_row, self._comment_entry_row.get_text(), self._current_parser.get_comment()),
            (self._keywords_filter, self._keywords_filter.get_text(), self._current_parser.get_keywords()),
            (self._categories_filter, self._categories_filter.get_text(), self._current_parser.get_categories()),
            (self._only_show_in_filter, self._only_show_in_filter.get_text(), self._current_parser.get_only_show_in()),
            (self._not_show_in_filter, self._not_show_in_filter.get_text(), self._current_parser.get_not_show_in()),
            (self._command_chooser_row, self._command_chooser_row.get_text(), self._current_parser.get_command()),
            (self._workdir_chooser_row, self._workdir_chooser_row.get_text(), self._current_parser.get_working_directory()),
            (self._dgpu_switch_row, self._dgpu_switch_row.get_active(), self._current_parser.get_prefers_dgpu()),
            (self._visible_switch_row, self._visible_switch_row.get_active(), self._current_parser.get_visible()),
            (self._notify_switch_row, self._notify_switch_row.get_active(), self._current_parser.get_notify()),
            (self._terminal_switch_row, self._terminal_switch_row.get_active(), self._current_parser.get_terminal())
        ]:
            self._input_children_changes[child] = method == default

    def _create_new_desktop_action_group(self):
        try:
            desktop_action_group = self._desktop_action_groups_cache.pop(0)
        except IndexError:
            desktop_action_group = DesktopActionGroup(self._application)
        desktop_action_group.hook("row-deleted", self._on_desktop_action_group_row_deleted)
        desktop_action_group.hook("data-changed", self._on_input_child_data_changed)
        return desktop_action_group

    def _add_desktop_action(self, action, set_focus=False):
        desktop_action_group = self._create_new_desktop_action_group()
        if action in self._current_parser.get_actions():
            desktop_action_group.set_name(self._current_parser.get_action_name(action))
            desktop_action_group.set_command(self._current_parser.get_action_command(action))
        self._current_desktop_action_groups[action] = desktop_action_group
        self._current_desktop_actions.append(action)
        self._action_box.append(desktop_action_group)
        if set_focus:
            GLib.idle_add(desktop_action_group.grab_focus)
        self._update_top_desktop_action_group_header()
        self._update_action_children_sensitive()

    def _remove_desktop_action(self, action, set_focus=False):
        index = self._current_desktop_actions.index(action)
        desktop_action_group = self._current_desktop_action_groups[action]
        del self._current_desktop_action_groups[action]
        self._current_desktop_actions.remove(action)
        if not len(self._current_desktop_actions):
            self.set_delete_mode_enabled(False)
        if set_focus:
            if not len(self._current_desktop_actions):
                self._primary_action_create_button.grab_focus()
            elif index < len(self._current_desktop_actions):
                self._current_desktop_action_groups[self._current_desktop_actions[index]].grab_focus()
            else:
                self._current_desktop_action_groups[self._current_desktop_actions[-1]].grab_focus()
        self._action_box.remove(desktop_action_group)
        desktop_action_group.reset()
        self._desktop_action_groups_cache.append(desktop_action_group)
        self._update_top_desktop_action_group_header()
        self._update_action_children_sensitive()

    def _update_visibility_widgets(self):
        rows_sensitive = self._visible_switch_row.get_active()
        self._only_show_in_combo_row.set_sensitive(rows_sensitive)
        self._only_show_in_flow_row.set_sensitive(rows_sensitive)
        self._not_show_in_combo_row.set_sensitive(rows_sensitive)
        self._not_show_in_flow_row.set_sensitive(rows_sensitive)
        if len(self._only_show_in_flow_row.get_tags()):
            self._not_show_in_combo_row.set_sensitive(False)
            self._not_show_in_flow_row.set_sensitive(False)
        elif len(self._not_show_in_flow_row.get_tags()):
            self._only_show_in_combo_row.set_sensitive(False)

    def _update_top_desktop_action_group_header(self):
        self._primary_action_delete_button.set_sensitive(len(self._current_desktop_action_groups))
        self._action_box.set_visible(len(self._current_desktop_action_groups))

    def _update_input_children_sensitive(self, value=True):
        self._action_box.set_sensitive(value)
        if self._delete_mode_enabled:
            value = False
        self._primary_header_suffix_box.set_sensitive(value)
        self._top_box.set_sensitive(value)
        self._bottom_box.set_sensitive(value)

    def _update_action_children_sensitive(self, value=True, skip_reload_button=False):
        if self._never_hide_reload_button:
            skip_reload_button = True
        input_children_changed = self._get_input_children_changed()
        if not self._loading_desktop_launcher:
            if value and not input_children_changed:
                value = False
            if value or self._always_show_save_button:
                self._save_button.set_sensitive(True)
                self._save_button.add_css_class("suggested-action")
            else:
                self._save_button.set_sensitive(False)
                self._save_button.remove_css_class("suggested-action")
            if not skip_reload_button:
                if self._reload_button_fade_timeout_id:
                    GLib.source_remove(self._reload_button_fade_timeout_id)
                if value:
                    self._reload_button.set_visible(True)
                    self._reload_button_fade_timeout_id = GLib.timeout_add(self._reload_button_fade_duration,
                        self._after_reload_button_show)
                else:
                    self._reload_button.set_sensitive(False)
                    self._reload_button_fade_timeout_id = GLib.timeout_add(self._reload_button_fade_duration,
                        self._after_reload_button_hide)

    def _after_reload_button_show(self):
        self._reload_button.set_sensitive(True)
        self._reload_button_fade_timeout_id = None
        return GLib.SOURCE_REMOVE

    def _after_reload_button_hide(self):
        self._reload_button.set_visible(False)
        self._reload_button_fade_timeout_id = None
        return GLib.SOURCE_REMOVE

    def get_delete_mode_enabled(self):
        return self._delete_mode_enabled

    def set_delete_mode_enabled(self, value):
        if not value == self._delete_mode_enabled:
            self._delete_mode_enabled = value
            self._banner.set_revealed(value)
            for action in self._current_desktop_actions:
                desktop_action_group = self._current_desktop_action_groups[action]
                desktop_action_group.set_delete_mode_enabled(value)
            self._update_input_children_sensitive()
            if value:
                self._current_desktop_action_groups[self._current_desktop_actions[0]].grab_focus()

    def load_desktop_launcher(self, name, parser, update_widgets=True):
        self._loading_desktop_launcher = True
        if update_widgets:
            self.reset(reset_data=False)
        self._current_name = name
        self._current_parser = parser
        if not self._current_name in self._show_in_filter_histories:
            self._show_in_filter_histories[self._current_name] = set()
        history = self._show_in_filter_histories[self._current_name]
        if update_widgets:
            for action in list(self._current_desktop_actions):
                self._remove_desktop_action(action)
            for action in self._current_parser.get_actions():
                self._add_desktop_action(action)
            self._only_show_in_filter.set_unknown_values_history(history)
            self._not_show_in_filter.set_unknown_values_history(history)
            self._icon_chooser_row.set_text(self._current_parser.get_icon())
            self._name_entry_row.set_text(self._current_parser.get_name())
            self._comment_entry_row.set_text(self._current_parser.get_comment())
            self._keywords_filter.set_text(self._current_parser.get_keywords())
            self._categories_filter.set_text(self._current_parser.get_categories())
            self._only_show_in_filter.set_text(self._current_parser.get_only_show_in())
            self._not_show_in_filter.set_text(self._current_parser.get_not_show_in())
            self._command_chooser_row.set_text(self._current_parser.get_command())
            self._workdir_chooser_row.set_text(self._current_parser.get_working_directory())
            self._dgpu_switch_row.set_active(self._current_parser.get_prefers_dgpu())
            self._visible_switch_row.set_active(self._current_parser.get_visible())
            self._notify_switch_row.set_active(self._current_parser.get_notify())
            self._terminal_switch_row.set_active(self._current_parser.get_terminal())
            self._loading_desktop_launcher = False
            self._update_action_children_sensitive(False)
        else:
            self._get_input_children_changed(rescan_all=True)
            self._loading_desktop_launcher = False
            self._update_action_children_sensitive()
        self._update_visibility_widgets()

    def save_desktop_launcher(self):
        for action in self._current_parser.get_actions():
            if not action in self._current_desktop_actions:
                self._current_parser.remove_action(action)
        for action in list(self._current_desktop_actions):
            desktop_action_group = self._current_desktop_action_groups[action]
            if not len(desktop_action_group.get_name()) and not len(desktop_action_group.get_command()):
                if action in self._current_parser.get_actions():
                    self._current_parser.remove_action(action)
                self._remove_desktop_action(action)
            else:
                if not action in self._current_parser.get_actions():
                    self._current_parser.add_action(action)
                self._current_parser.set_action_name(action, desktop_action_group.get_name())
                self._current_parser.set_action_command(action, desktop_action_group.get_command())
        self._current_parser.set_icon(self._icon_chooser_row.get_text())
        self._current_parser.set_name(self._name_entry_row.get_text())
        self._current_parser.set_comment(self._comment_entry_row.get_text())
        self._current_parser.set_keywords(self._keywords_filter.get_text())
        self._current_parser.set_categories(self._categories_filter.get_text())
        self._current_parser.set_only_show_in(self._only_show_in_filter.get_text())
        self._current_parser.set_not_show_in(self._not_show_in_filter.get_text())
        self._current_parser.set_command(self._command_chooser_row.get_text())
        self._current_parser.set_working_directory(self._workdir_chooser_row.get_text())
        self._current_parser.set_prefers_dgpu(self._dgpu_switch_row.get_active())
        self._current_parser.set_visible(self._visible_switch_row.get_active())
        self._current_parser.set_notify(self._notify_switch_row.get_active())
        self._current_parser.set_terminal(self._terminal_switch_row.get_active())
        self._current_parser.save()
        self.reset(reset_data=False)

    def get_always_show_save_button(self):
        return self._always_show_save_button

    def set_always_show_save_button(self, value):
        self._always_show_save_button = value
        self._update_action_children_sensitive(skip_reload_button=True)

    def get_never_hide_reload_button(self, value):
        return self._never_hide_reload_button

    def set_never_hide_reload_button(self, value):
        if value:
            if not self._reload_button_fade_timeout_id is None:
                GLib.source_remove(self._reload_button_fade_timeout_id)
                self._reload_button_fade_timeout_id = None
            self._reload_button.set_visible(True)
            self._reload_button.set_sensitive(True)
            self._never_hide_reload_button = value
        else:
            if self._never_hide_reload_button:
                self._never_hide_reload_button = value
                self._update_action_children_sensitive()
            else:
                self._never_hide_reload_button = value

    def get_hadjustment(self):
        return self._scrolled_window.get_hadjustment()

    def get_vadjustment(self):
        return self._scrolled_window.get_vadjustment()

    def get_edit_file_action_row(self):
        return self._edit_file_action_row

    def get_save_button(self):
        return self._save_button

    def get_reload_button(self):
        return self._reload_button

    def get_bottom_area(self):
        return self._bottom_area

    def get_changed(self):
        return self._changed

    def get_icon_browser(self):
        return self._icon_browser

    def get_icon_chooser_row(self):
        return self._icon_chooser_row

    def load_icon_browser_configs(self):
        self._icon_browser.set_show_names(self._config_manager.get("icon-browser.show-names"))
        try:
            self._icon_browser.set_icon_size(self._config_manager.get("icon-browser.icon-size"))
        except IconSizeNotSupportedError:
            pass

    def save_icon_brwser_configs(self):
        self._config_manager.set("icon-browser.show-names", self._icon_browser.get_show_names())
        self._config_manager.set("icon-browser.icon-size", self._icon_browser.get_icon_size())

    def reset(self, reset_data=True):
        if reset_data:
            for action in list(self._current_desktop_actions):
                self._remove_desktop_action(action)
            self._name_entry_row.set_text("")
            self._comment_entry_row.set_text("")
            self._command_chooser_row.set_text("")
            self._workdir_chooser_row.set_text("")
            self._dgpu_switch_row.set_active(False)
            self._visible_switch_row.set_active(False)
            self._notify_switch_row.set_active(False)
            self._terminal_switch_row.set_active(False)
            self._keywords_filter.reset()
            self._categories_filter.reset()
            self._only_show_in_filter.reset()
            self._not_show_in_filter.reset()
            self._icon_chooser_row.reset()
        self._icon_chooser_row.set_search_mode(False)
        self._keywords_entry_row.set_text("")
        self._update_action_children_sensitive(False)
        self._input_children_changes.clear()
        self.set_delete_mode_enabled(False)
        self._changed = False

    def hook(self, event, callback):
        return self._events.hook(event, callback)

    def release(self, id):
        self._events.release(id)

    def grab_focus(self):
        if self._delete_mode_enabled:
            self._current_desktop_action_groups[self._current_desktop_actions[0]].grab_focus()
        elif not self.get_focus_child():
            self._icon_chooser_row.grab_focus_without_selecting()
