# SPDX-License-Identifier: GPL-3.0-or-later
import datetime

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, GLib, Gtk  # noqa: E402

from .icon_batch import STATE_LABELS, export_icons
from .icon_store import IconState


class IconsExportDialog(Adw.Dialog):
    def __init__(self, app, launchers, only=None, **kwargs):
        super().__init__(title=_("Export icons"), content_width=560, content_height=640, **kwargs)
        self._app = app
        self._store = app.get_icon_store()
        self._checks = {}
        self._launchers = {name: (display_name, icon) for name, display_name, icon in launchers}
        to_review = [item for item in launchers if self._store.state(item[2]) != IconState.OK]
        complete = [item for item in launchers if self._store.state(item[2]) == IconState.OK]
        page = Adw.PreferencesPage()
        for title, items, checked in ((_("To review"), to_review, True), (_("Complete"), complete, False)):
            if not items:
                continue
            group = Adw.PreferencesGroup(title=title)
            for name, display_name, icon in items:
                check = Gtk.CheckButton(active=checked if only is None else name == only, valign=Gtk.Align.CENTER)
                check.connect("toggled", self._on_toggled)
                row = Adw.ActionRow(title=GLib.markup_escape_text(display_name),
                                    subtitle=GLib.markup_escape_text(f"{name} — {STATE_LABELS[self._store.state(icon)]}"),
                                    activatable_widget=check)
                image = Gtk.Image.new_from_file(icon) if "/" in icon else Gtk.Image.new_from_icon_name(icon)
                image.set_pixel_size(32)
                row.add_prefix(image)
                row.add_prefix(check)
                group.add(row)
                self._checks[name] = check
            page.add(group)
        self._export_button = Gtk.Button(label=_("Export…"))
        self._export_button.add_css_class("suggested-action")
        self._export_button.connect("clicked", self._on_export_clicked)
        header = Adw.HeaderBar()
        header.pack_end(self._export_button)
        view = Adw.ToolbarView(content=page)
        view.add_top_bar(header)
        self.set_child(view)
        self._on_toggled(None)

    def _selected(self):
        return [name for name, check in self._checks.items() if check.get_active()]

    def _on_toggled(self, check):
        count = len(self._selected())
        self._export_button.set_sensitive(count > 0)
        self._export_button.set_label(_("Export %d…") % count if count else _("Export…"))

    def _on_export_clicked(self, button):
        name = f"icones-a-redessiner-{datetime.date.today().isoformat()}.zip"
        Gtk.FileDialog(modal=True, initial_name=name).save(self._app.get_application_window(), None, self._on_chosen)

    def _on_chosen(self, dialog, result):
        try:
            path = dialog.save_finish(result).get_path()
        except GLib.GError:
            return
        items = [(name, *self._launchers[name]) for name in self._selected()]
        try:
            export_icons(path, items, self._store, self._app.get_icon_finder().get_theme())
        except OSError as error:
            self._app.notify(str(error), error=error)
            return
        self._app.notify(_("%d icons exported") % len(items))
        self.close()
