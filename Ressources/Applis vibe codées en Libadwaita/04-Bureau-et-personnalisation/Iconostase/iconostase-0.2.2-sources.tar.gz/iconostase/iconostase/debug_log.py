# SPDX-License-Identifier: GPL-3.0-or-later
# D'après libre-menu-editor (© 2022 Free Software Foundation).
import os
import sys
import datetime

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw  # noqa: E402


class DebugLog():
    def __init__(self, app):
        self._application = app
        self._raise_errors = False
        self._messages = []
        self._system_info = [
            f"{key}={os.getenv(key)}"
            for key in ("XDG_CURRENT_DESKTOP", "XDG_SESSION_TYPE", "LANG", "XDG_DATA_DIRS")
        ]
        self._system_info.insert(0, f"GTK {Gtk.get_major_version()}.{Gtk.get_minor_version()}, "
            f"libadwaita {Adw.get_major_version()}.{Adw.get_minor_version()}\n")

    def get_raise_errors(self):
        return self._raise_errors

    def set_raise_errors(self, value):
        self._raise_errors = value

    def add(self, text, error=None):
        if not error is None:
            if self._raise_errors:
                raise error
        now = datetime.datetime.now()
        message = "[{}][{}:{}:{}] {}".format(
            self._application.get_app_name(),
            now.strftime("%H"),
            now.strftime("%M"),
            now.strftime("%S"),
            text
        )
        self._messages.append(message)
        sys.stdout.write(f"{message}\n")

    def get(self):
        if len(self._messages):
            return "\n".join(self._messages + [""] + self._system_info)
        else:
            return "\n".join(self._system_info)
