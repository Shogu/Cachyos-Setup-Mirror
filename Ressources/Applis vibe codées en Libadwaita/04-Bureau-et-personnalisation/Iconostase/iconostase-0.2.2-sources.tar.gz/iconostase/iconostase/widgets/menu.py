# SPDX-License-Identifier: GPL-3.0-or-later
# D'après libre-menu-editor (© 2022 Free Software Foundation).

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gio, Gtk  # noqa: E402

from ..core.events import EventManager
from .errors import ItemNotFoundError, ItemNotSwitchError


class Menu(Gio.Menu):
    def __init__(self, app, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._events = EventManager()
        self._application_window = app.get_application_window()
        self._names = {}
        self._widgets = {}

    def _on_action_event(self, action, property):
        self._events.trigger(self._names[action])

    def get_switch_state(self, name):
        if isinstance(self._widgets[name], Gtk.Switch):
            return self._widgets[name].get_active()
        else:
            raise ItemNotSwitchError(name)

    def set_switch_state(self, name, value):
        if isinstance(self._widgets[name], Gtk.Switch):
            self._widgets[name].set_active(value)
        else:
            raise ItemNotSwitchError(name)

    def _add_action(self, action, widget, name, label):
        self.append(label, "win.%s" % name)
        self._events.add(name)
        self._names[action] = name
        self._widgets[name] = widget
        self._application_window.add_action(action)

    def get_enabled(self, name):
        for action in self._names:
            if self._names[action] == name:
                return action.get_enabled()
        else:
            raise ItemNotFoundError(name)

    def set_enabled(self, name, value):
        for action in self._names:
            if self._names[action] == name:
                action.set_enabled(value)
                break
        else:
            raise ItemNotFoundError(name)

    def add_button(self, name, label):
        action = Gio.SimpleAction.new(name, None)
        action.connect("activate", self._on_action_event)
        self._add_action(action, None, name, label)

    def add_switch(self, name, label):
        widget = Gtk.Switch()
        action = Gio.PropertyAction.new(name, widget, "active")
        action.connect("notify", self._on_action_event)
        self._add_action(action, widget, name, label)

    def hook(self, name, callback):
        return self._events.hook(name, callback)

    def release(self, id):
        self._events.release(id)
