# SPDX-License-Identifier: GPL-3.0-or-later
# D'après libre-menu-editor (© 2022 Free Software Foundation).



class Timeout():
    DEFAULT = 2


class Spacing():
    DEFAULT = 6
    LARGE = 11
    LARGER = 24
    LARGEST = 36


class Margin():
    SMALLEST = 2
    DEFAULT = 6
    LARGE = 11
    LARGER = 24
    LARGEST = 36


class Keyval():
    ENTER = 65293
    TAB = 65289
    ESCAPE = 65307
    LEFT = 65361
    UP = 65362
    RIGHT = 65363
    DOWN = 65364
    PAGEUP = 65365
    PAGEDOWN = 65366
    F2 = 65471
