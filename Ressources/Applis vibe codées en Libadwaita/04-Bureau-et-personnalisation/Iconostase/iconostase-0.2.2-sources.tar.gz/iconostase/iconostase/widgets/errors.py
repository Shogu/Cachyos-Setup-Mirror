# SPDX-License-Identifier: GPL-3.0-or-later
# D'après libre-menu-editor (© 2022 Free Software Foundation).



class IconNotFoundError(Exception):
    pass


class IconSizeNotSupportedError(Exception):
    pass


class TagNotFoundError(Exception):
    pass


class ItemAlreadyExistingError(Exception):
    pass


class ItemNotFoundError(Exception):
    pass


class ItemNotSwitchError(Exception):
    pass
