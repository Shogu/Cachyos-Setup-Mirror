# SPDX-License-Identifier: GPL-3.0-or-later
# D'après libre-menu-editor (© 2022 Free Software Foundation).

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import GLib, Gtk, Adw  # noqa: E402

from ..core.events import EventManager
from .constants import Margin, Spacing
from .errors import ItemAlreadyExistingError, ItemNotFoundError


class FlowingToolbar(Gtk.Box):
    def __init__(self, max_child_width=540, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._collapse_condition = None
        self._expand_condition = None
        self._max_child_width = max_child_width
        self._resize_frame = ResizeFrame()
        self._resize_frame.hook("resized", self._on_resize_frame_resized)
        self._start_clamp = Adw.Clamp()
        self._end_clamp = Adw.Clamp()
        self._spacer_child = Gtk.Box()
        self._spacer_child.set_hexpand(True)
        self._spacer_child.set_halign(Gtk.Align.FILL)
        self.set_spacing(Spacing.DEFAULT)
        self._content_box = Gtk.CenterBox()
        self._content_box.set_margin_top(Margin.LARGE)
        self._content_box.set_margin_bottom(Margin.LARGE)
        self._content_box.set_margin_start(Margin.LARGE)
        self._content_box.set_margin_end(Margin.LARGE)
        self._content_box.set_start_widget(self._start_clamp)
        self._content_box.set_center_widget(self._spacer_child)
        self._content_box.set_end_widget(self._end_clamp)
        self.set_orientation(Gtk.Orientation.VERTICAL)
        self.append(self._resize_frame)
        self.append(self._content_box)
        self.set_margin_top = self._content_box.set_margin_top
        self.set_margin_bottom = self._content_box.set_margin_bottom
        self.set_margin_start = self._content_box.set_margin_start
        self.set_margin_end = self._content_box.set_margin_end
        self.get_margin_top = self._content_box.get_margin_top
        self.get_margin_bottom = self._content_box.get_margin_bottom
        self.get_margin_start = self._content_box.get_margin_start
        self.get_margin_end = self._content_box.get_margin_end
        self._update_clamps()

    def _on_resize_frame_resized(self, event, width, height):
        self._update_clamps()

    def _update_clamps(self):
        width = self._resize_frame.get_width()
        collapse = width < (
            (self._max_child_width * 2) +
            self._content_box.get_margin_start() +
            self._content_box.get_margin_end() +
            self.get_spacing()
        )
        GLib.idle_add(self._after_update_clamps, width, collapse, priority=GLib.PRIORITY_LOW)

    def _after_update_clamps(self, width, collapse):
        if collapse and self.get_can_collapse():
            self._content_box.set_orientation(Gtk.Orientation.VERTICAL)
        elif not collapse and self.get_can_expand():
            self._content_box.set_orientation(Gtk.Orientation.HORIZONTAL)
        if self._content_box.get_orientation() == Gtk.Orientation.VERTICAL:
            clamp_child_width = width * 2
        else:
            clamp_child_width = self._max_child_width
        self._start_clamp.set_maximum_size(clamp_child_width)
        self._end_clamp.set_maximum_size(clamp_child_width)
        self._start_clamp.set_tightening_threshold(clamp_child_width)
        self._end_clamp.set_tightening_threshold(clamp_child_width)

    def _check_callable(self, func):
        if not callable(func):
            raise TypeError(f"not callable: {func}")

    def get_max_child_width(self):
        return self._max_child_width

    def set_max_child_width(self, value):
        self._max_child_width = value
        self._update_clamps()

    def get_spacing(self):
        return self._spacer_child.get_property("width-request")

    def set_spacing(self, spacing):
        self._spacer_child.set_property("width-request", spacing)
        self._spacer_child.set_property("height-request", spacing)

    def set_start_widget(self, widget):
        self._start_clamp.set_child(widget)

    def set_end_widget(self, widget):
        self._end_clamp.set_child(widget)

    def set_collapse_condition(self, func):
        self._check_callable(func)
        self._collapse_condition = func

    def set_expand_condition(self, func):
        self._check_callable(func)
        self._expand_condition = func

    def get_can_collapse(self):
        if self._collapse_condition:
            return self._collapse_condition()
        else:
            return True

    def get_can_expand(self):
        if self._expand_condition:
            return self._expand_condition()
        else:
            return True


class ResizeFrame(Gtk.Box):
    def __init__(self):
        super().__init__()
        self._events = EventManager()
        self._events.add("resized", int, int)
        self._last_width = 0
        self._last_height = 0
        self._widget = None
        self._drawing_area = Gtk.DrawingArea()
        self._drawing_area.connect("resize", self._on_drawing_area_resize)
        self._size_group = Gtk.SizeGroup()
        self._size_group.add_widget(self._drawing_area)
        self._overlay = Gtk.Overlay()
        self._overlay.set_child(self._drawing_area)
        self._overlay.set_hexpand(True)
        self._overlay.set_vexpand(True)
        self._overlay.set_halign(Gtk.Align.FILL)
        self._overlay.set_valign(Gtk.Align.FILL)
        self.append(self._overlay)

    def _on_drawing_area_resize(self, drawing_area, width, height):
        if not width == self._last_width or not height == self._last_height:
            self._last_width = width
            self._last_height = height
            self._events.trigger("resized", width, height)

    def get_child(self):
        return self._widget

    def set_child(self, widget):
        if self._widget:
            self._overlay.remove_overlay(self._widget)
            self._size_group.remove_widget(self._widget)
        self._widget = widget
        self._size_group.add_widget(widget)
        self._overlay.add_overlay(widget)

    def get_width(self):
        return self._last_width

    def get_height(self):
        return self._last_height

    def hook(self, event, callback, *args):
        self._events.hook(event, callback, *args)

    def release(self, id):
        self._events.release(id)


class ScrolledSqueezer(Gtk.Box):
    def __init__(self):
        super().__init__()
        self._widget = None
        self._max_height = 0
        self._scrolled_window = Gtk.ScrolledWindow()
        self._drawing_area = Gtk.DrawingArea()
        self._drawing_area.connect("realize", self._on_drawing_area_realize)
        self._drawing_area.connect("resize", self._on_drawing_area_resize)
        self._size_group = Gtk.SizeGroup()
        self._size_group.add_widget(self._drawing_area)
        self._overlay = Gtk.Overlay()
        self._overlay.add_overlay(self._scrolled_window)
        self._overlay.set_child(self._drawing_area)
        self.set_orientation(Gtk.Orientation.VERTICAL)
        self.append(self._overlay)

    def _on_drawing_area_realize(self, drawing_area):
        self._update_content_height()

    def _on_drawing_area_resize(self, drawing_area, width, height):
        self._update_content_height()

    def _after_update_content_height(self):
        if self._widget:
            additional_height = self._widget.get_margin_top() + self._widget.get_margin_bottom()
            height = self._widget.get_allocated_height() + additional_height
            max_height = self._max_height + additional_height
            if not height > max_height:
                self._scrolled_window.set_min_content_height(height)
                self._overlay.set_property("height-request", height)
            else:
                self._scrolled_window.set_min_content_height(max_height)
                self._overlay.set_property("height-request", max_height)

    def _update_content_height(self):
        self._after_update_content_height()
        GLib.idle_add(self._after_update_content_height)

    def get_max_height(self):
        return self._max_height

    def set_max_height(self, value):
        self._max_height = value
        self._update_content_height()

    def get_child(self):
        return self._widget

    def set_child(self, widget):
        if self._widget:
            self._widget.unparent()
            self._scrolled_window.set_child(None)
            self._size_group.remove_widget(self._widget)
        self._widget = widget
        self._widget.set_valign(Gtk.Align.START)
        self._size_group.add_widget(self._widget)
        self._scrolled_window.set_child(widget)
        self._update_content_height()


class MultiListBox(Gtk.Box):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._events = EventManager()
        self._events.add("row-activated", object, object)
        self._sort_data = {}
        self._order = []
        self._sections = {}
        self.set_orientation(Gtk.Orientation.VERTICAL)

    def _on_row_activated(self, list_box, row):
        self._events.trigger("row-activated", list_box, row)

    def _do_list_box_sort(self, row_1, row_2):
        items = [
            self._sort_data[row_1],
            self._sort_data[row_2]
        ]
        if items[0] == items[1]:
            return 0
        else:
            if sorted(items, key=str.lower)[0] == items[0]:
                return -1
            else:
                return 1

    def _update_separator_visible(self):
        sections_left = list(self._order)
        for section in reversed(self._order):
            has_children = self._sections[section]["list_box"].get_first_child()
            if section == sections_left[-1]:
                show_separator = False
            else:
                show_separator = has_children
            if not has_children:
                sections_left.remove(section)
            self._sections[section]["separator"].set_visible(show_separator)

    def get_visible_children(self):
        children = []
        for section in self._order:
            list_box = self._sections[section]["list_box"]
            child = list_box.get_first_child()
            if child:
                children.append(child)
                while True:
                    child = child.get_next_sibling()
                    if child:
                        children.append(child)
                    else:
                        break
        else:
            return children

    def get_first_child(self):
        for section in self._order:
            first_child = self._sections[section]["list_box"].get_first_child()
            if first_child:
                return first_child
        else:
            return None

    def get_pixel_height_for_n_rows(self, n_rows):
        first_child = self.get_first_child()
        if first_child:
            child_height = first_child.get_preferred_size()[1].height
        else:
            child_height = 0
        return child_height * n_rows

    def has_section(self, section):
        return section in self._sections

    def has_row(self, row, section):
        return row.get_parent() == self._sections[section]["list_box"]

    def append_section(self, name):
        if not name in self._sections:
            self._sections[name] = {
                "list_box": Gtk.ListBox(),
                "separator": Gtk.Separator(),
                "sort_data": []
            }
            self._order.append(name)
            self.append(self._sections[name]["list_box"])
            self.append(self._sections[name]["separator"])
            self._sections[name]["list_box"].set_sort_func(self._do_list_box_sort)
            self._sections[name]["list_box"].connect("row-activated", self._on_row_activated)
            self._update_separator_visible()
        else:
            raise ItemAlreadyExistingError(name)

    def remove_section(self, name):
        if name in self._sections:
            self.remove(self._sections[name]["list_box"])
            self.remove(self._sections[name]["separator"])
            del self._sections[name]
            self._order.remove(name)
            self._update_separator_visible()
        else:
            raise ItemNotFoundError(name)

    def append_row(self, widget, section, sort_data=None):
        if not self.has_row(widget, section):
            list_box = self._sections[section]["list_box"]
            self._sort_data[widget] = str(sort_data)
            list_box.append(widget)
            self._update_separator_visible()
        else:
            raise ItemAlreadyExistingError(widget)

    def remove_row(self, widget, section):
        if self.has_row(widget, section):
            list_box = self._sections[section]["list_box"]
            del self._sort_data[widget]
            list_box.remove(widget)
            self._update_separator_visible()
        else:
            raise ItemNotFoundError(widget)

    def hook(self, event, callback, *args):
        self._events.hook(event, callback, *args)

    def release(self, id):
        self._events.release(id)


class FocusGroup():
    def __init__(self):
        self._events = EventManager()
        self._events.add("changed", bool)
        self._focused = False
        self._widgets = {}

    def _on_focus_enter(self, controller):
        GLib.idle_add(self._after_focus_event)

    def _on_focus_leave(self, controller):
        GLib.idle_add(self._after_focus_event)

    def _after_focus_event(self):
        for widget in self._widgets:
            if widget.get_focus_child():
                focused = True
                break
        else:
            focused = False
        state_changed = not focused == self._focused
        self._focused = focused
        if state_changed:
            self._events.trigger("changed", focused)

    def get_focused(self):
        return self._focused

    def add(self, *widgets):
        for widget in widgets:
            self._widgets[widget] = {}
            controller = Gtk.EventControllerFocus()
            controller.connect("enter", self._on_focus_enter)
            controller.connect("leave", self._on_focus_leave)
            widget.add_controller(controller)
            self._widgets[widget]["controller"] = controller

    def remove(self, *widgets):
        for widget in widgets:
            del self._widgets[widget]

    def hook(self, event, callback, *args):
        self._events.hook(event, callback, *args)

    def release(self, id):
        self._events.release(id)
