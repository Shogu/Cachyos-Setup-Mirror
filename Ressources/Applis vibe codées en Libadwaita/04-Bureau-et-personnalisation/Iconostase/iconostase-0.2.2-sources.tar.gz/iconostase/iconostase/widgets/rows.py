# SPDX-License-Identifier: GPL-3.0-or-later
# D'après libre-menu-editor (© 2022 Free Software Foundation).
import os
import re

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Pango, GLib, Gio, Gtk, Adw  # noqa: E402

from ..core.events import EventManager
from ..core.exec_escape import DesktopEntryCommandArgEscaper
from .constants import Keyval, Margin, Spacing
from .errors import ItemNotFoundError
from .icons import IconBrowser, IconView
from .layout import FocusGroup, MultiListBox


class RevealerRow(Adw.PreferencesRow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._ignore_toggle_button_toggled = False
        self._toggle_button = Gtk.ToggleButton()
        self._toggle_button.connect("toggled", self._on_toggle_button_toggled)
        self._stack = Gtk.Stack()
        self._stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        self._stack.set_transition_duration(90)
        self._revealer_box = Gtk.Box()
        self._revealer_box.set_vexpand(True)
        self._revealer_box.set_orientation(Gtk.Orientation.VERTICAL)
        self._revealer_box.append(self._stack)
        self._revealer = Gtk.Revealer()
        self._revealer.set_transition_duration(300)
        self._revealer.connect("notify::reveal-child", self._on_revealer_reveal_child_changed)
        self._revealer.connect("notify::child-revealed", self._on_revealer_child_revealed_changed)
        self._revealer.set_child(self._revealer_box)
        self.set_activatable(False)
        self.set_active(True)
        self.set_child(self._revealer)

    def _on_toggle_button_toggled(self, toggle_button):
        if not self._ignore_toggle_button_toggled:
            self._revealer.set_reveal_child(toggle_button.get_active())

    def _on_revealer_reveal_child_changed(self, revealer, gparam):
        self._ignore_toggle_button_toggled = True
        self._toggle_button.set_active(self._revealer.get_reveal_child())
        self._ignore_toggle_button_toggled = False
        if self._revealer.get_reveal_child():
            self.show()

    def _on_revealer_child_revealed_changed(self, revealer, gparam):
        if not self._revealer.get_child_revealed():
            self.hide()

    def get_active(self):
        return self._revealer.get_reveal_child()

    def set_active(self, value):
        self._revealer.set_reveal_child(value)

    def get_page(self):
        return self._stack.get_visible_child()

    def set_page(self, child):
        if isinstance(child, Gtk.StackPage):
            child = child.get_child()
        self._stack.set_visible_child(child)

    def add_page(self, child):
        self._stack.add_named(child, str(child))

    def remove_page(self, child):
        self._stack.remove(child)

    def get_revealer(self):
        return self._revealer

    def get_stack(self):
        return self._stack

    def get_toggle_button(self):
        return self._toggle_button

    def append(self, widget):
        self._revealer_box.append(widget)

    def remove(self, widget):
        self._revealer_box.remove(widget)


class IconViewRow(RevealerRow):
    def __init__(self, app, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._icon_view = IconView(app)
        self._prefix_box = Gtk.Box()
        self._suffix_box = Gtk.Box()
        for box in [self._prefix_box, self._suffix_box]:
            box.set_margin_top(Margin.LARGE)
            box.set_margin_bottom(Margin.LARGE)
            box.set_margin_start(Margin.LARGE)
            box.set_margin_end(Margin.LARGE)
            box.set_spacing(Spacing.DEFAULT)
        self.remove(self._stack)
        self._center_box = Gtk.CenterBox()
        self._center_box.set_start_widget(self._prefix_box)
        self._center_box.set_end_widget(self._suffix_box)
        self._center_box.set_center_widget(self._stack)
        self._revealer.set_child(self._center_box)
        self.add_css_class("view")
        self.add_page(self._icon_view)

    def get_icon_view(self):
        return self._icon_view

    def add_prefix(self, child):
        self._prefix_box.append(child)

    def add_suffix(self, child):
        self._suffix_box.append(child)


class IconBrowserRow(RevealerRow):
    def __init__(self, app, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._icon_finder = app.get_icon_finder()
        self._icon_browser = IconBrowser(app)
        self._icon_browser.set_vexpand(True)
        self._bottom_separator = Gtk.Separator()
        self._bottom_separator.set_vexpand(False)
        self._toolbar = self._icon_browser.get_toolbar()
        self._toolbar.set_vexpand(False)
        self._style_manager = Adw.StyleManager.get_default()
        self._style_manager.connect("notify::dark", self._on_style_manager_dark_changed)
        self._stack.connect("notify::visible-child", self._on_stack_visible_child_changed)
        self.add_page(self._icon_browser)
        self.append(self._bottom_separator)
        self.append(self._toolbar)
        self._default_inner_margin_bottom = self._icon_browser.get_inner_margin_bottom()
        self._update_bottom_separator_visibility()

    def _on_style_manager_dark_changed(self, style_manager, gparam):
        self._update_bottom_separator_visibility()

    def _update_bottom_separator_visibility(self):
        dark_mode_enabled = self._style_manager.get_dark()
        self._bottom_separator.set_visible(dark_mode_enabled == False)
        self._icon_browser.set_inner_margin_bottom(self._default_inner_margin_bottom * (bool(dark_mode_enabled)))

    def _on_stack_visible_child_changed(self, stack, gparam):
        self._toolbar.set_sensitive(self._stack.get_visible_child() == self._icon_browser)

    def get_icon_browser(self):
        return self._icon_browser


class EntryRow(Adw.EntryRow):
    def __init__(self, app, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._icon_finder = app.get_icon_finder()
        self._events = EventManager()
        self._events.add("text-changed", object, str)
        self._event_controller_focus = Gtk.EventControllerFocus()
        self._event_controller_focus.connect("leave", self._on_event_controller_focus_leave)
        self._editable = self.get_delegate()
        self._editable.add_controller(self._event_controller_focus)
        self.set_enable_undo(True)
        self.connect("changed", self._on_changed)

    def _on_event_controller_focus_leave(self, controller):
        self.select_region(0, 0)

    def _on_changed(self, editable):
        text = editable.get_text()
        self._events.trigger("text-changed", self, text)

    def hook(self, event, callback, *args):
        self._events.hook(event, callback, *args)

    def release(self, id):
        self._events.release(id)


class PathChooserRow(EntryRow):
    def __init__(self, app, action, button_image="document-open-symbolic", *args, **kwargs):
        super().__init__(app, *args, **kwargs)
        self._icon_finder = app.get_icon_finder()
        self._application_window = app.get_application_window()
        self._default_image = self._icon_finder.get_image(button_image)
        self._chooser_button_event_controller_key = Gtk.EventControllerKey()
        self._chooser_button_event_controller_key.connect(
            "key-pressed", self._on_chooser_button_event_controller_key_pressed
        )
        self._chooser_button = Gtk.Button()
        self._chooser_button.set_focus_on_click(False)
        self._chooser_button.add_css_class("flat")
        self._chooser_button.set_valign(Gtk.Align.CENTER)
        self._chooser_button.connect("clicked", self._on_chooser_button_clicked)
        self._chooser_button.add_controller(self._chooser_button_event_controller_key)
        self._chooser_button.set_child(self._default_image)
        self._choose_folder = action == Gtk.FileChooserAction.SELECT_FOLDER
        self._file_dialog = Gtk.FileDialog(modal=True, initial_folder=Gio.File.new_for_path(GLib.get_home_dir()))
        self.add_suffix(self._chooser_button)

    def _on_chooser_button_event_controller_key_pressed(self, controller, keyval, keycode, state):
        text = self._editable.get_text()
        if not keyval == Keyval.ENTER:
            self._editable.set_position(-1)
            controller.forward(self._editable)
            if not text == self._editable.get_text():
                if not self._editable.has_focus():
                    self._editable.grab_focus_without_selecting()
                return True

    def _on_file_dialog_finished(self, dialog, result):
        try:
            file = dialog.select_folder_finish(result) if self._choose_folder else dialog.open_finish(result)
        except GLib.GError:
            return
        self._on_file_chosen(file.get_path())

    def _on_file_chosen(self, path):
        self.set_text(path)

    def _on_chooser_button_clicked(self, button):
        if self._choose_folder:
            self._file_dialog.select_folder(self._application_window, None, self._on_file_dialog_finished)
        else:
            self._file_dialog.open(self._application_window, None, self._on_file_dialog_finished)

    def set_dialog_accept_button_label(self, text):
        self._file_dialog.set_accept_label(text)

    def set_dialog_title(self, text):
        self._file_dialog.set_title(text)

    def get_chooser_button(self):
        return self._chooser_button


class FileChooserRow(PathChooserRow):
    def __init__(self, app, *args, **kwargs):
        super().__init__(app, action=Gtk.FileChooserAction.OPEN, *args, **kwargs)


class DirectoryChooserRow(PathChooserRow):
    def __init__(self, app, *args, **kwargs):
        super().__init__(app, action=Gtk.FileChooserAction.SELECT_FOLDER, button_image="folder-open-symbolic", *args, **kwargs)
        self._fallback_path = None
        self._has_focus = False
        self._event_controller_focus = Gtk.EventControllerFocus()
        self._event_controller_focus.connect("enter", self._on_event_controller_focus_enter)
        self._event_controller_focus.connect("leave", self._on_event_controller_focus_leave)
        self.add_controller(self._event_controller_focus)

    def _on_changed(self, editable):
        text = editable.get_text()
        if not len(text) or self._get_is_fallback_path(text):
            text = self._fallback_path
        self._events.trigger("text-changed", self, text)
        if len(text):
            if os.path.exists(text) and os.path.isdir(text) and os.access(text, os.R_OK):
                self.remove_css_class("error")
            else:
                self.add_css_class("error")
        else:
            self.remove_css_class("error")

    def _update_fallback_path_visible(self):
        if not self._has_focus and (not len(self.get_text()) or self._get_is_fallback_path()):
            self.set_text(self._fallback_path)

    def _get_is_fallback_path(self, path=None):
        if path is None:
            path = self.get_text()
        try:
            return os.path.samefile(path, self._fallback_path)
        except FileNotFoundError:
            return False

    def _on_event_controller_focus_leave(self, controller):
        self._has_focus = False
        self._update_fallback_path_visible()

    def _on_event_controller_focus_enter(self, controller):
        self._has_focus = True
        self._update_fallback_path_visible()

    def get_fallback_path(self):
        return self._fallback_path

    def set_fallback_path(self, path):
        self._fallback_path = path
        self._update_fallback_path_visible()


class IconChooserRow(FileChooserRow):
    def __init__(self, app, *args, **kwargs):
        super().__init__(app, *args, **kwargs)
        self._events.add("file-chosen", object, str)
        image_filter = Gtk.FileFilter(name=_("Images"))
        image_filter.add_mime_type("image/svg+xml")
        image_filter.add_mime_type("image/png")
        filters = Gio.ListStore.new(Gtk.FileFilter)
        filters.append(image_filter)
        self._file_dialog.set_filters(filters)
        self._icon_finder = app.get_icon_finder()
        self._ignore_text_changed = False
        self._default_entry_title = None
        self._search_entry_title = None
        self._ignore_first_empty_text = False
        self._search_mode = False
        self._previous_text = ""
        self._help_status_page = Adw.StatusPage()
        self._help_status_page.set_can_focus(False)
        self._help_status_page.add_css_class("view")
        self._none_status_page = Adw.StatusPage()
        self._none_status_page.set_can_focus(False)
        self._none_status_page.add_css_class("view")
        self._icon_view_row = IconViewRow(app)
        self._icon_view_row.set_active(True)
        self._icon_view_row.set_visible(True)
        self._icon_view = self._icon_view_row.get_icon_view()
        self._icon_view.hook("updated", self._on_icon_view_updated)
        self._icon_browser_row = IconBrowserRow(app)
        self._icon_browser_row.set_active(False)
        self._icon_browser_row.set_visible(False)
        self._icon_browser = self._icon_browser_row.get_icon_browser()
        self._icon_browser.hook("drawing-icons", self._on_icon_browser_drawing_icons)
        self._icon_browser.hook("updated", self._on_icon_browser_updated)
        self._icon_browser.hook("item-selected", self._on_icon_browser_item_selected)
        self._icon_browser_row.add_page(self._help_status_page)
        self._icon_browser_row.add_page(self._none_status_page)
        self.remove(self._chooser_button)
        self._chooser_button.set_valign(Gtk.Align.START)
        self._toggle_button = self._icon_browser_row.get_toggle_button()
        self._toggle_button.set_focus_on_click(False)
        self._toggle_button.connect("toggled", self._on_toggle_button_toggled)
        self._toggle_button.set_icon_name(self._icon_finder.get_name("system-search-symbolic"))
        self._toggle_button.set_valign(Gtk.Align.START)
        self._toggle_button.add_css_class("flat")
        self._icon_view_row.add_prefix(self._chooser_button)
        self._icon_view_row.add_suffix(self._toggle_button)
        self._entry_event_controller_key = Gtk.EventControllerKey()
        self._entry_event_controller_key.connect("key-pressed", self._on_event_controllers_key_pressed)
        self._view_event_controller_key = Gtk.EventControllerKey()
        self._view_event_controller_key.connect("key-pressed", self._on_event_controllers_key_pressed)
        self._browser_event_controller_key = Gtk.EventControllerKey()
        self._browser_event_controller_key.connect("key-pressed", self._on_event_controllers_key_pressed)
        self._icon_view_row.add_controller(self._view_event_controller_key)
        self._icon_browser_row.add_controller(self._browser_event_controller_key)
        self.add_controller(self._entry_event_controller_key)
        self.get_delegate().connect("activate", self._on_activate)

    def _on_chooser_button_clicked(self, button):
        self.set_search_mode(False)
        FileChooserRow._on_chooser_button_clicked(self, button)

    def _on_file_chosen(self, path):
        self._events.trigger("file-chosen", self, path)

    def _on_event_controllers_key_pressed(self, controller, keyval, keycode, state):
        if keyval == Keyval.ESCAPE and state == 0:
            self.set_search_mode(self.get_search_mode() == False)
            self.grab_focus_without_selecting()

    def _on_toggle_button_toggled(self, toggle_button):
        self.set_search_mode(self._toggle_button.get_active())
        self.grab_focus_without_selecting()

    def _on_activate(self, entry):
        if not self.get_search_mode():
            self.set_search_mode(True)
        else:
            if self._icon_browser_row.get_page() == self._icon_browser and len(self._icon_browser.get_results()):
                self._icon_browser_row.grab_focus()
            else:
                self.set_search_mode(False)

    def _on_changed(self, entry):
        text = entry.get_text()
        if not len(text) and self._ignore_first_empty_text:
            self._ignore_first_empty_text = False
            return
        if not self._search_mode:
            self._previous_text = text
            self._events.trigger("text-changed", self, text)
            self._icon_view.update(text)
        elif not self._ignore_text_changed:
            self._icon_browser.update(text)
        else:
            self._ignore_text_changed = False

    def _on_icon_view_updated(self, event, update_successful):
        if self._icon_view.get_update_successful():
            self.remove_css_class("warning")
        else:
            self.add_css_class("warning")

    def _on_icon_browser_updated(self, event, results):
        if self._search_mode:
            if len(results):
                self.remove_css_class("warning")
                self._icon_browser_row.set_page(self._icon_browser)
            else:
                if len(self.get_text()):
                    self.add_css_class("warning")
                    self._icon_browser_row.set_page(self._none_status_page)
                else:
                    self.remove_css_class("warning")
                    self._icon_browser_row.set_page(self._help_status_page)

    def _on_icon_browser_drawing_icons(self, event):
        self.remove_css_class("warning")
        self._icon_browser_row.set_page(self._icon_browser)

    def _on_icon_browser_item_selected(self, event, text):
        self._previous_text = text
        self.set_search_mode(False)
        self.grab_focus_without_selecting()

    def get_search_mode(self):
        return self._search_mode

    def set_search_mode(self, value):
        self._search_mode = value
        if value:
            self._ignore_text_changed = True
            self.set_text("")
            self._ignore_text_changed = False
            self.remove_css_class("warning")
            if self._search_entry_title:
                self.set_title(self._search_entry_title)
            self._icon_browser_row.set_page(self._help_status_page)
            self._icon_browser_row.set_active(True)
        else:
            if not len(self.get_text()):
                self.add_css_class("warning")
            if self._default_entry_title:
                self.set_title(self._default_entry_title)
            self._icon_browser_needs_cleanup = True
            self._icon_browser_row.set_active(False)
            self.set_text(self._previous_text)

    def get_default_entry_title(self):
        return self._default_entry_title

    def set_default_entry_title(self, text):
        self._default_entry_title = text
        if not self._search_mode:
            self.set_title(text)

    def get_search_entry_title(self):
        return self._search_entry_title

    def set_search_entry_title(self, text):
        self._search_entry_title = text
        if self._search_mode:
            self.set_title(text)

    def get_icon_view_row(self):
        return self._icon_view_row

    def get_icon_browser_row(self):
        return self._icon_browser_row

    def get_help_status_page(self):
        return self._help_status_page

    def get_none_status_page(self):
        return self._none_status_page

    def set_text(self, text):
        if len(text):
            self._ignore_first_empty_text = True
        EntryRow.set_text(self, text)
        self._ignore_first_empty_text = False

    def grab_focus_without_selecting(self):
        self.grab_focus()
        self.set_position(-1)

    def reset(self):
        self._previous_text = ""
        self.set_search_mode(False)


class LinkConverterRow(Gtk.Box):
    def __init__(self, app, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._application = app
        self._icon_finder = app.get_icon_finder()
        self._group_focused = False
        self._entry_connection_id = None
        self._entry = None
        self._url_regex_patterns = [
            r"((http|ftp|https)://)?(([a-zA-Z0-9]{1,}[_-]{1})*[a-zA-Z0-9]{1,}\.)+([a-zA-Z0-9]{2,}){1}" +
            r"(/[a-zA-Z0-9\@\%\&\#\=\~\+\-\_\.\,\;\:\?\!\'\*\$()\[\]\/]+)?$",
        ]
        self._url_open_commands = [
            "xdg-open",
            "open",
            "x-www-browser",
            "gnome-open",
            "kde-open"
        ]
        for command in self._url_open_commands:
            if app.get_command_exists(command):
                self._url_open_command = command
                break
        else:
            self._url_open_command = None
        self._button_label = Gtk.Label()
        self._button_label.set_ellipsize(Pango.EllipsizeMode.END)
        self._button_image = self._icon_finder.get_image("system-run-symbolic")
        self._button_image.set_margin_end(Margin.DEFAULT)
        self._center_box = Gtk.CenterBox()
        self._center_box.set_margin_start(Margin.LARGE)
        self._center_box.set_margin_end(Margin.LARGE)
        self._center_box.set_start_widget(self._button_image)
        self._center_box.set_center_widget(self._button_label)
        self._button = Gtk.Button()
        self._button.add_css_class("accent")
        self._button.add_css_class("circular")
        self._button.set_focus_on_click(False)
        self._button.connect("clicked", self._on_button_clicked)
        self._button.set_child(self._center_box)
        self._clamp = Adw.Clamp(maximum_size=480, tightening_threshold=380)
        self._clamp.set_margin_top(Margin.LARGE)
        self._clamp.set_margin_bottom(Margin.LARGE)
        self._clamp.set_child(self._button)
        self._revealer = Gtk.Revealer()
        self._revealer.set_child(self._clamp)
        self._revealer.connect("notify::reveal-child", self._on_revealer_reveal_child_changed)
        self._revealer.connect("notify::child-revealed", self._on_revealer_child_revealed_changed)
        self._focus_group = FocusGroup()
        self._focus_group.hook("changed", self._on_focus_group_changed)
        self._focus_group.add(self)
        self.set_visible(False)
        self.set_orientation(Gtk.Orientation.VERTICAL)
        self.append(self._revealer)

    def _on_focus_group_changed(self, event, focused):
        self._group_focused = focused
        self._update_widgets()

    def _on_button_clicked(self, button):
        self._convert_url_to_command()
        self._update_widgets()

    def _on_entry_changed(self, entry):
        self._update_widgets()

    def _on_revealer_reveal_child_changed(self, revealer, gparam):
        if self._revealer.get_reveal_child():
            self.show()

    def _on_revealer_child_revealed_changed(self, revealer, gparam):
        if not self._revealer.get_child_revealed():
            self.hide()

    def _update_widgets(self):
        if self._url_open_command:
            text = self._entry.get_text()
            if self._application.get_command_exists(text, desktop_entry=True):
                self._revealer.set_reveal_child(False)
                self._entry.remove_css_class("error")
                if not text.split(" ")[0] in self._url_open_commands and self._group_focused:
                    self._revealer.set_reveal_child(True)
            else:
                self._revealer.set_reveal_child(True)
                self._entry.add_css_class("error")
            if self._get_string_is_valid_url(text.strip()):
                self._entry.add_css_class("warning")
                self._entry.remove_css_class("error")
                self._button.add_css_class("accent")
                self.set_sensitive(True)
            else:
                self._entry.remove_css_class("warning")
                self._button.remove_css_class("accent")
                self.set_sensitive(False)

    def _convert_url_to_command(self):
        text = self._entry.get_text().strip()
        if text.startswith("http://"):
            text = text.replace("http://", "https://")
        elif not text.startswith("https://"):
            text = f"https://{text}"
        self._entry.set_text(f"{self._url_open_command} {text}")
        self._entry.grab_focus_without_selecting()
        self._entry.set_position(-1)

    def _get_string_is_valid_url(self, text):
        if not " " in text and not self._application.get_command_exists(text, desktop_entry=True, include_lookup_cwd=True):
            for pattern in self._url_regex_patterns:
                if re.match(pattern, text):
                    return True

    def get_entry(self, entry):
        return self._entry

    def set_entry(self, entry):
        if not self._entry == None:
            self._entry.dicsonnect(self._entry_connection_id)
        self._entry = entry
        self._entry_connection_id = self._entry.connect("changed", self._on_entry_changed)
        self._focus_group.add(entry)
        self._on_entry_changed(self._entry)

    def get_label(self):
        return self._button_label.get_text()

    def set_label(self, text):
        self._button_label.set_text(text)


class CommandChooserRow(FileChooserRow):
    def __init__(self, app, *args, **kwargs):
        super().__init__(app, *args, **kwargs)
        self._application = app
        self._command_arg_escaper = DesktopEntryCommandArgEscaper()
        self.add_css_class("error")

    def _on_file_chosen(self, path):
        self.set_text(self._command_arg_escaper.get_escaped_arg(path))

    def _on_changed(self, editable):
        text = editable.get_text()
        self._events.trigger("text-changed", self, text)
        if not len(text.strip()):
            self.add_css_class("error")
        elif not self._application.get_command_exists(text, desktop_entry=True, skip_empty_path=True, include_lookup_cwd=True):
            self.add_css_class("error")
        else:
            self.remove_css_class("error")


class DeleteRow(Adw.ActionRow):
    def __init__(self, app, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._icon_finder = app.get_icon_finder()
        self._delete_button = Gtk.Button()
        self._delete_button.set_icon_name(self._icon_finder.get_name("edit-delete-symbolic"))
        self._delete_button.add_css_class("flat")
        self._delete_button.set_can_focus(False)
        self._delete_button.set_can_target(False)
        self._delete_button.set_valign(Gtk.Align.CENTER)
        self.add_css_class("warning")
        self.set_activatable(True)
        self.add_suffix(self._delete_button)

    def get_text(self, text):
        return self.get_subtitle()

    def set_text(self, text):
        if len(text):
            self.add_css_class("property")
        else:
            self.remove_css_class("property")
        self.set_subtitle(text)


class SwitchRow(Adw.ActionRow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._events = EventManager()
        self._events.add("value-changed", object, bool)
        self._switch = Gtk.Switch()
        self._switch.set_can_focus(False)
        self._switch.set_valign(Gtk.Align.CENTER)
        self._switch.connect("notify::active", self._on_switch_active_changed)
        self.set_activatable(True)
        self.connect("activated", self._on_activated)
        self.add_suffix(self._switch)

    def _on_activated(self, action_row):
        self._switch.activate()

    def _on_switch_active_changed(self, switch, property):
        self._events.trigger("value-changed", self, switch.get_active())

    def get_switch(self):
        return self._switch

    def set_switch(self, switch):
        self._remove(self._switch)
        self._add_suffix(switch)
        self._switch = switch

    def get_active(self):
        return self._switch.get_active()

    def set_active(self, value):
        self._switch.set_active(value)

    def hook(self, event, callback, *args):
        self._events.hook(event, callback, *args)

    def release(self, id):
        self._events.release(id)


class ComboRow(Adw.ActionRow):
    def __init__(self, app, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._events = EventManager()
        self._events.add("item-selected", object, str)
        self._icon_finder = app.get_icon_finder()
        self._icon_finder.hook("changed", self._on_icon_finder_changed)
        self._display_n_buttons = 10
        self._flow_row = None
        self._buttons = {}
        self._multi_list_box = MultiListBox()
        self._multi_list_box.hook("row-activated", self._on_multi_list_box_row_activated)
        self._multi_list_box.set_margin_top(Margin.DEFAULT)
        self._multi_list_box.set_margin_bottom(Margin.DEFAULT)
        self._multi_list_box.set_margin_start(Margin.DEFAULT)
        self._multi_list_box.set_margin_end(Margin.DEFAULT)
        self._scrolled_window = Gtk.ScrolledWindow()
        self._scrolled_window.set_propagate_natural_height(True)
        self._scrolled_window.set_propagate_natural_width(True)
        self._scrolled_window.set_child(self._multi_list_box)
        self._popover = Gtk.Popover()
        self._popover.set_offset(-Margin.DEFAULT, 0)
        self._popover.set_valign(Gtk.Align.END)
        self._popover.add_css_class("menu")
        self._popover.connect("show", self._on_popover_show)
        self._popover.connect("closed", self._on_popover_closed)
        self._popover.set_child(self._scrolled_window)
        self._menu_button = Gtk.MenuButton()
        self._menu_button.add_css_class("flat")
        self._menu_button.set_icon_name(self._icon_finder.get_name("list-add-symbolic"))
        self._menu_button.set_direction(Gtk.ArrowType.LEFT)
        self._menu_button.set_valign(Gtk.Align.CENTER)
        self._menu_button.set_popover(self._popover)
        self.add_suffix(self._menu_button)
        self.connect("activated", self._on_activate)
        self.set_activatable(True)

    def _on_popover_show(self, popover):
        child = self._popover.get_child()
        self._popover.set_child(None)
        self._popover.set_child(child)
        self._update_buttons_sensitive()
        first_button = self._multi_list_box.get_first_child()
        if first_button:
            first_button.grab_focus()
        self._update_scrolled_window_height()

    def _on_popover_closed(self, popover):
        if self._menu_button.get_sensitive():
            self._menu_button.grab_focus()
        elif self._flow_row:
            self._flow_row.grab_focus()
        else:
            self.grab_focus()
        self._update_scrolled_window_height()

    def _on_icon_finder_changed(self, event, icon_finder):
        GLib.idle_add(self._update_buttons_icon_names)

    def _on_activate(self, *args):
        self._popover.popup()

    def _on_multi_list_box_row_activated(self, event, list_box, row):
        self._update_buttons_sensitive()
        self._events.trigger("item-selected", row.name, row.label.get_text())
        self._popover.popdown()

    def _on_flow_row_text_changed(self, event, child, data):
        self._update_buttons_sensitive()
        GLib.idle_add(self._update_buttons_icon_names)

    def _update_buttons_icon_names(self):
        for button in self._buttons.values():
            button.image.set_from_icon_name(button.icon_name)
        buttons = {}
        for button in self._buttons.values():
            buttons[button.label.get_text()] = button
        tags = {}
        for tag in self._flow_row.get_tags():
            tags[tag.get_text()] = tag
        for text in tags:
            if text in buttons:
                tags[text].set_icon_name(buttons[text].image.get_icon_name())
        self._update_scrolled_window_height()

    def _update_scrolled_window_height(self):
        height = self._multi_list_box.get_pixel_height_for_n_rows(self._display_n_buttons)
        self._scrolled_window.set_max_content_height(height + (2 * Margin.DEFAULT))

    def _update_buttons_sensitive(self):
        tag_texts = [tag.get_text() for tag in self._flow_row.get_tags()]
        for name in self._buttons:
            button = self._buttons[name]
            if not button.label.get_text() in tag_texts:
                if not self._multi_list_box.has_row(button, button.section):
                    self._multi_list_box.append_row(button, button.section, sort_data=button.label.get_text())
            else:
                if self._multi_list_box.has_row(button, button.section):
                    self._multi_list_box.remove_row(button, button.section)
        self._menu_button.set_sensitive(len(self._multi_list_box.get_visible_children()))

    def get_display_n_buttons(self):
        return self._display_n_buttons

    def set_display_n_buttons(self, n_buttons):
        self._display_n_buttons = n_buttons
        self._update_scrolled_window_height()

    def add_button(self, name, text, icon_name=None, section="default"):
        button = Gtk.ListBoxRow()
        button.image = Gtk.Image()
        button.image.set_margin_end(Margin.DEFAULT)
        button.label = Gtk.Label()
        button.label.set_text(text)
        button.box = Gtk.Box()
        button.box.append(button.image)
        button.box.append(button.label)
        button.set_child(button.box)
        button.set_activatable(True)
        button.name = name
        button.icon_name = icon_name
        button.section = section
        self._buttons[name] = button
        if not self._multi_list_box.has_section(section):
            self._multi_list_box.append_section(section)
        self._update_buttons_icon_names()
        self._update_buttons_sensitive()

    def remove_button(self, name, section="default"):
        button = self._buttons.pop(name)
        try:
            self._multi_list_box.remove_row(button, section)
        except ItemNotFoundError:
            pass
        self._update_buttons_sensitive()

    def get_buttons(self):
        return list(self._buttons.keys())

    def get_flow_row(self):
        return self._flow_row

    def set_flow_row(self, flow_row):
        flow_row.hook("text-changed", self._on_flow_row_text_changed)
        self._flow_row = flow_row

    def hook(self, event, callback, *args):
        self._events.hook(event, callback, *args)

    def release(self, id):
        self._events.release(id)
