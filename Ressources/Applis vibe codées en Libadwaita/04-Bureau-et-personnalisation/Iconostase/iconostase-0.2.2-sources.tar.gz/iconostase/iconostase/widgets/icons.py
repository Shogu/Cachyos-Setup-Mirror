# SPDX-License-Identifier: GPL-3.0-or-later
# D'après libre-menu-editor (© 2022 Free Software Foundation).
import os
import threading

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Pango, GObject, GLib, Gio, Gdk, Gtk  # noqa: E402

from ..core.events import EventManager
from .constants import Margin
from .errors import IconNotFoundError, IconSizeNotSupportedError
from .layout import FlowingToolbar, ResizeFrame


class IconFinder():
    def __init__(self, app):
        self._events = EventManager()
        self._events.add("changed", object)
        self._application = app
        self._application_window = app.get_application_window()
        self._legacy_icons = {}
        self._icon_theme = Gtk.IconTheme.get_for_display(self._application_window.get_display())
        self._icon_theme.connect("changed", self._on_icon_theme_changed)
        self._load_legacy_icons(*self._icon_theme.get_search_path())

    def _on_icon_theme_changed(self, icon_theme):
        self._events.trigger("changed", self)

    def _load_legacy_icons(self, *paths):
        for path in paths:
            if os.path.exists(path):
                for name in os.listdir(path):
                    icon_path = os.path.join(path, name)
                    if os.path.isfile(icon_path):
                        self._legacy_icons[".".join(name.split(".")[:-1])] = icon_path
                        self._legacy_icons[name] = icon_path

    def get_search_paths(self):
        return self._icon_theme.get_search_path()

    def add_search_paths(self, *paths):
        for path in paths:
            if not path in self._icon_theme.get_search_path():
                self._icon_theme.add_search_path(path)
                self._load_legacy_icons(path)

    def get_image(self, icon, missing_ok=True, allow_symbolic=True):
        image = Gtk.Image()
        self.set_image(image, icon, missing_ok=missing_ok, allow_symbolic=allow_symbolic)
        return image

    def set_image(self, image, icon, missing_ok=True, allow_symbolic=True):
        try:
            name = self.get_name(icon, missing_ok=False, allow_symbolic=allow_symbolic)
            image.set_from_icon_name(name)
            return True
        except IconNotFoundError:
            if icon in self._legacy_icons:
                icon = self._legacy_icons[icon]
            elif not icon.endswith("-symbolic") and f"{icon}-symbolic" in self._legacy_icons:
                icon = self._legacy_icons[f"{icon}-symbolic"]
            if os.path.exists(icon) and os.path.isfile(icon) and os.access(icon, os.R_OK):
                try:
                    texture = Gdk.Texture.new_from_filename(icon)
                except GLib.GError:
                    pass
                else:
                    image.set_from_paintable(texture)
                    return True
            elif missing_ok:
                if not os.path.sep in icon:
                    image.set_from_icon_name(icon)
                else:
                    image.set_from_file(icon)
                return False
            else:
                raise IconNotFoundError(icon)

    def get_name(self, name, missing_ok=True, allow_symbolic=True):
        if self._icon_theme.has_icon(name):
            return name
        if allow_symbolic and not name.endswith("-symbolic") and self._icon_theme.has_icon(f"{name}-symbolic"):
            return f"{name}-symbolic"
        if missing_ok:
            return name
        raise IconNotFoundError(name)

    def has_name(self, name, allow_symbolic=True):
        try:
            return self.get_name(name, missing_ok=False, allow_symbolic=allow_symbolic)
        except IconNotFoundError:
            return False

    def get_names(self):
        return self._icon_theme.get_icon_names()

    def get_theme(self):
        return self._icon_theme

    def hook(self, event, callback, *args):
        self._events.hook(event, callback, *args)

    def release(self, id):
        self._events.release(id)


class IconView(Gtk.CenterBox):
    def __init__(self, app, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._update_successful = None
        self._events = EventManager()
        self._events.add("updated", bool)
        self._icon_finder = app.get_icon_finder()
        self._icon_finder.hook("changed", self._on_icon_finder_changed)
        self._previous_text = ""
        self.set_image(Gtk.Image())
        self.set_hexpand(True)
        self.add_css_class("view")

    def _on_icon_finder_changed(self, event, icon_finder):
        self.update(self._previous_text)

    def _update_idle_target(self, text):
        try:
            self._icon_finder.set_image(self._icon_image, text, missing_ok=False)
            update_successful = True
        except IconNotFoundError:
            self._icon_image.clear()
            update_successful = False
        self._update_successful = update_successful
        self._events.trigger("updated", update_successful)

    def get_image(self):
        return self._icon_image

    def set_image(self, image):
        self._icon_image = image
        self._icon_image.set_pixel_size(128)
        self._icon_image.set_margin_top(Margin.LARGER)
        self._icon_image.set_margin_bottom(Margin.LARGER)
        self.set_center_widget(self._icon_image)

    def get_update_successful(self):
        return self._update_successful

    def update(self, text):
        self._previous_text = text
        GLib.idle_add(self._update_idle_target, text)

    def hook(self, event, callback, *args):
        self._events.hook(event, callback, *args)

    def release(self, id):
        self._events.release(id)


class IconName(GObject.Object):
    name = GObject.Property(type=str)

    def __init__(self, name):
        super().__init__()
        self.name = name


class LabeledImage(Gtk.Box):
    def __init__(self, max_label_width=192, breakpoint=192, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._image = Gtk.Image()
        self._label = Gtk.Label()
        self._image.set_hexpand(False)
        self._label.set_hexpand(True)
        self._label.set_ellipsize(Pango.EllipsizeMode.END)
        self._max_label_width = max_label_width
        self._breakpoint = breakpoint
        self.append(self._image)
        self.append(self._label)

    def set_pixel_size(self, value):
        if value >= self._breakpoint:
            self.set_orientation(Gtk.Orientation.VERTICAL)
            self.set_property("width-request", value)
            self._label.set_halign(Gtk.Align.CENTER)
            self._label.set_margin_top(Margin.DEFAULT)
            self._label.set_margin_start(0)
            self._label.set_margin_end(0)
        else:
            self.set_orientation(Gtk.Orientation.HORIZONTAL)
            total_width = value + self._max_label_width + self._label.get_margin_start() + self._label.get_margin_end()
            self.set_property("width-request", total_width)
            self._label.set_halign(Gtk.Align.START)
            self._label.set_margin_top(0)
            self._label.set_margin_start(Margin.DEFAULT)
            self._label.set_margin_end(Margin.DEFAULT)
        self._image.set_pixel_size(value)

    def set_from_icon_name(self, icon_name):
        self._image.set_from_icon_name(icon_name)
        self._label.set_text(icon_name)


class IconBrowser(Gtk.Box):
    def __init__(self, app, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._icon_finder = app.get_icon_finder()
        self._events = EventManager()
        self._events.add("drawing-icons")
        self._events.add("updated", object)
        self._events.add("item-selected", str)
        self._icon_sizes = [16, 24, 32, 48, 64, 96, 128, 192, 256]
        self._control_widgets_min_width = 0
        self._grid_view_list_item_border_width = 3
        self._default_inner_margin = Margin.DEFAULT
        self._image_margin = Margin.SMALLEST
        self._icon_names = []
        self._string_separator = ";"
        self._keyword_separator = " "
        self._last_text = ""
        self._search_string = ""
        self._results_cache = {}
        self._max_cached_results = 10
        self._results_key = None
        self._results_limit = 10000
        self._start_search_timeout_id = None
        self._lower_string = ""
        self._search_delay = 60
        self._name_slices = []
        self._slice_length = 10
        self._search_id = 0
        self._operations = {}
        self._current_grid_child_class = Gtk.Image
        self._current_grid_child_icon_size = 64
        self._add_new_list_store(self._search_id)
        self._factory = Gtk.SignalListItemFactory()
        self._factory.connect("setup", self._on_factory_setup)
        self._factory.connect("bind", self._on_factory_bind)
        self._factory.connect("unbind", self._on_factory_unbind)
        self._grid_view = Gtk.GridView()
        self._grid_view.set_hexpand(True)
        self._grid_view.set_halign(Gtk.Align.FILL)
        self._grid_view.set_single_click_activate(True)
        self._grid_view.set_margin_top(self._default_inner_margin)
        self._grid_view.set_margin_bottom(self._default_inner_margin)
        self._grid_view.set_margin_start(self._default_inner_margin)
        self._grid_view.set_margin_end(self._default_inner_margin)
        self._grid_view.set_tab_behavior(Gtk.ListTabBehavior.CELL)
        self._grid_view.connect("activate", self._on_grid_view_activate)
        self._grid_view.set_factory(self._factory)
        self._scrolled_window = Gtk.ScrolledWindow()
        self._scrolled_window.set_child(self._grid_view)
        self._resize_frame = ResizeFrame()
        self._resize_frame.set_child(self._scrolled_window)
        self._resize_frame.set_property("height-request",
                                        self._icon_sizes[-1] +
                                        self.get_inner_margin_top() +
                                        self.get_inner_margin_bottom() +
                                        (self._grid_view_list_item_border_width * 2) +
                                        (self._image_margin * 2) +
                                        Gtk.Label().get_preferred_size()[1].height +
                                        Margin.DEFAULT
                                        )
        self._resize_frame.hook("resized", self._on_resize_frame_resized)
        self._resize_frame.add_css_class("view")
        self._icon_size_increase_button = Gtk.Button()
        self._icon_size_increase_button.set_hexpand(False)
        self._icon_size_increase_button.set_focus_on_click(False)
        self._icon_size_increase_button.add_css_class("flat")
        self._icon_size_increase_button.connect("clicked", self._on_icon_size_increase_button_clicked)
        self._icon_size_increase_button.set_child(self._icon_finder.get_image("list-add-symbolic"))
        self._icon_size_decrease_button = Gtk.Button()
        self._icon_size_decrease_button.set_hexpand(False)
        self._icon_size_decrease_button.set_focus_on_click(False)
        self._icon_size_decrease_button.add_css_class("flat")
        self._icon_size_decrease_button.connect("clicked", self._on_icon_size_decrease_button_clicked)
        self._icon_size_decrease_button.set_child(self._icon_finder.get_image("list-remove-symbolic"))
        self._icon_size_scale = Gtk.Scale.new_with_range(Gtk.Orientation.VERTICAL, 0, len(self._icon_sizes) - 1, 1)
        self._icon_size_scale.set_value(self._icon_sizes.index(self._current_grid_child_icon_size))
        self._icon_size_scale.set_increments(1, len(self._icon_sizes) - 1)
        self._icon_size_scale.set_round_digits(False)
        self._icon_size_scale.set_orientation(Gtk.Orientation.HORIZONTAL)
        self._icon_size_scale.connect("value-changed", self._on_icon_size_scale_value_changed)
        self._icon_size_scale.set_hexpand(True)
        self._icon_size_scale.set_property("width-request", len(self._icon_sizes) * 10)
        self._icon_size_box = Gtk.Box()
        self._icon_size_box.append(self._icon_size_decrease_button)
        self._icon_size_box.append(self._icon_size_scale)
        self._icon_size_box.append(self._icon_size_increase_button)
        self._icon_size_box.set_hexpand(True)
        self._show_names_toggle_label = Gtk.Label()
        self._show_names_toggle_label.set_ellipsize(Pango.EllipsizeMode.END)
        self._show_names_toggle_label.connect("notify::label", self._on_show_names_toggle_label_changed)
        self._show_names_toggle = Gtk.ToggleButton()
        self._show_names_toggle.set_hexpand(True)
        self._show_names_toggle.set_focus_on_click(False)
        self._show_names_toggle.add_css_class("flat")
        self._show_names_toggle.connect("toggled", self._on_show_names_toggle_toggled)
        self._show_names_toggle.set_child(self._show_names_toggle_label)
        self._toolbar = FlowingToolbar()
        self._toolbar.set_margin_top(self._toolbar.get_margin_top() + Margin.SMALLEST)
        self._toolbar.set_start_widget(self._icon_size_box)
        self._toolbar.set_end_widget(self._show_names_toggle)
        self.set_orientation(Gtk.Orientation.VERTICAL)
        self.append(self._resize_frame)
        GLib.idle_add(self._update_search_data, priority=GLib.PRIORITY_LOW)
        GLib.idle_add(self._connect_icon_finder_changed, priority=GLib.PRIORITY_LOW)
        self._update_toolbar_max_child_width()

    def _on_show_names_toggle_label_changed(self, label, gparam):
        self._update_toolbar_max_child_width()

    def _on_resize_frame_resized(self, event, width, height):
        self._update_max_columns()

    def _on_icon_size_increase_button_clicked(self, button):
        self._increase_scale_value(1)

    def _on_icon_size_decrease_button_clicked(self, button):
        self._increase_scale_value(-1)

    def _on_icon_size_scale_value_changed(self, scale):
        allow_increase = int(scale.get_value()) < len(self._icon_sizes) - 1
        allow_decrease = scale.get_value()
        if (
            (not allow_increase and self._icon_size_increase_button.has_focus())
            or (not allow_decrease and self._icon_size_decrease_button.has_focus())
        ):
            self._icon_size_scale.grab_focus()
        self._icon_size_increase_button.set_sensitive(allow_increase)
        self._icon_size_decrease_button.set_sensitive(allow_decrease)
        self._update_grid_children_style()

    def _on_show_names_toggle_toggled(self, toggle_button):
        self._update_grid_children_style()

    def _increase_scale_value(self, step):
        current_size = self._icon_sizes[int(self._icon_size_scale.get_value())]
        new_value = self._icon_sizes.index(current_size) + step
        self._icon_size_scale.set_value(new_value)

    def _update_max_columns(self):
        width = self._resize_frame.get_width()
        first_child = self._grid_view.get_first_child()
        min_image_width = self._current_grid_child_icon_size + (self._image_margin * 2) + (
            self._grid_view_list_item_border_width * 2)
        item_width = 0
        if width < min_image_width:
            return
        if first_child:
            item_width = first_child.get_allocated_width()
        if item_width < min_image_width:
            item_width = min_image_width
        spots_float = (width - ((self.get_inner_margin_start() + self.get_inner_margin_end()) * 2)) / item_width
        spots_int = int(spots_float)
        if not spots_int >= spots_float:
            spots_int += 1
        if not self._grid_view.get_max_columns() == spots_int:
            self._grid_view.set_max_columns(spots_int)

    def _update_grid_children_style(self):
        show_names = self._show_names_toggle.get_active()
        icon_size = self._icon_sizes[int(self._icon_size_scale.get_value())]
        if not show_names == self.get_show_names() or not icon_size == self.get_icon_size():
            if show_names:
                self._current_grid_child_class = LabeledImage
            else:
                self._current_grid_child_class = Gtk.Image
            self._current_grid_child_icon_size = icon_size
            if self._grid_view.get_model() and len(self._grid_view.get_model().get_model()):
                self.clear()
                self._start_search()
            self._update_max_columns()

    def _update_toolbar_max_child_width(self):
        max_child_width = tuple(sorted((
            len(self._icon_sizes) * 20,
            self._show_names_toggle.get_preferred_size()[1].width,
            self._control_widgets_min_width
        )))[-1]
        self._toolbar.set_max_child_width(max_child_width)

    def _on_icon_finder_changed(self, event, icon_finder):
        self.clear()
        self._update_search_data()
        self._start_search()

    def _on_factory_setup(self, factory, list_item):
        image = self._current_grid_child_class()
        image.set_pixel_size(self._current_grid_child_icon_size)
        image.set_margin_top(self._image_margin)
        image.set_margin_bottom(self._image_margin)
        image.set_margin_start(self._image_margin)
        image.set_margin_end(self._image_margin)
        list_item.set_child(image)

    def _on_factory_bind(self, factory, list_item):
        GLib.idle_add(list_item.get_child().set_from_icon_name, list_item.get_item().name, priority=GLib.PRIORITY_LOW)

    def _on_factory_unbind(self, factory, list_item):
        list_item.get_child().set_from_icon_name("")

    def _on_grid_view_activate(self, grid_view, position):
        self._events.trigger("item-selected", grid_view.get_model().get_model()[position].name)

    def _connect_icon_finder_changed(self):
        self._icon_finder.hook("changed", self._on_icon_finder_changed)

    def _update_search_data(self):
        self._icon_names = self._icon_finder.get_names()
        self._search_string = self._string_separator.join(self._icon_names)
        self._lower_string = self._search_string.lower()

    def _add_new_list_store(self, search_id):
        list_store = Gio.ListStore()
        selection_model = Gtk.NoSelection()
        selection_model.set_model(list_store)
        self._operations[search_id] = {
            "list-store": list_store,
            "selection-model": selection_model
        }

    def _start_search(self, text=None, exclude=[]):
        if text == None:
            text = self._last_text
        else:
            self._last_text = text
        del self._operations[self._search_id]
        self._search_id += 1
        self._add_new_list_store(self._search_id)
        if self._start_search_timeout_id:
            GLib.source_remove(self._start_search_timeout_id)
        self._start_search_timeout_id = GLib.timeout_add(self._search_delay, self._start_search_thread, text,
            self._search_id, exclude)

    def _start_search_thread(self, text, search_id, exclude=[]):
        keywords = set(filter(None, text.lower().replace(self._string_separator,
            self._keyword_separator).split(self._keyword_separator)))
        results_key = self._keyword_separator.join(keywords)
        self._search_thread = threading.Thread(target=self._search_thread_target,
            args=[text, keywords, results_key, search_id], kwargs={"exclude": exclude})
        self._search_thread.start()
        self._start_search_timeout_id = None
        return GLib.SOURCE_REMOVE

    def _search_thread_target(self, text, keywords, results_key, search_id, exclude=[]):
        try:
            names = self._results_cache[results_key]["names"]
        except KeyError:
            if not len(keywords):
                names = []
            else:
                names = self._get_names(keywords, search_id, exclude=exclude)
        GLib.idle_add(self._after_search_thread, names, results_key, search_id, priority=GLib.PRIORITY_LOW)

    def _after_search_thread(self, names, results_key, search_id):
        try:
            del self._results_cache[list(self._results_cache.keys())[-self._max_cached_results]]
        except IndexError:
            pass
        try:
            if (
                self._results_key and self._results_key in self._results_cache
                and names == self._results_cache[self._results_key]["names"]
                and self._results_cache[self._results_key]["selection-model"] == self._grid_view.get_model()
            ):
                self._operations[search_id] = self._results_cache[self._results_key]
                self._after_search_finished(results_key, search_id)
            else:
                self._operations[search_id]["names"] = names
                selection_model = self._operations[search_id]["selection-model"]
                self._grid_view.set_model(selection_model)
                if len(names):
                    icon_names = [IconName(name) for n, name in zip(range(self._results_limit), names)]
                    name_slices = [icon_names[i:i+self._slice_length] for i in range(0, len(icon_names),
                        self._slice_length)]
                    self._operations[search_id]["name-slices"] = name_slices
                    GLib.idle_add(self._add_next_slice, results_key, search_id, priority=GLib.PRIORITY_LOW)
                else:
                    self._after_search_finished(results_key, search_id)
        except KeyError as error:
            if search_id in self._operations:
                raise error

    def _add_next_slice(self, results_key, search_id):
        try:
            self._events.trigger("drawing-icons")
            list_store = self._operations[search_id]["list-store"]
            name_slices = self._operations[search_id]["name-slices"]
            list_store.splice(len(list_store), 0, name_slices.pop(0))
        except IndexError:
            self._after_search_finished(results_key, search_id)
        except KeyError as error:
            if search_id in self._operations:
                raise error
        else:
            return True

    def _after_search_finished(self, results_key, search_id):
        self._results_cache[results_key] = self._operations[search_id]
        self._results_key = results_key
        list_store = self._operations[search_id]["list-store"]
        self._events.trigger("updated", list_store)

    def _get_names(self, keywords, search_id, exclude=[]):
        names = []
        for string in keywords:
            names.append([])
            start_pos = 0
            while search_id == self._search_id:
                try:
                    start_pos = self._lower_string.index(string, start_pos)
                except ValueError:
                    break
                else:
                    start_pos -= 1
                    while (
                        not self._search_string[start_pos:start_pos + len(
                        self._string_separator)] == self._string_separator
                    ):
                        start_pos -= 1
                        if start_pos < 1:
                            start_pos = 0
                            break
                    else:
                        start_pos += 1
                    try:
                        end_pos = self._search_string.index(self._string_separator, start_pos)
                    except ValueError:
                        name = self._search_string[start_pos:]
                        if not name in exclude:
                            names[-1].append(name)
                        break
                    else:
                        name = self._search_string[start_pos:end_pos]
                        if not name in exclude:
                            names[-1].append(name)
                        start_pos = end_pos + len(self._string_separator)
                        if not len(self._search_string) > start_pos:
                            break
            else:
                return []
        else:
            return self._get_matching_names(names)

    def _get_matching_names(self, lists):
        first_list = lists.pop(0)
        first_list = set(first_list)
        for remaining_list in lists:
            first_list = first_list.intersection(remaining_list)
        else:
            return first_list

    def get_show_names(self):
        return self._current_grid_child_class == LabeledImage

    def set_show_names(self, value):
        self._show_names_toggle.set_active(value)

    def get_icon_size(self):
        return self._current_grid_child_icon_size

    def set_icon_size(self, value):
        try:
            self._icon_size_scale.set_value(self._icon_sizes.index(value))
        except ValueError:
            raise IconSizeNotSupportedError(value)

    def get_show_names_toggle_label(self):
        return self._show_names_toggle_label.get_text()

    def set_show_names_toggle_label(self, text):
        self._show_names_toggle_label.set_text(text)

    def get_inner_margin_top(self):
        return self._grid_view.get_margin_top()

    def set_inner_margin_top(self, value):
        self._grid_view.set_margin_top(value)

    def get_inner_margin_bottom(self):
        return self._grid_view.get_margin_bottom()

    def set_inner_margin_bottom(self, value):
        self._grid_view.set_margin_bottom(value)

    def get_inner_margin_start(self):
        return self._grid_view.get_margin_start()

    def set_inner_margin_start(self, value):
        self._grid_view.set_margin_start(value)

    def get_inner_margin_end(self):
        return self._grid_view.get_margin_end()

    def set_inner_margin_end(self, value):
        self._grid_view.set_margin_end(value)

    def get_results(self):
        return self._grid_view.get_model().get_model()

    def get_toolbar(self):
        return self._toolbar

    def update(self, text, exclude=[]):
        self._start_search(text, exclude=exclude)

    def clear(self):
        self._results_cache.clear()
        self._grid_view.set_model(None)
        self._results_key = None

    def hook(self, event, callback, *args):
        self._events.hook(event, callback, *args)

    def release(self, id):
        self._events.release(id)
