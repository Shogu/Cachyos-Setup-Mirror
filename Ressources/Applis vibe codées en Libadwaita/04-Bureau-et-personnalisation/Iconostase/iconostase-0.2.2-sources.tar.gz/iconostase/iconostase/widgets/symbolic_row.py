# SPDX-License-Identifier: GPL-3.0-or-later
import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gio, GLib, Gtk  # noqa: E402

from ..core.events import EventManager
from ..icon_store import IconState

SUBTITLES = {
    IconState.OK: _("Installed in your icon theme"),
    IconState.NO_SYMBOLIC: _("No symbolic version yet: GNOME will fall back to a generic icon"),
    IconState.BY_PATH: _("The launcher points to a file path, so GNOME cannot find a symbolic version"),
    IconState.MISSING: _("This icon is not in your icon theme"),
}


class SymbolicIconRow(Adw.ActionRow):
    def __init__(self, app, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._application_window = app.get_application_window()
        self._icon_store = app.get_icon_store()
        self._events = EventManager()
        self._events.add("file-chosen", object, str)
        self._events.add("convert-requested", object)
        self.set_title(_("Symbolic icon"))
        self._tiles = []
        for style in ("dark", "light"):
            image = Gtk.Image(pixel_size=16)
            tile = Gtk.Box(valign=Gtk.Align.CENTER, halign=Gtk.Align.CENTER)
            tile.add_css_class("symbolic-tile")
            tile.add_css_class(style)
            tile.append(image)
            self._tiles.append(image)
            self.add_prefix(tile)
        self._convert_button = Gtk.Button(label=_("Convert"), valign=Gtk.Align.CENTER, visible=False)
        self._convert_button.set_tooltip_text(_("Install this file in your icon theme and refer to it by name"))
        self._convert_button.connect("clicked", self._on_convert_clicked)
        self._choose_button = Gtk.Button(icon_name="document-open-symbolic", valign=Gtk.Align.CENTER)
        self._choose_button.set_tooltip_text(_("Choose a symbolic SVG"))
        self._choose_button.add_css_class("flat")
        self._choose_button.connect("clicked", self._on_choose_clicked)
        self.add_suffix(self._convert_button)
        self.add_suffix(self._choose_button)
        svg_filter = Gtk.FileFilter(name=_("SVG images"))
        svg_filter.add_mime_type("image/svg+xml")
        filters = Gio.ListStore.new(Gtk.FileFilter)
        filters.append(svg_filter)
        self._file_dialog = Gtk.FileDialog(modal=True, filters=filters, title=_("Choose a symbolic SVG"))

    def _on_choose_clicked(self, button):
        self._file_dialog.open(self._application_window, None, self._on_file_dialog_finished)

    def _on_file_dialog_finished(self, dialog, result):
        try:
            file = dialog.open_finish(result)
        except GLib.GError:
            return
        self._events.trigger("file-chosen", self, file.get_path())

    def _on_convert_clicked(self, button):
        self._events.trigger("convert-requested", self)

    def update(self, icon):
        state = self._icon_store.state(icon)
        self.set_subtitle(SUBTITLES[state])
        self._convert_button.set_visible(state == IconState.BY_PATH)
        for image in self._tiles:
            if state == IconState.OK:
                image.set_from_icon_name(f"{icon}-symbolic")
            else:
                image.set_from_icon_name("image-missing-symbolic")

    def hook(self, event, callback, *args):
        self._events.hook(event, callback, *args)
