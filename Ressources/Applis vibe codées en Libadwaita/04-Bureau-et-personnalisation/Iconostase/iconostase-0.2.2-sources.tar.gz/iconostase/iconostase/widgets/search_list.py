# SPDX-License-Identifier: GPL-3.0-or-later
# D'après libre-menu-editor (© 2022 Free Software Foundation).

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Pango, GLib, Gtk  # noqa: E402

from ..core.events import EventManager
from .constants import Keyval, Margin, Spacing
from .errors import IconNotFoundError, ItemAlreadyExistingError, ItemNotFoundError
from ..icon_store import IconState


BADGES = {
    IconState.OK: (None, None),
    IconState.NO_SYMBOLIC: ("image-missing-symbolic", _("No symbolic icon")),
    IconState.BY_PATH: ("dialog-warning-symbolic", _("Icon set by path: the symbolic icon cannot work")),
    IconState.MISSING: ("dialog-warning-symbolic", _("Icon not found")),
}


class SearchList(Gtk.Box):
    def __init__(self, app, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._events = EventManager()
        self._events.add("item-activated", str)
        self._names = {}
        self._children = {}
        self._last_activated = None
        self._ignore_selection = False
        self._reset_by_unfocus = False
        self._icon_finder = app.get_icon_finder()
        self._icon_finder.hook("changed", self._on_icon_finder_changed)
        self._icon_store = app.get_icon_store()
        self._app = app
        self._application_window = app.get_application_window()
        self._toggle_button = Gtk.ToggleButton()
        self._toggle_button.set_icon_name(self._icon_finder.get_name("system-search-symbolic"))
        self._toggle_button.connect("toggled", self._on_toggle_button_toggled)
        self._search_entry_event_controller_focus = Gtk.EventControllerFocus()
        self._search_entry_event_controller_focus.connect("leave", self._on_search_entry_event_controller_focus_leave)
        self._search_entry_event_controller_key = Gtk.EventControllerKey()
        self._search_entry_event_controller_key.connect("key-pressed", self._on_search_entry_controller_key_pressed)
        self._search_entry = Gtk.SearchEntry()
        self._search_entry.set_hexpand(True)
        self._search_entry.add_controller(self._search_entry_event_controller_focus)
        self._search_entry.add_controller(self._search_entry_event_controller_key)
        self._search_entry.connect("search-changed", self._on_search_entry_search_changed)
        self._search_bar = Gtk.SearchBar()
        self._search_bar.set_key_capture_widget(self._application_window)
        self._search_bar.connect("notify::search-mode-enabled", self._on_search_bar_search_mode_enabled_changed)
        self._search_bar.set_child(self._search_entry)
        self._search_bar_box = Gtk.Box()
        self._search_revealer = self._search_bar.get_child().get_parent().get_parent()
        self._search_revealer.set_child(self._search_bar_box)
        self._search_bar_box.append(self._search_entry)
        self._search_bar.connect_entry(self._search_entry)
        self._list_box_event_controller_key = Gtk.EventControllerKey()
        self._list_box_event_controller_key.connect("key-pressed", self._on_list_box_controller_key_pressed)
        self._list_box = Gtk.ListBox()
        self._list_box.set_sort_func(self._do_list_box_sort)
        self._list_box.add_css_class("navigation-sidebar")
        self._list_box.set_selection_mode(Gtk.SelectionMode.BROWSE)
        self._list_box.connect("selected-rows-changed", self._on_list_box_selected_rows_changed)
        self._list_box.add_controller(self._list_box_event_controller_key)
        self._list_box.connect("row-activated", self._on_list_box_row_activated)
        self._scrolled_window = Gtk.ScrolledWindow()
        self._scrolled_window.set_vexpand(True)
        self._scrolled_window.set_kinetic_scrolling(True)
        self._scrolled_window.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self._scrolled_window.set_child(self._list_box)
        self.set_orientation(Gtk.Orientation.VERTICAL)
        self.append(self._search_bar)
        self.append(self._scrolled_window)

    def _on_icon_finder_changed(self, event, icon_finder):
        for name in self._children:
            GLib.idle_add(self._update_item_image, self._children[name]["image"], self._children[name]["icon"])
            GLib.idle_add(self._update_item_badge, name)

    def _on_toggle_button_toggled(self, button):
        self._search_bar.set_search_mode(button.get_active())

    def _on_search_entry_search_changed(self, search_entry):
        if not len(self._search_entry.get_text()) and not self._search_bar.get_focus_child():
            self._search_bar.set_search_mode(False)
        self._update_search_results()

    def _on_search_bar_search_mode_enabled_changed(self, search_bar, property):
        value = self._search_bar.get_search_mode()
        if self._reset_by_unfocus and self._application_window.get_focus() == self._toggle_button:
            self._reset_by_unfocus = False
        else:
            self._toggle_button.set_active(value)
        if not value and self._search_bar.get_focus_child():
            self._list_box.child_focus(Gtk.DirectionType.DOWN)

    def _on_search_entry_event_controller_focus_leave(self, controller):
        if self._search_bar.get_search_mode() and not len(self._search_entry.get_text()):
            self._reset_by_unfocus = True
            GLib.idle_add(self._search_bar.set_search_mode, False)

    def _on_search_entry_controller_key_pressed(self, controller, keyval, keycode, state):
        if keyval == Keyval.ESCAPE:
            self._search_bar.set_search_mode(False)
            return True
        elif keyval == Keyval.UP or keyval == Keyval.PAGEUP:
            self._toggle_button.grab_focus()
            if not len(self._search_entry.get_text()):
                self._toggle_button.set_active(False)
            return True
        elif keyval == Keyval.DOWN or keyval == Keyval.PAGEDOWN:
            if not len(self._search_entry.get_text()):
                self._search_bar.set_search_mode(False)
            else:
                self._list_box.child_focus(Gtk.DirectionType.DOWN)
            return True
        elif (
            keyval == Keyval.TAB and self._last_activated
            and not self._children[self._last_activated]["widget"].get_visible()
        ):
            self._list_box.set_selection_mode(Gtk.SelectionMode.NONE)
            self._list_box.set_selection_mode(Gtk.SelectionMode.BROWSE)

    def _on_list_box_controller_key_pressed(self, controller, keyval, keycode, state):
        if keyval == Keyval.ESCAPE and self._search_bar.get_search_mode():
            self._search_bar.grab_focus()
            self._search_bar.set_search_mode(False)
            return True
        elif (
            (keyval == Keyval.UP or keyval == Keyval.PAGEUP)
            and self._list_box.get_focus_child() == self._list_box.get_first_child()
        ):
            if not self._search_bar.get_search_mode():
                self._search_bar.set_search_mode(True)
            self._search_entry.grab_focus()
            return True

    def _on_list_box_selected_rows_changed(self, listbox):
        if not self._ignore_selection:
            self._list_box.unselect_all()
            if self._last_activated in self._children:
                self._list_box.select_row(self._children[self._last_activated]["widget"])
            else:
                self._list_box.select_row(None)

    def _on_list_box_row_activated(self, list_box, row):
        self._ignore_selection = True
        if self._events.trigger("item-activated", self._names[row]):
            self._last_activated = self._names[row]
        self._list_box.select_row(row)
        self._ignore_selection = False

    def _do_list_box_sort(self, row_1, row_2):
        labels = [
            self._children[self._names[row_1]]["label"].get_text(),
            self._children[self._names[row_2]]["label"].get_text()
        ]
        if labels[0] == labels[1]:
            return 0
        else:
            if sorted(labels, key=str.lower)[0] == labels[0]:
                return -1
            else:
                return 1

    def _get_visible_children(self):
        children = []
        for child in list(reversed(self._children.values())):
            if child["widget"].get_visible():
                children.append(child["widget"])
        return children

    def _update_search_results(self):
        text = self._search_entry.get_text().lower()
        for name in self._children:
            for keyword in self._children[name]["keywords"]:
                if text in keyword:
                    self._children[name]["widget"].set_visible(True)
                    break
            else:
                self._children[name]["widget"].set_visible(False)

    def _update_item_image(self, image, icon):
        try:
            self._icon_finder.set_image(image, icon, missing_ok=False)
        except IconNotFoundError:
            image.clear()

    def _update_item_badge(self, name):
        if name not in self._children:
            return
        badge = self._children[name]["badge"]
        state = self._icon_store.state(self._children[name]["icon"])
        if self._app.launcher_outdated(name):
            icon_name, tooltip, style = "software-update-available-symbolic", _("Updated by its package"), "accent"
        else:
            icon_name, tooltip = BADGES[state]
            style = "dim-label" if state == IconState.NO_SYMBOLIC else "warning"
        badge.set_visible(icon_name is not None)
        badge.set_css_classes(["icon-badge", style])
        if icon_name:
            badge.set_from_icon_name(icon_name)
            badge.set_tooltip_text(tooltip)

    def get_active_item(self):
        return self._last_activated

    def set_active_item(self, name, activate=True):
        if name is None:
            self._list_box.unselect_all()
            self._last_activated = None
        else:
            item = self._children[name]["widget"]
            if not item in self._list_box.get_selected_rows():
                self._list_box.select_row(item)
                if activate:
                    item.activate()

    def get_search_mode(self):
        return self._search_bar.get_search_mode()

    def set_search_mode(self, value):
        self._search_bar.set_search_mode(value)

    def get_search_bar(self):
        return self._search_bar

    def get_search_button(self):
        return self._toggle_button

    def get_search_entry(self):
        return self._search_entry

    def get_visible_items(self):
        children = []
        child = self._list_box.get_first_child()
        while True:
            if not child == None:
                children.append(child)
                child = children[-1].get_next_sibling()
            else:
                break
        return [self._names[child] for child in children if child.get_visible()]
        items = []
        for child in self._children:
            if self._children[child]["widget"].get_visible():
                items.append(child)
        else:
            return items

    def list(self):
        return list(self._children)

    def clear(self):
        for name in self.list():
            self.remove(name)

    def update(self, name, text, icon, keywords, invalidate_sort=True):
        if name in self._children:
            image = self._children[name]["image"]
            label = self._children[name]["label"]
            self._children[name]["icon"] = icon
            GLib.idle_add(self._update_item_image, image, icon)
            GLib.idle_add(self._update_item_badge, name)
            label.set_text(text)
            self._children[name]["keywords"] = [keyword.lower() for keyword in keywords]
            if invalidate_sort:
                self._list_box.invalidate_sort()
            self._update_search_results()
        else:
            raise ItemNotFoundError(name)

    def add(self, name, text, icon=None, keywords=None):
        if not name in self._children:
            image = Gtk.Image()
            image.set_pixel_size(48)
            label = Gtk.Label()
            label.set_ellipsize(Pango.EllipsizeMode.END)
            label.set_hexpand(True)
            label.set_xalign(0)
            badge = Gtk.Image(visible=False)
            badge.add_css_class("icon-badge")
            box = Gtk.Box()
            box.set_margin_top(Margin.DEFAULT)
            box.set_margin_bottom(Margin.DEFAULT)
            box.set_margin_start(Margin.DEFAULT)
            box.set_margin_end(Margin.DEFAULT)
            box.set_spacing(Spacing.DEFAULT)
            box.append(image)
            box.append(label)
            box.append(badge)
            child = Gtk.ListBoxRow()
            child.set_child(box)
            self._names[child] = name
            self._children[name] = {}
            self._children[name]["widget"] = child
            self._children[name]["image"] = image
            self._children[name]["label"] = label
            self._children[name]["badge"] = badge
            if not isinstance(keywords, list):
                keywords = [text]
            self.update(name, text, icon, keywords, invalidate_sort=False)
            self._list_box.prepend(child)
            self._update_search_results()
        else:
            raise ItemAlreadyExistingError(name)

    def remove(self, name):
        if name in self._children:
            child = self._children[name]["widget"]
            self._list_box.remove(child)
            del self._names[child]
            del self._children[name]
            self._update_search_results()
        else:
            raise ItemNotFoundError(name)

    def hook(self, event, callback):
        return self._events.hook(event, callback)

    def release(self, id):
        self._events.release(id)

    def grab_focus(self):
        if not self._search_bar.get_search_mode():
            self._search_bar.set_search_mode(True)
        self._search_entry.grab_focus()
