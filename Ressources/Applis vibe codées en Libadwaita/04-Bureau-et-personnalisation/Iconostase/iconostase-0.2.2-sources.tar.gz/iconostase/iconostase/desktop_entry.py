# SPDX-License-Identifier: GPL-3.0-or-later
# D'après libre-menu-editor (© 2022 Free Software Foundation).
from configparser import ConfigParser
import os

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import GLib  # noqa: E402


class NoAccessError(Exception):
    pass


class DesktopParser():
    def __init__(self, app, load_path, save_path):
        self._application = app
        self._config_parser = ConfigParser(interpolation=None, strict=False)
        self._config_parser.optionxform = str
        self._system_locale_names = list(filter(None, [
            os.getenv("LANG").split(".")[0].split("_")[0],
            os.getenv("LANG").split(".")[0],
            os.getenv("LANG")
        ]))
        self._load_path = load_path
        self._save_path = save_path
        self._save_callback_callable = None
        self._save_callback_data = None
        self.load()

    def _get_action_from_section(self, section):
        return section[len("Desktop Action "):]

    def _get_section_from_action(self, action):
        return "Desktop Action %s" % action

    def _get_str(self, key, section="Desktop Entry", localized=False, value=""):
        if self._config_parser.has_section(section):
            if localized:
                for locale in self._system_locale_names:
                    localized_key = "%s[%s]" % (key, locale)
                    if self._config_parser.has_option(section, localized_key):
                        return self._config_parser.get(section, localized_key)
            if self._config_parser.has_option(section, key):
                return self._config_parser.get(section, key)
        return value

    def _get_bool(self, key, section="Desktop Entry"):
        if self._config_parser.has_section(section):
            if self._config_parser.has_option(section, key):
                try:
                    return self._config_parser.getboolean(section, key)
                except ValueError as error:
                    self._application.log(error, error=error)
                    return False
            else:
                return False
        else:
            return False

    def _set(self, key, value, section="Desktop Entry", localized=False):
        if isinstance(value, bool):
            if value:
                value = "true"
            else:
                value = "false"
        if len(value):
            if section == "Desktop Entry" and not self._config_parser.has_section(section):
                self._config_parser.add_section(section)
            self._config_parser.set(section, key, value)
            if localized:
                for locale in self._system_locale_names:
                    localized_key = "%s[%s]" % (key, locale)
                    self._config_parser.set(section, localized_key, value)
        else:
            if self._config_parser.has_option(section, key):
                self._config_parser.remove_option(section, key)
            if localized:
                for locale in self._system_locale_names:
                    localized_key = "%s[%s]" % (key, locale)
                    if self._config_parser.has_option(section, localized_key):
                        self._config_parser.remove_option(section, localized_key)

    def get_action_name(self, action):
        return self.get_name(section=self._get_section_from_action(action))

    def set_action_name(self, action, name):
        self.set_name(name, section=self._get_section_from_action(action))

    def get_action_command(self, action):
        return self.get_command(section=self._get_section_from_action(action))

    def set_action_command(self, action, command):
        self.set_command(command, section=self._get_section_from_action(action))

    def get_name(self, section="Desktop Entry"):
        return self._get_str("Name", section=section, localized=True)

    def set_name(self, name, section="Desktop Entry"):
        self._set("Name", name, section=section, localized=True)

    def get_comment(self, section="Desktop Entry"):
        return self._get_str("Comment", section=section, localized=True)

    def set_comment(self, comment, section="Desktop Entry"):
        self._set("Comment", comment, section=section, localized=True)

    def get_keywords(self, section="Desktop Entry"):
        return self._get_str("Keywords", section=section, localized=True)

    def set_keywords(self, text, section="Desktop Entry"):
        self._set("Keywords", text, section=section, localized=True)

    def get_only_show_in(self, section="Desktop Entry"):
        return self._get_str("OnlyShowIn", section=section)

    def set_only_show_in(self, text, section="Desktop Entry"):
        self._set("OnlyShowIn", text, section=section)

    def get_not_show_in(self, section="Desktop Entry"):
        return self._get_str("NotShowIn", section=section)

    def set_not_show_in(self, text, section="Desktop Entry"):
        self._set("NotShowIn", text, section=section)

    def get_categories(self, section="Desktop Entry"):
        return self._get_str("Categories", section=section)

    def set_categories(self, text, section="Desktop Entry"):
        self._set("Categories", text, section=section)

    def get_icon(self, section="Desktop Entry"):
        return self._get_str("Icon", section=section)

    def set_icon(self, icon, section="Desktop Entry"):
        self._set("Icon", icon, section=section)

    def get_command(self, section="Desktop Entry"):
        return self._get_str("Exec", section=section)

    def set_command(self, command, section="Desktop Entry"):
        self._set("Exec", command, section=section)

    def get_disabled(self, section="Desktop Entry"):
        return self._get_bool("Hidden", section=section)

    def set_disabled(self, value, section="Desktop Entry"):
        self._set("Hidden", value, section=section)

    def get_hidden(self, section="Desktop Entry"):
        return self._get_bool("NoDisplay", section=section)

    def set_hidden(self, value, section="Desktop Entry"):
        self._set("NoDisplay", value, section=section)

    def get_visible(self, section="Desktop Entry"):
        return not self.get_hidden() and not self.get_disabled()

    def set_visible(self, value, section="Desktop Entry"):
        if value:
            self.set_disabled(False)
            self.set_hidden(False)
        else:
            self.set_hidden(True)

    def get_notify(self, section="Desktop Entry"):
        return self._get_bool("StartupNotify", section=section)

    def set_notify(self, value, section="Desktop Entry"):
        self._set("StartupNotify", value, section=section)

    def get_terminal(self, section="Desktop Entry"):
        return self._get_bool("Terminal", section=section)

    def set_terminal(self, value, section="Desktop Entry"):
        self._set("Terminal", value, section=section)

    def get_working_directory(self, section="Desktop Entry"):
        text = self._get_str("Path", section=section)
        if not len(text):
            return GLib.get_home_dir()
        else:
            return text

    def set_working_directory(self, text, section="Desktop Entry"):
        try:
            is_same_file = os.path.samefile(text, GLib.get_home_dir())
        except FileNotFoundError:
            is_same_file = False
        if (
            is_same_file
            or os.path.abspath(text) == os.path.abspath(GLib.get_home_dir())
        ):
            text = ""
        self._set("Path", text, section=section)

    def get_prefers_dgpu(self, section="Desktop Entry"):
        return self._get_bool("PrefersNonDefaultGPU", section=section)

    def set_prefers_dgpu(self, value, section="Desktop Entry"):
        self._set("PrefersNonDefaultGPU", value, section=section)

    def get_mimetypes(self):
        if self._config_parser.has_option("Desktop Entry", "MimeType"):
            return list(filter(None, self._config_parser.get("Desktop Entry", "MimeType").split(";")))
        else:
            return []

    def get_load_path(self):
        return self._load_path

    def set_load_path(self, path):
        self._load_path = path

    def get_save_path(self):
        return self._save_path

    def set_save_path(self, path):
        self._save_path = path

    def get_save_callback(self):
        return self._save_callback_callable, self._save_callback_data

    def set_save_callback(self, callback, data):
        self._save_callback_callable = callback
        self._save_callback_data = data

    def get_search_data(self):
        data = []
        data.append(self.get_name())
        data.append(self.get_icon())
        data.append(self.get_command())
        data.append(self.get_keywords())
        data.append(self.get_categories())
        data.append(self.get_only_show_in())
        data.append(self.get_not_show_in())
        data.append(self._get_str("MimeType"))
        data.append(os.path.basename(self._load_path))
        return list(filter(None, data))

    def get_actions(self):
        actions = []
        for section in self._config_parser.sections():
            if section.startswith("Desktop Action "):
                actions.append(self._get_action_from_section(section))
        return actions

    def add_action(self, action):
        section = self._get_section_from_action(action)
        if not self._config_parser.has_section(section):
            self._config_parser.add_section(section)

    def remove_action(self, action):
        self._config_parser.remove_section(self._get_section_from_action(action))

    def check_read(self, path=None):
        if path is None:
            path = self._load_path
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as file:
                    pass
            except Exception as e:
                raise NoAccessError(e)
        else:
            OSError(f"not found: {path}")

    def check_write(self, path=None):
        if path is None:
            path = self._save_path
        while True:
            if os.path.exists(path):
                if os.path.isdir(path):
                    if not os.access(path, os.W_OK):
                        raise NoAccessError(f"no access: {path}")
                    else:
                        return
                else:
                    break
            else:
                dirname = os.path.dirname(path)
                if not os.path.abspath(dirname) == os.path.abspath(path):
                    path = dirname
                else:
                    raise NoAccessError(f"no access: {path}")
        else:
            raise NoAccessError(f"no access: {path}")
        try:
            if os.path.islink(path) and os.access(path, os.W_OK, follow_symlinks=False):
                pass
            else:
                with open(path, "a", encoding="utf-8") as file:
                    pass
        except Exception as e:
            raise NoAccessError(e)

    def load(self, path=None):
        self.check_read(path=path)
        if path is None:
            path = self._load_path
        self._config_parser.clear()
        with open(path, "r", encoding="utf-8") as file:
            self._config_parser.read_file(file)

    def save(self, path=None, no_callback=False):
        self.check_write(path=path)
        if path is None:
            path = self._save_path
        actions = self.get_actions()
        self._set("Actions", f"{';'.join(actions)}{bool(len(actions))*';'}")
        if not os.path.exists(path):
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        elif os.path.islink(path):
            realpath = os.path.realpath(path)
            if os.access(realpath, os.W_OK):
                path = realpath
            else:
                os.remove(path)
        with open(path, "w", encoding="utf-8") as file:
            self._config_parser.write(file, space_around_delimiters=False)
        if not no_callback:
            if self._save_callback_callable:
                self._save_callback_callable(self._save_callback_data)
