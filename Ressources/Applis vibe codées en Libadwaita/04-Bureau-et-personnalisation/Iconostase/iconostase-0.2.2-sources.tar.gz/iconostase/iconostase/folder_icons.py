# SPDX-License-Identifier: GPL-3.0-or-later
import gettext
import json
import os
import re
import shutil

from gi.repository import Gio, GLib

DATA_DIR = os.path.join(GLib.get_user_data_dir(), "iconostase")
ICONS_DIR = os.path.join(DATA_DIR, "dossiers")
PLAN_PATH = os.path.join(DATA_DIR, "dossiers.json")
USER_DIRS = os.path.join(GLib.get_user_config_dir(), "user-dirs.dirs")
ATTRIBUTE = "metadata::custom-icon"
XDG_LINE = re.compile(r'^(XDG_\w+_DIR)="\$HOME/?(.*)"$')
SPECIAL_KEYS = {
    "XDG_DESKTOP_DIR": "Desktop",
    "XDG_DOCUMENTS_DIR": "Documents",
    "XDG_DOWNLOAD_DIR": "Downloads",
    "XDG_MUSIC_DIR": "Music",
    "XDG_PICTURES_DIR": "Pictures",
    "XDG_PUBLICSHARE_DIR": "Public",
    "XDG_TEMPLATES_DIR": "Templates",
    "XDG_VIDEOS_DIR": "Videos",
}
VISIBLE, HIDDEN, DISABLED = "visible", "hidden", "disabled"
DEPTH = 2


def absolute(relative):
    return os.path.join(GLib.get_home_dir(), relative)


def relative(path):
    return os.path.relpath(path, GLib.get_home_dir())


class FolderPlan:
    def __init__(self):
        self.folders = []
        self.hidden = []
        if os.path.isfile(PLAN_PATH):
            with open(PLAN_PATH, encoding="utf-8") as file:
                data = json.load(file)
            self.folders = data["dossiers"]
            self.hidden = data["masques"]

    def save(self):
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(PLAN_PATH, "w", encoding="utf-8") as file:
            json.dump({"dossiers": self.folders, "masques": self.hidden}, file, ensure_ascii=False, indent=1)

    def entry(self, path):
        return next((folder for folder in self.folders if folder["chemin"] == relative(path)), None)

    def icon_path(self, folder):
        return os.path.join(ICONS_DIR, folder["icone"]) if folder["icone"] else None

    def add(self, path):
        os.makedirs(path, exist_ok=True)
        folder = self.entry(path)
        if folder is None:
            folder = {"chemin": relative(path), "icone": None, "creer": True}
            self.folders.append(folder)
            self.folders.sort(key=lambda item: item["chemin"].lower())
        return folder

    def set_icon(self, path, source):
        os.makedirs(ICONS_DIR, exist_ok=True)
        filename = os.path.basename(source)
        target = os.path.join(ICONS_DIR, filename)
        if os.path.realpath(source) != os.path.realpath(target):
            shutil.copyfile(source, target)
        folder = self.entry(path) or self.add(path)
        folder["icone"] = filename
        write_custom_icon(path, target)

    def reset_icon(self, path):
        write_custom_icon(path, None)
        self.entry(path)["icone"] = None

    def remove(self, path):
        if self.entry(path)["icone"] and os.path.isdir(path):
            write_custom_icon(path, None)
        self.folders = [folder for folder in self.folders if folder["chemin"] != relative(path)]

    def set_create(self, path, create):
        self.entry(path)["creer"] = create

    def apply_all(self):
        problems = []
        for folder in self.folders:
            path = absolute(folder["chemin"])
            if not os.path.isdir(path):
                if not folder["creer"]:
                    problems.append(folder["chemin"])
                    continue
                os.makedirs(path)
            if folder["icone"]:
                try:
                    write_custom_icon(path, self.icon_path(folder))
                except GLib.GError:
                    problems.append(folder["chemin"])
        for folder in special_folders():
            if folder["name"] in self.hidden and folder["state"] != HIDDEN:
                set_hidden(folder, True)
        return problems

    def adopt_existing(self):
        known = {folder["chemin"] for folder in self.folders}
        adopted = []
        for path in _home_folders():
            icon = read_custom_icon(path)
            if not icon or relative(path) in known or not os.path.isfile(icon):
                continue
            os.makedirs(ICONS_DIR, exist_ok=True)
            filename = os.path.basename(icon)
            target = os.path.join(ICONS_DIR, filename)
            if os.path.isfile(target) and not _same_file(icon, target):
                filename = f"{relative(path).replace(os.sep, '-')}-{filename}"
                target = os.path.join(ICONS_DIR, filename)
            if os.path.realpath(icon) != os.path.realpath(target):
                shutil.copyfile(icon, target)
                write_custom_icon(path, target)
            self.folders.append({"chemin": relative(path), "icone": filename, "creer": False})
            adopted.append(relative(path))
        self.folders.sort(key=lambda item: item["chemin"].lower())
        return adopted


def read_custom_icon(path):
    try:
        info = Gio.File.new_for_path(path).query_info(ATTRIBUTE, Gio.FileQueryInfoFlags.NONE, None)
    except GLib.GError:
        return None
    uri = info.get_attribute_string(ATTRIBUTE)
    return Gio.File.new_for_uri(uri).get_path() if uri else None


def write_custom_icon(path, icon):
    file = Gio.File.new_for_path(path)
    if icon:
        file.set_attribute_string(ATTRIBUTE, Gio.File.new_for_path(icon).get_uri(), Gio.FileQueryInfoFlags.NONE, None)
    else:
        file.set_attribute(ATTRIBUTE, Gio.FileAttributeType.INVALID, None, Gio.FileQueryInfoFlags.NONE, None)


def _home_folders():
    home = GLib.get_home_dir()
    for root, dirs, files in os.walk(home):
        depth = 0 if root == home else relative(root).count(os.sep) + 1
        dirs[:] = [name for name in dirs if not name.startswith(".")] if depth < DEPTH else []
        for name in dirs:
            yield os.path.join(root, name)


def _same_file(first, second):
    with open(first, "rb") as one, open(second, "rb") as other:
        return one.read() == other.read()


def _read_user_dirs():
    if not os.path.isfile(USER_DIRS):
        return []
    with open(USER_DIRS, encoding="utf-8") as file:
        return file.read().splitlines()


def special_folders():
    values = {}
    for line in _read_user_dirs():
        match = XDG_LINE.match(line.strip())
        if match:
            values[match.group(1)] = match.group(2).rstrip("/")
    folders = []
    for key, english in SPECIAL_KEYS.items():
        value = values.get(key, "")
        default = gettext.dgettext("xdg-user-dirs", english)
        if default == english:
            default = _(english)
        if not value:
            state, name = DISABLED, default
        elif value.startswith("."):
            state, name = HIDDEN, value[1:]
        else:
            state, name = VISIBLE, value
        folders.append({"key": key, "name": name, "state": state})
    return sorted(folders, key=lambda folder: folder["name"].lower())


def set_hidden(folder, hidden):
    name = folder["name"]
    source, target = (name, f".{name}") if hidden else (f".{name}", name)
    if os.path.isdir(absolute(source)) and not os.path.exists(absolute(target)):
        os.rename(absolute(source), absolute(target))
    else:
        os.makedirs(absolute(target), exist_ok=True)
    lines = _read_user_dirs()
    new_line = f'{folder["key"]}="$HOME/{target}"'
    for index, line in enumerate(lines):
        if line.strip().startswith(f'{folder["key"]}='):
            lines[index] = new_line
            break
    else:
        lines.append(new_line)
    os.makedirs(os.path.dirname(USER_DIRS), exist_ok=True)
    with open(USER_DIRS, "w", encoding="utf-8") as file:
        file.write("\n".join(lines) + "\n")
