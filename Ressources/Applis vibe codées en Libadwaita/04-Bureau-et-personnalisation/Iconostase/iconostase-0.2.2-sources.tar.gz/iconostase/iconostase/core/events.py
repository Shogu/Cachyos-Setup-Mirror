# SPDX-License-Identifier: GPL-3.0-or-later
# D'après libre-menu-editor (© 2022 Free Software Foundation).



class EventAlreadyExistingError(Exception):
    pass


class EventNotFoundError(Exception):
    pass


class EventCallbackInvalidError(Exception):
    pass


class EventHookInvalidError(Exception):
    pass


class EventInvalidArgumentsError(Exception):
    pass


class EventUnexpectedArgumentsError(Exception):
    pass


class EventMissingArgumentsError(Exception):
    pass


class EventManager():
    def __init__(self):
        self._events = {}
        self._hooks = {}
        self._count = 0

    def get_events(self):
        return self._events.keys()

    def get_hooks(self):
        return self._hooks.keys()

    def add(self, event, *argtypes):
        if not event in self._events:
            for argtype in argtypes:
                if not isinstance(type, type(argtype)):
                    raise EventInvalidArgumentsError(argtypes)
            else:
                self._events[event] = {
                    "argtypes": argtypes,
                    "hooks": []
                }
        else:
            raise EventAlreadyExistingError(event)

    def remove(self, event):
        if event in self._events:
            for id in self._events[event]["hooks"]:
                self.release(id)
            del self._events[event]
        else:
            raise EventNotFoundError(event)

    def hook(self, event, callback, *args):
        if event in self._events:
            if callable(callback):
                self._count += 1
                id = str(self._count)
                self._hooks[id] = {
                    "callback": callback,
                    "args": args,
                    "event": event
                }
                self._events[event]["hooks"].append(id)
                return id
            else:
                raise EventCallbackInvalidError(callback)
        else:
            raise EventNotFoundError(event)

    def release(self, id):
        if id in self._hooks:
            event = self._hooks[id]["event"]
            self._events[event]["hooks"].remove(id)
            del self._hooks[id]
        else:
            raise EventHookInvalidError(id)

    def trigger(self, event, *args):
        responses = []
        if event in self._events:
            if len(self._events[event]["argtypes"]) == len(args):
                for n, arg in enumerate(args):
                    if not isinstance(arg, self._events[event]["argtypes"][n]):
                        raise EventInvalidArgumentsError(arg)
                else:
                    for id in self._events[event]["hooks"]:
                        callback = self._hooks[id]["callback"]
                        args += self._hooks[id]["args"]
                        responses.append(bool(callback(event, *args)))
            elif len(self._events[event]["argtypes"]) > len(args):
                value = len(self._events[event]["argtypes"]) - len(args)
                raise EventMissingArgumentsError(value)
            elif len(args) > len(self._events[event]["argtypes"]):
                value = len(args) - len(self._events[event]["argtypes"])
                raise EventUnexpectedArgumentsError(value)
        else:
            raise EventNotFoundError(event)
        return True in responses
