# SPDX-License-Identifier: GPL-3.0-or-later
# D'après libre-menu-editor (© 2022 Free Software Foundation).
import os
import json

from .events import EventManager


class SettingNotFoundError(Exception):
    pass


class ValueWrongTypeError(Exception):
    pass


class ConfigManager():
    def __init__(self, default_path, modified_path):
        self._events = EventManager()
        self._default_data = {}
        self._modified_data = {}
        self.set_default_path(default_path)
        self.set_modified_path(modified_path)
        if os.access(modified_path, os.W_OK):
            self.load()

    def _read_json_data(self, path):
        with open(path, mode="r", encoding="utf-8") as file:
            data = json.loads(file.read())
        return data

    def _write_json_data(self, path, data):
        with open(path, mode="w", encoding="utf-8") as file:
            file.write(json.dumps(data, indent=2))

    def get_default_path(self):
        return self._default_path

    def set_default_path(self, path):
        if os.access(path, os.R_OK):
            self._default_path = path
            data = self._read_json_data(path)
            for key in self._default_data:
                if not key in data:
                    del self._default_data[key]
                    del self._modified_data[key]
                    self._events.remove(key)
            for key in data:
                if not key in self._default_data:
                    self._events.add(key)
                    self._default_data[key] = data[key]
                    self._modified_data[key] = data[key]
        else:
            raise PathNotAccessibleError(path)

    def get_mofidied_path(self):
        return self._modified_path

    def set_modified_path(self, path):
        parent_dir = os.path.dirname(path)
        if os.access(parent_dir, os.W_OK) or not os.path.exists(parent_dir):
            self._modified_path = path
        else:
            raise PathNotAccessibleError(path)

    def get_default_data(self):
        return self._default_data.copy()

    def get_modified_data(self):
        return self._modified_data.copy()

    def hook(self, key, callback, *args):
        self._events.hook(key, callback, *args)

    def release(self, id):
        self._events.release(id)

    def get(self, key):
        if key in self._modified_data:
            return self._modified_data[key]
        else:
            raise SettingNotFoundError(key)

    def set(self, key, value):
        if key in self._modified_data:
            if type(value) == type(self._modified_data[key]):
                if not value == self._modified_data[key]:
                    self._modified_data[key] = value
                    self._events.trigger(key)
            else:
                raise ValueWrongTypeError(value)
        else:
            raise SettingNotFoundError(key)

    def load(self):
        try:
            data = self._read_json_data(self._modified_path)
        except json.decoder.JSONDecodeError:
            pass
        else:
            for key in data:
                try:
                    self.set(key, data[key])
                except SettingNotFoundError:
                    pass
                except ValueWrongTypeError:
                    pass

    def save(self):
        data = {}
        for key in self._modified_data:
            if not self._modified_data[key] == self._default_data[key]:
                data[key] = self._modified_data[key]
        if not os.path.exists(self._modified_path):
            os.makedirs(os.path.dirname(self._modified_path), exist_ok=True)
        elif not os.access(self._modified_path, os.W_OK):
            os.remove(self._modified_path)
        self._write_json_data(self._modified_path, data)


class PathNotAccessibleError(Exception):
    pass
