# SPDX-License-Identifier: GPL-3.0-or-later
# D'après libre-menu-editor (© 2022 Free Software Foundation).
import os
import threading
import time

from .events import EventManager


class PathInspector():
    def __init__(self):
        self._paths = {}
        self._delay = 0.5
        self._active = False
        self._stopped = False
        self._events = EventManager()
        self._events.add("changed", str, float)
        self._events.add("created", str, float)
        self._events.add("deleted", str, float)
        self._thread = threading.Thread(target=self._thread_target)

    def _thread_target(self):
        while not self._stopped:
            time.sleep(self._delay)
            for path in self._paths:
                old_timestamp = self._paths[path]["timestamp"]
                try:
                    new_timestamp = os.path.getmtime(path)
                    if new_timestamp > old_timestamp:
                        self._paths[path]["timestamp"] = new_timestamp
                        if old_timestamp:
                            self._events.trigger("changed", path, float(new_timestamp))
                        else:
                            self._events.trigger("created", path, float(new_timestamp))
                except FileNotFoundError:
                    if old_timestamp:
                        self._paths[path]["timestamp"] = 0
                        self._events.trigger("deleted", path, float(old_timestamp))

    def add(self, path):
        if not path in self._paths:
            if os.path.exists(path):
                self._paths[path] = {
                    "timestamp": os.path.getmtime(path)
                }
            else:
                self._paths[path] = {
                    "timestamp": 0
                }
            if not self.get_active():
                self.set_active(True)

    def remove(self, path):
        if path in self._paths:
            del self._paths[path]
            if not len(self._paths):
                self.set_active(False)

    def get_paths(self):
        return list(self._paths.keys())

    def get_active(self):
        return self._active

    def set_active(self, value):
        if value and not self._active:
            self._active = True
            self._thread.start()
        elif not value and self._active and not self._stopped:
            self._stopped = True
            self._thread.join()
            self._stopped = False
            self._active = False

    def hook(self, event, callback):
        return self._events.hook(event, callback)

    def release(self, id):
        self._events.release(id)
