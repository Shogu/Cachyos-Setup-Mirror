# Iconostase

Iconostase rassemble en une seule appli GNOME (GTK4 / libadwaita, Python) tout ce qui touche à l'habillage du bureau :
les icônes des applications, en couleur **et** en symbolique, les lanceurs du menu et les icônes des dossiers.

C'est un fork de [Libre Menu Editor](https://codeberg.org/libre-menu-editor/libre-menu-editor) (GPL-3.0),
nettoyé pour GNOME 50/51, auquel s'ajoutent les outils maison `icones-ogu` et `dossiers-ogu`.
Usage strictement personnel.

## Installation

```sh
sudo pacman -U iconostase-<version>-1-any.pkg.tar.zst
```

Dépendances : `python`, `python-gobject`, `gtk4`, `libadwaita`, `gdk-pixbuf2`, `librsvg`.
Le code est installé dans `/usr/lib/iconostase/`, avec un lanceur minimal `/usr/bin/iconostase`.

## Ce que fait l'appli

### Onglet Applications

Toute l'édition des lanceurs `.desktop` de Libre Menu Editor : nom, commentaire, commande, répertoire de travail,
actions, mots-clés, catégories, terminal, visibilité, GPU dédié…

La partie **Apparence** gère les deux icônes d'une appli :

- **Icône couleur** : choisie dans le thème (recherche) ou depuis un fichier SVG/PNG.
- **Icône symbolique** : aperçu en clair et en sombre, choix d'un SVG.

Une icône choisie depuis un fichier est installée dans `~/.local/share/icons/hicolor/` sous le nom du lanceur,
et le lanceur reçoit `Icon=nom` (sans chemin). C'est indispensable : GNOME ne trouve la version symbolique
d'une icône que par son nom (`nom-symbolic`). Un lanceur qui désigne son icône par un chemin affiche un bouton
**Convertir** qui fait cette opération d'un clic.

Si une appli livre des PNG en tailles fixes, Iconostase pose aussi des PNG de ton icône dans ces tailles :
sinon GNOME préférerait ceux du paquet.

Les badges de la liste signalent les lanceurs à revoir :

| Badge | Signification |
|---|---|
| triangle orange | icône désignée par un chemin, ou introuvable |
| petite icône grise | pas de version symbolique |
| flèche bleue | le paquet a mis à jour ce lanceur depuis ta personnalisation |

### Lanceurs mis à jour par leur paquet

Modifier un lanceur système crée une copie dans `~/.local/share/applications`, que GNOME utilise à la place
de celui du paquet. Iconostase garde l'original du paquet tel qu'il était à ce moment
(`~/.local/share/iconostase/origines/`) et le compare au fichier actuel du paquet.

Si le paquet a changé son lanceur depuis (nouvelle commande, nouvelle action…), un bandeau s'affiche avec **Voir…** :
la liste des changements du paquet, puis **Reprendre la mise à jour** (repart du nouveau lanceur et y remet
seulement ce que tu avais modifié, ton icône par exemple) ou **Garder ma version**. Les deux s'annulent.

Pour un lanceur déjà personnalisé avant l'installation d'Iconostase, la comparaison part du jour où il le voit
pour la première fois.

### Onglet Dossiers

Même disposition que l'onglet Applications : la liste à gauche, le dossier choisi à droite.

- **Dossiers spéciaux** : les huit dossiers de `~/.config/user-dirs.dirs` (Bureau, Documents, Téléchargements,
  Modèles, Public, Musique, Images, Vidéos), avec leur état :
  - *Dossier spécial* : visible normalement ;
  - *Masqué* : renommé avec un point devant (`.Bureau`), `user-dirs.dirs` suit ;
  - *Désactivé* : `user-dirs.dirs` le fait pointer vers le dossier personnel, il n'existe donc pas en tant que dossier.
  L'interrupteur **Masqué** bascule entre visible et masqué ; un dossier désactivé est considéré comme masqué.
- **Mes dossiers** : le bouton **+** ajoute un dossier (créé tout de suite s'il n'existe pas, sous-dossiers compris)
  ou reprend un dossier existant. À droite : l'icône actuelle, la grille de toutes les icônes de dossiers
  de ta collection (un clic pour changer), **Autre image…**, retour à l'icône d'origine,
  **Recréer s'il manque** et **Retirer de la liste** (le dossier n'est jamais supprimé du disque).
- **Tout réappliquer** (en bas de la liste) : recrée les dossiers manquants, remet leurs icônes et masque
  les dossiers choisis comme masqués.

Au premier affichage, Iconostase parcourt ton dossier personnel (deux niveaux) et reprend les dossiers qui portent
déjà une icône personnalisée, par exemple posée par l'ancien outil `dossiers-ogu` : l'icône est copiée dans sa
collection, le dossier apparaît dans la liste et entre dans les sauvegardes.

Les icônes passent par l'attribut `metadata::custom-icon` de GVfs, celui que lit Fichiers : le dossier lui-même
ne contient rien, seul ce pointeur vers le fichier d'icône est enregistré.

### Menu principal

| Entrée | Rôle |
|---|---|
| Exporter des icônes à redessiner… | ZIP des icônes cochées (celles à revoir le sont d'office), renommées avec l'identifiant du lanceur, plus un `inventaire.tsv` |
| Importer des icônes redessinées… | Reprend un ZIP de `nom.svg` / `nom-symbolic.svg` : installe les icônes et corrige `Icon=` des lanceurs concernés |
| Lanceurs orphelins… | Lanceurs dont la commande n'existe plus : masquer, ou supprimer pour les lanceurs faits main |
| Annuler la dernière modification | Revient en arrière, jusqu'aux 20 derniers changements |
| Exporter la sauvegarde… / Importer une sauvegarde… | Archive complète pour une réinstallation |

Le menu principal est le même dans les deux onglets : la sauvegarde est toujours complète.
Le menu ⋮ d'un lanceur propose aussi **Exporter l'icône…** pour une seule appli.

Un point sur le bouton de menu rappelle que des modifications n'ont pas encore été exportées.

## Circuit de refonte d'icônes

1. **Exporter des icônes à redessiner…** : on récupère `icones-a-redessiner-AAAA-MM-JJ.zip`.
2. On redessine les icônes en gardant les noms de fichiers (`com.ogu.Grabber.svg`, `com.ogu.Grabber-symbolic.svg`…).
3. **Importer des icônes redessinées…** avec le ZIP retourné : tout est installé et les lanceurs sont corrigés.
   Une fausse manipulation s'annule depuis le message qui s'affiche ou depuis le menu.

## Sauvegarde

L'archive `iconostase-AAAA-MM-JJ.tar.gz` contient :

```
manifeste.json   version, date, nombres, dossiers masqués
maison/          toutes les icônes ajoutées à la main, rangées comme dans ton dossier personnel :
                 ~/.local/share/icons (tous thèmes et toutes catégories : applis, symboliques,
                 types de fichiers, emplacements…), ~/.local/share/pixmaps, ~/.icons,
                 et les images de ton dossier personnel désignées par un chemin dans un lanceur
lanceurs/        les .desktop de ~/.local/share/applications
dossiers/        icônes des dossiers
dossiers.json    dossiers, icônes, « recréer s'il manque », dossiers masqués
```

À l'import, un résumé s'affiche avant de restaurer. Les dossiers Dropbox gardent « Recréer s'il manque » désactivé
pour ne pas devancer le client Dropbox ; ils sont signalés « laissés tels quels » tant qu'ils n'existent pas.

Les icônes des paquets installés (`/usr/share/icons`) ne sont jamais sauvegardées : elles reviennent avec les paquets.
Les archives plus anciennes (dossier `icones/`) restent lisibles.

## Où sont les données

| Emplacement | Contenu |
|---|---|
| `~/.local/share/icons/hicolor/` | icônes installées (thème utilisateur) |
| `~/.local/share/applications/` | lanceurs modifiés ou faits main |
| `~/.local/share/iconostase/icones/` | collection des icônes sources |
| `~/.local/share/iconostase/dossiers/`, `dossiers.json` | icônes et plan des dossiers |
| `~/.local/share/iconostase/historique/` | instantanés pour « Annuler » |
| `~/.local/share/iconostase/origines/` | lanceurs des paquets tels qu'ils étaient lors de ta personnalisation |
| `~/.local/share/iconostase/config.json` | réglages de la fenêtre |

## Développement

```
main.py                    point d'entrée (gettext, nom du processus)
iconostase/
  application.py           fenêtre, menus, export/import, annulation
  base_application.py      Adw.Application, chemins, thème d'icônes
  settings_page.py         page d'édition d'un lanceur
  desktop_entry.py         lecture/écriture des .desktop
  icon_store.py            pose des icônes couleur et symbolique
  icon_batch.py            export/import d'icônes en lot
  history.py               instantanés et annulation
  launcher_updates.py      détection et fusion des mises à jour de lanceurs
  folder_icons.py          icônes, création et masquage des dossiers
  folders_page.py          onglet Dossiers
  backup.py                sauvegarde complète
  orphans_dialog.py, icons_export_dialog.py
  core/                    échappement Exec=, évènements, config, surveillance de fichiers
  widgets/                 lignes, liste, navigateur d'icônes, menus
fr.po                      traduction française (compilée en locale/fr/LC_MESSAGES/iconostase.mo)
build_pkg.sh               construit le paquet pacman sans makepkg
convertir_pyz.py           convertit les anciens exports icones-ogu et dossiers-ogu en sauvegarde
```

Après une modification de `fr.po` :

```sh
msgfmt -o locale/fr/LC_MESSAGES/iconostase.mo fr.po
```

Code écrit selon les règles GNOME (EGO / gjs.guide) : une seule version cible, pas de vérifications défensives,
pas d'appels shell évitables (seul `gtk-update-icon-cache` reste, faute d'API).

## Licence

GPL-3.0-or-later, comme Libre Menu Editor (© 2022 Free Software Foundation).
