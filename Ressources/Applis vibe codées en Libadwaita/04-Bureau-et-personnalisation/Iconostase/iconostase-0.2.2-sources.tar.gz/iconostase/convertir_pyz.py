"""Construit une première sauvegarde Iconostase à partir des exports icones-ogu et dossiers-ogu."""
import datetime, io, json, os, sys, tarfile, zipfile

icones_pyz, dossiers_pyz, sortie = sys.argv[1:4]
manifest = {"version": "0.1.0", "date": datetime.datetime.now().isoformat(timespec="seconds")}
with zipfile.ZipFile(icones_pyz) as zi, zipfile.ZipFile(dossiers_pyz) as zd, tarfile.open(sortie, "w:gz") as tar:
    def add(name, data):
        info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644
        tar.addfile(info, io.BytesIO(data))
    icones = [n for n in zi.namelist() if n.startswith("bundle/icones/") and n.endswith((".svg", ".png"))]
    lanceurs = [n for n in zi.namelist() if n.startswith("bundle/lanceurs/") and n.endswith(".desktop")]
    for n in icones:
        add("icones/" + os.path.basename(n), zi.read(n))
    for n in lanceurs:
        add("lanceurs/" + os.path.basename(n), zi.read(n))
    plan = json.loads(zd.read("bundle/plan.json"))
    fichiers = {os.path.splitext(os.path.basename(n))[0]: os.path.basename(n)
                for n in zd.namelist() if n.startswith("bundle/icones/") and n.endswith((".svg", ".png"))}
    for nom, fichier in fichiers.items():
        add("dossiers/" + fichier, zd.read("bundle/icones/" + fichier))
    dossiers = [{"chemin": d["chemin"], "icone": fichiers.get(d["icone"]), "creer": d["creer"]} for d in plan["dossiers"]]
    add("dossiers.json", json.dumps({"dossiers": dossiers, "masques": plan["masques"]}, ensure_ascii=False, indent=1).encode())
    manifest.update(icones=len(icones), lanceurs=len(lanceurs),
                    dossiers=len([d for d in dossiers if d["icone"]]), masques=plan["masques"])
    add("manifeste.json", json.dumps(manifest, ensure_ascii=False, indent=1).encode())
print(json.dumps(manifest, ensure_ascii=False))
