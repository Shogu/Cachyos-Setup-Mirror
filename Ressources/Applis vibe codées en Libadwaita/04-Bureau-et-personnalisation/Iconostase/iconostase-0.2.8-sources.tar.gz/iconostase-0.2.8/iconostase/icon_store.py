# SPDX-License-Identifier: GPL-3.0-or-later
import enum
import os
import re
import shutil

import gi
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import GdkPixbuf, Gio, GLib  # noqa: E402

USER_THEME = os.path.join(GLib.get_user_data_dir(), "icons", "hicolor")


def theme_folder(kind):
    path = os.path.join(USER_THEME, kind, "apps")
    os.makedirs(path, exist_ok=True)
    return Gio.File.new_for_path(path)


def theme_icon_name(path):
    if os.path.realpath(path).startswith(os.path.realpath(USER_THEME) + os.sep):
        return os.path.splitext(os.path.basename(path))[0].removesuffix("-symbolic")
    return None
PNG_SIZES = (16, 24, 32, 48, 64, 128, 256, 512)
SIZE_DIR = re.compile(r"^(\d+)x\d+(?:@(\d+))?$")


class IconState(enum.Enum):
    OK = "ok"
    BY_PATH = "by-path"
    MISSING = "missing"
    NO_SYMBOLIC = "no-symbolic"


def system_hicolor_dirs():
    roots = [os.path.join(GLib.get_user_data_dir(), "flatpak", "exports", "share"),
             "/var/lib/flatpak/exports/share", *GLib.get_system_data_dirs()]
    return [path for path in (os.path.join(root, "icons", "hicolor") for root in roots) if os.path.isdir(path)]


class IconStore:
    def __init__(self, icon_theme):
        self._icon_theme = icon_theme

    def state(self, icon):
        if not icon or os.path.sep in icon:
            return IconState.BY_PATH if icon else IconState.MISSING
        if not self._icon_theme.has_icon(icon):
            return IconState.MISSING
        if not self._icon_theme.has_icon(f"{icon}-symbolic"):
            return IconState.NO_SYMBOLIC
        return IconState.OK

    def has_symbolic(self, name):
        return bool(name) and os.path.sep not in name and self._icon_theme.has_icon(f"{name}-symbolic")

    def install_color(self, name, source):
        extension = os.path.splitext(source)[1].lower()
        if extension == ".svg":
            self._copy(source, os.path.join(USER_THEME, "scalable", "apps", f"{name}.svg"))
        else:
            width = GdkPixbuf.Pixbuf.get_file_info(source)[1]
            size = next((size for size in PNG_SIZES if width <= size), PNG_SIZES[-1])
            self._copy(source, os.path.join(USER_THEME, f"{size}x{size}", "apps", f"{name}.png"))
        self._mask_system_pngs(name, source)

    def install_symbolic(self, name, source):
        self._copy(source, os.path.join(USER_THEME, "symbolic", "apps", f"{name}-symbolic.svg"))

    def refresh(self):
        Gio.Subprocess.new(["gtk-update-icon-cache", "-q", "-f", "-t", USER_THEME], Gio.SubprocessFlags.STDERR_SILENCE)
        self._icon_theme.set_search_path(self._icon_theme.get_search_path())

    def _mask_system_pngs(self, name, source):
        for base in system_hicolor_dirs():
            for size_dir in os.listdir(base):
                match = SIZE_DIR.match(size_dir)
                if match and os.path.isfile(os.path.join(base, size_dir, "apps", f"{name}.png")):
                    pixels = int(match.group(1)) * int(match.group(2) or 1)
                    target = os.path.join(USER_THEME, size_dir, "apps", f"{name}.png")
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    GdkPixbuf.Pixbuf.new_from_file_at_size(source, pixels, pixels).savev(target, "png", [], [])

    @staticmethod
    def _copy(source, target):
        os.makedirs(os.path.dirname(target), exist_ok=True)
        shutil.copyfile(source, target)


def icon_name_for(desktop_name, current_icon):
    if current_icon and os.path.sep not in current_icon:
        return current_icon
    return desktop_name
