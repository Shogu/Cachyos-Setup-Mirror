import GObject from 'gi://GObject';
import St from 'gi://St';
import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import Shell from 'gi://Shell';

import {Extension, gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

// Icône native Adwaita monochrome à l'état inactif : le bouton radio
// "radio" (non coché) — évoque directement un état binaire off/on.
const BASE_ICON = 'radio-symbolic';

// Icône monochrome générique (jamais d'icône couleur dans la topbar).
const FALLBACK_ICON = 'application-x-executable-symbolic';

// Relais monochrome : quand une app est épinglée, on affiche une icône
// symbolique native Adwaita. Correspondances prioritaires par app.
const APP_SYMBOLIC = {
    'ptyxis': 'utilities-terminal-symbolic',
    'texteditor': 'text-editor-symbolic',
    'gnome-text-editor': 'text-editor-symbolic',
    'text-editor': 'text-editor-symbolic',
    'nautilus': 'system-file-manager-symbolic',
    'org.gnome.files': 'system-file-manager-symbolic',
    'clapper': 'multimedia-player-symbolic',
    'grimoire': 'accessories-dictionary-symbolic',
};

const AlwaysOnTopIndicator = GObject.registerClass(
class AlwaysOnTopIndicator extends PanelMenu.Button {
    _init() {
        // dontCreateMenu = true : une simple icône cliquable, pas un menu.
        super._init(0.0, _('Always on Top'), true);

        // Cartouche de survol carrée/ronde alignée sur les icônes de statut
        // voisines (padding égal, cf. stylesheet.css), au lieu de la pilule
        // oblongue par défaut (padding horizontal seul) de .panel-button.
        this.add_style_class_name('aot-indicator');

        this._tracker = Shell.WindowTracker.get_default();

        // Fenêtre actuellement épinglée (si aucune, null) — indépendant du
        // focus, pour que l'icône reste correcte même après avoir changé
        // de fenêtre.
        this._pinnedWindow = null;
        this._pinnedAboveId = 0;
        this._pinnedUnmanagedId = 0;

        // Fenêtre focus : juste pour détecter un épinglage fait via le menu
        // natif de la barre de titre pendant qu'elle a le focus.
        this._focusedWindow = null;
        this._focusedAboveId = 0;

        // Taille standard "system-status-icon" : alignée sur les autres icônes.
        this._icon = new St.Icon({
            style_class: 'system-status-icon',
            gicon: this._baseIcon(),
        });
        this.add_child(this._icon);

        this.accessible_name = _('Always on Top');

        this.connect('button-press-event', this._onButtonPress.bind(this));
        this.connect('key-press-event', this._onKeyPress.bind(this));
        this.connect('destroy', this._onDestroy.bind(this));

        this._focusSignalId = global.display.connect(
            'notify::focus-window',
            () => this._onFocusChanged()
        );

        this._onFocusChanged();
    }

    _baseIcon() {
        return new Gio.ThemedIcon({name: BASE_ICON});
    }

    // Icône monochrome de l'app épinglée : correspondance Adwaita prioritaire,
    // sinon variante -symbolic déclarée par l'app, sinon générique mono.
    _appIconFor(win) {
        const app = this._tracker.get_window_app(win);
        if (!app)
            return this._baseIcon();

        const id = (app.get_id() || '').toLowerCase();
        for (const key in APP_SYMBOLIC) {
            if (id.includes(key))
                return new Gio.ThemedIcon({name: APP_SYMBOLIC[key]});
        }

        const gicon = app.get_icon();
        if (gicon instanceof Gio.ThemedIcon) {
            const names = gicon.get_names();
            const withFallback = [];
            for (const n of names)
                withFallback.push(`${n}-symbolic`);
            withFallback.push(FALLBACK_ICON);
            return Gio.ThemedIcon.new_from_names(withFallback);
        }

        return new Gio.ThemedIcon({name: FALLBACK_ICON});
    }

    _onFocusChanged() {
        if (this._focusedWindow && this._focusedAboveId) {
            this._focusedWindow.disconnect(this._focusedAboveId);
            this._focusedAboveId = 0;
        }

        this._focusedWindow = global.display.focus_window;

        if (this._focusedWindow) {
            this._focusedAboveId = this._focusedWindow.connect(
                'notify::above',
                () => this._onAboveChanged(this._focusedWindow)
            );
            // Rattrape une fenêtre déjà épinglée avant qu'on la surveille
            // (épinglée via le menu natif, ou avant l'activation de
            // l'extension).
            this._onAboveChanged(this._focusedWindow);
        }
    }

    _onAboveChanged(win) {
        if (win.is_above())
            this._setPinnedWindow(win);
        else if (win === this._pinnedWindow)
            this._clearPinnedWindow();
    }

    _setPinnedWindow(win) {
        if (this._pinnedWindow === win)
            return;

        this._clearPinnedWindow();
        this._pinnedWindow = win;
        // S'il y avait déjà une autre fenêtre épinglée, elle reste
        // épinglée (pas de restriction) : c'est juste l'icône qui montre
        // désormais celle-ci, la plus récemment épinglée.
        this._pinnedAboveId = win.connect(
            'notify::above',
            () => this._onAboveChanged(win)
        );
        this._pinnedUnmanagedId = win.connect(
            'unmanaging',
            () => this._clearPinnedWindow()
        );
        this._syncIcon();
    }

    _clearPinnedWindow() {
        if (!this._pinnedWindow)
            return;

        if (this._pinnedAboveId) {
            this._pinnedWindow.disconnect(this._pinnedAboveId);
            this._pinnedAboveId = 0;
        }
        if (this._pinnedUnmanagedId) {
            this._pinnedWindow.disconnect(this._pinnedUnmanagedId);
            this._pinnedUnmanagedId = 0;
        }
        this._pinnedWindow = null;
        this._syncIcon();
    }

    _syncIcon() {
        // Actif : relais vers l'icône monochrome de l'app épinglée — quelle
        // que soit la fenêtre qui a le focus en ce moment.
        // Inactif : bouton radio natif "radio". L'icône seule signale l'état.
        this._icon.set_gicon(
            this._pinnedWindow
                ? this._appIconFor(this._pinnedWindow)
                : this._baseIcon()
        );
    }

    _onButtonPress(_actor, event) {
        if (event.get_button() !== Clutter.BUTTON_PRIMARY)
            return Clutter.EVENT_PROPAGATE;

        return this._toggleFocusedWindow();
    }

    // Activation clavier (navigation Ctrl+Alt+Tab → barre supérieure).
    _onKeyPress(_actor, event) {
        const symbol = event.get_key_symbol();
        if (symbol !== Clutter.KEY_space &&
            symbol !== Clutter.KEY_Return &&
            symbol !== Clutter.KEY_KP_Enter &&
            symbol !== Clutter.KEY_ISO_Enter)
            return Clutter.EVENT_PROPAGATE;

        return this._toggleFocusedWindow();
    }

    _toggleFocusedWindow() {
        const win = global.display.focus_window;
        if (!win)
            return Clutter.EVENT_PROPAGATE;

        // Exactement ce qu'appelle GNOME Shell en interne pour l'option
        // "Toujours au premier plan" du menu de la fenêtre.
        if (win.is_above())
            win.unmake_above();
        else
            win.make_above();

        return Clutter.EVENT_STOP;
    }

    _onDestroy() {
        if (this._focusSignalId) {
            global.display.disconnect(this._focusSignalId);
            this._focusSignalId = 0;
        }
        if (this._focusedWindow && this._focusedAboveId) {
            this._focusedWindow.disconnect(this._focusedAboveId);
            this._focusedAboveId = 0;
        }
        this._clearPinnedWindow();
    }
});

export default class AlwaysOnTopAlwaysOnTopExtension extends Extension {
    enable() {
        this._indicator = new AlwaysOnTopIndicator();
        // Avant-dernière place de la zone de droite : juste avant le menu
        // système (Quick Settings), qui reste en bout de ligne.
        const rightBox = Main.panel._rightBox;
        const position = Math.max(0, rightBox.get_n_children() - 1);
        Main.panel.addToStatusArea(this.uuid, this._indicator, position, 'right');
    }

    disable() {
        this._indicator?.destroy();
        this._indicator = null;
    }
}
