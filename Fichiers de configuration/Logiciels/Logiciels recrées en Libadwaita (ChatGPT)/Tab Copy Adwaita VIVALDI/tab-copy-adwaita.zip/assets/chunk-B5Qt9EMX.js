/**
 * @license
 * Tab Copy - A browser extension for copying tabs to the clipboard
 * in a variety of formats.
 * Copyright (C) 2011-present, Hans Meyer, https://github.com/hansifer
 * 
 * Creative Commons Attribution-NonCommercial-NoDerivatives 4.0
 * International Public License
 * 
 * By using the code or any other material in this repository, you
 * agree to the terms of the following license:
 * 
 * You are free to:
 * 
 * Share - copy and redistribute the material in any medium or format
 * 
 * The licensor cannot revoke these freedoms as long as you follow
 * the license terms.
 * 
 * Under the following terms:
 * 
 * Attribution - You must give appropriate credit, provide a link to
 * the license, and indicate if changes were made. You may do so in
 * any reasonable manner, but not in any way that suggests the
 * licensor endorses you or your use.
 * 
 * NonCommercial - You may not use the material for commercial purposes.
 * 
 * NoDerivatives - If you remix, transform, or build upon the material,
 * you may not distribute the modified material.
 * 
 * No additional restrictions - You may not apply legal terms or
 * technological measures that legally restrict others from doing
 * anything the license permits.
 * 
 * No warranties are given. The license may not give you all of the
 * permissions necessary for your intended use. For example, other rights
 * such as publicity, privacy, or moral rights may limit how you use
 * the material.
 * 
 * Full Text of the License:
 * https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode
 */

(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))i(e);new MutationObserver(e=>{for(const r of e)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&i(o)}).observe(document,{childList:!0,subtree:!0});function s(e){const r={};return e.integrity&&(r.integrity=e.integrity),e.referrerPolicy&&(r.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?r.credentials="include":e.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function i(e){if(e.ep)return;e.ep=!0;const r=s(e);fetch(e.href,r)}})();
