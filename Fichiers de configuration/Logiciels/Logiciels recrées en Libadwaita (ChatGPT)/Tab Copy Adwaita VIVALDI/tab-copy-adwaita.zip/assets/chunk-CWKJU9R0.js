/**
 * @license
 * Tab Copy - A browser extension for copying tabs to the clipboard
 * in a variety of formats.
 * Copyright (C) 2011-present, Hans Meyer, https://github.com/hansifer
 * 
 * Creative Commons Attribution-NonCommercial-NoDerivatives 4.0
 * International Public License
 * 
 * By using the code or any other material in this repository, you
 * agree to the terms of the following license:
 * 
 * You are free to:
 * 
 * Share - copy and redistribute the material in any medium or format
 * 
 * The licensor cannot revoke these freedoms as long as you follow
 * the license terms.
 * 
 * Under the following terms:
 * 
 * Attribution - You must give appropriate credit, provide a link to
 * the license, and indicate if changes were made. You may do so in
 * any reasonable manner, but not in any way that suggests the
 * licensor endorses you or your use.
 * 
 * NonCommercial - You may not use the material for commercial purposes.
 * 
 * NoDerivatives - If you remix, transform, or build upon the material,
 * you may not distribute the modified material.
 * 
 * No additional restrictions - You may not apply legal terms or
 * technological measures that legally restrict others from doing
 * anything the license permits.
 * 
 * No warranties are given. The license may not give you all of the
 * permissions necessary for your intended use. For example, other rights
 * such as publicity, privacy, or moral rights may limit how you use
 * the material.
 * 
 * Full Text of the License:
 * https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode
 */

import"./chunk-B5Qt9EMX.js";import{a as h,h as j,o as q,j as J,c as N}from"./chunk-RZ7wazaN.js";import{f as S,J as m,i as y,K as U,L as z,N as I,h as Q,O as f,P as g,Q as R,b as P,R as L,a as T,g as O}from"./chunk-CfcWDim6.js";import{h as W,b as Z}from"./chunk-BaW50-Ur.js";import{s as $}from"./chunk-CnGWnZe7.js";import{s as k}from"./chunk-4cUrahGi.js";import"./chunk-CgOJoJEc.js";const G=`<svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    >
  <line
      x1="21"
      x2="14"
      y1="4"
      y2="4"
      />
  <line
      x1="10"
      x2="3"
      y1="4"
      y2="4"
      />
  <line
      x1="21"
      x2="12"
      y1="12"
      y2="12"
      />
  <line
      x1="8"
      x2="3"
      y1="12"
      y2="12"
      />
  <line
      x1="21"
      x2="16"
      y1="20"
      y2="20"
      />
  <line
      x1="12"
      x2="3"
      y1="20"
      y2="20"
      />
  <line
      x1="14"
      x2="14"
      y1="2"
      y2="6"
      />
  <line
      x1="8"
      x2="8"
      y1="10"
      y2="14"
      />
  <line
      x1="16"
      x2="16"
      y1="18"
      y2="22"
      />
</svg>`,X=`<svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
    >
  <circle
      cx="12"
      cy="12"
      r="10"
      />
  <path d="M12 16v-4" />
  <path d="M12 8h.01" />
</svg>`,Y=`<svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
    >
  <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
</svg>`,_=1e3*60*60*24*30;let b=null,l=null,p=!1;tt();function tt(){nt(),et(),ot(),at();const e=["customFormatIds","orderedFormatIds","hiddenFormatIds","formatOpts"];chrome.storage.onChanged.addListener(S(()=>{x({refocus:!0})},{listen:e,throttle:500})),document.documentElement.addEventListener("mousedown",()=>{A()})}async function nt(){if(m("header-text").textContent=y.copy(),!(await h("showHeaderIcons")).value)return;const s=document.createElement("div");s.classList.add("headerButtons");const a=n();d(a,G);const c=document.createElement("span");c.textContent=k(y.options()),a.appendChild(c),a.addEventListener("click",()=>{chrome.runtime.openOptionsPage()}),s.appendChild(a);const t=n();t.style.marginLeft="auto",d(t,X),t.addEventListener("click",()=>{chrome.tabs.create({url:"https://tabcopy.com/docs"})}),s.appendChild(t);const o=await U("donateHidden");if(!o||Date.now()-o>_){const r=n();d(r,Y),r.addEventListener("click",()=>{chrome.tabs.create({url:"https://tabcopy.com/donate"}),z("donateHidden",Date.now())}),s.appendChild(r)}I("header").appendChild(s);function n(){const r=document.createElement("button");return r.setAttribute("tabindex","-1"),r}function d(r,w){r.appendChild(new DOMParser().parseFromString(w,"image/svg+xml").documentElement)}}async function et(){const e=m("copy-buttons"),s=await Q(),c={highlightedTabCount:(await j("highlighted-tabs")).length};for(const i of s){const u=document.createElement("button");u.dataset.scope=i.id,u.classList.add("button-primary"),u.textContent=k(i.label(c)),e.appendChild(u)}e.style.removeProperty("display");const t=Array.from(e.children);t[0]?.focus();const o=i=>{g(i.currentTarget)&&F(B(i))},n=async i=>{const u=i.currentTarget;if(g(u)){F(B(i));const M=u.dataset.scope,K=await H();try{await N({scopeId:M,format:K}),window.close()}catch(V){console.error(V),t.forEach(E=>E.style.backgroundColor=u===E?"#7a2c2c":"")}}},d=i=>{i.code==="Enter"&&(n(i),i.preventDefault())};f(t,["keydown","keyup"],o),f(t,"click",n),f(t,"keydown",d),f(t,"focus",A),f(t,"blur",rt),setTimeout(()=>{f(t,"mouseenter",i=>{g(i.currentTarget)&&!i.buttons&&i.currentTarget.focus()})},100);const r=$(),w=["options"];chrome.storage.onChanged.addListener(S(()=>{r(v)},{listen:w,throttle:500})),q(()=>{r(v)}),r(v)}async function v(){const e=(await h("showTabCounts")).value,s=m("copy-buttons"),a=Array.from(s.children);if(document.body.classList.toggle("with-counts",e),!e){for(const n of a)n.style.removeProperty("--count"),n.classList.remove("single-digit-count"),n.removeAttribute("disabled"),n.removeAttribute("title");return}const t=(await h("ignorePinnedTabs")).value?({pinned:n})=>!n:void 0,o=await J(t);for(const n of a){const d=n.dataset.scope,r=d==="all-windows-and-tabs"?o["all-tabs"]:o[d];d==="highlighted-tabs"&&r===1?n.style.removeProperty("--count"):n.style.setProperty("--count",JSON.stringify(r.toString())),n.classList.toggle("single-digit-count",r<10),r?(n.toggleAttribute("disabled",!1),n.removeAttribute("title")):(n.toggleAttribute("disabled",!0),n.setAttribute("title",y.noTabsFound()))}}async function ot(){p=(await h("keepFormatSelectorExpanded")).value,await x();const e=async t=>{if(g(t.target)){const o=t.target.getAttribute("id"),n=await O();l=o===n?null:o,x(),A(),setTimeout(()=>{I(".button-primary")?.focus()},p?100:0)}},s=t=>{t.code==="Enter"&&(e(t),t.preventDefault())},a=m("format-selector");a.addEventListener("click",e),a.addEventListener("keydown",s),a.addEventListener("mouseover",t=>{g(t.target)&&!t.buttons&&t.target.focus()});const c=R("default-format-btn");p||(c.addEventListener("click",()=>{C()}),f([a,c],"mousedown",t=>{t.stopPropagation()})),p&&(c.classList.add("keep-expanded"),c.setAttribute("disabled","disabled")),C(p),m("format-section").style.removeProperty("display")}function at(){document.addEventListener("keydown",({code:e})=>{if(e!=="ArrowUp"&&e!=="ArrowDown")return;const s=Array.from(m("copy-buttons").children),a=s.indexOf(document.activeElement),c=Math.min(s.length-1,Math.max(0,a+(e==="ArrowUp"?-1:1)));s[c]?.focus()})}async function x({refocus:e}={}){const s=await P({visibleOnly:!0}),a=m("format-selector"),c=Array.from(a.querySelectorAll("button")),t=e&&c.find(o=>o===document.activeElement)?.getAttribute("id");a.innerHTML="";for(const o of s)if(l?l!==o.id:!o.isDefault){const n=document.createElement("button");n.setAttribute("id",o.id),n.classList.add("button-secondary");const d=document.createElement("span");d.classList.add("button-label"),d.textContent=o.label,n.appendChild(d),a.appendChild(n),t&&o.id===t&&n.focus()}l&&!s.some(({id:o})=>o===l)&&(l=null),D()}async function D(){L("copy-as-label").textContent=k(`${st()?y.copy1xAs():y.copyAs()}:`);const e=await H();L("default-format-label").textContent=e.label}function C(e){m("format-section").classList.toggle("expanded",e)}function A(){p||C(!1)}async function H(){return l?T(l):b?(await P({visibleOnly:!0}))[b==="secondary"?1:2]:T(await O())}function st(){return!!(l||b)}function B(e){return W(e)?"ternary":Z(e)?"secondary":null}function rt(){F(null)}function F(e){b=e,D()}
