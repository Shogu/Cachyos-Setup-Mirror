/**
 * @license
 * Tab Copy - A browser extension for copying tabs to the clipboard
 * in a variety of formats.
 * Copyright (C) 2011-present, Hans Meyer, https://github.com/hansifer
 * 
 * Creative Commons Attribution-NonCommercial-NoDerivatives 4.0
 * International Public License
 * 
 * By using the code or any other material in this repository, you
 * agree to the terms of the following license:
 * 
 * You are free to:
 * 
 * Share - copy and redistribute the material in any medium or format
 * 
 * The licensor cannot revoke these freedoms as long as you follow
 * the license terms.
 * 
 * Under the following terms:
 * 
 * Attribution - You must give appropriate credit, provide a link to
 * the license, and indicate if changes were made. You may do so in
 * any reasonable manner, but not in any way that suggests the
 * licensor endorses you or your use.
 * 
 * NonCommercial - You may not use the material for commercial purposes.
 * 
 * NoDerivatives - If you remix, transform, or build upon the material,
 * you may not distribute the modified material.
 * 
 * No additional restrictions - You may not apply legal terms or
 * technological measures that legally restrict others from doing
 * anything the license permits.
 * 
 * No warranties are given. The license may not give you all of the
 * permissions necessary for your intended use. For example, other rights
 * such as publicity, privacy, or moral rights may limit how you use
 * the material.
 * 
 * Full Text of the License:
 * https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode
 */

var Z=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function L(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var $={exports:{}},r={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var y=Symbol.for("react.element"),V=Symbol.for("react.portal"),A=Symbol.for("react.fragment"),F=Symbol.for("react.strict_mode"),U=Symbol.for("react.profiler"),q=Symbol.for("react.provider"),N=Symbol.for("react.context"),z=Symbol.for("react.forward_ref"),B=Symbol.for("react.suspense"),H=Symbol.for("react.memo"),Q=Symbol.for("react.lazy"),b=Symbol.iterator;function G(e){return e===null||typeof e!="object"?null:(e=b&&e[b]||e["@@iterator"],typeof e=="function"?e:null)}var g={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},j=Object.assign,O={};function p(e,t,n){this.props=e,this.context=t,this.refs=O,this.updater=n||g}p.prototype.isReactComponent={};p.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")};p.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function P(){}P.prototype=p.prototype;function S(e,t,n){this.props=e,this.context=t,this.refs=O,this.updater=n||g}var w=S.prototype=new P;w.constructor=S;j(w,p.prototype);w.isPureReactComponent=!0;var R=Array.isArray,x=Object.prototype.hasOwnProperty,k={current:null},D={key:!0,ref:!0,__self:!0,__source:!0};function I(e,t,n){var o,u={},i=null,f=null;if(t!=null)for(o in t.ref!==void 0&&(f=t.ref),t.key!==void 0&&(i=""+t.key),t)x.call(t,o)&&!D.hasOwnProperty(o)&&(u[o]=t[o]);var s=arguments.length-2;if(s===1)u.children=n;else if(1<s){for(var c=Array(s),a=0;a<s;a++)c[a]=arguments[a+2];u.children=c}if(e&&e.defaultProps)for(o in s=e.defaultProps,s)u[o]===void 0&&(u[o]=s[o]);return{$$typeof:y,type:e,key:i,ref:f,props:u,_owner:k.current}}function W(e,t){return{$$typeof:y,type:e.type,key:t,ref:e.ref,props:e.props,_owner:e._owner}}function E(e){return typeof e=="object"&&e!==null&&e.$$typeof===y}function J(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(n){return t[n]})}var C=/\/+/g;function _(e,t){return typeof e=="object"&&e!==null&&e.key!=null?J(""+e.key):t.toString(36)}function h(e,t,n,o,u){var i=typeof e;(i==="undefined"||i==="boolean")&&(e=null);var f=!1;if(e===null)f=!0;else switch(i){case"string":case"number":f=!0;break;case"object":switch(e.$$typeof){case y:case V:f=!0}}if(f)return f=e,u=u(f),e=o===""?"."+_(f,0):o,R(u)?(n="",e!=null&&(n=e.replace(C,"$&/")+"/"),h(u,t,n,"",function(a){return a})):u!=null&&(E(u)&&(u=W(u,n+(!u.key||f&&f.key===u.key?"":(""+u.key).replace(C,"$&/")+"/")+e)),t.push(u)),1;if(f=0,o=o===""?".":o+":",R(e))for(var s=0;s<e.length;s++){i=e[s];var c=o+_(i,s);f+=h(i,t,n,c,u)}else if(c=G(e),typeof c=="function")for(e=c.call(e),s=0;!(i=e.next()).done;)i=i.value,c=o+_(i,s++),f+=h(i,t,n,c,u);else if(i==="object")throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.");return f}function d(e,t,n){if(e==null)return e;var o=[],u=0;return h(e,o,"","",function(i){return t.call(n,i,u++)}),o}function K(e){if(e._status===-1){var t=e._result;t=t(),t.then(function(n){(e._status===0||e._status===-1)&&(e._status=1,e._result=n)},function(n){(e._status===0||e._status===-1)&&(e._status=2,e._result=n)}),e._status===-1&&(e._status=0,e._result=t)}if(e._status===1)return e._result.default;throw e._result}var l={current:null},m={transition:null},X={ReactCurrentDispatcher:l,ReactCurrentBatchConfig:m,ReactCurrentOwner:k};function M(){throw Error("act(...) is not supported in production builds of React.")}r.Children={map:d,forEach:function(e,t,n){d(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return d(e,function(){t++}),t},toArray:function(e){return d(e,function(t){return t})||[]},only:function(e){if(!E(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};r.Component=p;r.Fragment=A;r.Profiler=U;r.PureComponent=S;r.StrictMode=F;r.Suspense=B;r.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=X;r.act=M;r.cloneElement=function(e,t,n){if(e==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+e+".");var o=j({},e.props),u=e.key,i=e.ref,f=e._owner;if(t!=null){if(t.ref!==void 0&&(i=t.ref,f=k.current),t.key!==void 0&&(u=""+t.key),e.type&&e.type.defaultProps)var s=e.type.defaultProps;for(c in t)x.call(t,c)&&!D.hasOwnProperty(c)&&(o[c]=t[c]===void 0&&s!==void 0?s[c]:t[c])}var c=arguments.length-2;if(c===1)o.children=n;else if(1<c){s=Array(c);for(var a=0;a<c;a++)s[a]=arguments[a+2];o.children=s}return{$$typeof:y,type:e.type,key:u,ref:i,props:o,_owner:f}};r.createContext=function(e){return e={$$typeof:N,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},e.Provider={$$typeof:q,_context:e},e.Consumer=e};r.createElement=I;r.createFactory=function(e){var t=I.bind(null,e);return t.type=e,t};r.createRef=function(){return{current:null}};r.forwardRef=function(e){return{$$typeof:z,render:e}};r.isValidElement=E;r.lazy=function(e){return{$$typeof:Q,_payload:{_status:-1,_result:e},_init:K}};r.memo=function(e,t){return{$$typeof:H,type:e,compare:t===void 0?null:t}};r.startTransition=function(e){var t=m.transition;m.transition={};try{e()}finally{m.transition=t}};r.unstable_act=M;r.useCallback=function(e,t){return l.current.useCallback(e,t)};r.useContext=function(e){return l.current.useContext(e)};r.useDebugValue=function(){};r.useDeferredValue=function(e){return l.current.useDeferredValue(e)};r.useEffect=function(e,t){return l.current.useEffect(e,t)};r.useId=function(){return l.current.useId()};r.useImperativeHandle=function(e,t,n){return l.current.useImperativeHandle(e,t,n)};r.useInsertionEffect=function(e,t){return l.current.useInsertionEffect(e,t)};r.useLayoutEffect=function(e,t){return l.current.useLayoutEffect(e,t)};r.useMemo=function(e,t){return l.current.useMemo(e,t)};r.useReducer=function(e,t,n){return l.current.useReducer(e,t,n)};r.useRef=function(e){return l.current.useRef(e)};r.useState=function(e){return l.current.useState(e)};r.useSyncExternalStore=function(e,t,n){return l.current.useSyncExternalStore(e,t,n)};r.useTransition=function(){return l.current.useTransition()};r.version="18.3.1";$.exports=r;var v=$.exports;const ee=L(v),T="(prefers-color-scheme: dark)";function Y(){return!!window?.matchMedia?.(T).matches}const te=()=>{const[e,t]=v.useState(Y);return v.useEffect(()=>{if(!window?.matchMedia)return;const n=window.matchMedia(T),o=u=>{t(u.matches)};return n.addEventListener("change",o),()=>{n.removeEventListener("change",o)}},[]),e};export{ee as R,Z as c,L as g,Y as p,v as r,te as u};
