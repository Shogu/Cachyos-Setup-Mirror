/**
 * @license
 * Tab Copy - A browser extension for copying tabs to the clipboard
 * in a variety of formats.
 * Copyright (C) 2011-present, Hans Meyer, https://github.com/hansifer
 * 
 * Creative Commons Attribution-NonCommercial-NoDerivatives 4.0
 * International Public License
 * 
 * By using the code or any other material in this repository, you
 * agree to the terms of the following license:
 * 
 * You are free to:
 * 
 * Share - copy and redistribute the material in any medium or format
 * 
 * The licensor cannot revoke these freedoms as long as you follow
 * the license terms.
 * 
 * Under the following terms:
 * 
 * Attribution - You must give appropriate credit, provide a link to
 * the license, and indicate if changes were made. You may do so in
 * any reasonable manner, but not in any way that suggests the
 * licensor endorses you or your use.
 * 
 * NonCommercial - You may not use the material for commercial purposes.
 * 
 * NoDerivatives - If you remix, transform, or build upon the material,
 * you may not distribute the modified material.
 * 
 * No additional restrictions - You may not apply legal terms or
 * technological measures that legally restrict others from doing
 * anything the license permits.
 * 
 * No warranties are given. The license may not give you all of the
 * permissions necessary for your intended use. For example, other rights
 * such as publicity, privacy, or moral rights may limit how you use
 * the material.
 * 
 * Full Text of the License:
 * https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode
 */

import{i as r,S as v,T as b,o as $,U as L,s as p}from"./chunk-CfcWDim6.js";const c=[{id:"enablePopup",def:!0,label:()=>r.enablePopup(),description:()=>r.enablePopupDescription()},{id:"showTabCounts",def:!1,label:()=>r.showTabCounts(),description:()=>r.showTabCountsDescription(),requires:"enablePopup"},{id:"keepFormatSelectorExpanded",def:!1,label:()=>r.keepFormatSelectorExpanded(),description:()=>r.keepFormatSelectorExpandedDescription(),requires:"enablePopup"},{id:"showHeaderIcons",def:!0,label:()=>r.showHeaderIcons(),description:()=>r.showHeaderIconsDescription(),requires:"enablePopup"},{id:"showContextMenu",def:!0,label:()=>r.enableContextMenu(),description:()=>r.enableContextMenuDescription()},{id:"provideContextMenuFormatSelection",def:!0,label:()=>r.provideContextMenuFormatSelection(),description:()=>r.provideContextMenuFormatSelectionDescription(),requires:"showContextMenu"},{id:"ignorePinnedTabs",def:!1,label:()=>r.ignorePinnedTabs(),description:()=>r.ignorePinnedTabsDescription()},{id:"notifyOnCopy",def:!1,label:()=>r.notifyOnCopy(),description:()=>r.notifyOnCopyDescription(),requiresPermissions:["notifications"]},{id:"invertIcon",def:!1,label:()=>r.invertIcon(),description:()=>r.invertIconDescription()}],E=c.filter(e=>x(e)&&D(e)).map(({id:e})=>e);function R(e){return c.filter(t=>f(t)&&t.requires===e)}async function S(e){const t=c.find(n=>n.id===e),o=await v(e)??t.def;return{...t,value:o}}function D(e){return typeof e.def=="boolean"}function f(e){return"requires"in e}function x(e){return!f(e)}const P=["pinned","url","title","groupId"];async function h(e){return(await chrome.windows.getAll({populate:!0})).map(o=>({...o,tabs:(o.tabs??[]).filter(n=>n.url&&(!e||e(n)))})).filter(({tabs:o})=>o.length)}async function q(e="all-tabs",t){if(e==="all-tabs"){const{allTabs:i}=await g(t);return i}const{unfilteredWindowTabs:o,filteredWindowTabs:n}=await m(t);return e==="window-tabs"?n:o.filter(({highlighted:i})=>!!i)}async function k(e){const{windows:t,allTabs:o}=await g(e),{unfilteredWindowTabs:n,filteredWindowTabs:i}=await m(e);return{"highlighted-tabs":n.filter(({highlighted:l})=>!!l).length,"window-tabs":i.length,"all-tabs":o.length,"all-windows-and-tabs":t.length}}function H(e,t=500){let o;const n=()=>{clearTimeout(o),o=window.setTimeout(e,t)},i=(l,a)=>{P.some(d=>a.hasOwnProperty(d))&&n()},s=()=>{n()};return chrome.tabs.onUpdated.addListener(i),chrome.tabs.onCreated.addListener(s),chrome.tabs.onRemoved.addListener(s),chrome.tabs.onDetached.addListener(s),chrome.tabs.onAttached.addListener(s),chrome.tabs.onMoved.addListener(s),chrome.tabs.onActivated.addListener(s),chrome.tabs.onHighlighted.addListener(s),chrome.windows.onCreated.addListener(s),chrome.windows.onRemoved.addListener(s),()=>{chrome.tabs.onUpdated.removeListener(i),chrome.tabs.onCreated.removeListener(s),chrome.tabs.onRemoved.removeListener(s),chrome.tabs.onDetached.removeListener(s),chrome.tabs.onAttached.removeListener(s),chrome.tabs.onMoved.removeListener(s),chrome.tabs.onActivated.removeListener(s),chrome.tabs.onHighlighted.removeListener(s),chrome.windows.onCreated.removeListener(s),chrome.windows.onRemoved.removeListener(s)}}let w=1;function j({id:e=w++,tabs:t=[W({windowId:e})]}={}){return{id:e,focused:!1,alwaysOnTop:!1,incognito:!1,state:"normal",type:"normal",tabs:t}}function W({id:e=w++,title:t,url:o="https://example.com",favIconUrl:n,index:i=0,windowId:s=1,active:l=!1}={}){return{id:e,title:t,url:o,favIconUrl:n,index:i,pinned:!1,active:l,highlighted:l,selected:l,windowId:s,incognito:!1,discarded:!1,autoDiscardable:!1,groupId:-1}}async function g(e){const t=await h(e),o=t.flatMap(({tabs:n})=>n).filter(n=>!!n);return{windows:t,allTabs:o}}async function m(e){const t=(await chrome.tabs.query({currentWindow:!0})).filter(n=>n.url),o=t.filter(n=>!e||e(n));return{unfilteredWindowTabs:t,filteredWindowTabs:o}}function u(e,t={}){t.separate&&console.log(""),console.log(`%c${e}`,"color: #0ea9c0;")}async function U({scopeId:e,format:t,useLegacyClipboardWrite:o}){u(`copying scope ${e}...`,{separate:!0});const i=(await S("ignorePinnedTabs")).value?({pinned:a})=>!a:void 0;let s;const l={type:b(e)?"tab":"window",formatId:t.id};try{const a=b(e)?O({tabs:s=await q(e,i),format:t}):M({windows:s=await h(i),format:t});if(o){if(!await $.copyToClipboard(a))throw new Error("legacy clipboard copy failed")}else await L(a);p({status:"success",count:s.length,...l})}catch(a){throw p({status:"fail",...l}),a}return s.length}function O({tabs:e,format:t}){return T(e,A,t)}function M({windows:e,format:t}){return T(e,I,t)}function T(e,t,o){const{label:n,transforms:i}=o;return{text:t(e,i,"text",n),...i.html?{html:t(e,i,"html",n)}:null}}function A(e,t,o,n){const i=t[o];if(!i)throw new Error(`no transform for ${o} in format "${n}"`);return e.length?u(`transforming ${e.length} ${e.length===1?"tab":"tabs"} to "${n}" ${o}`):console.warn(`no tabs to copy as "${n}" ${o}. check filter options.`),`${i.start?.({formatName:n,tabCount:e.length,scopeType:"tab"})??""}${e.map((s,l)=>i.tab?.({tab:s,globalSeq:l+1})??"").join(i.tabDelimiter??"")}${i.end?.({formatName:n,tabCount:e.length})??""}`}function I(e,t,o,n){const i=t[o];if(!i)throw new Error(`no transform for ${o} in format "${n}"`);e.length?u(`transforming ${e.length} ${e.length===1?"window":"windows"} to "${n}" ${o}`):console.warn(`no windows to copy as "${n}" ${o}. check filter options.`);const s=e.flatMap(({tabs:a})=>a).filter(a=>!!a);let l=1;return`${i.start?.({formatName:n,windowCount:e.length,tabCount:s.length,scopeType:"window"})??""}${e.map((a,d)=>`${i.windowStart?.({window:a,seq:d+1,windowCount:e.length,windowTabCount:(a.tabs??[]).length})??""}${(a.tabs??[]).map((y,C)=>i.tab?.({tab:y,globalSeq:l++,windowTabSeq:C+1,windowSeq:d+1,windowCount:e.length})??"").join(i.tabDelimiter??"")}${i.windowEnd?.({window:a,seq:d+1,windowCount:e.length,windowTabCount:(a.tabs??[]).length})??""}`).join(i.windowDelimiter??"")}${i.end?.({formatName:n,windowCount:e.length,tabCount:s.length})??""}`}export{S as a,W as b,U as c,R as d,j as e,I as f,O as g,q as h,D as i,k as j,u as l,H as o,E as t};
