/**
 * @license
 * Tab Copy - A browser extension for copying tabs to the clipboard
 * in a variety of formats.
 * Copyright (C) 2011-present, Hans Meyer, https://github.com/hansifer
 * 
 * Creative Commons Attribution-NonCommercial-NoDerivatives 4.0
 * International Public License
 * 
 * By using the code or any other material in this repository, you
 * agree to the terms of the following license:
 * 
 * You are free to:
 * 
 * Share - copy and redistribute the material in any medium or format
 * 
 * The licensor cannot revoke these freedoms as long as you follow
 * the license terms.
 * 
 * Under the following terms:
 * 
 * Attribution - You must give appropriate credit, provide a link to
 * the license, and indicate if changes were made. You may do so in
 * any reasonable manner, but not in any way that suggests the
 * licensor endorses you or your use.
 * 
 * NonCommercial - You may not use the material for commercial purposes.
 * 
 * NoDerivatives - If you remix, transform, or build upon the material,
 * you may not distribute the modified material.
 * 
 * No additional restrictions - You may not apply legal terms or
 * technological measures that legally restrict others from doing
 * anything the license permits.
 * 
 * No warranties are given. The license may not give you all of the
 * permissions necessary for your intended use. For example, other rights
 * such as publicity, privacy, or moral rights may limit how you use
 * the material.
 * 
 * Full Text of the License:
 * https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode
 */

import{p as m}from"./chunk-Dq6TcfRs.js";const d="application/vnd.nxs",i=`web ${d}`;async function f(e){let t=!1;try{t=(await navigator.permissions.query({name:e})).state==="granted"}catch(o){console.warn(`Unable to check navigator permission "${e}"`,o)}return t}async function D({text:e,html:t,nxs:o}){const c=new ClipboardItem({"text/plain":new Blob([e],{type:"text/plain"}),...t?{"text/html":new Blob([t],{type:"text/html"})}:null,...o&&await h()&&await b()?{[i]:new Blob([JSON.stringify(o)],{type:i})}:null});await navigator.clipboard.write([c])}function y({text:e,html:t},o){o.value=e,o.select();const c=document.oncopy;try{let s="";if(document.oncopy=function(r){if(r.preventDefault(),!r.clipboardData){s="legacy clipboard copy failed";return}try{r.clipboardData.setData("text/plain",e),t&&r.clipboardData.setData("text/html",t)}catch(a){s=`${a?.message||a||"legacy clipboard copy failed"}`}},!document.execCommand("copy"))throw new Error("legacy clipboard copy failed");if(s)throw new Error(s)}finally{document.oncopy=c}}function h(){return f("clipboard-read")}function b(){return f("clipboard-write")}function w(e){return document.getElementById(e)}const g=w,l="offscreen.html",u="offscreen",p={copyToClipboard:async e=>{try{return y(e,g("clipboard")),!0}catch(t){console.error(t)}return!1},prefersColorSchemeDark:async e=>m()},T=Object.fromEntries(Object.keys(p).map(e=>[e,t=>E({type:e,data:t})]));function O(){let e;chrome.runtime.onMessage.addListener(({type:t,data:o,target:c},s,r)=>{if(c===u)return clearTimeout(e),p[t](o).then(a=>{r(a)}).catch(a=>{console.error(`offscreen action ${t} failed.`,a),r()}).finally(()=>{e=setTimeout(()=>{window.close()},5e3)}),!0})}async function E(e){return await x(),await chrome.runtime.sendMessage({...e,target:u})}let n=null;async function x(){if((await chrome.runtime.getContexts({contextTypes:[chrome.runtime.ContextType.OFFSCREEN_DOCUMENT],documentUrls:[chrome.runtime.getURL(l)]})).length){n&&await n;return}n?await n:(n=chrome.offscreen.createDocument({url:l,reasons:[chrome.offscreen.Reason.CLIPBOARD,chrome.offscreen.Reason.MATCH_MEDIA,chrome.offscreen.Reason.LOCAL_STORAGE],justification:"1) Copy a tab or link to the clipboard from a context menu or command. 2) Discover whether the user prefers dark or light mode."}),await n,n=null)}export{D as c,O as l,T as o};
