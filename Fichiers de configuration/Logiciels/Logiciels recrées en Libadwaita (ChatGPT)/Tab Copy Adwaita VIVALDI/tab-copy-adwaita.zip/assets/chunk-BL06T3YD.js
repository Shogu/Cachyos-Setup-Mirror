/**
 * @license
 * Tab Copy - A browser extension for copying tabs to the clipboard
 * in a variety of formats.
 * Copyright (C) 2011-present, Hans Meyer, https://github.com/hansifer
 * 
 * Creative Commons Attribution-NonCommercial-NoDerivatives 4.0
 * International Public License
 * 
 * By using the code or any other material in this repository, you
 * agree to the terms of the following license:
 * 
 * You are free to:
 * 
 * Share - copy and redistribute the material in any medium or format
 * 
 * The licensor cannot revoke these freedoms as long as you follow
 * the license terms.
 * 
 * Under the following terms:
 * 
 * Attribution - You must give appropriate credit, provide a link to
 * the license, and indicate if changes were made. You may do so in
 * any reasonable manner, but not in any way that suggests the
 * licensor endorses you or your use.
 * 
 * NonCommercial - You may not use the material for commercial purposes.
 * 
 * NoDerivatives - If you remix, transform, or build upon the material,
 * you may not distribute the modified material.
 * 
 * No additional restrictions - You may not apply legal terms or
 * technological measures that legally restrict others from doing
 * anything the license permits.
 * 
 * No warranties are given. The license may not give you all of the
 * permissions necessary for your intended use. For example, other rights
 * such as publicity, privacy, or moral rights may limit how you use
 * the material.
 * 
 * Full Text of the License:
 * https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode
 */

import{j as o}from"./chunk-CK8oU3CZ.js";const s=({size:t=16,color:r="currentColor",fill:e})=>o.jsx("svg",{xmlns:"http://www.w3.org/2000/svg",width:t,height:t,viewBox:"0 0 24 24",fill:e?r:"none",stroke:r,strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:o.jsx("path",{d:"M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"})});export{s as H};
