/**
 * @license
 * Tab Copy - A browser extension for copying tabs to the clipboard
 * in a variety of formats.
 * Copyright (C) 2011-present, Hans Meyer, https://github.com/hansifer
 * 
 * Creative Commons Attribution-NonCommercial-NoDerivatives 4.0
 * International Public License
 * 
 * By using the code or any other material in this repository, you
 * agree to the terms of the following license:
 * 
 * You are free to:
 * 
 * Share - copy and redistribute the material in any medium or format
 * 
 * The licensor cannot revoke these freedoms as long as you follow
 * the license terms.
 * 
 * Under the following terms:
 * 
 * Attribution - You must give appropriate credit, provide a link to
 * the license, and indicate if changes were made. You may do so in
 * any reasonable manner, but not in any way that suggests the
 * licensor endorses you or your use.
 * 
 * NonCommercial - You may not use the material for commercial purposes.
 * 
 * NoDerivatives - If you remix, transform, or build upon the material,
 * you may not distribute the modified material.
 * 
 * No additional restrictions - You may not apply legal terms or
 * technological measures that legally restrict others from doing
 * anything the license permits.
 * 
 * No warranties are given. The license may not give you all of the
 * permissions necessary for your intended use. For example, other rights
 * such as publicity, privacy, or moral rights may limit how you use
 * the material.
 * 
 * Full Text of the License:
 * https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode
 */

function L(e,t){for(var r=0;r<t.length;r++){const o=t[r];if(typeof o!="string"&&!Array.isArray(o)){for(const u in o)if(u!=="default"&&!(u in e)){const c=Object.getOwnPropertyDescriptor(o,u);c&&Object.defineProperty(e,u,c.get?c:{enumerable:!0,get:()=>o[u]})}}}return Object.freeze(Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}))}var ue=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function R(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var O={exports:{}},n={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var y=Symbol.for("react.element"),V=Symbol.for("react.portal"),q=Symbol.for("react.fragment"),F=Symbol.for("react.strict_mode"),U=Symbol.for("react.profiler"),N=Symbol.for("react.provider"),z=Symbol.for("react.context"),B=Symbol.for("react.forward_ref"),H=Symbol.for("react.suspense"),Q=Symbol.for("react.memo"),G=Symbol.for("react.lazy"),E=Symbol.iterator;function W(e){return e===null||typeof e!="object"?null:(e=E&&e[E]||e["@@iterator"],typeof e=="function"?e:null)}var $={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},C=Object.assign,P={};function p(e,t,r){this.props=e,this.context=t,this.refs=P,this.updater=r||$}p.prototype.isReactComponent={};p.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")};p.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function x(){}x.prototype=p.prototype;function S(e,t,r){this.props=e,this.context=t,this.refs=P,this.updater=r||$}var b=S.prototype=new x;b.constructor=S;C(b,p.prototype);b.isPureReactComponent=!0;var g=Array.isArray,D=Object.prototype.hasOwnProperty,w={current:null},I={key:!0,ref:!0,__self:!0,__source:!0};function M(e,t,r){var o,u={},c=null,f=null;if(t!=null)for(o in t.ref!==void 0&&(f=t.ref),t.key!==void 0&&(c=""+t.key),t)D.call(t,o)&&!I.hasOwnProperty(o)&&(u[o]=t[o]);var i=arguments.length-2;if(i===1)u.children=r;else if(1<i){for(var s=Array(i),a=0;a<i;a++)s[a]=arguments[a+2];u.children=s}if(e&&e.defaultProps)for(o in i=e.defaultProps,i)u[o]===void 0&&(u[o]=i[o]);return{$$typeof:y,type:e,key:c,ref:f,props:u,_owner:w.current}}function J(e,t){return{$$typeof:y,type:e.type,key:t,ref:e.ref,props:e.props,_owner:e._owner}}function k(e){return typeof e=="object"&&e!==null&&e.$$typeof===y}function K(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(r){return t[r]})}var j=/\/+/g;function v(e,t){return typeof e=="object"&&e!==null&&e.key!=null?K(""+e.key):t.toString(36)}function h(e,t,r,o,u){var c=typeof e;(c==="undefined"||c==="boolean")&&(e=null);var f=!1;if(e===null)f=!0;else switch(c){case"string":case"number":f=!0;break;case"object":switch(e.$$typeof){case y:case V:f=!0}}if(f)return f=e,u=u(f),e=o===""?"."+v(f,0):o,g(u)?(r="",e!=null&&(r=e.replace(j,"$&/")+"/"),h(u,t,r,"",function(a){return a})):u!=null&&(k(u)&&(u=J(u,r+(!u.key||f&&f.key===u.key?"":(""+u.key).replace(j,"$&/")+"/")+e)),t.push(u)),1;if(f=0,o=o===""?".":o+":",g(e))for(var i=0;i<e.length;i++){c=e[i];var s=o+v(c,i);f+=h(c,t,r,s,u)}else if(s=W(e),typeof s=="function")for(e=s.call(e),i=0;!(c=e.next()).done;)c=c.value,s=o+v(c,i++),f+=h(c,t,r,s,u);else if(c==="object")throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.");return f}function d(e,t,r){if(e==null)return e;var o=[],u=0;return h(e,o,"","",function(c){return t.call(r,c,u++)}),o}function X(e){if(e._status===-1){var t=e._result;t=t(),t.then(function(r){(e._status===0||e._status===-1)&&(e._status=1,e._result=r)},function(r){(e._status===0||e._status===-1)&&(e._status=2,e._result=r)}),e._status===-1&&(e._status=0,e._result=t)}if(e._status===1)return e._result.default;throw e._result}var l={current:null},_={transition:null},Y={ReactCurrentDispatcher:l,ReactCurrentBatchConfig:_,ReactCurrentOwner:w};function T(){throw Error("act(...) is not supported in production builds of React.")}n.Children={map:d,forEach:function(e,t,r){d(e,function(){t.apply(this,arguments)},r)},count:function(e){var t=0;return d(e,function(){t++}),t},toArray:function(e){return d(e,function(t){return t})||[]},only:function(e){if(!k(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};n.Component=p;n.Fragment=q;n.Profiler=U;n.PureComponent=S;n.StrictMode=F;n.Suspense=H;n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=Y;n.act=T;n.cloneElement=function(e,t,r){if(e==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+e+".");var o=C({},e.props),u=e.key,c=e.ref,f=e._owner;if(t!=null){if(t.ref!==void 0&&(c=t.ref,f=w.current),t.key!==void 0&&(u=""+t.key),e.type&&e.type.defaultProps)var i=e.type.defaultProps;for(s in t)D.call(t,s)&&!I.hasOwnProperty(s)&&(o[s]=t[s]===void 0&&i!==void 0?i[s]:t[s])}var s=arguments.length-2;if(s===1)o.children=r;else if(1<s){i=Array(s);for(var a=0;a<s;a++)i[a]=arguments[a+2];o.children=i}return{$$typeof:y,type:e.type,key:u,ref:c,props:o,_owner:f}};n.createContext=function(e){return e={$$typeof:z,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},e.Provider={$$typeof:N,_context:e},e.Consumer=e};n.createElement=M;n.createFactory=function(e){var t=M.bind(null,e);return t.type=e,t};n.createRef=function(){return{current:null}};n.forwardRef=function(e){return{$$typeof:B,render:e}};n.isValidElement=k;n.lazy=function(e){return{$$typeof:G,_payload:{_status:-1,_result:e},_init:X}};n.memo=function(e,t){return{$$typeof:Q,type:e,compare:t===void 0?null:t}};n.startTransition=function(e){var t=_.transition;_.transition={};try{e()}finally{_.transition=t}};n.unstable_act=T;n.useCallback=function(e,t){return l.current.useCallback(e,t)};n.useContext=function(e){return l.current.useContext(e)};n.useDebugValue=function(){};n.useDeferredValue=function(e){return l.current.useDeferredValue(e)};n.useEffect=function(e,t){return l.current.useEffect(e,t)};n.useId=function(){return l.current.useId()};n.useImperativeHandle=function(e,t,r){return l.current.useImperativeHandle(e,t,r)};n.useInsertionEffect=function(e,t){return l.current.useInsertionEffect(e,t)};n.useLayoutEffect=function(e,t){return l.current.useLayoutEffect(e,t)};n.useMemo=function(e,t){return l.current.useMemo(e,t)};n.useReducer=function(e,t,r){return l.current.useReducer(e,t,r)};n.useRef=function(e){return l.current.useRef(e)};n.useState=function(e){return l.current.useState(e)};n.useSyncExternalStore=function(e,t,r){return l.current.useSyncExternalStore(e,t,r)};n.useTransition=function(){return l.current.useTransition()};n.version="18.3.1";O.exports=n;var m=O.exports;const Z=R(m),ce=L({__proto__:null,default:Z},[m]);function ee(e){var t=typeof e;return!!e&&(t=="object"||t=="function")}var te=ee;const re=R(te);function ne(e){return e.filter((t,r)=>e.indexOf(t)===r)}function se(e,t){return e.includes(t)?e.filter(o=>o!==t):[...e,t]}function ie(...e){return ne(e.map(t=>re(t)?Object.entries(t).filter(([,r])=>r).map(([r])=>r):t).flat()).join(" ")}const A="(prefers-color-scheme: dark)";function oe(){return!!window?.matchMedia?.(A).matches}const fe=()=>{const[e,t]=m.useState(oe);return m.useEffect(()=>{if(!window?.matchMedia)return;const r=window.matchMedia(A),o=u=>{t(u.matches)};return r.addEventListener("change",o),()=>{r.removeEventListener("change",o)}},[]),e};export{Z as R,se as a,ce as b,ie as c,ue as d,R as g,oe as p,m as r,fe as u};
