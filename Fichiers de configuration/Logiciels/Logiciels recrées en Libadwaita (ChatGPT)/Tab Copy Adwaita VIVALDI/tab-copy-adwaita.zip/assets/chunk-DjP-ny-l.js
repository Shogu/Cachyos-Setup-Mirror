/**
 * @license
 * Tab Copy - A browser extension for copying tabs to the clipboard
 * in a variety of formats.
 * Copyright (C) 2011-present, Hans Meyer, https://github.com/hansifer
 * 
 * Creative Commons Attribution-NonCommercial-NoDerivatives 4.0
 * International Public License
 * 
 * By using the code or any other material in this repository, you
 * agree to the terms of the following license:
 * 
 * You are free to:
 * 
 * Share - copy and redistribute the material in any medium or format
 * 
 * The licensor cannot revoke these freedoms as long as you follow
 * the license terms.
 * 
 * Under the following terms:
 * 
 * Attribution - You must give appropriate credit, provide a link to
 * the license, and indicate if changes were made. You may do so in
 * any reasonable manner, but not in any way that suggests the
 * licensor endorses you or your use.
 * 
 * NonCommercial - You may not use the material for commercial purposes.
 * 
 * NoDerivatives - If you remix, transform, or build upon the material,
 * you may not distribute the modified material.
 * 
 * No additional restrictions - You may not apply legal terms or
 * technological measures that legally restrict others from doing
 * anything the license permits.
 * 
 * No warranties are given. The license may not give you all of the
 * permissions necessary for your intended use. For example, other rights
 * such as publicity, privacy, or moral rights may limit how you use
 * the material.
 * 
 * Full Text of the License:
 * https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode
 */

import{j as r,L as a}from"./chunk-CK8oU3CZ.js";const c="_Header_tguyw_1",o={Header:c},l=({text:s})=>r.jsxs("div",{className:o.Header,children:[r.jsx(a,{size:48}),r.jsx("h1",{children:s})]}),x=({content:s})=>r.jsx("div",{children:s.map(e=>typeof e=="string"?r.jsx("span",{children:e}):Array.isArray(e)?d(...e):e)});function d(s,e){const t=/^https?:\/\//.test(e);return r.jsx("a",{href:e,target:"_blank",onClick:t?void 0:n=>{chrome.tabs.create({url:chrome.runtime.getURL(e)}),n.preventDefault()},children:s})}export{l as H,x as T};
