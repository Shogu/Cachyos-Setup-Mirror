#include <adwaita.h>
#include <gio/gio.h>
#include <gtk/gtk.h>

#include <string.h>

#define APP_ID "org.cachyos.scx-manager-adwaita"
#define LOADER_BUS_NAME "org.scx.Loader"
#define LOADER_OBJECT_PATH "/org/scx/Loader"
#define LOADER_INTERFACE "org.scx.Loader"
#define PROPERTIES_INTERFACE "org.freedesktop.DBus.Properties"

typedef struct _App App;

typedef struct {
    gchar *current_scheduler;
    guint32 scheduler_mode;
    GPtrArray *current_args;
    gchar *default_scheduler;
    guint32 default_mode;
    gchar **supported_schedulers;
} LoaderState;

typedef struct {
    App *app;
    gchar *success_message;
} ActionContext;

struct _App {
    AdwApplication *application;
    AdwApplicationWindow *window;
    GDBusProxy *proxy;

    AdwToastOverlay *toast_overlay;
    GtkDropDown *scheduler_dropdown;
    GtkDropDown *profile_dropdown;
    AdwEntryRow *flags_row;

    GtkImage *status_icon;
    GtkLabel *status_title;
    GtkLabel *status_subtitle;
    GtkLabel *status_badge;
    AdwActionRow *scheduler_row;
    AdwActionRow *profile_row;

    GtkButton *apply_button;
    GtkButton *stop_button;
    GtkButton *restore_button;
    GtkButton *refresh_button;

    LoaderState state;
    gboolean loader_available;
    gboolean busy;
};

typedef struct {
    const gchar *id;
    const gchar *description;
} SchedulerInfo;

static const SchedulerInfo scheduler_infos[] = {
    {"scx_bpfland", "Scheduler vruntime orienté interactivité, attentif à la topologie des caches."},
    {"scx_lavd", "Scheduler conçu pour réduire les pics de latence dans les charges interactives et les jeux."},
    {"scx_flash", "Scheduler équitable et prévisible basé sur une politique de deadline."},
    {"scx_p2dq", "Scheduler qui répartit les tâches selon la capacité et la topologie des processeurs."},
    {"scx_rustland", "Scheduler expérimental exécuté en espace utilisateur via une file de tâches."},
    {"scx_rusty", "Scheduler simple et léger, utile pour tester sched-ext avec peu de réglages."},
    {"scx_cosmos", "Scheduler expérimental privilégiant une gestion flexible des files d'exécution."},
    {"scx_tickless", "Scheduler orienté réduction des ticks et des réveils inutiles."},
    {"scx_beerland", "Scheduler privilégiant la localité mémoire et la montée en charge."},
    {"scx_cake", "Scheduler expérimental inspiré de CAKE et orienté vers la classification des tâches."},
    {"scx_central", "Scheduler centralisé fourni par l'écosystème sched-ext."},
    {"scx_simple", "Scheduler minimal de référence pour sched-ext."},
    {NULL, NULL},
};

static const gchar *fallback_schedulers[] = {
    "scx_bpfland",
    "scx_lavd",
    "scx_flash",
    "scx_p2dq",
    "scx_rustland",
    "scx_rusty",
    "scx_cosmos",
    "scx_tickless",
    NULL,
};

static const gchar *profile_names[] = {
    "Auto",
    "Gaming",
    "Power Save",
    "Low Latency",
    "Server",
};

static const gchar *profile_descriptions[] = {
    "Utilise les arguments par défaut du scheduler.",
    "Privilégie la réactivité et les charges de jeu.",
    "Privilégie l'efficacité énergétique.",
    "Réduit la latence au prix d'un éventuel débit moindre.",
    "Privilégie le débit et la stabilité sous charge soutenue.",
};

static void loader_state_clear(LoaderState *state)
{
    g_clear_pointer(&state->current_scheduler, g_free);
    g_clear_pointer(&state->default_scheduler, g_free);

    if (state->current_args != NULL) {
        g_ptr_array_unref(state->current_args);
        state->current_args = NULL;
    }

    g_clear_pointer(&state->supported_schedulers, g_strfreev);
    state->scheduler_mode = 0;
    state->default_mode = 0;
}

static gboolean scheduler_is_active(const App *app)
{
    const gchar *scheduler = app->state.current_scheduler;

    return app->loader_available && scheduler != NULL && *scheduler != '\0' &&
           g_strcmp0(scheduler, "unknown") != 0 && g_strcmp0(scheduler, "none") != 0;
}

static const gchar *profile_name(guint32 mode)
{
    return mode < G_N_ELEMENTS(profile_names) ? profile_names[mode] : "Auto";
}

static const gchar *profile_description(guint32 mode)
{
    return mode < G_N_ELEMENTS(profile_descriptions) ? profile_descriptions[mode]
                                                       : profile_descriptions[0];
}

static gchar *pretty_scheduler_name(const gchar *scheduler)
{
    const gchar *short_name = scheduler;
    gchar *display;

    if (scheduler != NULL && g_str_has_prefix(scheduler, "scx_")) {
        short_name = scheduler + 4;
    }

    display = g_strdup(short_name != NULL && *short_name != '\0' ? short_name : "inconnu");
    for (gchar *cursor = display; cursor != NULL && *cursor != '\0'; cursor++) {
        if (*cursor == '_') {
            *cursor = ' ';
        }
    }

    if (display[0] != '\0') {
        display[0] = g_ascii_toupper(display[0]);
    }

    if (scheduler != NULL && *scheduler != '\0') {
        gchar *result = g_strdup_printf("%s (%s)", display, scheduler);
        g_free(display);
        return result;
    }

    return display;
}

static const gchar *scheduler_description(const gchar *scheduler)
{
    if (scheduler == NULL) {
        return "Sélectionnez un scheduler exposé par scx_loader.";
    }

    for (gsize index = 0; scheduler_infos[index].id != NULL; index++) {
        if (g_strcmp0(scheduler_infos[index].id, scheduler) == 0) {
            return scheduler_infos[index].description;
        }
    }

    return "Scheduler détecté par scx_loader. Consultez sa documentation pour connaître ses options.";
}

static void show_toast(App *app, const gchar *message)
{
    if (app->toast_overlay == NULL || message == NULL || *message == '\0') {
        return;
    }

    AdwToast *toast = adw_toast_new(message);
    adw_toast_set_timeout(toast, 4);
    adw_toast_overlay_add_toast(app->toast_overlay, toast);
}

static void set_status_badge_class(App *app, const gchar *css_class)
{
    const gchar *classes[] = {"success", "warning", "error", NULL};

    for (gsize index = 0; classes[index] != NULL; index++) {
        gtk_widget_remove_css_class(GTK_WIDGET(app->status_badge), classes[index]);
    }

    gtk_widget_add_css_class(GTK_WIDGET(app->status_badge), css_class);
}

static gchar *format_args(const GPtrArray *args)
{
    if (args == NULL || args->len == 0) {
        return g_strdup("");
    }

    GString *formatted = g_string_new(NULL);
    for (guint index = 0; index < args->len; index++) {
        const gchar *argument = g_ptr_array_index((GPtrArray *)args, index);
        gboolean needs_quotes = argument == NULL || *argument == '\0';

        if (argument != NULL) {
            for (const gchar *cursor = argument; *cursor != '\0'; cursor++) {
                if (g_ascii_isspace(*cursor) || *cursor == '"' || *cursor == '\\') {
                    needs_quotes = TRUE;
                    break;
                }
            }
        }

        if (index > 0) {
            g_string_append_c(formatted, ' ');
        }

        if (!needs_quotes) {
            g_string_append(formatted, argument);
            continue;
        }

        g_string_append_c(formatted, '"');
        if (argument != NULL) {
            for (const gchar *cursor = argument; *cursor != '\0'; cursor++) {
                if (*cursor == '"' || *cursor == '\\') {
                    g_string_append_c(formatted, '\\');
                }
                g_string_append_c(formatted, *cursor);
            }
        }
        g_string_append_c(formatted, '"');
    }

    return g_string_free(formatted, FALSE);
}

static gchar *selected_scheduler(App *app)
{
    GObject *item = gtk_drop_down_get_selected_item(app->scheduler_dropdown);
    if (item == NULL || !GTK_IS_STRING_OBJECT(item)) {
        return NULL;
    }

    return g_strdup(gtk_string_object_get_string(GTK_STRING_OBJECT(item)));
}

static void select_scheduler(App *app, const gchar *scheduler)
{
    GListModel *model = gtk_drop_down_get_model(app->scheduler_dropdown);
    if (model == NULL) {
        return;
    }

    guint number_of_items = g_list_model_get_n_items(model);
    for (guint index = 0; index < number_of_items; index++) {
        GObject *item = g_list_model_get_item(model, index);
        gboolean matches = item != NULL && GTK_IS_STRING_OBJECT(item) &&
                           g_strcmp0(gtk_string_object_get_string(GTK_STRING_OBJECT(item)), scheduler) == 0;
        g_clear_object(&item);

        if (matches) {
            gtk_drop_down_set_selected(app->scheduler_dropdown, index);
            return;
        }
    }

    if (number_of_items > 0) {
        gtk_drop_down_set_selected(app->scheduler_dropdown, 0);
    }
}

static void update_scheduler_description(App *app)
{
    gchar *scheduler = selected_scheduler(app);
    adw_action_row_set_subtitle(app->scheduler_row, scheduler_description(scheduler));
    g_free(scheduler);
}

static void update_profile_description(App *app)
{
    guint32 mode = gtk_drop_down_get_selected(app->profile_dropdown);
    const gchar *flags = gtk_editable_get_text(GTK_EDITABLE(app->flags_row));

    if (flags != NULL && *flags != '\0') {
        adw_action_row_set_subtitle(app->profile_row,
                                    "Les arguments personnalisés remplacent les arguments du profil sélectionné.");
    } else {
        adw_action_row_set_subtitle(app->profile_row, profile_description(mode));
    }
}

static void update_status(App *app)
{
    if (!app->loader_available) {
        gtk_image_set_from_icon_name(app->status_icon, "dialog-error-symbolic");
        gtk_label_set_text(app->status_title, "scx_loader indisponible");
        gtk_label_set_text(app->status_subtitle,
                           "Le service D-Bus org.scx.Loader ne répond pas. Vérifiez scx-tools et scx_loader.service.");
        gtk_label_set_text(app->status_badge, "Indisponible");
        set_status_badge_class(app, "error");
        return;
    }

    if (!scheduler_is_active(app)) {
        gtk_image_set_from_icon_name(app->status_icon, "media-playback-stop-symbolic");
        gtk_label_set_text(app->status_title, "Aucun scheduler sched-ext actif");

        gchar *default_name = pretty_scheduler_name(app->state.default_scheduler);
        gchar *subtitle = app->state.default_scheduler != NULL &&
                                  g_strcmp0(app->state.default_scheduler, "unknown") != 0
                              ? g_strdup_printf("Le scheduler Linux par défaut est utilisé · défaut configuré : %s",
                                                default_name)
                              : g_strdup("Le scheduler Linux par défaut est utilisé.");
        gtk_label_set_text(app->status_subtitle, subtitle);
        gtk_label_set_text(app->status_badge, "Inactif");
        set_status_badge_class(app, "warning");
        g_free(default_name);
        g_free(subtitle);
        return;
    }

    gchar *display_name = pretty_scheduler_name(app->state.current_scheduler);
    gchar *arguments = format_args(app->state.current_args);
    gchar *subtitle = arguments[0] != '\0'
                          ? g_strdup_printf("Arguments personnalisés · %s", arguments)
                          : g_strdup_printf("Profil %s", profile_name(app->state.scheduler_mode));

    gtk_image_set_from_icon_name(app->status_icon, "emblem-ok-symbolic");
    gtk_label_set_text(app->status_title, display_name);
    gtk_label_set_text(app->status_subtitle, subtitle);
    gtk_label_set_text(app->status_badge, "Actif");
    set_status_badge_class(app, "success");

    g_free(display_name);
    g_free(arguments);
    g_free(subtitle);
}

static void update_controls(App *app)
{
    gboolean can_use_loader = app->loader_available && !app->busy;
    gboolean active = scheduler_is_active(app);
    gboolean has_custom_args = gtk_editable_get_text(GTK_EDITABLE(app->flags_row))[0] != '\0';

    gtk_widget_set_sensitive(GTK_WIDGET(app->scheduler_dropdown), can_use_loader);
    gtk_widget_set_sensitive(GTK_WIDGET(app->profile_dropdown), can_use_loader && !has_custom_args);
    gtk_widget_set_sensitive(GTK_WIDGET(app->flags_row), can_use_loader);
    gtk_widget_set_sensitive(GTK_WIDGET(app->apply_button), can_use_loader);
    gtk_widget_set_sensitive(GTK_WIDGET(app->stop_button), can_use_loader && active);
    gtk_widget_set_sensitive(GTK_WIDGET(app->restore_button), can_use_loader);
    gtk_widget_set_sensitive(GTK_WIDGET(app->refresh_button), !app->busy);
}

static void set_busy(App *app, gboolean busy)
{
    app->busy = busy;
    update_controls(app);
}

static void populate_scheduler_dropdown(App *app)
{
    const gchar *const *items = (const gchar *const *)app->state.supported_schedulers;
    if (items == NULL || items[0] == NULL) {
        items = fallback_schedulers;
    }

    GtkStringList *model = gtk_string_list_new(items);
    gtk_drop_down_set_model(app->scheduler_dropdown, G_LIST_MODEL(model));
    g_object_unref(model);

    select_scheduler(app, scheduler_is_active(app) ? app->state.current_scheduler
                                                   : app->state.default_scheduler);
    update_scheduler_description(app);
}

static GPtrArray *parse_argument_line(const gchar *text, GError **error)
{
    GPtrArray *arguments = g_ptr_array_new_with_free_func(g_free);
    GString *current = g_string_new(NULL);
    gboolean in_single_quotes = FALSE;
    gboolean in_double_quotes = FALSE;
    gboolean escaped = FALSE;
    gboolean token_started = FALSE;

    for (const gchar *cursor = text != NULL ? text : ""; *cursor != '\0'; cursor++) {
        gchar character = *cursor;

        if (escaped) {
            g_string_append_c(current, character);
            escaped = FALSE;
            token_started = TRUE;
            continue;
        }

        if (in_single_quotes) {
            if (character == '\'') {
                in_single_quotes = FALSE;
            } else {
                g_string_append_c(current, character);
            }
            continue;
        }

        if (in_double_quotes) {
            if (character == '"') {
                in_double_quotes = FALSE;
            } else if (character == '\\') {
                escaped = TRUE;
            } else {
                g_string_append_c(current, character);
            }
            continue;
        }

        if (character == '\'') {
            in_single_quotes = TRUE;
            token_started = TRUE;
        } else if (character == '"') {
            in_double_quotes = TRUE;
            token_started = TRUE;
        } else if (character == '\\') {
            escaped = TRUE;
            token_started = TRUE;
        } else if (g_ascii_isspace(character)) {
            if (token_started) {
                g_ptr_array_add(arguments, g_string_free(current, FALSE));
                current = g_string_new(NULL);
                token_started = FALSE;
            }
        } else {
            g_string_append_c(current, character);
            token_started = TRUE;
        }
    }

    if (escaped || in_single_quotes || in_double_quotes) {
        const gchar *reason = escaped ? "barre oblique finale" : "guillemet non fermé";
        g_set_error(error, G_IO_ERROR, G_IO_ERROR_INVALID_ARGUMENT,
                    "Arguments personnalisés invalides : %s.", reason);
        g_string_free(current, TRUE);
        g_ptr_array_unref(arguments);
        return NULL;
    }

    if (token_started) {
        g_ptr_array_add(arguments, g_string_free(current, FALSE));
    } else {
        g_string_free(current, TRUE);
    }

    return arguments;
}

static GVariant *string_array_variant(const GPtrArray *arguments)
{
    GVariantBuilder builder;
    g_variant_builder_init(&builder, G_VARIANT_TYPE("as"));

    for (guint index = 0; arguments != NULL && index < arguments->len; index++) {
        const gchar *argument = g_ptr_array_index((GPtrArray *)arguments, index);
        g_variant_builder_add(&builder, "s", argument != NULL ? argument : "");
    }

    return g_variant_builder_end(&builder);
}

static void action_context_free(ActionContext *context)
{
    g_free(context->success_message);
    g_free(context);
}

static void refresh_app(App *app);

static void action_finished(GObject *source_object, GAsyncResult *result, gpointer user_data)
{
    ActionContext *context = user_data;
    App *app = context->app;
    GError *error = NULL;
    GVariant *reply = g_dbus_proxy_call_finish(G_DBUS_PROXY(source_object), result, &error);

    if (reply != NULL) {
        g_variant_unref(reply);
        show_toast(app, context->success_message);
        action_context_free(context);
        refresh_app(app);
        return;
    }

    gchar *message = g_strdup_printf("Échec de l'opération : %s", error != NULL ? error->message : "erreur inconnue");
    show_toast(app, message);
    g_free(message);
    g_clear_error(&error);
    action_context_free(context);
    set_busy(app, FALSE);
}

static void call_loader(App *app, const gchar *method, GVariant *parameters, const gchar *success_message)
{
    if (app->proxy == NULL) {
        show_toast(app, "Le service scx_loader n'est pas disponible.");
        if (parameters != NULL) {
            g_variant_unref(parameters);
        }
        return;
    }

    ActionContext *context = g_new0(ActionContext, 1);
    context->app = app;
    context->success_message = g_strdup(success_message);

    set_busy(app, TRUE);
    g_dbus_proxy_call(app->proxy,
                      method,
                      parameters,
                      G_DBUS_CALL_FLAGS_NONE,
                      -1,
                      NULL,
                      action_finished,
                      context);
}

static void apply_scheduler(App *app)
{
    gchar *scheduler = selected_scheduler(app);
    if (scheduler == NULL || *scheduler == '\0') {
        show_toast(app, "Aucun scheduler n'est sélectionné.");
        g_free(scheduler);
        return;
    }

    GError *error = NULL;
    const gchar *flags = gtk_editable_get_text(GTK_EDITABLE(app->flags_row));
    GPtrArray *arguments = parse_argument_line(flags, &error);
    if (arguments == NULL) {
        show_toast(app, error != NULL ? error->message : "Arguments invalides.");
        g_clear_error(&error);
        g_free(scheduler);
        return;
    }

    gboolean active = scheduler_is_active(app);
    const gchar *method;
    GVariant *parameters;
    gchar *success_message;

    if (arguments->len > 0) {
        method = active ? "SwitchSchedulerWithArgs" : "StartSchedulerWithArgs";
        GVariant *array = string_array_variant(arguments);
        parameters = g_variant_new("(s@as)", scheduler, array);
        success_message = g_strdup_printf("Scheduler %s activé avec les arguments personnalisés.", scheduler);
    } else {
        guint32 mode = gtk_drop_down_get_selected(app->profile_dropdown);
        method = active ? "SwitchScheduler" : "StartScheduler";
        parameters = g_variant_new("(su)", scheduler, mode);
        success_message = g_strdup_printf("Scheduler %s activé en profil %s.", scheduler, profile_name(mode));
    }

    call_loader(app, method, parameters, success_message);
    g_free(success_message);
    g_ptr_array_unref(arguments);
    g_free(scheduler);
}

static void stop_scheduler(App *app)
{
    call_loader(app,
                "StopScheduler",
                g_variant_new("()"),
                "Scheduler arrêté : le scheduler Linux par défaut reprend la main.");
}

static void restore_default(App *app)
{
    call_loader(app,
                "RestoreDefault",
                g_variant_new("()"),
                "Scheduler par défaut restauré.");
}

static void parse_loader_properties(App *app, GVariant *reply)
{
    GVariant *properties = NULL;
    LoaderState parsed = {0};

    g_variant_get(reply, "(@a{sv})", &properties);

    g_variant_lookup(properties, "CurrentScheduler", "s", &parsed.current_scheduler);
    g_variant_lookup(properties, "DefaultScheduler", "s", &parsed.default_scheduler);
    g_variant_lookup(properties, "SchedulerMode", "u", &parsed.scheduler_mode);
    g_variant_lookup(properties, "DefaultMode", "u", &parsed.default_mode);
    g_variant_lookup(properties, "SupportedSchedulers", "^as", &parsed.supported_schedulers);

    gchar **current_args = NULL;
    if (g_variant_lookup(properties, "CurrentSchedulerArgs", "^as", &current_args)) {
        parsed.current_args = g_ptr_array_new_with_free_func(g_free);
        for (gchar **cursor = current_args; cursor != NULL && *cursor != NULL; cursor++) {
            g_ptr_array_add(parsed.current_args, g_strdup(*cursor));
        }
        g_strfreev(current_args);
    } else {
        parsed.current_args = g_ptr_array_new_with_free_func(g_free);
    }

    loader_state_clear(&app->state);
    app->state = parsed;
    app->loader_available = TRUE;

    g_variant_unref(properties);
    populate_scheduler_dropdown(app);

    if (scheduler_is_active(app)) {
        gchar *arguments = format_args(app->state.current_args);
        gtk_editable_set_text(GTK_EDITABLE(app->flags_row), arguments);
        g_free(arguments);
    } else {
        gtk_editable_set_text(GTK_EDITABLE(app->flags_row), "");
    }

    guint32 mode = MIN(app->state.scheduler_mode, 4);
    gtk_drop_down_set_selected(app->profile_dropdown, mode);
    update_scheduler_description(app);
    update_profile_description(app);
    update_status(app);
    update_controls(app);
}

static void properties_finished(GObject *source_object, GAsyncResult *result, gpointer user_data)
{
    App *app = user_data;
    GError *error = NULL;
    GVariant *reply = g_dbus_connection_call_finish(G_DBUS_CONNECTION(source_object), result, &error);

    if (reply == NULL) {
        loader_state_clear(&app->state);
        app->loader_available = FALSE;
        update_status(app);
        set_busy(app, FALSE);
        update_controls(app);

        if (error != NULL) {
            g_warning("Unable to read scx_loader state: %s", error->message);
            g_clear_error(&error);
        }
        return;
    }

    parse_loader_properties(app, reply);
    g_variant_unref(reply);
    set_busy(app, FALSE);
}

static void refresh_app(App *app)
{
    if (app->proxy == NULL) {
        app->loader_available = FALSE;
        update_status(app);
        update_controls(app);
        return;
    }

    set_busy(app, TRUE);
    g_dbus_connection_call(g_dbus_proxy_get_connection(app->proxy),
                            LOADER_BUS_NAME,
                            LOADER_OBJECT_PATH,
                            PROPERTIES_INTERFACE,
                            "GetAll",
                            g_variant_new("(s)", LOADER_INTERFACE),
                            G_VARIANT_TYPE("(a{sv})"),
                            G_DBUS_CALL_FLAGS_NONE,
                            -1,
                            NULL,
                            properties_finished,
                            app);
}

static void on_refresh_clicked(GtkButton *button, gpointer user_data)
{
    (void)button;
    refresh_app(user_data);
}

static void on_apply_clicked(GtkButton *button, gpointer user_data)
{
    (void)button;
    apply_scheduler(user_data);
}

static void on_stop_clicked(GtkButton *button, gpointer user_data)
{
    (void)button;
    stop_scheduler(user_data);
}

static void on_restore_clicked(GtkButton *button, gpointer user_data)
{
    (void)button;
    restore_default(user_data);
}

static void on_scheduler_changed(GtkDropDown *dropdown, GParamSpec *pspec, gpointer user_data)
{
    (void)dropdown;
    (void)pspec;
    App *app = user_data;
    update_scheduler_description(app);
}

static void on_profile_changed(GtkDropDown *dropdown, GParamSpec *pspec, gpointer user_data)
{
    (void)dropdown;
    (void)pspec;
    update_profile_description(user_data);
}

static void on_flags_changed(GtkEditable *editable, gpointer user_data)
{
    (void)editable;
    update_profile_description(user_data);
    update_controls(user_data);
}

static gboolean on_window_close(GtkWindow *window, gpointer user_data)
{
    (void)window;
    App *app = user_data;
    g_object_set_data(G_OBJECT(app->application), "scx-manager-window", NULL);
    g_application_quit(G_APPLICATION(app->application));
    return FALSE;
}

static GtkWidget *make_heading(const gchar *title, const gchar *subtitle)
{
    GtkBox *box = GTK_BOX(gtk_box_new(GTK_ORIENTATION_VERTICAL, 4));
    GtkLabel *title_label = GTK_LABEL(gtk_label_new(title));
    GtkLabel *subtitle_label = GTK_LABEL(gtk_label_new(subtitle));

    gtk_widget_add_css_class(GTK_WIDGET(title_label), "title-1");
    gtk_widget_add_css_class(GTK_WIDGET(subtitle_label), "dim-label");
    gtk_label_set_wrap(subtitle_label, TRUE);
    gtk_label_set_xalign(subtitle_label, 0.0f);

    gtk_box_append(box, GTK_WIDGET(title_label));
    gtk_box_append(box, GTK_WIDGET(subtitle_label));
    return GTK_WIDGET(box);
}

static GtkWidget *make_status_card(App *app)
{
    GtkFrame *frame = GTK_FRAME(gtk_frame_new(NULL));
    GtkBox *box = GTK_BOX(gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 16));
    GtkBox *text_box = GTK_BOX(gtk_box_new(GTK_ORIENTATION_VERTICAL, 3));
    GtkBox *title_line = GTK_BOX(gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10));

    gtk_widget_add_css_class(GTK_WIDGET(frame), "card");
    gtk_widget_add_css_class(GTK_WIDGET(frame), "scx-status-card");
    gtk_widget_set_margin_top(GTK_WIDGET(frame), 6);

    app->status_icon = GTK_IMAGE(gtk_image_new_from_icon_name("dialog-error-symbolic"));
    gtk_widget_add_css_class(GTK_WIDGET(app->status_icon), "scx-status-icon");
    gtk_image_set_pixel_size(app->status_icon, 28);

    app->status_title = GTK_LABEL(gtk_label_new("Connexion à scx_loader…"));
    gtk_widget_add_css_class(GTK_WIDGET(app->status_title), "title-3");
    gtk_label_set_xalign(app->status_title, 0.0f);

    app->status_badge = GTK_LABEL(gtk_label_new("…"));
    gtk_widget_add_css_class(GTK_WIDGET(app->status_badge), "scx-status-badge");
    gtk_widget_add_css_class(GTK_WIDGET(app->status_badge), "warning");

    app->status_subtitle = GTK_LABEL(gtk_label_new("Lecture de l'état du scheduler en cours…"));
    gtk_widget_add_css_class(GTK_WIDGET(app->status_subtitle), "dim-label");
    gtk_label_set_wrap(app->status_subtitle, TRUE);
    gtk_label_set_xalign(app->status_subtitle, 0.0f);

    gtk_box_append(title_line, GTK_WIDGET(app->status_title));
    gtk_box_append(title_line, GTK_WIDGET(app->status_badge));
    gtk_box_append(text_box, GTK_WIDGET(title_line));
    gtk_box_append(text_box, GTK_WIDGET(app->status_subtitle));
    gtk_widget_set_hexpand(GTK_WIDGET(text_box), TRUE);

    gtk_box_append(box, GTK_WIDGET(app->status_icon));
    gtk_box_append(box, GTK_WIDGET(text_box));
    gtk_frame_set_child(frame, GTK_WIDGET(box));
    return GTK_WIDGET(frame);
}

static GtkWidget *make_settings_group(App *app)
{
    AdwPreferencesGroup *group = ADW_PREFERENCES_GROUP(adw_preferences_group_new());
    adw_preferences_group_set_title(group, "Configuration");
    adw_preferences_group_set_description(group, "Les changements sont appliqués immédiatement par scx_loader.");

    AdwActionRow *scheduler_row = ADW_ACTION_ROW(adw_action_row_new());
    adw_preferences_row_set_title(ADW_PREFERENCES_ROW(scheduler_row), "Scheduler");
    adw_action_row_set_subtitle(scheduler_row, "Sélectionnez le planificateur sched-ext à utiliser");
    adw_action_row_set_subtitle_lines(scheduler_row, 2);

    app->scheduler_dropdown = GTK_DROP_DOWN(gtk_drop_down_new(NULL, NULL));
    gtk_widget_set_size_request(GTK_WIDGET(app->scheduler_dropdown), 220, -1);
    adw_action_row_add_suffix(scheduler_row, GTK_WIDGET(app->scheduler_dropdown));
    adw_action_row_set_activatable_widget(scheduler_row, GTK_WIDGET(app->scheduler_dropdown));
    adw_preferences_group_add(group, GTK_WIDGET(scheduler_row));
    app->scheduler_row = scheduler_row;

    app->profile_row = ADW_ACTION_ROW(adw_action_row_new());
    adw_preferences_row_set_title(ADW_PREFERENCES_ROW(app->profile_row), "Profil");
    adw_action_row_set_subtitle(app->profile_row, profile_descriptions[0]);
    adw_action_row_set_subtitle_lines(app->profile_row, 2);

    app->profile_dropdown = GTK_DROP_DOWN(gtk_drop_down_new(NULL, NULL));
    GtkStringList *profile_model = gtk_string_list_new(profile_names);
    gtk_drop_down_set_model(app->profile_dropdown, G_LIST_MODEL(profile_model));
    gtk_drop_down_set_selected(app->profile_dropdown, 0);
    g_object_unref(profile_model);
    gtk_widget_set_size_request(GTK_WIDGET(app->profile_dropdown), 180, -1);
    adw_action_row_add_suffix(app->profile_row, GTK_WIDGET(app->profile_dropdown));
    adw_action_row_set_activatable_widget(app->profile_row, GTK_WIDGET(app->profile_dropdown));
    adw_preferences_group_add(group, GTK_WIDGET(app->profile_row));

    g_signal_connect(app->scheduler_dropdown, "notify::selected", G_CALLBACK(on_scheduler_changed), app);
    g_signal_connect(app->profile_dropdown, "notify::selected", G_CALLBACK(on_profile_changed), app);

    return GTK_WIDGET(group);
}

static GtkWidget *make_custom_group(App *app)
{
    AdwPreferencesGroup *group = ADW_PREFERENCES_GROUP(adw_preferences_group_new());
    adw_preferences_group_set_title(group, "Arguments personnalisés");
    adw_preferences_group_set_description(group,
                                          "Ils remplacent le profil prédéfini. Exemple : --performance. Les arguments sont transmis tels quels.");

    app->flags_row = ADW_ENTRY_ROW(adw_entry_row_new());
    adw_preferences_row_set_title(ADW_PREFERENCES_ROW(app->flags_row), "Arguments du scheduler");
    gtk_widget_set_hexpand(GTK_WIDGET(app->flags_row), TRUE);
    adw_preferences_group_add(group, GTK_WIDGET(app->flags_row));

    g_signal_connect(app->flags_row, "changed", G_CALLBACK(on_flags_changed), app);
    return GTK_WIDGET(group);
}

static GtkWidget *make_actions(App *app)
{
    GtkBox *box = GTK_BOX(gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8));
    gtk_widget_set_halign(GTK_WIDGET(box), GTK_ALIGN_END);
    gtk_widget_set_margin_top(GTK_WIDGET(box), 6);
    gtk_widget_set_margin_bottom(GTK_WIDGET(box), 6);

    app->restore_button = GTK_BUTTON(gtk_button_new_with_label("Restaurer par défaut"));
    gtk_widget_add_css_class(GTK_WIDGET(app->restore_button), "flat");
    gtk_widget_set_tooltip_text(GTK_WIDGET(app->restore_button),
                                "Restaurer le scheduler et le profil configurés dans scx_loader");

    app->stop_button = GTK_BUTTON(gtk_button_new_with_label("Désactiver"));
    gtk_widget_add_css_class(GTK_WIDGET(app->stop_button), "destructive-action");

    app->apply_button = GTK_BUTTON(gtk_button_new_with_label("Appliquer"));
    gtk_widget_add_css_class(GTK_WIDGET(app->apply_button), "suggested-action");

    gtk_box_append(box, GTK_WIDGET(app->restore_button));
    gtk_box_append(box, GTK_WIDGET(app->stop_button));
    gtk_box_append(box, GTK_WIDGET(app->apply_button));

    g_signal_connect(app->restore_button, "clicked", G_CALLBACK(on_restore_clicked), app);
    g_signal_connect(app->stop_button, "clicked", G_CALLBACK(on_stop_clicked), app);
    g_signal_connect(app->apply_button, "clicked", G_CALLBACK(on_apply_clicked), app);
    return GTK_WIDGET(box);
}

static void install_css(GApplication *application, gpointer user_data)
{
    (void)application;
    (void)user_data;

    const gchar *css =
        ".scx-status-card { padding: 20px; }"
        ".scx-status-icon { padding: 12px; border-radius: 14px; background-color: alpha(@accent_bg_color, 0.16); color: @accent_color; }"
        ".scx-status-badge { padding: 4px 10px; border-radius: 999px; font-weight: 600; }"
        ".scx-status-badge.success { background-color: alpha(@success_color, 0.18); color: @success_color; }"
        ".scx-status-badge.warning { background-color: alpha(@warning_color, 0.18); color: @warning_color; }"
        ".scx-status-badge.error { background-color: alpha(@error_color, 0.18); color: @error_color; }"
        ".title-1 { font-weight: 800; }";

    GtkCssProvider *provider = gtk_css_provider_new();
    gtk_css_provider_load_from_string(provider, css);
    gtk_style_context_add_provider_for_display(gdk_display_get_default(),
                                               GTK_STYLE_PROVIDER(provider),
                                               GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);
    g_object_unref(provider);
}

static GDBusProxy *create_loader_proxy(GError **error)
{
    return g_dbus_proxy_new_for_bus_sync(G_BUS_TYPE_SYSTEM,
                                         G_DBUS_PROXY_FLAGS_NONE,
                                         NULL,
                                         LOADER_BUS_NAME,
                                         LOADER_OBJECT_PATH,
                                         LOADER_INTERFACE,
                                         NULL,
                                         error);
}

static void activate(GApplication *application, gpointer user_data)
{
    (void)user_data;

    gpointer existing = g_object_get_data(G_OBJECT(application), "scx-manager-window");
    if (existing != NULL) {
        gtk_window_present(GTK_WINDOW(existing));
        return;
    }

    App *app = g_new0(App, 1);
    app->application = ADW_APPLICATION(application);
    app->window = ADW_APPLICATION_WINDOW(adw_application_window_new(GTK_APPLICATION(app->application)));
    gtk_window_set_title(GTK_WINDOW(app->window), "SCX Manager");
    gtk_window_set_default_size(GTK_WINDOW(app->window), 720, 700);
    gtk_window_set_resizable(GTK_WINDOW(app->window), TRUE);

    AdwHeaderBar *header = ADW_HEADER_BAR(adw_header_bar_new());
    GtkLabel *header_title = GTK_LABEL(gtk_label_new("SCX Manager"));
    gtk_widget_add_css_class(GTK_WIDGET(header_title), "title-4");
    adw_header_bar_set_title_widget(header, GTK_WIDGET(header_title));

    app->refresh_button = GTK_BUTTON(gtk_button_new_from_icon_name("view-refresh-symbolic"));
    gtk_widget_set_tooltip_text(GTK_WIDGET(app->refresh_button), "Actualiser l'état");
    gtk_widget_add_css_class(GTK_WIDGET(app->refresh_button), "flat");
    adw_header_bar_pack_start(header, GTK_WIDGET(app->refresh_button));
    g_signal_connect(app->refresh_button, "clicked", G_CALLBACK(on_refresh_clicked), app);

    GtkScrolledWindow *scrolled = GTK_SCROLLED_WINDOW(gtk_scrolled_window_new());
    gtk_scrolled_window_set_policy(scrolled, GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);

    AdwClamp *clamp = ADW_CLAMP(adw_clamp_new());
    adw_clamp_set_maximum_size(clamp, 720);
    gtk_scrolled_window_set_child(scrolled, GTK_WIDGET(clamp));

    GtkBox *content = GTK_BOX(gtk_box_new(GTK_ORIENTATION_VERTICAL, 18));
    gtk_widget_set_margin_start(GTK_WIDGET(content), 18);
    gtk_widget_set_margin_end(GTK_WIDGET(content), 18);
    gtk_widget_set_margin_top(GTK_WIDGET(content), 24);
    gtk_widget_set_margin_bottom(GTK_WIDGET(content), 24);
    adw_clamp_set_child(clamp, GTK_WIDGET(content));

    gtk_box_append(content, make_heading("Planificateur sched-ext",
                                         "Choisissez et appliquez le scheduler BPF qui gère actuellement les tâches de votre système."));
    gtk_box_append(content, make_status_card(app));
    gtk_box_append(content, make_settings_group(app));
    gtk_box_append(content, make_custom_group(app));
    gtk_box_append(content, make_actions(app));

    GtkLabel *footer = GTK_LABEL(gtk_label_new("Les schedulers sched-ext nécessitent un noyau compatible et un agent Polkit fonctionnel pour les opérations privilégiées."));
    gtk_widget_add_css_class(GTK_WIDGET(footer), "caption");
    gtk_widget_add_css_class(GTK_WIDGET(footer), "dim-label");
    gtk_label_set_wrap(footer, TRUE);
    gtk_label_set_xalign(footer, 0.0f);
    gtk_box_append(content, GTK_WIDGET(footer));

    app->toast_overlay = ADW_TOAST_OVERLAY(adw_toast_overlay_new());
    adw_toast_overlay_set_child(app->toast_overlay, GTK_WIDGET(scrolled));

    AdwToolbarView *toolbar = ADW_TOOLBAR_VIEW(adw_toolbar_view_new());
    adw_toolbar_view_add_top_bar(toolbar, GTK_WIDGET(header));
    adw_toolbar_view_set_content(toolbar, GTK_WIDGET(app->toast_overlay));
    adw_application_window_set_content(app->window, GTK_WIDGET(toolbar));

    GError *proxy_error = NULL;
    app->proxy = create_loader_proxy(&proxy_error);
    if (app->proxy == NULL && proxy_error != NULL) {
        g_warning("Unable to create scx_loader D-Bus proxy: %s", proxy_error->message);
        g_clear_error(&proxy_error);
    }

    g_object_set_data(G_OBJECT(application), "scx-manager-window", app->window);
    g_signal_connect(app->window, "close-request", G_CALLBACK(on_window_close), app);
    gtk_window_present(GTK_WINDOW(app->window));
    refresh_app(app);
}

int main(int argc, char **argv)
{
    AdwApplication *application = adw_application_new(APP_ID, G_APPLICATION_DEFAULT_FLAGS);
    g_signal_connect(application, "startup", G_CALLBACK(install_css), NULL);
    g_signal_connect(application, "activate", G_CALLBACK(activate), NULL);

    int status = g_application_run(G_APPLICATION(application), argc, argv);
    g_object_unref(application);
    return status;
}
