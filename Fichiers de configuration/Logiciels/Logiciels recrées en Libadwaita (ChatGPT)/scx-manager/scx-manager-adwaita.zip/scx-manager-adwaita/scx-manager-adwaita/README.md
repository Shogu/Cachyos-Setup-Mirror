# SCX Manager — Libadwaita

Une interface GTK4/Libadwaita native pour gérer les planificateurs `sched-ext`
via le service D-Bus `scx_loader`.

Cette réécriture conserve le fonctionnement de l'application CachyOS originale
et remplace sa couche Qt par une interface adaptée à GNOME :

- état du scheduler actuellement actif ;
- liste des schedulers annoncés par `scx_loader` ;
- profils Auto, Gaming, Power Save, Low Latency et Server ;
- arguments personnalisés ;
- activation, désactivation et restauration du scheduler par défaut ;
- prise en charge du thème clair/sombre de GNOME ;
- authentification via l'agent Polkit déjà présent sur le bureau.

## Dépendances

Sur CachyOS ou Arch Linux :

```bash
sudo pacman -S --needed base-devel meson ninja gtk4 libadwaita pkgconf
```

Le service fonctionnel est fourni par `scx-tools` :

```bash
sudo pacman -S --needed scx-tools scx-scheds
```

Si le service n'est pas lancé automatiquement par D-Bus :

```bash
sudo systemctl enable --now scx_loader.service
```

## Compilation

```bash
meson setup build
meson compile -C build
./build/scx-manager-adwaita
```

## Installation utilisateur

```bash
meson setup build --prefix="$HOME/.local"
meson compile -C build
meson install -C build
update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true
```

Le binaire installé dans `~/.local/bin` doit être accessible dans le `PATH`.

## Architecture

L'application n'exécute pas de commande avec un shell. Elle appelle directement
les méthodes D-Bus documentées de `org.scx.Loader` : `StartScheduler`,
`SwitchScheduler`, leurs variantes `WithArgs`, `StopScheduler` et
`RestoreDefault`. Les arguments personnalisés sont donc transmis comme une
liste de chaînes, sans expansion de commandes par le shell.

Le projet est distribué sous GPL-3.0-or-later.
