#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
build_dir="$project_dir/build"
install_prefix="${PREFIX:-$HOME/.local}"

meson setup "$build_dir" --prefix="$install_prefix" --wipe
meson compile -C "$build_dir"
meson install -C "$build_dir"

if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$install_prefix/share/applications" >/dev/null 2>&1 || true
fi

printf 'SCX Manager installé dans %s\n' "$install_prefix"
