# SCX Manager — Libadwaita

Une interface GTK4/Libadwaita native pour gérer les planificateurs `sched-ext`
via le service D-Bus `scx_loader`.

Cette réécriture conserve le fonctionnement de l'application CachyOS originale
et remplace sa couche Qt par une interface adaptée à GNOME :

- état du scheduler actuellement actif ;
- liste des schedulers annoncés par `scx_loader` ;
- profils Auto, Gaming, Power Save, Low Latency et Server ;
- arguments personnalisés ;
- activation, désactivation et restauration du scheduler par défaut ;
- prise en charge du thème clair/sombre de GNOME ;
- authentification via l'agent Polkit déjà présent sur le bureau.

## Dépendances

Sur CachyOS ou Arch Linux :

```bash
sudo pacman -S --needed base-devel meson ninja gtk4 libadwaita pkgconf
```

Distinction importante :

- `meson`, `ninja` et `pkgconf` sont les outils de compilation temporaires ;
- `base-devel` fournit la chaîne de compilation générale et peut être conservé
  pour les paquets AUR ;
- `gtk4` et `libadwaita` sont nécessaires à la compilation et à l'exécution de
  l'application : ils doivent rester installés ;
- `scx-tools` et `scx-scheds` sont les dépendances d'exécution de SCX Manager.

Les paquets de compilation uniquement peuvent être retirés, si aucun autre
projet ne les utilise :

```bash
sudo pacman -Rns meson ninja pkgconf
```

Ne supprimez pas `base-devel` en bloc sans vérifier les paquets concernés.

Le service fonctionnel est fourni par `scx-tools` et `scx-scheds` :

```bash
sudo pacman -S --needed scx-tools scx-scheds
```

Si le service n'est pas lancé automatiquement par D-Bus :

```bash
sudo systemctl enable --now scx_loader.service
```

## Paquet Arch natif

L'archive `scx-manager-adwaita-0.1.1-pacman.zip` contient un `PKGBUILD` et une
archive source locale. Après extraction :

```bash
unzip scx-manager-adwaita-0.1.1-pacman.zip
cd scx-manager-adwaita
```

Depuis le dossier qui contient le `PKGBUILD`, construisez d'abord le paquet
natif :

```bash
makepkg
```

Puis installez le fichier généré avec `pacman -U` :

```bash
sudo pacman -U ./scx-manager-adwaita-0.1.1-1-x86_64.pkg.tar.zst
```

`makepkg -si` reste possible si vous préférez construire et installer en une
seule commande :

```bash
makepkg -si
```

Le paquet installe le binaire dans `/usr/bin`, le lanceur GNOME et l'icône
corrigée. Pour supprimer uniquement l'application :

```bash
sudo pacman -R scx-manager-adwaita
```

Cette commande conserve `gtk4`, `libadwaita`, `scx-tools` et `scx-scheds`.

Les dépendances de construction du paquet sont `base-devel`, `meson`, `ninja`
et `pkgconf`. Si elles ne servent à aucun autre projet, `meson`, `ninja` et
`pkgconf` peuvent être retirés après compilation :

```bash
sudo pacman -Rns meson ninja pkgconf
```

`base-devel` est un groupe général utile notamment pour construire des paquets
AUR ; ne le supprimez pas en bloc sans vérifier vos besoins.

## Compilation

```bash
meson setup build
meson compile -C build
./build/scx-manager-adwaita
```

## Installation utilisateur alternative

Le script `install.sh` affiche les dépendances de compilation et, sur
Arch/CachyOS, installe celles qui manquent avant de construire l'application :

```bash
./install.sh
```

Pour ignorer l'installation automatique des paquets de compilation :

```bash
SKIP_BUILD_DEPS=1 ./install.sh
```

Les paquets d'exécution `scx-tools` et `scx-scheds` doivent être présents,
mais ne sont pas modifiés par le script.

Pour désinstaller l'application installée dans `~/.local` :

```bash
./uninstall.sh
```

Les scripts n'effacent pas les paquets de compilation. Si `meson`, `ninja` et
`pkgconf` ne servent plus à aucun autre projet, ils peuvent être retirés :

```bash
sudo pacman -Rns meson ninja pkgconf
```

Installation manuelle équivalente :

```bash
meson setup build --prefix="$HOME/.local"
meson compile -C build
meson install -C build
update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true
```

Le binaire installé dans `~/.local/bin` doit être accessible dans le `PATH`.

## Architecture

L'application n'exécute pas de commande avec un shell. Elle appelle directement
les méthodes D-Bus documentées de `org.scx.Loader` : `StartScheduler`,
`SwitchScheduler`, leurs variantes `WithArgs`, `StopScheduler` et
`RestoreDefault`. Les arguments personnalisés sont donc transmis comme une
liste de chaînes, sans expansion de commandes par le shell.

Le projet est distribué sous GPL-3.0-or-later.
